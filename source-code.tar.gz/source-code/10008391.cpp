//Language: GNU C++


/*Author: Rishul Aggarwal*/

#include<bits/stdc++.h>

#define mod 1000000007
#define ll long long
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define in(type,x) scanf("%" #type,&x)
#define debug(args...) {dbg,args; cerr<<endl;}
#define test int t;\
in(d,t);\
while(t--)

using namespace std;

struct debugger
{template<typename T> debugger& operator,(const T& v)
{cerr<< v <<" ";
return *this;
}
}dbg;

ll gcd(ll a,ll b) {if(b==0) return a; return gcd(b,a%b);}

ll power(ll b,ll exp,ll m) {ll ans=1; b%=m; while(exp){if(exp&1) ans=(ans*b)%m; exp>>=1; b=(b*b)%m; } return ans; }


int main()
{
  
  string a,b,c;
  cin>>a>>b;
  c=a;
  int l=a.length();
  for(int i=l-1;i>=0;i--)
  {
    if(a[i]!='z') {a[i]++; break;}
    else a[i]='a';
  }
    
  if(a>c && a<b) cout<<a;
  else cout<<"No such string";
  
  return 0;
}
