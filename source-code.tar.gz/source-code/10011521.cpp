//Language: GNU C++0x


#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
double dp[2005][2005],s[2005][2005];
int main ()
{
    int i,j,n,t;
    double p;
    cin>>n>>p>>t;
    dp[1][1]=p;
    s[1][1]=dp[1][1];
    for(i=2;i<=t;i++){
        dp[1][i]=dp[1][i-1]*(1-p);
        s[1][i]=s[1][i-1]*(1-p)+dp[1][i];
    }
    for(i=2;i<=t;i++){
        for(j=i;j<=t;j++){
            dp[i][j]=s[i-1][j-1]*p;
            s[i][j]=s[i][j-1]*(1-p)+dp[i][j];
        }
    }
    double ss=0;
    for(i=1;i<=n;i++){
        for(j=1;j<=t;j++){
            ss+=dp[i][j];
        }
    }
    printf("%.6lf\n",ss);
}