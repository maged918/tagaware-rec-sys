//Language: MS C++


#if 1
#include <iostream>
#include <cstdio>
#include <numeric>
#include <vector>
#include <string>
#include <deque>
#include <map>
#include <set>
#include <bitset>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <locale>

using namespace std;
#define PROBLEM "problem"
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> pii;
#define X first 
#define Y second 

const int INF = 1000 * 1000 * 1000 + 100;
const LL INF64 = 1LL * INF * INF;
const LL mod = INF + 7;

LL a[int(1e5) + 100] = {};
bool is[int(1e5) + 100] = {};

void solve()
{
    int n, k;
    scanf("%d %d\n", &n, &k);

    char s[12];
    for (int i = 0; i < n; ++i)
    {   
        scanf("%s", s);
        if (s[0] == '?')
            is[i] = 1;
        else
            a[i] = atoi(s);
    }

    for (int i = 0; i < k; ++i)
    {
        int beg = -INF, end = -INF;
        LL l = 0;
        for (int j = i; j < n; j += k)
        {
            if (is[j] && beg == -INF)
                beg = j - k,l=1;
            else if (is[j])
                l++;
            else if (!is[j] && beg != -INF)
                end = j;

            if (beg != -INF && (end != -INF || j+k >= n))
            {
                if (beg < 0 && end != -INF)
                    a[beg + k] = min(a[end] - l, -(l / 2)), beg += k,l--;
                else if (beg < 0)
                    a[beg + k] = -(l / 2), a[j] = l - (l / 2) - 1, beg += k, end = j,l-=2;
                else if (end == -INF)
                {
                    if (a[beg] >= -(l / 2) - 1)
                        a[j] = a[beg] + l, end = j;
                    else
                    {
                        a[j] = -(l / 2) + l - 1;
                    }
                    l--;
                    end = j;
                }

                is[beg] = 0, is[end] = 0;

                if (a[end] - a[beg] - 1 < l)
                {
                    puts("Incorrect sequence");
                    return;
                }

                if (a[beg] > 0 && a[end] > 0)
                {
                    for (int p = beg + k; p < end; p += k)
                        a[p] = a[p - k] + 1, is[p] = 0;
                }
                else if (a[beg] < 0 && a[end] < 0)
                {
                    for (int p = end - k; p > beg; p -= k)
                        a[p] = a[p + k] - 1, is[p] = 0;
                }
                else if (beg + k < end)
                {
                    a[beg + k] = min(-(l / 2), a[end] - l);
                    a[beg + k] = max(a[beg + k], a[beg] + 1);

                    for (int p = beg + k + k; p < end; p += k)
                        a[p] = a[p - k] + 1, is[p] = 0;
                }
                beg = -INF, end = -INF;
            }
        }
    }

    for (int i = 0; i < k; ++i)
    {
        for (int j = i + k; j < n; j += k)
        {
            if (a[j] <= a[j - k])
            {
                puts("Incorrect sequence");
                return;
            }
        }
    }

    for (int i = 0; i < n; ++i)
        printf("%d ", a[i]);
    puts("");
}

int main()
{
#ifdef _DEBUG
    freopen("input.txt", "r", stdin); //freopen("output.txt", "w", stdout);
#else
    //freopen(PROBLEM".in", "r", stdin); freopen(PROBLEM".out", "w", stdout);
#endif


    //ios_base::sync_with_stdio(false);
    solve();

    return 0;
}
#endif