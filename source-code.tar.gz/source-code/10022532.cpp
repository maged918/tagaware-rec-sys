//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <string>
#include <memory.h>
#include <math.h>
#define pr pair <int,int>
#define mp make_pair
#define pb push_back
using namespace std;
int main()
{
    int h = 0,j = 0;
    string a,b;
    vector <char> vec;
    cin >> a >> b;
    if(a == b)
    {
        cout << "No such string" << endl;
        return 0;
    }
    for(int i = a.length()-1 ; i >= 0 ;i--)
    {
         if(a[i] == 'z' && h == 0)
            vec.pb('a');
         else if(h == 0)
          vec.pb(char(a[i] + 1)),h = 1;
         else
            vec.pb(a[i]);
          if(vec[vec.size()-1] != b[i])
            j = 1;
    }
    if(h == 1 && j == 1)
     for(int i = vec.size()-1 ;i >= 0 ;i--)
        cout << vec[i];
    else
        cout << "No such string";
    cout << endl;
    return 0;
}
