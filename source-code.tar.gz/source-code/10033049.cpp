//Language: GNU C++0x


#include <iostream>

using namespace std;

const long long LIM = 1001;
const long long REM = 100;

long long ans[LIM][REM][2];
long long pow[LIM];

int main() {
  long long n, k, m;
  cin >> n >> k >> m;
  pow[0] = 1 % k;
  for (long long i = 1; i < n; ++i)
    pow[i] = (pow[i - 1] * 10) % k;

  //for (long long i = 1; i < 10; ++i)
  //  ++ans[1][i % k][1];
  //++ans[1][0][0];

  for (long long i = 0; i < n; ++i) {
    //cout << i << " : ";
    for (long long d = 1; d < 10; ++d) {
      long long new_rem = (d * pow[i]) % k;
      ++ans[i + 1][new_rem][1];
      ans[i + 1][new_rem][1] %= m;
    }
    for (long long j = 1; j < k; j++) {
      for (long long d = 1; d < 10; ++d) {
        long long new_rem = ((d * pow[i]) % k + j) % k;
        //cout << "(" << i + 1 << "," << new_rem << ") ";
        ans[i + 1][new_rem][1] += ans[i][j][1] + ans[i][j][0];
        ans[i + 1][new_rem][1] %= m;
      }
      ans[i + 1][j][0] += ans[i][j][1] + ans[i][j][0];
      ans[i + 1][j][0] %= m;
    }
    //cout << endl;
  }
  long long buf = 0;
  long long cur_pow = 1;
  for (long long i = n; i > 0; --i) {
    buf += (ans[i][0][1] * cur_pow);
    buf %= m;
    if (i == n)
      cur_pow *= 9;
    else
      cur_pow *= 10;
    cur_pow %= m;
  }
  cout << buf;
  return 0;
}
