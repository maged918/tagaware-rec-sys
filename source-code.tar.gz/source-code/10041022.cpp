//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<string>
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
const int N=100100;
const int mark=1e9+N;
const int inf=mark+N;
int a[N];
int n,K;
void solve(){
    scanf("%d%d",&n,&K);
    char s[100];
    for(int i=0;i<n;i++){
        scanf("%s",s);
        if('?'==s[0])a[i]=mark;
        else sscanf(s,"%d",&a[i]);
    }
    for(int i=0;i<K;i++){
        vector<int> v;
        v.push_back(-inf);
        for(int j=i;j<n;j+=K){
            v.push_back(a[j]);
        }
        v.push_back(inf);
        for(int j=0,tmp=0;j<v.size();j=tmp){
            tmp=j+1;
            for(;tmp<v.size()&&v[tmp]==mark;tmp++);
            if(tmp>=v.size())break;
            if(tmp-j>v[tmp]-v[j]){
                puts("Incorrect sequence");
                return ;
            }
            if(v[tmp]<=0){
                for(int k=tmp-1;k>j;k--){
                    v[k]=v[k+1]-1;
                }
            }
            else if(v[j]>=0){
                for(int k=j+1;k<tmp;k++){
                    v[k]=v[k-1]+1;
                }
            }
            else{
                vector<int> aa;
                aa.push_back(0);
                for(int tt=1;aa.size()<tmp-j-1;tt++){
                    if(-tt>v[j])aa.push_back(-tt);
                    if(tt<v[tmp])aa.push_back(tt);
                }
                sort(aa.begin(),aa.end());
                for(int k=j+1;k<tmp;k++){
                    v[k]=aa[k-j-1];
                }
            }
        }
        for(int j=1,k=i;j+1<v.size();j++,k+=K){
            a[k]=v[j];
        }
    }
    for(int i=0;i<n;i++){
        printf("%d ",a[i]);
    }
}

int main(){
    solve();
    return 0;
}
