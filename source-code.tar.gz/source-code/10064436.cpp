//Language: GNU C++0x


#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

typedef unsigned long long ull;
typedef pair<ll,ll> ii;
typedef vector<ll> vi;
typedef vector< ii > vii;

#define INF 0x3F3F3F3F
#define LINF 0x3F3F3F3F3F3F3F3FLL
#define pb push_back
#define mp make_pair
#define pq priority_queue
#define LSONE(s) ((s)&(-s)) //LASTBIT
#define DEG_to_RAD(X)   (X * PI / 180)
#define F first
#define S second

 
#ifdef ONLINE_JUDGE
#define debug(args...)
#else
#define debug(args...) fprintf(stderr,args)
#endif

//////////////////////
int dx[] = {1,-1,0,0};
int dy[] = {0,0,-1,1};	
//////////////////////

const int N = 1000100;

string s1 = "qrbnpk";
string s2 = "QRBNPK";

int pts[6] = {9,5,3,3,1,0};

int main()
{
	//ios::sync_with_stdio(0);
	int p1,p2;
	p1 = p2 = 0;
	for(int i=0;i<8;++i)
	{
		for(int j=0;j<8;++j)
		{
			char c; scanf(" %c",&c);
			for(int k=0;k<s1.size();++k)
			{
				if( c == s1[k] )
					p1+=pts[k];
			}
			for(int k=0;k<s2.size();++k)
			{
				if( c == s2[k] )
					p2+=pts[k];
			}

		}
	}
	if(p1<p2) printf("White\n");
	else if(p1>p2) printf("Black\n");
	else printf("Draw\n");
	return 0;
}
