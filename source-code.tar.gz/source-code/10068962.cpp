//Language: GNU C++


#include <iostream>
#include <cmath>
#include <algorithm>
#include <set>

using namespace std;

typedef long long ll;

multiset<int> s, s2;



int main()
{
	ios::sync_with_stdio(false);

	int n;
	cin >> n;

	for (int i=0; i<n; i++)
	{
		int t;
		cin >> t;
		s.insert(t);
	}

	for (int i=0; i<n-1; i++)
	{
		int t;
		cin >> t;
		s2.insert(t);
		s.erase(s.find(t));
	}

	cout << *s.begin() << "\n";

	for (int i=0; i<n-2; i++)
	{
		int t;
		cin >> t;
		s2.erase(s2.find(t));
	}

	cout << *s2.begin() << "\n";

	return 0;
}