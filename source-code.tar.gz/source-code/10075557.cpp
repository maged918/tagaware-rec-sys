//Language: GNU C++0x


#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <algorithm>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <string>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>

using namespace std;

#define sz(a) (int)(a.size())
#define len(a) (int)(a.length())
#define pb push_back
#define mp make_pair
#define fi first
#define se second

const int N=1e5+3;

int cnt[N];
int par[N][18];
vector<int> edges[N];
int depth[N];

void dfs(int i)
{
	cnt[i]=1;
	for(int j=0;j<sz(edges[i]);++j)
	{
		int v=edges[i][j];
		if(v==par[i][0]) continue;
		par[v][0]=i;
		depth[v]=depth[i]+1;
		for(int de=1;de<18;++de)
			par[v][de]=par[par[v][de-1]][de-1];
		dfs(v);
		cnt[i]+=cnt[v];
	}
}

int lca(int u,int v)
{
	if(depth[u]>depth[v]) swap(u,v);
	for(int de=17;de>=0;--de)
		if(depth[par[v][de]]>depth[u])
		{
			v=par[v][de];
		}
	if(depth[v]>depth[u]) v=par[v][0];
	//assert(depth[v]==depth[u]);
	for(int de=17;de>=0;--de)
		if(par[v][de]!=par[u][de])
		{
			v=par[v][de];
			u=par[u][de];
		}
	if(u!=v)
	{
		//assert(par[u][0]==par[v][0]);
		u=par[u][0];
	}
	return u;
}

int dist(int u,int v)
{
	return depth[u]+depth[v]-2*depth[lca(u,v)];
}

int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n-1;++i)
	{
		int u,v;
		cin>>u>>v;
		edges[u].pb(v);
		edges[v].pb(u);
	}
	dfs(1);
	int m;
	cin>>m;
	for(int qq=0;qq<m;++qq)
	{
		int x,y;
		cin>>x>>y;
		if(x==y)
		{
			cout<<n<<'\n';
			continue;
		}
		int LCA=lca(x,y);
		int dist_x_y=dist(x,y);
		if(dist_x_y&1)
		{
			cout<<0<<'\n';
		}
		else
		{
			int dist_x_LCA=dist(x,LCA);
			int dist_y_LCA=dist(y,LCA);
			if(dist_x_LCA==dist_x_y/2)
			{
				int answer=n;
				int t_x=x;
				for(int de=17;de>=0;--de)
					if(depth[par[t_x][de]]>depth[LCA])
					{
						t_x=par[t_x][de];
					}
				//assert(depth[t_x]==depth[LCA]+1);
				answer-=cnt[t_x];
				int t_y=y;
				for(int de=17;de>=0;--de)
					if(depth[par[t_y][de]]>depth[LCA])
					{
						t_y=par[t_y][de];
					}
				//assert(depth[t_y]==depth[LCA]+1);
				answer-=cnt[t_y];
				cout<<answer<<'\n';
			}
			else if(dist_x_LCA>dist_x_y/2)
			{
				int other_side=dist_y_LCA;
				int leave_from_top=dist_x_y/2-other_side;
				int target_depth=depth[LCA]+leave_from_top;
				--target_depth;
				int t_x=x;
				for(int de=17;de>=0;--de)
					if(depth[par[t_x][de]]>target_depth)
					{
						t_x=par[t_x][de];
					}
				++target_depth;
				//assert(depth[t_x]==target_depth);
				int answer=cnt[t_x];
				t_x=x;
				for(int de=17;de>=0;--de)
				{
					if(depth[par[t_x][de]]>target_depth)
					{
						t_x=par[t_x][de];
					}
				}
				//assert(depth[t_x]==target_depth+1);
				answer-=cnt[t_x];
				cout<<answer<<'\n';
			}
			else
			{
				int other_side=dist_x_LCA;
				int leave_from_top=dist_x_y/2-other_side;
				int target_depth=depth[LCA]+leave_from_top;
				--target_depth;
				int t_y=y;
				for(int de=17;de>=0;--de)
					if(depth[par[t_y][de]]>target_depth)
					{
						t_y=par[t_y][de];
					}
				++target_depth;
				//assert(depth[t_y]==target_depth);
				int answer=cnt[t_y];
				t_y=y;
				for(int de=17;de>=0;--de)
				{
					if(depth[par[t_y][de]]>target_depth)
					{
						t_y=par[t_y][de];
					}
				}
				//assert(depth[t_y]==target_depth+1);
				answer-=cnt[t_y];
				cout<<answer<<'\n';
			}
		}
	}


	return 0;
}