//Language: GNU C++


// ...............................BIG OH.....................................//
//prob-
//Algo-
//complexity-
#include<cstdio>
#include<iostream>
#include<cstring>
#include<sstream>
#include<stdlib.h>
#include<algorithm>
#include<cmath>
#include<vector>
#include<map>
#include<set>
#include<list>
#include<stack>
#include<queue>
#include<iomanip>
#include<ctype.h>
#include<complex>
#include<utility>
#include<functional>
#include<bitset>
#include<numeric>
#include<cassert>
#include<climits>
 
using namespace std;
#define ll long long 
#define gc getchar_unlocked
//#define inf 1000000000000000006LL
#define mod 1000000009
#define pq priority_queue
#define vi vector<int>
#define eps 1e-9
//#define inf (1 << 28)
#define pb push_back
#define del( a ) memset( a , 0 , sizeof ( a ) )

map<char,int>m1,m2;

int main()
{
   m1['Q']=9;m2['q']=9;
   m1['R']=5;m2['r']=5;
   m1['B']=3;m2['b']=3;
   m1['N']=3;m2['n']=3;
   m1['P']=1;m2['p']=1;
   m1['K']=0;m2['k']=0;
   int ans1=0,ans2=0;
   string str;
   for(int j=0;j<8;j++)
   {
     cin>>str;
     for(int i=0;i<8;i++) 
     {
       if(str[i]!='.')
       {
           if(str[i]=='Q'|| str[i]=='R'|| str[i]=='B'|| str[i]=='N'||str[i]=='P'|| str[i]=='K')
           ans1+=m1[str[i]];
           else
            ans2+=m2[str[i]];
        }
     }
   }
   if(ans1>ans2) cout<<"White\n";
   else if(ans1==ans2) cout<<"Draw\n";
   else cout<<"Black\n";
}