//Language: GNU C++


#include<stdio.h>
#include<vector>
#include<map>
#include<set>
#include<math.h>
#include<string.h>
#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
    char a[105],a1;
    int b[27],c,d,l,i,j;
    scanf("%d",&d);
    scanf("%s",a);
    for(i=0; i<26; i++)
        b[i]=0;
    for(i=0; i<d; i++)
    {
        if(a[i]>='a' && a[i]<='z')
            l=a[i]-97;
        else
            l=a[i]-65;
        b[l]++;
    }
    c=0;
    for(i=0; i<26; i++)
    {
        if(b[i]==0)
        {
            c=1;
            break;
        }
    }
    if(c==0)
        printf("YES\n");
    else
        printf("NO\n");
    return 0;
}


