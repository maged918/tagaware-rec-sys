//Language: GNU C++0x


#include <cstdio>
#include <algorithm>
#include <iostream>
#include <set>
#include <cmath>
#include <string>
#include <cstring>
#include <queue>

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
#define MOD 1000000007
int N;

int coun[4];

int main() {

    cin >> N;
    string str;
    cin >> str;
    for(int i = 0; i < N; i++){
        if(str[i] == 'A'){
            coun[0]++;
        }
        if(str[i] == 'G') coun[1]++;
        if(str[i] == 'C') coun[2]++;
        if(str[i] == 'T') coun[3]++;
    }
    int ma = 0;
    for(int i = 0; i < 4; i++){
        ma = max(coun[i], ma);
    }
    ll c = 0;
    for(int i = 0; i < 4; i++){
        if(coun[i] == ma) c++;
    }
    ll total = 1;
    for(int i = 0; i < N; i++){
        total *= c;
        total = total%MOD;
    }

    cout << total << endl;

}
