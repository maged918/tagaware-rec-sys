//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <string>
#include <map>
#include <stack>
#include <vector>
#include <set>
#include <queue>
#pragma comment (linker,"/STACK:102400000,102400000")
#define maxn 100005
#define MAXN 2005
#define mod 1000000007
#define INF 0x3f3f3f3f
#define pi acos(-1.0)
#define eps 1e-6
#define lson rt<<1,l,mid
#define rson rt<<1|1,mid+1,r
#define FRE(i,a,b)  for(i = a; i <= b; i++)
#define FRL(i,a,b)  for(i = a; i < b; i++)
#define mem(t, v)   memset ((t) , v, sizeof(t))
#define sf(n)       scanf("%d", &n)
#define sff(a,b)    scanf("%d %d", &a, &b)
#define sfff(a,b,c) scanf("%d %d %d", &a, &b, &c)
#define pf          printf
#define DBG         pf("Hi\n")
typedef long long ll;
using namespace std;

__int64 n;
char str[maxn];
__int64 num[30];

__int64 pow_m(__int64 a,__int64 n)
{
    __int64 ret=1;
    __int64 tmp=a%mod;
    while (n)
    {
        if (n&1) ret=(ret*tmp)%mod;
        tmp=tmp*tmp%mod;
        n>>=1;
    }
    return ret;
}

int main()
{
    while (~scanf("%I64d",&n))
    {
        scanf("%s",str);
        mem(num,0);
        for (__int64 i=0;i<n;i++)
            num[ str[i]-'A' ]++;
        __int64 maxx=0;
        for (__int64 i=0;i<26;i++)
            maxx=max(maxx,num[i]);
        __int64 m=0;
        for (__int64 i=0;i<26;i++)
            if (num[i]==maxx) m++;
        printf("%I64d\n",pow_m(m,n));
    }
    return 0;
}
