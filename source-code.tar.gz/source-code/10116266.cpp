//Language: GNU C++0x


#include <sstream>
#include <string>
#include <queue>
#include <iostream>
#include <stdio.h>
#include <vector>
#include <map>
#include <set>
#include <algorithm>
using namespace std;
#define MOD 1000000009LL
#define fs first
#define sc second
#define mp make_pair
#define pb push_back

long long dx[] = {-1,0,1};
long long dy[] = {1,1,1};
long long dx1[] = {-1,0,1,-2,+2,-1,0,1,-2,+2,-1,0,1,-2,+2};
long long dy1[] = {1,1,1,1,1,-1,-1,-1,-1,-1,0,0,0,0,0};
long long N;
string s;
map<pair<long long,long long>, long long> h;
map<pair<long long,long long>, long long> hnr;
vector<pair<long long,long long> > vec;
long long nr,mmax;
set<long long> S;
long long vf[501010];
long long pos;

long long getMin(){
    set<long long>::iterator it = S.begin();
    long long ret = *it;
    S.erase(it);
    return ret;
}
long long getMax(){
    set<long long>::iterator it = S.end();
    --it;
    long long ret = *it;
    S.erase(it);
    return ret;
}


long long isStable(long long x,long long y){
    if(h[mp(x,y)] == 0)
        return 0;
    for(long long i=0;i<3;++i){
        if(hnr[mp(x+dx[i],y+dy[i])] == 1)
            return 0;
    }
    return 1;
}
long long recheckStable(long long x,long long y){
    if(h[mp(x,y)] == 0)
        return 0;
    set<long long>::iterator it = S.find(h[mp(x,y)] - 1);
    if(isStable(x,y)){
       if(it == S.end()){
        S.insert(h[mp(x,y)] - 1);
       }
    } else {
        if(it != S.end()){
            S.erase(it);
        }
    }
    return 1;
}

void make(long long x){
    pair<long long,long long> a = vec[x];
    for(long long i=0;i<3;++i){
        long long x=a.fs + dx[i];
        long long y=a.sc + dy[i];
        if(h[mp(x,y)]){
            --hnr[mp(x,y)];
        }
    }
    h[a]=0;
    hnr[a]=0;
    for(long long i=0;i<15;++i){
        //printf("%d %d!!!\n",dx1[i],dy1[i]);
        recheckStable(a.fs+dx1[i],a.sc+dy1[i]);
    }
}

int main(){
  //  freopen("test1.in","r",stdin);
    cin>>N;
    pos = N;
    for(long long i=1;i<=N;++i){
        long long x,y;
        cin>>x>>y;
        h[mp(x,y)] = i;
        vec.pb(mp(x,y));
    }
    for(long long i=0;i<N;++i){
        long long x = vec[i].fs;
        long long y = vec[i].sc;
        for(long long j=0;j<3;++j){
            if(h[mp(x+dx[j],y-dy[j])])
                hnr[mp(x,y)]++;
        }
    }
    for(long long i=0;i<N;++i){
        long long x = vec[i].fs;
        long long y = vec[i].sc;

        if(isStable(x,y)){
            S.insert(i);
        }
    }

    long long nr = 0;
    while(S.size()>0){
        //printf("%d\n",S.size());
        long long val=0;

        if(nr % 2 == 0){
            val = getMax();
        } else {
            val = getMin();
        }

        make(val);
        vf[pos] = val;
        --pos;
        ++nr;
    }
    long long pox = 1;
    long long ret = 0;
    for(long long i=1;i<=N;++i){
        ret += 1LL*vf[i] * pox;
        ret %= MOD;
        pox*=N;
        pox%=MOD;
    }
    cout<<ret%MOD<<endl;
    return 0;

}
