//Language: MS C++


#include <iostream>
#include <queue>
#include <algorithm>
#include <string>
using namespace std;



long long powop(long long a,long long b){
    long long res=1;
    for(int i=0;i<b;++i)
        res=(res*a)%1000000007;
    return res;

}

char ch,AA[5]="ACGT";

int main(){
    int n,m,bio[4]={0,0,0,0},lel=4;

    cin>>n;
    for(int i=0;i<n;++i){
        cin>>ch;
        for(int j=0;j<4;++j)
            if(AA[j]==ch)
                ++bio[j];
    }
    sort(bio,bio+4);
    if(bio[2]!=bio[3])
        cout<<1;
    else
        if(bio[1]!=bio[2])
            cout<<powop(2,n);
        else
            if(bio[0]!=bio[1])
                cout<<powop(3,n);
            else
                cout<<powop(4,n);

















    return 0;
}