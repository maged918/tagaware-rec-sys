//Language: GNU C++


#include <iostream>
#include <cmath>
#include <cstdio>
#include <algorithm>

#define Mod 1000000007

using namespace std;

long long C[2635][2635];

inline void init()
{
    for(int i = 0;i < 2630;++i)
        for(int j = 0;j < 2630;++j)
        {
            if(!j)
                C[i][j] = 1;

            else if(!i)
                C[i][j] = 0;

            else
            {
                C[i][j] = C[i - 1][j] + C[i - 1][j - 1];
                if(C[i][j] >= Mod)
                    C[i][j] -= Mod;
            }
        }

    return;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    init();
    int t;
    string A;
    cin >> t;
    while(t--)
    {
        int len;
        long long sum = 0;
        cin >> A;
        len = A.size();

        for(int i = 0;i < len;++i)
            sum += (A[i] - 'a');

        long long ans = 0;
        for(int i = 0;i < len;++i)
        {
            long long k = sum - i * 26;
            if(k < 0)
                break;

            if(i & 1)
                ans -= (C[len][i] * C[len + k - 1][k]) % Mod;

            else
                ans += (C[len][i] * C[len + k - 1][k]) % Mod;

            if(ans >= Mod)
                ans -= Mod;
        }
        --ans;
        ans = (ans % Mod + Mod) % Mod;
        cout << ans << endl;
    }
    return 0;
}
