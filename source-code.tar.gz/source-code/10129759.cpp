//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

typedef long long lint;
const lint MAXN = 6e5+222;
const lint mod = 1e9+7;
const lint mod1= 1e8+7;

lint N,M,prime[MAXN],val1[MAXN],val2[MAXN];
lint prime1[MAXN],val11[MAXN],val22[MAXN];
string s[MAXN],q[MAXN];
map<lint,bool> mp,mp1;

int main(){
	
	cin>>N>>M;
	for(lint i=1;i<=N;i++)
		cin>>s[i];
	for(lint i=1;i<=M;i++)
		cin>>q[i];
	
	prime[0]=255;
	for(lint i=1;i<=6e5;i++)
		prime[i]=prime[i-1]*255%mod;
	prime1[0]=255;
	for(lint i=1;i<=6e5;i++)
		prime1[i]=prime1[i-1]*255%mod1;
	
	for(lint i=1;i<=N;i++){
		for(lint j=0;j<(lint)s[i].size();j++)
			val1[i]=(val1[i]+(s[i][j]-'a'+1)*prime[j])%mod;
		mp[val1[i]]=1;
	}
	for(lint i=1;i<=M;i++)
		for(lint j=0;j<(lint)q[i].size();j++)
			val2[i]=(val2[i]+(q[i][j]-'a'+1)*prime[j])%mod;
	
	for(lint i=1;i<=N;i++){
		for(lint j=0;j<(lint)s[i].size();j++)
			val11[i]=(val11[i]+(s[i][j]-'a'+1)*prime1[j])%mod1;
		mp1[val11[i]]=1;
	}
	for(lint i=1;i<=M;i++)
		for(lint j=0;j<(lint)q[i].size();j++)
			val22[i]=(val22[i]+(q[i][j]-'a'+1)*prime1[j])%mod1;
	
	for(lint i=1;i<=M;i++){
		lint cnt=0;
		for(lint j=0;j<(lint)q[i].size();j++){
			for(char k='a';k<='c';k++)
				if(k!=q[i][j]){
					lint tmp=val2[i];
					tmp-=prime[j]*(q[i][j]-'a'+1);
					tmp+=prime[j]*(k-'a'+1);
					tmp%=mod;
					if(tmp<0) tmp+=mod;
					lint tmp1=val22[i];
					tmp1-=prime1[j]*(q[i][j]-'a'+1);
					tmp1+=prime1[j]*(k-'a'+1);
					tmp1%=mod1;
					if(tmp1<0) tmp1+=mod1;
					if(mp[tmp] && mp1[tmp1])
						cnt=1;
				}
		}
		if(cnt)
			cout<<"YES"<<endl;
		else
			cout<<"NO"<<endl;
	}
	
	return 0;
}
