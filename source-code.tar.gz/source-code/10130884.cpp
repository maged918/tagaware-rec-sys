//Language: GNU C++


#include<stdio.h>
#include<string.h>
char c[2020];
main()
{
	int m=0,s=0,i,j,k,a[30];
	gets(c);
	scanf("%d",&k);
	for(i=0;i<26;i++)
	    scanf("%d",&a[i]);
    j=strlen(c);
    for(i=0;i<j;i++)
        s+=(i+1)*a[c[i]-97];
    for(i=0;i<26;i++)
        if(m<a[i])m=a[i];
    for(i=j+1;i<=j+k;i++)
    s+=m*i;
    printf("%d\n",s);
}

		  		  		  		 	   				 			 			