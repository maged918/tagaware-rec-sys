//Language: GNU C++0x


#include<bits/stdc++.h>
#define in freopen("input.txt","r",stdin)
#define out freopen("output.txt","w",stdout)

#define inp freopen(".in","r",stdin)
#define outp freopen(".out","w",stdout)

using namespace std;

#define pb push_back
#define pf push_front
#define p_f pop_front
#define p_b pop_back
#define LL long long int
#define LD long double
#define MP make_pair
#define sqr(x) (x*x)
#define fi first
#define dist(x,y,xx,yy) sqrt( (x-xx)*(x-xx)+(y-yy)*(y-yy) )
#define lenint int intsi(int x){ int cnt=0; while(x>0){cnt++;x/=10;} return (cnt); }
#define se second
#define all(v) v.begin(),v.end()
#define sc scanf
#define DEBUG(a) cout<<#a<<" -> "<<a<<endl;
#define pr printf
#define si size()
#define str strlen
#define time clock()/(double)CLOCKS_PER_SEC
#define gcd LL GCD(LL a,LL b){ if(b==0)return a;else return GCD(b,a%b); }
const int INF=(-1u)/2;
const long long int INF2=(-1ull)/2;
int a,b,i,d[2050][2050],j,k,n,m,timer=0,l,r,x,y,mx,mn;
int c[1011000],cnt=0,fl=0,a2,a3=-1000000,ans=0;
main()
{
    #ifndef ONLINE_JUDGE
        in;out;
    #endif
    ios_base::sync_with_stdio(0);
    cin>>n;
    mx=mn=1001;
    mn=999;
    x=0;
    y=1000;
    for( i=0;i<n;i++ )
    {
        cin>>c[i];
        for( ;c[i]>0;((i%2==0) ? y++ : y--) , x++,c[i]-- )
        {
            ((i%2==0) ? d[x][y]=1 : d[x][y]=2);
        }
        mx=max( mx,y );
        mn=min( mn,y );
        ((i%2==0) ? y-- : y++);
    }
    //cout<<mx-1000<<" "<<mn-1000<<endl;
    cnt=0;
    //d[0][1000]=1;
    for( j=mx-1;j>mn;j-- )
    {
        cnt=0;
        for( i=0;i<x;i++ )
        {
            if( d[i][j] )
            {
                cnt=0;
                if( d[i][j]==2 )cout<<"\\";
                else cout<<"/";
            }
            else cout<<" ";
        }
        cout<<endl;
    }
    return 0;
}
