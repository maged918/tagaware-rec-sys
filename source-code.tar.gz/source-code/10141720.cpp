//Language: GNU C++


#include<bits/stdc++.h>
#define N 100005
#define INF (1<<30)
using namespace std;

int n, m, a[N];
char buf[12];

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>buf;
        if(buf[0] == '?') a[i] = INF;
        else a[i] = atoi(buf);
    }

    for(int i=0;i<m;i++){
        int prev = -INF, s =( (n - i - 1) / m) + 1;
        //cout<<"i:"<<i<<"\ts:"<<s<<endl;
        for(int j=0;j<s;j++){
            int k = j, next = INF;
            while(k < s && a[i + k * m] == INF) k++;
            //cout<<"\tj:"<<j<<"\tk:"<<k<<"\tprev:"<<prev<<endl;
            if(k < s) next = a[i + k * m];

            //cout<<"\t\tnext:"<<next<<"\tk-j+prev:"<<prev<<endl;

            if(next <= k - j + prev){
                cout<<"Incorrect sequence";
                return 0;
            }

            int up = (k - j + 1) / 2;
            up = min(up, next);
            up = max(up, prev + k - j + 1);

            for(int x=j;x<k;x++){
                a[i + x * m] = up - k + x;
            }
            prev = next;
            j = k;
        }
    }

    for(int i=0;i<n;i++){
        cout<<a[i];
        if(i==n-1)cout<<"\n";
        else cout<<" ";
    }
}
