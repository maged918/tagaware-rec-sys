//Language: GNU C++0x


#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef vector< ll > Row;
typedef vector< Row > Matrix;
const int kD = 101;
const ll kMod = 1000000007LL;

int N, X, A[kD];
Matrix mR, mQ;

void read();
void solve();

Matrix mtrx_mul(const Matrix &, const Matrix &);

int main() {
  ios::sync_with_stdio(false);
  read();
  solve();

  return 0;
}

void read() {
  int di;
  cin >> N >> X;
  for (int i = 0; i < N; ++i)
    cin >> di, ++A[di];
}

void solve() {
  mR = mQ = Matrix(kD, Row(kD));
  for (int i = 0; i < kD; ++i)
    mR[i][i] = ll(1);
  for (int i = 0; i < kD - 1; ++i)
    mQ[0][i] = ll(A[i + 1]);
  for (int i = 1; i < kD; ++i)
    mQ[0][i] -= ll(A[i]);
  for (int i = 1; i < kD; ++i)
    mQ[i][i - 1] = ll(1);
  ++mQ[0][0];

  for (int i = 30; i >= 0; --i) {
    mR = mtrx_mul(mR, mR);
    if (((1 << i) & X) != 0)
      mR = mtrx_mul(mQ, mR);
  }

  cout << mR[0][0] << "\n";
}

Matrix mtrx_mul(const Matrix &a, const Matrix &b) {
  Matrix ret(kD, Row(kD));
  for (int i = 0; i < kD; ++i)
    for (int j = 0; j < kD; ++j)
      for (int k = 0; k < kD; ++k)
        ret[i][j] += a[i][k] * b[k][j], ret[i][j] = ((ret[i][j] % kMod) + kMod) % kMod;
  return ret;
}
