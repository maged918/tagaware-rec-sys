//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <string>
#include <vector>
#include <cmath>
#include <ctime>
#include <queue>
#include <stack>
#include <map>

using namespace std;


#define rofeach(i,x) for(type(x)i=x.rbegin();i!=x.rend();i++)
#define foreach(i,x) for(type(x)i=x.begin();i!=x.end();i++)
#define dbgs(x) cerr << (#x) << " --> " << (x) << ' '
#define dbg(x) cerr << (#x) << " --> " << (x) << endl
#define FOR(ii,aa,bb) for(int ii=aa;ii<=bb;ii++)
#define ROF(ii,aa,bb) for(int ii=aa;ii>=bb;ii--)
#define type(x) __typeof(x.begin())
#define pii pair< int,int >
#define mod 1000000007LL
#define inf 1000000000
#define ll long long
#define pb push_back
#define mp make_pair
#define nd second
#define st first
#define endl '\n'

const int N = 3e5+5;
const int MAX = 1e9+5;

ll start[N], end[N], T, depth[N], x, y, z, t, n, m, F[N], F2[N];

vector< ll > v[N];

int query(int x){
	ll sum = 0;
	for(;x && x < N;x += x & -x) sum = (sum + F[x]) % mod;
	return sum;
}

int query2(int x){
	ll sum = 0;
	for(;x && x < N;x += x & -x) sum = (sum + F2[x]) % mod;
	return sum;
}

int update(int x,int y,int t){
	ll sum = 0; x--;
	for(; y>0 ; y -= y & -y) F[y] = ((ll)F[y] + t + 5*mod) % mod;
	for(; x>0 ; x -= x & -x) F[x] = ((ll)F[x] - t + 5*mod) % mod;
}

int update2(int x,int y,int t){
	ll sum = 0; x--;
	for(; x>0 ; x -= x & -x) F2[x] = ((ll)F2[x] - t + 5*mod) % mod;
	for(; y>0 ; y -= y & -y) F2[y] = ((ll)F2[y] + t + 5*mod) % mod;
}

int dfs(int node,int last){
	
	start[node] = ++T;

	foreach(it,v[node]){
		
		if(*it == last) continue;
	
		depth[*it] = depth[node] + 1; 

		dfs(*it,node);
		
	}

	end[node] = T;
	
}

int main(){

	scanf("%lld",&n);

	FOR(i,2,n){
		
		scanf("%lld",&x);

		v[x].pb(i);
	
	}

	dfs(1,0);

	scanf("%lld",&m);

	FOR(i,1,m){
		
		scanf("%lld",&t);

		if(t == 1){
			
			scanf("%lld %lld %lld",&x,&y,&z);
	
			update(start[x],end[x],-z);		
			
			update2(start[x],end[x],(y + z * depth[x]) % mod);		
			
		}

		else {
		
			scanf("%lld",&x);

			printf("%lld\n",(query(start[x]) * depth[x] % mod + 5LL *mod + query2(start[x])) % mod);
			
		}
		
	}

    return 0;
}
