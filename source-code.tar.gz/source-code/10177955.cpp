//Language: GNU C++


#include <iostream>
#include <vector>
#include <queue>

using namespace std;

const int MAXN = 1000 * 100 + 10;
vector<int> v[MAXN];
bool mark[MAXN];
queue<int> q, ans;
int change[MAXN], state[MAXN], father[MAXN];


void bfs(int ver)
{
    int tmp;
    q.push(ver);
    while(q.size() > 0)
    {
        tmp = q.front();
        q.pop();
        mark[tmp] = true;

        if((tmp == 1 || father[tmp] == 1) && state[tmp] == 1)
        {
            ans.push(tmp);
            change[tmp] = 1;
        }
        else if((state[tmp] == 1 && change[father[father[tmp]]] % 2 == 0) || (state[tmp] == 0 && change[father[father[tmp]]] % 2 == 1))
             {
                ans.push(tmp);
                change[tmp] = change[father[father[tmp]]] + 1;
             }
             else
                change[tmp] = change[father[father[tmp]]];

        for(int i = 0 ; i < v[tmp].size() ; i++)
            if(mark[v[tmp][i]] == false)
            {
                q.push(v[tmp][i]);
                father[v[tmp][i]] = tmp;
            }
    }
}

int main()
{
    int n;
    cin >> n;
    int v1, v2, tmp;
    for(int i = 0 ; i < n - 1 ; i++)
    {
        cin >> v1 >> v2;
        v[v1].push_back(v2);
        v[v2].push_back(v1);
    }
    for(int i = 1 ; i < n + 1 ; i++)
        cin >> state[i];
    for(int i = 1 ; i < n + 1 ; i++)
    {
        cin >> tmp;
        if(state[i] != tmp)
            state[i] = 1;
        else
            state[i] = 0;
    }
    bfs(1);
    cout << ans.size() << endl;
    while(ans.size() > 0)
    {
        cout << ans.front() << endl;
        ans.pop();
    }
}
