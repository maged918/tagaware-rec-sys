//Language: GNU C++


#include <iostream>
using namespace std;
int t = 0 , n , a[100100] , ans = 0;

int main(){
	cin >> n;
	for (int i = 0 ; i < n ; ++ i){
		cin >> a[i];
	}
	for (int i = 0 ; i < n ; ++ i){
		if (a[i] > 0) t += a[i];
		else if (t) t --;
		else {
			ans ++;
		}
	}
	cout << ans;
}
