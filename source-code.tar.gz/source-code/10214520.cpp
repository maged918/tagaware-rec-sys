//Language: GNU C++


#include<iostream>

using namespace std;

int contrast[55] = { 0, 1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 66, 78, 91, 105, 120, 136, 153, 171, 190, 210, 231, 253,
					276, 300, 325, 351, 378, 406, 435, 465, 496, 528, 561, 595, 630, 666, 703, 741, 780, 820, 861, 903,
					946, 990, 1035, 1081, 1128, 1176, 1225, 1275, };

int main()
{
	int n, m;

	while (cin >> n >> m)
	{
		m = m%contrast[n];

		for (int i = 1;;i ++)
		{

			if (m<i)
			{
				break;
			}
			else
			{
				m -= i;
			}
		}

		cout << m << endl;

	}

	return 0;
}