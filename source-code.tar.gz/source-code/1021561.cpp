//Language: GNU C++


//In the name of Allah
//Smagulov Aybek Astana
#include <iostream>
#include <math.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>

using namespace std;

long long x, y, a;
long long num = 1, d[10000000];

int main() {

#ifndef ONLINE_JUDGE
	freopen("input.txt","rt",stdin);
	freopen("output.txt","wt",stdout);
#endif
	scanf ("%I64d%I64d%I64d", &a, &x, &y);
	d[1] = a;
	num = 1;
	if (d[1] > y && y > 0 && x * 1.00000000 > a / -2.00000000 && x * 1.00000000 < a / 2.00000000)
	{
		printf ("1");
		exit (0);
	}
	d[2] = a + a;
	num = 2;
	if (d[2] > y &&  d[1] < y && x * 1.00000000 > a / -2.00000000 && x * 1.00000000 < a / 2.00000000)
	{
		printf ("2");
		exit (0);
	}
	long long from = 3;
	if (x < a * -100 || x > a * 100)
	{
		printf ("-1");
		exit (0);
	}
	while (1)
	{
		num++;
		d[num]=d[num - 1] + a;
		if (d[num] > y && d[num - 1] > y) 
		{
			printf ("-1");
			exit (0);
		}
		if (num & 1)
		{
			if (d[num] > y && d[num - 1] < y && x > -a && x < 0)
			{
				printf ("%I64d", from);
				exit (0);
			}
			else if (d[num] > y && d[num - 1] < y && x > 0 && x < a)
			{
				printf ("%I64d", from + 1);
				exit (0);
			}
			from += 2;
		}
		else
		{
			if (d[num] > y && d[num-1] < y && x * 1.00000000 > a / -2.00000000 && x * 1.00000000 < a / 2.00000000)
			{
				printf ("%I64d", from);
				exit (0);
			}
			from += 1;
		}
	}
	printf ("-1");
	return 0;
}

