//Language: GNU C++0x


#include <iostream>
#include <vector>
#include <map>
#include <set>

using namespace std;

typedef pair<int, int> pii;
typedef map<pair<int, int>, int> Coordinate;

int exists(Coordinate& c, pii key) {
    Coordinate::iterator it = c.find(key);
    if (it != c.end()) {
        return it->second;
    }
    return 0;
}

bool isRemovable(Coordinate& c, int x, int y) {
    if (exists(c, make_pair(x - 1, y + 1))) {
        if (!exists(c, make_pair(x - 2, y))
                && !exists(c, make_pair(x - 1, y))) {
            return false;
        }
    }
    if (exists(c, make_pair(x, y + 1))) {
        if (!exists(c, make_pair(x - 1, y))
                && !exists(c, make_pair(x + 1, y))) {
            return false;
        }
    }
    if (exists(c, make_pair(x + 1, y + 1))) {
        if (!exists(c, make_pair(x + 1, y))
                && !exists(c, make_pair(x + 2, y))) {
            return false;
        }
    }
    return true;
}

long long mult(int m, int d, int val) {
    long long ret = 1LL;
    for (int i = 0; i < d; ++i) {
        ret *= m;
        ret %= 1000000009;
    }
    ret = (ret * val) % 1000000009;
    return ret;
}

int main() {
    int m;
    vector<int> ansV;
    long long ans = 0, base = 1;
    Coordinate c;
    cin >> m;
    set<int> removables;
    vector<pair<int, int> > v;
    int turn = 1;
    for (int i = 1, x, y; i <= m; ++i) {
        cin >> x >> y;
        c[make_pair(x, y)] = i;
        v.push_back(make_pair(x, y));
    }
    for (Coordinate::iterator it = c.begin(); it != c.end(); ++it) {
        if (isRemovable(c, it->first.first, it->first.second)) {
            //cout << it->first.first << " " << it->first.second << ":" << it->second << endl;
            removables.insert(it->second);
            //cout << it->second << endl;
        }
    }
    while (!removables.empty()) {
        int val;
        Coordinate::iterator it;
        pair<int, int> P;
        if (turn) {
            val = *(removables.rbegin());
        } else {
            val = *(removables.begin());
        }
        //cout << (turn ? "Max=" : "Min=") << val << endl;
        removables.erase(removables.find(val));
        it = c.find(v[val - 1]);
        P = make_pair(it->first.first, it->first.second);
        c.erase(it);
        //cout << c.size() << endl;
        for (int i = -2; i <= 2; ++i) {
            if (exists(c, make_pair(P.first - i, P.second))
                    && !isRemovable(c, P.first - i, P.second)) {
                set<int>::iterator sit = removables.find(
                        c[make_pair(P.first - i, P.second)]);
                if (sit != removables.end()) {
                    removables.erase(sit);
                }
            }
        }
        for (int i = -1; i <= 1; ++i) {
            int value;
            if ((value = exists(c, make_pair(P.first - i, P.second - 1)))
                    && isRemovable(c, P.first - i, P.second - 1)) {
                removables.insert(value);
            }
        }
        //cout << val - 1 << endl;
        ansV.push_back(val - 1);
        turn = (turn + 1) % 2;
    }
    for (int i = m - 1; i >= 0; --i) {
        ans += ansV[i] * base;
        ans %= 1000000009;
        base *= m;
        base %= 1000000009;
    }
    cout << ans << endl;
    return 0;
}
