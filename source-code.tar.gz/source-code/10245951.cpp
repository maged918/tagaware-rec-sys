//Language: MS C++


#include <iostream>
#include <algorithm>
#include <math.h>
#include <string>
#include <vector>
#include <numeric>
#include <stack>
#include <iomanip>
using namespace std;
int main()
{
	long n, l;
	cin >> n >> l;
	long double maxl;
	long double* a = new long double[n];
	for (long i = 0; i < n;i++)
	{
		cin >> a[i];
	}
	sort(a, a + n);
	maxl = max(a[0], l - a[n-1]);
	for (long i = 0; i < n-1; i++)
	{
		if ((a[i + 1] - a[i])/2 > maxl)
			maxl = ((a[i + 1] - a[i])/2);
	}
	cout << setprecision(9)<<maxl;
}