//Language: MS C++


#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    long a, x, y;
    cin >> a >> x >> y;
    if (y>0 && y<a && fabs(x*1.0)<double(a)/2.0)
        cout << "1";
    else if (y>0 && y<a && fabs(x*1.0)>=double(a)/2.0) cout << "-1";
    else
        if ((y/a)%2<1 && y%a>0 && abs(x)<a)
        {
            if (x>0) cout << ((y/a)/2)*3+1;
            else
                if (x<0) cout << ((y/a)/2)*3;
                else cout << "-1";
        }
        else
            if ((y/a)%2>0 && y%a>0 && fabs(x*1.0)<double(a)/2.0)
                cout << ((y/a+1)/2)*3-1;
            else cout << "-1";
    return 0;
}