//Language: GNU C++


#include <bits/stdc++.h>

#define MAX 1005

using namespace std;

long long dp1[MAX][MAX] = {0};
long long dp2[MAX][MAX] = {0};
long long dp3[MAX][MAX] = {0};
long long dp4[MAX][MAX] = {0};
long long a[MAX][MAX] = {0};

int main()
{
//    ios::sync_with_stdio(false);
    long long n,m;

    cin>>n>>m;

    for(long long i=1; i<=n; i++)
    {
        for(long long j=1; j<=m; j++)
        {
            cin>>a[i][j];
        }
    }

    for(long long i=1; i<=n; i++)
    {
        for(long long j=1; j<=m; j++)
        {
            dp1[i][j] = a[i][j];
            dp1[i][j] += max(dp1[i-1][j], dp1[i][j-1]);
        }
    }

    for(long long i=1; i<=n; i++)
    {
        for(long long j=m; j>=1; j--)
        {
            dp2[i][j] = a[i][j];
            dp2[i][j] += max(dp2[i-1][j], dp2[i][j+1]);
        }
    }

    for(long long i=n; i>=1; i--)
    {
        for(long long j=m; j>=1; j--)
        {
            dp3[i][j] = a[i][j];
            dp3[i][j] += max(dp3[i+1][j], dp3[i][j+1]);
        }
    }

    for(long long i=n; i>=1; i--)
    {
        for(long long j=1; j<=m; j++)
        {
            dp4[i][j] = a[i][j];
            dp4[i][j] += max(dp4[i][j-1], dp4[i+1][j]);
        }
    }

    long long ans = 0;
    for(long long i=2; i<n; i++)
    {
        for(long long j=2; j<m; j++)
        {
            long long tmp = dp1[i-1][j] + dp3[i+1][j] + dp2[i][j+1] + dp4[i][j-1];
            ans = max(ans, tmp);

            tmp = dp1[i][j-1] + dp3[i][j+1] + dp2[i-1][j] + dp4[i+1][j];
            ans = max(ans, tmp);
        }
    }

    cout<<ans<<endl;
    return 0;
}
