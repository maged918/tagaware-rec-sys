//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <map>
#include <stack>
#include <math.h>
#include <set>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
using namespace std;
const int maxn=10005;
#define mem(a,b) memset(a,b,sizeof(a))
#define LL long long
#define Max(a,b) a>b?a:b;
#define Min(a,b) a<b?a:b;
char mapp[maxn][1005];
int a[100000],b[100000],c[100000];
int main()
{
    int n,m;
    scanf("%d %d",&n,&m);
    int sum=0;
    while(n&&m)
    {
        int n1=n-2;
        int m1=m-2;
        if(n>=m&&n-2>=0)
        {
            n-=2;
            m--;
            sum++;
        }
        else if(n<m&&m-2>=0)
        {
            m-=2;
            n--;
            sum++;
        }
        else
        {
            n--;
            m--;
        }
    }
    printf("%d\n",sum);
    return 0;
}

	 	  			  	  	  	       		  			