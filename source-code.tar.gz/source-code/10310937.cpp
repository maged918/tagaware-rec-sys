//Language: GNU C++0x


#include<stdio.h>
#include<queue>
#include<vector>

main()
{
    std::vector<int> distance(30000, -1);
    std::queue<int> myqueue;

    int numstart, numfinish;
    scanf("%d", &numstart);;
    scanf("%d", &numfinish);


    distance[numstart] = 0;
    myqueue.push(numstart);
    int temp;
    while(1)
    {
        temp = myqueue.front();
        myqueue.pop();
        if(temp == numfinish) break;
        //do the -1
        if(temp - 1 >= 0 && distance[temp - 1] == -1)
        {
            distance[temp - 1] = distance[temp] + 1;
            myqueue.push(temp - 1);
        }
        //do the *2
        if(temp * 2 < 30000 && distance[temp * 2] == -1)
        {
            distance[temp * 2] = distance[temp] + 1;
            myqueue.push(temp * 2);
        }
    }

    printf("%d", distance[numfinish]);

}
