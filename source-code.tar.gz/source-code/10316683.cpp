//Language: MS C++


#include<iostream>
using namespace std;
int main(){
	__int64 a,b;
	while(scanf("%I64d%I64d",&a,&b)!=EOF){
		__int64 count=0;
		while(1){
			if(a%b==0){
				count+=a/b;
				break;
			}
			else{
				count+=a/b;
				__int64 t=a%b;
				a=b;
				b=t;
			}
		}
		printf("%I64d\n",count);
	}
	return 0;
}