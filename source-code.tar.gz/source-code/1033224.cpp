//Language: GNU C++


//
//  main.cpp
//  1
//
//  Created by Liza Kondakova on 12.01.12.
//  Copyright (c) 2012 likogra@gmail.com. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main ()
{
    int c1,c2,d1,d2,r1,r2;
    cin>>r1>>r2>>c1>>c2>>d1>>d2;
    int a,b,c,d;
    if((r1+r2!=c1+c2) || (r1+r2!=d1+d2) ||((r1+d1+c2)%2!=0)){
        cout<<"-1"<<endl;
        return 0;
    }
    a=(r1+d1-c2)/2;
    b=r1-a;
    c=c1-a;
    d=d1-a;
    vector<int> v;
    v.push_back(a);
    v.push_back(b);
    v.push_back(c);
    v.push_back(d);
    sort(v.begin(),v.end());
    if((v[0]<=0) || (v[3]>9)||(v[0]==v[1])||(v[2]==v[1])||(v[3]==v[2])){
        cout<<"-1"<<endl;
        return 0;
    }
    //cout<<v[0]<<endl;
    cout<<a<<" "<<b<<" "<<endl<<c<<" "<<d<<endl;
    //std::cout << "Hello, World!\n";
    return 0;
}

