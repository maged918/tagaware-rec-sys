//Language: GNU C++



#include <bits/stdc++.h>
using namespace std ;
#define pb push_back
#define mp make_pair
#define ft first
#define sd second
#define MAXN 500000
int n , BIT[MAXN];
vector<pair<int,int> > A , B;

bool cmp(const pair<int,int> &a,const pair<int,int> &b){
    if(a.sd < b.sd){
        return 1 ;
    }
    if(a.sd == b.sd){
        return a.ft <= b.ft ;
    }
    return 0 ;
}

void update(int idx,int val){

    while(idx < MAXN){
        BIT[idx] = max(BIT[idx],val) ;
        idx += ( idx & -idx ) ;
    }
}

int query(int idx){
    int  s = 0 ;
    while(idx){
        s = max(s,BIT[idx]) ;
        idx -= (idx & -idx) ;
    }
    return s ;
}

int main(){
    cin >> n ;
    A.resize(n+1) ;
    for(int i=1;i<=n;i++){
        cin >> A[i].first >> A[i].second ;
    }
    sort(A.begin()+1,A.end()) ;
    for(int i=1;i<=n;i++){
        B.pb({A[i].ft-A[i].sd,i}) ;
        B.pb({A[i].ft+A[i].sd,i}) ;
    }
    sort(B.begin(),B.end()) ;
    int idx = 0 , i = 0 ;
    while(i < B.size()){
        int x = B[i].ft ;
        ++ idx ;
        while(i < B.size() && x == B[i].ft){
            B[i].ft = idx ;
            i ++ ;
        }
    }
    sort(B.begin(),B.end(),cmp) ;
    int ans = 0 ;
    for(int i=1;i<=n;i++){
        int x,y,v;
        y = B[2*i-1].ft ;
        x = B[2*i-2].ft ;
        v = query(x) ;
        ans = max(ans , v+1) ;
        update(y,v+1) ;
    }
    cout << ans << endl ;
    return 0;
}
