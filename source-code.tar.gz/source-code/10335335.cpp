//Language: MS C++


#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <functional>
#include <numeric>
#include <queue>
#include <stack>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <complex>
#include <memory.h>
#include <time.h>

using namespace std;

typedef long long LL;

vector<string> best;
string s[6];

int main()
{
	for(int i = 0; i < 6; ++i)
		cin >> s[i];

	vector<int> p(6);
	for(int i = 0; i < 6; ++i)
		p[i] = i;

	do
	{
		int i1 = p[0], j1 = p[1], k1 = p[2];
		int i2 = p[3], j2 = p[4], k2 = p[5];
		if (s[i1].size() + s[j1].size() - 1 != s[k1].size())
			continue;
		if (s[i2].size() + s[j2].size() - 1 != s[k2].size())
			continue;
		if (s[i1][0] != s[i2][0])
			continue;
		if (s[j1].back() != s[j2].back())
			continue;
		if (s[i1].back() != s[k2][0] || s[j1][0] != s[k2].back())
			continue;
		if (s[i2].back() != s[k1][0] || s[j2][0] != s[k1].back())
			continue;
		if (s[k1][s[i1].size() - 1] != s[k2][s[i2].size() - 1])
			continue;

		int n = s[k2].size(), m = s[k1].size();
		vector<string> S(s[k2].size(), string(s[k1].size(), '.'));

		for(int i = 0; i < s[i1].size(); ++i)
			S[0][i] = s[i1][i];
		for(int i = 0; i < s[i2].size(); ++i)
			S[i][0] = s[i2][i];
		for(int i = 0; i < s[j1].size(); ++i)
			S[n - 1][m - s[j1].size() + i] = s[j1][i];
		for(int i = 0; i < s[j2].size(); ++i)
			S[n - s[j2].size() + i][m - 1] = s[j2][i];
		for(int i = 0; i < n; ++i)
			S[i][s[i1].size() - 1] = s[k2][i];
		for(int i = 0; i < m; ++i)
			S[s[i2].size() - 1][i] = s[k1][i];

		if (best.empty() || best > S)
			best = S;

	}
	while (next_permutation(p.begin(), p.end()));

	if (best.empty())
	{
		cout << "Impossible" << endl;
		return 0;
	}
	for(int i = 0; i < best.size(); ++i)
		cout << best[i] << endl;
	return 0;
}