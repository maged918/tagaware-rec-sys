//Language: GNU C++0x


#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
template <typename T>
T modpow(T base, T exp, T modulus) {
  base %= modulus;
  T result = 1;
  while (exp > 0) {
    if (exp & 1) result = (result * base) % modulus;
    base = (base * base) % modulus;
    exp >>= 1;
  }
  return result;
}

int main()
{
    string str;
    long long int n;
    cin >> n >> str;
    vector<int> counts(26,0);
    for(char x:str) counts[x-'A'] += 1;
    int m = *max_element(counts.begin(),counts.end());
    long long int c = 0;
    for(int x: counts) if (x == m) c++;
    cout << modpow(c,n,1000000007LL) << '\n';
}


