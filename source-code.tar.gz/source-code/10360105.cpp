//Language: MS C++


#include<iostream>
#include<algorithm>
#include<vector>
#include<string>
#include<stack>
#include<queue>
#include<map>
#include<set>
#include<cstdio>

using namespace std;

#define ll long long
#define ull unsigned long long
#define mp make_pair
#define pb push_back
#define maxn 300005
#define mod 1E9 + 7;     

int main(){
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    string s;
    cin >> s;

    for (int i = 0; i < s.length()+1; i++){
        for (char ch = 'a'; ch <= 'z'+1; ch++){
            string d = s.substr(0, i) + string(1,ch) + s.substr(i);
            string p = d;
            reverse(p.begin(), p.end());
            if(p == d){
                cout<<d;
                return 0;
            }
        }
    }

    cout << "NA";

    //system("pause");
    return 0;
}