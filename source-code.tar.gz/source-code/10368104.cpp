//Language: MS C++


#define _USE_MATH_DEFINES 
#define _CRT_SECURE_NO_DEPRECATE 
#include <iostream> 
#include <cstdio> 
#include <cstdlib> 
#include <vector> 
#include <sstream> 
#include <string> 
#include <map> 
#include <set> 
#include <algorithm> 
#include <cmath> 
#include <cstring> 
#include <queue>
using namespace std; 
#pragma comment(linker, "/STACK:256000000") 
#define mp make_pair 
#define pb push_back 
#define all(C) (C).begin(), (C).end() 
#define sz(C) (int)(C).size() 
#define PRIME 1103 
#define PRIME1 31415 
typedef long long int64; 
typedef unsigned long long uint64; 
typedef pair<int, int> pii; 
typedef vector<int> vi; 
typedef vector<vector<int> > vvi; 
//------------------------------------------------------------ 
const int N = 200000;
int64 a, b, ans;
int n, m;
int cy[4 * N], sep;
struct edges
{
    int u, v, ind, typ;
    edges()
    {
        typ = -1;
    }
    edges (int a, int b, int c)
    {
        u = a, v = b, ind = c, typ = -1;
    }
    bool operator < (const edges a)
    {
        return u < a.u;
    }
};
pii ver[N];
int st[N];
edges ed[4 * N];
int was[4 * N];
void dfs(int u)
{
    if (ver[u].first > ver[u].second)
        return;
    for(; ver[u].first <= ver[u].second; )
    {
        int i = ver[u].first;
        ver[u].first++;
        if (was[ed[i].ind])
            continue;
        //cerr << ed[i].u << ' ' << ed[i].v << ' ' << ed[i].typ << endl;
        was[ed[i].ind] = 1;
        dfs(ed[i].v);
    }
    cy[sep++] = u;
}
int main()
{
#ifdef WIN32
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    scanf("%d %d", &n, &m);
    for(int i = 0; i < m; ++i)
    {
        int a, b;
        scanf("%d %d", &a, &b);
        a--; b--;
        ed[i] = edges(a, b, i);
        st[a]++;
        st[b]++;
        ed[i + m] = edges(b, a, i);
    }
    for(int i = 0; i < n; ++i)
    {
        if (st[i] & 1)
        {
            int k = i;
            for(++i; i < n; ++i)
            {
                if (st[i] & 1)
                {
                    ed[2 * m] = edges(k, i, m);
                    ed[2 * m + 1] = edges(i, k, m);
                    m++;
                    break;
                }
            }
        }
    }
    if (m & 1)
    {
        ed[2 * m] = edges(0, 0, m);
        ed[2 * m + 1] = edges(0, 0, m);
        m++;
    }
    sort(ed, ed + 2 * m);
    ver[ed[0].u].first = 0;
    for(int i = 1; i < 2 * m; ++i)
    {
        if (ed[i].u == ed[i - 1].u)
            continue;
        ver[ed[i - 1].u].second = i - 1;
        ver[ed[i].u].first = i;
        
    }
    ver[ed[2 * m - 1].u].second = 2 * m - 1;
    for(int i = 0; i < n; ++i)
    {
        dfs(i);
    }
    printf("%d\n", m);
    int q = 0;
    //for(int i = 0; i < sep; ++i)
        //cerr << cy[i] << ' ';
    for(int i = 1; i < sep; ++i)
    {
        if (q)
            printf("%d %d\n", cy[i - 1] + 1, cy[i] + 1);
        else
            printf("%d %d\n", cy[i] + 1, cy[i - 1] + 1);
        q ^= 1;
    }
} 