//Language: GNU C++


#include<iostream>
#include<algorithm>
using namespace std;

int main() {
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	
	int n;
	cin >> n;
	bool sign = false;
	
	for (int i = 0; i < 4; i++) {
		int a[2], b[2];
		cin >> a[0] >> a[1] >> b[0] >> b[1];

		for (int j = 0; j < 2; j++)
			for (int k = 0; k < 2; k++) {
				if (a[j]+b[k] <= n) {
					cout << i+1 << " ";
					cout << a[j] << " " << n-a[j] << endl;
					sign = true;
					k = j = 2;
					i = 4;
				}
			}
			
	}
	
	if (!sign) cout << -1 << endl;

	return 0;
}

 	 				 		 	  				 		 	  	 	