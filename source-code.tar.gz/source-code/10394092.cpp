//Language: GNU C++


#include <iostream>
#include <string>
#include <cstring>
using namespace std;


long stoi(string s)
{
   // cout<<"START FUNCTION: "<<endl;
    int pointer=0;
    long j=0;
    bool isNegative=false;
    int i=0;
    if (s[0]=='-')
    {
        i++;
        isNegative=true;
    }
    for (; i<s.length(); i++)
    {
      //  cout<<s[i]<<endl;
        j = j * 10 + (s[i] - '0');
   //     cout<<"N: "<<j<<endl;
    }
   // cout<<"NUMBER IS : "<<j<<endl;
    if (isNegative)
        return (-1)*j;
    return j;
}


bool solve()
{


    int n,k;
    n=5;
    string t;
    getline(cin, t);
    int t1=0;
    while (t[t1]!=' ')
        t1++;
    string t2=t.substr(0,t1);
    n=stoi(t2);
    t2=t.substr(t1+1,t.length()-(t1+1));
    k=stoi(t2);

    //cout<<"N: "<<n<<" K: "<<k<<endl;
    string s;
    getline(cin, s);

    bool isNumber [n];
    int minNumber[n];
    int maxNumber[n];
    for (int i=0; i<n; i++)
    {
        isNumber[i]=true;
    }
    int number[n];
    int p=0;
    int no=0;

    for (int i=0; i<s.length(); i++)
    {
        if (s[i]==' ')
        {

            string temp;
            temp= s.substr(p,i-p);
           // cout<<"DIVE "<<temp<<endl;
            number[no]=stoi(temp);
            p=i+1;
            no++;
        }
         if (s[i]=='?')
        {
            number[no]=0;
            isNumber[no]=false;
            no++;
            p=i+2;
            i++;

        }
    }
    //for last number
    if ((int)(s.length()-p)>0)
    {

    string temp;
    temp= s.substr(p,s.length()-p);

    if (temp[0]=='?')
    {
        number[no]=0;
        isNumber[no]=false;
    }
    else
    {
       number[no]=stoi(temp);
    }
    no++;
    }

    //

    for (int i=0; i<n-k; i++)
    {
        if (isNumber[i+k])
            maxNumber[i]=number[i+k]-1;
        if (isNumber[i])
            minNumber[i+k]=number[i]+1;
    }
    bool isAnswerCorrect=true;
    for (int i=0; i<n; i++)
    {
        if (isNumber[i])
        {
            if (i<n-k)
            {
                if (isNumber[i+k])
               if (number[i]>maxNumber[i])
                   {isAnswerCorrect=false;}
            }
            if (i>=k)
            {
                if (isNumber[i-k])
                if (number[i]<minNumber[i])
                    {isAnswerCorrect=false;}
            }
        }
        else
        {
            //NOTHING
        }
    }
    if (!isAnswerCorrect)
    {
        return false;
    }

    for (int i=0; i<n; i++)
    {
        if (!isNumber[i])
        {
            //cout<<"HOLY SHIT"<<i<<endl;
            int p=i;
            int counter=0;
            bool hasMax=true;
            bool hasMin=true;
            int minV, maxV;
            if (i-k<0)
                hasMin=false;
            else
                minV=number[i-k]+1;

            while (!isNumber[p])
            {
                p+=k;
                counter++;
                if (p>=n)
                break;
            }
            if (p>=n)
                hasMax=false;
            else
                maxV=number[p]-1;
            //cout<<"MAX: "<<hasMax<<":"<<maxV<<" MIN: "<<hasMin<<" "<<minV<<" P: "<<p<<endl;
            if (hasMax||hasMin)
            {
                if (maxV-minV+1<counter&&hasMax&&hasMin)
                {
                    isAnswerCorrect=false;
                    return false;
                }
                if (minV>=0&&hasMin)
                {
                    for (int j=0; j<counter; j++)
                    {
                        number[i+j*k]=minV+j;
                        isNumber[i+j*k]=true;
                    }
                }
                else if (maxV<=0&&hasMax)
                {
                    for (int j=0; j<counter; j++)
                    {
                        number[i+j*k]=maxV+j-counter+1;
                        isNumber[i+j*k]=true;
                    }
                }
                else if ((minV<0||!hasMin)&&(maxV>0||!hasMax))
                {

                    int neg=0, pos=0;
                    int c=1;
                    while (c<counter)
                    {
                        if (neg>minV||!hasMin)
                        {
                            neg--;
                            c++;
                        }
                        if ((pos<maxV||!hasMax)&&c<counter)
                        {
                            pos++;
                            c++;
                        }
                    }
                    for (int j=0; j<counter; j++)
                    {
                        number[i+j*k]=neg+j;
                        isNumber[i+j*k]=true;
                    }
                }
            }
            else
            {
                    //cout<<"WE DON't have min and MAX"<<endl;
                    int neg=0, pos=0;
                    int c=1;
                    while (c<counter)
                    {
                        if (hasMin)
                        {
                           if (neg>minV)
                            {
                            neg--;
                            c++;
                            }
                        }
                        else
                        {
                            neg--;
                            c++;
                        }
                        if (hasMax)
                        {
                           if (pos<maxV&&c<counter)
                            {
                                pos++;
                                c++;
                            }
                        }
                        else
                        {
                            if (c<counter)
                            {
                                pos++;
                                c++;
                            }
                        }

                    }
                    for (int j=0; j<counter; j++)
                    {
                        number[i+j*k]=neg+j;
                        isNumber[i+j*k]=true;
                    }
            }
        }
    }
    for (int i=0; i<n; i++)
        cout<<number[i]<<" ";
    cout<<endl;
    return true;
}
int main()
{
    bool answer=solve();
    if (answer==true)
    {
        //Do nothing
    }
    else
    {
        cout<<"Incorrect sequence"<<endl;
    }

}
