//Language: GNU C++


#include<iostream>

using namespace std;

int main()
{
    int n;
    long long L,R;
    cin>>n;
    while(n--)
    {

        cin>>L>>R;

        for(int i=0;i<63;i++)
            if( (L | 1LL << i) <= R )
              L = L | 1LL << i;
            else break;

        cout<<L<<endl;
    }

    return 0;
}
