//Language: GNU C++


#include <iostream>
#include <algorithm>
using namespace std;

struct Node {
    long long a, b;
}s[100010];

bool cmp (Node x, Node y) {
    return x.b < y.b;
}

int main () {
    long long n, r, avg;
    long long sum = 0;

    cin >> n >> r >> avg ;

    for (int i=0; i<n; i++) {
        cin >> s[i].a >> s[i].b;
        sum += s[i].a;
    }

    sum = avg * n - sum;

    sort(s, s+n, cmp);

    long long ans = 0;

    for (int i=0; i<n; i++) {
        if (sum <= 0) break;
        long long k = min (r - s[i].a, sum);
        ans += k * s[i].b;
        sum -= k;
    }

    cout << ans <<endl;

    return 0;
}

