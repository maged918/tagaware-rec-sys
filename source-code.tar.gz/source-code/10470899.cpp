//Language: GNU C++


#include<bits/stdc++.h>
#define ll long long
using namespace std;
int fre[200006];
char ch[200006];
char an[200006];
int main()
{

    //freopen("i.txt","r",stdin);
    string st;
    cin>>st;
    int m,x;
    cin>>m;
    for(int i=0;i<m;i++)
    {
        cin>>x;
        fre[x-1]++;
    }
    int n=st.length();
    int ans=0;
    for(int i=0;i<n/2;i++)
    {
        if(fre[i]>0 && fre[i]%2)
        {
            ans++;
        }
        if(ans%2)
        {
            an[n-1-i]=st[i];
        }
        else
        {
            an[i]=st[i];
        }
    }
    for(int i=n/2;i<n;i++)
    {
        if(ans%2)
        {
            an[n-i-1]=st[i];
        }
        else
        {
            an[i]=st[i];
        }
        if(fre[n-i-1]>0 && fre[n-i-1]%2)
        ans--;
    }
    for(int i=0;i<n;i++)
    cout<<an[i];
    cout<<endl;
}
