//Language: GNU C++


#include <bits/stdc++.h>
#define _ ios_base::sync_with_stdio(false);cin.tie(0);
using namespace std;
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define mp make_pair
#define all(a) a.begin(),a.end()
#define bitcnt(x) __builtin_popcountll(x)
#define MOD 1000000007
#define MAXN 100005
typedef unsigned long long int uint64;
typedef long long int int64;

int n,k;
int64 s;
int a[30];
int64 fact[30];
int64 ans=0;
map<int64,int64>m[30];
void pre(){
    fact[0]=1;
    for(int64 i=1;i<=18;i++)
    fact[i]=i*fact[i-1];
}
void meet1(int idx,int sel,int64 sum){
    if(sel>k)
    return;
    if(sum>s)
    return;
    if(idx==(n/2)){
        m[sel][sum]++;
        return;
    }
    meet1(idx+1,sel,sum);
    meet1(idx+1,sel,sum+a[idx]);
    if(a[idx]<=18)
    meet1(idx+1,sel+1,sum+fact[a[idx]]);
}
void meet2(int idx,int sel,int64 sum){
    if(sel>k)
    return;
    if(sum>s)
    return;
    if(idx==n){
        for(int i=0;i<=k-sel;i++){
        if(m[i].find(s-sum)!=m[i].end())
        ans+=m[i][s-sum];}
        return;
    }
    meet2(idx+1,sel,sum);
    meet2(idx+1,sel,sum+a[idx]);
    if(a[idx]<=18)
    meet2(idx+1,sel+1,sum+fact[a[idx]]);
}
int main(){
    pre();
    cin>>n>>k>>s;
    for(int i=0;i<n;i++)
    cin>>a[i];
    meet1(0,0,0);
    meet2((n/2),0,0);
    cout<<ans;
    return 0;
}