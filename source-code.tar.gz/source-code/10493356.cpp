//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int maxn = 26;
const LL INF = (1LL<<60);
unordered_map<LL,int>hs[maxn];
LL fact[maxn];
int N,K;
LL S,ans;
int *A;
inline void gao1(int cnt,LL sum){
    hs[cnt][sum]++;
}
inline void gao2(int cnt,LL sum){
    cnt=K-cnt;
    sum=S-sum;
    for(int i=0;i<=cnt;++i){
        ans+=hs[i][sum];
    }
}
template<class T>
void dfs(int x,int cnt,LL sum,const T& func){
    //cout<<x<<" "<<cnt<<" "<<sum<<endl;
    if(sum>S||cnt>K){
        return;
    }
    if(sum==S){
        func(cnt,sum);
        return;
    }
    if(x<0){
        func(cnt,sum);
        return;
    }
    dfs(x-1,cnt,sum,func);
    dfs(x-1,cnt,sum+A[x],func);
    if(cnt<K&&sum<S){
        int k=min(A[x],18);
        sum=min(INF,sum+fact[k]);
        dfs(x-1,cnt+1,sum,func);
    }
}
int main(){
#ifndef ONLINE_JUDGE
    freopen("/home/mark/in.txt","r",stdin);
#endif
    cin>>N>>K>>S;
    fact[0]=1;
    for(int i=1;i<=20;++i){
        fact[i]=fact[i-1]*i;
//        cout<<fact[i]<<endl;
    }
    static int a[maxn];
    static int b[maxn];
    int n,m,k;
    n=m=0;
    for(int i=0;i<N;++i){
        cin>>k;
        if(i&1){
            a[n++]=k;
        }else{
            b[m++]=k;
        }
    }
    A=a;
    dfs(n-1,0,0,gao1);
    A=b;
    dfs(m-1,0,0,gao2);
    cout<<ans<<endl;
    return 0;
}
