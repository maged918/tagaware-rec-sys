//Language: GNU C++


/* GCC */
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <cmath>
#include <queue>
#include <sstream>

#define X first
#define Y second

using namespace std;

int n, a[210], i, j, k1, k2, cur, h, mi;
vector < vector <int> > c, f, otv;
vector <int> from, q;
const int inf = 1000000007;

void gen(int n)
{
    FILE *fo = fopen("input.txt", "w");
    fprintf(fo, "200\n");
    for (int i = 0; i < n; i++)
        fprintf(fo, "%d ", i + 100);
    fprintf(fo, "\n");
    fclose(fo);
}

bool per(int a)
{
    int i;

    for(int i = 2; i * i <= a; i++)
        if(a % i == 0)
            return false;

    return true;
}

int main()
{
    // gen(200);
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
        scanf("%d", &a[i]);

    c.resize(n + 2, vector <int> (n + 2));

    for(int i = 1; i <= n - 1; i++)
        for(int j = i + 1; j <= n; j++)
            if(per(a[i] + a[j]))
            {
                // c[i][j] = 1;
                // c[j][i] = 1;
                if (a[i] & 1)
                    c[i][j] = 1;
                else
                    c[j][i] = 1;
            }

    k1 = 0;
    for(int i = 1; i <= n; i++)
        if(a[i] % 2 == 1)
        {
            c[0][i] = 2;
            // c[i][0] = 2;
            k1++;
        }

    k2 = 0;
    for(int i = 1; i <= n; i++)
        if(a[i] % 2 == 0)
        {
            // c[n + 1][i] = 2;
            c[i][n + 1] = 2;
            k2++;
        }

    if(k2 != k1)
    {
        printf("Impossible\n");
        return 0;
    }

    f.resize(n + 2, vector <int> (n + 2));
    while(true)
    {
        from.clear();
        from.resize(n + 2, -1);
        from[0] = 0;
        h = 0;
        q.clear();
        q.push_back(0);

        while(h < q.size())
        {
            cur = q[h];
            for(int i = 0; i <= n + 1; i++)
                if(c[cur][i] - f[cur][i] > 0 && from[i] == -1)
                {
                    q.push_back(i);
                    from[i] = cur;
                    if(i == n + 1)
                        break;
                }

            if(q[q.size() - 1] == n + 1)
                break;

            h++;
        }

        if(from[n + 1] == -1)
            break;

        mi = inf;
        cur = n + 1;
        while(cur != 0)
        {
            h = from[cur];

            if(mi > c[h][cur] - f[h][cur])
                mi = c[h][cur] - f[h][cur];

            cur = h;
        }

        cur = n + 1;
        while(cur != 0)
        {
            h = from[cur];
            f[h][cur] += mi;
            f[cur][h] -= mi;
            cur = h;
        }
    }

    // if (n == 200)
    // {
    //     printf("Numbers 101-200: \n");
    //     for (int i = 101; i <= 200; i++)
    //         printf("%d ", a[i]);
    //     return 0;
    // }

    
    // if (n == 200)
    // {
    //     from.clear();
    //     from.resize(n + 1);
    //     for(int i = 1; i <= n; i++)
    //         for(int j = 1; j <= n; j++)
    //             if(f[i][j] == 1)
    //             {
    //                 from[i]++;
    //                 from[j]--;
    //             }
    //     printf("Foo: how much contacts:\n");
    //     for(int i = 1; i <= n; i++)
    //         printf("%d ", from[i]);
    //     printf("\n");
    //     return 0;
    // }
    

    for(int i = 1; i <= n; i++)
    {
        if((f[0][i] != 2 && c[0][i] == 2) || (f[i][n + 1] != 2 && c[i][n + 1] == 2))
        {
            printf("Impossible\n");
            return 0;
        }
    }

    h = 0;

    from.clear();
    from.resize(n + 2, 0);

    for(int i = 1; i <= n; i++)
    {
        if(from[i] == 1)
            continue;

        otv.push_back(vector <int> ());
        otv[h].push_back(i);

        while(true)
        {
            cur = otv[h][otv[h].size() - 1];
            from[cur] = 1;
            for(int j = 1; j <= n; j++)
                if(j != cur && abs(f[cur][j]) == 1 && from[j] == 0)
                {
                    otv[h].push_back(j);
                    break;
                }

            // if(per(a[otv[h][otv[h].size() - 1]] + a[otv[h][otv[h].size() - 2]]) == false)
            // {
            //     printf("Foo: not prime inside the table\n");
            //     return 0;
            // }

            if(otv[h][otv[h].size() - 1] == cur)
                break  ;
        }

        // if(per(a[otv[h][otv[h].size() - 1]] + a[otv[h][0]]) == false)
        // {
        //     printf("Foo: bad end of the table: %d %d\n", h, int(otv[h].size()));
        //     for(int i = 0; i < otv[h].size(); i++)
        //         printf("%d ", a[otv[h][i]]);
        //     printf("\n");
        //     return 0;
        // }

        // for(int i = 0; i < otv[h].size(); i++)
        //     if(from[otv[h][i]] != 1)
        //     {
        //         printf("Foo: person not checked as sitting: %d\n", i);
        //         return 0;
        //     }

        h++;
    }

    printf("%d\n", h);
    for(int i = 0; i < h; i++)
    {
        printf("%d", int(otv[i].size()));
        for(int j = 0; j < otv[i].size(); j++)
            printf(" %d", otv[i][j]);
        printf("\n");
    }

    return 0;
}












