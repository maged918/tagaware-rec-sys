//Language: GNU C++


#include <bits/stdc++.h>
#define FOR(i, a, b) for(int i = (a), _b = (b); i <= _b; i++)
using namespace std;
const long long MOD = 1e9+7;

int n, k;
char a[100010];
long long sum, c, c2, ans;

long long pw(long long a, int b)
{
    if (b == 0) return 1;
    long long x = pw(a, b/2);
    x = x*x%MOD;
    return b&1 ? x*a%MOD : x;
}
long long div(int x)
{
    return pw(x, MOD-2);
}
long long mod(long long a, long long b, long long c)
{
    return (a * b % MOD) * c % MOD;
}
main()
{
    #ifndef ONLINE_JUDGE
        freopen("vao.inp","r",stdin);
    #endif

    scanf("%d %d %s", &n, &k, a);
    if (k)
    {
        c = c2 = 1;
        for (int i=0; i<k; i++)
            c = (c * (n-1-i) % MOD) * div(i+1) % MOD;
        for (int i=0; i<k-1; i++)
            c2 = (c2 * (n-2-i) % MOD) * div(i+1) % MOD;

        ans = sum = 0;
        for (int i=n-1; i>=0; i--)
        {
            ans = (ans + (sum + c * pw(10, n-1-i) % MOD) * (a[i]-'0')) % MOD;
            c = mod(c, div(i), i-k);
            sum = (sum + c2 * pw(10, n-1-i)) % MOD;
            c2 = mod(c2, div(i-1), i-k);
        }
    }
    else
        for (int i=0; i<n; i++)
            ans = (ans*10 + a[i]-'0') %MOD;
    printf("%lld", ans);
}
