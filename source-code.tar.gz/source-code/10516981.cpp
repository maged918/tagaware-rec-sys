//Language: GNU C++


#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#include<cstdio>
#include<set>
#include<map>
#include<climits>
#include<cstring>
#include<list>
#include<fstream>
#include<queue>
#include<sstream>


using namespace std;

typedef long long LL;


bool finder(vector <double> pres, double slope)
{
    for(int i=0; i<pres.size(); i++)
        if(pres[i]-slope==0)
        return true;

    return false;


}


int main()
{

     int n, X, Y;
     cin>>n>>X>>Y;

     vector <int> x(n);
     vector <int> y(n);

     for(int i=0; i<n; i++)
     {
         cin>>x[i]>>y[i];

     }

     int ret=0;

     vector <double> pres;

     for(int i=0; i<n; i++)
     {
         double m1= (double)( (double)y[i]-(double)Y );
         double m2=( (double)x[i]- (double)X );

         double slope;
         if(m2==0)
            slope=1e18;

         else
            slope=m1/m2;

        if(finder( pres, slope))
            continue;
         else
         {
            pres.push_back(slope);
            ret++;
         }
     }


   cout<<ret;

}


