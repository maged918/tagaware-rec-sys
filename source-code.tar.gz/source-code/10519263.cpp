//Language: GNU C++11


#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int main(int argc, char** argv) {
    int a[4];
    char niz[100005];
    scanf ("%i %i %i %i",a,a+1,a+2,a+3);
    gets (niz);
    gets (niz);
    
    long d = strlen (niz);
    long long sum = 0;
    for (long i = 0; i<d; i++) sum+=a[niz[i] - 49];
    
    printf ("%I64d",sum);
    
    return 0;
}