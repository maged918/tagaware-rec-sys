//Language: GNU C++11


#include<iostream>
#include<fstream>
#include<string>
#include<cmath>
#include<vector>
#include<algorithm>
#include<cstring>
#include<map>
#include<set>
#include<cstdio>

using namespace std;

char mp[2000][2000];
int n,m;

void dfs(int a,int b)
{
    int sum=0,i,j;
    for(i=0;i<2;i++)
    {
        for(j=0;j<2;j++)
        {
            if(mp[a+i][b+j]=='*')
                sum++;
        }
    }
    if(sum==1)
    {
        for(i=0;i<2;i++)
        {
            for(j=0;j<2;j++)
            {
                mp[a+i][b+j]='.';
            }
        }
        for(i=-1;i<2;i++)
        {
            for(j=-1;j<2;j++)
            {
                if(a+i>=0&&a+i<n-1&&b+j>=0&&b+j<m-1)
                    dfs(a+i,b+j);
            }
        }
    }
    
}


int main()
{
    int i,j,k,f;
    cin>>n>>m;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            scanf(" %c",&mp[i][j]);
        }
    }
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<m-1;j++)
        {
            dfs(i,j);
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            printf("%c",mp[i][j]);
        }
        printf("\n");
    }
} 



