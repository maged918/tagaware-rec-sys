//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

int n;

int main() {
    cin >> n;
    if (n % 2 == 0)
        cout << "white" << endl << "1 2" << endl;
    else
        cout << "black" << endl;
}
