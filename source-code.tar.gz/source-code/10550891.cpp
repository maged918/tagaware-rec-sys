//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
#define ull unsigned long long
#define ui unsigned int
#define ll long long
int main()
{
    ll a,b,c,d;
    cin>>a>>b>>c>>d;
    string s;
    cin>>s;
    ll sum=0,sum1=0;
    for(int i=0; i<s.size(); i++)
    {
        if(s[i]=='1')
        {
            sum1+=a;
        }
        else if(s[i]=='2')
        {
            sum1+=b;
        }
         else if(s[i]=='3')
        {
            sum1+=c;
        }
         else if(s[i]=='4')
        {
            sum1+=d;
        }
        //i++;
        //cout<<sum1;
    }
    cout<<sum1<<endl;
    return 0;
}
