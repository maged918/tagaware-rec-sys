//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
deque <int> death_connections [76*76+1];  
int o_luv_the_ded_man[76*76+1]; 
int o_hate_the_ded_men[76*76+1]; 
int ded_man_mapping_dead_to_dead (char a, char b)
{
    return 75*(a-'0')+(b-'0');
}  
vector <int> dead_searching_ded;
void dead_primary_dead_man_search (int love)
{
    while (death_connections[love].size())
    {
       int r=death_connections[love][0]; 
       death_connections[love].erase(death_connections[love].begin());
       dead_primary_dead_man_search(r); 
    }
    dead_searching_ded.push_back(love); 
}
int main()
{
    int a; cin >> a;
    for (int g=0; g<a; g++)
    {
        string b; cin >> b;
        death_connections[ded_man_mapping_dead_to_dead(b[0], b[1])].push_back(ded_man_mapping_dead_to_dead(b[1], b[2])); 
        o_luv_the_ded_man[ded_man_mapping_dead_to_dead(b[1], b[2])]++; 
        o_hate_the_ded_men[ded_man_mapping_dead_to_dead(b[0], b[1])]++; 
    }    
    int index=-1, dead_o_ded_test_o=0; 
    for (int g=0; g<=76*76; g++)
    {
     if (abs(o_luv_the_ded_man[g]-o_hate_the_ded_men[g])>=2){cout << "NO"; return 0;}
     if ((o_luv_the_ded_man[g]+o_hate_the_ded_men[g])&1)
     {
         dead_o_ded_test_o++; 
         if (o_hate_the_ded_men[g]>o_luv_the_ded_man[g]){index=g;}
     }
    }
    if (dead_o_ded_test_o==0)
    {
        for (int g=0; g<=76*76; g++)
        {
            if ((o_luv_the_ded_man[g]+o_hate_the_ded_men[g])==0) continue;
            dead_primary_dead_man_search(g); 
            break; 
        }
    }
    else if (dead_o_ded_test_o==2)
    {
        dead_primary_dead_man_search(index); 
    }
    else
    {
        cout << "NO"; return 0; 
    }
    if (dead_searching_ded.size()!=a+1)
    {
        cout << "NO"; return 0; 
    }
    cout << "YES" << '\n';
    reverse(dead_searching_ded.begin(), dead_searching_ded.end()); 
    for (int g=0; g<dead_searching_ded.size(); g++)
    {
        if (g==0)
        {
            int next_dead_man=dead_searching_ded[g]%75; 
            int primary_dead_man=(dead_searching_ded[g]-next_dead_man)/75; 
            cout << char('0'+primary_dead_man) << char('0'+next_dead_man); 
        }
        else
        {
            int primary_dead_man=(dead_searching_ded[g]%75); 
            int next_dead_man=(dead_searching_ded[g]-primary_dead_man)/75; 
            cout << char('0'+primary_dead_man); 
        }
    }
    return 0; 
}
