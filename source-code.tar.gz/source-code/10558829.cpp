//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cctype>
#include<algorithm>
#include<queue>
#include<stack>
#include<vector>
#include<string>
#include<cstring>
#include<ctime>
#include<map>
#include<set>
#include<list>
#include<deque>
#include<iterator>
#include<utility>
#include<climits>
#include<iomanip>
#include<assert.h>
#include<bitset>
#include<stdint.h>

#define LL long long 
#define sn(n) scanf("%d",&n) ;
#define slld(n) scanf("%lld",&n) ;
#define sc(n) scanf(" %c",&n) ;
#define ss(n) scanf(" %s",n) ;
#define all(n) n.begin() , n.end()
#define pb push_back
#define vi vector<int> 
#define vLL vector<LL >
#define vvi vector<vi >
#define vvLL vector<vLL >
#define vc vector<char>
#define vvc vector<vc >
#define vb vector<bool>
#define vvb vector<vb > 
#define pii pair<int , int> 
#define fi first 
#define se second
#define mp make_pair
#define vpii vector<pii >
#define vvpii vector<vpii >
#define rep(i , a , b) for(int (i) = (a) ; (i) < (b) ; ++(i))
#define rev(i , a , b) for(int (i) = (a)-1 ; (i) >= (b) ; --(i))
#define tr(container , it) for(typeof(container.begin()) it = container.begin() ; it != container.end() ; ++it)
#define mii map<int , int>
#define msi map<string , int>
#define mci map<char , int>
#define INF (1<<31)
#define fast_io ios::sync_with_stdio(0) ; cin.tie(0) ; 
#define max_array 2002
#define in() freopen("input.txt" , "r" , stdin) ;
#define out() freopen("output.txt" , "w" , stdout) ;
#define MOD 1000000007
#define debug() cout << "HI" << endl ;
 
using namespace std ;

int main()
{
    #ifndef ONLINE_JUDGE
        in() ;
    #endif
    fast_io ;
    int n, s ;
    cin >> n >> s ;
    int temp_s = s, temp_n = n ;
    int min_output ;
    vi ans ;
    if((s == 0 && n != 1) || s > 9*n)
    {
        cout << "-1 -1" << endl ;
        return 0 ;
    }
    while(temp_n--)
    {
        min_output = temp_s ;
        ans.pb(min(9, min_output)) ;
        temp_s -= min(9, min_output) ;
    }
    reverse(all(ans)) ;
    rep(i, 0, ans.size())
    {
        if(ans[i] == 1)
        {
            swap(ans[i], ans[0]) ;
            break ;
        }
        if(ans[i] > 1)
        {
            if(i == 0)
                break ;
            ans[0] = 1 ;
            ans[i] -= 1 ;
            break ;
        }

    }
    rep(i, 0, ans.size())
        cout << ans[i] ;

    cout << " " ;
    temp_s = s, temp_n = n ;
    while(temp_n--)
    {
        min_output = temp_s ;
        cout << min(9, min_output) ;
        temp_s -= min(9, min_output) ;
    }
    cout << endl ;

    return 0 ;
}