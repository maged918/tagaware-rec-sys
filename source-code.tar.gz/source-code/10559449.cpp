//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <set>
#include <cmath>
#include <cstring>
#include <fstream>
#include <queue>
#include <stack>
#include <vector>
#include <map>
#define LL long long
#define INF 2*0x3f3f3f3f

using namespace std;

char str[110];
bool vis[30],flag=true;
int len;

int main(){
    scanf("%d%s",&len,str);
    memset(vis,false,sizeof(vis));
    for(int i=0;i<len;i++){
        if(str[i]>='a'&&str[i]<='z') vis[str[i]-'a']=true;
        else vis[str[i]-'A']=true;
    }
    for(int i=0;i<='z'-'a';i++) if(!vis[i])  { flag=false; break; }
    if(flag) printf("YES\n");
    else printf("NO\n");
    return 0;
}

 	  	  	     	 	 					 	 				