//Language: GNU C++11


#include <iostream>
#include <string>
#include <cctype>
#include <cmath>
#include <vector>
#include <deque>
#include <algorithm>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <climits>
#include <iomanip>
#include <cstdio>
#include <functional>

using namespace std;

struct node {
    long long x, w;
};

bool compare(node a, node b) {
    return a.x+a.w<b.x+b.w;
}

node nodes[200010];
long long depth[200010];


int main() {
    long long n;
    cin >>n;
    set<long long> indices;

    for (long long i=0;i<n;i++) {
        cin>>nodes[i].x>>nodes[i].w;
        indices.insert(i);
    }
    sort(nodes, nodes+n, compare);
    
    long long max=0;

    while (!indices.empty()) {
        long long len=1;
        auto it = indices.begin();
        node prev = nodes[*it];
        it = indices.erase(it);
        
        //cout << "Begin with " << prev.x << " " << prev.w << endl;
        
        while (it != indices.end()) {
            node current = nodes[*it];
            bool erased = false;
            if (current.x - prev.x >= current.w + prev.w) {
                len++;
                //it = indices.erase(it);
                //erased = true;
                prev = current;
               // cout << "Continue with " << prev.x << " " << prev.w << endl;

            }
            if (!erased) {
                it++;
            }
        }
        if (len > max) {
            max=len;
        }
        break;
    }
    
    cout<<max<<endl;
}
