//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<int, pair<int, int> > iii;


ll xa, ya, xb, yb, n;
//vector<iii> lines;

/*
struct point {
    double x, y;
    point() {x = y = 0.0;}
    point(double _x, double _y) : x(_x), y(_y) {}
    bool operator < (point other) const {
        if (fabs(x - other.x) > EPS) {
            return x < other.x;
        }
        return y < other.y;
    }
    bool operator == (point other) const {
        return fabs(x - other.x) < EPS && fabs(y - other.y) < EPS;
    }
};

struct line  {double a, b, c; };

void pointsToLine(point p1, point p2, line &l) {
    if (fabs(p1.x - p2.x) < EPS) {
        l.a = 1.0; l.b = 0.0; l.c = -p1.x;
    } else {
        l.a = -(double)(p1.y - p2.y)/(p1.x - p2.x);
        l.b = 1.0;
        l.c = -(double)(l.a*p1.x) - p1.y;
    }
}
bool areParallel(line l1, line l2) {
    return fabs(l1.a - l2.a) < EPS && fabs(l1.b - l2.b) < EPS;
}
bool areSame(line l1, line l2) {
    return areParallel(l1, l2) && fabs(l1.c - l2.c) < EPS;
}
bool areIntersect(line l1, line l2, point &p) {
    if (areParallel(l1, l2)) return false;
    p.x = (l2.b*l1.c-l1.b*l2.c)/(l2.a*l1.b - l1.a*l2.b);
    if (fabs(l1.b) < EPS) {
        p.y = -(l1.a*p.x + l1.c);
    } else {
        p.y = - (l2.a*p.x + l2.c);
    }
    return true;
}

bool isBetween(point a, point b, point c){
    double crossproduct = (c.y - a.y) * (b.x - a.x) - (c.x - a.x) * (b.y - a.y);
    if (fabs(crossproduct) > EPS) return false;

    double dotproduct = (c.x - a.x) * (b.x - a.x) + (c.y - a.y)*(b.y - a.y);
    if (dotproduct < 0) return false;

    double squaredlengthba = (b.x - a.x)*(b.x - a.x) + (b.y - a.y)*(b.y - a.y);
    if (dotproduct > squaredlengthba) return false;

    return true;
}*/

int main() {


    cin >> xa >> ya;
    cin >> xb >> yb;
    cin >> n;
    int result = 0;
    for(int i = 0; i < n; i++) {
        ll a, b, c;
        cin >> a >> b >> c;
        ll val1 = a*xa + b*ya;
        ll val2 = a*xb + b*yb;
        if ((val1 > -c && val2 < -c) || (val1 < -c && val2 > -c)) result++;
    }
    cout << result << endl;

}
