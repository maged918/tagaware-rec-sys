//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>
using namespace std;

set<int> s;
int n, a[100001], x, y, l;

int find()
{
	for (int i = 1; i <= n; i++) {
		if (a[i]+x <= l && (s.count(a[i]+x+y) || s.count(a[i]+x-y)))
			return a[i] + x;
		if (a[i]-x >= 0 && (s.count(a[i]-x+y) || s.count(a[i]-x-y)))
			return a[i] - x;
	}
	return -1;
}

int check(int m)
{
	for (int i = 1; i <= n; i++)
		if (s.count(a[i]-m))
			return 1;
	return 0;
}

int main() {
	scanf("%d%d%d%d", &n, &l, &x, &y);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		s.insert(a[i]);
	}
	int t1 = check(x), t2 = check(y);
	if (t1 && t2)
		printf("0\n");
	else if (t1 && !t2)
		printf("1\n%d\n", y);
	else if (!t1 && t2)
		printf("1\n%d\n", x);
	else {
		int flag = find();
		if (flag == -1)
			printf("2\n%d %d\n", x, y);
		else printf("1\n%d\n", flag);
	}
	return 0;
}

  	 	 	  	  			 			   	 	  		