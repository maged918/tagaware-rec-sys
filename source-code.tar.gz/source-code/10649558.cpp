//Language: MS C++


#include <iostream>
#include <string>

using namespace std;
string s, t;
bool flag = true;

int main() {
    cin >> s >> t;
    int i = s.length() - 1;
    s[i]++;
    while(s[i] > 'z') {
        s[i] = 'a';
        if(i > 0) {
            s[--i]++;
        } else {
            flag = false;
            break;
        }
    }
    if(s < t) {
        cout << s;
    } else {
        cout << "No such string";
    }
    //system("pause");
    return 0;
}