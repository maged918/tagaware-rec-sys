//Language: GNU C++


#include <iostream>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <map>
#include <set>
#include <queue>
#include <sstream>
using namespace std;
set<char>let;
int main()
{
     string name;getline(cin , name);

     for(int i=0;i<name.length();i++){

        switch(name[i]){
        case ' ' : continue;
        case '{' : continue;
        case '}' : continue;
        case ',' : continue;

        }
        let.insert(name[i]);
     }
       cout << let.size() << endl;
    return 0;
}
