//Language: GNU C++


#include <iostream>
#include <cstdio>
using namespace std;

int n, A[10];
char s[17];

int main() {
    scanf("%d %s", &n, s + 1);
    for (int i = n; i > 0; i--) {
        switch(s[i] - '0')
        {
        case 2:
            A[2]++; break;
        case 3:
            A[3]++; break;
        case 4:
            A[3]++; A[2] += 2; break;
        case 5:
            A[5]++; break;
        case 6:
            A[5]++; A[3]++; break;
        case 7:
            A[7]++; break;
        case 8:
            A[7]++; A[2] += 3; break;
        case 9:
            A[7]++; A[3] += 2; A[2]++; break;
        }
    }
    for (int i = 9; i > 1; i--)
        for (int j = 0; j < A[i]; j++)
            printf("%d", i);
    return 0;
}