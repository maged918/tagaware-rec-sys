//Language: MS C++


#pragma comment (linker,"/stack:102400000,102400000")
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
using namespace std;

typedef __int64 LL;
//typedef unsigned long long ULL;
const int N = 2005;
const int M = 4000005; 
const int INF = 0x3f3f3f3f;
const LL MOD = 1000000000000000000;
const double PI = acos(-1.0);

#define Key_value ch[ch[root][1]][0]
#define lson (i<<1)
#define rson (i<<1|1)
#define lsony (j<<1)
#define rsony (j<<1|1)

template < class T > inline T f_min(T a,T b){return a < b ? a : b;}
template < class T > inline T f_max(T a,T b){return a > b ? a : b;}
template < class T > inline T f_abs(T a){return a > 0 ? a : -a;}
template < class T > inline T gcd(T a,T b){return b == 0 ? a : gcd(b,a%b);}
template < class T > inline void f_swap(T &a,T &b){T t = a;a = b;b = t;}

int n,m;
int b[4][2] = {0,1,1,0,0,-1,-1,0};
char s[N][N],ans[N][N];
char temp[4] = {'>','v','<','^'};
char temp1[4] = {'<','^','>','v'};
int vis[M],in[M];
vector<int>G[M];
void dfs(int from){
    vis[from] = true;
    for(int i = 0;i < G[from].size();++i){
        int to = G[from][i];
        in[to]++;
        if(vis[to]) continue;
        dfs(to);
    }
}
int main(){
    while(~scanf("%d%d",&n,&m)){
        for(int i = 0;i < n;++i)scanf("%s",s[i]);
        for(int i = 0;i < n*m;++i)G[i].clear();
        for(int i = 0;i < n;++i){
            for(int j = 0;j < m;++j)if(s[i][j] == '.'){
                for(int k = 0;k < 2;++k){
                    int x = i + b[k][0];
                    int y = j + b[k][1];
                    if(x >= 0 && x < n && y >= 0 && y < m){
                        if(s[x][y] == '.'){
                            G[i*m+j].push_back(x*m+y);
                            G[x*m+y].push_back(i*m+j);
                        }
                    }
                }
            }
        }/*
        for(int i = 0;i < n * m;++i){
            for(int j = head[i];j != -1;j = G[j].next)
                cout<<G[j].to<<" ";
            cout<<endl;
        }*/
        memset(vis,0,sizeof(vis));
        memset(in,0,sizeof(in));
        for(int i = 0;i < n*m;++i)if(!vis[i])
            dfs(i);
        //for(int i = 0;i < n*m;++i)cout<<in[i]<<" ";
        //cout<<endl;
        queue<int>  q;
        for(int i = 0;i < n*m;++i)if(in[i] == 1)
            q.push(i);
        memset(vis,0,sizeof(vis));
        for(int i = 0;i < n;++i){
            for(int j = 0;j < m;++j)ans[i][j] = '*';
            ans[i][m] = '\0';
        }
        bool w = false;
        while(!q.empty()){
            int from = q.front();
            q.pop();
            if(vis[from])   continue;
            //cout<<from<<" : ";
            vis[from] = true;
            bool flag = false;
            for(int i = 0;i < G[from].size();++i){
                int to = G[from][i];
                //cout<<to<<" ";
                in[to]--;
                if(vis[to]) continue;
                flag = true;
                vis[to] = true;
                for(int j = 0;j < G[to].size();++j){
                    int temp_to = G[to][j];
                    in[temp_to]--;
                    if(in[temp_to] == 1)    q.push(temp_to);
                }
                int x = from / m;
                int y = from - x * m;
                int temp_x = to / m;
                int temp_y = to - temp_x * m;
                for(int j = 0;j < 4;++j)if(x + b[j][0] == temp_x && y + b[j][1] == temp_y)
                    ans[x][y] = temp1[j],ans[temp_x][temp_y] = temp[j]; 
            }
            if(!flag){
                w = true;
                break;
            }
            /*
            cout<<endl;
            for(int i = 0;i < n*m;++i)cout<<" "<<in[i];
            cout<<endl;
            for(int i = 0;i < n*m;++i)cout<<" "<<vis[i];
            cout<<endl;
            for(int j = 0;j < n;++j)printf("%s\n",ans[j]);
            */
        }
        int i;
        for(i = 0;i < n*m;++i)if(in[i]) break;
        if(i != n*m || w || n*m == 1 && s[0][0] == '.')
            puts("Not unique");
        else 
            for(int i = 0;i < n;++i)printf("%s\n",ans[i]);
            
    }
    return 0;
}