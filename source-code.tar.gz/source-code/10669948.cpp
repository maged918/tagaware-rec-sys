//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
#define For(i,a,b) for(int i=a;i<b;i++)
#define pb push_back
#define mod 1000000007
#define reset(s,val) memset(s,val,sizeof(s))
#define eps 0.0000001
#define pi acos(-1)
#define sqr(x) (x)*(x)
#define maxn 32000

int v1,v2,t,d,ans,v;

int main( ){
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
    cin>>v1>>v2>>t>>d;
    ans=v1+v2;
    v=v1;
    For(i,2,t)
    {
        v=min(v+d,v2+d*(t-i));
        ans+=v;
        //cout<<v<<endl;
    }
    cout<<ans;
}
