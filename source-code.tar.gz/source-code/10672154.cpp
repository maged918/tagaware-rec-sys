//Language: GNU C++11


#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <cmath>
#include <algorithm>
#include <cstdio>

using namespace std;

vector <int> first;
vector <int> ans = { 1, 5, 3, 6, 2, 4 };

int main()
{
	int n;
	cin >> n;
	if (n == 1) {
		cout << 1 << endl << 1;
		return 0;
	}
	if (n == 2) {
		cout << 1 << endl << 1;
		return 0;
	}
	if (n == 3) {
		cout << 2 << endl << "1 3";
	}
	if (n == 4) {
		cout << 4 << endl << "2 4 1 3";
	}
	if (n == 5) {
		cout << 5 << endl << "1 4 2 5 3";
	}
	if (n >= 6) {
		for (int i = n; i > 6; --i) {
			if (i % 2 == 0)
				ans.push_back(i);
			else
				first.push_back(i);
		}
		cout << n << endl;
		for (auto it = first.begin(); it != first.end(); ++it) {
			cout << (*it) << " ";
		}
		for (auto it = ans.begin(); it != ans.end(); ++it) {
			cout << (*it) << " ";
		}
	}
	return 0;
}