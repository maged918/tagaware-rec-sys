//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define mod 1000000007
#define f first
#define s second

int main()
{
    int n,m,i,d,t,dd,tt,ct,u,v,s;
    scanf("%d%d",&n,&m);
    scanf("%d%d",&t,&d);
    if(n>m)
    {
        i=n;
        n=m;
        m=i;
    }
    s=0;
    for(i=1;i<t;i++)
    {
        if(n<m)
        {
           s=s+n;
           //printf("%d\n",n);
           n=n+d;
        }
        else
        {
            s=s+m;
            //printf("%d\n",m);
            m=m+d;
        }
    }
    s=s+min(n,m);
    //printf("%d\n",min(n,m));
    printf("%d\n",s);
    return 0;
}

