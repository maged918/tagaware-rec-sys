//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <cmath>
#include <stack>
#include <set>
#include <map>
#include <vector>
#include <queue>
#include <algorithm>
#include <utility>
#include <cstdlib>
#include <cstring>
#include <string>
using namespace std;

#ifdef WIN32
	#define lld "%I64d"
#else
	#define lld "%lld"
#endif

#define mp make_pair
#define pb push_back
#define put(x) { cerr << #x << " = "; cerr << (x) << endl; }
                                                                                                                                                               
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef double db;

const int M = 3 * 1e5 + 15 * 15 * 15;
const int Q = 1e9 + 7;


set<pair<int, int> > se[3];
vector<int> ans;
int a[M], val[M];

void fin(){
	printf("Impossible");
	exit(0);
}
int main(){
	srand(time(NULL));
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n;
	scanf("%d", &n);
	int pos0 = -1;
	for (int i = 0; i < n; i++){
		scanf("%d", &a[i]);
		se[a[i] % 3].insert(mp(a[i], i + 1));
		if (a[i] == 0){
			pos0 = i + 1;
		}
	}
	if (pos0 == -1)
		fin();
	ans.pb(pos0);
	se[0].erase(se[0].find(mp(0, pos0)));
	val[0] = 0;
	for (int i = 1; i < n; i++){
		if (se[i % 3].size() == 0)
			fin();
		set<pair<int, int> > :: iterator it = se[i % 3].upper_bound(mp(val[i - 1] + 1, n + 1));
		if (it == se[i % 3].begin())
			fin();
		it--;
		ans.pb((*it).second);
		val[i] = (*it).first;
		se[i % 3].erase(it);
	}
	printf("Possible\n");
	for (int i = 0; i < n; i++)
		printf("%d ", ans[i]);
	return 0;

		
}	