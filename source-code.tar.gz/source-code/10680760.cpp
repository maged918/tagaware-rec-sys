//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;

int main()
{
    int st,ed,i,d,t,dis,sum,step;
    vector<int>v;
    while(cin>>st>>ed>>t>>d)
    {
        v.push_back(st);
        v.push_back(ed);
        for(i=1;i<=t-2;i++)
        {
            dis=d;
            step=t-i-1;
            while(1)
            {
                if(abs((st+dis)-ed)<=step*d)
                {
                    v.push_back(st+dis);
                    st=st+dis;
                    //ed=st+dis;

                    break;
                }

                dis--;
            }
        }
        sum=0;
        for(i=0;i<v.size();i++)
        {
            sum+=v[i];
            //cout<<v[i]<<" ";
        }
        //cout<<endl;
        cout<<sum<<endl;
        v.clear();
    }
}
