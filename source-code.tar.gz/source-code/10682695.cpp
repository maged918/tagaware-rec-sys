//Language: MS C++


#include <iostream>

using namespace std;

int main()
{
	int n,d[222222];
	long long s=0,a;
	cin >> n >> a;
	for(int i=0;i<n;i++)cin >> d[i],s+=d[i];
	
	int ans;
	for(int i=0;i<n;i++)
	{
		int lt=1,rt=d[i];

		int l=1,r=d[i],c;
		while(l<r)
		{
			c = (l+r)/2;
			if(s-d[i]+c>=a)r=c; else l=c+1;
		}
		lt = l;

		l=lt;
		r=d[i];
		while(l<r)
		{
			c = (l+r)/2;
			if(c+n-1>a)r=c; else l=c+1;
		}
		if(r+n-1>a)r--;
		rt = r;

		ans=lt-1+(d[i]-rt);
		cout << ans << " ";
	}
//	system("pause");
}