//Language: GNU C++11


#include <fstream>
#include <iostream>
#include <string>
#include <complex>
#include <math.h>
#include <set>
#include <vector>
#include <map>
#include <queue>
#include <stdio.h>
#include <stack>
#include <algorithm>
#include <list>
#include <ctime>
#include <memory.h>
#include <ctime> 
 
#define y0 why_is_y0_reserved
#define y1 why_is_y1_reserved
#define yn why_is_yn_reserved
#define j1 why_is_j1_reserved
#define tm why_is_tm_reserved
#define lr why_is_lr_reserved
//...if I want to use them
 
#define eps 1e-9
#define bs 1000000007
#define bsize 256
#define inf 1000000000
#define linf 1500000000 

using namespace std;

int main() {
//ios_base::sync_with_stdio(0);

int v1,v2,t,d,k;
    cin>>v1>>v2>>t>>d;
    int i,l=0;
    i=0;
    if(v1<v2)
    {
        while(v1<v2){
            l+=v1;
            v1+=d;
            i++;
        }
        t-=i;
        while(t>1)
        {
            l+=v1+v2;
            v1+=d;
            v2+=d;
            t-=2;
        }
        if(t==1)
        {
            l+=v2;
        }
    }
    else
    {
        while(v2<v1){
            l+=v2;
            v2+=d;
            i++;
        }
        t-=i;
        while(t>1)
        {
            l+=v1+v2;
            v1+=d;
            v2+=d;
            t-=2;
        }
        if(t==1)
        {
            l+=v1;
        }
    }
    cout<<l<<endl;

cin.get();cin.get();
return 0;}
