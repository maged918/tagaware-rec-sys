//Language: GNU C++


#include <iostream>

#define endl '\n'

using namespace std;

int v1, v2, t, d;

int main() {

	ios::sync_with_stdio( false);	cin.tie( NULL);

	cin >> v1 >> v2 >> t >> d;

	int ans = v1;
	for( int i=2;  i<t ; i++) {

		int incr1 = v1 + (i-1)*d;
		int incr2 = v2 + (t-i)*d;
		int incr = incr1 > incr2 ? incr2 : incr1;
		ans += incr;
	}
	ans += v2;

	cout << ans << endl;




	return 0;
}
