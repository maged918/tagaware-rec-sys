//Language: GNU C++11


#include<bits/stdc++.h>

//TEMPLATE STARTS HERE
using namespace std;

//constants
const int MAXN=(int)(1e5+1e1);
const double PI=acos(-1.0);

//defines
#define ll long long
#define F first
#define S second
#define FFF ""
#define fr freopen(FFF"in","r",stdin);
#define fw freopen(FFF"out","w",stdout);
#define mp make_pair
#define pb push_back
#define eof (-1)
#define forr(xx,yy,zz) for(int zz=xx;zz<=yy;zz++)
#define forl(xx,yy,zz) for(int zz=xx;zz>=yy;zz--)
#define sqr(x) ((x)*(x))
#define sz(x) (int)x.size()
#define len(s) (int)(s.length())
#define all(a) a.begin(),a.end()
ll n,k;
vector<int> v;
int main()
{
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cin>>n; /*
  if(n%2==0)
  {
  	if(n==2)
  	{
  		cout<<1<<'\n'<<1;
  		return 0;
  	}
  	cout<<n<<'\n';
  	forr(1,n/2,i)
  	{	
  		cout<<i<<' '<<n/2+i<<' ';	
  	}
  }
  else
  {         */
  	if(n==1 || n==2)
  	{
  		cout<<1<<'\n'<<1;
  		return 0;
  	}
  	if(n==3)
  	{
  		cout<<2<<'\n'<<"1 3";
  		return 0;
  	}
  	if(n==4)
  	{
  		cout<<4<<'\n'<<"3 1 4 2";
  		return 0;
  	}       
  	cout<<n<<'\n';
  	for(int i=1;i<=n;i+=2)
  		cout<<i<<' ';
  	for(int i=2;i<=n;i+=2)
  		cout<<i<<' ';
	return 0;	
}                  