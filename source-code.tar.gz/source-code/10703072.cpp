//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <cstdio>

using namespace std;
typedef long long LL;
typedef long double LD;
    LL a,b;
    bool flag;
    LL GCD;
    LL ans;


LL gcd(LL x,LL y)
{
    if (x<y) return gcd(y,x);
    if (x%y==0) return y;
    return gcd(y,x%y);
}
bool ok()
{
    if ((a%2==0||a%3==0||a%5==0||a==1)&&(b%2==0||b%3==0||b%5==0||b==1))
    return true;
    return false;
}

int main()
{

    cin>>a>>b;
    if (a==b)
    {
        cout<<"0"<<endl;
        return 0;
    }
    GCD =gcd (a,b);
    a = a / GCD;
    b = b / GCD;
    flag = false;
    flag = ok();
    ans = 0;
   // cout<<a<<endl;
  //  cout<<b<<endl;
    if (flag)
    {
        while (a%2==0)
        {
            ans++;
            a = a / 2;
         //     cout<<"ans:"<<ans<<endl;

        }
        while  (a%3==0)
        {
            ans++;
            a = a/ 3;

        }
        while  (a%5==0)
        {
            ans++;
            a = a/ 5;

        }
        while  (b%2==0)
        {
            ans++;
            b = b/2;
        }
        while (b%3==0)
        {
            ans++;
            b = b/3;
       //       cout<<"ans:"<<ans<<endl;
        }
        while (b%5==0)
        {
            ans++;
            b = b/5;

        }
          //  ans = floor (ans+0.5);
          if (a==b)
          cout<<ans<<endl;
          else cout<<-1<<endl;

    }
    else
    {
        cout<<-1<<endl;
    }


 //   system("pause");
    return 0;
}
 	 	   		 	 		 	 	 			   				