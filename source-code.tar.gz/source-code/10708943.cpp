//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
int main()
{
    ios_base::sync_with_stdio(false);
    string s;
    cin>>s;
    if(s.size()==1)
    {
        int d=atoi(&s[0]);
        if(d==0)
        {
            cout<<"zero\n";
        }
        else if(d==1)
        {
            cout<<"one\n";
        }
        else if(d==2)
        {
            cout<<"two\n";
        }
        else if(d==3)
        {
            cout<<"three\n";
        }
        else if(d==4)
        {
            cout<<"four\n";
        }
        else if(d==5)
        {
            cout<<"five\n";
        }
        else if(d==6)
        {
            cout<<"six\n";
        }
        else if(d==7)
        {
            cout<<"seven\n";
        }
        else if(d==8)
        {
            cout<<"eight\n";
        }
        else if(d==9)
        {
            cout<<"nine\n";
        }
    }
    else
    {
        int d=atoi(&s[0]);
        int e=d/10;
        if(e==2)
        {
            cout<<"twenty";
        }
        else if(e==3)
        {
            cout<<"thirty";
        }
        else if(e==4)
        {
            cout<<"forty";
        }
        else if(e==5)
        {
            cout<<"fifty";
        }
        else if(e==6)
        {
            cout<<"sixty";
        }
        else if(e==7)
        {
            cout<<"seventy";
        }
        else if(e==8)
        {
            cout<<"eighty";
        }
        else if(e==9)
        {
            cout<<"ninety";
        }
        if(d%10==0)
        {
            if(e==1)
            {
                cout<<"ten";
            }
            cout<<"\n";
        }
        else
        {
            if(e==1)
            {
                d=d%10;
                if(d==1)
        {
            cout<<"eleven\n";
        }
        else if(d==2)
        {
            cout<<"twelve\n";
        }
        else if(d==3)
        {
            cout<<"thirteen\n";
        }
        else if(d==4)
        {
            cout<<"fourteen\n";
        }
        else if(d==5)
        {
            cout<<"fifteen\n";
        }
        else if(d==6)
        {
            cout<<"sixteen\n";
        }
        else if(d==7)
        {
            cout<<"seventeen\n";
        }
        else if(d==8)
        {
            cout<<"eighteen\n";
        }
        else if(d==9)
        {
            cout<<"nineteen\n";
        }
            }
            else
            {
                cout<<"-";
                d=d%10;
                if(d==1)
        {
            cout<<"one\n";
        }
        else if(d==2)
        {
            cout<<"two\n";
        }
        else if(d==3)
        {
            cout<<"three\n";
        }
        else if(d==4)
        {
            cout<<"four\n";
        }
        else if(d==5)
        {
            cout<<"five\n";
        }
        else if(d==6)
        {
            cout<<"six\n";
        }
        else if(d==7)
        {
            cout<<"seven\n";
        }
        else if(d==8)
        {
            cout<<"eight\n";
        }
        else if(d==9)
        {
            cout<<"nine\n";
        }
            }
        }
    }
}