//Language: GNU C++


#include<iostream>
#include<cmath>
#include<cstdio>
#include<iomanip>
using namespace std;
int n;
int ans;
int fun(long long x)
{
    if(x>n)
        return 0;
    else
    {
        ans++;
        fun(x*10+4);
        fun(x*10+7);
    }
}
int main()
{
//    freopen("in.txt","r",stdin);
    while(cin>>n)
    {
        ans=0;
        fun(4);
        fun(7);
        cout<<ans<<endl;
    }
    return 0;
}
