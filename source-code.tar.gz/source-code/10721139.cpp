//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;

const int N=100001 ;
typedef long long ll ;
ll a , b , n , q , l , t , m , s[N] , sum[N] ;

bool isPossible(int l ,int r) {
  if(a+(r-1)*b > t ) return false ;	
  ll x1= 1LL*r*(2*a+(r-1)*b)/2 ;
  ll x2= 1LL*(l-1)*(2*a+(l-2)*b)/2 ;
  ll x = x1-x2  ; 
  return ( ( x/m + (x%m!=0) ) <= t ) ; 
}
 
int main() {
  cin >> a >> b >> q ;  
/*  for(int i=1 ; i<=n ; i++) { 
     s[i] = a + (i-1)*b ;  
     sum[i] = sum[i-1]+s[i] ; 
  } */
  
  while(q--) {
    cin >> l >> t >> m ;

    ll mid , L=l , h=t ;
    while(l<h) {
      mid=(l+h)/2+1 ;   
      if(isPossible(L,mid)) l=mid ; 
      else h=mid-1 ;
    }
    
    cout << ((isPossible(L,l))?l:-1) << "\n";
  }
  return 0 ;
}