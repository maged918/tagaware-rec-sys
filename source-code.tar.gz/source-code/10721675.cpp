//Language: GNU C++


#define TASKNAME ""
#include <bits/stdc++.h>

#define MAXN int(1e6 + 10)
#define INF int(1e9)    
#define MOD int(1e9 +7) 
#define pb push_back
#define mp make_pair
#define sz(A) (int)(A).size()
#define pi 3.1415926535897932384626433832795
#define sqr(a) ((a) * (a))
#define x fghsdhgjfshgkjfdhgjfs
#define y jhfjghjfdsghsjfd
#define out(x) cout<<(x)<<" " << "\n"
#define DB(x) cerr<<#x<<" = "<<(x)<<"\n"
#define DB2(a,b)   cerr<<#a<<"="<<(a)<<", "<<#b<<"="<<(b)<<"\n"

using namespace std;

typedef long long LL;


long long t = 239, r = MOD, left1, right1;
long long hash[MAXN], pt[MAXN], hash_str;
int ind = 0, n, m, a[MAXN];
string pat, str;



void power(){
  pt[0] = 1;
  for(int i = 1; i <= int(pat.size()); i++)
    pt[i] = (pt[i - 1] * t) % MOD;         
}


void build_hash(){    
  long long v = 0;
  n = int(pat.size());
  for(int i = 0; i <= n; i++){   
     v = (v * t + (pat[i])) % r;
     hash[i] = v;    
  }              
}


long long build_hash1(){
  long long v = 0;
  n = int(str.size());
  for(int i = 0; i < n; i++)   
     v = (v * t + (str[i])) % r;
  return v;    
}

                
long long get_hash(int left, int right){
  LL vr = hash[right];
  LL vl;
  if(left == 0)
    vl = 0;
  else
   vl = hash[left - 1];
  LL ans = (vr - vl * pt[right - left + 1]) % r;
  if(ans < 0) //так быстрее, потому что предсказатель решений
    ans += r;
  return ans;
}


long long get_ans(int n){
  long long ans = 1;                       
  for(int i = 1; i <= n; i++)
    ans = (ans * 26) % MOD;
  return ans;
}


bool check(){
  for(int i = 0; i < m; i++){
    int left1 = a[i], right1 = a[i] + sz(str) - 1;
    if(hash_str != get_hash(left1, right1))
      return false;
  }
  return true;
}


int main()
{
  
  #ifndef ONLINE_JUDGE
    freopen(TASKNAME".in", "r", stdin);
    freopen(TASKNAME".out", "w", stdout);
  #endif

  cin >> n >> m;
  int len_string  = n;
  for(int i = 0; i <= n; i++)
     pat.pb('0');
  cin >> str;
  for(int i = 0; i < m; i++){
    cin >> a[i];
    a[i]--;
  }

  int cur_pos = 0;
  for(int i = 0; i < m; i++){
     if(cur_pos > a[i] + sz(str))
      continue;
     else{
      if(a[i] > cur_pos)
        ind = 0;
      else
        ind = cur_pos - a[i];
      for(int j = max(cur_pos, a[i]); ind < sz(str); j++, ind++)
        pat[j] = str[ind];
      cur_pos = a[i] + sz(str) - 1;
     }  
  }

  //build_hashes
  power();
  build_hash();
  hash_str = build_hash1();


  //cout << pat;
  if(check()){
    int nulls = 0;
    for(int i = 0; i < len_string; i++)
      if(pat[i] == '0')
        nulls++;
    cout << get_ans(nulls);
  }  
  else
    cout << 0;   
  return 0;
}