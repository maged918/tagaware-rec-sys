//Language: GNU C++11


#include<bits/stdc++.h>
typedef long long ll;
const int inf=0x3f3f3f3f;
const int MAXN=200100;
using namespace std;
int n,m;
int a[MAXN],b[MAXN];
int Min,Max;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;++i) scanf("%d",&a[i]);
    scanf("%d",&m);
    int x;
    for(int i=1;i<=m;++i){
        scanf("%d",&x);
        b[x]++;
        if(x==1||x==n) b[x]++;
    }
    Min=inf,Max=0;
    for(int i=1;i<=n;++i){
        Max=max(Max,b[i]);
        Min=min(Min,b[i]);
    }
    if(Min==Max){
        bool flag=true;
        for(int i=1;flag&&i<=n-2;++i){
            if(a[i+1]-a[i]!=a[i+2]-a[i+1])
                flag=false;
        }
        if(!flag) puts("-1");
        else{
            printf("%I64d\n",(ll)(a[n]-a[1])*Min-(a[2]-a[1]));
        }
    }else{
        ll ans=0;
        for(int i=2;i<=n;++i){
            ans+=(ll)(a[i]-a[i-1])*min(b[i],b[i-1]);
        }
        printf("%I64d\n",ans);
    }
    return 0;
}
