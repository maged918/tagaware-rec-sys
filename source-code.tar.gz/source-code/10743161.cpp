//Language: GNU C++


/********************************/
/***  Coded By Ankush Sharma  ***/
/********************************/

#include<bits/stdc++.h>
using namespace std;

int main()
{
    std::ios::sync_with_stdio(false);
    int n; cin>>n;
    int arr[300001], ans[300001], index[300001]={0}; memset(ans, -1, sizeof(ans));
    vector<int> v[300001];
    memset(arr, 0, sizeof(arr));
    for(int i=0; i<n; i++)
    {
        int temp; cin>>temp;
        arr[temp]++; v[temp].push_back(i+1);
    }  
    if(arr[0]==0){ cout<<"Impossible"; return 0; }  
    int count=0; 
    while(arr[0])
    {
        int i=0;
        while(arr[i])
        {
            ans[count++]=i; arr[i]--;  i++;
        }
        int req=ans[count-1]+1;
        while(req>=0)
        {
            while(req>=0 && (arr[req]==0 || (req%3)!=(count%3)))
                req--;    
            if(req>=0) { ans[count++]=req; arr[req]--; req=ans[count-1]+1;  }
        } 
        while(count%3!=0) count++;
        if(count>=n && arr[0])
        { cout<<"Impossible"; return 0; }
    } 
    for(int i=0; i<n; i++)
        if(ans[i]==-1)
        { cout<<"Impossible"; return 0; }  
        
    cout<<"Possible\n";
    for(int i=0; i<n; i++)
    {
        cout<<v[ans[i]][index[ans[i]]++]<<" ";
    }    
    return 0;
}
    
