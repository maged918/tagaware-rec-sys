//Language: GNU C++


/*
 * smiesc4_5.cpp
 *
 *  Created on: 2015年4月18日
 *      Author: prince
 */
#include <cstdio>
#include <algorithm>
#include <vector>
#define maxn 100005
using namespace std;

int n, m, ans;
int a[maxn];
vector<int> v[maxn];

void solve() {
	int i, j, k, flag = 0, ok, sz, tmp;
	for (i = 1; i <= 500; i++)     // 随机500次
			{
		ok = 1;
		random_shuffle(a + 1, a + n + 1);
		for (j = 1; j <= m; j++)     // 检验排列是否满足条件
				{
			sz = v[a[j]].size();
			for (k = 0; k < sz; k++) {
				if (j == n)
					tmp = 1;   // 要考虑m==n的情况
				else
					tmp = j + 1;
				if (v[a[j]][k] == a[tmp]) {
					ok = 0;
					break;
				}
			}
		}
		if (ok) {
			flag = 1;
			for (j = 1; j <= m; j++) {
				if (j == n)
					tmp = 1;
				else
					tmp = j + 1;
				printf("%d %d\n", a[j], a[tmp]);
			}
			break;
		}
	}
	if (!flag)
		printf("-1\n");
}
int main() {
	int i, l, r;

	scanf("%d%d", &n, &m);
	for (i = 1; i <= n; i++) {
		v[i].clear();
		a[i] = i;
	}
	for (i = 1; i <= m; i++) {
		scanf("%d%d", &l, &r);
		v[l].push_back(r);
		v[r].push_back(l);
	}
	solve();

	return 0;
}

 	   	    		   	 	 	  	 			