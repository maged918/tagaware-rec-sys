//Language: GNU C++


#include<stdio.h>
int main()
{
    int max(int i,int j);
    int a,b,c,x,y,n,m,d,s;
    while(~scanf("%d%d%d",&a,&b,&c))
    {
        x=a+b*c;
        y=a*(b+c);
        m=a*b*c;
        n=(a+b)*c;
        d=a+b+c;
        s=max(max(max(max(x,y),n),m),d);
        printf("%d\n",s);
    }
}
int max(int i,int j)
{
    int z;
    if(i>j)z=i;
    else z=j;
    return (z);
}

			 	 	 	 		 	  	 	 		 			 			