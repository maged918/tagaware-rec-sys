//Language: GNU C++


#include <cstdio>
#include<string.h>
#include <algorithm>
using namespace std;
int gem[30005],dp[30005][500],d,ma=0;//dp[i][j]表示i坐标上次跳跃j+d最多获得宝石数

int dfs(int now,int pa)
{
    if(now>ma||pa+d<=0)
        return 0;
    if(dp[now][pa]>=0)
        return dp[now][pa];
    dp[now][pa]=gem[now]+max(dfs(now+pa+d,pa),max(dfs(now+pa+d-1,pa-1),dfs(now+pa+d+1,pa+1)));
    return dp[now][pa];
}

int main()
{
    int n,t;
    scanf("%d%d",&n,&d);
    memset(dp,-1,sizeof(dp));
    for(int i=0;i<n;i++)
    {
       scanf("%d",&t);
       ma=max(ma,t);
       ++gem[t];
    }
    printf("%d\n",dfs(d,0));
}
