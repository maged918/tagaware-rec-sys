//Language: GNU C++11


#include <iostream>
#include <string>
#include <cstdlib>
#include <map>

using namespace std;

const int maxn = 200001;

int h[maxn];
int T[maxn];
int P[maxn];
long long V[maxn];
int X[maxn];

long long max_h;
int n;
long long a[maxn], b[maxn];
int mas[maxn];

void add(long long t[], int i, long long value) {
    for (; i < maxn; i += (i + 1) & -(i + 1))
        t[i] += value;
}

long long sum(long long t[], int i) {
    long long res = 0;
    for (; i >= 0; i -= (i + 1) & -(i + 1))
        res += t[i];
    return res;
}


long long get(int H)
{
    long long V;
    V = mas[H]*1ll*n;

    long long cnt = sum(a, max_h) - sum(a, H);

    V -= mas[H]*cnt;
    V -= sum(b, H);
    return V;
}

int main()
{
    ios::sync_with_stdio(0);
    int q;
    cin >> n >> q;

    map<int,int> mp, id;

    for(int i = 0 ; i < n ; ++i)
    {
        cin >> h[i];
        mp[h[i]] = 1;
    }

    for(int i = 0 ; i < q ; ++i)
    {
        cin >> T[i];
        if(T[i] == 1)
        {
            cin >> P[i] >> X[i];
            mp[X[i]] = 1;
        }
        else
            cin >> V[i];
    }

    int index = 1;
    mas[0] = 0;
    for(map<int,int> :: iterator it = mp.begin() ; it != mp.end() ; ++it)
    {
        id[it->first] = index;
        mas[index] = it->first;
        ++index;
    }
    max_h = index-1;

    for(int i = 0 ; i < n ; ++i)
    {
        add(a, id[h[i]], 1ll);
        add(b, id[h[i]], h[i]);
    }

    int t;
    int p, x, cnt;
    long long v, H;
    for(int i = 0 ; i < q ; ++i)
    {
        t = T[i];
        if(t == 1)
        {
            p = P[i];
            x = X[i];
            add(a, id[h[p-1]], -1);
            add(b, id[h[p-1]], -h[p-1]);

            h[p-1] = x;

            add(a, id[h[p-1]], 1);
            add(b, id[h[p-1]], h[p-1]);
        }
        else
        {
            v = V[i];

            H = 0;
            for(int i = 20 ; i >= 0 ; --i)
            {
                if(H + (1<<i) > max_h) continue;
                if(get(H + (1<<i)) <= v)
                    H += (1<<i);
            }

            cout.precision(5);
            cnt = sum(a, max_h) - sum(a, H);
            cout << fixed << mas[H] + (v-get(H))/(double)(n-cnt) << "\n";
        }
    }
    return 0;
}