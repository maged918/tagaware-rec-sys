//Language: GNU C++


/*
Solution By Aidyn Aluadin
All rights reserved �
Almaty 2015
*/
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <algorithm>
#include <stack>
#include <utility>
#include <queue>
#include <vector>
#include <cstdio>
#include <set>
#include <map>
#include <stdlib.h>
#include <iomanip>     //setprecision()
#define pb push_back()
#define pp pop_back()
#define sz(a) (int)(a.size())
#define F first
#define S second
#define ll long long
#define ull unsigned long long
const int N = (int)1e6 + 123;
const ll inf = (ll)1e18 + 123;
const double eps = 1e-6;

using namespace std;


int main() {
	ios_base::sync_with_stdio(0);	
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	ll r, g, b;
	cin >> r >> g >> b;
	if(max(r , max(g ,b)) >= 2 * (r + g + b - max(r , max(g, b))))
	{
		cout << r + g + b - max(r, max(g, b));
	}else
	cout << (r + g + b) / 3;
	return 0;
}