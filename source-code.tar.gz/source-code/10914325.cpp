//Language: GNU C++


#include <iostream>
#include <vector>
#include <algorithm>
#include <stdio.h>

using namespace std;

int main(){

	long long int n, aux,a ;
	double area;
	vector<int> vetor;
	cin >> n;
	

	for(long long int i=0; i<n; i++){
		cin >> aux;
		vetor.push_back(aux);
	}


	sort(vetor.begin(), vetor.end());	

	for(long long int i=0; i<n; i++){
		
		if(i%2 == 0) area += vetor[n-i-1]*vetor[n-i-1];
		else area -= vetor[n-i-1]*vetor[n-i-1];
	}

	//printf("%f\n", area*3.14159265358979323846264338327950288419716939937510);
	cout.setf( std::ios::fixed, std:: ios::floatfield ); 	
	cout << area*3.141592653589793 << endl;

	return 0;
}
