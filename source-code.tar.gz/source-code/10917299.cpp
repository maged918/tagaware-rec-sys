//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define mod 1000000007LL
#define pb push_back
#define mp make_pair
#define f first
#define s second
#define pii pair<int,int>
#define pll pair<ll,ll>
vector<ll>a,b,v;
vector<ll>::iterator it,it1;
int main()
{
    int i,k,l,n,m,t;
    ll j,d,ans,ansa,ansb,p;
    scanf("%d",&n);
    for(i=0; i<n; i++)
    {
        scanf("%lld",&j);
        a.pb(j);
    }
    sort(a.begin(),a.end());
    scanf("%d",&m);
    for(i=0; i<m; i++)
    {
        scanf("%lld",&j);
        b.pb(j);
    }
    sort(b.begin(),b.end());
        for(i=0; i<a.size(); i++)
    {
        for(j=i; j<n; j++)
            if(a[i]!=a[j])
                break;
        i=j-1;
        v.pb(a[i]-1);
    }

    for(i=0; i<b.size(); i++)
    {
        for(j=i; j<m; j++)
            if(b[i]!=b[j])
                break;
        i=j-1;
        v.pb(b[i]);
    }
    ans=-1000000000000000LL;
    ansa=-1;
    ansb=-1;
    for(i=0; i<v.size(); i++)
    {
        it=upper_bound(a.begin(),a.end(),v[i]);
        it1=upper_bound(b.begin(),b.end(),v[i]);
        d=2*(it-a.begin());
        d=d+(3*(n-(it-a.begin())));
        p=2LL*(ll)(it1-b.begin());
        p=p+(3LL*(ll)(m-(it1-b.begin())));
        if(d-p>ans)
        {
            ans=d-p;
            ansa=d;
            ansb=p;
        }
        else if(d-p==ans&&d>ansa)
        {
            ansa=d;
            ansb=p;
            ans=d-p;
        }
    }
    printf("%lld:%lld\n",ansa,ansb);
    return 0;
}

