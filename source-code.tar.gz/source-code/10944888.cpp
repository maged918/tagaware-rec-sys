//Language: GNU C++11


//============================================================================
// Name        : shit.cpp
// Author      : SaMer
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================
#include <bits/stdc++.h>
#define mp make_pair
typedef long long ll;
using namespace std;
int n,m,r,c;
int dx[]={ 0 , 0 , 1 , -1};
int dy[]={1 , -1 , 0 , 0 };
int mat[555][555];
int vis[555][555],VIS;
bool viss[555][555];
bool dfs2(int x,int y){
    vis[x][y]=VIS;
    if(x==r && y==c && mat[x][y]) return 1;
    mat[x][y]=1;
    for(int i=0;i<4;++i){
        int a=x+dx[i],b=y+dy[i];
        if(a<0 || a>=n || b<0 || b>=m) continue;

        if((!mat[a][b] &&  vis[a][b]!=VIS) || (a==r && b==c)) if(dfs2(a,b)) return 1;
    }
    mat[x][y]=0;
    return 0;
}
bool dfs(int x,int y){
    vis[x][y]=1;
    if(x==r && y==c){
        VIS++;
        return dfs2(x,y);
    }
    mat[x][y]=1;
    for(int i=0;i<4;++i){
        int a=x+dx[i],b=y+dy[i];
        if(a<0 || a>=n || b<0 || b>=m) continue;
        if((!mat[a][b] && !vis[a][b]) || (a==r && b==c)) if(dfs(a,b)) return 1;
    }
    mat[x][y]=0;
    return 0;
}


int main() {
#ifndef ONLINE_JUDGE
    freopen("myfile.in","r",stdin);
#endif
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;++i)
        for(int j=0;j<m;++j){
            char a;
            scanf(" %c",&a);
            if(a=='X') mat[i][j]=1;
        }
    int a,b;
    scanf("%d%d",&a,&b);
  scanf("%d%d",&r,&c);
  r--,c--;a--,b--;
  mat[a][b]=0;
  if(dfs(a,b)) puts("YES");
  else puts("NO");
    return 0;
}
