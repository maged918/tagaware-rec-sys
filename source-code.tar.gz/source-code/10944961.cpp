//Language: GNU C++11


#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <iomanip>

using namespace std;

double dp[101][101][101];
bool vis[101][101][101];

double getdp(int r, int s, int p) {
    if (!r) return 0.0;
    if (!s && !p) return 1.0;
    if (vis[r][s][p]) return dp[r][s][p];
    vis[r][s][p] = 1;
    int rs = r*s;
    int pr = p*r;
    int sp = s*p;
    int tot = rs + pr + sp;
    if (s) dp[r][s][p] += getdp(r, s-1, p) * rs / tot;
    if (r) dp[r][s][p] += getdp(r-1, s, p) * pr / tot;
    if (p) dp[r][s][p] += getdp(r, s, p-1) * sp / tot;
    return dp[r][s][p];
}

int main() {
    int r,s,p;
    cin >> r >> s >> p;
    cout << fixed << setprecision(15) << getdp(r,s,p) << ' ';
    cout << fixed << setprecision(15) << getdp(s,p,r) << ' ';
    cout << fixed << setprecision(15) << getdp(p,r,s) << '\n';
}
