//Language: GNU C++11


/*
    Look at me!
    Look at me!
    Look at how large the monster inside me has become!
*/
#include<fstream>
#include<iostream>
#include<cstdio>
#include<map>
#include<typeinfo>
#include<set>
#define FIT(a,b) for(vector<int >::iterator a=b.begin();a!=b.end();a++)
#define FITP(a,b) for(vector<pair<int,int> >::iterator a=b.begin();a!=b.end();a++)
#define RIT(a,b) for(vector<int>::reverse_iterator a=b.end();a!=b.begin();++a)
#include<stack>
#define ROF(a,b,c) for(int a=b;a>=c;--a)
#include<vector>
#include<algorithm>
#define FOR(a,b,c) for(int a=b;a<=c;++a)
#define REP(a,b) for(register int a=0;a<b;++a)
#include<cstring>
#include<bitset>
#include<cmath>
#include<iomanip>
#define f cin
#define g cout
#include<queue>
#define INF 0x3f3f3f3f
#define debug cerr<<"OK";
#define pii pair<int,int>
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define ld long double
#define ll long long
#define ull unsigned long long
#define eps 1.e-7
#define BUFMAX 10100100
#define M 100005
#define N 1010
#define R 310
#define mod 1000000007
#define eps 1.e-10

using namespace std;

int a[N][N],t,crt,aux[10],nr[10],u3,u1,u0,s0[N],s1[N],s3[N],l0[N],l1[N],l3[N],n,m;
char cha,chb;
int ok(int x)
{
    FOR(i,0,4)
    nr[i]=aux[i];

    FOR(j,1,m)
    {
        u3=u1=u0=0;
        FOR(k,0,x)
        {
            if(k>nr[3])
                break;
            int left=min((x-k)*2,n-k);
            left=min(left,nr[1]);
            if(left+k==n)
            {
                u3=k;
                u1=left;
                u0=0;
            }
            else
            {
                if(n-left-k<=nr[0])
                {
                    u0=n-left-k;
                    u3=k;
                    u1=left;
                }
            }
        }
        if(u1+u0+u3!=n)
        {
            return 0;
        }
        l3[j]=u3;
        l0[j]=u0;
        l1[j]=u1;
        nr[3]-=u3;
        nr[0]-=u0;
        nr[1]-=u1;
    }
    FOR(i,1,m)
    {
        s3[i]=l3[i];
        s0[i]=l0[i];
        s1[i]=l1[i];
    }
    return 1;
}
int main ()
{

    #ifndef ONLINE_JUDGE
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    #endif

    f>>n>>m;
    FOR(i,1,n)
    {
        FOR(j,1,m)
        {
            f>>cha>>chb;
            cha-='0';
            chb-='0';
            if(cha&&chb)
                nr[3]++;
            else
            if(cha||chb)
                nr[1]++;
            else
                nr[0]++;
        }
    }
    FOR(i,0,4)
    aux[i]=nr[i];

    int st=0;
    int dr=n;
    while(st<=dr)
    {
        int mij=(st+dr)>>1;
        if(ok(mij))
            dr=mij-1;
        else
            st=mij+1;
    }
    FOR(i,1,m)
    {
        crt=1;
        FOR(j,1,n)
        {
            if(s3[i])
            {
                a[j][i]=3;
                --s3[i];
            }
            else
            if(s0[i])
            {
                --s0[i];
            }
            else
            {
                a[j][i]=crt;
                crt=1-(crt-1)+1;
                s1[i]--;
            }
        }
    }
    FOR(i,1,n)
    {
        FOR(j,1,m)
        {
            if(a[i][j]==1)
                g<<"01 ";
            else
            if(a[i][j]==2)
                g<<"10 ";
            else
            if(a[i][j])
                g<<"11 ";
            else
                g<<"00 ";
        }
        g<<"\n";
    }
    return 0;
}
