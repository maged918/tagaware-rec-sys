//Language: GNU C++


#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int main()
{
    int a,c=1,v=0;
    cin>>a;
    string b[a];
    for(int i=0;i<a;i++) {
    cin>>b[i];
    }
    sort(b,b+a);
    for(int i=1;i<a;i++)
    {
        if(b[i]==b[i-1]) v++;
    }
    if(v==a-1) cout<<b[0]<<endl;
    else
    {
    
    for(int i=0;i<a;i++)
    {
        if(b[i]==b[i+1]) c++;
        else break;
    }
    if(c>(a-c)) cout<<b[0]<<endl;
    else cout<<b[a-1]<<endl;
}
    return 0;
}