//Language: GNU C++11


#include<cstdio>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<set>
#include<limits>
#include<map>
using namespace std;
typedef long long l;
string s;
l n,k;
char a[101][101];

void input(){
    cin>>n>>k;
    l x;
    x=n*n/2;
    if(n%2==1){
        x=(n/2)*(n/2)+((n+1)/2)*((n+1)/2);
    }
    //cout<<x;
    if(x<k){
        cout<<"NO";
        return;
    }
    if(n%2==1){
    for(int i=1;i<=n;++i){
        for(int j=1;j<=n;++j){
            if(i%2==1 and j%2==1){
                a[i][j]='L';
            }
            else if(i%2==0 and j%2==0){
                a[i][j]='L';
            }
            else a[i][j]='S';

            }
            }

            l res=0;
            cout<<"YES\n";
            for(int i=1;i<=n;++i){
                for(int j=1;j<=n;++j){
                    if(res<k){
                        if(a[i][j]=='S') cout<<a[i][j];
                        else{
                            cout<<a[i][j];
                            ++res;
                        }
                    }
                    else cout<<'S';
                    if(j==n) cout<<endl;
                }
            }
    }
    else{
        for(int i=1;i<=n;++i){
            for(int j=1;j<=n;++j){
                if(i%2==1 and j%2==1) a[i][j]='S';
                else if(i%2==0 and j%2==0)a[i][j]='S';
                else a[i][j]='L';
            }
        }
        l res=0;
            cout<<"YES\n";
            for(int i=1;i<=n;++i){
                for(int j=1;j<=n;++j){
                    if(res<k){
                        if(a[i][j]=='S') cout<<a[i][j];
                        else{
                            cout<<a[i][j];
                            ++res;
                        }
                    }
                    else cout<<'S';
                    if(j==n) cout<<endl;
                }
            }
    }


}

int main(){
    ios_base::sync_with_stdio(false);
    #ifndef ONLINE_JUDGE
       // freopen("1.inp","r",stdin);
    #endif
    input();
    //output();

}
