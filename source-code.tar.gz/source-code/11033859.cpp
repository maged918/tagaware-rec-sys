//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
char sl[111][111];
void ptf(int n)
{
	puts("YES");
	int i,j;
	for(i=0;i<n;i++){for(j=0;j<n;j++)putchar(sl[i][j]);putchar('\n');}
}
int main()
{
	int n,k,i,j,l;
	scanf("%d%d",&n,&k);
	int m=max(n*n/2,n*n-n*n/2);
	if(k>m)puts("NO");
	else
	{
		for(i=0;i<n;i++)for(j=0;j<n;j++)sl[i][j]='S';
		if(k==0){ptf(n);return 0;}
		for(i=0;i<n;i++)
		{
			for(j=(i&1);j<n;j++,j++)
			{
				if(k>0){sl[i][j]='L',k--;
				if(k==0)goto _;}
			}
		}
		_:
		//if(i==0)for(l=j+1;l<n;l++)sl[i][l]='L';
		//else for(l=j+2;l<n;l+=2)sl[i][l]='L';
		//i++;if(i<n){	
		//for(l=(i&1);l<j;l++,l++)sl[i][l]='L';
		//for(l=j;l<n;l++)sl[i][l]='L';	
		//for(i++;i<n;i++)for(l=0;l<n;l++)sl[i][l]='L';}
		ptf(n);
	}
	return 0;
}
