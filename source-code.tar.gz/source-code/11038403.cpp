//Language: GNU C++


// Haters Gonna Hate ....
#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <cstdio>
#include <set>

using namespace std;
typedef long long int ll ;
typedef pair<int,int> pii ;
typedef pair<ll,ll> pll ;
const int maxn  = 1e6 + 13 ;
const int modn  = 1e9 + 7 ;

ll n ,L ,match ;
ll l[maxn] ,lp[maxn] ;
ll sum ;
bool  av[maxn] ;
vector <pll> v ;
ll cnt ;
int main(int argc, char *argv[]) {
    ios::sync_with_stdio(false);
    cin >> n ;
    for (int i = 0 ; i < n ; i++){
        cin >> L ;
        l[L]++;
    }
    for (int i = maxn ; i >= 2 ; i--){
        if ( (l[i]+lp[i])%2 == 1 && l[i] >= 1 ){
            l[i]-- ;
            lp[i-1]++;
        }
    }
    for (int i = maxn ; i >= 2 ; i--){
        ll x = l[i]+lp[i] ;
        if (x >= 2){
            x=x - x%2;
            v.push_back(make_pair(i,x));
            //cout << i << " " << x << endl ;
        }
    }
    for (ll i = 0 ; i < v.size() ; i++)
    {
        if ( cnt > 0 ){
            if ( cnt >= v[i].second ){
                sum += ((v[i].first * match) * cnt) /2 ; 
                cnt -= v[i].second ;
                v[i].second = 0 ;
            }else if ( cnt < v[i].second ){
                sum += ((v[i].first * match) * cnt) /2 ; 
                v[i].second -= cnt ;
                cnt = 0 ;
                sum += (v[i].second/4) * v[i].first * v[i].first ;
                v[i].second %= 4 ;
                cnt = v[i].second ;
                v[i].second = 0 ;
                match = v[i].first ;

            }
            
        }else {
            sum += (v[i].second/4) * v[i].first * v[i].first ;
            v[i].second %= 4 ;
            cnt = v[i].second ;
            v[i].second = 0 ;
            match = v[i].first ;
        }
        //cout << sum << endl;
    }
    cout << sum ;
    return 0;
}




