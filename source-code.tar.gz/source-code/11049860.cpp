//Language: GNU C++11


	//stay hungry stay foolish
#include "bits/stdc++.h"
#define sd(n) scanf("%d", &(n))
#define rep(i, x, n) for (int i = x, _n = (n); i < _n; ++i)
#define repV(i, v) for (i = v.begin(); i != v.end(); i++)
#define SZ(c) (int)(c).size()
#define lcm(a,b) (a*(b/__gcd(a,b)))
#define VI vector<int>
#define all(c) (c).begin(), (c).end()
#define pb push_back
#define mii map<int, int>
#define pii pair<int, int>
#define pip pair<int, pii>
#define F first
#define S second
#define mp make_pair
#define lli long long int
#define CLR(p) memset(p, 0, sizeof(p))
#define SET(p) memset(p, -1, sizeof(p))
#define INF 0x3f3f3f3f
using namespace std;

const int MOD = 1e9+7;
const int MAX = 1000010;

int n, m, ans[MAX];

int main()
{
	sd(n);
	sd(m);

	set<int> alive;
	rep(i, 0, n)
		alive.insert(i);

	int L, R, x;
	rep(i, 0, m)
	{
		sd(L);
		sd(R);
		sd(x);
		L--, R--, x--;

		auto it = alive.lower_bound(L);

		VI toErase;

		while(it != alive.end())
		{
			int cur = *it;
			if(cur > R) break;

			if(cur != x)
			{
				ans[cur] = x+1;
				toErase.pb(cur);
			}
			it++;
		}

		rep(i, 0, SZ(toErase))
			alive.erase(toErase[i]);
	}

	rep(i, 0, n)
		cout << ans[i] << " ";
	cout << endl;
    return 0;
}    
