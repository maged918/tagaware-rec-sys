//Language: GNU C++


#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <math.h>

#define FR(i, a, b)   for(int i = a; i < b; i++)
#define FOR(i, a, b)  for(int i = a; i <= b; i++)
#define LFOR(i, a, b) for(int i = a; i >= b; i--)
#define FRSZ(i, x)    for(int i = 0; i < (int)x.size(); i++)
#define RP(i, n)      for(int i = 0; i < n; i++)
#define repeat        do
#define until(x)      while(!(x))
#define _ve vector
#define _pa pair
#define _tu tuple
#define _mp make_pair
#define _mt make_tuple
#define _pb push_back
#define _fi first
#define _sc second
#define sz(a) ((int)(a).size())

using namespace std;

template <class T> T min3(T a, T b, T c){ return min(a, min(b, c));};
template <class T> T max3(T a, T b, T c){ return max(a, max(b, c));};

typedef long long int64;
typedef unsigned long long qword;
typedef long double ldouble;

void openFile(){freopen("/home/khaihanhdk/devplace/a.inp", "r", stdin);}

int64 calC(int64 x)
{
    return x * (x - 1);
}

int r, s, p;

double res[110][110][110];

int main()
{
    cin >> r >> s >> p;
    res[r][s][p] = 1;
    for(int i = r; i >= 0; i--)
        for(int j = s; j >= 0; j--)
            for(int k = p; k >= 0; k--)
            {
                int64 a = calC(i + j + k) - calC(i) - calC(j) - calC(k);
                if(j > 0 && i > 0)
                    res[i][j - 1][k] +=  2 * i * j * 1.0 / a * res[i][j][k];
                if(k > 0 && j > 0)
                    res[i][j][k - 1] += 2* j * k * 1.0 / a * res[i][j][k];
                if(i > 0 && k > 0)
                    res[i - 1][j][k] += 2 * i * k * 1.0 / a * res[i][j][k];
            }
    double resa = 0;
    for(int i = 1; i <= r; i++)
        resa += res[i][0][0];
    double resb = 0;
    for(int j = 1; j <= s; j++)
        resb += res[0][j][0];
    double resc = 0;
    for(int k = 1; k <= p; k++)
        resc += res[0][0][k];
    printf("%.11lf %.11lf %.11lf", resa, resb, resc);

}
