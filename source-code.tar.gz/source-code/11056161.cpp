//Language: GNU C++11


#include <iostream>

int main()
{
    int cout, cin, n;
    std::cin >> n;
    int string = 0;
    for (int i = 0; i < n; ++i)
    {
        std::cin >> cout >> cin;
        if (cin - cout >= 2) ++string;
    }
    std::cout << string;
}
