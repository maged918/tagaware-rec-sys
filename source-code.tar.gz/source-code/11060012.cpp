//Language: GNU C++


#include<stdio.h>
#include<math.h>
int main()
{
    int n,m,i,j,s,p,b,c;
    double a;
    while(~scanf("%d",&n))
    {
        s=0;
        for(c=1;c<=n;c++)
        {
            for(b=1;b<c;b++)
            {
                p=c*c-b*b;
                a=sqrt(p);
                if(a-(int)a==0.0&&a<=b)
                {
                    s++;
                }
            }
        }
        printf("%d\n",s);
    }
    return 0;
}


                                                    