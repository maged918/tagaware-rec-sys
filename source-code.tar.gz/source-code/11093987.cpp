//Language: GNU C++11


#include <iostream>
#include <algorithm>
#include <string>
#include <map>
#include <set>
#include <cmath>
#include <sstream>
#include<bitset>
#include <fstream>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <queue>	
#include <ctime>
#include <cstring>
using namespace std;
#define ll long long
#define EPS 0.00000001

double dp1[110][110][100], dp2[110][110][110], dp3[110][110][100];
bool c[110][110][110];
int r, s, p;
double solve_r(int i, int j, int k){
	if (j == 0 && k == 0) return 1;
	if (i <= 0 || j < 0 || k < 0) return 0;
	if (c[i][j][k]) return dp1[i][j][k];

	int den = (i * j + i * k + j * k);
	double ans = 0;
	if (j > 0 && i > 0) ans += (double)(i * j) / den  * solve_r(i, j - 1, k);
	if (k > 0 && i > 0) ans += (double)(k * i) / den * solve_r(i - 1, j, k);
	if (j > 0 && k > 0) ans += (double)(j * k) / den * solve_r(i, j, k - 1);
	c[i][j][k] = 1;
	dp1[i][j][k] = ans;
	return ans;
}
double solve_s(int i, int j, int k){
	if (i == 0 && k == 0) return 1;
	if (j <= 0 || i < 0 || k < 0) return 0;
	if (c[i][j][k]) return dp2[i][j][k];
	int den = (i * j + i * k + j * k);
	double ans = 0;
	if (j > 0 && i > 0) ans += (double)(i * j) / den * solve_s(i, j - 1, k);
	if (k > 0 && i > 0) ans += (double)(k * i) / den * solve_s(i - 1, j, k);
	if (j > 0 && k > 0) ans += (double)(j * k) / den * solve_s(i, j, k - 1);
	c[i][j][k] = 1;
	dp2[i][j][k] = ans;
	return ans;
}
double solve_p(int i, int j, int k){
	if (i == 0 && j == 0) return 1;
	if (k <= 0 || i < 0 || j < 0) return 0;
	if (c[i][j][k]) return dp3[i][j][k];
	int den = (i * j + i * k + j * k);

	double ans = 0;
	if (j > 0 && i > 0) ans += (double)(i * j) / den * solve_p(i, j - 1, k);
	if (k > 0 && i > 0) ans += (double)(k * i) / den * solve_p(i - 1, j, k);
	if (j > 0 && k > 0) ans += (double)(j * k) / den * solve_p(i, j, k - 1);
	c[i][j][k] = 1;
	dp3[i][j][k] = ans;
	return ans;
}
int main(){

	cin >> r >> s >> p;

	double r1 = 0, s1 = 0, p1 = 0;

	r1 = solve_r(r, s, p);
	memset(c, 0, sizeof(c));
	s1 = solve_s(r, s, p);
	memset(c, 0, sizeof(c));
	p1 = solve_p(r, s, p);
	cout.precision(15);
	cout << r1 << " " << s1 << " " << p1 << endl;

	cin >> p;

	return 0;
}