//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,d,sum=0,time_gap=0;
    cin>>n>>d;
    time_gap=(n-1)*10;
    int A[n];
    for(int i=0; i<n; i++){
        cin>>A[i];
        sum+=A[i];
    }
    if(sum+time_gap>d)cout<<"-1\n";
    else{
        int jokes=d-sum;
        jokes/=5;
        cout<<jokes<<endl;
    }
    return 0;
}