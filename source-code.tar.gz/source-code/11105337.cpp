//Language: GNU C++11


#include <iostream>
#include <vector>
#include <stdio.h>
#define MAXN 100010

using namespace std;

int N, M, H[MAXN], P[MAXN][20], INDEX[1 << 20], U[MAXN];
vector<int> G[MAXN];
void dfs(int i, int p, int h) {
    H[i] = h;
    P[i][0] = p;
    U[i] = 1;

    for(auto x : G[i]) if (x != p) {
        dfs(x, i, h + 1);
        U[i] += U[x];
    }
}

int getParent(int x, int l) {
    for (int i = 0; i < 20; i++) if ((l & (1 << i)) != 0)
        x = P[x][i];
    return x;
}

int lca(int i, int j) {
    if (H[i] > H[j]) {
        int v = H[i] - H[j];
        return lca(getParent(i, v), j);
    }

    if (H[j] > H[i]) {
        int v = H[j] - H[i];
        return lca(i, getParent(j, v));
    }

    if (i == j) return i;
    if (P[i][0] == P[j][0]) return P[i][0];

    for(int p = 19; p >= 0; p--)
        if (P[i][p] != -1 && P[j][p] != -1 && P[i][p] != P[j][p]) {
            return lca(P[i][p], P[j][p]);
        }
}
int main() {
    for(int i = 0; i < 20; i++)
        INDEX[1 << i] = i;

    cin >> N;
    for(int i = 0; i < N - 1; i++) {
        int a, b;
        cin >> a >> b;
        a--; b--;

        G[a].push_back(b);
        G[b].push_back(a);
    }

    dfs(0, -1, 0);

    for(int l = 1; l < 20; l++)
    for(int i = 0; i < N; i++)
        P[i][l] = P[i][l - 1] == -1 ? -1 : P[P[i][l - 1]][l - 1];

    cin >> M;
    for(int i = 0; i < M; i++) {
        int x, y;
        cin >> x >> y;
        x--; y--;

        int c = lca(x, y);
        int dist = H[x] + H[y] - 2 * H[c] - 1;

        int ans = 0;
        if (x == y) {
            ans = N;
        } else if (dist % 2 != 0) {
            if (H[x] == H[y]) {
                int hd = dist / 2;
                ans = N - U[getParent(x, hd)] - U[getParent(y, hd)];
            } else {
                int hd = dist / 2;
                if (H[x] > H[y]) {
                    ans = U[getParent(x, hd + 1)] - U[getParent(x, hd)];
                } else {
                    ans = U[getParent(y, hd + 1)] - U[getParent(y, hd)];
                }
            }
        }

        printf("%d\n", ans);
    }
    return 0;
}
