//Language: GNU C++11


#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <map>
#include <stack>
#include <vector>
#include <memory.h>
#include <set>
#include <list>
#include <string>
#include <math.h>
#include <time.h>
using namespace std;
vector <int> son[5005];
int a[100005];
int n, q;
struct Node{
	int lf, rg;
	double p;
};
Node seg[5005];
int cmp(Node a,Node b){
	if (a.lf != b.lf)
		return a.lf < b.lf;
	else
		return a.rg > b.rg;
}
int build(int k,int f){
	while (true)
	{
		if (k == q)
			return q;
		if (seg[k].rg>seg[f].rg)
			return k;
		son[f].push_back(k);
		k = build(k + 1, k);
	}
}
struct Line{
	int from;
	vector <double> p;
};
void f(int k, Line &res){
	int tlen = son[k].size();
	Line temp1,temp2;
	res.from = 0;
	for (int i = seg[k].lf; i <= seg[k].rg; ++i)
		res.from = max(res.from, a[i]);
	res.p.clear();
	res.p.push_back(1);

	for (int t = 0; t < tlen; ++t){
		f(son[k][t], temp1);
		swap(temp2, res);
		res.from = max(temp1.from, temp2.from);
		res.p.clear();
		int to1 = temp1.from -1+ temp1.p.size();
		int to2 = temp2.from -1+ temp2.p.size();
		for (int i = res.from;i<=max(to1,to2); ++i){
			double s = 1;
			if (i <= to1)
				s *= temp1.p[i - temp1.from];
			if (i <= to2)
				s *= temp2.p[i - temp2.from];
			res.p.push_back(s);
		}
	}
	int len = res.p.size();
	res.p.push_back(1);
	for (int i = len - 1; i > 0; --i){
		res.p[i] -= (res.p[i] - res.p[i - 1])*seg[k].p;
	}
	res.p[0] -= res.p[0] * seg[k].p;
	return;
}
int main(){
	//freopen("abc.txt", "r", stdin);
	cin >> n >> q;
	for (int i = 1; i <= n; ++i)
		scanf("%d", a + i);
	for (int i = 0; i < q; ++i)
		scanf("%d%d%lf", &seg[i].lf, &seg[i].rg, &seg[i].p);
	sort(seg, seg + q, cmp);
	seg[q].lf = 1;
	seg[q].rg = n;
	seg[q].p = 0;
	build(0, q);
	Line res;
	f(q, res);
	int len = res.p.size();
	double sum=0;
	sum = res.p[0] * res.from;
	for (int i = 1; i < len; ++i){
		sum += (res.p[i] - res.p[i - 1])*(i + res.from);
	}
	printf("%.12llf\n", sum);
	return 0;
}