//Language: GNU C++11


#include <bits/stdc++.h>
#include <unordered_map>
#define all(t) (t).begin(),(t).end()
#define CLR(a) memset((a),0,sizeof(a))
#define pb push_back
#define pf push_front
#define mp make_pair
using namespace std;
typedef long long LL;
typedef pair<int,int> pii;
typedef pair<LL,LL> pLL;
typedef map<int,int> mii;
typedef map<LL,LL> mLL;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vLL;
typedef vector<vLL> vvLL;

int main(){
    int k,i,j;
    string s;
    cin>>k>>s;
    vi toda;
    vector<string> vs(k);
    if(k==1){
        cout<<"YES\n"<<s; return 0;
    }
    if(k>s.size()){
        cout<<"NO";return 0;
    }
    int cnt=1;
    vector<int> b(26, 0);
    b[s[0]-'a']=1;
    for(i=1;i<s.size();i++){
        if(s[i]!=s[i-1] && b[s[i]-'a']==0){
            b[s[i]-'a']=1;
            cnt++;
            toda.push_back(i);
            if(cnt==k){
                break;
            }
        }
    }
    if(cnt!=k){cout<<"NO";return(0);}
    cout<<"YES\n";
    for(j=0;j<toda[0];j++){
        cout<<s[j];
    }cout<<endl;
    for(i=1;i<toda.size();i++){
        for(j=toda[i-1];j<toda[i];j++){
            cout<<s[j];
        }cout<<endl;
    }if(j!=s.size()){
    for( ;j<s.size();j++){
        cout<<s[j];
    }cout<<endl;}
    return 0;
}





