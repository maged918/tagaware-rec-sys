//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

const int MAX = 100000;

vector <int> adj[MAX];
int n, m, p[MAX][21], Size[MAX], d[MAX];

void DFS(int u, int par)
{
    Size[u] = 1;
    for (vector <int> :: iterator i = adj[u].begin(); i != adj[u].end(); i++)
    {
        if (*i == par) continue;
        d[*i] = d[u] + 1;
        p[*i][0] = u;
        DFS(*i, u);
        Size[u] += Size[*i];
    }
}

void Init()
{
    DFS(0, -1);
    for (int j = 1; j <= 20; j++)
        for (int i = 0; i < n; i++)
            p[i][j] = p[p[i][j - 1]][j - 1];
}

int LCA(int u, int v)
{
    if (d[u] < d[v]) return LCA(v, u);
    int ans = d[u] - d[v];
    for (int i = 20; i >= 0; i--)
        if ((ans >> i) & 1) u = p[u][i];

    if (u == v) return u;
    for (int i = 20; i >= 0; i--)
        if (p[u][i] == p[v][i]) ans = p[u][i];
        else u = p[u][i], v = p[v][i];
    return ans;
}

int parent(int u, int k)
{
    for (int i = 20; i >= 0; i--)
        if ((k >> i) & 1) u = p[u][i];
    return u;
}

int Dist(int u, int v)
{
    int par = LCA(u, v);
    return d[u] + d[v] - 2*d[par];
}

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n - 1; i++)
    {
        int u, v;
        scanf("%d %d", &u, &v);
        u--; v--;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    Init();

    scanf("%d", &m);
    while (m--)
    {
        int u, v;
        scanf("%d %d", &u, &v);
        u--; v--;
        if (d[u] < d[v]) swap(u, v);
        int par = LCA(u, v), dist = Dist(u, v);;
        if (u == v) printf("%d\n", n);
        else if (dist & 1) printf("%d\n", 0);
        else if (Dist(u, par) == Dist(v, par))
        {
            int paru = parent(u, Dist(u, par) - 1);
            int parv = parent(v, Dist(v, par) - 1);
            printf("%d\n", n - Size[paru] - Size[parv]);
        }
        else
        {
            int paru = parent(u, dist >> 1);
            int parv = parent(u, (dist >> 1) - 1);
            printf("%d\n", Size[paru] - Size[parv]);
        }
    }
}
