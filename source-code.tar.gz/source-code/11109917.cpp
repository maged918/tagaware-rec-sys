//Language: MS C++


#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <algorithm>

using namespace std;


int main(){
	//ifstream cin("input.txt");
	//ofstream cout("output.txt");

	int n, m;
	cin >> n;
	m = n;
	unsigned int** arr = new unsigned int*[3];
	for(int i = 0; i < 3; i++){
		arr[i] = new unsigned int[m];
		for(int j = 0; j < m; j ++){
			cin >> arr[i][j];
		}
		sort(arr[i], arr[i] + m);
		m--;
	}

	/*m = n;
	for(int i = 0; i < 3; i++){
		for(int j = 0; j < m; j ++){
			cout << arr[i][j] << ' ';
		}
		cout << endl;
		m--;
	}*/
	
	bool f =false;
	for(int i = 0; i < n - 1; i++){
		if(arr[0][i] != arr[1][i]){
			cout << arr[0][i] << endl;
			f = true;
			break;
		}
	}
	if(!f){
		cout << arr[0][n - 1] << endl;
	}
	f = false;
	for(int i = 0; i < n - 2; i++){
		if(arr[1][i] != arr[2][i]){
			cout << arr[1][i] << endl;
			f = true;
			break;
		}
	}
	if(!f){
		cout << arr[1][n - 2] << endl;
	}

	//cin.close();
	//cout.close();
	return 0;
}
