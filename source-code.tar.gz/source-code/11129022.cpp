//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

#define  sz(s) ((int)s.size())

class HASH{
private:
    vector<long long> p;
    vector<long long>prefixHash;
    vector<long long>sufixHash;
    int n;
    long long a,mod;
    string s;
public:
    HASH(int n,long long a,long long mod,string s){
        this->n=n;
        this->a=a;
        this->mod=mod;
        this->s=s;
        calc_p();
        calc_Hash();
    }
    void calc_p(){
        p.resize(n);
        p[0] = 1;
        for(int i=1;i<n;i++){
            p[i] = p[i-1] * a ;
            p[i] %= mod;
        }
    }
    void calc_Hash(){
        long long ans = 0;
        for(int i=0;i<sz(s);i++){
            ans *= a;
            ans += s[i];
            ans %= mod;
            prefixHash.push_back(ans);
        }
        for(int i=0;i<sz(s);i++){
            sufixHash.push_back(ans);
            long long po = p[s.size()-i-1];
            ans = ans - po*s[i] ;
            while(ans < 0)ans += mod;
            ans %=mod;
        }
    }
    long long get_sufix(int idx){
        return sufixHash[idx];
    }
    long long get_prefix(int idx){
        return prefixHash[idx];
    }
};


bool built_S(const vector<int>&vec,string & s,const string &p ){
    HASH h1 = HASH(s.size(),4,1000000009,p);
    HASH h2 = HASH(s.size(),100007,1000000007,p);
    int pos = 0;
    for(int i=0;i<sz(vec);i++){

        if(pos <= vec[i]){
            pos = vec[i];
            for(int id=0;pos < sz(s) and id<sz(p);id++){
                s[pos++] = p[id];
            }
            if(pos >= sz(s))break;
        }else{
            if(pos >= sz(s))break;
            int len = pos - vec[i] ;
            long long old = h1.get_sufix(sz(p)-len);
            long long nw  = h1.get_prefix(len-1);
            bool ok = 0;
            if(old == nw){
                ok = 1;
                old = h2.get_sufix(sz(p)-len);
                nw  = h2.get_prefix(len-1);
                if(old == nw){
                    ok = 1;
                }
            }
            if(ok == 0)return 0;
            for(int id=len;pos < sz(s) and id<(sz(p));id++){
                s[pos++] = p[id];
            }
        }

    }
    return 1;
}

int main(){

    int n,m;
    string p,s;
    vector<int> vec;
    cin>>n>>m;
    cin>>p;
    vec.resize(m);
    s.resize(n,'?');
    for(int i=0;i<m;i++){
        cin>>vec[i];
        vec[i]--;
    }

    sort(vec.begin() , vec.end());
    if(built_S(vec,s,p)){

        int cnt = 0;
        for(int i=0;i<sz(s);i++){
            cnt+=(s[i]=='?');
        }

        long long ans = 1;
        while(cnt--){
            ans *= 26;
            ans %= 1000000007;
        }
        cout<<ans<<endl;
    }else{
        puts("0");
    }

}
