//Language: GNU C++


#include<iostream>
using namespace std;
int main()
{
    int k;
    cin>>k;
    string str;
    cin>>str;
    int arr[k],dist[26];
    
    int len = str.length();
    char prev = str[0];
    k--;
    int cnt = 0;
    arr[0] = 0;
     int y;
     for (int i = 0 ; i < 26 ; i++)
        dist[i] = 0;
  
     y = prev-'a';
        dist[y] = 1;
          for (int i = 1 ; i < len ; i++)
    {
        char b;
        b = str[i];
        int x;
        x = b-'a';
        if (dist[x]==0 && k!=0)
        {
           cnt++;
           arr[cnt] = i;
           prev = b;
           k--;
           dist[x] = 1;
        }
        else
        {
           arr[cnt]++; 
        }
    }
    
    if (k==0)
    {
       cout<<"YES"<<endl;
       int end;
       int st = 0;
       for (int i = 0 ; i <= cnt ; i++)
       {
           end = arr[i];
           for (int j = st ; j <= end ; j++)
           {
               char b;
               b = str[j];
               cout<<b;
           }
           st = end+1;
           cout<<endl;
       }
    }
    else
    cout<<"NO"<<endl;
    //cin>>k;
    return 0;
}
