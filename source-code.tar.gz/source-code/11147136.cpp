//Language: MS C++


#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;

bool was[1111];

int main()
{
    //freopen("input.in", "r", stdin);
    //freopen("output.out", "w", stdout);
    int n;
    cin >> n;
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            int a;
            cin >> a;
            if(a == 1 || a == 3)
                was[i] = true;
        }
    }
    int ans = 0;
    for(int i = 0; i < n; i++)
    {
        if(!was[i])
            ans++;
    }
    cout << ans << "\n";
    for(int i = 0; i < n; i++)
    {
        if(!was[i])
            cout << i + 1 << " ";
    }
    return 0;
}