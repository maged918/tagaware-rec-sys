//Language: GNU C++


#include<cstdio>
#include<algorithm>
#include<vector>
#include<utility>
#include<queue>
#define ll long long
#define pi pair<int,long long>
using namespace std;
const int max_n = 300300;
int n,m,k;
int x,y;
int edge[max_n][3];
long long z;
bool chk[max_n], done[max_n];
struct data {
    int x,num;
    ll val;
    data() {
    }
    data(int x_,ll val_,int num_) {
        x = x_, val = val_, num = num_;
    }
};
priority_queue<data> pq;
vector<data> v[max_n];
bool operator <(data a,data b) {
    if(a.val == b.val) {
        if(chk[a.num] || chk[b.num]) {
            if(chk[a.num]) return false;
            return true;
        }
        return edge[a.num][2] > edge[b.num][2];
    }
    return a.val > b.val;
}
void input() {
    scanf("%d %d",&n,&m);
    for(int i=1;i<=m;i++) {
        scanf("%d %d %lld",&x,&y,&z);
        v[x].push_back(data(y,z,i));
        v[y].push_back(data(x,z,i));
        edge[i][0] = x, edge[i][1] = y, edge[i][2] = (int)z;
    }
    scanf("%d",&k);
    return;
}
void solve() {
    pq.push(data(k,0,0));
    int ct = 0;
    while(ct < n) {
        data t = pq.top();
        pq.pop();
        if(done[t.x] == false) {
            
        ct++;
        done[t.x] = true;
        chk[t.num] = true;
        for(int i=0;i<v[t.x].size();i++) {
            if(done[v[t.x][i].x] == true) continue;
            int next = v[t.x][i].x;
            ll price = v[t.x][i].val;
            int tag = v[t.x][i].num;
            pq.push(data(next, t.val + price, tag));
        }
            
        }
    }
    ll ans = 0;
    for(int i=1;i<=n;i++) {
        for(int j=0;j<v[i].size();j++) {
            if(chk[v[i][j].num]) {
                ans += v[i][j].val;
            }
        }
    }
    printf("%I64d\n",ans/2);
    for(int i=1;i<=n;i++) {
        for(int j=0;j<v[i].size();j++) {
            if(chk[v[i][j].num]) {
                chk[v[i][j].num] = false;
                printf("%d ",v[i][j].num);
            }
        }
    }
}

int main() {
    input();
    solve();
    return 0;
}