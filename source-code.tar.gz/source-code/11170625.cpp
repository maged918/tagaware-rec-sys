//Language: GNU C++11


#include <iostream>
#include <ios>
#include <vector>
#include <cstdio>
#include <string>
#include <queue>
#include <algorithm>
#include <set>

typedef unsigned long long ulong;
typedef unsigned long long ullong;

using namespace std;

struct Edge
{
	Edge(ulong v, ulong l, ulong id): v(v), l(l), id(id) {}
	ulong v, l, id;
};

struct Que
{
	Que(ulong d, ulong v): d(d), v(v) {}
	ulong d, v;
};

struct QueCompare
{
	bool operator()(const Que &q1, const Que &q2)
	{
		return q1.d > q2.d;
	}
};

int main()
{

	ios::sync_with_stdio(false);
	//freopen("in.txt", "r", stdin); //freopen("out.txt", "w", stdout);

	int n, m, s;
	cin >> n >> m;
	vector < vector <Edge> > g(n, vector<Edge>());
	vector<ulong> wvec(m);
	for(int i=0; i<m; i++) {
		int ui, vi, wi;
		cin >> ui >> vi >> wi;
		ui--; vi--;
		g[ui].push_back(Edge(vi, wi, i));
		g[vi].push_back(Edge(ui, wi, i));
		wvec[i] = wi;
	}
	cin >> s; s--;

	vector<bool> sel(m, false);

	vector<ullong> d(n, -1);
	vector<ulong>  p(n, -1);
	d[s] = 0;
	p[s] = s;

	priority_queue< Que, vector<Que>, QueCompare > q;

	q.push (Que(0, s));
	while (!q.empty())
	{
		ulong v = q.top().v, cur_d = q.top().d;
		q.pop();
		if (cur_d > d[v]) continue;

		Edge best(-1, -1, -1);
		for (auto e : g[v]) {
			sel[e.id] = false;
			if(d[e.v] != -1 && d[e.v] + e.l == d[v] && e.l < best.l) {
				best = e;
			}
		}
		if (best.id != -1) sel[best.id] = true;

		for (size_t j=0; j < g[v].size(); ++j)
		{
			int to = g[v][j].v, len = g[v][j].l;
			if (d[v] + len < d[to]) {
				d[to] = d[v] + len;
				p[to] = v;
				q.push (Que(d[to], to));
			}
		}
	}

	ullong totalw = 0;
	for (int i=0; i<m; ++i) {
		if(sel[i]) totalw += wvec[i];
	}
	cout << totalw << '\n';
	for (int i=0; i<m; ++i) {
		if(sel[i]) cout << i+1 << ' ';
	}
	cout << '\n';
	return 0;
}


