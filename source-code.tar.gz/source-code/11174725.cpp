//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <queue>
#include <algorithm>
#define LL long long
using namespace std;
const int maxn=3e5+10;
const LL inf=1e18;

struct t
{
    LL from,to,v,num,cnt;
    bool operator < (const t& a) const{
        return v==a.v?cnt<a.cnt:v>a.v;
    };
};

vector<t> a[maxn];
priority_queue<t> pq;
LL m,n,d[maxn],w[maxn],ans[maxn],ce[maxn];
bool visit[maxn],visitb[maxn];
LL sum=0,cnt=0;

void dijkstra(int k)
{
    LL i,j;
    memset(ce,0,sizeof(ce));
    memset(visit,0,sizeof(visit));
    while(!pq.empty()) pq.pop();
    for(i=1;i<=n;i++)   d[i]=inf;
    d[k]=0;
    visit[k]=true;
    int from=k;
    for(i=1;i<=n;i++)
    {
        for(j=0;j<a[from].size();j++)
            if(!visit[a[from][j].to])
                pq.push( (t){from,a[from][j].to,d[from]+a[from][j].v,a[from][j].num,ce[from]});
        t e=(t){-1,-1,0,0,0};
        while(!pq.empty())
        {
            e=pq.top(); pq.pop();
            if(!visit[e.to] && !visitb[e.num]) break;
        }
        if(e.from==-1 || e.to==-1) break;
        if(!visit[e.to] )
        {
            ce[e.to]=ce[from]+1;
            from=e.to;
            d[from]=e.v;
            visit[from]=true;
            ans[cnt++]=e.num;
            sum+=w[e.num];
        }
    }
}

int main()
{
    LL i,k;
    scanf("%I64d%I64d",&n,&m);
    for(i=0;i<m;i++)
    {
        LL x,y;
        scanf("%I64d%I64d%I64d",&x,&y,&w[i+1]);
        a[x].push_back( (t){x,y,w[i+1],i+1,0});
        a[y].push_back( (t){y,x,w[i+1],i+1,0});
    }
    scanf("%I64d",&k);
    dijkstra(k);
    printf("%I64d\n",sum);
    for(i=0;i<cnt;i++)
            printf("%I64d ",ans[i]);
    return 0;
}
