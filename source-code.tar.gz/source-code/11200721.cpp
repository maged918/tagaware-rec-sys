//Language: GNU C++


#include <algorithm>
#include <functional>
#include <numeric>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <bitset>
#include <sstream>
using namespace std;

int main()
{
    int n=0,k=0;
    cin>>n;
    cin>>k;
    if((n%2==0 && k<=(n*n)/2)  )
    {
        cout<<"YES"<<endl;
        int turn_i=0,turn_j=0,count=0;
        for(int i=0;i<n;i++)
        {
            if(turn_i==0)
            {
                for(int j=0;j<n;j++)
                {
                    if(turn_j==0)
                    {
                        if(count<k)
                        {
                            cout<<"L";
                            count++;
                            turn_j=1;

                        }
                        else
                        {
                            cout<<"S";
                        }

                    }
                    else if(turn_j==1)
                    {
                        cout<<"S";
                        turn_j=0;
                    }
                }
                turn_i=1;
                turn_j=0;
        }

        else if(turn_i==1)
        {
            for(int j=0;j<n;j++)
                {
                    if(turn_j==1)
                    {
                        if(count<k)
                        {
                            cout<<"L";
                            count++;
                            turn_j=0;



                        }
                        else
                        {
                            cout<<"S";
                        }

                    }
                    else if(turn_j==0)
                    {
                        cout<<"S";
                        turn_j=1;
                    }
                }
                turn_i=0;
                turn_j=0;
        }
        cout<<endl;
    }

    }
    else if(((n+1)%2==0) && k<=((n*n)/2)+1)
        {
        cout<<"YES"<<endl;
        int turn_i=0,turn_j=0,count=0;
        for(int i=0;i<n;i++)
        {
            if(turn_i==0)
            {
                for(int j=0;j<n;j++)
                {
                    if(turn_j==0)
                    {
                        if(count<k)
                        {
                            cout<<"L";
                            count++;
                            turn_j=1;

                        }
                        else
                        {
                            cout<<"S";
                        }

                    }
                    else if(turn_j==1)
                    {
                        cout<<"S";
                        turn_j=0;
                    }
                }
                turn_i=1;
                turn_j=0;
        }

        else if(turn_i==1)
        {
            for(int j=0;j<n;j++)
                {
                    if(turn_j==1)
                    {
                        if(count<k)
                        {
                            cout<<"L";
                            count++;
                            turn_j=0;



                        }
                        else
                        {
                            cout<<"S";
                        }

                    }
                    else if(turn_j==0)
                    {
                        cout<<"S";
                        turn_j=1;
                    }
                }
                turn_i=0;
                turn_j=0;
        }
        cout<<endl;
    }

    }
    else
    {
        cout<<"NO"<<endl;
    }

}
