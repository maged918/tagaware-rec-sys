//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
int main()
{
    long long int k,n,w,ans;
    cin>>k>>n>>w;
    ans=(k*(w*(w+1)/2));
    if(ans<n)cout<<0<<endl;
    else cout<<ans-n<<endl;
}
