//Language: GNU C++


#include <bits/stdc++.h>
#define  mem(x, v)      memset(x, v, sizeof(x))
#define  pb             push_back
#define  mp             make_pair
#define  elif           else if
#define  INF            0x3fffffffffffffff
#define  read(x, n)     for ( int i = 0; i < n; i++ ) cin >> x[i]
#define  debug(x, n)    for ( int i = 0; i < n; i++ ) cout <<  x[i] << ' '
#define  min3(a, b, c)  min((a), min((b), (c)))
#define  MOD            1000000007LL
#define  MAX            3005

using namespace std;
typedef long long ll;
typedef vector<vector<pair<int, int> > > graph;

int a[MAX];

int main ( ) {
    cin.tie(0);
    ios_base::sync_with_stdio(0);

    int n;
    cin >> n;
    read(a, n);

    sort(a, a + n);
    int ans = 0;
    for ( int i = 1; i < n; ++i )
        if ( a[i] <= a[i - 1] ) {
            ans += a[i - 1] - a[i] + 1;
            a[i] = a[i - 1] + 1;
        }

    cout << ans;
}
