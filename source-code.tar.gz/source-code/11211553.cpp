//Language: GNU C++11


#include <bits/stdc++.h>
/*#include <boost/multiprecision/cpp_int.hpp> */
#define ll long long
#define pb push_back
#define mp make_pair
#define mod 1000000007
#define gc getchar_unlocked
#define pp pair<int,int>
#define bigint boost::multiprecision::cpp_int
#define PLIM 68000000
using namespace std;


vector<int> arr;
int n;

int main()
{
cin>>n;
for(int i=0;i<n;i++)
{
    int val;
    cin>>val;
    arr.pb(val);
}

sort(arr.begin(),arr.end());

ll ans=0;

for(int i=1;i<n;i++)
{
    if(arr[i]<=arr[i-1])
    {
        ans+=1 + arr[i-1]-arr[i];
        arr[i]=arr[i-1]+1;
    }
}
cout<<ans;

return 0;
}