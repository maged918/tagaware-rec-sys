//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
#define pb push_back



int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(nullptr);
    int n;
    cin>>n;
    int k1,k2;
    cin>>k1;
    queue<int> q1,q2;
    for(int i=0;i<k1;i++){
            int x; cin>>x;
        q1.push(x);
    }
    cin>>k2;
    for(int i=0;i<k2;i++){
        int x;cin>>x;
        q2.push(x);
    }
    int e1,e2;
    for(int i=0;i<1000000;i++){
        if (q1.empty()){
            cout<<i<<" "<<2;
            exit(0);
        }
        if(q2.empty()){
            cout<<i<<" "<<1;
            exit(0);
        }
        e1=q1.front();q1.pop();
        e2=q2.front();q2.pop();
        if (e1>e2){
            q1.push(e2);
            q1.push(e1);
        }
        else{
            q2.push(e1);
            q2.push(e2);
        }
    }
    cout<<-1;
    return 0;
}
