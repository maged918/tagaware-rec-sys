//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
const int n = 333;
int f[n][n], sink, source, c[n][n];
vector<char> used;


char dfs(int v = source) {
	used[v] = true;

	if (v == sink) {
		return true;
	}

	for (int to = 0; to <= sink; to++)
		if (!used[to] && f[v][to] > 0 && dfs(to)) {
			f[v][to]--;
			f[to][v]++;
			return true;
		}

	return false;
}


int nextInt() {
	char c = getchar();
	int x = 0;

	while (!isdigit(c)) {
		c = getchar();
	}

	while (isdigit(c)) {
		x = x * 10 + c - '0';
		c = getchar();
	}

	return x;
}


main() {
#ifndef ONLINE_JUDGE
	freopen("1.txt", "r", stdin);
#endif // ONLINE_JUDGE

	int n = nextInt(), m = nextInt();
	source = 0;
	sink = 2 * n + 1;
	vector<int> e[n];

	vector<int> a(n), b(n);

	for (int i = 0; i < n; i++) {
		a[i] = nextInt();
		f[source][i + 1] = a[i];
	}

	for (int i = 0; i < n; i++) {
		b[i] = nextInt();
		f[n + i + 1][sink] = b[i];
	}

	while (m--) {
		int x = nextInt(), y = nextInt();
		x--; y--;
		e[x].push_back(y);
		e[y].push_back(x);
	}

	for (int v = 0; v < n; v++) {
		f[v + 1][n + v + 1] = a[v];

		for (int to : e[v]) {
			f[v + 1][n + to + 1] = a[v];
		}
	}

	while (1) {
		used.assign(sink + 1, false);

		if (!dfs()) {
			break;
		}
	}

	char ok = true;

	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++) {
			c[i][j] = f[n + j + 1][i + 1];
		}

	for (int i = 0; i < n; i++) {
		int sum = 0;

		for (int j = 0; j < n; j++) {
			sum += c[i][j];
		}

		if (sum != a[i]) {
			ok = false;
		}

		sum = 0;

		for (int j = 0; j < n; j++) {
			sum += c[j][i];
		}

		if (sum != b[i]) {
			ok = false;
		}
	}

	if (!ok) {
		printf("NO");
		return 0;
	}

	printf("YES");

	for (int i = 0; i < n; i++) {
		printf("\n");

		for (int j = 0; j < n; j++) {
			printf("%d ", c[i][j]);
		}
	}

	/*for (int i = 0; i <= sink; i++)
		for (int j = i + 1; j <= sink; j++)
			if (f[j][i]) {
				printf("%d %d : %d\n", i, j, f[j][i]);
			}*/

}
