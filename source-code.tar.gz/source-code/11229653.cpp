//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

int n, k, c, t;
queue<int> playerA, playerB;

int main()
{
	scanf("%d", &n);
	
	scanf("%d", &k);
	for (int i=0; i<k; i++)
		scanf("%d", &c), playerA.push(c);

	scanf("%d", &k);
	for (int i=0; i<k; i++)
		scanf("%d", &c), playerB.push(c);

    
    t = 0;
    while (t < 2*(n*(n+1)/2))
    {
    	if (playerA.empty()) {
    		printf("%d %d\n", t, 2);
    		return 0;
    	}
    	
    	if (playerB.empty()) {
    		printf("%d %d\n", t, 1);
    		return 0;
    	}
    	
    	int card_A = playerA.front(); playerA.pop();
    	int card_B = playerB.front(); playerB.pop();
    	
    	if (card_A > card_B) {
    	    playerA.push(card_B);
			playerA.push(card_A);	
    	} else {
    		playerB.push(card_A);
			playerB.push(card_B);
    	}
    	
    	t++;
    }
	
	printf("-1\n");
	
	return 0;
}
