//Language: MS C++


#include <iostream>
#include <cstdio>
#include<cstdlib>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<vector>
#include<iomanip>
#include<queue>
using namespace std;
#define inf 0x3f3f3f3f
int a,b;
int t;
long long dp[5000100],sum[5000100];
int pr[100000];
int main()
{
	scanf("%d",&t);
	int k=1;
	pr[0]=2;
	for(int i=3;i<=2500;i+=2)
	{
		int flag=0;
		for(int j=2;j<=sqrt(double(i));j++)
			if(i%j==0)
			{
				flag=1;
				break;
			}
		if(flag==0)
			pr[k++]=i;
	}
	
	dp[2]=1;
	sum[1]=0;
	sum[2]=1;
	for(int i=3;i<=5000000;i++)
	{
		if(i%2==0)
			dp[i]=dp[i/2]+1;
		else
		{
			dp[i]=1;
			for(int j=0;j<k;j++)
			{
				if(i%pr[j]==0)
				{
					dp[i]=1+dp[i/pr[j]];
					break;
				}
			}
		}
		sum[i]=sum[i-1]+dp[i];
	}
	while(t--)
	{
		scanf("%d%d",&a,&b);
		/*for(int i=0;i<k;i++)
		{

		}*/
		printf("%I64d\n",sum[a]-sum[b]);
	}
}