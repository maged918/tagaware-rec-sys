//Language: GNU C++11


#include<algorithm>
#include <cstdio>
int a[1010];
int b[1010];
int main() {
	int n, k, p, x, y;
	scanf("%d%d%d%d%d", &n, &k, &p, &x, &y);
	for (int i = 0; i < k; ++i) scanf("%d", a + i);
if (y == 1) {
	for (int i = k; i < n; ++i) b[i] = a[i] = 1;
} else {
	int sum = 0;
for (int i = 0; i < k; ++i) sum+= a[i];
sum = x - sum;
sum -= n - k;
int cnt = sum / (y - 1);
for (int i = k; i < n; ++i) {
	if (sum >= y - 1)b[i] =  a[i] = y ; else b[i] =  a[i] =1;
sum -= a[i] - 1;
}
}
std::sort(a, a + n);
int m = a[n / 2];

int sum = 0; for (int i = 0; i < n; ++i) sum += a[i];

	if (m < y|| sum > x) { puts("-1"); return 0;}
for (int i = 0; i< n - k; ++i) printf("%d ", b[i + k]);
}
