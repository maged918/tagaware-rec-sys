//Language: GNU C++


#include <bits/stdc++.h>

using namespace std ;

int n , a[3333] , ans ;

int main()
{
    ios::sync_with_stdio(0) ;

    cin >> n ;

    for ( int i = 0 ; i < n ; i ++ )
        cin >> a[i] ;
    sort ( a, a + n) ;

    for ( int i = 1 ; i < n ; i ++ ){
        if ( a[i] <= a[i - 1] ){
            ans += a[i - 1] - a[i] + 1 ;
            a[i] = a[i - 1] + 1 ;
        }
    }

    cout << ans ;
}
