//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<cctype>
#include<climits>
#include<iostream>
#include<algorithm>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<complex>
#include<bitset>

using namespace std;

const int INF = 0x3f3f3f3f;
const double EPS = 1e-7;
const double PI = 3.1415926535897932384626433832795;

typedef long long LL;
typedef unsigned long long ull;
typedef unsigned int uint;
typedef pair<int, int> pii;

#define rep(i, x) for(int i = 0; i < (int)(x); i++)

inline int get_int() {
    int res, t = 1; char c;
    while(!isdigit(c = getchar())) if(c == '-') t = -1;
    for(res = c - '0'; isdigit(c = getchar()); )
        res = res * 10 + c - '0';
    return res * t;
}

const int MAXN = 200000;

int n;
vector<int> A[MAXN + 10];
vector<int> ans;

int main()  {

    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
        int t;
        scanf("%d", &t);
        A[t].push_back(i);
    }

    int cnt = 0;
    for(int i = 1; i <= n; i++) {
        while(!A[cnt].size()) {
            cnt -= 3;
            if(cnt < 0) {
                puts("Impossible");
                return 0;
            }
        }
        ans.push_back(A[cnt].back());
        A[cnt].pop_back();
        cnt++;
    }

    puts("Possible");
    for(int i = 0; i < n; i++) {
        printf(i == 0 ? "%d" : " %d", ans[i]);
    }

    return 0;
}

   		   	 	    	 	  	 	  	   	