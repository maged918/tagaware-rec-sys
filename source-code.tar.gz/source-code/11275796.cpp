//Language: MS C++


#include <cstdlib>
#include <iostream>
#include <set>
#include <string>

using namespace std;

int main(int argc, char *argv[])
{int k; string q;
 cin>>k>>q;
 int i,N=q.size(),j;
 set<int>V; set<char>W; V.insert(0); W.insert(q[0]);
 for(i=j=1;i<N && j<k;i++)
   if(W.count(q[i]));
   else {
         V.insert(i); W.insert(q[i]);
         j++;
        }
   if(j<k)cout<<"NO";
   else
   {   cout<<"YES"<<endl;
       cout<<q[0];
       for(i=1;i<N;i++)
         {if(V.count(i))cout<<endl;
          cout<<q[i];
          }
   }
 //   system("PAUSE");
    return EXIT_SUCCESS;
}