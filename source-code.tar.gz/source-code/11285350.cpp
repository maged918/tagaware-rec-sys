//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,m,q,x,y,sol,a[505][505],L[505];
void calcul(int linie)
{
    int i,Max=0,p=1,u=0;
    for (i=1;i<=m;++i)
        if (a[linie][i]==1) ++u;
        else{
            if (u-p+1>Max) Max=u-p+1;
            p=i+1, u=i;
        }
    if (u-p+1>Max) Max=u-p+1;
    L[linie]=Max;
}
int main()
{
    int i,j;
//    freopen("date.in","r",stdin);
//    freopen("date.out","w",stdout);
    cin>>n>>m>>q;
    for (i=1;i<=n;++i)
        for (j=1;j<=m;++j)
            cin>>a[i][j];
    for (i=1;i<=n;++i)
        calcul(i);
    for (i=1;i<=q;++i)
    {
        cin>>x>>y;
        a[x][y]=1-a[x][y];
        calcul(x);
        sol=0;
        for (j=1;j<=n;++j)
            sol=max(sol,L[j]);
        cout<<sol<<"\n";
    }
    return 0;
}
