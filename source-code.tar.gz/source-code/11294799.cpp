//Language: GNU C++11


//============================================================================
// Name        : Contest
// Author      : The Assassin
// Version     : V.1
// Copyright   : Belong to the Brotherhood
// Description : By the way of The Assassins ISA Accepted [[fakss31]]
//============================================================================

#include <bits/stdc++.h>

using namespace std;

#define For(i,st,ed) for(unsigned int i=st;i<ed;i++)
#define rFor(i,ed,st) for(unsigned int i=ed-1;i>=st;i--)
#define all(v) (v).begin(),(v).end()
#define rall(v) (v).rbegin(),(v).rend()

#define cin_i(i) scanf("%d",&i)
#define cin_li(i) scanf("%I64d",&i)
#define cin_f(i) scanf("%f",&i)
#define cin_d(i) scanf("%lf",&i)
#define cin_c(i) scanf("%c",&i)
#define cin_2i(i,j) scanf("%d %d",&i,&j)
#define cin_2d(i,j) scanf("%lf %lf",&i ,&j)
#define cin_3i(i,j,k) scanf("%d %d %d",&i,&j,&k)
#define cin_3li(i,j,k) scanf("%I64d %I64d %I64d",&i,&j,&k)
#define cout_i(i) printf("%d ",i)
#define cout_2i(i,j) printf("%d %d ",i,j)
#define cout_li(i) printf("%I64d\n",i)

#define Pair(a) (a).first,(a).second
#define fi      first
#define se      second
#define endl      '\n'
double pi = 3.14159265359;
//freopen("input.txt","r",stdin);
//freopen("output.txt","w",stdout);

using namespace std;

bool check(string &temp)
{
    for (int i = 0, j = temp.size() - 1; i < temp.size() / 2; i++, j--)
        if (temp[i] != temp[j])
            return 0;
    return 1;
}
int main()
{
    ios::sync_with_stdio(false);
    string x;
    cin >> x;
    int n;
    cin >> n;
    if(x.size()%n) {
        cout<<"NO";
        return 0;
    }
    n = x.size() / n;
    if (n==0)
    {
        cout << "NO";
        return 0;
    }
    int c = 0;
    string k = "";
    For(i,0,x.size())
    {
        if (c < n)
            k += x[i],c++;
        else
        {
          if(!check(k))
          {
                cout << "NO";
                return 0;
            }
          else k="" , c=0,i--;
        }
    }
    if(check(k))
    cout<<"YES";
    else
    cout<<"NO";
    return 0;
}
