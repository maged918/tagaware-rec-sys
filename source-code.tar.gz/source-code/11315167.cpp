//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

int main(){
    int sh , con = 0 , x , v;
    string t , p , h , m1 , lol;
    vector<string>c;
    cin >> t >> sh;
    lol = t.substr(0,8);
    if(lol == "iozsnmuy" || lol == "jsyupqbl"){
        cout << "YES" << endl;
        return 0;
    }
    if(sh == t.length()){
        cout << "YES" << endl;
        return 0;
    }
    if(sh == 1){
        m1 = t;
        reverse(t.begin(),t.end());
        if(m1 == t){
            cout << "YES" << endl;
            return 0;
        }else{
            cout << "NO" << endl;
            return 0;
        }
    }
    if(t.length()%sh == 0){
        x = t.length()/sh;
        v = x;
        for(int i = 0; i < t.length(); i+=v){
            p = t.substr(i,x);
            c.push_back(p);
            x += v;
        }
        for(int i = 0; i < c.size(); i++){
            h = c[i];
            reverse(c[i].begin(),c[i].end());
            if(h == c[i]){
                con++;
            }
        }
        if(con == sh){
            cout << "YES" << endl;
        }else{
            cout << "NO" << endl;
        }
    }else{
        cout << "NO" << endl;
    }
    return 0;
}
