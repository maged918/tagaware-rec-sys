//Language: MS C++


#pragma comment (linker,"/stack:102400000,102400000")
#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
using namespace std;

typedef __int64 LL;
typedef unsigned long long ULL;
const int N = 100005;
const int M = 600005; 
const LL INF = 1111111111111111;
const int MOD = 1000000007;
const double Pi = acos(-1.0);

#define Key_value ch[ch[root][1]][0]
#define lson (i<<1)
#define rson (i<<1|1)

template < class T > inline T f_min(T a,T b){return a < b ? a : b;}
template < class T > inline T f_max(T a,T b){return a > b ? a : b;}
template < class T > inline T f_abs(T a){return a > 0 ? a : -a;}
template < class T > inline T f_gcd(T a,T b){return b == 0 ? a : f_gcd(b,a%b);}
template < class T > inline T f_Lcm(T a,T b){return a / gcd(a,b) * b;}
template < class T > inline void f_swap(T &a,T &b){T t = a;a = b;b = t;}

struct p{
	int x,y;
}a[N],b[N<<2];
int temp[N<<1];
LL num[N<<4];
void update(int i,int x,int L,int R,int cost){
	num[i] += cost;
	if(L == R)	return ;
	int mid = L + R >> 1;
	if(x <= mid)	update(lson,x,L,mid,cost);
	else update(rson,x,mid+1,R,cost);
}
LL query(int i,int x,int L,int R){
	if(L == R)	return 0;
	int mid = L + R >> 1;
	if(x <= mid)	return query(lson,x,L,mid) + num[rson];
	else return query(rson,x,mid+1,R);
}
int main(){
	int n;
	while(~scanf("%d",&n)){
		int cnt = 0;
		for(int i = 0;i < n;++i)scanf("%d%d",&a[i].x,&a[i].y),
			temp[cnt++] = a[i].x,temp[cnt++] = a[i].y;
		temp[cnt++] = 1;
		sort(temp,temp+cnt);
		cnt = unique(temp,temp+cnt) - temp;
		//for(int i = 0;i < cnt;++i)cout<<temp[i]<<" ";
		//cout<<endl;
		b[0].x = 0;b[0].y = 1;
		for(int i = 1;i < cnt;++i){
			b[lson-1].x = lson-1;
			b[lson-1].y = temp[i] - temp[i-1] - 1;
			b[lson].x = lson;
			b[lson].y = 1;
		}
		//for(int i = 0;i < 2*cnt-1;++i)cout<<b[i].x<<" "<<b[i].y<<endl;
		//cout<<endl;
		for(int i = 0;i < n;++i){
			int x = (lower_bound(temp,temp+cnt,a[i].x) - temp)*2;
			int y = (lower_bound(temp,temp+cnt,a[i].y) - temp)*2;
			f_swap(b[x],b[y]);
		}
		//for(int i = 0;i < 2*cnt-1;++i)cout<<b[i].x<<" "<<b[i].y<<endl;
		LL res = 0;
		memset(num,0,sizeof(num));
		for(int i = 0;i < 2*cnt-1;++i){
			res += 1LL*b[i].y * query(1,b[i].x+1,1,2*cnt-1);
			//cout<<query(1,b[i].x+1,1,2*cnt-1)<<endl;
			update(1,b[i].x+1,1,2*cnt-1,b[i].y);
		}
		printf("%I64d\n",res);
	}
	return 0;
}
/*
2
2 15
8 17
*/