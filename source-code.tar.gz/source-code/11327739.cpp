//Language: GNU C++11


/*
10 50
151790 360570 1 1 123690 162690 1 155208 227488 1
3
10
10
7
9
10
3
4
9
1
3
6
8
9
3
4
8
8
8
8
9
8
6
2
4
5
2
2
2
1
6
2
8
4
5
1
1
10
4
7
2
8
5
6
5
3
1
6
10
7
5
10
7
5
3
3
10
4
9
3
4
6
7
4
9
8
10
9
1
7
6
3
8
2
6
9
3
9
5
8
3
7
9
2
1
3
3
4
10
3
4
1
3
4
6
2
7
5
9
8
5
2
6
10
2
1
3
2
2
6
5
6
4
7
5
4
10
8
8
6
6
9
5
10
10
6
9
6
4
5
9
3
5
8
5
1
9
1
7
3
10
10

*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <list>
#include <iomanip>
#include <iostream>
#include <queue>
#include <list>
#include <map>
#include <numeric>
#include <unordered_map>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>
#include <cstdlib>
#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(typeof((cont).begin()) it=(cont).begin(); it!=(cont).end(); it++)
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(), (x).end()
typedef int mint;
#define int ll
using namespace std; typedef long long ll; typedef pair<int, int> ii; typedef vector<int> vi; typedef vector<ii> vii; typedef vector<vi> vvi;

#define SIZE 1000000
bitset<SIZE> sieve;
void buildSieve() {
	sieve.set();
	sieve[0] = sieve[1] = 0;
	int root = sqrt(SIZE);
	FOR(i, 2, root+1)
		if (sieve[i])
			for(int j = i*i; j < SIZE; j+=i)
				sieve[j] = 0;
}

vi primesList;
void buildPrimesList() {
	if(!sieve[2])
		buildSieve();
	primesList.reserve(SIZE/log(SIZE));
	FOR(i, 2, SIZE+1)
		if(sieve[i])
			primesList.pb(i);
}

vi primeFactorization(int N) {
	vi factors;
	int idx = 0, pf = primesList[0];
	while(pf*pf <= N) {
		while(N%pf==0) {
			N /= pf;
			if(!factors.size() || factors.back() != pf)
				factors.pb(pf);
		}
		pf = primesList[++idx];
 	}
	if(N!=1) factors.pb(N);
	return factors;
}


struct container_hash {
	std::size_t operator()(std::vector<int> const& vec) const {
		std::size_t seed = 0;
		for(auto& i : vec) {
			seed ^= i + 0x9e3779b9 + (seed << 6) + (seed >> 2);
		}
		return seed;
	}
};

int m2[500010];
int ans = 0;

void modify(vi &pf, bool insert) {
	int k = (1<<pf.size());
	FOR(i, 1, k) {
		int r = i;
		int a = 1;
		while(r) {
			int p = r & -r;
			r -= p;
			a*=pf[log2(p)];
		}
		if (!insert)
			m2[a]--;
		ans += (insert*2-1) * m2[a] * (__builtin_popcount(i)%2 == 1 ? 1 : -1);
		if(insert)
			m2[a]++;
	}
}

int ct = 0;
mint main() {
	int N, Q;
	cin >> N >> Q;
	buildPrimesList();
	vvi arr;
	FOR(i, 0, N) {
		mint k;
		scanf("%d", &k);
		vi pf = primeFactorization(k);
		arr.pb(pf);
	}

	vi on(N, 0);
	FOR(i, 0, Q) {
		mint q;
		scanf("%d", &q);
		on[q-1] = !on[q-1];
		ct += on[q-1]*2-1;
		modify(arr[q-1], on[q-1]);
		cout << ct*(ct-1)/2 - ans << endl;
	}
}
