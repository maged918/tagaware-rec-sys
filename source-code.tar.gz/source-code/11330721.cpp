//Language: GNU C++


#include <stdio.h>
#include <string.h>

int check(char s[], int i, int j){
	int x=1;

	while(i<j && x==1){
		if(s[i]==s[j]);
		else
			x=0;

		i++;
		j--;
	}

	return x;
}

int main(){
	int n,i,j,k,x;
	char s[1001];

	scanf("%s", s);
	scanf("%d", &k);

	n=strlen(s);

	if(n%k==0)
		x=1;
	else
		x=0;

	j=n/k;

	for(i=0;i<n && x==1;i+=j)
		if(check(s,i,i+j-1)==1);
		else
			x=0;

	if(x==1)
		printf("YES\n");
	else
		printf("NO\n");

	return 0;
}