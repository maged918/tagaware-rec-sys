//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
typedef long long int LL;
#define M 1000000009
const int N=300005;
LL a[N],sum[N],fibo[N];
int lf[N],rt[N];
void solve()
{
    fibo[1]=1,fibo[2]=1;
    for(int i=3;i<N;i++){
        fibo[i]=fibo[i-1]+fibo[i-2];
        while(fibo[i]>=M)
            fibo[i]-=M;
    }
}
int main()
{
    int n,m;
    scanf("%d %d",&n,&m);
    for(int i=1;i<=n;i++){
        scanf("%lld",&a[i]);
        a[i]=a[i-1]+a[i];
        while(a[i]>=M)
            a[i]-=M;
    }
    solve();
    int sq=1000;
    int sz=0,id,l,r;
    while(m--)
    {
        if(sz==sq)
        {
            LL temp=sum[1];
            a[1]=(a[1]+temp);
            while(a[1]>=M)
                a[1]-=M;
            for(int i=2;i<=n;i++){
                sum[i]=(sum[i]+sum[i-1]+sum[i-2])%M;
                while(sum[i]>=M)
                    sum[i]-=M;
                if(sum[i]<0)
                    sum[i]+=M;
                temp+=sum[i];
                if(temp<0)
                    temp+=M;
                while(temp>=M)
                    temp-=M;
                a[i]=(a[i]+temp)%M;
                while(a[i]>=M)
                    a[i]-=M;
                if(a[i]<0)
                    a[i]+=M;
                sum[i-2]=0;
            }
            sum[n-1]=0;
            sum[n]=0;
            sz=0;
        }
        scanf("%d %d %d",&id,&l,&r);
        if(id==1){
            sum[l]=(sum[l]+fibo[1]);
            if(sum[l]>=M)
                sum[l]%=M;
            sum[l+1]=(sum[l+1]+fibo[2]-fibo[1]);
            sum[r+1]=(sum[r+1]-fibo[r-l+2]);
            sum[r+2]=(sum[r+2]-fibo[r-l+1]);
            while(sum[l+1]<0)
                sum[l+1]+=M;
            while(sum[l+1]>=M)
                sum[l+1]-=M;
            while(sum[r+1]<0)
                sum[r+1]+=M;
            while(sum[r+1]>=M)
                sum[r+1]-=M;
            while(sum[r+2]<0)
                sum[r+2]+=M;
            while(sum[r+2]>=M)
                sum[r+2]-=M;
            lf[sz]=l;
            rt[sz]=r;
            sz++;
        }
        else
        {
            LL ans=0;
            ans=(a[r]-a[l-1]);
           // printf("%lld\n",ans);
            while(ans>=M)
                ans-=M;
            if(ans<0)
                ans+=M;
            for(int i=0;i<sz;i++){
                int L=lf[i];
                int R=rt[i];
              //  printf("%d %d\n",L,R);
                if(R<l || L>r)
                    continue;
                else if(L>=l && R<=r)
                    ans+=fibo[R-L+3]-1;
                else if(L>l)
                    ans+=(fibo[r-L+3]-1);
                else if(r>R)
                    ans+=(fibo[R-L+3]-1)-(fibo[l-L+2]-1);
                else if(l>=L && R>=r)
                    ans+=(fibo[r-L+3]-1)-(fibo[l-L+2]-1);
                while(ans<0)
                    ans+=M;
                while(ans>=M)
                    ans-=M;
                // printf("here = %lld\n",ans);
            }
            printf("%lld\n",ans);
        }
    }
}
