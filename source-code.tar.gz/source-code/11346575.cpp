//Language: MS C++


#include <iostream>
#include <cstdio>
#include <map>
#include <vector>
#include <cstring>
using namespace std;
int num[30];
long long sum[100050];
char s[100050];
vector<int> pos[30];
int main()
{
	for (int i = 0; i < 26; i++)scanf("%d", &num[i]);
	getchar();
	int i = 1;
	while (scanf("%c", &s[i++]) && s[i - 1] != '\n')
	{
		sum[i - 1] += sum[i - 2] + num[s[i - 1] - 'a'];
		pos[s[i - 1] - 'a'].push_back(i - 1);
	}
	s[0] = 1;
	int n = strlen(s);
	long long ans = 0;
	
	for (int cc = 0; cc < 26; cc++)
	{
		map<long long, int>M;
		for (i = 0; i < pos[cc].size(); i++)
		{
			int p = pos[cc][i];
			ans += M[sum[p - 1]];
			M[sum[p]]++;
		}
		M.clear();
	}

	cout << ans << endl;
	return 0;
}
	     	 	   	  		 		  	    	  	