//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;
typedef long long LL;

LL r, g, ans, modulo = 1e9 + 7;
LL dp[2][222222];
int flag;

LL calcAll(LL h){
    return h * (h + 1) / 2;
}

int main()
{
    cin >> r >> g;

    dp[0][0] = 1; ans = 1;
    for (int i = 0; ans != 0; ++i, flag ^= 1){
        ans = 0;
        memset(dp[flag ^ 1], 0, sizeof(dp[flag ^ 1]));

        for (int j = 0; j < 222222; ++j){
            if (dp[flag][j] == 0) continue;

            LL red = j, green = calcAll(i) - j, step = i + 1;

            if (red + step <= r) {
                dp[flag ^ 1][red + step] += dp[flag][j];
                if (dp[flag ^ 1][red + step] >= modulo) dp[flag ^ 1][red + step] -= modulo;
            }
            if (green + step <= g) {
                dp[flag ^ 1][red] += dp[flag][j];
                if (dp[flag ^ 1][red] >= modulo) dp[flag ^ 1][red] -= modulo;
            }

            ans += dp[flag ^ 1][red] + dp[flag ^ 1][red + step];
        }
    }

    for (int i = 0; i < 222222; ++i) ans = (ans + dp[flag ^ 1][i]) % modulo;

    cout << ans;

    return 0;
}
