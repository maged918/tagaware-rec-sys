//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
const int N(1e5+200);
int n,a,b,hh[N],fa[N],tot;
map<int,int> mp;
set<int> s;
typedef map<int,int>::iterator iter;
inline int find(int x)
{
    return fa[x]==x?x:fa[x]=find(fa[x]);
}
int main()
{
    cin>>n>>a>>b;
    for(int i(1);i<=n+2;i++)fa[i]=i;
    for(int i(1);i<=n;i++)
    {
        cin>>hh[i];
        mp[hh[i]]=1;
        s.insert(hh[i]);
    }
    for(iter i=mp.begin();i!=mp.end();i++)
        i->second=++tot;
    for(int i(1);i<=n;i++)
    {
        int x(hh[i]);
        if(s.count(a-x))
            fa[find(mp[a-x])]=find(mp[x]);
        else fa[find(mp[x])]=find(n+2);
        if(s.count(b-x))
            fa[find(mp[b-x])]=find(mp[x]);
        else fa[find(mp[x])]=find(n+1);
    }
    if(find(n+1)==find(n+2))puts("NO");
    else
    {
        puts("YES");
        for(int i(1);i<=n;i++)
            printf("%d ",find(mp[hh[i]])==find(n+2));
    }
    return 0;
}