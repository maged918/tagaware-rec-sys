//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;
const int maxn=30;
int mark[maxn];
main(){
    char c;
    ios::sync_with_stdio(false);
    cin.tie(false);
    string s;
    cin>>s;
    int sz=s.size();
    int n;
    cin>>n;
    for(int i=0;i<n;i++)
        s+='Z';
    int ans=-1;
    for(int i=0;i<s.size();i++){
        for(int j=i+1;j<s.size();j+=2){
            string t="";
            int need=0;
            for(int k=i;k<=j;k++)
                t+=s[k];
            bool can=true;
            for(int k=0;k<t.size()/2;k++){
                if(t[k]!=t[k+t.size()/2]){
                    if(t[k+t.size()/2]!='Z' && t[k]!='Z')
                        can=false;
                    else
                        need++;
                }
            }
            int x=t.size();
            if(can){
                ans=max(ans,x);
            }
        }
    }
    cout<<ans<<endl;
    return 0;
}
