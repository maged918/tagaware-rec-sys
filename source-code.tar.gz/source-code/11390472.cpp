//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>
#include <queue>

#define MAXN 110000

using namespace std;

typedef long long int LL;
typedef pair<int,int> pr;

int n,m,K;
LL P,h[MAXN],a[MAXN];
LL nowh[MAXN]; //二分判定时倒着模拟的每根竹子的高度

priority_queue<pr,vector<pr>,greater<pr> >heap;

bool check(LL lastMaxH)
{
    while(!heap.empty()) heap.pop(); //!!!!
    for(int i=1;i<=n;i++) nowh[i]=lastMaxH;
    for(int i=1;i<=n;i++)
    {
        if(nowh[i]-m*a[i]>=0) continue;
        heap.push(make_pair(nowh[i]/a[i]-1,i));
    }
    int tot=0; //最后tot=使得所有竹子的高度大于等于初始高度的最少进行的砍伐次数
    for(;tot<=m*K;tot++) //进行tot次砍竹(倒着处理就是增加高度)操作,第tot次操作发生在tot/K天，这个循环后使得每个竹子在开始的那天高度不为负数
    {
        if(heap.empty()) break;
        pr now=heap.top();
        heap.pop();
        if(now.first<tot/K) return false;
        nowh[now.second]+=P;
        if(nowh[now.second]-m*a[now.second]>=0) continue;
        heap.push(make_pair(nowh[now.second]/a[now.second]-1,now.second));
    }
    if(tot>m*K) return false;
    for(int i=1;i<=n;i++)
    {
        if(nowh[i]-m*a[i]>=h[i]) continue;
        tot+=((h[i]-nowh[i]+m*a[i])+P-1)/P; //加上一定操作次数，使得第i个竹子刚刚好比它的初始高度h[i]高
        if(tot>m*K) return false;
    }
    return true;
}

int main()
{
    scanf("%d%d%d%I64d",&n,&m,&K,&P);
    for(int i=1;i<=n;i++)
        scanf("%I64d%I64d",&h[i],&a[i]);
    LL lowerBound=0,upperBound=1e15,ans=-1;
    while(lowerBound<=upperBound)
    {
        LL mid=(lowerBound+upperBound)>>1;
        if(check(mid))
        {
            ans=mid;
            upperBound=mid-1;
        }
        else lowerBound=mid+1;
    }
    printf("%I64d\n",ans);
    return 0;
}
