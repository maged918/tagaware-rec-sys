//Language: GNU C++11


/*
 ***************************************************************************************************************
 
 Author : Tapan Sahni
 
 **************************************************************************************************************
 */

#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define LL long long
#define si(x) scanf("%d",&x)
#define sc(x) scanf("%c",&x)
#define sl(x) scanf("%I64d",&x)
#define all(x) x.begin(),x.end()
#define compress(x) {sort(all(x));(x).resize(unique(all(x))-(x).begin());}
template<class T> inline void umax(T &a,T b){if(a<b) a = b ;}
typedef pair<int, int> ii;
typedef pair<LL, LL> iil;
typedef pair<LL, iil> iiil;
typedef pair<ii, int> iii;
typedef pair<ii, ii> iiii;
#define vl vector<ll>
#define vi vector<int>
#define vii vector<ii>
#define vvl vector< vl >
#define vvi vector< vi >
#define vvii vector< vii >
#define sz size()
#define pb push_back
#define F first
#define S second
#define mem(x,y) memset(x,y,sizeof(x))
#define rep(i,a,b) for(int i=(a);i<(b);i++)
#define mod 1000000007
#define pb push_back

const int maxn = 1000005;
//const int INF  = 1e9 + 7;
const LL INF = 0x0123456789ABCDEFLL;
LL a[maxn] , b[maxn];
LL cnt[maxn] , cnt1[maxn];
inline void solve(void){
        int n  , m;
       //scanf("%d%d",&n ,&m);
        cin  >> n>> m;
    //    rep(i , 1 , n + 1) scanf("I64d" , &a[i]) , b[i] = a[i];
        rep(i , 1 , n + 1) cin >> a[i], b[i] = a[i];
        reverse(b + 1 , b + n + 1);
        for(int i = 1 ; i<=n; i++){
            if(i > m){
            int mul = (i - 1) / m;
            int mul1 = mul;
            mul = mul * m;
            cnt[i] = cnt[mul] + (a[i] - a[mul + 1]) + (a[i] - a[mul]) * mul1;
            cnt1[i] = cnt1[mul] + (b[mul + 1] - b[i]) + (b[mul] - b[i]) * mul1;;
            }
            else{
            cnt[i] =  a[i] - a[1];
            cnt1[i]= b[1] - b[i];
            }
        }
        LL ans = cnt1[n] + cnt[1];
        for(int i = 2 ;i<=n;i++){
            ans  = min(cnt1[n - i + 1] + cnt[i] , ans);
        }
       // printf("%I64d\n", ans);
        cout << 2* ans;

} 
void init() {
 ios::sync_with_stdio(false);
 cin.tie(nullptr);
 }
int main(int argc, const char * argv[]){
    init();
    solve();
    return 0;
}