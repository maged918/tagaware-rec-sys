//Language: GNU C++


#include <iostream>
using namespace std;
int main() {
    
    char chess[64];
    int white=0,black=0;
    char white_pieces[]={'Q','R','B','N','P'};
    char black_pieces[]={'q','r','b','n','p'};
    
    int value[]={9,5,3,3,1};
    
    for(int a=0;a<64;a++)
        cin>>chess[a];
    
    for(int a=0;a<64;a++){
        for(int b=0;b<5;b++)
            if(chess[a]==black_pieces[b])
                black+=value[b];
            else if(chess[a]==white_pieces[b])
                white+=value[b];
    }
    
    if(white>black)cout<<"White";
    else if(black>white)cout<<"Black";
    else cout<<"Draw";
    
    
    return 0;
}
