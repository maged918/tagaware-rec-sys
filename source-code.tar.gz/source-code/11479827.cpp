//Language: GNU C++


#include <iostream>
#include <set>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <climits>
#include <utility>
#include <map>
#include <sstream>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <string>
#include <bitset>

#define fore(i,n) for(int i=0;i<n;i++)
#define fori(i,n) for(int i=0;i<=n;i++)
#define all(v) v.begin(),v.end()

#define T 105
#define M 100005

using namespace std;

int v1,v2,t,d,s;
int main()
{
    int i;
    scanf("%d%d%d%d",&v1,&v2,&t,&d);
    for(i=1;i<=t;i++)
        s+=min(v1+(i-1)*d,v2+(t-i)*d);
    printf("%d\n",s);
    return 0;
}