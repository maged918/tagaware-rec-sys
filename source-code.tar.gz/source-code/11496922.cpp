//Language: GNU C++11


/*
 * Problem:  
 * Author:  SHJWUDP
 * Created Time:  2015/6/8 星期一 16:51:21
 * File Name: 233.cpp
 * State: 
 * Memo: 
 */
#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long int64;

const int MaxA=1e5+7;
const int MaxB=MaxA<<1;

struct Fenwick {
    int n;
    int c[MaxB];

    void init(int _n) {
        this->n=_n;
        memset(c, 0, sizeof(c[0])*(n+3));
    }

    int lowbit(int x) {
        return x&-x;
    }

    void update(int x, int v) {
        while(x<=n) {
            c[x]+=v;
            x+=lowbit(x);
        }
    }

    int query(int x) {
        int res=0;
        while(x>0) {
            res+=c[x];
            x-=lowbit(x);
        }
        return res;
    }
} fw;

int n;
pair<int, int> op[MaxA];
int table[MaxB], tn;
int arr[MaxB], an;
int find(int x) {
    return lower_bound(table, table+tn, x)-table;
}
int main() {
#ifndef ONLINE_JUDGE
    freopen("in", "r", stdin);
    //freopen("out", "w", stdout);
#endif
    while(~scanf("%d", &n)) {
        tn=0;
        for(int i=0; i<n; i++) {
            scanf("%d%d", &op[i].first, &op[i].second);
            table[tn++]=op[i].first;
            table[tn++]=op[i].second;
        }
        sort(table, table+tn);
        tn=unique(table, table+tn)-table;
        memcpy(arr, table, tn*sizeof(table[0]));
        an=tn;

        for(int i=0; i<n; i++) {
            swap(arr[find(op[i].first)], arr[find(op[i].second)]);
        }
        fw.init(tn);
        int64 ans=0;
        for(int i=0; i<an; i++) {
            int p=find(arr[i])+1;
        //  cout<<"tn: "<<tn<<"\tpos: "<<p<<endl;
            ans+=fw.query(tn)-fw.query(p);
        //  cout<<fw.query(tn)<<"\t"<<fw.query(p)<<endl;
            if(i!=an-1) {
                int q=find(table[i])+1;
                fw.update(p, 1);
                int num=table[i+1]-table[i]-1;
                ans+=(int64)num*(fw.query(tn)-fw.query(q));
            //  cout<<fw.query(tn)<<"\t"<<fw.query(q)<<endl;
                fw.update(q+1, num);
            }
        }
        printf("%I64d\n", ans);
    }
    return 0;
}
