//Language: GNU C++


#include"cstdio"
#include"cstring"
#include"string"
#include"iostream"
#include"cmath"
#include"algorithm"
#include"map"
using namespace std;
int main()
{
    string s;
    cin>>s;
    for(int i=0; i<26; i++)
    {
        for(int j=0; j<s.size()+1;j++)
        {
            string re1=s;
            char x=i+'a';
            string str="";
            str+=x;
            re1.insert(j, str);
            string re2=re1;
            reverse(re2.begin(),re2.end());
            if (re1==re2)
            {
                cout<<re1<<endl;
                return 0;
            }
        }
    }
    printf("NA\n");
    return 0;
}

	 	 						  	 	  		  			 				 	