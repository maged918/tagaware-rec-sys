//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;


int main()
{
    string s;
    cin>>s;
    bool f1=false,f2=false,f3=false;
    for(int i=0;i<(s.length()-1);i++)
    {
        if(s[i]=='A'&&(!f1))
        {
            if(s[i+1]=='B')
            {
                if(s[i+2]=='A'&&(!f3))
                {   f3=true;i++;}
                else
                    f1=true;
                i++;
                
            }
        }
        else if(s[i]=='B'&&(!f2))
        {
            if(s[i+1]=='A')
            {
                if(s[i+2]=='B'&&(!f3))
                {   f3=true;i++;}
                else
                    f2=true;
                    i++;
                
            }
        }
        
    }
    if(f1&&f2)
        cout<<"YES"<<endl;
    else if((f3&&(f1||f2)))
        cout<<"YES"<<endl;
    else
        cout<<"NO"<<endl;
    return 0;
}