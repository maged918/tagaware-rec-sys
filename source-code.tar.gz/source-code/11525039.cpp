//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
string board[8];
int main() {
	for (int i = 0; i < 8; ++i) cin >> board[i];
	for (int i = 0; i < 8; ++i) {
		for (int j = 1; j < 8; ++j) {
			if (board[i][j] == board[i][j - 1]) {
				cout << "NO\n";
				return 0;
			}
		}
	}
	cout << "YES\n";
	return 0;
}

