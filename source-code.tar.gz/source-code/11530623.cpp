//Language: GNU C++11


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;
typedef long long LL;
const int maxn=100000+100;
const LL mod=1e9+7;

int d[maxn], sum[maxn];

int main()
{
    int n, k;
    scanf("%d%d", &n, &k);
    d[0]=1;
    for(int i=1; i<maxn; i++)
    {
        d[i]+=d[i-1];
        if(i>=k)d[i]+=d[i-k];
        if(d[i]>=mod)d[i]-=mod;
        sum[i]=d[i]+sum[i-1];
        if(sum[i]>=mod)sum[i]-=mod;
    }
    while(n--)
    {
        int l, r;
        scanf("%d%d", &l, &r);
        printf("%d\n", (sum[r]-sum[l-1]+mod)%mod);
    }
    return 0;
}
