//Language: GNU C++11


#include <iostream>
#include<cmath>
using namespace std;
int main()
{
string str;
int a[4],sum=0;
for(int i=0;i<4;i++)
    cin>>a[i];
    cin>>str;
for(int i=0;i<str.size();i++){
    if(str[i]=='1')
        sum=sum+a[0];
    else if(str[i]=='2')
        sum=sum+a[1];
        else if(str[i]=='3')
        sum=sum+a[2];
        else if(str[i]=='4')
        sum=sum+a[3];}
    cout<<sum<<endl;

    return 0;
}
