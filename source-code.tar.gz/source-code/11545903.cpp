//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
#include<math.h>
#include<queue>
#include<stack>
#include<sstream>
#include<stdio.h>
#include<map>
#include<set>
#include<memory.h>
#include<algorithm>
#include<vector>
using namespace std;
typedef long long ll;
ll gcd(ll a, ll b){
    if (!b)
        return a;
    return gcd(b, a%b);
}
ll lcm(ll a, ll b){
    return b / gcd(a, b)*a;
}
#define FOR(I,N) for(int(i)=0;i<int(N);++i)
#define FORK(I,N,K) for(int(i)=0;i<int(N);i+=int(K))
const int N = 1e6 + 2;
ll res;
int n, x, a[N], b[N];
int p1, p2;
int main(){
    cin >> n;
    while (n--){
        scanf("%d", &x);
        ++a[x];
        p1 = max(x, p1);
    }
    p2 = -1;
    while (p1){
        if (b[p1] == 1 && a[p1]){
            a[p1]++;
            if (a[p1] > 3){
                if (p2 != -1){
                    res += 1ll * p2 * p1;
                    a[p1] -= 2;
                    p2 = -1;
                }
                int T = a[p1] / 4;
                int R = a[p1] - T * 4;
                if (R & 1)
                    ++b[p1 - 1];
                if (R > 1)
                    p2 = p1;
                res += 1ll * T * p1 * p1;
            }
            else if (a[p1] == 1){
                ++b[p1 - 1];
            }
            else if (a[p1] == 3){
                ++b[p1 - 1];
                if (p2 != -1){
                    res += 1ll * p2 * p1;
                    p2 = -1;
                }
                else p2 = p1;
            }
            else {
                if (p2 != -1){
                    res += 1ll * p2 * p1;
                    p2 = -1;
                }
                else p2 = p1;
            }
        }
        
        else if(a[p1]){
            if (a[p1] > 3){
                if (p2 != -1){
                    res += 1ll * p2 * p1;
                    a[p1] -= 2;
                    p2 = -1;
                }
                int T = a[p1] / 4;
                int R = a[p1] - T * 4;
                if (R & 1)
                    ++b[p1 - 1];
                if (R > 1)
                    p2 = p1;
                res += 1ll * T * p1 * p1;
            }
            else if (a[p1] == 1){
                ++b[p1 - 1];
            }
            else if (a[p1] == 3){
                ++b[p1 - 1];
                if (p2 != -1){
                    res += 1ll * p2 * p1;
                    p2 = -1;
                }
                else p2 = p1;
            }
            else {
                if (p2 != -1){
                    res += 1ll * p2 * p1;
                    p2 = -1;
                }
                else p2 = p1;
            }
        }
        --p1;
    }
    cout << res << endl;
}