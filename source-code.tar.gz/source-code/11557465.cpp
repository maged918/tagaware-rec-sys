//Language: GNU C++


#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <algorithm>
#include <map>
using namespace std;
#define ll long long
#define x first
#define y second
#define pii pair<int, int>
#define pdd pair<double, double>
#define L(s) (int)(s).size()
#define VI vector<int>
#define all(s) (s).begin(), (s).end()
#define pb push_back
#define mp make_pair
#define ull unsigned ll
ull n, k;
int m, l;
int f[2][2] = {{1,1},{1,0}}, res[2][2], tmp[2][2];
inline void mul(int a[][2], int b[][2], int c[][2]) {
	for(int i = 0; i < 2; ++i) {
		for(int j = 0; j < 2; ++j) {
			ll t = 0;
			for(int k = 0; k < 2; ++k) {
				t += (ll)a[i][k] * b[k][j];
			}
			tmp[i][j] = t % m;
		}
	}
	for(int i = 0; i < 2; ++i) for(int j = 0; j < 2; ++j) c[i][j] = tmp[i][j];
}
int main() {
	cin >> n >> k >> l >> m;

	if (l != 64) {
		if (k >= ((ull)1 << l)) {
			cout << 0 << endl;
			return 0;
		}
	}

	res[0][0] = res[1][1] = 1;

	ull pw = n;
	int p2 = 2, n2 = 1;
	while(pw) {
		if (pw & 1) { mul(res, f, res); n2 = (ll)n2 * p2 % m; }
		pw /= 2; mul(f, f, f);  p2 = (ll)p2 * p2 % m;
	}

	int fn = (res[0][0] + res[0][1]) % m;
	int on = n2 - fn; if (on < 0) on += m;

//	cerr << fn << " " << n2 << " " << on << endl;

	int ans = 1 % m;
	for(int i = 0; i < l; ++i) {
		if (k & ((ull)1 << i)) {
			ans = (ll)ans * on % m;
		} else {
			ans = (ll)ans * fn % m;
		}
	}
	cout << ans << endl;
}