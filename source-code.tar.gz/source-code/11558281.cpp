//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

#define FINAL_OUT(x) {cout << x << '\n'; return 0;}

struct Matr{
    long long a,b,c,d;
void norm(int m)
    {
        a %= m;
        b %= m;
        c %= m;
        d %= m;
    }
};
// a b
// c d
Matr prod(Matr const& x, Matr const& y, int m)
{
    Matr ret;
    ret.a = x.a * y.a + x.b * y.c;
    ret.b = x.a * y.b + x.b * y.d;
    ret.c = x.c * y.a + x.d * y.c;
    ret.d = x.c * y.b + x.d * y.d;
    ret.norm(m);
    return ret;
}

long long fib(long long n, int m)
{
    n += 1LL;
    Matr ret = {1,0,1,0};
    Matr tmp = {1,1,1,0};
    while (n)
    {
        if (n%2)
            ret = prod(ret, tmp, m);
        tmp = prod(tmp, tmp, m);
        n /= 2;
    }
    ret.norm(m);
    return ret.a;
}

long long mypow(long long n, int m)
{
    long long ret = 1 % m;
    long long tmp = 2;
    while (n)
    {
        if (n%2)
            ret = (ret * tmp) % m;
        tmp = (tmp * tmp) % m;
        n/=2;
    }
    return ret;
}

int main()
{
//        freopen("in.txt", "r", stdin);
    ios_base::sync_with_stdio(false);

    long long n,m;
    unsigned long long k;
    int l;
    cin >> n >> k >> l >> m;
    unsigned long long tmpk = k;
    for(int i = 0; i < l && tmpk; ++i)
    {
        if (tmpk & (1uLL << i))
            tmpk ^= (1uLL << i);
    }
    if (tmpk > 0)
        FINAL_OUT(0);

    long long ans = 1%m;
    long long tmp = fib(n,m);
    long long tmp2 = mypow(n,m);
    for(int i = 0; i < l; ++i)
    {
        long long cur = tmp;
        if (k & (1uLL << i))
            cur = (tmp2 - tmp + m) % m;
        ans = (ans * cur) % m;
    }
    cout << ans << endl;
    return 0;
}