//Language: GNU C++


#include<iostream>
using namespace std;

typedef unsigned long long ll;

ll m;

struct M{
	ll a, b, c, d;
	M(ll aa, ll bb, ll cc, ll dd){
		a = aa;
		b = bb;
		c = cc;
		d = dd;
	}
	M () {}
};

M operator * ( M &A, M &B ){
	M J;
	J.a = (A.a * B.a + A.b * B.c)%m;
	J.b = (A.a * B.b + A.b * B.d)%m;
	J.c = (A.c * B.a + A.d * B.c)%m;
	J.d = (A.c * B.b + A.d * B.d)%m;
	return J;
}

ll fib(ll n){
	M A(1, 1, 1, 0);
	M J(1, 0, 0, 1);
	while(n){
		if (n%2)
			J = J * A;
		A = A * A;
		n /= 2;
	}
	return (J.a + J.b)%m;
}

ll g(ll n){
	ll J = 1;
	ll A = 2;
	while(n){
		if (n%2)
			J = (A * J)%m;
		A = (A * A)%m;
		n /= 2;
	}	
	return J%m;	
}

int main(){
	ios::sync_with_stdio(0); cin.tie(0);
	ll n, k, l;
	cin >> n >> k >> l >> m;
	ll J = 1;
	for (ll i=0 ; i<l ; i++){
		ll t = 1;
		if (k&(1ULL<<i))
			t = (g(n) - fib(n) +m)%m;
		else
			t = fib(n);
		J = (J*t)%m;
	}
	if (k<(1ULL<<l) || l==64)
		cout << J%m << endl;
	else
		cout << 0 << endl;
}
