//Language: GNU C++11


#include <bits/stdc++.h>
#define vec vector
#define sz(c) int(c.size())
#define FOR(i, a, b) for (int i = a; i < (b); ++i)
#define DOWN(i, a, b) for(int i = (a) - 1; i >= (b); --i)
using namespace std;
const char eol = '\n';
typedef long long ll;
typedef pair<int,int> pii;
typedef vec<int> vi;

int const bs = 500;

int n;
int bc;
vec<ll> val;
vec<vi> blo;
vec<ll> add;

bool cmp(int A, int B) {
  if (val[A] != val[B]) return val[A] < val[B];
  return A < B;
}

void sortBlock(int i) {
  sort(blo[i].begin(), blo[i].end(), cmp);
}

void init(vi a) {
  n = sz(a);
  val = vec<ll>(n);
  FOR(i, 0, n) val[i] = a[i];
  
  bc = n / bs;
  if (n % bs != 0) bc += 1;

  blo = vec<vi>(bc);
  FOR(i, 0, n) {
    blo[i / bs].push_back(i);
  }

  FOR(i, 0, bc) {
    sortBlock(i);
  }

  add = vec<ll>(bc);
}

void inc(int l, int r, int x) {
  if (l / bs == r / bs) {
    FOR(i, l, r + 1) val[i] += x;
    sortBlock(l / bs);
    return;
  }

  FOR(i, l, (l / bs + 1) * bs) val[i] += x;
  sortBlock(l / bs);

  FOR(i, l / bs + 1, r / bs) add[i] += x;

  FOR(i, (r / bs) * bs, r + 1) val[i] += x;
  sortBlock(r / bs);
}

int getmax(int i, ll y) {
  y -= add[i];
  int l = 0, r = sz(blo[i]);
  while (l < r) {
    int m = (l + r) / 2;
    if (val[blo[i][m]] <= y) l = m + 1; else r = m;
  }
  l -= 1;
  if (l == -1 || val[blo[i][l]] != y) return -1;
  return blo[i][l];
}

int getmin(int i, ll y) {
  y -= add[i];
  int l = 0, r = sz(blo[i]);
  while (l < r) {
    int m = (l + r) / 2;
    if (val[blo[i][m]] < y) l = m + 1; else r = m;
  }
  if (l == sz(blo[i]) || val[blo[i][l]] != y) return n;
  return blo[i][l];
}

int get(int y) {
  int mx = -1;
  int mn = n;
  FOR(i, 0, bc) {
    mx = max(mx, getmax(i, y));
    mn = min(mn, getmin(i, y));
  }
  return mx == -1 ? -1 : mx - mn;
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout << fixed << setprecision(10);

  int N, M;
  cin >> N >> M;
  vi a(N);
  FOR(i, 0, N) cin >> a[i];

  init(a);
  while (M--) {
    int q;
    cin >> q;
    if (q == 1) {
      int l, r, x;
      cin >> l >> r >> x;
      inc(l - 1, r - 1, x);
    }
    else if (q == 2) {
      int y;
      cin >> y;
      cout << get(y) << eol;
    }
    else {
      assert(false);
    }
  }
  

  return 0;
}
