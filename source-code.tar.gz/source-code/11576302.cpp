//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

const int N=200010;
struct point
{
    long long x,y;
    int no;
}p[N],q[N],st[N],l,d;
int n,cnt,ans[N],m,top;

long long cross(point p0,point p1,point p2)
{
    return p1.y*p2.x*(p0.x*p0.y-p0.x*p2.y-p0.y*p1.x+p1.x*p2.y)-p2.y*p1.x*(p0.x*p0.y-p0.y*p2.x-p0.x*p1.y+p1.y*p2.x);
}

bool lcmp(point p1,point p2)
{
    if(p1.x>p2.x) return true;
    if(p1.x==p2.x) return p1.y>p2.y;
    return false;
}
bool dcmp(point p1,point p2)
{
    if(p1.y>p2.y) return true;
    if(p1.y==p2.y) return p1.x>p2.x;
    return false;
}
bool cmp(point p1,point p2)
{
    long long tmp=cross(d,p1,p2);
    if(!tmp) return p1.y>p2.y;
    return tmp<0LL;
}


int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        cin>>p[i].x>>p[i].y;
        p[i].no=i;
    }
    sort(p+1,p+n+1,lcmp);
    l=p[1];
   // for(int i=1;i<=n;i++) cout<<p[i].x<<" "<<p[i].y<<" "<<p[i].no<<endl;
    sort(p+1,p+n+1,dcmp);
    d=p[1];
    sort(p+1,p+n+1,cmp);
    q[++m]=p[1];
   // for(int i=1;i<=n;i++) cout<<p[i].x<<" "<<p[i].y<<" "<<p[i].no<<endl;
    for(int i=2;i<=n;i++)
    {
        if(p[i-1].x!=p[i].x||p[i-1].y!=p[i].y) q[++m]=p[i];
     //   cout<<p[i].x<<"   "<<p[i].y<<" "<<p[i].no<<endl;
        if(q[m].x==l.x&&q[m].y==l.y) break;
    }
    //for(int i=1;i<=m;i++)cout<<q[i].x<<" "<<q[i].y<<" "<<q[i].no<<endl;
    st[0]=q[1];
    if(l.x!=d.x||l.y!=d.y)
    {
        st[++top]=q[2];
        for(int i=3;i<=m;i++)
        {
            while(top&&cross(st[top-1],st[top],q[i])>0LL) top--;
            st[++top]=q[i];
        }
    }
    for(int i=0,j=1;i<=top&&j<=n;i++)
    {
     //   cout<<st[i].x<<" "<<st[i].y<<" "<<st[i].no<<" "<<0<<endl;
     //   cout<<p[j].x<<" "<<p[j].y<<" "<<p[j].no<<endl;
        while(j<=n&&p[j].x!=st[i].x||p[j].y!=st[i].y) j++;
        if(j>n) break;
        while(j<=n&&p[j].x==st[i].x&&p[j].y==st[i].y) ans[cnt++]=p[j++].no;
    }
    sort(ans,ans+cnt);
    for(int i=0;i<cnt-1;i++)
        printf("%d ",ans[i]);
    printf("%d\n",ans[cnt-1]);
    return 0;
}
