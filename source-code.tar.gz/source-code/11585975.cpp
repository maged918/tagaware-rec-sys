//Language: GNU C++


#include <iostream>
#include<algorithm>
#include<cstring>
#include<cctype>
#include<stdio.h>
#include<cstdlib>

using namespace std;
int main()
{
    int n;
    cin>>n;
    int p,q,d=0;
    cin>>p;
    int a[p],i=0;
    while(i<p){cin>>a[i];i++;}
    cin>>q;
    int b[q];
    i=0;
    while(i<q){cin>>b[i];i++;}
    int *a1,*b1,*c;
    a1= new int[p];
    b1= new int[q];
    a1=a;
    b1=b;
    c= new int[p+q];
    for(i=0;i<p+q;i++)
    {
        if(i<p)
            c[i]=a1[i];
        else
            c[i]=b1[i-p];
    }
    sort(c,c+p+q);
    for(i=0;i<p+q;i++)
    {
        if(c[i]==c[i+1])
            continue;
        else
            d++;
    }

    if(d==n)
        cout<<"I become the guy.";
    else
        cout<<"Oh, my keyboard!";

}
