//Language: GNU C++11


    #include <iostream>
    #include <algorithm>
    #include <string>
    #include <cmath>
    #include <set>
    using namespace std;

    int main()
    {
        int n, s = 0, d = 0, ar[1000];
        cin >> n;
        for (int i = 1; i <= n; i++)
        {
            cin >> ar[i];
        }
        int x = 0, z = 0;
        for (int i = 1; i <= n; i++)
        {
            s = 0, x = 0;
            for (int j = i+1; j <= n; j++)
            {
                if (ar[i] == ar[j])
                {   
                    s++;
                    z += j;
                }
                else
                    x++;
            }
            if (s > x)
            {
                if (d<s)
                    d = s;
            }
        }
        if (n % 2 != 0){
            if (n-d<=((n-1)/2))
                cout << "NO" << endl;
            else
                cout << "YES" << endl;
        }
        else
        {
            if (n-d<=(n/2))
                cout << "NO" << endl;
            else
                cout << "YES" << endl;
        }
    }