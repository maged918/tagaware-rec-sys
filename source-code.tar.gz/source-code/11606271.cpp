//Language: GNU C++11


#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
#include<deque>
#include<map>
#include<set>
#include<stdlib.h>
#include<math.h>
#include<queue>
#include<stack>
#include<functional>
using namespace std;
#define LL long long
#define si(x) scanf("%d",&x)
#define sc(x) scanf("%c",&x)
#define sl(x) scanf("%I64d",&x)
#define all(x) x.begin(),x.end()
#define compress(x) {sort(all(x));(x).resize(unique(all(x))-(x).begin());}
template<class T> inline void umax(T &a,T b){if(a<b) a = b ;}
typedef pair<int, int> ii;
typedef pair<LL, LL> PII;
typedef pair<int, ii> iii;
#define vl vector<ll>
#define vi vector<int>
#define vii vector<ii>
#define vvl vector< vl >
#define vvi vector< vi >
#define vvii vector< vii >
#define sz size()
#define pb push_back
#define F first
#define S second
#define mp make_pair
#define mem(x,y) memset(x,y,sizeof(x))
#define rep(i,a,b) for(int i=(a);i<(b);i++)
#define repv(i,b,a) for(int i=(b);i>=(a);i--)
#define mod 1000000007
#define pb push_back

const int maxn = 3*100000 + 5;
const LL MAX = 1e18;
const int INF  = 1e9 + 7;
const int N = 100000;


//const LL INF = 0x0123456789ABCDEFLL;
vector<LL> Div;
vector<LL> fact[1000005];
LL x;
map<LL , int> pos;
vector <LL>   go(LL k){
    vector<LL> lst , t1;
    if(k == 0) {
        lst.pb(x);
        return lst;
    }
    if(k == 1){
        lst = Div;
        return lst;
    }
    if(k&1) {
        lst = go(k - 1);
      //  rep(i,0,lst.sz) cout << lst[i] << " ";
        //cout << endl;
        for(LL i=0;i <lst.sz;i++){
            for(LL j=0;j<fact[pos[lst[i]] - 1].sz;j++){
                t1.pb(fact[pos[lst[i]] - 1][j]);
                if(t1.sz == N) return t1;
            }
        }
        return t1;
    }
    lst = go(k / 2);
    map<LL , LL > use1;
    for(int i=0;i<lst.sz; i++){
        if(use1[lst[i]] == 0) use1[lst[i]] = i + 1;
    }
    
    for(LL i=0;i<lst.sz;i++){
        for(LL m=0;m<fact[pos[lst[i]]-1].sz;m++){
        LL x = fact[pos[lst[i]] - 1][m];
        if(pos[x] == 1){
            t1.pb(x);
            if(t1.sz == N) return t1;
            continue;
        }
        LL y = Div[pos[x] - 2];
        LL l = use1[y] + 1;
        for(int j = l-1 ;j < use1[x];j++){
            t1.pb(lst[j]);
            if(t1.sz == N) return t1;
        } 

    }
    }
    return t1;
}

inline void solve(void){
        LL k;
        cin  >> x >> k;
        for(LL i = 1; i*i<=x; i++){
            if(x%i == 0){
                Div.pb(x/i);
                if(i!=x/i) Div.pb(i);
            }
        }
        sort(all(Div));
        for(LL i=0;i<Div.sz ;i++){
            pos[Div[i]] = i + 1;
            LL x = Div[i];
            for(int j=0;j<=i;j++){
                if(x%Div[j] == 0) fact[i].pb(Div[j]);
            }
        }
        vector<LL> res = go(k);
        rep(i,0,res.sz) cout << res[i] << " ";
        return;
}
void init() {
   ios::sync_with_stdio(false);
    cin.tie(nullptr);
}
int main(int argc, const char * argv[]){
    //freopen("rmq.in","r",stdin);
    //freopen("rmq.out","w",stdout);
    init();
    solve();
    return 0;
}
