//Language: GNU C++11


//In C<>de We Trust :D
#include <bits/stdc++.h>

using namespace std;

#define MohammadAmin main()
#define ll long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define pcc pair<char, char>
#define mpair make_pair
#define endl "\n"
#define c_false ios_base::sync_with_stdio(false)
#define pushb push_back
#define pushf push_front
#define popb pop_back
#define popf pop_front
#define sz size()
#define X first
#define Y second
#define ashar(a) cout << fixed << setprecision((a))
#define reset(a,b) memset(a, b, sizeof(a))
#define min(x, y) ((x) < (y) ? (x) : (y))
#define max(x, y) ((x) > (y) ? (x) : (y))
#define for0(a, n) for (int (a) = 0; (a) < (n); (a)++)
#define for1(a, n) for (int (a) = 1; (a) <= (n); (a)++)
#define rof0(a, n) for (int (a) = (n); (a) >= 0; (a)--)
#define For(i, a, n) for (int (i) = (a); (i) <= (n); (i)++)
#define rof(i, n, a) for (int (i) = (n); (i) >= (a); (i)--)
const ll INF = 1e9;
ll gcd (ll a, ll b) {return ( a ? gcd(b%a, a) : b );}
ll power(ll a, ll n) {ll p = 1;while (n > 0) {if(n%2) {p = p * a;} n >>= 1; a *= a;} return p;}


int MohammadAmin {
	c_false;
	int n, a, b, sum = 0;
	scanf("%d", &n);
	while(n--) {
		scanf("%d %d", &a, &b);
		if (sum + a <= 500) {
			printf("A"); sum += a;
		}else{
			sum -= b; printf("G");
		}
	}
	return 0;
}