//Language: GNU C++11


#include <iostream>
using namespace std;
# include<cmath>
# include<algorithm>
int main() {
    // your code goes here
    int n,i,j,k,l;
    cin>>n;
    int x[n],y[n],sum=0;
    for(i=0;i<n;i++)cin>>x[i]>>y[i];
    for(i=0;i<n-2;i++){
        for(j=i+1;j<n-1;j++){
            for(k=j+1;k<n;k++){
                if((y[j]-y[i])*(x[k]-x[i])!=(y[k]-y[i])*(x[j]-x[i])) sum++;
            }
        }
    }
    cout<<sum;
    return 0;
}