//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair

typedef pair<int, int> pii;
typedef long long ll;

string s;
int n;

ll solve(int l, int r) {
  ll bra = 0;
  ll tmp = s[l] - '0';
  for (int i = l + 1; i <= r; i += 2) {
    if (s[i] == '+') {
      bra += tmp;
      tmp = s[i + 1] - '0';
    } else if (s[i] == '*') {
      tmp *= s[i + 1] - '0';
    }
  }
  bra += tmp;
  ll res = 0;
  tmp = 1;
  for (int i = 1; i < n; i += 2) {
    if (i == l - 1) {
      tmp *= bra;
      i = r - 1;
    } else if (s[i] == '+') {
      res += tmp;
      tmp = s[i + 1] - '0';
    } else {
      tmp *= s[i + 1] - '0';
    }
  }
  res += tmp;
  return res;
}

int main() {
  ios_base::sync_with_stdio(false);
  cin >> s;
  s = "1*" + s + "*1";
  n = s.length();
  ll res = 0;
  for (int i = 0; i < n; ++i) {
    for (int j = i + 1; j < n; ++j) {
      if (s[i] == '*' && s[j] == '*') {
	res = max(res, solve(i + 1, j - 1));
      }
    }
  }
  cout << res << '\n';
  return 0;
}
