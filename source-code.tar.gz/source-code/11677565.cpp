//Language: GNU C++11


/*
 * A.cpp
 * Copyright (C) 2015 zhao <zhao@kamel-ThinkPad-X201>
 *
 * Distributed under terms of the MIT license.
 */

#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
#define REP(i, N) for (int i = 0; i < (int)N; i++)

int n;
int ratings[2010];
int main(){
  cin>>n;
  for(int i = 0; i < n; ++i){
    cin>>ratings[i];
  }
  for(int i = 0; i < n; ++i){
    int temp = 1;
    for(int j = 0; j < n; ++j){
      if(j == i) continue;
      if(ratings[j] > ratings[i]){
        temp++;
      }
    }
    cout<<temp;
    if(i < n - 1){
      cout<<" ";
    }
  }
  cout<<endl;
  return 0;
}
