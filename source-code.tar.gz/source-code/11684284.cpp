//Language: GNU C++11


#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <list>
#include <algorithm>
using namespace std;

#define nln        puts("")                         ///prllnewline
#define getll(a)  scanf("%d",&a);
#define max3(a,b,c) max(a,max(b,c))                  ///3 ta theke max
#define min3(a,b,c) min(a,min(b,c))                  ///3 ta theke min

#define FOR1(i,n)  for(ll i=1;i<=n;i++)
#define FOR0(i,n)  for(ll i=0;i<n;i++)                 ///looping
#define FORR(i,n)  for(ll i=n-1;i>=0;i--)
#define ALL(p)     p.begin(),p.end()

#define SET(p)     memset(p,-1,sizeof(p))
#define CLR(p)     memset(p,0,sizeof(p))            ///memset
#define MEM(p,v)   memset(p,v,sizeof(p))

#define READ(f)    freopen(f, "r", stdin)           /// file
#define WRITE(f)   freopen(f, "w", stdout)

#define SZ(c)      (ll)c.size()
#define PB(x)      push_back(x)                     ///STL defines
#define MP(x,y)    make_pair(x,y)
#define ff         first
//#define ss         second

#define LI         long ll
#define ll        long long
#define f64        long double
#define PI         acos(-1.0)                        ///PI er value

ll Set(ll N,ll pos)
{
    return N=N | (1<<pos);
}
ll reset(ll N,ll pos)
{
    return N= N & ~(1<<pos);
}
bool check(ll N,ll pos)
{
    return (bool)(N & (1<<pos));
}
void CI(ll &_x)
{
    scanf("%d",&_x);
}

void CO(ll &_x)
{
    cout<<_x;
}

template<typename T> void getarray(T a[],ll n)
{
    for(ll i=0; i<n; i++) cin>>a[i];
}
template<typename T> void prllarray(T a[],ll n)
{
    for(ll i=0; i<n-1; i++) cout<<a[i]<<" ";
    cout<<a[n-1]<<endl;
}

const double EPS=1e-9;                              ///constatnts
const ll INF=0x7f7f7f7f;

ll dr8[8]= {1,-1,0,0,1,-1,-1,1};            ///8 direction move
ll dc8[8]= {0,0,-1,1,1,1,-1,-1};
ll dr4[4]= {0,0,1,-1};                      ///4 direction move
ll dc4[4]= {-1,1,0,0};                      ///or adjacent dir.
ll kn8r[8]= {1,2,2,1,-1,-2,-2,-1};          ///knight moves
ll kn8c[8]= {2,1,-1,-2,-2,-1,1,2};
ll x[2005],y[2005];
ll gcd(ll a,ll b)
{

    if(b==0)return a;
    return gcd(b,a%b);
}
int main()
{
    ll i,j,k,n,m;
    cin>>n;
    FOR0(i,n)
    {
        cin>>x[i]>>y[i];
    }
    ll ans=(n*(n-1)*(n-2));
    ans/=6;
    ll ans2=0,g=0;
    for( i=0; i<n; i++)
    {

        vector<pair<ll,ll> >vp;

        for(ll j=0; j<n; j++)
        {
            if(i==j)continue;
            pair<ll,ll>p;
            p.first=x[j]-x[i];
            p.second=y[j]-y[i];

            g=gcd(p.first,p.second);
//                cout<<j<<" : "<<x<<" "<<y<<" "<<g<<"\n";
            p.first/=g;
            p.second/=g;
//                if(x<0)x*=-1,y*=-1;

            vp.push_back(p);
        }

        //
        sort(vp.begin(),vp.end());
        ll k=1;
        for( j=1; j<vp.size(); j++)
        {

            if(vp[j-1]!=vp[j])
            {
                ans2+=((k-1)*k)/2;
                k=1;
            }
            else
                k++;
//            ans2+=(k-1);
        }
                ans2+=((k-1)*k)/2;

    }
    ans2=ans2/3;

    cout<<ans-ans2<<"\n";
}
