//Language: GNU C++


#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <fstream>
#include <numeric>
#include <iomanip>
#include <bitset>
#include <list>
#include <stdexcept>
#include <functional>
#include <utility>
using namespace std;

#define PB push_back
#define MP make_pair

#define REP(i,n) for(i=0;i<(n);++i)
#define FOR(i,l,h) for(i=(l);i<=(h);++i)
#define FORD(i,h,l) for(i=(h);i>=(l);--i)

typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;
typedef long long LL;
typedef pair<int, int> PII;

char s1[10], s2[10], s3[20];
int x[10], y[10];

inline int f(char a) {
    if (a >= '0' && a <= '9')
        return a - '0';
    return a - 'A' + 10;
}

int ff(int xx[], int l, int jz) {
    int sum = 0;
    for (int i = 0; i < l; ++i) {
        sum = sum * jz + xx[i];
    }
    return sum;
}
int ans[1000];

int main() {
    memset(s3, 0, sizeof (s3));
    while (~scanf("%s", s3)) {
        memset(s1, 0, sizeof (s1));
        memset(s2, 0, sizeof (s2));
        for (int i = 0; i < strlen(s3); ++i) {
            if (s3[i] == ':') {
                for (int j = 0; j < i; ++j) {
                    s1[j] = s3[j];
                }
                for (int j = i + 1; j < strlen(s3); ++j) {
                    s2[j - i - 1] = s3[j];
                }
                break;
            }
        }
        int Max = 0;
        int bude = 0, bude2 = 0,flag1=0,flag2=0;

        int l1 = strlen(s1), l2 = strlen(s2);
        for (int i = 0; i < strlen(s1); ++i) {
            x[i] = f(s1[i]);
            if (x[i] != 0 || flag1) {//计算前导0比较失败，1、没计算  2、把后面的也计算了
                bude++;
                flag1=1;
            }
            Max = max(Max, x[i]);
        }
        for (int i = 0; i < strlen(s2); ++i) {
            y[i] = f(s2[i]);
            if (y[i] != 0 || flag2) {
                bude2++;
                flag2=1;
            }
            Max = max(Max, y[i]);
        }
        int t = Max + 1;
        //cout << "t=" << t << endl;
        int sum1 = ff(x, l1, t);
        int sum2 = ff(y, l2, t);
        if (sum1 >= 24 || sum2 >= 60) {
            puts("0");
            return 0;
        }
//                if (strcmp(s2, "00001")==0) {
//                    printf("bude1=%d\nbude2=%d\nsum1=%d\nsum2=%d\n", bude, bude2, sum1, sum2);
//                }
        if ((bude <= 1 && bude2 <= 1 && sum1 >= sum2) || (bude <= 1 && bude2 <= 1 && sum1 <= 23 && sum2 <= 59)) {//没考虑好前面是2位的情况
            //        if ( (bude <= 1 && bude2 <= 1 && sum1 <= 23 && sum2 <= 59 && sum1 >= sum2)) {
            puts("-1");
            return 0;
        }
        int pos = 0;
        while (1) {
            ans[pos++] = t;
            //cout<<t<<"-";
            t++;
            sum1 = ff(x, l1, t);
            sum2 = ff(y, l2, t);
            if (sum1 >= 24 || sum2 >= 60) {
                break;
            }
        }
        for (int i = 0; i < pos - 1; ++i) {
            printf("%d ", ans[i]);
        }
        printf("%d\n", ans[pos - 1]);
    }
}