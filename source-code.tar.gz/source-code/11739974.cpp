//Language: GNU C++


/*Bolot Bekbolotov*/
#include <bits/stdc++.h>
using namespace std;

const long long inf=1000000000;

int main()
{
    int k,i;
    string s;
    cin>>s;
    k=26;
    for(i=1;i<=s.length();i++)
    {
        k+=25;
    }
    cout<<k<<endl;

return 0;
}
