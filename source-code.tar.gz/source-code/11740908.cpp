//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

int cnt[111], n;

char st[111][111];

int F[111];

//int dp(int j) {
//  if (j == n) {
//    
//  }
//}

int main() {
  #ifdef DEBUG
  freopen("in.txt", "r", stdin);
  #endif
  
  scanf("%d", &n);
  int f = 0, cnt = 0;
  for (int i = 0; i < n; i++) {
    scanf("%s", st[i]);
    int g = 1;
    for (int j = 0; st[i][j]; j++) {
      if (st[i][j] == '0') f = 1;
      g &= st[i][j] == '1';
    }
    cnt += g;
  }
  if (!f) {
    cout << n << '\n';
  } else {
    int mx = -1, id = -1;
    for (int i = 0; i < n; i++) {
      int cn = 0;
      for (int j = 0; j < n; j++) {
        if (!strcmp(st[i], st[j])) cn++;
      }
      if (mx < cn) {
        mx = cn;
        id = i;
      }
    }
    cout << max(mx, cnt) << endl;
  }
  return 0;
}