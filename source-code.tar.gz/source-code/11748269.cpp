//Language: GNU C++11


#include<iostream>
#include<vector>
#include<cstdio>
#include<algorithm>
#include<utility>
#include<set>
#include<map>
#include<cstring>
#include<cmath>
#include<string>
#include<cstdlib>


using namespace std;

void cout_v(vector<long long >&a)
{
    long long n=a.size();
    for(long long i=0;i<n;i++)
    {
        cout<<a[i]<<" ";
        if(i!=n-1)
        {
            continue;
        }
        else
            cout<<endl;
    }
}

void cin_v(vector<long long >&a)
{
    
    long long n=a.size();
    for(long long i=0;i<n;i++)
    {
        cin>>a[i];
    }
    
}


long long pow_mod(long long a,long long b,long long m)
{
    long long res=1;
    while(b>0)
    {
        if(b%2==1)
            res=(res*a)%m;
        b=b/2;
        a=(a*a)% m;
    }
    return res;
}

long long InverseEuler(long long n, long long m)
{
    return pow_mod(n,m-2,m);
}

long long C(long long n, long long r, long long m)
{
    vector<long long> f(n + 1,1);
    for (long long i=2; i<=n;i++)
        f[i]= (f[i-1]*i) % m;
    return (f[n]*((InverseEuler(f[r],m) * InverseEuler(f[n-r],m)) % m)) % m;
}

#define MOD 1000000007


const long long MAX = 1000000005;


vector<long long> presum;

long long dp_solve(vector<long long>arr,long long ind,long long n)
{
    if(ind==0)
        return 1;
    n--;
    long long val=C(n,arr[ind]-1,MOD);
    long long ans=(val*dp_solve(arr,ind-1,n-(arr[ind]-1)));
    return ans%MOD;
}

int main()
{
    long long n;
    cin>>n;
    vector<long long>a(n);
    
    
    for(long long i=0;i<n;i++)
    {
        cin>>a[i];
    }
    
    presum.resize(n+1);
    
    presum[0]=0;
    for(long long i=1;i<=n;i++)
    {
        presum[i]=presum[i-1]+a[i-1];
    }
    
    long long vn=presum[n];
    
    cout<<dp_solve(a,n-1,vn)<<endl;
    
    
    return 0;
}