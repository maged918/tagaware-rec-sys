//Language: GNU C++


/* HellGeek */
/* Shiva Bhalla */
/* iit2012077 */
 
#include<stdio.h>
#include<vector>
#include<map>
#include<utility>
#include<algorithm>
#include<set>
#include<string>
#include<string.h>
#include<time.h>
#include<iostream>
#include<queue>
#include<stack>
#include<math.h>

#define LL long long
#define FIT(i,t) for(i=0;i<t;i++)
#define REP(i,a,b) for(i=a;i<=b;i++)
#define fi first
#define se second
#define v vector
#define pii pair<int,int>
#define pll pair<long long , long long>
#define MOD 1000000007


using namespace std;

LL dp[1005][1005];
LL ar[1005];
LL n,k;
LL sum[1005];
LL nc[1005][1005];

LL ncr(){ 
   LL i,j,l,m,t;
   
   nc[0][0] = 0;
   
   for(i=0;i<=1001;i++) {
                        for(j=0;j<=i;j++) {
                                          if(i==j || j==0)
                                          nc[i][j] = 1;
                                          else 
                                          nc[i][j] = (nc[i-1][j-1]+nc[i-1][j])%MOD;
                        }
   }
}

LL func(LL ind, LL pr) {
           
           if(ind == n) {
                  if(pr==k) {
                            return 1;
                  }
                  else
                  return 0;
           }
           
           if(dp[ind][pr]!=-1)
           return dp[ind][pr];
           
           LL i,j,l,m,t;
           
           l = 0;
           l = func(ind+1,pr);
           if(sum[pr+1]<=ind+1)
           l = (l+(func(ind+1,pr+1)*nc[ind-sum[pr]][ar[pr+1]-1])%MOD)%MOD;
          /* for(i=ind+1;i<=n;i++) {
                               if(sum[pr+1]<=i) {
                                                l = (l+(func(i,pr+1)*nc[i-sum[pr]-1][ar[pr+1]-1])%MOD)%MOD;
                               }
           }*/
           //cout << ind << " " << pr << " " << l << endl;
           return dp[ind][pr] = l;
}
           
int main()
{
    LL i,j,l,m,t;
    ncr();
    cin >> k;
    n = 0;
    
    for(i=1;i<=k;i++)
    {
                    cin >> ar[i];
                    n = n + ar[i];
    }
    memset(dp,-1,sizeof dp);
    
    sum[0] = 0;
    
    for(i=1;i<=k;i++)
    sum[i] = sum[i-1] + ar[i];

    k = func(0,0);
    
    cout << k << endl;
    
     
    return 0;
}
