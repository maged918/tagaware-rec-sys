//Language: GNU C++


/*
 *	@url : http://codeforces.com/contest/554/problem/A
 */

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <string.h>
#include <limits.h>
#include <vector>
#include <map>
#include <set>
#include <list>
#include <stack>
#include <queue>
#include <string>
#include <numeric>
#include <algorithm>

/* Macros start */
#define MAX(a,b)         	((a < b) ?  (b) : (a))
#define BIGGEST(a,b,c)   	((MAX(a,b) < c) ?  (c) : (MAX(a,b)))
#define MIN(a,b)         	((a < b) ?  (a) : (b))
#define LEAST(a,b,c)		((MIN(a,b) < c) ? (MIN(a,b)) : (c))
#define RESET(arr, value) 	memset(arr, value, sizeof(arr)) //Remember, value can be {0,-1}
#define ALL(v) 			 	(v).begin(), (v).end()
#define SZ(v) 			 	((int)(v).size())
#define DREP(a)             sort(all(a)); a.erase(unique(all(a)),a.end())
#define FOR(c,it) 			for(typeof((c).begin()) it = (c).begin(); it != (c).end(); it++)
#define RFOR(c,rit) 		for(typeof((c).rbegin()) rit = (c).rbegin(); rit != (c).rend(); rit++)
#define MAXSIZE 100
/* Macros end */

using namespace std;
/* Typedefs*/
typedef long long 					ll;
typedef unsigned long long 			ull;
typedef pair<int, int> 				ii;
typedef vector<int> 				vi;
typedef vector<ii> 					vii;
typedef vector<vi> 					vvi;

int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	
	set<string> s;
	string str;
	cin >> str;
    int len = str.length();
    for(char c = 'a'; c <= 'z' ; c++){
    	for(int i = 0; i < len ; i++){
			ostringstream os;
    		os << str.substr(0,i);
			os << c;
			os << str.substr(i, len-i);
			s.insert(os.str());
		}
		ostringstream os;
    	os << str;
		os << c;
		s.insert(os.str());
    }
    cout << s.size() << '\n';
	return 0;
}