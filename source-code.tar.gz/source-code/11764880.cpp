//Language: GNU C++11


#include<bits/stdc++.h>

using namespace std;

typedef long long int ll ;

 long long int   n , dp[55] = {0} ;

 ll k ;

 char s[55] ={'\0'};

 ll fibo ( int  p ) {

if( dp[p] != 0 ){
        return dp[p] ;
    }

    if( p < 2 ){
        return ( dp[p] = 1 ) ;
    }

    return ( dp[p] = fibo(p-2) + fibo(p-1) ) ;

 }

void find_kth_per(  int index , long long int kth ) {

    //cout<<index<< "  " << kth <<endl;
    int i ;
    if ( index <= 0 ){return ;}
    //cout<<index<< "  " << dp[index-1]<<endl;
    if( kth <= dp[index-1] ){
           //cout<<"H"<<endl;

        s[n-index] = '1' ;
        int l = strlen(s) ;
        find_kth_per( index-1 , kth ) ;

        for ( i = l ; i <  strlen(s) ; i++ ){

            s[i] = s[i] + 1 ;
            //cout<<s[i]<< " ";

        }//cout<<endl;
       // s[i] = '\0' ;
    }
    else{
       //cout<<"e"<<endl;
        s[n-index] = '2' ;
        s[n-index+1] = '1' ;

        int l = strlen(s);

        find_kth_per( index-2 , kth-dp[index-1] ) ;

        for ( int i = l ; i <  strlen(s) ; i++ ){

            s[i] = s[i] + 2 ;

        }
        // s[i] = '\0' ;
    }


}

int main (  ) {

    cin>>n>>k;

    //cout<<n<<k<<" "<<endl;
    //ll num = fib( n ) ;
    dp[0] = 1 ;

    fibo( n ) ;

    /*cout<< fibo( n ) ;*/

    /*for( int i = 1 ; i <= n ;i++ ){
        cout<<dp[i]<<" ";
    }cout<<endl;*/

    find_kth_per(  n , k ) ;

    for ( int i = 0 ; i < strlen(s) ; i++ ){

        cout<<s[i]-'0'<<" ";
    }cout<<endl;

    return 0;

}
