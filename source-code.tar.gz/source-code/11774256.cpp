//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;
int low(int x){
    int counter = 0;
    for(int i=x;i>0;i/=2){
        if(i%2 == 1) return counter;
        else counter++;
    }

}

int main()
{
   int sum,limit;
   cin>>sum>>limit;
   vector<int> lows(limit);
   for(int i = 1;i <= limit; i++){
        lows[i-1] = pow(2,low(i));
   }
   vector<int>index;
   int s = sum;
   for(int i=lows.size()-1;i>=0;i--){
    if(s - lows[i] >= 0){
        s= s-lows[i];
        index.push_back(i+1);
    }
    if(s == 0)break;
   }
    if(index.size() == 0 || s != 0) cout<<"-1"<<endl;
    else   { cout<<index.size()<<endl;
            for(int i=0;i<index.size();i++) cout<<index[i]<<" ";
            cout<<endl;

    }



}
