//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
long long p,q,r,m,n,i,j,k,res,ok[100010],cnt,x,val;
vector<long long>v;
string s;
set<long long>st;
map<int,int>mmm,mm;
int main()
{
    ios_base::sync_with_stdio(0);

    cin>>n>>p;
    for(i=0;i<p;i++)
    {
        cin>>x;
        for(j=0;j<x;j++)
        cin>>ok[j];

        if(ok[0]==1)
            {
               for(j=1;j<x;j++)
               if(ok[j]!=ok[j-1]+1)
               break;
               else
               cnt++;
               res=res+(x-j);
            }
        else
        res=res+(x-1);
    }
    val=n-1+res-cnt;
    cout<<val;
}
