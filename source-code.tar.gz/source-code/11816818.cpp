//Language: GNU C++11


#include<bits/stdc++.h>
#include<limits.h>
#define LL long long

using namespace std;

int e[100][100][100],vis[100];
int n,m,q;
void dfs(int u, int c){
    if(vis[u] == c) 
    return;
    vis[u]=c;
    for(int i=0;i<n;i++)
    {
        if(e[u][i][c]) 
        dfs(i,c);
    }
}
int main(){
    cin >> n >> m;
    for(int i=0;i<m;i++)
    {
        int u,v,c;
        cin >> u >> v >> c;
        u--; v--; c--;
        e[u][v][c]=e[v][u][c]=1;
    }
    cin >> q;
    while(q--){
        int u,v,ans=0;
        cin >> u >> v;
        u--; v--;
        memset(vis,-1,sizeof vis);
        for(int i=0;i<m;i++){
            dfs(u,i);
            if(vis[v] == i) 
            ans++;
        }
        cout << ans << "\n";
    }
    return 0;
}