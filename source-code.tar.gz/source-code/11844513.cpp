//Language: GNU C++


#include <iostream>
using namespace std;

char tb[12][12];
int main()
{
    int n,m;
    cin >> n >> m;
    for (int i = 0; i < n; i++)
    {
        string t;
        cin >> t;
        for (int j = 0; j < m; j++)
        {
            tb[i+1][j+1] = t[j];
        }
    }
    n++;
    m++;
    int anw = 0;
    for (int i = 1; i < n; i++)
    {
        for (int j = 1; j < m; j++)
        {
            if (tb[i][j] == 'W')
            {
                if (tb[i+1][j] == 'P' || tb[i-1][j] == 'P')
                {
                    anw++;
                    tb[i][j] = '.';
                }
                else if (tb[i][j+1] == 'P' || tb[i][j-1] == 'P')
                {
                    anw++;
                    tb[i][j] = '.';
                }
            }
        }
    }
    cout << anw << endl;
}
