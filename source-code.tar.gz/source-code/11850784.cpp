//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;

//#pragma comment (linker, "/STACK:256000000")

typedef long long ll ;
typedef vector<ll> VI ;
typedef pair<ll,ll>  PP;
typedef vector<PP>  VPP ;

#define endl '\n'
#define  MP make_pair
#define PB push_back
#define F first
#define S second
#define sz(x) ((int)(x).size())
#define rep(i,n) for(i=0;i<n;i++)
#define rep1(i,n) for(i=1;i<=n;i++)
#define fileio freopen("in.txt","r",stdin); freopen("out.txt","w",stdout);
#define boost  ios_base::sync_with_stdio(false);cin.tie(0);
#define trace1(x)                cerr << #x << ": " << x << endl;
#define trace2(x, y)             cerr << #x << ": " << x << " | " << #y << ": " << y << endl;
#define trace3(x, y, z)          cerr << #x << ": " << x << " | " << #y << ": " << y << " | " << #z << ": " << z << endl;

int mod = 1e9 + 7 ;
int powmod(ll a,int b) {ll res=1;if(a>=mod)a%=mod;for(;b;b>>=1){if(b&1)res=res*a;if(res>=mod)res%=mod;a=a*a;if(a>=mod)a%=mod;}return res;}
ll gcd(ll a , ll b){return b==0?a:gcd(b,a%b); }

/*---------------------------------------------------------------------------------------------------------------------------------------------------------------*/
/*                                                              SNIPPETS DONE
/*---------------------------------------------------------------------------------------------------------------------------------------------------------------*/

struct island {
	              ll from , to ; int index ;
				   
};

bool comp(island a , island b)
{
	if(a.to==b.to) return a.from > b.from ;
     return a.to < b.to ;
}


set<pair<ll,int> >  S ;

island a[200005] ;


int ans[200005];

int main()
{
       boost ;	
	int i , j ; ll  l , r, pr , pl ;
	int flag = 1 ;
	ll x ;
	int n , m ;
	cin >> n >> m ;
	
	cin >> pl >> pr ;
	
	rep1(i,n-1)
	{
		cin >> l >> r ;
		a[i].index = i ;
		a[i].from = l-pr ;
		a[i].to = r-pl ;
		pl = l ; pr = r ;
	}
	
	
	sort(&a[1],&a[n],comp);
	
	rep1(i,m)
	{
		cin >> x ;
		S.insert(MP(x,i));
	}
	
	typeof(S.begin()) it ;
	
	S.insert(MP(1e18+100,0));
	rep1(i,n-1)
	{
		it = S.lower_bound(MP(a[i].from,0));
       
       if((it->F)<=a[i].to){
	    ans[a[i].index] = it->S ;
	    S.erase(it);
       }
	   else {flag = 0 ;break ;}
	
	}
	
	if(flag==0) cout<<"No\n";
	else 
	{   cout<<"Yes\n";
		rep1(i,n-1) cout<<ans[i]<<" ";
	}
	
	
	
	return 0 ;
}
