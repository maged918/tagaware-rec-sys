//Language: GNU C++11


#include <bits\stdc++.h>
using namespace std;
typedef long long ll;
typedef vector<int> Vint;
#define pb push_back
#define mp make_pair

void solve(int n)
{
    int w;
    cin >> w;
    Vint a(2 * n);

    for (int i = 0; i < 2 * n; i++)
        scanf(" %d", &a[i]);

    ll ans = 2 * w;
    sort(a.begin(), a.end());

    int x2_value = (int)2e9 + 10;
    x2_value = min(a[0] * 2, a[n]);

    ans = min(ans, (ll)x2_value * 3 * n);

    printf("%.10f\n", (double)(ans / 2.0));
}

int main()
{
    #ifndef ONLINE_JUDGE
    freopen("input.txt", "rt", stdin);
    freopen("output.txt", "w", stdout);
    #endif

    int n, m;
    while (cin >> n)
        solve(n);
}
