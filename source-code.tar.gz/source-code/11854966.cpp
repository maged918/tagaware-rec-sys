//Language: GNU C++


#include<iostream>
#include<algorithm>
#include<set>
#include<cmath>
#include<queue>
#include<sstream>
#include <iomanip>
#include<map>
#include <vector>
#include<algorithm>
using namespace std;
#define ll  long long

ll n,w,a[200010];
double jav;
std::stringstream ss;
int main(){
	cout.precision(7);
	cin>>n>>w;
	for(int i=1;i<=2*n;i++){
		cin>>a[i];
	}
	sort(a+1,a+2*n+1);
	if(a[1]*2<=a[n+1])jav=a[1];
	else jav=double(a[n+1])/2;
	if(jav*3*n<=w)cout<<jav*3*n;
	else{
		cout<<w;
	}
}
