//Language: GNU C++


#include<cstdio>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<map>
#include<queue>
#include<iostream>
#define LL long long
#define INF 99999999
#define EPS 1e-9
//using namespace std;
const int N = 1e5 + 10;
int a[N * 2];
int main(){
	int n,w;
	while(scanf("%d%d",&n,&w) == 2){
		for(int i = 1; i <= n + n; i++)
			scanf("%d",&a[i]);
		std::sort(a + 1, a + 1 + n + n);
		double Min = a[1], Max = a[n + 1];
		if(Min * 2 > Max)
			Min = Max / 2; 
		else{
			if(Max > 2 * Min)
				Max = Min * 2;
		}
		if(Max * n + Min * n  >= w)
			printf("%d\n",w);
		else
			printf("%f\n",Max * n + Min * n);
	} 
	return 0;
}
