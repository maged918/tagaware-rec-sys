//Language: GNU C++11


#include <cstdio>
#include <cstring>
#include <climits>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;

#define Nmax 100002
#define inf INT_MAX

struct picior{
    int lg, cost;
}v[Nmax];

vector < int > V;

bool cmp ( picior x, picior y ){
    return x.lg < y.lg;
}

priority_queue <int> Heap;

int main(){

   /* freopen ( "date.in", "r", stdin );
    freopen ( "date.out", "w", stdout );*/

    int N, sol = inf, sum = 0;
    vector < int > :: iterator it;

    scanf ( "%d", &N );

    for ( int i = 1; i <= N; ++i )
        scanf ( "%d", &v[i].lg );

    for ( int i = 1; i <= N; ++i ){
        scanf ( "%d", &v[i].cost );
        sum += v[i].cost;
    }

    sort ( v + 1, v + N + 1, cmp );

    int st = 1, dr = 1, cate = 0, now;

    while ( st <= N ){
        cate = 0;
        now = 0;

        while ( v[st].lg == v[dr].lg ){
            now += v[dr].cost;
            cate++;
            dr++;
        }

        int nr = 0;
        while ( !Heap.empty() && nr != cate-1 ){
            now += Heap.top();
            V.push_back ( Heap.top() );
            nr++;
            Heap.pop();
        }

        if ( sum - now < sol )
            sol = sum - now;

        for ( it = V.begin(); it < V.end(); ++it )
            Heap.push( *it );
        V.clear();

        while ( st < dr ){
            Heap.push ( v[st].cost );
            st++;
        }
    }


    printf (  "%d", sol );

    return 0;
}
