//Language: GNU C++11


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cassert>
using namespace std ;

typedef long long LL ;

int main() {
	LL n , a , b , m ;
	while(cin>>n >> a >> b) {
		while(n--) {
			cin>>m ;
			if(a == b) {printf("Both\n") ; continue ;}
			LL l = min(a , b) , r = m*(min(a , b)) ;
			while(l < r) {
				LL mid = (l+r)>>1 ;
				if(mid/a + mid/b >= m) r = mid ;
				else l = mid+1 ;
			}
			if(r%a == 0 && r%b == 0) printf("Both\n") ;
			else if(r%a == 0) {
				printf("Vova\n") ;
			}else {
				printf("Vanya\n") ;
			}
		}
	}
}

	    	   	 								 		 		 		  	