//Language: GNU C++


#include <iostream>

using namespace std;
int k, v[26];
char s[101];
int main()
{
    cin>>k>>s;
    for(int i=0; s[i]!='\0'; i++)
        v[s[i]-'a']=1;
    int dist = 0;
    for(int i=0; i<26; i++)
        dist += v[i];
    if(dist<k){
        cout<<"NO";
        return 0;
    }
    cout<<"YES";
    for(int i=0; s[i]!='\0'; i++){
        if(k>0 and v[s[i]-'a']==1){
            cout<<'\n';
            k--;
            v[s[i]-'a'] = 2;
        }
        cout<<s[i];
    }
    return 0;
}
