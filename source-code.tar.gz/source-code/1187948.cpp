//Language: MS C++


#include<stdio.h>
#include<iostream>
using namespace std;
#define MINI(a,b) ((a)<(b)?(a):(b))
#define MAXI(a,b) ((a)>(b)?(a):(b))
int main()
{
    long n, k, l, c, d, p, nl, np;
    cin>>n>>k>>l>>c>>d>>p>>nl>>np;
    long ans = 1000000;
    ans = MINI( (k*l)/nl,MINI(c*d, p/np));
    ans /= n;
    cout<<ans<<endl;
    return 0;
}
