//Language: GNU C++


#include<iostream>
using namespace std;
int n,k,l,c,d,p,nl,np;
int MIN(int a,int b){return a<b?a:b;}
int main()
{
	#ifndef ONLINE_JUDGE 
		ifstream cin("cf.in");
		ofstream cout("cf.out");
	#endif
	cin>>n>>k>>l>>c>>d>>p>>nl>>np;
	cout<<MIN(k*l/nl,MIN(c*d,p/np))/n<<endl;
	return 0;
}
