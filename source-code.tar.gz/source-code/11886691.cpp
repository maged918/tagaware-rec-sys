//Language: GNU C++


#include <iostream>

using namespace std;

int main()
{ int a, b, c, d,n,x;

cin >> n;
x=n+1;
while (true)
{a=x/1000;
b=(x/100)%10;
c=(x/10)%10;
d=x%10;
if (a!=b&&a!=c&&a!=d&&b!=c&&b!=d&&c!=d)
{
    break;
}
else
    x++;
}
cout << x << endl;



    return 0;
}
