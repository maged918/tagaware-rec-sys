//Language: GNU C++11


#include<bits/stdc++.h>

using namespace std;

// Shortcuts for "common" data types in contests
typedef long long int ll;
typedef vector<int> vi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef set<int> si;
typedef map<string, int> msi;
// To simplify repetitions/loops, Note: define your loop style and stick with it!
#define s(i) scanf("%d",&i)
#define sl(i) scanf("%ld",&i)
#define sll(i) scanf("%lld",&i)
#define REP(i, a, b) \
for (int i = int(a); i <= int(b); i++) // a to b, and variable i is local!
#define NREP(i,a,b) \
for (int i = int(a); i >= int(b); i--)
#define TRvi(c, it) \
for (vi::iterator it = (c).begin(); it != (c).end(); it++)
#define TRvii(c, it) \
for (vii::iterator it = (c).begin(); it != (c).end(); it++)
#define TRmsi(c, it) \
for (msi::iterator it = (c).begin(); it != (c).end(); it++)
#define MOD 1000000007 // 2 billion

int dp[2009][2009] , n , h , a[2009] ;

int memoize( int no , int  opened )
{
    if( no == n && opened == 0 )
        return 1;
    if( no == n || opened < 0 )
        return 0;
    if( dp[no][opened] != -1 )
        return dp[no][opened];
    int ans = 0;
    if( a[no] + opened == h )
        ans += ( ( opened * 1ll * memoize( no + 1 , opened - 1 ) ) % MOD + memoize( no + 1 , opened ) ) % MOD;
    ans %= MOD;
    if( a[no] + opened + 1 == h )
        ans += ( memoize( no + 1 , opened + 1 )  + ( ( opened  + 1 ) * 1ll * memoize( no + 1 , opened ) ) % MOD ) % MOD;
    ans %= MOD;
    return dp[no][opened] = ans;
}

int main()
{
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
    s( n ) ; s( h );
    REP( i , 0 , n - 1 )
        s(a[i]);
    memset( dp , -1 , sizeof( dp ) );
    int ans = memoize( 0 , 0 );
    printf("%d\n",ans);
    return 0;
}
