//Language: GNU C++11


#include <iostream>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <string>
#include <cmath>
#include <memory.h>
#include <stack>
#include <cstdio>
#include <unordered_map>
#include <map>
#include <queue>
#include <set>
using namespace std;

/*
*/

int n, m, K;
vector<int> l;
vector<int> r;
vector<vector<int> > aut;
vector<string> s;
vector<int> val;
vector<int> val2;
map<pair<int, int> , int> mp;
//vector<vector<vector<vector<vector<vector<int> > > > > >dp;
int dp[200][200][501][2][2];
vector<vector<vector<int> > > LCP;

int sol(int cur, int st, int k, int L, int R, int P)
{
	if (cur == r.size()) if (k >= 0) return 1; else return 0;
	if (k < 0) return 0;
	if (dp[cur][st][k][L][R] != -1) return dp[cur][st][k][L][R];
	int start = 0;
	int end = m-1;
	if (L == 1) start = l[cur];
	if (R == 1) end = r[cur];
	long long sm = 0;
	for (int i = start; i <= end; i++)
	{
		int newL = L;
		if (i > start) newL = 0;
		int newR = R;
		if (i < end) newR = 0;
		int nP = (i > 0) || P;
		if (nP)
			sm += sol(cur+1, aut[st][i], k-val[aut[st][i]], newL, newR, nP);
		else
			sm += sol(cur+1, 0, k, newL, newR, nP);
		sm %= 1000000007;
	}
	return dp[cur][st][k][L][R] = sm;
}

void gen(int i, int j)
{
	if (mp.count(make_pair(i, j))) return;
	int sz = mp.size();
	aut.push_back(vector<int> (m));
	mp[make_pair(i, j)] = sz;
	val.push_back(-1);
	int v = 0;
	for (int x = 0; x < m; x++)
	{
		int mx = -1;
		int in = -1;
		for (int k = 0; k < n; k++)
		{
			int cur = LCP[k][i][s[k].size()+j];
			if (cur == s[k].size()) v += val2[k];
			while (cur > 0 && (cur == s[k].size() || s[k][cur] != x)) cur = LCP[k][k][cur-1];
			if (s[k][cur] == x) cur++;
			if (cur > mx)
			{
				mx = cur;
				in = k;
			}
		}
		gen(in, mx);
		aut[sz][x] = mp[make_pair(in, mx)];
	}
	v /= m;
	val[sz] = v;
}

vector<int> prefix_function (string &a, string &b) {
	string S(a.size() + b.size() + 1, '.');
	for (int i = 0; i < a.size(); i++) S[i] = a[i]+'a';
	for (int i = 0; i < b.size(); i++) S[a.size() + 1+i] = b[i]+'a';
	int n = (int) S.size();
	vector<int> pi (n);
	for (int i=1; i<n; ++i) {
		int j = pi[i-1];
		while (j > 0 && S[i] != S[j])
			j = pi[j-1];
		if (S[i] == S[j])  ++j;
		pi[i] = j;
	}
	return pi;
}

int main()
{
	cin>>n>>m>>K;
	int len;
	cin>>len;
	l = vector<int> (len);
	for (int i = len-1; i >= 0; i--) cin>>l[i];
	cin>>len;
	r = vector<int> (len);
	for (int i = 0; i < len; i++) cin>>r[i];
	while (l.size() < r.size()) l.push_back(0);
	reverse(l.begin(), l.end());
	val2 = vector<int> (n);
	s = vector<string> (n);
	LCP = vector<vector<vector<int> > > (n, vector<vector<int> > (n));
	for (int i = 0; i < n; i++)
	{
		cin>>len;
		
		s[i] = string(len, '.');
		for (int j = 0; j < len; j++)
		{
			int x;
			cin>>x;
			s[i][j] = x;
		}
		cin>>val2[i];
	}
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n; j++)
		{
			LCP[i][j] = prefix_function(s[i], s[j]);
		}
	}
	gen(0, 0);
	//dp = vector<vector<vector<vector<vector<vector<int> > > > > >(r.size(), vector<vector<vector<vector<vector<int> > > > >(mp.size() , vector<vector<vector<vector<int> > > >(K+1, vector<vector<vector<int> > >(2, vector<vector<int> >(2, vector<int> (2, -1))))));
	memset(dp, -1, sizeof(dp));
	cout<<sol(0, 0, K,1,1, 0)<<endl;

}