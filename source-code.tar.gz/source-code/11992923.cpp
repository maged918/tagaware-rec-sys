//Language: GNU C++11


#include<iostream>
#include<cstdio>
using namespace std;
const int Maxn=1e5+100,mod=1e9+7;int n,m,f[2*Maxn];
int find(int x){return f[x]==x?x:f[x]=find(f[x]);}
void merge(int x,int y){x=find(x);y=find(y);if(x!=y)f[x]=y;}
int main(int argc, const char * argv[]) {
    ios::sync_with_stdio(0);
    int i;cin>>n>>m;
    for(i=1;i<=2*n;i++)f[i]=i;
    for(i=1;i<=m;i++){int a,b,c;cin>>a>>b>>c;if(c==1){if(find(a+n)==find(b)||find(b+n)==find(a)){puts("0");return 0;}merge(a,b);merge(a+n,b+n);}else{if(find(a)==find(b)){puts("0");return 0;}merge(a+n,b);merge(a,b+n);}}
    int cnt=0;for(i=1;i<=n;i++){
        if(f[i]==i)cnt++;}cnt--;
    int ans=1,base=2;while(cnt){if(cnt&1){ans=1LL*ans*base%mod;}
        base=1LL*base*base%mod;cnt>>=1;}
    printf("%d\n",ans);
    return 0;
}
