//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;

typedef struct ttrie {
    int nr;
    ttrie *a[26];
    ttrie() { memset(a,0,sizeof(a)); nr=0; }
}*trie;

int i,n,k,nr=1,Win[100005],Lose[100005];
string s;
trie root;

void Insert() {
    int i,n=s.length();
    trie aux=root;
    for(i=0;i<n;++i)
    {
      if(!aux->a[s[i]-'a']) aux->a[s[i]-'a']=new ttrie;
      aux=aux->a[s[i]-'a']; aux->nr=++nr;
    }
}

void dfs(trie x) {
    bool u=0;
    for(int i=0;i<26;++i)
    if(x->a[i]) {
                  u=1; dfs(x->a[i]);
                  if(!Win[x->a[i]->nr]) Win[x->nr]=1;
                  if(!Lose[x->a[i]->nr]) Lose[x->nr]=1;
                }

    if(!u) Lose[x->nr]=1,Win[x->nr]=0;
}

int main()
{
  ios_base::sync_with_stdio(0);

  root=new ttrie;

  cin>>n>>k; getline(cin,s);
  while(n--) getline(cin,s),Insert();

  dfs(root);

  if(!Win[0]) return cout<<"Second\n",0;

  if(Lose[0]) return cout<<"First\n",0;

  cout<<(k&1 ? "First":"Second")<<'\n';

 return 0;
}
