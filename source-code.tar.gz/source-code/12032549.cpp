//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int maxd=7000;
#define int long long
vector<int>divs;
vector<int>v[maxd];

int kkk=1e5+5;
vector<int>res;
void doo(int ind,int t){
    int sz=res.size();
    if(sz>=kkk)
        return;
    if(!ind){
        res.push_back(1);
        return;
    }
    if(t==1){
        for(int i=0;i<v[ind].size();i++)
            res.push_back(divs[v[ind][i]]);
        return;
    }
    for(int i=0;i<v[ind].size();i++)
        doo(v[ind][i],t-1);
}
main(){
    int n,maxpos=1e5+5,tim;
    ios::sync_with_stdio(false);
    cin>>n>>tim;
    if(!tim){
        cout<<n<<endl;
        return 0;
    }
    tim=min(maxpos,tim);
    tim--;
    for(int i=1;i*i<=n;i++){
        if(n%i==0){
            divs.push_back(i);
            if(i*i!=n)
                divs.push_back(n/i);
        }
    }
    sort(divs.begin(),divs.end());
    if(!tim){
        for(int i=0;i<divs.size();i++)
            cout<<divs[i]<<" ";
        return 0;
    }
    for(int i=0;i<divs.size();i++){
        for(int j=0;j<divs.size();j++){
            if(divs[i]%divs[j]==0)
                v[i].push_back(j);
        }
    }
    for(int i=0;i<divs.size();i++)
        doo(i,tim);
    for(int i=0;i<res.size() && i<1e5;i++)
        cout<<res[i]<<" ";
    return 0;
}
