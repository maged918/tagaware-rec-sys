//Language: GNU C++


#include<cstdio>
using namespace std;

#define SIZE 1000006

int A[SIZE], C[SIZE], L[SIZE], R[SIZE];

void solve(int n, int &l, int &r)
{
    int m = 0, maxC = 0, minLen = 0, i;

    for(i = 1; i<=n; ++i)
    {
        C[A[i]]++, R[A[i]] = i;
        if(!L[A[i]])
            L[A[i]] = i;

        if(m<A[i])
            m = A[i];
    }

    for(i = 1; i<=m; ++i)
        if(maxC<C[i])
            maxC = C[i], minLen = R[i]-L[i]+1, l = L[i], r = R[i];
        else if(maxC==C[i] && minLen>R[i]-L[i]+1)
            minLen = R[i]-L[i]+1, l = L[i], r = R[i];
}

int main()
{
    int n, l, r, i;

    scanf("%d", &n);
    for(i = 1; i<=n; ++i)
        scanf("%d", A+i);

    solve(n, l, r);
    printf("%d %d\n", l, r);

    return 0;
}
