//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

int main(){
  // freopen("input.txt", "r", stdin);
  // int t;
  // cin>>t;
  // while(t--){
    int n;
    cin>>n;
    vector<pair<int, int> >sump, summ;
    for(int i = 0; i < n; i++){
      int x, a;
      cin>>x>>a;
      if(x<0){
        x *= -1;
        summ.push_back(make_pair(x,a));
      }else{
        sump.push_back(make_pair(x,a));
      }
    }
    int countm = summ.size();
    int countp = sump.size();
    sort(summ.begin(), summ.end());
    sort(sump.begin(), sump.end());
    bool right = true;
    int max_ans = 0;
    int i = 0, j = 0;
    int ans = 0;
    while(1){
      if(right == true){
        if(i >= countp) break;
        ans += sump[i].second;
        i++;
        right = false;
      }
      else{
        if(j >= countm) break;
        ans += summ[j].second;
        j++;
        right = true;
      }
    }
    right = false;
    i = 0; j = 0;
    max_ans = max(ans, max_ans);
    ans = 0;
    while(1){
      if(right == true){
        if(i >= countp) break;
        ans += sump[i].second;
        i++;
        right = false;
      }
      else{
        if(j >= countm) break;
        ans += summ[j].second;
        j++;
        right = true;
      }
    }
    max_ans = max(ans, max_ans);
    cout<<max_ans<<endl;
  // }
  return 0;
}
