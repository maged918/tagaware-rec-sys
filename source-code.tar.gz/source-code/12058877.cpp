//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

typedef ostringstream OSS;
typedef istringstream ISS;

typedef long long LL;
typedef pair<int, int> PII;

typedef vector<int> VI;
typedef vector<VI> VVI;
typedef vector<LL> VLL;
typedef vector<VLL> VVLL;
typedef vector<double> VD;
typedef vector<VD> VVD;
typedef vector<string> VS;
typedef vector<VS> VVS;
typedef vector<bool> VB;
typedef vector<VB> VVB;
typedef vector<PII> VPII;

#define fst first
#define snd second
// #define Y first
// #define X second
#define MP make_pair
#define PB push_back
#define EB emplace_back 
#define ALL(x) (x).begin(),(x).end()
#define RANGE(x,y,maxX,maxY) (0 <= (x) && 0 <= (y) && (x) < (maxX) && (y) < (maxY))
#define DUMP( x ) cerr << #x << " = " << ( x ) << endl
#define rep(i, N) for (int i = 0; i < (int)(N); i++)
#define REP(i, init, N) for (int i = (init); i < (int)(N); i++)

template < typename T > inline T fromString(const string &s) { T res; ISS iss(s); iss >> res; return res; };
template < typename T > inline string toString(const T &a) { OSS oss; oss << a; return oss.str(); };

const int INF = 0x3f3f3f3f;
const LL INFL = 0x3f3f3f3f3f3f3f3fLL;
const double DINF = 0x3f3f3f3f;
const int DX[]={1,0,-1,0},DY[]={0,-1,0,1};
const double EPS = 1e-12;
//const double PI = acos(-1.0);

int main(void) {
    int n;
    cin >> n;
    VI as(n);
    for (auto &a : as) cin >> a;

    VI bs(n);
    rep(i, n) {
        int x = __builtin_clz(as[i]);
        bs[i] = 32 - x - 1;
    }

    int cnt = 0;
    int p0 = 0;
    while (true) {
        bool flg = true;

        rep(i, n) {
            int j = (i + 1) % n;
            
            if (bs[i] - cnt < 0 || bs[j] - cnt < 0) {
                flg = false;
                break;
            }

            if (!((as[i] >> (bs[i] - cnt) & 1) ==
                (as[j] >> (bs[j] - cnt) & 1))) {
                flg = false;
                break;
            }
        }

        if (!flg) break;
        p0 <<= 1;
        p0 |= as[0] >> (bs[0] - cnt) & 1;
        ++cnt;
    }

    int ans = INF;
    int plim = *max_element(ALL(as));
    int pb0 = 32 - __builtin_clz(p0) - 1;
    for (int p = p0; p <= plim; p <<= 1) {
        int pb = 32 - __builtin_clz(p) - 1;
        int c = 0;
        rep(i, n) {
            int a = as[i];
            int b = bs[i];
            a = a & ~(p0 << (b - pb0));
            if (a) {
                int b2 = 32 - __builtin_clz(a);
                c += b2;
                c += abs(pb - (b - b2));
            } else {
                c += abs(pb - b);
            }
        }
        ans = min(c, ans);
    }

    cout << ans << endl;



	return 0;
}
