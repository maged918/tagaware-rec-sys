//Language: GNU C++


#include <cstdio>
#include <queue>
using namespace std;

int main()
{
    bool admis[100];
    int nb_etudiants;
    int nb_sujets;
    char notes[100][102];
    
    scanf("%d%d", &nb_etudiants, &nb_sujets);
    for (int i=0; i<nb_etudiants; i++)
    {
        admis[i] = false;
        scanf("%s", notes[i]);
    }
    
    for (int i=0; i<nb_sujets; i++)
    {
        queue<int> id;
        for (int j=0; j<nb_etudiants; j++)
        {
            if (!id.empty() && notes[id.front()][i] < notes[j][i])
                while (!id.empty()) id.pop();
            if (id.empty() || notes[id.front()][i] == notes[j][i])
                id.push(j);
        }
        while (!id.empty())
        {
            admis[id.front()] = true;
            id.pop();
        }
    }
    
    int nb = 0;
    for (int i=0; i<nb_etudiants; i++)
        if (admis[i])
            nb++;
    printf("%d", nb);
}
