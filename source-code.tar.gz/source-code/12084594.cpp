//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int const MAX = 1e5 + 10;
int next[MAX], le[MAX], t[MAX], num[MAX];
char s[MAX];

void get_next()
{
    int i = 0, j = -1;
    next[0] = -1;
    while(s[i] != '\0')
    {
        if(j == -1 || s[i] == s[j])
        {
            i ++;
            j ++;
            next[i] = j;
        }
        else
            j = next[j];
    }
}

int main()
{
    scanf("%s", s);
    int len = strlen(s);
    get_next();
    for(int i = 1; i <= len; i++)
        num[i] = 1;
    for(int i = len; i >= 0; i--)
        if(next[i])
            num[next[i]] += num[i];
    int cnt = 0;
    le[cnt] = len;
    t[cnt ++] = 1;
    len = next[len];
    while(len)
    {
        le[cnt] = len;
        t[cnt ++] = num[len];
        len = next[len];
    }
    printf("%d\n", cnt);
    for(int i = cnt - 1; i >= 0; i--)
        printf("%d %d\n", le[i], t[i]);
}


    	  	   			 	 				 		   	  	