//Language: GNU C++


#include <iostream>
#include <sstream>
#include <limits.h>
#include <algorithm>
#include <vector>
#include <math.h>
#include <set>
#include <string>
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <map>
#define SI(x) scanf("%d", &x)
#define vi vector<int>
#define PB push_back
#define PI(x) printf("%d\n", x)
#define rep(i, n) for(int i=0;i<n;i++)
#define repx(i,x,n) for(int i=x;i<n;i++)
#define endl "\n"
typedef long long LL;
typedef long long int LLI;
using namespace std;
struct sort_pred {
    bool operator()(const pair<int, int> &left, const pair<int, int> &right) {
        return left.second < right.second;
    }
};
struct convert {
    void operator()(char& c) { c = toupper((unsigned char)c); }
};
struct convertd {
    void operator()(char& c) { c = tolower((unsigned char)c); }
};
int gcd(int a, int b) {
    return b ? gcd(b, a % b) : a;
}

struct lol {
    int min_start;
    int max_end;
    int cnt;
};
map < int, lol > m;
int main()
{
    //ios::sync_with_stdio(false);
    int n;
    SI(n);
    int maxx = 0;
    for (int i = 0; i < n; i++){
        int tmp;
        SI(tmp);
        if (m.find(tmp) == m.end())
        {
            lol t;
            t.cnt = 0;
            t.min_start = 1000000;
            t.max_end = 0;
            m[tmp] = t;
        }
        if (m[tmp].min_start > i){
            m[tmp].min_start = i;
        }
        if (m[tmp].max_end < i){
            m[tmp].max_end = i;
        }
        m[tmp].cnt++;
        if (m[tmp].cnt > maxx)
            maxx = m[tmp].cnt;
    }
    map< int, lol >::iterator it;
    int min_diff=1000000;
    int res = 0;
    for (it = m.begin(); it != m.end(); ++it){
        if (it->second.cnt == maxx){
            {
                if ((it->second.max_end - it->second.min_start) <= min_diff)
                {
                    res = it->first;
                    min_diff = it->second.max_end - it->second.min_start;
                }
            }
        }
    }
    cout << m[res].min_start + 1<< " "<<m[res].max_end + 1 << endl;
    return 0;
}