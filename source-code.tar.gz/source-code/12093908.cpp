//Language: MS C++


#include <stdio.h>
#include <iostream>
#include <hash_map>

using namespace std;

typedef long long ll;

int arr[520000];

int add[720];
int segm_cnt;
hash_map <int, int> lb[720], rb[720];

void Build(int sz){
    segm_cnt = sz / 720 + (sz % 720 != 0);
    for (int segm = 0; segm < segm_cnt; ++segm)
        for (int i = segm * 720; i < (segm + 1) * 720; ++i){
            if (lb[segm].find(arr[i]) == lb[segm].end())
                lb[segm][arr[i]] = i;
            rb[segm][arr[i]] = i;
        }
}

void RebuildSegm(int segm){
    lb[segm].clear();
    rb[segm].clear();
    for (int i = segm * 720; i < (segm + 1) * 720; ++i){
        if (lb[segm].find(arr[i]) == lb[segm].end())
            lb[segm][arr[i]] = i;
        rb[segm][arr[i]] = i;
    }
}

void SegmAdd(int l, int r, ll x){
    int segm_id = 0, s_left = 0;
    while (s_left < l){
        s_left += 720;
        ++segm_id;
    }
    if (l < s_left){
        for (int i = min(r, s_left - 1); i >= l; --i){
            arr[i] += x;
            arr[i] = min(arr[i], 1000000005);
        }
        RebuildSegm(segm_id - 1);
    }
    int s_right = s_left + 719;
    if (s_right <= r){
        add[segm_id] += x;
        while (s_right + 720 <= r){
            ++segm_id;
            s_right += 720;
            add[segm_id] += x;
            add[segm_id] = min(add[segm_id], 1000000005);
        }
        if (r > s_right){
            for (int i = s_right + 1; i <= r; ++i){
                arr[i] += x;
                arr[i] = min(arr[i], 1000000005);
            }
            RebuildSegm(segm_id + 1);
        }
    }
    else{
        for (int i = r; i >= s_left; --i){
            arr[i] += x;
            arr[i] = min(arr[i], 1000000005);
        }
        RebuildSegm(segm_id);
    }
}

int Calc(int val){
    int left = -1, right = -1;
    for (int i = 0; i < segm_cnt; ++i)
        if (rb[i].find(val - add[i]) != rb[i].end())
            right = rb[i][val - add[i]];
    if (right == -1)
        return -1;
    for (int i = segm_cnt - 1; i >= 0; --i)
        if (lb[i].find(val - add[i]) != lb[i].end())
            left = lb[i][val - add[i]];
    return right - left;
}

int main(){
    int n, q;
    scanf("%d%d", &n, &q);
    for (int i = 0; i < n; ++i)
        scanf("%d", &arr[i]);
    Build(n);

    for (int quest = 0; quest < q; ++quest){
        int type;
        scanf("%d", &type);
        if (type == 1){
            int l, r, x;
            scanf("%d%d%d", &l, &r, &x);
            SegmAdd(l - 1, r - 1, x);
        }
        else{
            int need;
            scanf("%d", &need);
            printf("%d\n", Calc(need));
        }
    }
    return 0;
}
