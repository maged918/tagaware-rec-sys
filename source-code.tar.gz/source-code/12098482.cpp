//Language: GNU C++11


#include <bits/stdc++.h>
#define ll long long int

using namespace std;

set< pair<ll, ll> > s;

int main()
{
	ios_base::sync_with_stdio(0);
	int h,q,hi,ans;
	ll start=1,end,l,r,val;
	cin>>h>>q;
	for(int i=0;i<h-1;i++)
		start*=2;
	end=(start*2);
	while(q--)
	{
		cin>>hi>>l>>r>>ans;
		r++;
		for(int i=hi;i<h;i++)
		{
			l=l*2;
			r=r*2;
		}
		if(ans==1)
		{
			start=max(start,l);
			end=min(end,r);
		}
		else
			s.insert(make_pair(l,r));
	}
	s.insert(make_pair(end,end));
	val=0;
	for(auto it=s.begin();it!=s.end();it++)
	{
		if(end<=start)
			break;
		if(start<(it->first))
		{
			if(val||start+1<(it->first))
			{
				cout<<"Data not sufficient!\n";
				return 0;
			}
			val=start;
		}
		start=max(start,(it->second));
	}
	if(!val)
		cout<<"Game cheated!\n";
	else
		cout<<val<<"\n";
	return 0;
}