//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int k,a,b,v,sec,Count;
int main()
{
    while(scanf("%d %d %d %d",&k,&a,&b,&v) != EOF)
    {
        Count = 0;
        while(a > 0)
        {
            if(b >= k)
            {
                sec = k;
                b -= (k - 1);
            }
            else
                if(b != 0)
                {
                    sec = b + 1;
                    b = 0;
                }
                else
                    sec = 1;
            a -= sec * v;
            Count++;
            //printf("%d %d %d %d\n",k,a,b,v);
        }
        printf("%d\n",Count);
    }
    return 0;
}
