//Language: GNU C++


#include <iostream>
#include <string>



int main(){

    std::string input;

    int length;
    std::cin >> length;//unused
    std::cin >> input;
    int count = 0;

    for(int i = 1; i < input.length(); i++){

        if(input.at(i) == input.at(i-1)){

            count++;

        }

    }

    std::cout << count;



}
