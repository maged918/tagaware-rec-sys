//Language: GNU C++


#include <iostream>
#include <cstdio>

#define INF (~(1<<(8*sizeof(int)-1)))

int main() {
	int n, m, xc, yc, k, i;
	scanf("%d%d", &n, &m);
	scanf("%d%d", &xc, &yc);
	scanf("%d", &k);

	int x = xc, y = yc;
	long long int steps = 0;
	
	for (i = 0; i < k; ++i) {
		int dx, dy;
		scanf("%d%d", &dx, &dy);

		int nr_valid = INF;
		if (dx > 0) {
			int z = (n - x) / dx;
			if (z < nr_valid) nr_valid = z;
		} else if (dx < 0) {
			int z = (x - 1) / (-dx);
			if (z < nr_valid) nr_valid = z;
		}

		if (dy > 0) {
			int z = (m - y) / dy;
			if (z < nr_valid) nr_valid = z;
		} else if (dy < 0) {
			int z = (y - 1) / (-dy);
			if (z < nr_valid) nr_valid = z;
		}
		
		x += dx*nr_valid;
		y += dy*nr_valid;
		steps += nr_valid;
	}


	std::cout << steps << std::endl;

	return 0;
}