//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cmath>
#include <cstring>
using namespace std;
#define N 1000000
typedef long long ll;
double a[N];
int main()
{
    int i;
    int n;
    double w,sum;
    scanf("%d%lf",&n,&w);
    for(i=0;i<n*2;i++)
    scanf("%lf",&a[i]);
    sort(a,a+n*2);
    double p,q;
    p=a[0];
    q=a[n];
    if(p*2<=q)
    {
        sum=n*(p+p*2);
        if(sum<=w)
        sum=n*(p+p*2);
        else
        sum=w;
    }
    else
    {
        sum=n*(q/2+q);
        if(sum<=w)
        sum=n*(q/2+q);
        else
        sum=w;
    }
   printf("%.7f\n",sum);
    return 0;
}
