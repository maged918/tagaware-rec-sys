//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int a[100001], b[100001], c[100001], d[201], f[100001], p[100001], cont[100001];
struct node  {
    int x, val;
    bool operator < (node X) const  {
        return x < X.x;
    }
}E[100001];
int main()
{
    int n;
    while(scanf("%d", &n) != EOF)  {
        memset(f, 0, sizeof(f));
        memset(d, 0, sizeof(d));
        memset(cont, 0, sizeof(cont));
        for(int i = 0; i < n; i++)  scanf("%d", &a[i]);
        for(int i = 0; i < n; i++)  scanf("%d", &b[i]);
        for(int i = 0; i < n; i++)  E[i].x = a[i], E[i].val = b[i], f[a[i]] += b[i], cont[a[i]]++;
        sort(E, E+n);
        sort(a, a+n);
        int cnt = 0;
        c[cnt++] = a[0];
        for(int i = 1; i < n; i++)  if(a[i] != a[i-1])  c[cnt++] = a[i];
        p[c[cnt-1]] = 0;
        for(int i = cnt-2; i >= 0; i--)  p[c[i]] = p[c[i+1]]+f[c[i+1]];
        int ans = 1<<30, cc = 0, k = 0;
        for(int i = 0; i < cnt; i++)  {
            int aux = p[c[i]], m = cont[c[i]];
            k += cont[c[i]];
            //for(int j = 0; j <= i; j++)  k += cont[c[j]];
            //printf("aux is %d %d %d\n", aux, k, m);
            for(cc; E[cc].x != c[i]; cc++)  {
                d[E[cc].val]++;
            }
            int num = 2*m-1;
            if(k/2+1 > m) {
                int v = k-num;
                for(int l = 0; l <= 200; l++)  if(d[l])  {
                    if(d[l] >= v)  {  aux += l*v;  break;  }
                    else  aux += l*d[l], v -= d[l];
                }
            }
            ans = min(aux, ans);
        }
        printf("%d\n", ans);
    }
}