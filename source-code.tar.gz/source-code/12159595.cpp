//Language: GNU C++11


#include<iostream>
using namespace std;

int main()
{
    int n,a,b,c,d,e,f,x,y,z;
    cin>>n;
    cin>>a>>b>>c>>d>>e>>f;
    x=min(b,n-c-e);
    y=min(d,n-x-e);
    z=n-x-y;
    cout<<x<<" "<<y<<" "<<z<<" ";
}