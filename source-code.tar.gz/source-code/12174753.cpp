//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
int main(){
    int a1,b1,a2,b2,a3,b3;
    cin>>a1>>b1>>a2>>b2>>a3>>b3;
    //a2+a3<=a1 || <=b1
    int f=0;
    if(a2+a3<=a1){
        if(b2<=b1 && b3<=b1)f=1;//cout<<"YES\n";
    }
    if(a2+a3<=b1){
        if(b2<=a1 && b3<=a1)f=1;//cout<<"YES\n";
    }
    if(a2+b3<=a1){
        if(b2<=b1 && a3<=b1)f=1;//cout<<"YES\n";
    }
    if(a2+b3<=b1){
        if(b2<=a1 && a3<=a1)f=1;//cout<<"YES\n";
    }
    if(b2+a3<=a1){
        if(a2<=b1 && b3<=b1)f=1;//cout<<"YES\n";
    }
    if(b2+a3<=b1){
        if(a2<=a1 && b3<=a1)f=1;//cout<<"YES\n";
    }
    if(b2+b3<=a1){
        if(a2<=b1 && a3<=b1)f=1;//cout<<"YES\n";
    }
    if(b2+b3<=b1){
        if(a2<=a1 && a3<=a1)f=1;//cout<<"YES\n";
    }
    if(f)cout<<"YES\n";
    else{
        cout<<"NO\n";
    }   
    return 0;
}
/*
    */