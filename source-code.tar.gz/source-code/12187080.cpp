//Language: GNU C++


#include<bits/stdc++.h>
 
#define     ll          long long int
#define     D               double
#define     LD              long double
 
#define     sd(n)       scanf("%d",&n)
#define     ss(n)       scanf("%s",n)
#define     sc(n)       scanf("%c",&n)
#define     sl(n)       scanf("%ld",&n)
#define     sll(n)      scanf("%lld",&n)
 
#define     fr(i,a,b)       for(ll i=a;i<b;i++)
 
#define     max(a,b)        ((a)>(b)?(a):(b))
#define     min(a,b)        ((a)<(b)?(a):(b))
 
#define     p(n)        printf("%d",n)
#define     pl(n)       printf("%ld",n)
#define     pll(n)      printf("%lld",n)
#define     pbl(n)      printf("\n")
 
#define     mp              make_pair
#define     vi              vector<ll>
#define     pb              push_back
#define     s               second
#define     f               first
#define     mod             1000000007
using namespace std;
inline ll getn(){
    ll n=0, c=getchar();
    while(c < '0' || c > '9')
        c = getchar();
    while(c >= '0' && c <= '9')
        n = (n<<3) + (n<<1) + c - '0', c = getchar();
    return n;
}
bool go(ll i,ll j,ll a,ll b)
{
    if((i>=a&&j>=b)||(j>=a&&i>=b))
    return 1;
    else
    return 0;
    
}

int main()
{
        std::ios_base::sync_with_stdio(0);
ll n,m,p,q,r,s,mi,ma,mip,map,mar,mir;
n=getn();
m=getn();
p=getn();
q=getn();
r=getn();
s=getn();

mi=min(n,m);
ma=max(n,m);
mip=min(p,q);
map=max(p,q);
mar=min(r,s);
mir=max(r,s);
ll firmi,firma,secmi,secma;
    firmi=mi-mip;
    firma=map;
    secmi=ma-map;
    secma=mi;
    //printf("%lld %lld %lld %lld \n",firmi,firma,secmi,secma);
    bool check=0;
    if(firmi>=0&&secmi>=0)
    {
    
    check+=go(firmi,firma,r,s);
    check+=go(secmi,secma,r,s);
    }
    
    firmi=mi-map;
    firma=mip;
    secmi=ma-mip;
    secma=mi;
//  printf("%lld %lld %lld %lld \n",firmi,firma,secmi,secma);
    //check=0;
    if(firmi>=0&&secmi>=0)
    {
    
    check+=go(firmi,firma,r,s);
    check+=go(secmi,secma,r,s);
    }
    firmi=ma-mip;
    firma=map;
    secmi=mi-map;
    secma=ma;
//printf("%lld %lld %lld %lld \n",firmi,firma,secmi,secma);
    // check=0;
    if(firmi>=0&&secmi>=0)
    {
    
    check+=go(firmi,firma,r,s);
    check+=go(secmi,secma,r,s);
    }
    firmi=ma-map;
    firma=mip;
    secmi=mi-mip;
    secma=ma;
    //printf("%lld %lld %lld %lld \n",firmi,firma,secmi,secma);
    //bool check=0;
    if(firmi>=0&&secmi>=0)
    {
    
    check+=go(firmi,firma,r,s);
    check+=go(secmi,secma,r,s);
    }
    
    if(check)
    printf("YES\n");
    else
    printf("NO\n");
    return 0;
}