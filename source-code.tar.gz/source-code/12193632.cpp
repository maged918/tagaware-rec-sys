//Language: GNU C++11


//by Tanmay Chaudhari
#define _CRT_SECURE_NO_WARNINGS
//#pragma comment(linker, "/STACK:66777216")
#include <bits/stdc++.h>
using namespace std;

#define si(a)				scanf("%d",&a)
#define sl(a)				scanf("%lld",&a)
#define pi(a)				printf("%d\n",a)
#define pl(a)				printf("%lld\n",a)

typedef long long			ll;
typedef vector<int>			vi;
typedef pair<int, int>		ii;
typedef vector<vi>			vvi;
typedef vector<ii>			vii;
//freopen("input.txt","r",stdin);
//freopen("output.txt","w",stdout);

#define SET(a,b)			memset(a,b,sizeof(a))	
#define forall(i,a,b)		for(int i=a; i<b; i++)
#define forrev(i,a,b)		for(int i=a; i>=b; i--)
#define forr(it,container)  for(typeof(container.begin()) it=container.begin();it!=container.end();it++)
#define w(t)				int t;si(t);while(t--)

#define TRACE

#ifdef TRACE
#define trace1(x)                cerr << #x << ": " << x << endl;
#define trace2(x, y)             cerr << #x << ": " << x << " | " << #y << ": " << y << endl;
#define trace3(x, y, z)          cerr << #x << ": " << x << " | " << #y << ": " << y << " | " << #z << ": " << z << endl;
#define trace4(a, b, c, d)       cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << endl;
#define trace5(a, b, c, d, e)    cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << endl;
#define trace6(a, b, c, d, e, f) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << endl;

#else

#define trace1(x)
#define trace2(x, y)
#define trace3(x, y, z)
#define trace4(a, b, c, d)	
#define trace5(a, b, c, d, e)
#define trace6(a, b, c, d, e, f)

#endif

#define N 1<<20
const int MOD = 1000000007;
vii arr;
ll fact[N], invfact[N], dp[1 << 20];

ll powmod(ll a, ll b)
{
	ll res = 1;
	while (b)
	{
		if (b & 1)
			res = (res*a) % MOD;
		a = (a*a) % MOD;
		b >>= 1;
	}
	return res;
}

void precompute()
{
	fact[0] = 1;
	forall(i, 1, 300000)
		fact[i] = (fact[i - 1] * i) % MOD;
	invfact[300000 - 1] = powmod(fact[300000 - 1], MOD - 2);
	for (int i = 300000 - 2; i >= 0; i--)
		invfact[i] = (invfact[i + 1] * (i + 1)) % MOD;
}

ll ncr(ll n, ll r)
{
	if (n < r)
		return 0;
	ll res = fact[n];
	res = (res*invfact[r]) % MOD;
	res = (res*invfact[n - r]) % MOD;
	return res;
}

int main()
{
	precompute();
	int h, w, n;
	si(h); si(w); si(n);
	
	forall(i, 0, n)
	{
		ii temp;
		si(temp.first);  si(temp.second);
		arr.push_back(temp);
	}

	arr.push_back(ii(1, 1));
	arr.push_back(ii(h, w));
	sort(arr.begin(), arr.end());
	dp[0] = 1;

	for (int i = 1; i < n + 2; i++)
	{
		dp[i] = ncr(arr[i].first + arr[i].second - 2, arr[i].first - 1);
		for (int j = 1; j < i; j++)
		{
			if (arr[j].first <= arr[i].first && arr[j].second <= arr[j].second)
			{
				ll temp = ncr(arr[i].first - arr[j].first + arr[i].second - arr[j].second, arr[i].first - arr[j].first);
				temp = (temp*dp[j]) % MOD;
				dp[i] = (dp[i] + MOD - temp) % MOD;
			}
		}
	}

	pl(dp[n + 1]);
	return 0;
}