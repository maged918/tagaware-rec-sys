//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
#define eps 1e-8

int main()
{
	double r,x,y,x1,y1;
	int m,n;
	while(scanf("%lf%lf%lf%lf%lf",&r,&x,&y,&x1,&y1)!=EOF)
	{
		double dis;
		dis=sqrt((x1-x)*(x1-x)+(y1-y)*(y1-y));
		n=(int)(dis/(2*r));
		if((dis-n*2*r)>eps)
			n++;
		printf("%d\n",n);
	}

	return 0;
}
	  		 	 	    		   		 	 		     	