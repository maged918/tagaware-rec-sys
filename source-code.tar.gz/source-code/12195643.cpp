//Language: GNU C++11


#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <assert.h>
#include <string.h>
using namespace std;

#define MAXN ((int)1e6+5)

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
#ifndef ONLINE_JUDGE
#pragma warning (disable : 4996)
    freopen("input.txt", "rt", stdin);
    //freopen("output.txt", "wt", stdout);
#endif

    long long r, c, s;
    cin >> r >> c >> s;

    long long stpsr = 0, stpsc = 0;
    if(r-1!=0)
        stpsr = (r - 1) / s;
    if(c-1!=0)
        stpsc = (c - 1) / s;

    long long remRs = r - (stpsr*s + 1);
    long long remCs = c - (stpsc*s + 1);
    long long consumedCells = (stpsr + 1)*(stpsc + 1);

    cout << ((remRs+1) * (remCs + 1))*consumedCells << endl;
}