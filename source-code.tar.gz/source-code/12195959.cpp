//Language: MS C++


#include<iostream>
#include<cstdio>
using namespace std;
int fa[105][105];
int find(int x,int z)
{
	if(fa[x][z]!=x)
	fa[x][z]=find(fa[x][z],z);
	return fa[x][z];
}
void merge(int x, int y,int z){
    int fax = find(x,z), fay = find(y,z);
    fa[fax][z] = fay;
}

int main()
{
	int n,m;
	cin>>n>>m;
     int a,b,c; 
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	fa[i][j]=i; 
	for(int i=1;i<=m;i++)
	{
		cin>>a>>b>>c;
		merge(a,b,c);
	}
	
	
	int q; int x,y;
	cin>>q;
	for(int i=1;i<=q;i++) 
	{
		cin>>x>>y;
		int ans=0;
		for(int i=1;i<=m;i++)
		if(find(x,i)==find(y,i))ans++;
		cout<<ans<<endl; 
	}
	return 0;
}











		  		 		 	 	   	 	 		 	 	 				