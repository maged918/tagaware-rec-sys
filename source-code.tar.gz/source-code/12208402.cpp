//Language: GNU C++


#include <bits/stdc++.h>

#define PB push_back
#define SZ(c) ll((c).size())
#define ALL(c) (c).begin(), (c).end()
#define CONTAINS(c, x) ((c).find(x)!=(c).end())
#define REP(i, c) for(ll i=0; i<c; i++)
#define foreach(it, c) for(__typeof((c).begin()) it=(c).begin(); it!=(c).end(); it++)
#define WAIT cout<<flush, system("PAUSE")
using namespace std;
typedef long long ll;
#define MOD
#define xx first
#define yy second

namespace Intervals{
    typedef pair<ll, ll> pii;
    pii curr;
    set<pii> S;
    set<pii>::iterator it;
    
    void print(pii p){ cout<<"["<<p.xx<<","<<p.yy<<"]"<<endl; }
    void printall(){
        cout << "-----------------ALL-------------------" << endl;
        foreach(it, S) print(*it);
        cout << "--------------END OF ALL---------------" << endl;
    }
    void intersection(pii p){
        //cout << "Intersecting with ", print(p);
        while(!S.empty()){
            curr = *S.begin();
            S.erase(S.begin());
            curr.xx = max(curr.xx, p.xx);
            if (curr.xx <= curr.yy){
                S.insert(curr);
                break;
            }
        }
        while(!S.empty()){
            curr = *S.rbegin();
            S.erase(*S.rbegin());
            curr.yy = min(curr.yy, p.yy);
            if (curr.xx <= curr.yy){
                S.insert(curr);
                break;
            }
        }
        //printall();
    }
    void difference(pii p){
        //cout << "Substracting ", print(p);
        while((it = S.lower_bound(pii(p.xx, -1))) != S.end()){
            curr = *it;
            S.erase(it);
            curr.xx = max(curr.xx, p.yy+1);
            if (curr.xx <= curr.yy){
                it = (S.insert(curr)).first;
                break;
            }
        }
        if (it == S.begin()) return;
        curr = *(--it);
        S.erase(it);
        if (curr.yy > p.yy){
            S.insert(pii(curr.xx, p.xx-1));
            S.insert(pii(p.yy+1, curr.yy));
        }else   S.insert(pii(curr.xx, min(curr.yy, p.xx-1)));
        //printall();
    }   
};
using namespace Intervals;

// lets solve 312 D
ll H, Q, lvl, L, R, op;
ll fst(ll x){ return x*(1ll<<(H-lvl)); }
ll lst(ll x){ return x*(1ll<<(H-lvl)) + (1ll<<(H-lvl)) - 1; }

int main(){
   ios_base::sync_with_stdio(0);
   cin.tie(0);
   
    cin >> H >> Q;
    lvl = 1;
    S.insert(pii(fst(1), lst(1)));
    
    while(Q--){
        cin >> lvl >> L >> R >> op;
        curr = pii(fst(L), lst(R));
        
        if (op==1)  intersection(curr);
        else            difference(curr);
    }
    if (S.empty()) cout << "Game cheated!" << endl;
    else if (SZ(S)==1 && (S.begin()->yy == S.begin()->xx)) 
        cout << S.begin()->xx << endl;
    else cout << "Data not sufficient!" << endl;
}














