//Language: GNU C++11


#define _CRT_SECURE_NO_WARNINGS
#include<bits\stdc++.h>
using namespace std;
#define For(i,a,b) for(int i=a;i<b;i++)
#define all(v)     (v).begin(),(v).end()
#define sz(v)      (ll) (v).size()
#define ll  long long
#define mem(a,val) memset(a,val,sizeof(a))
#define sc1(n) scanf("%I64d",&n)
#define sc2(n,m) scanf("%I64d %I64d",&n,&m)
#define sc3(n,m,x) scanf("%I64d %I64d %I64d",&n,&m,&x)
#define pf1(n) printf("%I64d",n)
#define pf2(n,m) printf("%I64d %I64d",n,m)
#define pf  printf
#define sc scanf
#define mp make_pair
#define endl '\n'
#define d(x) {cerr <<#x <<" = " <<x <<endl; }
#define d2(x,y) {cerr <<#x <<" = " <<x << ", "<<#y<<" = "<< y <<endl; } 
#define d3(x,y,z) {cerr <<#x <<" = " <<x << ", "<<#y<<" = "<< y << ", " << #z << " = " << z <<endl; }
#define dp(a){cerr<<#a<<" = first :"<<a.first<<"  , second : "<<a.second<<endl;;}
#define dv(x) {cerr <<#x <<" = ";for(int i=0;i<sz(x);i++) cerr <<x[i] <<", "; cerr <<endl; }
#define Max 0x3f3f3f3f3f3f3f3fLL
typedef pair<ll, ll>pii;
typedef vector<ll>vi;
typedef vector<pii>vp;
typedef vector<string>vs;
inline void hoba(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
}
int main(){
    //hoba();
    ll n, m, a, b, c;
    sc2(n, m);
    map<ll, char>arr;
    For(i, 0, m){
        sc3(a, b, c);
        if (arr[a] || arr[b] || arr[c]){
            if (arr[a] == '1'){
                arr[b] = '2';
                arr[c] = '3';
            }
            else if (arr[a] == '2'){
                arr[b] = '1';
                arr[c] = '3';
            }
            else if (arr[a] == '3'){
                arr[b] = '1';
                arr[c] = '2';
            }
            else if (arr[b] == '1'){
                arr[a] = '2';
                arr[c] = '3';
            }
            else if (arr[b] == '2'){
                arr[a] = '1';
                arr[c] = '3';
            }
            else if (arr[b] == '3'){
                arr[a] = '1';
                arr[c] = '2';
            }
            else if (arr[c] == '1'){
                arr[a] = '2';
                arr[b] = '3';
            }
            else if (arr[c] == '2'){
                arr[a] = '1';
                arr[b] = '3';
            }
            else if (arr[c] == '3'){
                arr[a] = '2';
                arr[b] = '1';
            }
        }
        else{
            arr[a] = '1';
            arr[b] = '2';
            arr[c] = '3';
        }
    }
    for (auto i : arr)
        cout << i.second << " ";

    return 0;
}