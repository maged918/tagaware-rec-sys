//Language: GNU C++


#include<cstdio>
#include<map>
#include<iostream>
using namespace std;
int l[305],c[305];
map<int,int> dp;
int gcd(int x,int y){	return x%y?gcd(y,x%y):y; }
int main(){
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;++i) scanf("%d",&l[i]);
	for(int i=0;i<n;++i) scanf("%d",&c[i]);
	int k=l[0];
	for(int i=1;i<n;++i) k=gcd(k,l[i]);
	if(k!=1) printf("-1\n");
	else{
		for(int i=0;i<n;++i){
			if(dp[l[i]]) dp[l[i]]=min(dp[l[i]],c[i]);
			else dp[l[i]]=c[i];
			map<int,int>::iterator j;
			for(j=dp.begin();j!=dp.end();++j){
				int g=gcd(l[i],j->first);
				if(dp[g]) dp[g]=min(dp[g],c[i]+j->second);
				else dp[g]=c[i]+j->second;
			}
		}
		printf("%d\n",dp[1]);
	}
	return 0;
}
   			 	 	 	   	 		 	 	 	 		  	