//Language: GNU C++


#pragma comment (linker,"/stack:102400000,102400000")
#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <utility>
#include <queue>
#include <stack>
#include <set>
#include <map>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
const int N = 2000005;
const int M = 200005;
const int INF = 0x3f3f3f3f;
const int MOD = 1000000007;
const double Pi = acos(-1.0);

#define Key_value ch[ch[root][1]][0]
#define lson (i<<1)
#define rson (i<<1|1)

int lowbit(int x) { return x & (-x); }
template < class T > inline T f_min(T a, T b) { return a < b ? a : b; }
template < class T > inline T f_max(T a, T b) { return a < b ? b : a; }
template < class T > inline T f_abs(T a) { return a > 0 ? a : -a; }
template < class T > inline T f_gcd(T a, T b) { return b == 0 ? a : f_gcd(b, a%b); }
template < class T > inline T f_Lcm(T a, T b) { return a / f_gcd(a, b) * b; }
template < class T > inline void f_swap(T &a, T &b) { T t = a;a = b;b = t; }
bool is_digit(char a) { if (a >= '0' && a <= '9')return true;return false; }
bool is_lowch(char a) { if (a >= 'a' && a <= 'z')return true;return false; }
bool is_upch(char a) { if (a >= 'A' && a <= 'Z')return true;return false; }

struct Node {
	int dep, id;
	Node() {}
	Node(int _dep,int _id) :dep(_dep),id(_id) {}
	bool operator < (const Node &ah)const {
		return dep > ah.dep;
	}
	bool operator == (const Node &ah)const {
		return dep == ah.dep && id == ah.id;
	}
};
multiset<Node>	s[N];
struct Edge {
	int to, next;
}G[M];
int head[N/10], e;
void clear() { memset(head, -1, sizeof(head));e = 0; }
void add_node(int from, int to) {
	G[e].to = to;
	G[e].next = head[from];
	head[from] = e++;
}
int prime[N/10], vis[N], cnt, pos[N], tot, pool[N<<2];
void init() {
	cnt = 0;
	memset(vis, 0, sizeof(vis));
	for (int i = 2;i < N;++i) {
		if (!vis[i])	prime[cnt++] = i;
		for (int j = 0;j < cnt;++j) {
			if (1LL * i * prime[j] >= 1LL * N)	break;
			vis[i * prime[j]] = true;
			if (i % prime[j] == 0)	break;
		}
	}
	//cout << cnt << endl;
	//for (int i = 0;i < 100;++i)cout << prime[i] << " ";cout << endl;

	tot = 1;
	pool[0] = -1;
	pos[1] = 0;
	for (int i = 2;i < N;++i) {
		pos[i] = tot;
		int temp = i;
		for (int j = 0;j < cnt;++j) {
			if (!vis[temp]) {
				pool[tot++] = temp;
				break;
			}
			if (temp % prime[j] == 0) {
				pool[tot++] = prime[j];
				while (temp % prime[j] == 0)	temp /= prime[j];
			}
			if (temp == 1)	break;
		}
		pool[tot++] = -1;
	}
	//cout << tot << endl;
	/*
	for (int i = 2;i <= 20;++i) {
		cout << i << " : ";
		for (int j = pos[i];pool[j] != -1;++j)cout << pool[j] << " ";
		cout << endl;
	}*/
}
int a[N/10], ans[N/10];
void dfs(int from, int fa,int dep) {
	Node ma(-1, -1);
	for (int i = pos[a[from]];pool[i] != -1;++i) {
		//cout << pool[i] << " ";
		if (s[pool[i]].size() > 0)	ma = f_min(ma, (*s[pool[i]].begin()));
		s[pool[i]].insert(Node(dep, from));
	}
	//cout << endl;
	ans[from] = ma.id;

	for (int i = head[from];i != -1;i = G[i].next) {
		int to = G[i].to;
		if (to == fa)	continue;
		dfs(to, from, dep + 1);
	}

	for (int i = pos[a[from]];pool[i] != -1;++i) s[pool[i]].erase(Node(dep, from));
}
int main() {
	init();
	int n, m;
	while (~scanf("%d%d", &n, &m)) {
		clear();
		for (int i = 1;i <= n;++i)scanf("%d", &a[i]);
		for (int i = 0;i < n - 1;++i) {
			int x, y;
			scanf("%d%d", &x, &y);
			add_node(x, y);
			add_node(y, x);
		}
		
		for (int i = 0;i < cnt;++i)s[prime[i]].clear();
		//puts("ok");
		dfs(1, -1, 1);
		while (m--) {
			int op, x, y;
			scanf("%d", &op);
			if (op == 1) {
				scanf("%d", &x);
				printf("%d\n", ans[x]);
			}
			else {
				scanf("%d%d", &x, &y);
				a[x] = y;
				for (int i = 0;i < cnt;++i)s[prime[i]].clear();
				dfs(1, -1, 1);
			}
		}
	}
	return 0;
}
/*
10 10
1 2 3 4 5 6 7 8 9 10
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 9
9 10
*/
 		  	  	 	 	  	 		  		  					