//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;
#define md int(1e5+100)
#define modul int(1e9+7)
#define FOR(i,a,b) for( int i=(a),_b=(b);i<=_b;i++)
#define DOW(i,b,a) for( int i=(b),_a=(a);i>=_a;i--)
int xx[4]={0,0,1,-1};
int yy[4]={1,-1,0,0};
typedef long long ll;
int n;
char a[md],b[md];
int f[md],s[md],fb[md],lef[md];
int d[md];
bool t[md];
int main()
{
  //  freopen("inp.txt","r",stdin);
    scanf("%s",a+1);
    int la=strlen(a+1);
    scanf("%s",b+1);
    int lb=strlen(b+1);
    int j=0;
    FOR(i,2,lb)
    {
        while (j!=0 && b[j+1]!=b[i]) j=fb[j];
        if (b[j+1]==b[i]) j++;
        fb[i]=j;
    }
    j=0;
    FOR(i,1,la)
    {
        while (j!=0 && b[j+1]!=a[i]) j=fb[j];
        if (b[j+1]==a[i]) j++;
        if (j==lb)
        {
            t[i]=true;
            j=fb[j];
        }
    }
    memset(lef,-63,sizeof(lef));
    int def=lef[0];
    FOR(i,1,la)
    if (t[i])
    {
        lef[i]=i-lb;
    }
    else
    {
        lef[i]=lef[i-1];
    }
    d[0]=1;
    s[0]=1;
    FOR(i,1,la)
    {
        f[i]=(f[i]+f[i-1])%modul;
        int x;
        if (lef[i]==def)
        {
            d[i]=(f[i]+1)%modul;
            s[i]=(s[i-1]+d[i])%modul;
            continue;
        }
        x=lef[i];
        f[i]=(f[i]+s[x])%modul;
        d[i]=(f[i]+1)%modul;
        s[i]=(s[i-1]+d[i])%modul;
    }
    cout<<f[la]<<endl;
}
