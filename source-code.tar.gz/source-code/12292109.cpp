//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair

const int MAXN=1e5;

int isroot[MAXN+5];
int vis[MAXN+5];
vector<int>child[MAXN+5];

pair<int,pair<int,int> >query[MAXN+5];
vector<pair<int,int> >confirm[MAXN+5];
vector<pair<int,int> >ask_doc[MAXN+5];
string ans[MAXN+5];

int P[MAXN+5][25],L[MAXN+5];

void dfs(int ind,int lvl){

     L[ind]=lvl;
    for(int i=0;i<(int)child[ind].size();i++)dfs(child[ind][i],lvl+1);

}


int par[MAXN+5],height[MAXN+5];
void init(int n){
    for(int i=0;i<n;i++)par[i]=i,height[i]=1;
}
int find(int e){
    if(par[e]==e)return e;
    return par[e]=find(par[e]);
}
void join(int e1,int e2){
    e1=find(e1),e2=find(e2);
    if(e1==e2)return ;
    if(height[e1]<height[e2])swap(e1,e2);
    par[e2]=e1;
    if(height[e1]==height[e2])height[e1]++;
}


int get_ith_ancestor(int v,int ith){
    if(ith<0)return -1;

    for(int i=19;i>=0;i--){
        if(  (1<<i)<=ith ){
            v=P[v][i];
            ith-=(1<<i);
        }
    }
    return v;
}

int main(){

      int n,m,t,x,y,doc,QUERY=0,DOCUMENT=0;

      scanf("%d%d",&n,&m);

      for(int i=0;i<m;i++){

            scanf("%d",&t);query[i].first=t;
            if(t==1){
                scanf("%d%d",&x,&y);x--; y--; // y become ancestor of x
                query[i].second.first=x;  query[i].second.second=y;
            }
            if(t==2){
                scanf("%d",&x);x--;
                query[i].second.first=x;  query[i].second.second=-1;
            }
            if(t==3){
                scanf("%d%d",&x,&doc); x--;doc--;
                query[i].second.first=x;  query[i].second.second=doc;
                ask_doc[doc].pb(mp(x,QUERY++));
            }
      }



      for(int i=0;i<n;i++)isroot[i]=1;
      init(n);

      for(int i=0;i<m;i++){

            t=query[i].first;
            if(t==1){
                x=query[i].second.first; y=query[i].second.second;
                // y become ancestor of x
                join(x,y);
                isroot[x]=0;
                P[x][0]=y;
                child[y].push_back(x);
            }
            if(t==2){
                x=query[i].second.first;

                for(int i=0;i<ask_doc[DOCUMENT].size();i++){
                     int emp=ask_doc[DOCUMENT][i].first,idx=ask_doc[DOCUMENT][i].second;
                     if(find(emp)==find(x)){
                        ans[idx]="YES\n";
                        confirm[x].push_back(make_pair(emp,idx));
                     }
                     else ans[idx]="NO\n";
                }

                DOCUMENT++;

            }
            if(t==3)continue;
      }

     for(int j=1;j<20;j++)
        for(int i=0;i<n;i++)
            P[i][j]=P[P[i][j-1]][j-1];


     for(int i=0;i<n;i++)if(isroot[i])dfs(i,0);
     for(int i=0;i<n;i++){
        for(int j=0;j<(int)confirm[i].size();j++){
            int leaf=i,root=confirm[i][j].first,idx=confirm[i][j].second;
            if(get_ith_ancestor(leaf,L[leaf]-L[root])!=root)ans[idx]="NO\n";

        }
     }

     for(int i=0;i<QUERY;i++)printf("%s",ans[i].c_str());
}
