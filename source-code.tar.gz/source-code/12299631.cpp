//Language: GNU C++


#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=30;
char a[maxn];

int main()
{
    int i,j,len,k;
    scanf("%s%d",a,&k);
    len=strlen(a);
    char temp,maxc,foot;
    int cj,flag,q;
    for(i=0;i<len && k!=0;i++)
    {
        maxc=a[i];
        flag=0;
        for(j=i+1;j<len && j-i<=k ;j++)
        {
            if(a[j]>maxc)
            {
                maxc=a[j];
                cj=j;
                flag=1;
            }
        }
        if(flag==1)
        {
            k=k-(cj-i);
            temp=a[cj];
            for(q=cj;q>i;q--)
                a[q]=a[q-1];
            a[i]=temp;
        }
    }
    printf("%s\n",a);

    return 0;
}



 	 	  	  			 		 					   	 	   	