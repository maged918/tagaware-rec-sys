//Language: GNU C++11


    #pragma comment(linker, ”/STACK:36777216“)
    #include<bits/stdc++.h>

    #define x first
    #define h second
    #define y0 hi1
    #define y1 hi2
    #define ll long long
    #define mp make_pair
    #define pb push_back
    #define sqr(a) (a)*(a)
    #define ld long double
    #define all(a) (a).begin(), (a).end()

    using namespace std;

    const int N = 100005;
    const int inf = 2000000009;

    pair<int, int> a[N];

    int main(){
        cin.tie(0);
        ios_base::sync_with_stdio(0);
        int n;
        cin >> n;
        for(int i = 0; i < n; i++){
            cin >> a[i].x >> a[i].h;
        }
        int ans = 1, l = a[0].x;
        a[n].x = inf;
        for(int i = 1; i < n; i++){
            if(a[i - 1].x < a[i].x - a[i].h && a[i].x - a[i].h > l){
                l = a[i].x;
                ans ++;
            } else
            if(l < a[i].x){
                if(a[i + 1].x > a[i].x + a[i].h){
                    ans ++;
                    l = a[i].x + a[i].h;
                }
            } else
            if(a[i].x + a[i].h < l){
                l = a[i].x + a[i].h;
            }
            //cout << i << " " << l << "\n";

        }
        cout << ans;
    }
