//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;
int last=0;
int head[300004],next[600004],to[600004];
int Parent[300004], MaxDepth[300004], MaxPath[300004];
bool vis[300004];
int MaxCurPath=-1;
void AddEdge(int f,int t)
{
    next[last]=head[f];
    head[f]=last;
    to[last++]=t;
    return;
}
void CreateSet(int node)
{
    Parent[node]=node;
    MaxDepth[node]=0;
    MaxPath[node]=0;
    return ;
}
int FindSet(int node)
{
    while(node!=Parent[node])
        node=Parent[node];
    return node;
}
void MergeSets(int node1,int node2)
{
    int x=FindSet(node1);
    int y=FindSet(node2);
    if(x==y)
        return;
    if(MaxDepth[x]>MaxDepth[y]){
        Parent[y]=x;
        MaxPath[x]=max(MaxPath[x],MaxDepth[y]+MaxDepth[x]+1);
    }
    else{
        Parent[x]=y;
        MaxPath[y]=max(MaxPath[y],MaxDepth[y]+MaxDepth[x]+1);
        if(MaxDepth[x]==MaxDepth[y]){
            MaxDepth[y]++;
        }
        MaxPath[x]=max(MaxPath[x],MaxDepth[x]+MaxDepth[y]);
    }

    return ;
}
int dfs(int node,int pp)
{
    vis[node]=1;
    int depthmax1=0,depthmax2=0;
    for(int i=head[node];i!=-1;i=next[i]){
        if(to[i]==pp)
            continue;
        MergeSets(node,to[i]);
        depthmax2=max(depthmax2,dfs(to[i],node)+1);
        if(depthmax2>depthmax1)
            swap(depthmax1,depthmax2);
    }
    MaxCurPath=max(MaxCurPath,depthmax1+depthmax2);
    return depthmax1;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int n,m,q;
    cin>>n>>m>>q;
    memset(head,-1,sizeof head);
    for(int i=1;i<=n;i++)
        CreateSet(i);
    for(int i=0;i<m;i++){
        int f,t;
        cin>>f>>t;
        AddEdge(f,t);
        AddEdge(t,f);
    }
    for(int i=1;i<=n;i++){
        if(!vis[i]){
            MaxCurPath=-1;
            dfs(i,-1);
            int sett=FindSet(i);
            MaxPath[sett]=MaxCurPath;
            MaxDepth[sett]=MaxCurPath/2+MaxCurPath%2;
        }
    }
    for(int i=0;i<q;i++){
        int type;
        cin>>type;
        if(type==1){
            int x;cin>>x;cout<<MaxPath[FindSet(x)]<<"\n";
        }
        else{
            int x,y;
            cin>>x>>y;
            MergeSets(x,y);
        }

    }
    return 0;
}
