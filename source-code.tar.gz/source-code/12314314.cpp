//Language: GNU C++


#include <iostream>
#include <stdio.h>
#define MAX 99999999
#define N 100010
using namespace std;

int i,flag[N],s[N],c[N];

void solve(int x, int ti)
{
	if(x>100000||flag[x]==i)
		return;
	flag[x]=i;
	s[x]+=ti;
	c[x]++;
	solve(2*x,ti+1);
	solve(x/2,ti+1);
}

int main()
{
	//ios_base::sync_with_stdio(false);
	int n,a,ans=MAX;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a);
		solve(a, 0);
	}
	for(int j=0;j<=100000;j++)
		if(c[j]==n)
			ans=min(ans,s[j]);
	printf("%d",ans);
	return 0;
}
