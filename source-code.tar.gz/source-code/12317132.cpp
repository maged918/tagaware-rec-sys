//Language: GNU C++


#include<bits/stdc++.h>

using namespace std;

#define endline "\n"
#define MAXN 210
#define MAXM 1100

typedef pair<int,int> pii;

const int inf=1e9;
const int source=201;
const int destination=202;

int head[MAXN];
int to[MAXM],next[MAXM],cost[MAXM],from[MAXM],id;
int vis[MAXN],visID;
int selfcost[MAXN];
int arr[MAXN];
int n,m;
map<int,int> rnk;
vector< vector<pii> > v;

void addedge(int f,int t,int c)
{
    next[id]=head[f];
    head[f]=id;
    cost[id]=c;
    from[id]=f;
    to[id++]=t;
}

void addflowedge(int f,int t,int c)
{
    addedge(f,t,c);
    addedge(t,f,0);
}

void construct(int p)
{
    int cur=rnk[p];
    memset(selfcost,0,sizeof selfcost);
    for(int i=0;i<v[cur].size();i++)
        selfcost[v[cur][i].first]=v[cur][i].second;
    for(int i=0;i<id;i+=2)
    {

        if(from[i]==source)
            cost[i]=selfcost[to[i]/2];
        else if(to[i]==destination)
            cost[i]=selfcost[from[i]/2];
        else
            cost[i]=inf;
    }
    for(int i=1;i<id;i+=2)
        cost[i]=0;
}

int dfs(int src,int dist,int mn)
{
    if(vis[src]==visID)
        return 0;
    vis[src]=visID;
    if(src==dist)
        return mn;
    int cur;
    for(int i=head[src];i!=-1;i=next[i])
    {
        if(cost[i])
            if(cur=dfs(to[i],dist,min(mn,cost[i])),cur)
            {
                cost[i]-=cur;
                cost[i^1]+=cur;
                return cur;
            }
    }
    return 0;
}

int maxflow(int src=source,int dist=destination)
{
    int ret=0,cur;
    while(visID++,cur=dfs(src,dist,inf),cur)
        ret+=cur;
    return ret;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    const int garbage=134144;
    memset(head,-1,sizeof head);
    cin>>n>>m;
    for(int i=0;i<n;i++)
        cin>>arr[i];
    for(int i=0;i<n;i++)
        addflowedge(source,i*2,garbage),addflowedge(i*2+1,destination,garbage);
    while(m--)
    {
        int a,b;
        cin>>a>>b;
        a--,b--;
        addflowedge(a*2,b*2+1,garbage);
        addflowedge(b*2,a*2+1,garbage);
    }
    for(int i=2;i<=32000;i++)
    {
        vector<pii> cur;
        for(int j=0;j<n;j++)
        {
            pii p(j,0);
            while(arr[j]%i==0)
                p.second++,arr[j]/=i;
            if(p.second)
                cur.push_back(p);
        }
        if(cur.size()>1)
            rnk[i]=v.size(),v.push_back(cur);
    }
    for(int i=0;i<n;i++)
    {
        if(arr[i]==1)
            continue;
        vector<pii> cur(1,make_pair(i,1));
        for(int j=i+1;j<n;j++)
        {
            pii p(j,0);
            while(arr[j]%arr[i]==0)
                p.second++,arr[j]/=arr[i];
            if(p.second)
                cur.push_back(p);
        }
        if(cur.size()>1)
            rnk[arr[i]]=v.size(),v.push_back(cur);
    }
    int ans=0;
    for(map<int,int>::iterator it=rnk.begin();it!=rnk.end();it++)
    {
        int cur=it->first;
        construct(cur);
        ans+=maxflow();
    }
    cout<<ans/2<<endline;
    return 0;
}
