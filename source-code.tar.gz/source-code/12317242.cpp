//Language: GNU C++


#include <iostream>

using namespace std;

int main()
{
    int n, x;
    bool noSuchSum = false;

    cin >> n;
    for(int i = 0; i < n; i++)
    {
        cin >> x;
        if(x == 1) noSuchSum = true;
    }

    if(noSuchSum) cout << -1 << endl;
    else cout << 1 << endl;
}
        
        