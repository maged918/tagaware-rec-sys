//Language: GNU C++


#include <iostream>
#include "stdio.h"

using namespace std;

int main() {
    int n, res = 0, a, b;
    scanf("%d", &n);
    for (int i = 0; i < n ; i ++) {
        scanf("%d %d", &a, &b);
        if (a + 2 <= b) res ++;
    }
    printf("%d", res);
    return 0;
}