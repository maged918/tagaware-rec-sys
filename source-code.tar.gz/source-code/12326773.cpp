//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<sstream>
#include<cmath>
#include<string>
#include<map>
using namespace std;
int N,Q,x[300000],y[300000];
map<int,int> ma;
int main()
{
            while(cin>>N>>Q)
            {
                   ma.clear();
                   ma[0]=ma[N+1]=Q;
                    while(Q--)
                    {
                              char c[2];
                              scanf("%d%d%s",&x[Q],&y[Q],c);
                              map<int,int>::iterator it=ma.lower_bound(x[Q]);
                        //      cout<<endl<<it->first<<' '<<it->second<<endl;
                              if(it->first==x[Q])
                              {
                                         printf("0\n");
                                         continue;
                              }

                              if(c[0]=='U')
                              {
                                        ma[x[Q]]=Q;
                                        printf("%d\n",y[Q]-y[it->second]);
                                        y[Q]=y[it->second];ma[x[Q]]=Q;
                              }
                              else
                              {
                                        it--;
                                      //  it--;
                                        ma[x[Q]]=Q;
                                        printf("%d\n",x[Q]-x[it->second]);
                                        x[Q]=x[it->second];
                              }

                    }
            }
            return 0;
}



		  	 				 	 		 			  	    	 			