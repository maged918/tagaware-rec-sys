//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int main()
{
    long long a[200005],i,n,m;
    while(~scanf("%I64d%I64d",&n,&m))
    {
        long long sum=0,k=n-1;
        for(i=1;i<=n;i++)
        {
            scanf("%I64d",&a[i]);
            sum+=a[i];
        }
        for(i=1;i<=n;i++)
        {
            long long temp=sum-a[i],ans=0;
            if(m-temp>=1)  ans+=m-temp-1;
            if(m-k<=a[i])  ans+=a[i]-m+k;
            printf("%I64d ",ans);
        }
        printf("\n");
    }
    return 0;
}

   				 				  	 	  	 			  	