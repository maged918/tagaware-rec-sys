//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>

#define mp make_pair
#define pb push_back
#define eps 1e-17
#define INF 999999999.0

using namespace std;

struct point
{
    double x, y;
    int id;
    point() {}
    point(double x, double y, int id) : x(x), y(y), id(id) {}
};

point operator + (const point& p1, const point& p2) { return point(p1.x + p2.x, p1.y + p2.y, 0); }
point operator - (const point& p1, const point& p2) { return point(p1.x - p2.x, p1.y - p2.y, 0); }
double det(point p1, point p2) { return p1.x * p2.y - p1.y * p2.x; }
double dot(point p1, point p2) { return p1.x * p2.x + p1.y * p2.y; }
int dcmp(double x) { return fabs(x) <= eps ? 0 : (x > 0 ? 1 : -1); }
bool cmp1(const point& p1, const point& p2) { return dcmp(p1.x - p2.x) < 0 || (!dcmp(p1.x - p2.x) && dcmp(p1.y - p2.y) < 0); }

int n, cnt = 0;
point p[400001], stack[400001];
int size = 0, ans[400001], px[400001], py[400001];
map<pair<int, int>, int> M;
vector<int > v[400001];

int main( )
{
    scanf("%d", &n);
    for (int i = 0; i < n; i ++)
    {
        scanf("%d %d", &px[i], &py[i]);
        if (!M.count(mp(px[i], py[i]))) M[mp(px[i], py[i])] = ++ cnt;
        int tmp = M[mp(px[i], py[i])];
        v[tmp].pb(i + 1);
        p[i] = point(1000.0 / px[i], 1000.0 / py[i], i);
    }
    sort(p, p + n, cmp1);
    int m = 0;
    for (int i = 0; i < n; i ++)
    {
        while (m > 1 && dcmp(det(stack[m - 1] - stack[m - 2], p[i] - stack[m - 2])) <= 0) -- m;
        stack[m ++] = p[i];
    }
    int k = m;
    for (int i = n - 2; i >= 0; i --)
    {
        while (m > k && dcmp(det(stack[m - 1] - stack[m - 2], p[i] - stack[m - 2])) <= 0) -- m;
        stack[m ++] = p[i];
    }
    if (n > 1) -- m;
    point leftmost = point(INF, INF, 0), downmost = point(INF, INF, 0);
    int idx = -1, idy = -1;
    for (int i = 0; i < m; i ++)
    {
        int tmp = dcmp(stack[i].x - leftmost.x);
        if (tmp < 0 || (tmp == 0 && dcmp(stack[i].y - leftmost.y) < 0))
            leftmost = stack[i], idx = i;
        tmp = dcmp(stack[i].y - downmost.y);
        if (tmp < 0 || (tmp == 0 && dcmp(stack[i].x - downmost.y) < 0))
            downmost = stack[i], idy = i;
    }
    for (int i = idx; ; )
    {
        int tmp = M[mp(px[stack[i].id], py[stack[i].id])];
        for (int j = 0; j < (int )(v[tmp].size()); j ++) ans[++ size] = v[tmp][j]; 
        if (i == idy) break;
        i ++, i %= m;
    }
    sort(ans + 1, ans + 1 + size);
    for (int i = 1; i <= size; i ++)
        printf("%d ", ans[i]);
    printf("\n");
    return 0;
}