//Language: GNU C++


#include<iostream>
using namespace std;
int main()
{
    int n;
    cin>>n;
    long long p[n];
    for(int i=0;i<n;i++)
    {
        cin>>p[i];
    }
    for(int i=0;i<n;i++)
    {
        if(i==0)
        {
            cout<<p[1]-p[0]<<" "<<p[n-1]-p[0]<<endl;
        }
        if(i==n-1)
        {
            cout<<p[i]-p[i-1]<<" "<<p[n-1]-p[0]<<endl;
        }
        if((i!=0)&&(i!=n-1))
        {
            cout<<min(p[i]-p[i-1],p[i+1]-p[i])<<" "<<max(p[n-1]-p[i],p[i]-p[0])<<endl;
        }
    }
}