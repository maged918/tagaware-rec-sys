//Language: GNU C++


#include <cstdio>
#include <algorithm>
using namespace std;

const int maxn=100005;

struct Town{
    int x, j;
    Town() {}
    Town(int a, int b)
        : x(a), j(b) {}
};

inline bool operator<(Town a, Town b){
    return a.x<b.x;
}

Town t[maxn];
int mi[maxn];
int ma[maxn];

int main()
{
    int n, x;
    scanf("%d", &n);
    for(int i=0;i<n;++i){
        scanf("%d", &x);
        t[i]=Town(x, i);
    }
    sort(t, t+n);
    ma[t[0].j]=ma[t[n-1].j]=t[n-1].x-t[0].x;
    mi[t[0].j]=t[1].x-t[0].x;
    for(int i=1;i<n-1;++i){
        ma[t[i].j]=max(t[i].x-t[0].x, t[n-1].x-t[i].x);
        mi[t[i].j]=min(t[i].x-t[i-1].x, t[i+1].x-t[i].x);
    }
    mi[t[n-1].j]=t[n-1].x-t[n-2].x;
    for(int i=0;i<n;++i)
        printf("%d %d\n", mi[i], ma[i]);
}
