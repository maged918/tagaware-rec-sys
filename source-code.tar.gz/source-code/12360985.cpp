//Language: GNU C++


/*
    Manish Kumar
    c0dezer0
    www.fb.com/kur.manish
*/
#include <bits/stdc++.h>
#define mod 1000000007
#define ll long long
#define ull unsigned long long

using namespace std;


int main() 
{
    ios_base::sync_with_stdio(false);cin.tie(0);
    
    ll t ,n,k,x,y,z,i;
    cin>>t;
    ll arr[t];
    for(i=0;i<t;i++)
        cin>>arr[i];
    cout<<abs(arr[0]-arr[1])<<" "<<abs(arr[t-1]-arr[0])<<"\n";
    for(i=1;i<t-1;i++)
    {
        x= min(abs(arr[i]-arr[i+1]),abs(arr[i]-arr[i-1]));
        y= max(abs(arr[t-1]-arr[i]),abs(arr[0]-arr[i]));
        cout<<x<<" "<<y<<"\n";
    }
    cout<<abs(arr[t-1]-arr[t-2])<<" "<<abs(arr[t-1]-arr[0]);
    
    return 0;
}
