//Language: GNU C++11


#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>

using namespace std;

typedef complex<double> point;
#define EPS 1e-9
#define X                                    real()
#define Y                                    imag()
#define ptoc(r,t)              ((r)*exp(Point(0,t))
#define angle(v)               (atan2((v).Y,(v).X))
#define length(v)              (hypot((v).Y,(v).X))
#define dot(a,b)                  ((conj(a)*(b)).X)
#define cross(a,b)                ((conj(a)*(b)).Y)
#define vec(a,b)                      ((b)-(a))
#define legthsq(a)                         dot(a,a)
#define rotate(v,t)                       ptoc(v,t)
#define rotate_about(v,t,a) ((rotate(vec(a,v,t)+a))
#define norm(v)                     ((v)/length(v))
#define reflect(v,m)          ((conj((v)/(m)))*(m))
#define same(a,b)          (lengthsq(vec(a,b))<eps)
#define mid(a,b)                      (((a)+(b))/2)
#define perp(v)               (Point(-(v).Y,(v).X))


#define all(v)             v.begin(),v.end()
#define sz(v)            ((int)((v).size()))
#define psh(x)                  push_back(x)
#define sc(x)                 scanf("%d",&x)
#define scl(x)              scanf("%lld",&x)
#define sc2(x,y)         scanf("%d%d",&x,&y)
#define lop(i,n)        for(int i=0;i<n;++i)
#define loop(i,f,l)     for(int i=f;i<l;++i)
#define R_(s)         freopen(s, "r", stdin)
#define W_(s)        freopen(s, "w", stdout)
#define R_W R_("input.txt"),W_("output.txt")
#define PI           acos(-1)
#define re             return
#define oo              1<<30
#define DFS_GRAY           -1
#define DFS_WHITE           0
#define DFS_BLACK           1

typedef string            ss;
typedef long long         ll;
typedef pair <int, int>   ii;
typedef pair<ss, int>     si;
typedef pair<int, ss>     is;
typedef pair<char, int>  chi;
typedef pair<ss, ss>     pss;
typedef vector<ii>       vii;
typedef vector<int>       vi;
typedef vector<vi>       vvi;
typedef vector<ss>        vs;
typedef vector<ll>       vll;
typedef vector<vll>     vvll;

ll pw(ll b, ll p){ if (!p) re 1; ll sq = pw(b, p / 2); sq *= sq; if (p % 2) sq *= b; re sq; }
ll gcd(ll a, ll b)  { re(b == 0 ? a : gcd(b, a % b)); }
ll sd(ll x)  { re x<10 ? x : x % 10 + sd(x / 10); }
ll lcm(ll a, ll b){ re((a*b) / gcd(a, b)); }

int n,k,arr[210000];

map<ll,ll> mp;
map<ll,ll> val;
int main(){
#ifndef ONLINE_JUDGE
    R_("input.txt");
#endif
    sc2(n,k);
    lop(i,n)sc(arr[i]);
    for(int i=n-1;i>=0;--i){
        val[arr[i]]+=mp[1LL*k*arr[i]];
        ++mp[arr[i]];
    }
    ll sum=0;
    lop(i, n){
        --mp[arr[i]];
        val[arr[i]] -= mp[1LL * k*arr[i]];
        sum += val[1LL * k*arr[i]];

    }
    printf("%lld\n",sum);
}







