//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <queue>
#include <vector>
#include <math.h>
using namespace std;
#define md int(5e3+50)
#define modul int(1e9+7)
#define FOR(i,a,b) for( int i=(a),_b=(b);i<=_b;i++)
#define DOW(i,b,a) for( int i=(b),_a=(a);i>=_a;i--)
int xx[4]={0,0,1,-1};
int yy[4]={1,-1,0,0};
typedef long long ll;
int n,time;
double f[md][md],s[2][md];
double p[md],tmp[md];
int t[md];
int m=0;
int main()
{
   // freopen("inp.txt","r",stdin);
    scanf("%d%d",&n,&time);
    f[0][0]=1;
    int po;
    FOR(i,1,n)
    {
        scanf("%d%d",&po,&t[i]);
        p[i]=po;
        tmp[i]=pow(1-p[i]/100,t[i]-1);
    }
    s[0][0]=1;
    FOR(i,1,time)
    s[m][i]=s[m][i-1]*(1-p[1]/100);
    FOR(x,1,n)
    {
        s[1-m][x-1]=0;
        FOR(i,x,time)
        {
            int l=i-t[x];
            int r=i-1;
            if (l>=x-1)
            {
                f[i][x]+=(s[m][r]-s[m][l]*tmp[x])*(p[x]/100);

            }
            else
                f[i][x]+=s[m][r]*(p[x]/100);

            if (i-t[x]>=0)
            {
                f[i][x]+=f[i-t[x]][x-1]*tmp[x];
            }
            s[1-m][i]=s[1-m][i-1]*(1-p[x+1]/100)+f[i][x];
        }
        m=1-m;
    }
    double res=0;
    FOR(x,1,n)
    {
        double a=1;
        DOW(i,time,x)
        if (x==n)
        {
            res+=f[i][x]*x;
        }
        else if (time-i<t[x+1])
        {
            res+=f[i][x]*x*a;//pow(1-p[x+1]/100,time-i);
            a*=(1-p[x+1]/100);
        }
    }
    printf("%.6f",res);
}
