//Language: MS C++


#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<cstdio>
#include<iomanip>
#include<algorithm>
using namespace std;


int main()
{
    int n,num,arr[1000],ans = 0,sum = 0,now = 0;
    char a;
    scanf("%d",&n);
    memset(arr,0,sizeof(arr));
    while(n--){
        cin >> a >> num;
        if(a == '+')
            arr[ans] = num,ans++,now++;
        else{
            int judge = 0;
            for(int i=0; i<ans; i++)
                if(arr[i] == num){
                    now--;
                    judge = 1;
                    arr[i] = 0;
                    break;
                }
            if(!judge)
                sum++;
        }
        if(now > sum)
            sum = now;
    }
    printf("%d\n",sum);
    /*system("pause");*/
    return 0;
}