//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
long n,k,a,m,ht,itmax[2000000],itmin[2000000];
int lt[2000000];
long getmax(long vt,long l,long r,long x,long y)
{
    if (l>y or r<x) return 0;
    if (x<=l and y>=r) return itmax[vt];
    long m=(l+r)>>1;
    return max(getmax(vt*2,l,m,x,y),getmax(vt*2+1,m+1,r,x,y));
}
long getmin(long vt,long l,long r,long x,long y)
{
    if (l>y or r<x) return n+1;
    if (x<=l and y>=r) return itmin[vt];
    long m=(l+r)>>1;
    return min(getmin(vt*2,l,m,x,y),getmin(vt*2+1,m+1,r,x,y));
}
void updatemax(long vt,long l,long r,long x,long y)
{
    if (l>x or r<x) return;
    if (l==r)
    {
        itmax[vt]=x;
        return;
    }
    long m=(l+r)>>1;
    updatemax(vt*2,l,m,x,y);
    updatemax(vt*2+1,m+1,r,x,y);
    itmax[vt]=max(itmax[vt*2],itmax[vt*2+1]);
}
void updatemin(long vt,long l,long r,long x,long y)
{
    if (l>x or r<x) return;
    if (l==r)
    {
        itmin[vt]=x;
        return;
    }
    long m=(l+r)>>1;
    updatemin(vt*2,l,m,x,y);
    updatemin(vt*2+1,m+1,r,x,y);
    itmin[vt]=min(itmin[vt*2],itmin[vt*2+1]);
}
void doc()
{
    cin>>n>>k>>a;
    cin>>m;
    for (int i=1;i<=5*n;i++)
    {
        itmax[i]=0;
        itmin[i]=n+1;
        if (i==a) lt[i]=1;
        if (i>a)
            lt[i]=max(1,lt[i-a-1]+1);
    }
    ht=lt[n];
    long x,l,r,thu;
    for (int i=1;i<=m;i++)
    {
        cin>>x;
        l=getmax(1,1,n,1,x-1);
        r=getmin(1,1,n,x+1,n);
        ht-=lt[r-l-1]-(lt[x-l-1]+lt[r-x-1]);
        if (ht<k)
        {
            cout<<i;
            return;
        }
        updatemax(1,1,n,x,x);
        updatemin(1,1,n,x,x);
    }
    cout<<"-1";
}
int main()
{
    cin.tie(NULL);
    ios_base::sync_with_stdio(false);
    doc();
}
