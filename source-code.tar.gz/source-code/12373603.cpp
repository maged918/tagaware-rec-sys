//Language: GNU C++11


//c++11
#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cassert>
#include<stack>
#include<cstring>
#include<vector>
#include<string>
#include<cmath>
#include<ctime>
#include<set>
#include<map>
#include<queue>
#include<fstream>
#include<sstream>
#include<iomanip>
#include<complex>

#define mp make_pair
#define mt(tri1,tri2,tri3) mp(tri1,mp(tri2,tri3))
#define X first
#define Y second
#define pb push_back

using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<int, pii> tri;
const ll MOD = 1e9 + 7;
const double eps = 1e-7;
const int maxN = 1e6 + 10;
const int maxL = 45;
const int inf = 1e9 + 10;
int n, m, s, t;
ll dis[maxN][2];
vector<pair<pii, int>> G[maxN], G_r[maxN], E;
vector<pii> GC[maxN];
ll W[maxN];
set<pair<ll, int>> S;
bool ne[maxN];
bool vis[maxN];
int dep[maxN];

inline int dfs(int v, int d = 0, int par = -1)
{
	vis[v] = 1;
	dep[v] = d;
	int ret = d;
	for (int i = 0; i < GC[v].size(); i++)
	{
		int u = GC[v][i].X;
		int k = GC[v][i].Y;
		if (k == par) continue;
		if (vis[u]) ret = min(ret, dep[u]);
		else
		{
			int t = dfs(u, d + 1, k);
			if (t > d) ne[GC[v][i].Y] = 1;
			ret = min(ret, t);
		}
	}
	return ret;
}

inline void init()
{
	cin >> n >> m >> s >> t; s--; t--;
	int u, v, w;
	for (int i = 0; i < m; i++)
	{
		cin >> u >> v >> w; u--; v--;
		E.pb(mp(mp(u, v), w));
		W[i] = w;
		G[u].pb(mp(mp(v, w), i));
		G_r[v].pb(mp(mp(u, w), i));
	}
	for (int i = 0; i < maxN; i++)
		for (int j = 0; j < 2; j++)
			dis[i][j] = (ll)maxN * maxN;
}

inline void solve()
{
	S.insert(mp(0, s));
	while (S.size())
	{
		pair<ll, int> fr = *(S.begin());
		S.erase(S.begin());
		if (fr.X < dis[fr.Y][0])
		{
			dis[fr.Y][0] = fr.X;
			int v = fr.Y;
			ll d = fr.X;
			for (int i = 0; i < G[v].size(); i++)
				S.insert(mp(d + G[v][i].X.Y, G[v][i].X.X));
		}
	}

	S.insert(mp(0, t));
	while (S.size())
	{
		pair<ll, int> fr = *(S.begin());
		S.erase(S.begin());
		if (fr.X < dis[fr.Y][1])
		{
			dis[fr.Y][1] = fr.X;
			int v = fr.Y;
			ll d = fr.X;
			for (int i = 0; i < G_r[v].size(); i++)
				S.insert(mp(d + G_r[v][i].X.Y, G_r[v][i].X.X));
		}
	}

	ll ds = dis[t][0];

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < G[i].size(); j++)
		{
			ll a = dis[i][0];
			int v = G[i][j].X.X;
			ll d = G[i][j].X.Y;
			ll b = dis[v][1];
			if (a + d + b != ds) continue;
			GC[i].pb(mp(v, G[i][j].Y));
			GC[v].pb(mp(i, G[i][j].Y));
		}
	}
	dfs(s);

	for (int i = 0; i < m; i++)
	{
		if (ne[i]) cout << "YES\n";
		else
		{
			int v = E[i].X.X;
			int u = E[i].X.Y;
			ll a = dis[v][0];
			ll b = dis[u][1];
			ll c = a + b;
			ll de = W[i];
			ll k = c + W[i] - (ds - 1);
			if (k > W[i] - 1) cout << "NO" << '\n';
			else cout << "CAN " << k << '\n';
		}
	}
}


int main()
{
	//freopen("a.in", "r", stdin);
	//freopen("a.out", "w", stdout);
	ios_base::sync_with_stdio(0); cin.tie(); cout.tie();
	init();
	solve();
	//system("pause");
	return 0;
}