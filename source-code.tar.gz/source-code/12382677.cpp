//Language: GNU C++11


#include <algorithm>
#include <iostream>
#include <assert.h>
#include <stdlib.h>
#include <cstring>
#include <cstdlib>  
#include <stdio.h>
#include <cstdio>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <cmath>
#include <math.h>
#include <map>
#include <set>
#include <time.h>
#include <bitset>
inline int Rand() { return (rand() << 16) | rand(); }
#define y1 google
#define INF 2147483647
#define MOD 1000000007
#define pf push_front
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define fname "a" 
                                
using namespace std;

typedef long long ll;

const int N = 100500;

int n;

struct node {
    int x, p, mn, mx;
} a[N];

bool cmp1(node x, node y) {
    return x.x < y.x;
}

bool cmp2(node x, node y) {
    return x.p < y.p;
}

int main () {
       
    #ifndef ONLINE_JUDGE
    freopen(fname".in", "r", stdin);
    freopen(fname".out", "w", stdout);
    #endif

    scanf("%d", &n);

    for (int i = 1; i <= n; i++) {
        scanf("%d", &a[i].x);
        a[i].p = i;
        a[i].mn = INF;
        a[i].mx = -INF;
    }

    sort(a + 1, a + n + 1, cmp1);

    for (int i = 1; i <= n; i++) {
        if (i == 1)
            a[i].mn = abs(a[i].x - a[i + 1].x), a[i].mx = abs(a[i].x - a[n].x);
        else if (i == n)
            a[i].mn = abs(a[i].x - a[i - 1].x), a[i].mx = abs(a[1].x - a[i].x);
        else
            a[i].mn = min(abs(a[i].x - a[i - 1].x), abs(a[i].x - a[i + 1].x)),
            a[i].mx = max(abs(a[1].x - a[i].x), abs(a[n].x - a[i].x));
    }

    sort(a + 1, a + n + 1, cmp2);

    for (int i = 1; i <= n; i++)
        printf("%d %d\n", a[i].mn, a[i].mx);

    return 0;

}
