//Language: GNU C++11


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
int main() {
	int n;
	while (scanf("%d", &n) != EOF) {
		int x1, x2, y1, y2;
		int sum=0;
		for (int i = 1; i <= n; i++) {
			scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
			sum += (x2 - x1 + 1) * (y2 - y1 + 1);
		}
		cout << sum << endl;
	}
	return 0;
}
