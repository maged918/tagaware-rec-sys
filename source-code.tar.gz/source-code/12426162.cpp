//Language: GNU C++


#include <cstdio>
#include <cmath>
#include <cstring>
#include <ctime>
#include <iostream>
#include <algorithm>
#include <set>
#include <vector>
#include <sstream>
#include <typeinfo>
#include <fstream>

#include <iomanip>
#include <string>
#include <cstdlib>
#include <utility>
#include <locale>
#include <queue>
#include <stack>
#include <list>
#include <climits>
#include <cfloat>
#include <map>
#include <functional>
using namespace std;

const long long MAXVAL = 1e18;
long long len, goal, fibo[55] = {0, 1, 2};
vector<long long> v;

vector<long long> recur(long long idx, long long g)
{
    vector<long long> ret(0), rem(0);
    if(idx<1LL) return ret;
    if(idx==1LL)
    {
        ret.push_back(1LL);
        return ret;
    }

    if(idx==2LL)
    {
        ret.resize(2);
        if(g==1LL)
        {
            ret[0] = 1LL;
            ret[1] = 2LL;
        }
        else
        {
            ret[0] = 2LL;
            ret[1] = 1LL;
        }

        return ret;
    }

    if(g <= fibo[idx-1])
    {
        ret.push_back(1LL);
        rem = recur(idx-1LL, g);
        for(long long i=0LL; i<rem.size(); i++) ret.push_back(rem[i]+1LL);
    }
    else
    {
        ret.push_back(2LL);
        ret.push_back(1LL);
        rem = recur(idx-2LL, g-fibo[idx-1LL]);
        for(long long i=0LL; i<rem.size(); i++) ret.push_back(rem[i]+2LL);
    }

    return ret;
}

int main() // Codeforces Round #309 (Div. 2)
{
    for(int i=3; i<54; i++) fibo[i] = fibo[i-1] + fibo[i-2];
    
    scanf("%lld %lld", &len, &goal);
    // goal--; // to 0-based
    
    v = recur(len, goal);

    printf("%lld", v[0]);
    for(long long i=1; i<len; i++) printf(" %lld", v[i]);
    printf("\n");

    return 0;
}