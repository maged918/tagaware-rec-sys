//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
const int Maxn=200020;
typedef long long Int;
typedef pair<int,int>pi;
Int dp[100][100];
vector<pi>G[100];
int a[100];
int get(char *s)
{
    if(s[0]=='=')return 0;
    if(strlen(s)==1)
    {
        if(s[0]=='<')return 1;
        if(s[0]=='>')return 2;
    }
    else
    {
        if(s[0]=='<')return 3;
        if(s[0]=='>')return 4;
    }
}
int rev(int x)
{
    if(x==0)return 0;
    if(x==1)return 2;
    if(x==2)return 1;
    if(x==3)return 4;
    return 3;
}
bool check(int x)
{
   // printf("x=%d\n",x);
    for(pi u:G[x])
    {
        int v=u.second,ty=u.first;
        //printf("v=%d ty=%d\n",v,ty);
        if(ty==0&&a[x]!=a[v])return 0;
        if(ty==1&&a[x]>=a[v])return 0;
        if(ty==2&&a[x]<=a[v])return 0;
        if(ty==3&&a[x]>a[v])return 0;
        if(ty==4&&a[x]<a[v])return 0;
    }
    //printf("x=%d\n",x);
    return 1;
}
int main()
{
    int n,k;
    scanf("%d%d",&n,&k);
    while(k--)
    {
        int x,y;
        char s[5];
        scanf("%d%s%d",&x,s,&y);
        G[x].push_back(pi(get(s),y));
        G[y].push_back(pi(rev(get(s)),x));
    }
    //a[1]=1,a[4]=1,a[2]=2,a[3]=2;
    //if(check(1))puts("ok");
   
    dp[0][0]=1;
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<=n+n;j++)
        {
            if(dp[i-1][j])
            {
                //printf("j=%d\n",j);
                Int w=dp[i-1][j];
                int id=n+n-(2*(i-1)-j);
                //printf("id=%d w=%lld\n",id,w);
                for(int k=i==n?2:0;k<=2;k++)
                {
                    for(int p=1;p<=j;p++)a[p]=0;
                    for(int p=n+n;p>id;p--)a[p]=0;
                    if(k==0)
                    {
                        a[id]=1;
                        a[id-1]=1;
                        for(int p=j+1;p<id-1;p++)a[p]=2;
                        if(check(id)&&check(id-1))dp[i][j]+=w;
                    }
                    else
                    if(k==1)
                    {
                        a[id]=1;
                        a[j+1]=1;
                        for(int p=j+2;p<id;p++)a[p]=2;
                        if(check(id)&&check(j+1))
                        {
                            dp[i][j+1]+=w;
                        }
                    }
                    else
                    if(k==2)
                    {
                        a[j+1]=1;
                        a[j+2]=1;
                        for(int p=j+3;p<=id;p++)a[p]=2;
                        if(check(j+1)&&check(j+2))dp[i][j+2]+=w;
                    }
                }
            }
        }
    }
    Int ans=0;
    for(int i=0;i<=n+n;i++)ans+=dp[n][i];
    printf("%lld\n",ans);

}