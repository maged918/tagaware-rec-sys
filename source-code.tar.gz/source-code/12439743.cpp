//Language: GNU C++11


#include <iostream>
#include <algorithm>
#include <stdio.h>
using namespace std;
void solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    sort(a.begin(), a.end());
    int res = 10000, first = 0, step = 0;
    int pl = 0, pr = 10000;
    for (int i = 0; i <= 200000; ++i) {
        int mi, ma;
        mi = ma = a[0];
        for (int j = 0; j < n; ++j) {
            mi = min(mi, a[j] - j * i);
            ma = max(ma, a[j] - j * i);
        }
        int mid = (mi + ma) / 2;
        int c = max(mid - mi, ma - mid);
        if (c < res) {
            res = c;
            first = mid;
            step = i;
        }
    }
    cout << res << "\n" << first << " " << step << endl;
}
int main(int argc, char *argv[]) {
  solve();
  return 0;
}