//Language: GNU C++11


#include <bits/stdc++.h>
#define all(t) (t).begin(),(t).end()
#define CLR(a) memset((a),0,sizeof(a))
#define pb push_back
#define pf push_front
#define mp(a,b) make_pair(a,b)
#define fr first
#define sc second
#define inf 2e9
#define DEBUG(x) cout << '>' << #x << ':' << x << endl;
using namespace std;
typedef long long LL;
typedef pair<int,int> pii;
typedef vector<pii> vpii;
typedef pair<LL,LL> pLL;
typedef vector<pLL> vpLL;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<LL> vLL;
typedef long double ld;
const int N=1e5+1500;
int main(){
    //ios::sync_with_stdio(false);
    //freopen("xyz.txt", "r", stdin);
    int n,i,ans=0,j,k;

    scanf("%d",&n);
    vi a(N,0);
    vi c(N,0);
    vvi v(N);
    for(i=0;i<n;i++){
        scanf("%d", &a[i]);
        a[i]--;
        c[a[i]]++;
        v[a[i]].pb(i);
    }
    vi e, s, e2;
    for(i=0;i<n;i++){
        if(v[i].size()==1){
            continue;
        }
        else if(v[i].size()>1){
            e.pb(i);
        }
        else{
            s.pb(i);
        }
    }
    for(i=n;i<N;i++){
        if(!v[i].empty()){
            e2.pb(i);
        }
    }
    k=0;
    for(i=0;i<e.size();i++){
        for(j=0;j<v[e[i]].size()-1;j++){
            a[v[e[i]][j]]=s[k++];
        }
    }
    for(i=0;i<e2.size();i++){
        for(j=0;j<v[e2[i]].size();j++){
            a[v[e2[i]][j]]=s[k++];
        }
    }
    for(i=0;i<n;i++){
        cout<<a[i]+1<<' ';
    }

    /*unordered_set<pair<int,int> > left;
    for(i=1;i<=n;i++){
        left.insert(i,);
    }
    for(i=1;i<=n;i++){
        if(c[i]>0)
            left.erase(i);
    }
    for(i=1;i<=n;i++){
        while(c[i]>1){
            auto it=left.begin();
            c[*it]=1;
            left.erase(it);
            c[i]--;
            ans++;
        }
    }
    cout<<ans;*/



    return 0;
}

