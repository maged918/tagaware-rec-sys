//Language: GNU C++11


#include<iostream>
#include<cstdio>
#include<vector>
#include<queue>

#include<map>
#include<set>
#include<string>
#include<algorithm>
#include<functional>
using namespace std;
#define FOR(i,a,b) for (int i=(a);i<(b);i++)
#define RFOR(i,a,b) for (int i=(b)-1;i>=(a);i--)
#define REP(i,n) for (int i=0;i<(n);i++)
#define RREP(i,n) for (int i=(n)-1;i>=0;i--)
#define INF 1<<30
#define MP make_pair
#define mp make_pair
#define pb push_back
#define PB push_back
#define DEBUG(x) cout<<#x<<": "<<x<<endl
#define ll long long
#define ull unsigned long long
const ll MOD=1e9+7;
ll dp[4005];
ll com[4005][4005];

int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);
	int n;
	cin>>n;
	com[0][0]=1;
	FOR(i,1,n+1)REP(j,i+1){
		com[i][j]+=com[i-1][j];
		com[i][j]%=MOD;
		if(j>0) com[i][j]+=com[i-1][j-1];
		com[i][j]%=MOD;
	}
	dp[0]=1;dp[1]=1;
	FOR(i,2,n+1){
		REP(j,i){
// 			DEBUG(i);DEBUG(j);DEBUG(com[i][j]);
			dp[i]=(dp[i]+com[i-1][j]*dp[j]%MOD)%MOD;
		}
	}
	ll ans=0;
	REP(i,n){
		ans=(ans+com[n][i]*dp[i]%MOD)%MOD;
	}
	cout<<ans<<endl;

}
