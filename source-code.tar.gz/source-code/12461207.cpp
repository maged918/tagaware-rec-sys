//Language: GNU C++


#include <cstdio>
#include <vector>

using namespace std;

int main()
{
    int n;
    scanf("%d",&n);
    vector<int>a(n);
    vector<int>b((int)1e5+1,0);
    for(int i=0;i<n;i++)
    {
       scanf("%d",&a[i]);
       b[a[i]]++;     
    }
    int minUnused=0;
    for(int i=1;i<=n;i++)
     if(b[i]==0)
     {
       minUnused=i;
       break;         
     }
    for(int i=0;i<n;i++)
    {
       int x;
       if(b[a[i]]>=2||a[i]>n)
       {
        for(int j=minUnused;j<=n;j++)
        {
          if(b[j]==0)
          {
            x=j;
            break;       
          }     
        }  
        b[a[i]]--;
        b[x]++;   
        a[i]=x;
        minUnused++;
       }
    }
    for(int i=0;i<n;i++)
    {
       printf("%d ",a[i]);     
    }
    
}
