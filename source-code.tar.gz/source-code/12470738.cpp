//Language: GNU C++


#include <iostream>
#include <stdio.h>

using namespace std;

typedef struct tree
{
    int x;
    int h;
} tree;

tree tr[100001];
int td[100001];

int main()
{
    int n, cnt;
    cin >> n;
    for(int i = 0; i < n; i++)
    {
        cin >> tr[i].x >> tr[i].h;
    }
    td[0] = -1;
    td[n-1] = 1;
    
    cnt = (n > 1) ? 2 : 1;

    for(int i = 1; i < n-1; i++)
    {
        if(tr[i].x - tr[i].h > max(tr[i-1].x + td[i-1]*tr[i-1].h, tr[i-1].x))
        {
            td[i] = -1;
            cnt++;
        }
        else if(tr[i].x + tr[i].h < tr[i+1].x)
        {
            td[i] = 1;
            cnt++;
        }
        else
        {
            td[i] = 0;
        }
    }

    cout << cnt << endl;

    return 0;
}