//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#define ll long long
using namespace std;
const ll mod = 1000000007;
const int maxn  = 2000+10;
ll d[maxn],dp[maxn][maxn],fac[maxn];
void init()
{
    d[1]=0,d[2]=1;
    fac[1]=1;fac[2]=2;
    for(int i=3;i<=2000;i++)
    {
        d[i]=(i-1)*(d[i-2]+d[i-1])%mod;
        fac[i]=fac[i-1]*i%mod;
    }
}

int a[maxn];
bool vis[maxn];
ll DP(int n,int k)
{
    if(dp[n][k]!=-1)
        return dp[n][k];
    if(n==0 && k==0)
        return dp[n][k]=0;
    if(n==0)
        return dp[n][k]=d[k];
    if(k==0)
        return dp[n][k]=fac[n];

    return dp[n][k]=(n*DP(n-1,k)%mod+k*DP(n,k-1)%mod)%mod;
}
int main ()
{
    init();
    int n;
    while(~scanf("%d",&n))
    {
        int tmpn=0,tmpk=0;
        memset(vis,0,sizeof(vis));
        memset(a,0,sizeof(a));
        memset(dp,-1,sizeof(dp));
        for(int i=1;i<=n;i++)
        {
            scanf("%d",&a[i]);
            if(a[i]!=-1)
            vis[a[i]]=1;
        }
        for(int i=1;i<=n;i++)
        {
            if(!vis[i])
            {
                if(a[i]!=-1)
                {
                    tmpn++;
                }
                else
                {
                    tmpk++;
                }
            }
        }
        printf("%I64d\n",DP(tmpn,tmpk)%mod);
    }
    return 0;
}
