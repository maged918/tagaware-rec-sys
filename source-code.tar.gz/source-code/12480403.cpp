//Language: GNU C++


// Made By Haireden Aibyn
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <string>
#include <cstdio>
#include <vector>
#include <cmath>
#include <ctime>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>

using namespace std;

#define fname ""
#define INF 2147483647
#define MOD 1000000007
#define sc scanf
#define pr printf
#define pb push_back
#define ex exit(0)
#define tim printf("%.4lf\n", (clock() * 1.) / CLOCKS_PER_SEC)
#define cas printf(""), ex;
#define y1 y4

typedef long long ll;
typedef unsigned long long ull;

const int N = 100500;

int dx[N], dy[N], dz[N];

int main () {
    srand(time(NULL));
    #ifndef ONLINE_JUDGE
    freopen(fname".in", "r", stdin);
    freopen(fname".out", "w", stdout);
    #endif  
    string s;
    cin >> s;
    int m = s.size(); 
    for (int i = 1; i <= m; i++) {
        int x = 0, y = 0, z = 0;
        if (s[i - 1] == 'x') 
           x = 1;
        if (s[i - 1] == 'y')
           y = 1;
        if (s[i - 1] == 'z')
           z = 1;
        dx[i] = dx[i - 1] + x;
        dy[i] = dy[i - 1] + y;
        dz[i] = dz[i - 1] + z;
    }
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        int l, r;
        cin >> l >> r;
        if (r - l + 1 <= 2) { 
           cout << "YES\n";
           continue;
        }
        int x = dx[r] - dx[l - 1];
        int y = dy[r] - dy[l - 1];
        int z = dz[r] - dz[l - 1]; 
        if (abs(x - y) <= 1 && abs(x - z) <= 1 && abs(y - z) <= 1)
           cout << "YES";
        else
           cout << "NO";
        cout << "\n";
    }
    return 0;
}
