//Language: GNU C++


#include<cstdio>
int n,m,i,j,a,vmax,pmax,v[1100];
int main(){
    scanf("%d%d",&n,&m);
    for(i=1;i<=m;i++){
        vmax=-1;
        for(j=1;j<=n;j++){
            scanf("%d",&a);
            if(a>vmax){
                vmax=a;
                pmax=j;
            }
        }
        v[pmax]++;
    }
    vmax=0;
    for(i=1;i<=n;i++){
        if(v[i]>vmax){
            vmax=v[i];
            pmax=i;
        }
    }
    printf("%d",pmax);



    return 0;
}
