//Language: GNU C++


/* Man Mohan Mishra aka m17
   IIIT - Allahabad */
#include <cstdio>
#include <cmath>
#include <cstring>
#include <climits>
#include <cstdlib>
#include <cctype>
#include <iostream>
#include <algorithm>
#include <utility>
#include <string>
#include <vector>
#include <map>
#include <list>
#include <stack>
#include <queue>
#include <set>
#include <iterator>

#define MOD 1000000007
#define INF 1000000000000000000
#define PI acos(-1)

using namespace std;

long long GCD (long long a,long long b) {
	if (b == 0) return a;
	return(a % b == 0 ? b : GCD(b,a % b));
}

long long POW (long long base,long long exp) {
	long long val;
	val = 1;
	while (exp > 0) {
		if (exp % 2 == 1) {
			val = (val * base) % MOD;
		}
		base = (base * base) % MOD;
		exp = exp / 2;
	}
	return val;
}

int a[105];

int main()
{
	int n,m,i,j,idx,mx,num;
	scanf("%d%d",&n,&m);
	for (i = 0; i < m; i++) {
		idx = -1;
		mx = -1;
		for (j = 1; j <= n; j++) {
			scanf("%d",&num);
			if (num > mx) {
				mx = num;
				idx = j;
			}
		}
		a[idx] += 1;
	}
	idx = -1;
	mx = -1;
	for (i = 1; i <= n; i++) {
		if (a[i] > mx) {
			mx = a[i];
			idx = i;
		}
	}
	printf("%d\n",idx);
	return 0;
}
