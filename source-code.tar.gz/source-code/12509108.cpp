//Language: GNU C++


#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>

using namespace std;

int main()
{
    int m, n, ans;
    while(scanf("%d%d", &m, &n) != EOF)
    {
        if(m % 2 == 0)
        {
            if((m - n) >= n)
                ans = n + 1;
            else
                ans = n - 1;
        }
        else
        {
            if((m - n) > n)
                ans = n + 1;
            else
                ans = n - 1;
        }
        if(m == 1) printf("1\n");
        else
        printf("%d\n", ans);
    }
    return 0;
}
