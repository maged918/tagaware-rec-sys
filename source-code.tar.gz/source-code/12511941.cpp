//Language: GNU C++


#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;
typedef long long int ll;

ll maxim(ll ar[],ll n){
    ll m=ar[0];
    
    for(ll j=0;j<n;j++){
        if(ar[j]>m){
        m=ar[j];
        
    }
    }
    return m;
}

ll maxind(ll ar[],ll n,ll m){
    ll ind=0;
    for(ll j=0;j<n;j++){
        if(ar[j]==m){
        ind=j;
        break;
    }
    }
    return ind;
}



int main(){
    
    ll n,m;
    cin>>n>>m;
    ll arr[m][n];
    for(ll i=0;i<m;i++){
        for(ll j=0;j<n;j++){
            cin>>arr[i][j]; 
        }
    }
    
    vector< pair<ll,ll> > max;
    ll temp_max=0;
    ll c[n];
    for(ll i=0;i<m;i++){
        ll temp_arr[n];
        
        for(ll k=0;k<n;k++){
        temp_arr[k]=arr[i][k];
        c[k]=0;
        }
        temp_max=maxim(temp_arr,n);
        max.push_back(make_pair(temp_max,(maxind(temp_arr,n,temp_max))));       
    }
    

    sort(max.begin(),max.end());

    
    for(vector< pair<ll,ll> >::iterator it=max.begin();it!=max.end();it++){
            c[it->second]++;
        }   
    

    ll ansmax=maxim(c,n);
    ll ans=maxind(c,n,ansmax);
    cout<<ans+1<<endl;
    
    return 0;
}