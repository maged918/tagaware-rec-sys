//Language: GNU C++


/*
 Muhammad Magdi Muhammad
 Feb 29, 2012
 A.cpp
 */
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <set>
#include <complex>

#define all(v)          v.begin(),v.end()
#define allr(v)         v.rbegin(),v.rend()
#define rep(i,m)        for(int i=0;i<m;i++)
#define REP(i,k,m)      for(int i=k;i<m;i++)
#define mem(a,b)        memset(a,b,sizeof(a))
#define mp              make_pair
#define pb              push_back
#define OO ((int)1e9)
#define MAX 100000

typedef long long ll;

int diri[] = { -1, 0, 1, 0, -1, 1, 1, -1 };
int dirj[] = { 0, 1, 0, -1, 1, 1, -1, -1 };
int compare(double d1, double d2) {
    if (fabs(d1 - d2) < 1e-9)
        return 0;
    if (d1 < d2)
        return -1;
    return 1;
}

using namespace std;

set<int> haramy;
int tr[100001];
int fa[100001];
int nt, nf;
int n, m, num;
string says[100001];
int main() {
#ifndef ONLINE_JUDGE
    freopen("1.in", "r", stdin);
#endif
    cin >> n >> m;
    string s;

    rep(i,n) {
        cin >> s;
        says[i + 1] = s;
        char c = s[0];
        s[0] = ' ';
        stringstream ss(s);
        ss >> num;
        if (c == '+') {
            tr[num]++, nt++;
        } else
            fa[num]++, nf++;
    }
    for (int i = 1; i <= n; ++i) {
        int ntrue = tr[i] + (nf - fa[i]);
        if (ntrue == m)
            haramy.insert(i);

    }
    for (int i = 1; i <= n; ++i) {
        s = says[i];
        char c = s[0];
        s[0] = ' ';
        stringstream ss(s);
        ss >> num;
        if (c == '+') {
            if (haramy.count(num) < 1)
                cout << "Lie" << endl;
            else if (haramy.count(num) > 0 && haramy.size() == 1) {
                cout << "Truth" << endl;
            } else
                cout << "Not defined" << endl;
        } else {
            if (haramy.count(num) < 1)
                cout << "Truth" << endl;
            else if (haramy.count(num) > 0 && haramy.size() == 1) {
                cout << "Lie" << endl;
            } else
                cout << "Not defined" << endl;
        }
    }
    return 0;
}
