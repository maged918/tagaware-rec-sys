//Language: GNU C++


#include <iostream>
#include <string>
#include <cmath>
using namespace std;

string s;

int main() {
	int n;
	long long ans=0;
	cin >> n >> s;
	for(int i=0; i<s.size(); i++)
		if(s[i] == 'B')
			ans += pow(2, i);
	cout << ans << endl;		
	return 0;
}
	 			 				  		   	      	 			 	