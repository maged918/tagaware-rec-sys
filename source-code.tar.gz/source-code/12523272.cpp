//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

#define sqr(x) (x)*(x)
#define pb push_back

const ll mod=1000000007;

const int maxn=505;
const double eps=1e-9;
const double pi=acos(-1.0);

typedef pair<int,int> pii;

int n,m;
char c[maxn][maxn];

ll dp[2][maxn][maxn]={0};

int main()
{
    int i,j,k,l;
    scanf("%d %d",&n,&m);
    for(i=0;i<n;i++) scanf("%s",c[i]);
    if((n+m)%2)
    {
        i=0;j=(n+m-2)/2;
        while(j>=0)
        {
            if(i<n&&j<m&&i>=0&&j>=0)
            {
                if(j<m-1) dp[0][i][i]=(c[i][j]==c[i][j+1]);
                if(i<n-1) dp[0][i][i+1]=(c[i][j]==c[i+1][j]);
            }
            ++i;--j;
        }
    }
    else
    {
        i=0;j=(n+m-2)/2;
        while(j>=0)
        {
            if(i<n&&j<m&&i>=0&&j>=0)
            {
                dp[0][i][i]=1;
            }
            ++i;--j;
        }
    }
    int can=0,ct;
    for(l=(n+m-2)/2;l>0;l--)
    {
        ct=1-can;
        memset(dp[ct],0,sizeof(dp[ct]));
        for(i=0;i<=l&&i<n;i++)
        {
            if(l-i>=m) continue;
            for(j=i;j<=n+m-2-l&&j<n;j++)
            {
                if(n+m-2-l-j>=m) continue;
                if(n+m-2-l-j<l-i) break;
                if(dp[can][i][j]==0) continue;
                //cout<<can<<" "<<i<<" "<<j<<" "<<dp[can][i][j]<<endl;
                int xt=i,yt=l-i,zt=j,wt=n+m-2-l-j;
                if(xt>0&&zt<n-1)
                {
                    dp[ct][xt-1][zt+1]+=dp[can][xt][zt]*(c[xt-1][yt]==c[zt+1][wt]);
                    dp[ct][xt-1][zt+1]%=mod;
                }
                if(yt>0&&zt<n-1)
                {
                    dp[ct][xt][zt+1]+=dp[can][xt][zt]*(c[xt][yt-1]==c[zt+1][wt]);
                    dp[ct][xt][zt+1]%=mod;
                }
                if(xt>0&&wt<m-1)
                {
                    dp[ct][xt-1][zt]+=dp[can][xt][zt]*(c[xt-1][yt]==c[zt][wt+1]);
                    dp[ct][xt-1][zt]%=mod;
                }
                if(yt>0&&wt<m-1)
                {
                    dp[ct][xt][zt]+=dp[can][xt][zt]*(c[xt][yt-1]==c[zt][wt+1]);
                    dp[ct][xt][zt]%=mod;
                }
            }
        }
        can=ct;
    }
    printf("%d\n",int(dp[can][0][n-1]));
    return 0;
}
