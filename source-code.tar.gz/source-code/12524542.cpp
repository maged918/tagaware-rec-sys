//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
const int MOD = 1e9+7;
const int N = 4000 + 100;
int C[N][N],dp[N][N];
void init()
{
    memset(C,0,sizeof(C));
    for(int i=1;i<=4000;i++)
    {
        for(int j=0;j<=i;j++)
        {
            if(j == 0 || j == i) C[i][j] = 1;
            else C[i][j] = ( C[i-1][j-1] + C[i-1][j] ) % MOD;
        }
    }

    for(int i=1;i<=4000;i++)
    {
        for(int j=0;j<=i;j++) {
            if( j == 0 ) dp[i][j] = 0;
            else if(j == i) dp[i][j] = 1;
            else {
                dp[i][j] = (1ll*j*dp[i-1][j] + dp[i-1][j-1]) % MOD;
            }
        }
    }
}
int main()
{
    init();
    int n;
    while(cin>>n){
        int ans = 1;
        for(int i=1;i<n;i++)
        {
            LL x = C[n][i];LL sum = 0;
            for(int j=0;j<=i;j++) {
                sum += dp[i][j];
                sum %= MOD;
            }
         //   cout<<"i= "<<i<<" sum = "<<sum<<endl;
            x *= sum;
            x %= MOD;
            ans  = (ans + x)%MOD;
        }
        cout<<ans<<endl;
    }
}
