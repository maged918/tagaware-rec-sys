//Language: GNU C++11


#include <bits/stdc++.h>
#include <tuple>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define INF 1e9
#define MP make_pair
#define SZ(c) int(c.size())
#define SQ(c) ((c) * 1ll * (c))
#define ALL(c) c.begin(), c.end()
#define SET(c, v) memset(c, v, sizeof c)

const int N = 2e6;

int prime[N];

bool palin(int n) {
    int d[10], j = 0;
    while (n) {
        d[j++] = n % 10;
        n /= 10;
    }
    for (int i = 0, k = j - 1; i < j / 2; ++i, --k)
        if (d[i] != d[k]) return 0;
    return 1;
}

int main() {
#ifndef ONLINE_JUDGE
    freopen("inp.txt", "r", stdin);
#endif
    int p, q;
    scanf("%d %d", &p, &q);
    fill(prime, prime + N, 1);
    prime[0] = prime[1] = 0;
    for (int i = 2; i * i < N; ++i)
        if (prime[i]) for (int j = i * i; j < N; j += i)
            prime[j] = 0;
    int a = 0, b = 0, ans = 0;
    for (int i = 1; i < N; ++i) {
        if (prime[i]) ++a;
        if (palin(i)) ++b;
        if (q * a <= p * b) ans = i;
    }
    printf("%d\n", ans);
    return 0;
}