//Language: GNU C++11


#include<bits/stdc++.h>

using namespace std;

// Shortcuts for "common" data types in contests
typedef long long int ll;
typedef vector<int> vi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef set<int> si;
typedef map<string, int> msi;
// To simplify repetitions/loops, Note: define your loop style and stick with it!
#define s(i) scanf("%d",&i)
#define sl(i) scanf("%ld",&i)
#define sll(i) scanf("%lld",&i)
#define REP(i, a, b) \
for (int i = int(a); i <= int(b); i++) // a to b, and variable i is local!
#define NREP(i,a,b) \
for (int i = int(a); i >= int(b); i--)
#define TRvi(c, it) \
for (vi::iterator it = (c).begin(); it != (c).end(); it++)
#define TRvii(c, it) \
for (vii::iterator it = (c).begin(); it != (c).end(); it++)
#define TRmsi(c, it) \
for (msi::iterator it = (c).begin(); it != (c).end(); it++)
#define MOD 1000000007 // 2 billion

char a[509][509] ;
int dp[3][509][509] ;

int main()
{
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
    int n , m ; s(n) ; s(m) ;
    getchar();
    REP( i , 1 , n )
    {
        REP( j , 1 , m )
        {
            a[i][j] = getchar();
         //   printf("%c ",a[i][j]);
        }
       // printf("\n");
        getchar();
    }
    int maxd = ( n + m ) / 2 ;
    REP( x , 1 , n )
    {
        REP( p , 1 , n )
        {
            int y = maxd + 1 - x , q = n + m - p - maxd + 1;
            if( x <= p && y <= q && a[x][y] == a[p][q] && y >= 1 && y <= m && q >= 1 && q <= m  )
            {
    //            cout << x << " " << y << " " << p << " " << q << endl;
                dp[maxd % 2][x][p] = 1;
            }
        }
    }
    NREP( i , maxd - 1 , 1 )
    {
        REP( x , 1 , n )
        {
            REP( p , 1 , n )
            {
                int y = i + 1 - x , q = n + m - p - i + 1;
                //cout << x << " " << y << " " << p << " " << q << endl;
                if( x > p || y > q || q > m || q < 1 || y > m || y < 1 )
                {
                    dp[i % 2][x][p] = 0 ;
                    continue;
                }
                if( a[x][y] != a[p][q] )
                {
                    dp[i % 2][x][p] = 0;
                    continue;
                }
                //cout << ( i % 2 ) << " " << ( 1 - i % 2 ) << endl;
                dp[i % 2][x][p] = 0;
                if( x + 1 <= n && p - 1 >= 1 )
                    dp[i % 2][x][p] += dp[1 - i % 2][x + 1][p - 1];
                dp[i % 2][x][p] %= MOD;
                dp[i % 2][x][p] += dp[1 - i % 2][x][p];
                dp[i % 2][x][p] %= MOD;
                if( x + 1 <= n )
                    dp[i % 2][x][p] += dp[1 - i % 2][x + 1][p];
                dp[i % 2][x][p] %= MOD;
                if( p - 1 >= 1 )
                    dp[i % 2][x][p] += dp[1 - i % 2][x][p - 1];
                dp[i % 2][x][p] %= MOD;
            }
        }
    }
    printf("%d\n",dp[1][1][n]);
    return 0;
}
