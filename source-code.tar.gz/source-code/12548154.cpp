//Language: GNU C++


#include<iostream>
using namespace std;

int rub[2000001]={},prime[2000001]={};
int flag[2000001]={};
int main()
{
int i,cur=0,curpalind=1,check,got;
long long int temp,j,last=10,p,q;
rub[1]=1;
cin >> p >> q;
for(i=2;i<2000001;i++)
{
	if(!flag[i])
	{
		j=(long long int)i;
		temp=j;
		while(temp*j<2000001)
		{
			flag[temp*j]=1;
			j++;
		}

		cur++;
	}
	prime[i]=cur;
	if(i!=last)
	{
		check=i;
		got=0;
		while(check!=0)
		{
			got=got*10+check%10;
			check/=10;
		}
		if(got==i)
			curpalind++;
	}
	else
		last+=10;
	rub[i]=curpalind;

}
cur=1;
for(i=1;i<2000000;i++)
{
	if((long long int)((long long int)prime[i]*q) <= (long long int)((long long int)rub[i]*p))
		cur=i;
}
cout << cur << endl;
return 0;
}