//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

int n;

int main () {
    cin >> n;

    int s; int last = -1; int t = 0;
    for (int i=0; i<n; i++) {
        cin >> s;
        if (!s) continue;

        if (last == -1) {
            t++;
        } else {
            if (last == i-1) {
                t++;
            } else t+=2;
        }
        last = i;
    }

    cout << t << endl;
}
