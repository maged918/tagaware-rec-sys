//Language: GNU C++


#include <bits/stdc++.h>
#define SZ(x) (int)x.size()
using namespace std;

int main() {

//  string s, s1, s2;
//  cin >> s >> s1 >> s2;
//
//  int i = s.find(s1), j = s.find(s2, max(i + (int) s1.size(), 0));
//  reverse(s.begin(), s.end());
//  int i1 = s.find(s1), j1 = s.find(s2, max(i1 + (int) s1.size(), 0));
//  if (min(min(i, j), min(i1, j1)) > -1)
//      cout << "both";
//  else if (min(i, j) > -1)
//      cout << "forward";
//  else if (min(i1, j1) > -1)
//      cout << "backward";
//  else
//      cout << "fantasy";

    int n;
    cin >> n;
    cout << n << " ";
    for (int i = 1; i < n; ++i) {
        cout << i << " ";
    }
    cout << endl;

}
