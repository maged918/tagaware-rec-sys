//Language: GNU C++


#include<stdio.h>
#include<cstdio>
#include<stdlib.h>
#include<string.h>
#include<algorithm>
#include<iostream>
#include<set>
#include<map>
#include<math.h>
#define N 110
using namespace std;

int x[1000010];
int main() {
	int n, key = 0; 
	scanf("%d", &n);
	for(int i=0; i<n; i++) scanf("%d", &x[i]);
	sort(x, x+n);
	for(int i=0; i<n; i++) {
		if(x[i]==1 || (i>1 && x[i]==x[i-1])) continue;
		for(int j=2; x[i]*(j-1)<=x[n-1]; j++) {
			int num = lower_bound(x, x+n, x[i]*j) - x;
			key = key>=x[num-1]%x[i] ? key : x[num-1]%x[i];
		}
	}
	printf("%d\n", key);
	return 0;
}



//int len(long long int x) {
//	int len = 0;
//	while(x!=0) {
//		x >>= 1; len++;
//	}
//	return len;
//}
//int main() {
//	int n; 
//	long long int l, r;
//	scanf("%d", &n);
//	for(int i=0; i<n; i++) {
//		scanf("%I64d %I64d", &l, &r);
//		int len_l = l==0?1:len(l);
//		int len_r = r==0?1:len(r);
//		
//		long long int m = 0;
//		for(int i=0; i<len_r; i++) m += pow(2, i); 
//		long long int a = r^m;
//		
//		if(l==r) {
//			printf("%I64d\n", r); continue;
//		}
// 		if(a==0) {
// 			printf("%I64d\n", r); continue;
// 		} 
// 		if(len_l<len_r) {
// 			long long int x = 0;
//			for(int i=0; i<len_r-1; i++) x += pow(2, i);
// 			printf("%I64d\n", x); continue;
// 		}
// 		
// 		long long int x = l^r;
// 		int len_add = len(x)-1;
// 		if(len_add==0) {
// 			printf("%I64d\n", r); continue;
// 		}
// 		
// 		x = 0;
// 		for(int i=0; i<len_add; i++) x += pow(2, i);
// 		long long int y = l, z = r;
// 		bool state = false;
// 		for(int i=0; i<len_add; i++) {
// 			int c = y&1; 
// 			int d = z&1;
// 			if(d==0) state = true;
// 			l -= c*pow(2, i);
// 			y>>=1;
// 			z>>=1;
// 		}
// 		if(state) {
// 			x += l; 		
// 			printf("%I64d\n", x);
// 		} else {
// 			printf("%I64d\n", r);
// 		} 
// 		
//	}
//	
//	return 0;
//} 
	 	 		 	  	 				 	  	 	 	 	 	