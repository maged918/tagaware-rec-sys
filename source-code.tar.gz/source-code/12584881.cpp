//Language: GNU C++11


#include<bits/stdc++.h>
#define LL long long
#define x first
#define y second
using namespace std;

int n;
vector<pair<LL, int>> a;
LL k, ans = 0;

bool ss(pair<LL, int> xx, pair<LL, int> yy){
    return xx.x < yy.x;
}
bool tt(pair<LL, int> xx, pair<LL, int> yy){
    return xx.y <= yy.y;
}

int main(){
    cin >> n >> k;
    for(int i=0,b; i<n; i++) { cin >> b; a.push_back({b,i});}
    sort(a.begin(), a.end(), [](pair<LL, int> xx, pair<LL, int> yy)
    { return xx.x < yy.x || (xx.x == yy.x && xx.y < yy.y);});
    
    // Primary school algorithm: loop all element, try to use it as the middle number
    // bsearch range of  item/k  & item * k,  then for each range, bsearch again for position < (or >) item's position
    // crazy abuse C++11 feature, actually may write very simply 4 bsearch, do not use lambda is better, as resuse many times
    
    // shit 1: Damn Codeforces not allow auto in lambda 
    // shit 2: Damn, C++11 equal_range(), lower_bound() etc, you cannot use {x,y} as search value of a List<pair<>>, if you use lambda as well
    for(auto item: a){
        if(item.x % k != 0) continue;
        LL lo = item.x / k, hi = item.x * k, cp = item.y;
        pair<LL, int> v1 = {lo, cp}, v2 = {hi, cp};
        auto lo1 = equal_range(a.begin(), a.end(), v1, ss);
        auto hi1 = equal_range(a.begin(), a.end(), v2, ss);
        
        if(lo1.y - lo1.x == 0) continue;
        if(hi1.y - hi1.x == 0) continue;
        // shit 3: even equal position must seem as different, to handle k = 1 case
        auto lo2 = upper_bound(lo1.x, lo1.y, v1, tt);
        auto hi2 = lower_bound(hi1.x, hi1.y, v2, tt);
        
        // shit 4: cast to LL not only to ans, but each of the element of the *
        ans += (LL)(lo2-lo1.x)*(LL)(hi1.y-hi2);
    }
    cout << ans << endl;
    return 0;   
}