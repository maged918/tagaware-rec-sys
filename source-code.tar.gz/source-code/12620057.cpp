//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <cstring>
#include <iomanip>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <stdio.h>
#include <set>
#include <map>
#include <sstream>
using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int,int> pii;
#define x first
#define y second
#define mp make_pair
#define pb push_back
ll G(ll a,ll b){if(b==0)return a;return G(b,a%b);}
bool r[2222],c[2222];
double dp[2222][2222];
int main(){
	ios_base::sync_with_stdio(false);
	ll n,m,a=0,b=0;
	cin>>n>>m;
	for(int i=0;i<m;i++){
		ll q,w;
		cin>>q>>w;
		if(!r[q])a++;
		if(!c[w])b++;
		r[q]=1;
		c[w]=1;
	}
	a=n-a,b=n-b;
	for(int i=0;i<=a;i++){
		for(int j=0;j<=b;j++){
			if(i+j==0)continue;
			if(j==0){
				dp[i][j]=dp[i-1][j]+(double)n/i;
				continue;
			}
			if(i==0){
				dp[i][j]=dp[i][j-1]+(double)n/j;
				continue;
			}
			dp[i][j]+=(double)i*j/(n*n)*dp[i-1][j-1];
			dp[i][j]+=(double)i*(n-j)/(n*n)*dp[i-1][j];
			dp[i][j]+=(double)(n-i)*j/(n*n)*dp[i][j-1];
			dp[i][j]++;
			dp[i][j]/=1-(((double)n-i)*(n-j))/(n*n);
		}
	}/*
	for(int i=0;i<5;i++){
		for(int j=0;j<5;j++){
			cout<<dp[i][j]<<" ";
		}
		cout<<endl;
	}*/
	cout<<fixed<<setprecision(6)<<dp[a][b]<<endl;
}


    	 	      	   			   	 	 		 	