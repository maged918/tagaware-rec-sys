//Language: MS C++


#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#define optimize ios_base::sync_with_stdio(false)
using namespace std;
typedef pair<int,int> pii;
typedef long long lint;
#define MOD 1000000007
#define MAXN 100000

lint fmin(lint a, lint b)
{
    return a < b? a: b;
}
lint fmax(lint a, lint b)
{
    return a > b? a: b;
}
int getBit(int n, int pos)
{
    return (n >> pos) & 1;
}

int m, n;
int q;
int arr[502][502];
vector<int> res[502];
bool ss(int a, int b)
{
    return a > b;
}
void make(int row)
{
    res[row].clear();
    int len = 0;
    for (int i = 1; i <= n + 1; i++)
    {
        if (arr[row][i] == 1)
            len++;
        else
        {
            if (len > 0)
            {
                res[row].push_back(len);
                len = 0;
            }
        }
    }
    sort(res[row].begin(), res[row].end(), ss);
}

int main()
{
    optimize;


    cin >> m >> n >> q;

    for (int i = 0; i <= m+1; i++)
        for (int j = 0; j <= n+1; j++)
            arr[i][j] = 0;

    for (int i = 1; i <= m; i++)
        for (int j = 1; j <= n; j++)
            cin >> arr[i][j];
    
    for (int i = 1; i <= m; i++)
        make(i);

    while (q--)
    {
        int x, y;
        cin >> x >> y;
        arr[x][y] = 1 - arr[x][y];
        make(x);
        int max = 0;
        for (int i = 1; i <= m; i++)
            if (res[i].size() > 0)
            {
                if (res[i][0] > max)
                    max = res[i][0];
            }
        cout << max << endl;
    }
}