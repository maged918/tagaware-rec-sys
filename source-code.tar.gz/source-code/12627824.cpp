//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>

using namespace std;

int main(){
    ios_base::sync_with_stdio(0);
#ifdef LOCAL
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#else

#endif //LOCAL
    long long r, x, y, x_, y_;
    cin >> r >> x >> y >> x_ >> y_;
    long double dist = sqrt((x-x_)*(x-x_) + (y-y_)*(y-y_));
    cout << (long long) (ceil(dist/(1ll*2*r))) << endl;
    return 0;
}
