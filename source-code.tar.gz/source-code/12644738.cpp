//Language: GNU C++


#include <iostream>
#include <string>

using namespace std;

int frq[200001];

int main()
{

string s;
cin >> s;
int m, a;
cin >> a;
for(int i=0; i<a; i++){
    cin >> m;
    frq[m-1]++;
}
for(int i=1; i<s.size() ; i++){
    frq[i]+=frq[i-1];
}
for(int i=0; i<s.size()/2 ; ++i){
    if(frq[i]%2!=0){
        swap(s[i],s[s.size()-i-1]);
    }
}

cout << s <<endl;
    return 0;
}
