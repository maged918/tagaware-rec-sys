//Language: GNU C++


#include <iostream>
#define MAXN 100005

using namespace std;

typedef long long ll;

ll A[MAXN],B[MAXN];
ll na,nb,m,k;

void Read(){
    cin>>na>>nb>>m>>k;
    for(int i=0;i<na;i++) cin>>A[i];
    for(int i=0;i<nb;i++) cin>>B[i];
}

int main()
{
    Read();
    if(A[m-1] < B[nb-k]) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;

    return 0;
}
