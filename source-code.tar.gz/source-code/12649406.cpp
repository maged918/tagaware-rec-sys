//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int na,nb,k,m,inputa[100005],inputb[100005];
int main(int argc, char** argv) {
	int i,j,z;
	while(scanf(" %d %d",&na,&nb)==2){
		scanf(" %d %d",&k,&m);
		for(i=0;i<na;i++){
			scanf(" %d",&inputa[i]);
		}
		for(i=0;i<nb;i++){
			scanf(" %d",&inputb[i]);
		}
		if(inputb[nb-m]>inputa[k-1]){
			printf("YES\n");
		}
		else{
			printf("NO\n");
		}
	}
	return 0;
}
