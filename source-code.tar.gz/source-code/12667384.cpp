//Language: GNU C++


//#pragma comment(linker, "/STACK:1024000000,1024000000")
#include<iostream>
#include<algorithm>
#include<cassert>
#include<string>
#include<sstream>
#include<set>
#include<bitset>
#include<vector>
#include<stack>
#include<map>
#include<queue>
#include<deque>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<ctime>
#include<cctype>
#include<functional>
using namespace std;

#define me(s)  memset(s,0,sizeof(s))
#define rep(i,n) for(int i=0;i<(n);i++)
typedef long long ll;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef pair <int, int> P;



ll a,b,c,l;

int main()
{
    while(cin>>a>>b>>c>>l)
    {
        ll ans=0;
        ll maxsum=a+b+c+l;
        for(ll i=a;i<=a+l;i++)
            if(b+c>i)continue;
        else
        {
            ans+=(min(i,maxsum-i)-b-c+1)*(min(i,maxsum-i)-b-c+2)/2;
        }
        for(ll i=b;i<=b+l;i++)
            if(a+c>i)continue;
        else ans+=(min(i,maxsum-i)-a-c+1)*(min(i,maxsum-i)-a-c+2)/2;
        for(ll i=c;i<=c+l;i++)
            if(b+a>i)continue;
        else ans+=(min(i,maxsum-i)-b-a+1)*(min(i,maxsum-i)-b-a+2)/2;
        printf("%I64d\n",(l+1)*(l+2)*(l+3)/6-ans);
    }
}




















