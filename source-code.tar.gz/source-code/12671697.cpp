//Language: GNU C++11


/*
  Aeksios aohos onoso ilon jehikas
  Kesrio syt bantis zobrie issa se ossyngnoti ledys!
*/

#include <algorithm>
#include <vector>
#include <limits>

#include <cstdio>

using namespace std;

const int maxn = 300005;

int n, k;

long long a[maxn];
long long dp[2][5005];

int main() {
#ifdef AEKSIO_ONO_ELENI_JEVE_RYBIS
  freopen("data.txt", "r", stdin);
#endif

  scanf("%d%d", &n, &k);
  for (int i = 0; i < n; ++i) scanf("%lld", a + i);
  sort(a, a + n);

  int sz = n / k;
  int total_lg = n % k;  // chunks of size (sz + 1)

  for (int i = 1; i <= k; ++i) {
    swap_ranges(dp[0], dp[0] + 5005, dp[1]);
    fill(dp[1], dp[1] + 5005, numeric_limits<long long>::max());
    for (int lg = 0; lg <= i; ++lg) {
      if (lg > 0) {
        int l = (lg - 1) * (sz + 1) + (i - lg) * sz;
        int r = l + sz + 1;
        if (l >= 0 && r <= n)
          dp[1][lg] = min(dp[1][lg], dp[0][lg - 1] + a[r - 1] - a[l]);
      }
      if (lg < i) {
        int l = lg * (sz + 1) + (i - 1 - lg) * sz;
        int r = l + sz;
        if (l >= 0 && r <= n)
          dp[1][lg] = min(dp[1][lg], dp[0][lg] + a[r - 1] - a[l]);
      }
    }
  }

  printf("%lld\n", dp[1][total_lg]);
}
