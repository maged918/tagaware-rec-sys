//Language: MS C++


#pragma comment(linker,"/stack:67108864")
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <sstream>
#include <fstream>
#include <climits>
#include <cfloat>
#include <functional>
#include <ctime>
#include <numeric>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <algorithm>
#include <cstring>
#include <utility>
#include <bitset>
#include <string>
#include <list>
#include <stack>
#include <vector>
#include <queue>
#include <deque>
#include <map>
#include <set>
#include <typeinfo>
#include <cassert>
#include <ctime>

using namespace std;

#define forn(i, n) for(int i = 0; i < int(n); ++i)
#define forn1(i, n) for(int i = 1; i <= int(n); ++i)
#define ford(i, n) for(int i = int(n) - 1; i >= 0; --i)
#define ford1(i, n) for(int i = int(n); i > 0; --i)
#define foran(i, a, n) for(int i = int(a); i <= int(n); ++i)

#define mp make_pair
#define pb push_back
#define sqr(x) (x)*(x)
#define all(v) (v).begin(),(v).end()

typedef long double ld;
typedef long long ll;

const ld EPS = 1e-9;
const ld PI = 3.1415926535897932384626433832795;
const ll INF = 1000 * 1000 * 1000 + 9;
const int NMAX = 1000*1000 + 3;

int a, b, c, l;

inline bool read()
{
    if (!(cin >>a >>b >>c >>l))
        return false;
    return true;
}

ll calc(int a, int b, int len)
{
    ll ans = 0;
    if (a > b) swap(a, b);
    if (len <= a)
        ans = 1LL * (len + 1) * (len + 2) / 2;
    if (a < len && len < b)
        ans = 1LL * (len - a + 1 + len + 1) * (a + 1) / 2;
    if (b <= len && len < a + b)
    {
        int a_f = len - b;
        ans = 1LL * (a_f + 1) * (b + 1);
        ans += 1LL *(a - a_f) * (len - a + 1 + b) / 2;
    }
    if (len >= a + b)
        ans = 1LL * (a + 1) * (b + 1);
    return ans;
}

ll a_bc(int a, int b, int c, int l)
{
    //calculate number of triangles with biggest side a
    ll ans = 0;
    forn(i, l + 1)
    {
        int newa = a + i;
        if (b + c + l - i <= newa) continue;
        int addmin = max(0, newa - b - c + 1);
        int addmax = l - i;
        int mlb = newa - 1 - b;
        int mlc = newa - 1 - c;
        if (mlb < 0 || mlc < 0) continue;
        if (mlb + mlc < addmin) continue;
        ans += calc(mlb, mlc, addmax) - calc(mlb, mlc, addmin - 1);
        //cerr <<mlb <<' ' <<mlc <<' ' <<addmax <<endl;//calc(mlb, mlc, addmax) <<endl;
    }
    return ans;

}

ll ab_c(int a, int b, int c, int l)
{
    //calculate number of triangles with biggest equal sides a and b
    ll ans = 0;
    forn(i, l + 1)
    {
        int newa = a + i;
        int newb = newa;

        if (newb < b) continue;
        int addmin = (newa - a) + (newb - b) ;
        if (addmin > l) continue;
        if (newa <= c) continue;
        ans += (ll)min(l - addmin + 1, newa - c);
    }
    return ans;
}

ll eq_triangles(int a, int b, int c, int l)
{
    //calculate equilateral triangles
    ll ans = 0;
    forn(i, l + 1)
    {
        int newa = a + i;
        int newb = newa;
        int newc = newa;

        if (newb < b) continue;
        if (newc < c) continue;
        int addmin = (newa - a) + (newb - b) + (newc - c) ;
        if (addmin > l) continue;
        ans ++;
    }
    return ans;
}

inline void solve()
{   
    ll ans = 0;
    ans += a_bc(a, b, c, l);
    ans += a_bc(b, a, c, l);
    ans += a_bc(c, a, b, l);
    ans += ab_c(a, b, c, l);
    ans += ab_c(a, c, b, l);
    ans += ab_c(b, c, a, l);
    ans += eq_triangles(a, b, c, l);
    cout <<ans <<endl;
}

int main()
{
    ifstream ifile("input.txt");
    if (ifile) {
        freopen("input.txt", "rt", stdin);
    }
#ifdef ONLINE_JUDGE
    if (ifile) {
        freopen("output.txt","wt",stdout);
    }
#endif
    while(read())
        solve();
    return 0;
}
