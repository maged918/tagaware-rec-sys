//Language: GNU C++11


#include <iostream>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <algorithm>
#include <map>
#include <cmath>
#include <set>

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pii;

#define fi first
#define se second
#define mp make_pair
#define pb push_back

const int INF = 1 << 30;
const double EPS = 1e-12;

const int maxn = 542;
string d[maxn];

ll dp[2][maxn][maxn];
const ll mod=1000000007;

int main()
{
    ios_base::sync_with_stdio(0);
    int n, m;
    cin>>n>>m;
    for(int i=0;i<n;i++) cin>>d[i];
    dp[0][0][0]=(d[0][0]==d[n-1][m-1]);
    for(int i=1;i<(n+m)/2;i++)
    {
        ll ans=0;
        for(int j=0;j<=i;j++)
        {
            for(int k=0;k<=i;k++)
            {
                int x1=i-j, y1=j;
                int x2=n-1-i+k, y2=m-1-k;
                dp[i%2][j][k]=0;
                if(x1>=n || x2>=n || y1>=m || y2>=m) continue;
                if(x1>x2 || y1>y2) continue;
                if(d[x1][y1]!=d[x2][y2]) continue;
                for(int dj=-1;dj<1;dj++)
                {
                    for(int dk=-1;dk<1;dk++)
                    {
                        if(j+dj>=0 && k+dk>=0)
                        {
                            dp[i%2][j][k]+=dp[!(i%2)][j+dj][k+dk];
                        }
                    }
                }
                dp[i%2][j][k]%=mod;
                //cout<<"dla "<<x1<<" "<<y1<<" " <<x2<<" "<<y2<<" jest "<<dp[i%2][j][k]<<endl;
                if(x2-x1+y2-y1<=1) ans=(ans+dp[i%2][j][k])%mod;
            }
        }
        if(i+1>=(n+m)/2)
        {
            cout<<ans<<"\n";
        }
    }
}
