//Language: GNU C++11


#include<cstdio>
#include<set>
#include<vector>
int abs(int xx){return xx>0?xx:-xx;}
int a,b,c,i,j,t,u,s,d[200023],ans[200023];
bool ch[200023];
std::vector<int>G[200022],H[200022];
struct A{
    int how,num;
};
bool operator<(A aa,A bb){return aa.how<bb.how;}
std::multiset<A>S;
std::multiset<A>::iterator it;
main()
{
    scanf("%d%d",&a,&b);
    for(i=1;i<=a;i++)
    {
        scanf("%d",&c);
        d[i]=c;
        for(j=0;j<c;j++)
        {
            scanf("%d",&t);
            G[i].push_back(t);
            if(t<0)H[-t].push_back(i);
            else H[t].push_back(i);
        }
    }
    for(i=1;i<=a;i++)S.insert({d[i],i});
    int check,p;
    while(!S.empty())
    {
        it=S.begin();
        A s=*it;
        S.erase(it);
        if(ch[s.num])continue;
        ch[s.num]=1;
        check=0;
        for(i=0;i<G[s.num].size();i++)
        {
            if((G[s.num][i]<0&&ans[-G[s.num][i]]==-1)||(G[s.num][i]>0&&ans[G[s.num][i]]==1))
            {
                break;
            }
            else if((G[s.num][i]<0&&ans[-G[s.num][i]]==1)||(G[s.num][i]>0&&ans[G[s.num][i]]==-1))
            {
                check++;
            }
        }
        if(i!=G[s.num].size())continue;
        if(check==G[s.num].size())
        {
            printf("NO");
            return 0;
        }
        for(i=0;i<G[s.num].size();i++)
        {
            if(ans[abs(G[s.num][i])]==0)break;
        }
        p=abs(G[s.num][i]);
        ans[p]=G[s.num][i]/p;
        d[s.num]--;
        for(i=0;i<H[p].size();i++)
        {
            if(H[p][i]!=s.num)
            {
                d[H[p][i]]--;
                S.insert({d[H[p][i]],H[p][i]});
            }
        }
    }
    puts("YES");
    for(i=1;i<=b;i++)
    {
        if(ans[i]==1)printf("1");
        else printf("0");
    }
}
