//Language: GNU C++11


#define _CRT_SECURE_NO_WARNINGS
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>

#define oo 1e9
#define pi 3.1415926536
#define all(x) x.begin(),x.end()
#define sorta(x) sort(all(x))
#define sortam(x,comp) sort(all(x),comp)
#define sortd(x) sort(x.rbegin(),x.rend())
#define sf(x) scanf("%d", &x);
#define sf2(x, y) scanf("%d %d", &x, &y);
#define sf3(x, y, z) scanf("%d %d %d", &x, &y, &z);
#define sfll(x) scanf("%I64d", &x);
#define sfll2(x, y) scanf("%I64d %I64d", &x, &y);
#define sfll3(x, y, z) scanf("%I64d %I64d %I64d", &x, &y, &z);
#define sfd(x) scanf("%f", &x);
#define pr(x) printf("%I64d\n", x);

typedef long long ll;
using namespace std;
ll fact[500010];
ll dp[2010];
ll mod = 1e9 + 7, h, w, n;
pair<ll, ll>b[2010];

ll pw(ll b, ll p) {
    if(p == 1) return b;
    else if(p % 2 == 0) return pw((b*b) % mod, p / 2);
    return (pw(b, p - 1)*b) % mod;
}

ll C(ll n, ll r) {
    return (fact[n] * pw((fact[n - r] * fact[r]) % mod, mod - 2) % mod) % mod;
}

ll go(int i) {
    if(dp[i] != -1) return dp[i];
    ll ret = C(h - b[i].first + w - b[i].second, h - b[i].first);
    for(int j = 0; j <= n; j++) {
        if(i != j && b[j].first >= b[i].first && b[j].second >= b[i].second)
            ret = (ret - (go(j) * C(b[j].first - b[i].first + b[j].second - b[i].second, b[j].first - b[i].first)) % mod + mod) % mod;
    }
    return dp[i] = ret;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    memset(dp, -1, sizeof dp);
    fact[0] = 1;
    for(ll i = 1; i < 500010; i++) fact[i] = (fact[i - 1] * i) % mod;
    cin >> h >> w >> n;
    h--; w--;
    b[0] = {0, 0};
    for(int i = 1; i <= n; i++) {
        cin >> b[i].first >> b[i].second;
        b[i].first--;
        b[i].second--;
    }

    cout << go(0) << endl;
    return 0;
}