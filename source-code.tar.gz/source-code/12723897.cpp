//Language: GNU C++11


#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <stdio.h>

using namespace std;

const int N = 300000;
int x[N][2];
int ans[N];
bool hear[N];
vector <pair <int, int> > G[N];

int color[N];

void dfs1(int s)
{
	color[s] = 1;
	for (int i = 0; i < (int)G[s].size(); i++)
	{
		int v = G[s][i].first;
		if (color[v] == 0){
			if (G[s][i].second > 0) {
				ans[G[s][i].second] = 1;
			}
			else {
				ans[-G[s][i].second] = 0;
			}
			dfs1(v);
		}
	}
	color[s] = 2;
}

pair <int, int> cyc;
void dfs2(int s, int per = -1)
{
	color[s] = 1;
	for (int i = 0; i < (int)G[s].size(); i++)
	{
		int v = G[s][i].first;
		if (color[v] == 0) {
			dfs2(v, abs(G[s][i].second));
		}
		if ((color[v] == 1) && (per != abs(G[s][i].second))){
			cyc.first = s;
			cyc.second = i;
		}
	}
	color[s] = 2;
}

int color1[N];
void dfs3(int s, int per){
	color1[s] = 1;
	for (int i = 0; i < (int)G[s].size(); i++)
	{
		int v = G[s][i].first;
		if (abs(G[s][i].second) == per) {
			continue;
		}
		if (color1[v] == 0) {
			ans[abs(G[s][i].second)] = (G[s][i].second > 0 ? 1 : 0);
			dfs3(v, abs(G[s][i].second));
		}
	}
	color1[s] = 2;
}

int main()
{
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
	{
		int k;
		//cin >> k;
		scanf("%d", &k);
		for (int j = 0; j < k; j++)
		{
			int r;
			//cin >> r;
			scanf("%d", &r);
			if (x[abs(r)][0] == 0){
				x[abs(r)][0] = i * (r > 0 ? 1 : -1);
			}
			else {
				x[abs(r)][1] = i * (r > 0 ? 1 : -1);
			}
		}
	}

	for (int i = 1; i <= m; i++)
	{
		if ((x[i][0] >= 0) && (x[i][1] >= 0)){
			ans[i] = 1;
			hear[x[i][0]] = 1;
			hear[x[i][1]] = 1;
		}
		else if ((x[i][0] <= 0) && (x[i][1] <= 0)){
			ans[i] = 0;
			hear[-x[i][0]] = 1;
			hear[-x[i][1]] = 1;
		}
		else
		{
			int v1 = abs(x[i][0]);
			int v2 = abs(x[i][1]);
			G[v1].push_back(make_pair(v2, i * (x[i][1] > 0 ? 1 : -1)));
			G[v2].push_back(make_pair(v1, i * (x[i][0] > 0 ? 1 : -1)));
		}
	}

	for (int i = 1; i <= n; i++)
	{
		if ((hear[i] == 1) && (color[i] == 0))
		{
			dfs1(i);
		}
	}

	for (int i = 1; i <= n; i++)
	{
		if (color[i] == 0)
		{
			cyc.first = 0;
			dfs2(i);
			if (cyc.first == 0) {
				cout << "NO" << endl;
				return 0;
			}
			else
			{
				int s = cyc.first;
				int j = cyc.second;
				ans[abs(G[s][j].second)] = (G[s][j].second > 0 ? 1 : 0);
				dfs3(G[s][j].first, abs(G[s][j].second));
			}
		}
	}
	cout << "YES" << endl;
	for (int i = 1; i <= m; i++)
	{
		cout << ans[i];
	}
	cout << endl;
}

/*
FILE *streamIn;
freopen_s(&streamIn, "input.txt", "r", stdin);
FILE *streamOut;
freopen_s(&streamOut, "output.txt", "w", stdout);
*/