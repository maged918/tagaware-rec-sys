//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
#define FZ(n) memset((n),0,sizeof(n))
#define FMO(n) memset((n),-1,sizeof(n))
#define MC(n,m) memcpy((n),(m),sizeof(n))
#define F first
#define S second
#define MP make_pair
#define PB push_back
#define FOR(x,y) for(__typeof(y.begin())x=y.begin();x!=y.end();x++)
#define ALL(x) x.begin(),x.end()
#define IOS ios_base::sync_with_stdio(0);cin.tie(0)
#ifdef ONLINE_JUDGE
#define FILEIO(name) \
  freopen(name".in", "r", stdin); \
  freopen(name".out", "w", stdout);
#else
#define FILEIO(name)
#endif

#define _TOKEN_CAT2(x, y) x ## y
#define _TOKEN_CAT(x, y) _TOKEN_CAT2(x, y)
#define _MACRO_OVERL3(_1, _2, _3, _N, ...) _N
#define _RANGE1(a) int _TOKEN_CAT(_t, __LINE__)=0; _TOKEN_CAT(_t, __LINE__)<(a); (_TOKEN_CAT(_t, __LINE__))++
#define _RANGE2(i, a) int (i)=0; (i)<(a); (i)++
#define _RANGE3(i, a, b) int (i)=a; (i)<(b); (i)++
#define range(...) _MACRO_OVERL3(__VA_ARGS__, _RANGE3, _RANGE2, _RANGE1)(__VA_ARGS__)

typedef pair<int, int> pii;
const pii dir[4] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

pii operator + (const pii &p1, const pii &p2) {
    return MP(p1.F+p2.F, p1.S+p2.S);
}

pii operator - (const pii &p1, const pii &p2) {
    return MP(p1.F-p2.F, p1.S-p2.S);
}

int operator / (const pii &p1, const pii &p2) {
    return p1.F*p2.S - p1.S*p2.F;
}

int sqdis(pii p1, pii p2) {
    return (p1.F - p2.F) * (p1.F - p2.F) + \
           (p1.S - p2.S) * (p1.S - p2.S);
}

vector<pii> convexHull(vector<pii> &vs) {
    sort(ALL(vs));
    vector<pii> ret;
    auto judge = [&](pii p) {
        int sz = ret.size();
        pii p2 = ret[sz-2]-p, p1 = ret[sz-1]-p;
        return (p1/p2) >= 0;
    };
    reverse(ALL(vs));
    for (auto pt: vs) {
        while (ret.size() > 1 and judge(pt)) {
            ret.pop_back();
        }
        ret.PB(pt);
    }
    reverse(ALL(vs));
    int t = ret.size()+1;
    for (auto pt: vs) {
        while (ret.size() > t and judge(pt)) {
            ret.pop_back();
        }
        ret.PB(pt);
    }
    ret.pop_back();
    return ret;
}

int best = 0;
vector<pii> convexs, bestEx = {}, now = {};
int N, R;

void dfs(int i, int n, int v) {
    if (n == N) {
        if (v > best) {
            best = v; bestEx = now;
        }
        return;
    }
    int sz = convexs.size();
    if (i >= sz) return;

    for (int j=i; j<(int)convexs.size(); j++) {
        pii np = convexs[j];
        int nv = v;
        for (auto p: now) {
            nv += sqdis(p, np);
        }
        now.PB(np);
        dfs(j, n+1, nv);
        now.pop_back();
    }
}

int main() {

    cin >> N >> R;

    auto sqdis = [](pii p1, pii p2) {
        return (p1.F - p2.F) * (p1.F - p2.F) + \
               (p1.S - p2.S) * (p1.S - p2.S);
    };
    vector<pii> vl;
    for (int x=-30; x<=30; x++) {
        for (int y=-30; y<=30; y++) {
            pii np = MP(x, y);
            if (sqdis(np, MP(0, 0)) <= R*R) vl.PB(np);
        }
    }
    convexs = convexHull(vl);
    //cout << convexs.size() << endl;
    dfs(0, 0, 0);
    cout << best << endl;
    for (auto p: bestEx) {
        cout << p.F << ' ' << p.S << endl;
    }

    return 0;
}


// ntuj - dhvku6bimkg330dj2rkl1