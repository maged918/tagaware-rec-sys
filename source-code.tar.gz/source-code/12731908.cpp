//Language: MS C++


#include<iostream>
#include<vector>
using namespace std;
bool A[51][51];
bool Vis[51];
int B[51];
int n,s,e,f;
void solve(int i)
{
    Vis[i]=1;
    if(i==e)f=-1;
    for(int j=0; j<n; ++j)
        if(A[i][j]&&!Vis[j])
            solve(j);
}
int main()
{
    cin>>n;
    for(int i=0; i<n*(n-1)/2-1; ++i)
    {
        int a,b;
        cin>> a >> b;
        A[a-1][b-1]=1;
        ++B[a-1];
        ++B[b-1];
    }
    s=-1;
    for(int i=0; i<n; ++i)
    {
        if(B[i]==n-2)
        {
            if(s==-1)s=i;
            else e=i;
        }
    }
    solve(s);
    if(f!=-1)swap(s,e);
    cout<<s+1<<' '<<e+1;
    return 0;
}