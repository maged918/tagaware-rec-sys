//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <climits>
#include <cctype>
#include <cassert>
#include <complex>
#include <stdio.h>
#include<math.h>

using namespace std;

  long long leftsum[4005];
    long long rightsum[4005];
    int a[2005][2005];
   
int main()
{
   
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n;
    cin >> n;
   // int a[n][n];
  
  
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
            {
              
                   cin >> a[i][j];
                   rightsum[i+j]+=a[i][j];
                   leftsum[i-j+n]+=a[i][j];
            }
    }
 

  //  int start =1,j;
    long long maxblack = -1,maxwhite =-1,tempsum;
    int xblack,yblack,xwhite,ywhite;
    for(int i=0;i<n;i++)
    {
       

        for(int j=0;j<n;j++)
        {
            if((i+j)%2==0)
            {
         
           tempsum = leftsum[i-j+n]+rightsum[i+j]-a[i][j];
        
            if(tempsum>maxblack)
            {
                maxblack = tempsum;
                xblack = i;
                yblack = j;
            }
            }
           else 
            {
               //int j = jwhite;
                tempsum = leftsum[i-j+n]+rightsum[i+j]-a[i][j];
             
            if(tempsum>maxwhite)
            {
                maxwhite = tempsum;
                xwhite = i;
                ywhite = j;
            }
            }

        }
    }

  

    cout << maxblack+maxwhite <<endl<<xblack+1<<" "<<yblack+1<<" "<<xwhite+1<<" "<<ywhite+1<<endl;

    return 0;
}



