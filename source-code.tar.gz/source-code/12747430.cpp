//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
const int MaxN = 2e3 + 17;
const int INF = 1e9 + 7;
int n, x, a[MaxN], Sum;
int main()
{ 
    #ifndef ONLINE_JUDGE 
        freopen(".in", "r", stdin); 
    #endif 
    cin >> n >> x;
    for (int i = 1; i < n; ++ i)
    	cin >> a[i];
    sort (a + 1, a + n);
    while (x <= a[n - 1])
    {
    	x ++;
    	a[n - 1] --;
    	sort (a + 1, a + n);	
    	Sum ++;
    }
    cout << Sum;
    return 0; 
}