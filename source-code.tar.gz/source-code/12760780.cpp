//Language: GNU C++11


#include <stdio.h>
#include <algorithm>
#include <vector>

using namespace std;

struct list
{
    vector <int> x;
}d[4005];

int n, m;
int se[4005];

int find(int x, int find)
{
    int s = 0, e = d[x].x.size() - 1, mid;

    if (d[x].x.empty() == true) return -1;

    for (;;)
    {
        mid = (s + e) / 2;

        if (find == d[x].x[mid]) return mid;
        if (find > d[x].x[mid]) s = mid + 1;
        else e = mid - 1;

        if (s > e) return -1;
    }
}

int main()
{
    scanf("%d %d", &n, &m);

    for (int i = 0; i < m; i++)
    {
        int x, y;
        scanf("%d %d", &x, &y);

        se[x]++; se[y]++;

        if (x > y)
        {
            int t = y;
            y = x;
            x = t;
        }

        d[x].x.push_back(y);
    }

    int ans = 0x7fffffff;

    for (int i = 0; i < n; i++)
        sort(d[i].x.begin(), d[i].x.end());

    for (int i = 1; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            if (find(i, j) == -1) continue;

            int q, w = 0;

            for (q = 0; q < d[i].x.size(); q++)
                if (d[i].x[q] > j) break;

            for (;;)
            {
                if (q == d[i].x.size()) break;
                if (w == d[j].x.size()) break;

                if (d[i].x[q] == d[j].x[w])
                {
                    int m = se[i] + se[j] + se[d[i].x[q]];

                    if (m < ans) ans = m;

                    q++;
                }

                else if (d[i].x[q] > d[j].x[w])
                    w++;

                else
                    q++;
            }
        }
    }

    if (ans == 0x7fffffff) printf("-1");
    else printf("%d\n", ans - 6);
}