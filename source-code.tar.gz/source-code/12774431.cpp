//Language: GNU C++11


#define _CRT_SECURE_NO_WARNINGS
#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>

using namespace std;



int a[100000];

int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int n;
	scanf("%d", &n);
	int i;
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
	}
	for (i = 0; i < n; i++)
	{
		while (a[i] % 3 == 0)
		{
			a[i] /= 3;
		}
		while (a[i] % 2 == 0)
		{
			a[i] /= 2;
		}
		if (a[i] == a[0])
		{
			continue;
		}
		else
		{
			printf("%s", "No");
			return 0;
		}
	}
	printf("%s", "Yes");
	return 0;
}