//Language: GNU C++11


//Shubham Vijayvargiya

#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;

#define pb push_back
#define mp make_pair
#define eb emplace_back
#define F first
#define S second
#define sz(a) (int)(a.size())
#define set(a,b) memset(a,b,sizeof(a))
#define let(x,a) __typeof(a) x(a)
#define rep(i, begin, end) for (__typeof(end) i = (begin) - ((begin) > (end)); i != (end) - ((begin) > (end)); i += 1 - 2 * ((begin) > (end)))
#define all(v) (v).begin(),(v).end()
#define sll(x) { scanf("%lld",&x); }
#define si(x) { scanf("%d",&x); }
#define slf(x) { scanf("%lf",&x); }
#define tcases() long long testcases; cin>>testcases ; while(testcases--)

#define trace(args...) { vector<string> _v = split(#args, ','); err(_v.begin(), args); cout<<endl;}

vector<string> split(const string& s, char c)
{
	vector<string> v;
	stringstream ss(s);
	string x;
	while (getline(ss, x, c))
		v.emplace_back(x);
	return move(v);
}
void err(vector<string>::iterator it) {}
template<typename T, typename... Args>
void err(vector<string>::iterator it, T a, Args... args) 
{
	cerr << it -> substr((*it)[0] == ' ', it -> length()) << " = " << a <<" | ";
	err(++it, args...);
}

template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;

typedef long long ll;
typedef pair<long long,long long> pll;
typedef vector<long long> vll;
typedef vector<pll> vpll;
typedef vector<vll> vvll;

//-----------------------------------------------------------------------------------------------------------------------------------------------//
#define N 100009
#define INF 1000000

vll g[N];
ll mark[N],dis1[N],dis2[N];

ll dfs1(ll u,ll p)
{
	ll x=-1000000;
	if(mark[u])
		x=0;
	for(auto v:g[u])
	{
		if(v!=p)
		{
			x=max(x,(dfs1(v,u)+1));
		}
	}
	return dis1[u]=x;
}

ll dfs2(ll u,ll p,ll d1=-INF,ll d2=-INF)
{
	dis2[u]=max(1+d1,2+d2);
	if(p!=-1)
		if(mark[p])
			dis2[u]=max(dis2[u],1ll);
	ll mx1=-INF,mx2=-INF;
	for(auto v:g[u])
	{
		if(v!=p)
		{
			if(dis1[v]>=mx1)
			{
				mx2=mx1;
				mx1=dis1[v];
			}
			else if(dis1[v]>mx2)
			{
				mx2=dis1[v];
			}
		}
	}
	for(auto v:g[u])
	{
		if(v!=p)
		{
			int x=mx1;
			if(dis1[v]==mx1)
				x=mx2;
			dfs2(v,u,dis2[u],x);
		}
	}
}
int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	ll n,m,d,u,v,ans;
	cin>>n>>m>>d;
	set(mark,0);
	rep(i,0,m)
	{
		cin>>u;
		u--;
		mark[u]=1;
	}
	rep(i,0,n-1)
	{
		cin>>u>>v;
		u--;v--;
		g[u].pb(v);
		g[v].pb(u);
	}
//	trace("yes3");
	dfs1(0,-1);
//	trace("yes1");
//	trace("yes2");
	dfs2(0,-1);
	ans=0;
	rep(i,0,n)
	{
		if(dis1[i]<=d and dis2[i]<=d)
		{
			ans++;
		}
	}
	cout<<ans<<endl;
	return 0;
}

