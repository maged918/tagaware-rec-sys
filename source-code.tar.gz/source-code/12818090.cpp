//Language: MS C++


#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<int> t(n);
    for (int i = 0; i < n; ++i) {
        cin >> t[i];
        while (t[i] % 2 == 0) t[i] /= 2;
        while (t[i] % 3 == 0) t[i] /= 3;
    }
    for (int i = 1; i < n; ++i)
        if (t[i] != t[0]) {
            cout << "No";
            return 0;
        }
    cout << "Yes";
}