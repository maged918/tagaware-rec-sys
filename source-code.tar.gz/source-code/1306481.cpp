//Language: GNU C++


#include <iostream>
#include <vector>
#include <set>

using namespace std;

int main()
{
    int n,m;
    cin>>n>>m;
    vector < vector < char > > v(n);

    for(int i = 0 ; i < n ; i++)
    {
        for(int j = 0 ; j < m ; j++)
        {
            char c;
            cin>>c;
            v[i].push_back(c);
        }
    }
    long long res = 1L;
    for(int j = 0 ; j < m ; j++)
    {   
        set<char> s;
        for(int i = 0 ; i < n ; i++)
        {
            s.insert(v[i][j]);
        }
        res *= ((long long) s.size());
        res %= 1000000007;
    }
    cout<<res;

}