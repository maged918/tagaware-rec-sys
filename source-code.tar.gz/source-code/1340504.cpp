//Language: MS C++


#include <stdio.h>
#include <algorithm>
using namespace std;
int n, d, h, c;
int hs[1000];
int main() {
    scanf("%d%d",&n,&d);
    for(int i=0; i<n; i++)
        scanf("%d",&hs[i]);
    sort(hs, hs+n);
    for(int i=0; i<n; i++) {
        for(int j=i; j>=0; j--) 
            if (i!=j) if (hs[i]-hs[j]<=d) c++; else break;
        for(int j=i; j<n; j++) 
            if (i!=j) if (hs[j]-hs[i]<=d) c++; else break;
    }
    printf("%d", c);
}