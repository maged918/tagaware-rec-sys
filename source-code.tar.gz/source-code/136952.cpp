//Language: MS C++


#include<stdio.h>
#include<iostream>
#include<vector>
#include<string.h>
#include<algorithm>
using namespace std;
#define maxn 205
bool g[maxn][maxn];
struct coor{int x,y;};
vector<int>ans;
int a[8][2]={1,0, -1,0, 0,1, 0,-1, 1,1 ,1,-1, -1,1, -1,-1};
coor Max,Min;
int w,h;
void dfs(int x,int y)
{
    g[x][y]=1;
    for(int i=0;i<8;i++){
        coor c;
        c.x=x+a[i][0];
        c.y=y+a[i][1];
        if(c.x>=0&&c.x<=w&&c.y>=0&&c.y<=h){
        if(c.x>=Max.x&&c.y>=Max.y)Max=c;
        if(c.x<=Min.x&&c.y<=Min.y)Min=c;
            if(g[c.x][c.y]==0)dfs(c.x,c.y);
        }
    }
}
void out(){
    int i,j;
    for(i=0;i<=w;i++)
    {
        for(j=0;j<=h;j++)
        {
            printf("%d",g[i][j]);
        }printf("\n");
    }printf("\n");
}
int main(){
    int i,j,n,x1,x2,y1,y2;
    //freopen("d.txt","r",stdin);
    scanf("%d%d%d",&w,&h,&n);
    //while(scanf("%d%d%d",&w,&h,&n)!=EOF){
        w=w+w;
        h=h+h;
    ans.clear();
    memset(g,0,sizeof(g));
    for(i=0;i<=w;i++)g[i][0]=g[i][h]=1;
    for(i=0;i<=h;i++)g[0][i]=g[w][i]=1;
    for(j=0;j<n;j++){
        scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
        x1+=x1;
        x2+=x2;
        y1+=y1;
        y2+=y2;
        if(x1==x2)for(i=y1;i<=y2;i++)g[x1][i]=1;
        else for(i=x1;i<=x2;i++)g[i][y1]=1;
    }
    //out();
    for(i=0;i<=w;i++)
        for(j=0;j<=h;j++){
            if(g[i][j]==0){
                Max.x=Max.y=-1;
                Min.y=Min.x=1000;
                dfs(i,j);
                //printf("%d %d %d %d\n",max.x,max.y,min.x,min.y);
                ans.push_back((Max.x-Min.x)*(Max.y-Min.y)/4);
            }
        }
    //  out();
    sort(ans.begin(),ans.end());
    for(i=0;i<ans.size()-1;i++)printf("%d ",ans[i]);printf("%d\n",ans[i]);
//}
    return 0;
}



