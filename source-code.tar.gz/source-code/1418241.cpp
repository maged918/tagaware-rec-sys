//Language: GNU C++


/*
ID: lxc9021
PROG: hamming
LANG: C++
*/
/** @author starLeo
 *  Standard C++ Header File For Contests
 */
#include <iostream>
#include <fstream>
//#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>
#include <vector>
#include <functional>
#include <utility> //pair
#include <map>
//#include <set>
#include <list>
#include <deque>
#include <queue>
#include <stack>
#include <cctype>
#include <cstring>
//#include <malloc.h>
using namespace std;
#define R(x) scanf("%d",&(x)) //read int
#define RS(x) scanf("%s",(x)) //read string
#define PL(x) printf("%d\n",(x)) //println int
#define REP(i,n) for(int i(0),_n(n);i<_n;++i)
#define FOR(i,l,h) for(int i(l),_h(h);i<=_h;++i)
#define FORD(i,h,l) for(int i(h),_l(l);i>=_l;--i)
#define RESET(a,b) memset((a),b,sizeof(a))
#define DEBUG(exp) (cout<<(#exp)<<" = "<<(exp)<<endl)
//#define oo (1234567890LL) // 64bits
#define oo (1<<29) // 32bits
//#define oo 9999999999.0 // Double
#define eps 1e-10
typedef long long Int;
typedef pair<int,int> pii;
typedef pair<double,double> pdd;

#define M ( 100000+10 )
struct Lem {
    int m,v,id;
    bool operator < (Lem b) const {
        return m<b.m || (m==b.m && v<b.v);
    }
};

int n,k,h;
Lem a[M];

bool can(double t)
{
    int j=k;
    FORD(i,n-1,0) {
        if( j>0 && (double)j*h/a[i].v - t <= -eps ) j--;
    }
    return j==0;
}
void putAns(double t)
{
    int ans[M];
    int j=k;
    FORD(i,n-1,0) {
        if( j>0 && (double)j*h/a[i].v - t <= -eps ) ans[--j]=a[i].id;
    }
    REP(i,k-1) printf("%d ",ans[i]);
    PL(ans[k-1]);
}
int main()
{
#ifndef MyComputer
//    freopen("hamming.in","r",stdin);
//    freopen("hamming.out","w",stdout);
#endif

    R(n),R(k),R(h);
    REP(i,n) R(a[i].m),a[i].id=i+1;
    REP(i,n) R(a[i].v);
    sort(a,a+n);

    double l=0, r=1e10;
    int cnt=100;
    while(cnt--) {
        double mid=(l+r)/2.0;
        if( can(mid) ) r=mid;
        else l=mid;
    }
    putAns(r);

    return 0;
}
