//Language: GNU C++


#include<iostream>
#include<cstdlib>
#include<vector>
#include<climits>
#include<cctype>
#include<map>
#include<list>
#include<cstdio>
#include<algorithm>
#include<memory.h>
#include<cmath>
#define L long long int
#define LD long double
#define M 1000000007

using namespace std;

int main()
{
    int t=1;
    int n,x,y;
    while(t--)
    {
              
              cin>>n>>x>>y;
              double p=y*n;
              double p1=(int)ceil(p/100);
              if(p1>x)
              cout<<p1-x;
              else
              cout<<"0";
              
    }
    return 0;
}
