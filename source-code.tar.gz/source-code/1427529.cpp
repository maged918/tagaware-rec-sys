//Language: GNU C++


#include <cstdio>

char s[1048578];
char a[1048578];
int len = 0;

int main() {
	bool prt = false;
	while (gets(a) != NULL) {
		int fi = 0;
		while (a[fi] == ' ') fi++;
		if (a[fi] == '#') {
			if (prt) puts(s);
			prt = false;
			len = 0;
			puts(a);
		} else {
			for (int i = 0; a[i]; ++i) {
				if (a[i] == ' ') continue;
				s[len++] = a[i];
			}
			s[len] = 0;
			prt = true;
		}
	}
	if (prt) puts(s);
}
