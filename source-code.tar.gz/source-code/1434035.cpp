//Language: MS C++


#include <iostream>
#include <vector>
#include <math.h>
#include <stdio.h>

using namespace std;

double d[210][210][210] = {0};

vector<int> p;
vector<int> a;
int n, l, k;

using namespace std;

void setD()
{
    d[0][0][0] = 1.0;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j <= i; ++j)
            for (int m = 0; m <= n; ++m)
            {
                d[i + 1][j][m] += d[i][j][m] * (1 - p[i] / 100.0);
                int newM = min(m + a[i] + 1, n);
                d[i + 1][j + 1][newM] += d[i][j][m] * p[i] / 100.0;
            }
}

int main()
{
    cin >> n >> l >> k;
    int t;
    for (int i = 0; i < n; ++i)
    {
        cin >> t;
        p.push_back(t);
    }
    for (int i = 0; i < n; ++i)
    {
        cin >> t;
        a.push_back(t);
    }
    setD();
    double res = 0;
    for (int j = 0; j <= n; ++j)
        for (int m = 0; m <= n; ++m)
            if ((j <= m + k) && (j >= l))
                res += d[n][j][m];
    printf("%.9f\n", res);
    return 0;
}