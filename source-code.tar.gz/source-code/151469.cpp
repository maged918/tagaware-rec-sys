//Language: MS C++


#include <stdio.h>
#include <math.h>

int main ()
{
    int a=0;
    int an=0;
    int b=0;
    int bn=0;
    int diff=20000;
    int tmp=0;
    
    int first=0;
    
    int n=0;
    
    scanf("%d", &n);
    
    scanf("%d", &first);
    
    a=first;
    
    for (int i=1; i<n; ++i)
    {
        scanf("%d", &b);
        if (  diff>(tmp=abs(a-b)))
        {
            diff=tmp;
            an=i;
            bn=i+1;
        }
        a=b;
    }
    
    a=first;
    if (  diff>(tmp=abs(a-b)))
    {
        diff=tmp;
        an=1;
        bn=n;
    }
    
    printf("%d %d\n", an, bn);
}