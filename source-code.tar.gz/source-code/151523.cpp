//Language: GNU C++


#include <iostream>
#include <math.h>
using namespace std ;

const       long double EPS=1e-8 ;
int         n ;
long double t , x[20] , v[20] , m[20] ;

long double fabs(long double x) { return x<0?-x:x ; }

int  main()
{
        cout << fixed ;
        cout.precision(10) ;
        cin >> n >> t ;
        for ( int i = 1 ; i <= n ; i ++ ) cin >> x[i] >> v[i] >> m[i] ;
        long double start = 0 ;

        while ( start + EPS < t )
        {
              long double p = t ;

              for ( int i = 1 ; i <= n ; i ++ )
              for ( int j = i+1 ; j <= n ; j ++ )
              {
                     long double h = (x[i] - x[j])/(v[j] - v[i]) ;
                     if ( h > EPS ) p = min(h , p) ;
              }

              p = min(p , t-start ) ;
              for ( int i = 1 ; i <= n ; i ++ ) x[i] += v[i] * p ;
              start += p ;

              for ( int i = 1 ; i <= n ; i ++ )
              for ( int j = i+1 ; j <= n ; j ++ )
                     if ( fabs(x[i] - x[j]) < EPS )
                     {
                          long double v1 , v2 ;
                          v1 = ( (m[i] - m[j])*v[i] + 2*m[j]*v[j] ) / (m[i] + m[j]) ;
                          v2 = ( (m[j] - m[i])*v[j] + 2*m[i]*v[i] ) / (m[i] + m[j]) ;
                          v[i] = v1 ;
                          v[j] = v2 ;
                     }
        }
        for ( int i = 1 ; i <= n ; i ++ ) cout << x[i] << endl ;
        

        return 0 ;
}
