//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <string.h>
#include <limits.h>
#include <cstdio>
#include <string>
#include <vector>
#include <cmath>
#include <map>
#define LL long long
using namespace std;
int num[110],mark[110];

int main()
{
    int n,i,temp,ans;
    while(cin >> n)
    {
        memset(mark,0,sizeof(mark));
        for(i=0;i<n;i++)
        {
            cin>>num[i];
            mark[ num[i] ]++;
        }
        ans=0;
        for(i=1;i<=100;i++)
        {
            temp=mark[i]/2;
            ans+=temp;
        }
        cout<<ans/2<<endl;
    }
	return 0;
}
