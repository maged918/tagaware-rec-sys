//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <iostream>

using namespace std;

char s[2002],s1[2002];

int main(){
    scanf("%s%s",s,s1);
    int ans=strlen(s1);
    for (int i=0;i<strlen(s);i++){
        int ans1=0;
        for (int j=0;j<strlen(s1);j++)
            if (i+j>=strlen(s)||s[i+j]!=s1[j]) ans1++;
        ans=min(ans,ans1);
    }
    for (int i=0;i<strlen(s1);i++){
        int ans1=i;
        for (int j=0;j<strlen(s);j++)
            if (i+j>=strlen(s1)) break;
            else if (s1[i+j]!=s[j]) ans1++;
        if (i+strlen(s)-1<strlen(s1)) ans1+=strlen(s1)-1-(i+strlen(s)-1);
        ans=min(ans1,ans);
    }
    printf("%d\n",ans);
    return 0;
}
