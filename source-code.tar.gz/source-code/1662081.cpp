//Language: GNU C++


#include <iostream>
#include <algorithm>
using namespace std;
#define rem 1000000007
long long binpow (long long n) {
    if (n == 0)
        return 1;
    if (n % 2 == 1)
        return (binpow (n-1) * 2)%rem;
    else {
        long long b = binpow (n/2);
        return (b * b)%rem;
    }
}
int main()
{
    long long n, res, cur;
    cin >> n;
    cur=binpow(n);
    res=(((cur%rem)*((cur+1)%rem))/2)%rem;
    cout << res << endl;
    return 0;
}
