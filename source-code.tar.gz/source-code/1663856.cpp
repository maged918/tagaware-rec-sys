//Language: GNU C++


#include <string>
#include <vector>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <queue>

#define pii pair<int, int>

using namespace std;

double s;
long long a, b, c;

int main() {
  cin >> s;
  cin >> a >> b >> c;
  if (a == b && b == c) printf("%.12lf %.12lf %.12lf\n", s/3, s/3, s/3);
  else {
    printf("%.12lf ", (s / (a + b + c)) * a);
    printf("%.12lf ", (s / (a + b + c)) * b);
    printf("%.12lf\n", (s / (a + b + c)) * c);
  }
  return 0;
}
