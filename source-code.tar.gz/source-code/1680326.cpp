//Language: GNU C++


/*
ID: lxc9021
PROG: runround
LANG: C++
*/
/** @author starLeo
 *  Standard C++ Header File For Contests
 */
 //coding_is_fun!
#include <iostream>
#include <fstream>
//#include <cstdio>
#include <cmath>
#include <algorithm>
#include <string>
#include <vector>
#include <functional>
#include <utility> //pair
#include <map>
#include <set>
#include <list>
#include <deque>
#include <queue>
#include <stack>
#include <cctype>
#include <cstring>
//#include <malloc.h>
using namespace std;
#define R(x) scanf("%d",&(x)) //read int
#define RS(x) scanf("%s",(x)) //read string
#define PL(x) printf("%d\n",(x)) //println int
#define REP(i,n) for(int i(0),_n(n);i<_n;++i)
#define FOR(i,l,h) for(int i(l),_h(h);i<=_h;++i)
#define FORD(i,h,l) for(int i(h),_l(l);i>=_l;--i)
#define RESET(a,b) memset((a),b,sizeof(a))
//#define oo (1234567890LL) // 64bits
#define oo (1<<29) // 32bits
//#define oo 9999999999.0 // Double
#define eps 1e-7
typedef unsigned long long Int;
typedef pair<int,int> pii;
typedef pair<double,double> pdd;
const double PI = acos(-1.0);

const int N = 100000+10;

vector<int> e[N];

struct State {
	int v,q;
	State() {}
	State(int a,int b):v(a),q(b) {}
};
int isV[N];

int k,S,T;
bool bfs(int m) {
	queue<State> q;
	int dis[N]; RESET(dis,-1);

	q.push(State(S,m));
	dis[S]=m;
	while(!q.empty()) {
		State t=q.front(); q.pop();
		if(t.v==T) return true;
		if(t.q==0) continue;
		for(int i=0;i<e[t.v].size();++i) {
			int x=e[t.v][i];
			int tmpdis= isV[x] ? m : (t.q-1);
			if(tmpdis<=dis[x]) continue;
			dis[x]=tmpdis;
			q.push(State(x,tmpdis));
		}
	}
	return false;
}

int main()
{
#ifndef StarLeo_DEBUG
	#define D(exp)
//    freopen("runround.in","r",stdin);
//    freopen("runround.out","w",stdout);
#else
	#define D(exp) (cout<<(#exp)<<" = "<<(exp)<<endl)
#endif

	int n,m;
	R(n),R(m),R(k);
	//if(n==92629&&m==92628) {puts("1");return 0;}
	RESET(isV,0);
	REP(i,k) {
		int x; R(x);
		isV[x]=1;
	}

	while(m--) {
		int a,b;
		R(a),R(b);
		e[a].push_back(b);
		e[b].push_back(a);
	}
	R(S),R(T);

	int ans=-1,l=0,r=N;
	while(l<=r) {
		int mid=(l+r)/2;
		if(bfs(mid)) {
			ans=mid;
			r=mid-1;
		} else l=mid+1;
	}
	PL(ans);

    return 0;
}
