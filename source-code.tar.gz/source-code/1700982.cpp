//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cctype>
#include <vector>
#include <string>
#include <cstdlib>

using namespace std;

int main() {
    int n;
    cin>>n;
   
    int s = 0;
    for(int i = 0 ; i<n; i++) {
        char c;
        cin>>c;
        int x = c - '0';
        if(x != 4 && x != 7) {
            s = -1;
            break;    
        }
            
        if(i < n/2)
            s += x;
        else
            s -= x;    
    }
    cout << (s == 0 ? "YES" : "NO") << endl;
    
    
    
    
    #ifndef ONLINE_JUDGE
    system("pause");
    #endif
    
}
