//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cmath>
int x,x2,y,y2,r1,r2;
double d,ans;
using namespace std;
int main()
{
	scanf("%d%d%d%d%d%d",&x,&y,&r1,&x2,&y2,&r2);
	d=sqrt((x-x2)*(x-x2)+(y-y2)*(y-y2));
	if (d<abs(r1-r2))
	ans=(abs(r1-r2)-d)/2.0;
	else
	if (d>r1+r2)
	ans=(d-r1-r2)/2.0;
	else
	ans=0;
	printf("%.15lf",ans);
	return 0;
}
