//Language: GNU C++


# include<stdio.h>
int jud(int a,int b,int c,int d)
{
    if(a!=b&&a!=c&&a!=d&&b!=c&&b!=d&&c!=d)
    return 1;
    else
    return 0;
}
int main()
{
    int x1,x2,x3,x4;
    int r1,r2,c1,c2,d1,d2;
    int flag;
    //int i,j,k,h;
    while(scanf("%d%d%d%d%d%d",&r1,&r2,&c1,&c2,&d1,&d2)!=EOF)
    {
        flag=0;
        int f=0;
        for(x1=1;x1<=9;x1++){
        for(x2=1;x2<=9;x2++){
        for(x3=1;x3<=9;x3++){
        for(x4=1;x4<=9;x4++)
        {
            if(x1+x2==r1&&x1+x4==d1&&x1+x3==c1&&x2+x4==c2&&x3+x4==r2&&x3+x2==d2)
            {
                f=jud(x1,x2,x3,x4);
                if(f==1)
                {
                    flag=1;
                    break;
                }
            }
        }
        if(flag==1)
        break;
        }
        if(flag==1)
        break;
        }
        if(flag==1)
        break;
        }
        if(flag==1)
        {
            printf("%d %d\n",x1,x2);
            printf("%d %d\n",x3,x4);
        }
        else
        printf("-1\n");

    }
    return 0;
}

     	     	    							 		