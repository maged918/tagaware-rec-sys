//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
__int64 gcd(__int64 a,__int64 b)
{
    while(a>b?a=a%b:b=b%a);
    return a+b;
}
int main()
{
	__int64 ans,n,k,m;
	int t,i;
	cin>>t;
	while(t--)
	{
		cin>>n;
		ans=(4*n/gcd(4*n,n+1))+1;
		cout<<ans<<endl;
	}
}
