//Language: MS C++


#define _USE_MATH_DEFINES
#define _CRT_SECURE_NO_DEPRECATE
#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <string>
#include <deque>
#include <queue>
#include <ctime>
#include <utility>
#include <iomanip>
#include <map>
#include <set>
#include <algorithm>
#include <sstream>
#include <list>
using namespace std;
#pragma comment(linker, "/STACK:256000000")
#define prime 1103
#define INF 123456789
#define pb push_back
#define mp make_pair
#define all(c) (c).begin(), (c).end()
#define eps 1e-7
#define TEST "test"
#define sz(c) (int)(c).size()
template<class T> inline T sqr(T a) {return a * a; }
typedef long long int64; 
typedef unsigned long long uint64; 
//----------------------------------------------------

int n, u, r;
int64 ans = 0;
vector<int> a(30), b(30), k(30), p(30);

int64 getsum(vector<int> &ta)
{
	int64 sum = 0;
	for(int i = 0; i < n; ++i)
		sum += (int64)ta[i] * k[i];
	return sum;
}

void f1(vector<int> &ta)
{
	vector<int> res(30);
	for(int i = 0; i < n; ++i)
		res[i] = ta[p[i]] + r;
	copy(res.begin(), res.end(), ta.begin());
}
void revf1(vector<int> &ta)
{
	vector<int> res(30);
	for(int i = 0; i < n; ++i)
		res[p[i]] = ta[i] - r;
	copy(res.begin(), res.end(), ta.begin());
}

void f0(vector<int> &ta)
{
	for(int i = 0; i < n; ++i)
		ta[i] ^= b[i];
}

void f(int ind, int last)
{
	if(!((u - ind) & 1))
	{
		int64 c = getsum(a);
		ans = max(ans, c);
	}
	if(ind == u) return;
	if(last)
	{
		f0(a);
		f(ind + 1, 0);
		f0(a);
	}
	f1(a);
	f(ind + 1, 1);
	revf1(a);
}

int main()
{
#ifndef ONLINE_JUDGE
	freopen(TEST ".in", "r", stdin);
	freopen(TEST ".out", "w", stdout);
#endif
	scanf("%d%d%d", &n, &u, &r);
	for(int i = 0; i < n; ++i)
		scanf("%d", &a[i]);
	for(int i = 0; i < n; ++i)
		scanf("%d", &b[i]);
	for(int i = 0; i < n; ++i)
		scanf("%d", &k[i]);
	for(int i = 0; i < n; ++i)
	{
		scanf("%d", &p[i]);
		--p[i];
	}
	ans = -(int64)INF * INF;
	f(0, 1);
	cout << ans;
	return 0;
}