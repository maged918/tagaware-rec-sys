//Language: GNU C++0x


#include<iostream>
#include<cstring>
using namespace std;
int main()
{

char s1[100001],s2[100001];
cin>>s1>>s2;
int f=0,count=0,p=0;
char c1,c2;
long long l1,l2,i;
l1=strlen(s1);
l2=strlen(s2);
if(l1!=l2)
f=1;
else{
for(i=0;i<l1;i++)
{
if(s1[i]!=s2[i])
{
if(count==1)
{if(s1[i]==c2&&s2[i]==c1)
p=1;
}
count++;
if(count>2)
p=0;
c1=s1[i];
c2=s2[i];
}
}
}
if(f==0&&p==1)
cout<<"YES\n";
else
cout<<"NO\n";
}

