//Language: GNU C++


#include <stdio.h>
#include <string.h>

int main() {
  int n, m;
  scanf("%d %d", &n, &m);
  if (m % 2 == 0) {
    int t = m / 2;
    for (int i = 0; i < n; i ++) {
      printf("%d\n", t);
      if (t == m) {
    t = m / 2;
      } else if (t <= m / 2) {
    t = m - t + 1;
      } else {
    t = m - t;
      }
    }
  } else {
    int t = (m + 1) / 2;
    for (int i = 0; i < n; i ++) {
      printf("%d\n", t);
      if (t == m) {
    t = (m + 1) / 2;
      } else if (t == (m + 1) / 2) {
    t --;
      } else if (t < (m + 1) / 2) {
    t = m - t + 1;
      } else {
    t = m - t;
      }
    }
  }
  return 0;
}
