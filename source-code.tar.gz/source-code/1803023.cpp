//Language: GNU C++0x


#include <fstream>
#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#include <memory.h>
using namespace std;


struct point {
    int x, y;
};
typedef pair<point,int> ppi;

const int MAXN = 1500;

int n;
vector<int> adj[MAXN];
ppi dest[MAXN];

int tree_size[MAXN]; 
int dfs(int v = 0, int anc = -1) {
    tree_size[v] = 1;
    for (int i = 0; i < (int)adj[v].size(); i++) 
        if (adj[v][i] != anc) tree_size[v] += dfs(adj[v][i], v);
    return tree_size[v];
}

inline double atan3(double y, double x) {
    if (x == y && x == 0) return -2000000000;
    return atan2(y, x);
}

int ans[MAXN];
double at[MAXN];
void solve(int root = 0, int l = 0, int r = n-1, int anc = -1) {
    int down_left = l;
    for (int i = l+1; i <= r; i++) 
        if (dest[i].first.y < dest[down_left].first.y) down_left = i;
        else if (dest[i].first.y == dest[down_left].first.y 
                 && dest[i].first.x < dest[down_left].first.x) down_left = i;
    ans[dest[down_left].second] = root;
            //cout << dest[down_left].second << ": ";
    point dlp = dest[down_left].first;
    for (int i = l; i <= r; i++)
        at[dest[i].second] = atan3(dest[i].first.y-dlp.y, dest[i].first.x-dlp.x);
    sort(dest+l, dest+r+1, 
         [=](const ppi &a, const ppi &b) {
             return at[a.second] < at[b.second];
         }
    );
        //for (int i = l; i <= r; i++) cout << dest[i].second << " ";
        //cout << endl;
    int tmp = l+1;
    for (int i = 0; i < (int)adj[root].size(); i++)
        if (adj[root][i] != anc) {
                //cout << adj[root][i] << " " << tree_size[adj[root][i]] << endl;
            solve(adj[root][i], tmp, tmp+tree_size[adj[root][i]]-1, root);
            tmp += tree_size[adj[root][i]];
        }
}

int main() {
    cin >> n;
    for (int i = 0; i < n-1; i++) {
        int a, b; cin >> a >> b;
        --a; --b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    for (int i = 0; i < n; i++) {
        cin >> dest[i].first.x >> dest[i].first.y;
        dest[i].second = i;
    }

    memset(ans, -1, sizeof(ans));
    dfs();
    solve();
    
    for (int i = 0; i < n-1; i++)
        cout << ans[i]+1 << ' ';
    cout << ans[n-1]+1 << endl;
}
