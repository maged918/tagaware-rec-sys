//Language: MS C++


//#pragma comment(linker,"/STACK:16777216") /*16Mb*/
//#pragma comment(linker,"/STACK:33554432") /*32Mb*/
#define _CRT_SECURE_NO_DEPRECATE
#include <cassert>
#include <sstream>
#include<iostream>
#include<numeric>
#include<sstream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<memory>
#include<string>
#include<vector>
#include<cctype>
#include<list>
#include<queue>
#include<deque>
#include<stack>
#include<map>
#include<set>
#include<algorithm>
using namespace std;

typedef unsigned long long      ui64;
typedef long long               i64;
typedef vector<i64>             VI;
typedef vector<bool>            VB;
typedef vector<VI>              VVI;
typedef vector<string>          VS;
typedef pair<int,int>           PII;
typedef map<string,int>         MSI;
typedef set<int>                SI;
typedef set<string>             SS;
typedef map<int,int>            MII;
typedef pair<double,double>     PDD;

#define PB                      push_back
#define MP                      make_pair
#define X                       first
#define Y                       second
#define FOR(i, a, b)            for(int i = (a); i < (b); ++i)
#define RFOR(i, a, b)           for(int i = (a) - 1; i >= (b); --i)
#define CLEAR(a, b)             memset(a, b, sizeof(a))
#define SZ(a)                   int((a).size())
#define ALL(a)                  (a).begin(), (a).end()
#define RALL(a)                 (a).rbegin(), (a).rend()
#define INF                     (2000000000)

#ifdef _DEBUG
#define eprintf(...) fprintf (stderr, __VA_ARGS__)
#else
#define eprintf(...) assert (true)
#endif

bool is(string s) {
    FOR(i,0,SZ(s))
        if( s[i]!='4' && s[i]!='7' )
            return false;
    return true;
}

const i64 MOD = 1000000007;

int gcdex(int a, int b, int &x, int &y) {
    if (a == 0) {
        x = 0; y = 1;
        return b;
    }
    int x1, y1;
    int d = gcdex (b%a, a, x1, y1);
    x = y1 - (b / a) * x1;
    y = x1;
    return d;
}

int ob(int a) {
    int x, y;
    int g = gcdex(a,MOD,x,y);
    return (x%MOD+MOD)%MOD;
}

char buf[10];

int main()
{
    map<int,int> M;
    int n,k;
    scanf("%d%d",&n,&k);
    VI c;
    int r = 0;
    FOR(i,0,n) {
        string s;
        scanf("%s",buf);
        s = buf;
        if( is(s) )
            M[ atoi(s.c_str()) ] ++;
        else r++;
    }

    
    for(map<int,int>::iterator it=M.begin(); it!=M.end(); it++) {
        c.PB( it->second );
    }
    
    VVI dp(2,VI(k+1,0));
    dp[0][0] = 1;
    FOR(i,0,SZ(c))
        dp[(i+1)%2][0] = 1;
    FOR(i,1,SZ(c)+1) {
        FOR(j,1,min(SZ(c),k)+1) {
            dp[i%2][j] = ((dp[(i+1)%2][j-1] * c[i-1]) %MOD + dp[(i+1)%2][j])%MOD;
        }
    }

    i64 C = 1;
    i64 res = 0;

    FOR(i,0,k+1) {
        i64 tres = (dp[SZ(c)%2][k-i] * C);
        tres %= MOD;
        res = (res + tres) % MOD;
        //calc C
        C = (C*(r-i))%MOD;
        C = (C*(ob(i+1)))%MOD;
    }

    cout << res << endl;
    return 0;
}