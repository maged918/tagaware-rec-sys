//Language: MS C++


#define _CRT_SECURE_NO_DEPRECATE
#include <ctime>
#include <float.h>
#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <iostream>
#include <cmath>
#include <sstream>
#include <map>
#include <set>
using namespace std;
#define pb push_back
#define inf 1000000000
#define L(s) (int)((s).size())
#define C(a) memset((a),0,sizeof(a))
#define ll long long
#define all(c) (c).begin(), (c).end()
#define VI vector<int>
#define ppb pop_back
#define mp make_pair
#define pii pair<int,int>
#define pdd pair<double,double>
#define x first
#define y second
#define ll long long
int a, b, r;
int main() {
	cin >> a >> b >> r;
	if (a < 2 * r || b < 2 * r) cout << "Second\n"; else cout << "First\n";
}