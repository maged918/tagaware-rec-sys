//Language: GNU C++


/**
 * ID: ping128
 * LANG: C++
 */

#include <stdio.h>
#include <iostream>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#include <list>
#include <math.h>
#include <algorithm>
#include <map>
#include <string.h>

using namespace std;

typedef long long LL;
typedef pair<LL, LL>PII;
typedef pair<PII,int>PII2;

LL n;
LL order[55];
LL prize[5];
LL ans[5];

int main(){
	
	cin >> n;
	for(int i = 0; i < n; i++ )
	{
		cin >> order[i];
	}
	for(int i = 0; i < 5; i++ )
	{
		cin >> prize[i];
	}
	LL sum = 0;
	for(int i = 0; i < n; i++ )
	{
		sum += order[i];
		bool buf = true;
		while(buf)
		{
			buf =  false;
			for(int i = 4; i >= 0; i-- )
			{
				if(prize[i] <= sum)
				{
					LL num = sum / prize[i];
					sum -= prize[i] * num;
					ans[i] += num;
					buf = true;
					break;
				}
			}
		}
	}
	for(int i = 0; i < 5; i++ )
	{
		cout << ans[i] << " ";
	}
	cout << endl << sum << endl;
		
	
	
return 0;
}
