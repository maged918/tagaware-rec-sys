//Language: GNU C++


#include<stdio.h>
int n,a[310][310],dp[610][310][310]={0};

int max(int i,int j,int m,int n)
{
	int ans;
	i=i>j?i:j;
	m=m>n?m:n;
	ans=i>m?i:m;
	return ans;
}

void initial()
{
	int i,j,k;
	for(i=0;i<=300;i++)
		for(j=0;j<=300;j++)
			for(k=0;k<=600;k++)
				dp[k][i][j]=-10000000;
}

int main()
{
	int i,j,k;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	initial();
	dp[0][1][1]=a[1][1];
	for(k=1;k<=2*(n-1);k++)
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
			{
				if(i==j)
				{
					dp[k][i][j]=max(dp[k-1][i-1][j-1],dp[k-1][i][j-1],
						dp[k-1][i-1][j],dp[k-1][i][j])+a[i][k+2-i];
				}
				else
				{
					dp[k][i][j]=max(dp[k-1][i-1][j-1],dp[k-1][i][j-1],
						dp[k-1][i-1][j],dp[k-1][i][j])+a[i][k+2-i]+a[j][k+2-j];
				}
			}
	printf("%d",dp[2*n-2][n][n]);
	return 0;
}


/*rhgsrimepbppmloithoqiqnjteemegbnnhlchesoffbrrirqpl*/