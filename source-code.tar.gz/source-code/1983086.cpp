//Language: GNU C++


#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <utility>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <string>
#include <cstring>
#include <ctime>
#define mem(a,b) memset(a,b,sizeof(a));
#define INF 0x7fffffff
#define lldINF 0x3f3f3f3f3f3f3f3fll
#define eps 1e-8
#define lld long long
#define sqr(x) ((x)*(x))
#define ab(x) ((x>0) ? x : -(x))
#define PI 3.14159265358979323846
#define rin freopen("in.txt","r",stdin)
#define pout freopen("out.txt","w",stdout)
using namespace std;

double r1,r2,p1,p2,mm,A,B;
int n,m;

int main(){
    int i,j,num,tem;
    scanf("%d",&num);
    mm=-1;
    for (i=1; i<=num; i++){
        scanf("%lf",&r1);
        if (r1>mm) mm=r1;
    }
    r1=mm;

    scanf("%d",&num);
    mm=-1;
    for (i=1; i<=num; i++){
        scanf("%lf",&p1);
        if (p1>mm) mm=p1;
    }
    p1=mm;
    
    scanf("%d",&num);
    mm=1e20;
    for (i=1; i<=num; i++){
        scanf("%lf",&p2);
        if (p2<mm) mm=p2;
    }
    p2=mm;


    scanf("%lf%lf",&A,&B);
    r2=sqrt(r1*r1*B/(B+p2/p1*A));
    printf("%.12lf\n",r2);
    return 0;
}