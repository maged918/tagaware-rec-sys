//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <utility>
using namespace std;

const int MAX_N = 1000005;
typedef pair<int,int> pii;

#ifdef DEBUG
#define D(x...) fprintf(stderr,x)
#else
#define D(x...)
#endif

int N, R;
bool buffer[MAX_N];

// returns <iters, mistakes>
// INV: a > b
pii gcd(int a, int b) {
    if(b == 0) {
        if(a == 1) {
            return make_pair(0, 0);
        } else {
            return make_pair(-1, MAX_N);
        }
    } else if(b == 1) {
        return make_pair(a, max(0,a-2));
    } else {
        pii next = gcd(b, a%b);
        return make_pair(next.first+(a/b), next.second + (a/b)-1);
    }
}

int main() {
    int best = MAX_N;
    int bp = -1;
    scanf("%d %d",&N,&R);

    for(int i=0;i<=R;i++) {
        pii res = gcd(R, i);
        D("trying (%d,%d): %d iterations, %d errors\n",R,i,res.first,res.second);
        if(res.first == N) {
            if(best > res.second) {
                best = res.second;
                bp = i;
            }
        }
    }

    if(best == MAX_N) {
        printf("IMPOSSIBLE\n");
    } else {
        printf("%d\n",best);
        int a = R;
        int b = bp;
        bool side = false;
        int upto = N-1;

        while(b > 0) {
            do {
                buffer[upto] = side;
                a -= b;
                upto--;
            } while(a > b);
            a ^= b ^= a ^= b;
            side = !side;
        }

        bool test = buffer[0];
        for(int i=0;i<N;i++) {
            if(buffer[i] == test) {
                printf("T");
            } else {
                printf("B");
            }
        }
        printf("\n");
    }

    return 0;
}
