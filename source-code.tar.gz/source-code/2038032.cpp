//Language: GNU C++


#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<memory>
#include<cstring>
#include<vector>
using namespace std;
const int maxn = 1005;
int n,m,k;
vector<int> res;

int main(){
    while(cin>>n>>m>>k){
        int ans = 0;
        for(int i=1;i<=n+m;++i){
            int num = 0;
            bool ff = false;
            for(int j=0;j<(int)res.size();++j){
                if(i-res[j] < n) ++num;
                if(i-res[j] < n - 1) ff = true;
            }
            num = k - num;
            if(num < 0) num = 0;
            if(!num && !ff) ++num;
            ans += num;
            while(num--) res.push_back(i);
        }
        cout<<ans<<endl;
        for(int i=0;i<(int)res.size();++i)cout<<res[i]<<' ';
    }
    return 0;
}
