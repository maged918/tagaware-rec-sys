//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <vector>
#include <set>
#include <cstring>
#include <string>
#include <map>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <bitset>
#include <queue>
#include <sstream>

using namespace std;

#define mp make_pair
#define pb push_back
#define rep(i,n) for(int i = 0; i < n; i++)
#define re return
#define fi first
#define se second
#define sz(x) ((int) (x).size())
#define all(x) (x).begin(), (x).end()
#define sqr(x) ((x) * (x))
#define y0 y3487465
#define y1 y8687969

    int n, nr1 = 0, nr2 = 0;
    char s[10000], s1[10000], c[10000];

int main ()
{
    s[0]=0;
    s1[0]=0;
    scanf ("%d\n", &n);
    while (n)
    {
        n--;
        for (int  i = 0 ; i< 100 ;i++)
            c[i] = 0;
        int  i = 0;
        char C;
        scanf ("%c", &C);
        while (C!='\n')
        {
            c[i++] =C;
            scanf ("%c", &C);
        }

        if (strlen(s)==0)
            strcpy(s, c);
        else
            if (strcmp(s, c)!=0)
            if (strlen(s1)==0)
                strcpy(s1, c);
        if (strcmp(s, c)!=0)
            nr1++;
        else
            nr2++;
    }
    if (nr1<nr2)
    printf("%s\n", s);
    else
    printf("%s\n", s1);
    return 0;
}
