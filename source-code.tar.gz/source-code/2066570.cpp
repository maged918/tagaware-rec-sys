//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <queue>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <memory.h>

using namespace std;

#define ABS(a) ((a>0)?a:-(a))
#define MIN(a,b) ((a<b)?(a):(b))
#define MAX(a,b) ((a<b)?(b):(a))
#define FOR(i,a,n) for (int i=(a);i<(n);++i)
#define FI(i,n) for (int i=0; i<(n); ++i)
#define pnt pair <int, int>
#define mp make_pair
#define PI 3.14159265358979
#define MEMS(a,b) memset(a,b,sizeof(a))
#define LL long long
#define U unsigned
set <int> p;
set<pair<int,pnt > >s;
int pid[1000010];
int main()
{
#ifdef Fcdkbear
    freopen("in.txt","r",stdin);
    //freopen("out.txt","w",stdout);
    double beg=clock();
#endif
    int n,q;
    scanf("%d%d",&n,&q);
    FOR(i,0,q)
    {
        int t,id;
        scanf("%d%d",&t,&id);
        if (t==1)
        {
            int bdist=-1000000000;
            int how=-1;
            if (p.find(1)==p.end())
            {
                set<int>::iterator it=p.begin(); 
                if (it==p.end())
                {
                    bdist=1000000000;
                    how=1;
                }
                else
                {
                    if (*it-1>bdist)
                    {
                        bdist=*it-1;
                        how=1;
                    }
                }
            }
            if (p.find(n)==p.end())
            {
                set<int>::iterator it=p.end();
                if (it!=p.begin())
                {
                    it--;
                    if (n-*it>bdist)
                    {
                        bdist=n-*it;
                        how=n;
                    }
                }
            }
            if (s.size())
            {
                int curdist=-s.begin()->first;
                //curdist/=2;
                int pos=s.begin()->second.first+curdist;
                if ((curdist>bdist) || ((curdist==bdist) && (pos<how)))
                {
                    bdist=curdist;
                    how=pos;
                }
            }
            pid[id]=how;
            set<int>::iterator it=p.lower_bound(how);
            int v1=-1,v2=-1;
            if (it!=p.end())
            {
                v2=*it;
            }
            if (it!=p.begin())
            {
                it--;
                v1=*it;
            }
            if ((v2!=-1) && (v1!=-1))
                s.erase(mp((v1-v2)/2,mp(v1,v2)));
            if (v1!=-1)
                s.insert(mp((-how+v1)/2,mp(v1,how)));
            if (v2!=-1)
                s.insert(mp((-v2+how)/2,mp(how,v2)));
            printf("%d\n",how);
            p.insert(how);
        }
        else
        {
            int how=pid[id];
            p.erase(how);
            set<int>::iterator it=p.lower_bound(how);
            int v1=-1,v2=-1;
            if (it!=p.end())
            {
                v2=*it;
            }
            if (it!=p.begin())
                {
                    it--;
                    v1=*it;
                }
            if ((v2!=-1) && (v1!=-1))
                s.insert(mp((v1-v2)/2,mp(v1,v2)));
            if (v1!=-1)
                s.erase(mp((-how+v1)/2,mp(v1,how)));
            if (v2!=-1)
                s.erase(mp((-v2+how)/2,mp(how,v2)));
        }
    }

#ifdef Fcdkbear
    double end=clock();
    fprintf(stderr,"*** Total time = %.3lf ***\n",(end-beg)/CLOCKS_PER_SEC);
#endif
}