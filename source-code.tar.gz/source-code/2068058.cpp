//Language: GNU C++


#include <cstdio>

using namespace std;

typedef long long int64;

int n, m, s;

int main () {
//	freopen ("cf132c.in", "r", stdin);
//	freopen ("cf132c.out", "w", stdout);
	
	scanf ("%d %d %d\n", &n, &m, &s);
	
	int64 res = 0;
	for (int x = 1; x <= n; x += 2)
		for (int y = 1; y <= m; y += 2) {
			int a = x >> 1, b = y >> 1;
			int k = (n - x + 1) * (m - y + 1);
			
			if (x * y == s)
				res += (2 * (a + 1) * (b + 1) - 1) * k;
			else if (x * y > s) {
				int r = x * y - s;
				if (!(r & 3)) {
					r >>= 2;
					for (int c = 1; c <= a; ++c)
						if (!(r % c)) {
							int d = r / c;
							if (d <= b)
								res += 2 * k;
						}
				}
			}
		}
	
	printf ("%I64d\n", res);
	
	fclose (stdin);
	fclose (stdout);
	return 0;
}
