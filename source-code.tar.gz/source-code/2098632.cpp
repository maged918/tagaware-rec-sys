//Language: GNU C++


#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
using namespace std;
#define lson l, m, rt<<1
#define rson m+1,r,rt<<1|1
const int maxn = 200010 ;
const int maxm = 1000010 ;
int n,m;
int lsum[maxn<<2],rsum[maxn<<2],msum[maxn<<2];
int pos[maxm];
void PushUp(int rt,int m)
{
    lsum[rt] = lsum[rt<<1];
    rsum[rt] = rsum[rt<<1|1];
    if(lsum[rt<<1] == m-(m>>1)) lsum[rt] += lsum[rt<<1|1];
    if(rsum[rt<<1|1] == (m>>1)) rsum[rt] += rsum[rt<<1];
    msum[rt] = max(lsum[rt<<1|1] + rsum[rt<<1],max(msum[rt<<1],msum[rt<<1|1]));
}
void build(int l,int r,int rt)
{
    lsum[rt] = rsum[rt] = msum[rt] = r-l+1;
    if(l == r) return;
    int m = (l+r)>>1;
    build(lson);
    build(rson);
}
void update(int v,int c,int l,int r,int rt)
{
    if(l == r)
    {
        lsum[rt] = rsum[rt] = msum[rt] = c?0:1;
        return ;
    }
    int m = (l+r)>>1;
    if(v <= m) update(v,c,lson);
    else update(v,c,rson);
    PushUp(rt,r-l+1);
}
int query(int c,int l,int r,int rt)
{
    if(l == r) return l;
    if(l == 1 && lsum[rt] >= c) return 1;
    int m = (l+r)>>1;
    if(msum[rt<<1]+1 >= 2*c) return query(c,lson);
    else if(rsum[rt<<1]+lsum[rt<<1|1]+1 >= 2*c) return m-rsum[rt<<1]+c;
    else return query(c,rson);
}
int main()
{
    scanf("%d%d",&n,&m);
    build(1,n,1);
    while(m--)
    {
        int op,id;
        scanf("%d%d",&op,&id);
        if(op == 1)
        {
            int len = (msum[1]+1)/2;
            len = max(lsum[1],len);
            len = max(rsum[1],len);
            pos[id] = query(len,1,n,1);
            printf("%d\n",pos[id]);
            update(pos[id],1,1,n,1);
        }
        else
            update(pos[id],0,1,n,1);
    }
    return 0;
}