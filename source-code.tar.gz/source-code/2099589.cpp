//Language: GNU C++


#include<stdio.h>
#include<string.h>
#include<string>
#include<cmath>
#include<iostream>
#include<queue>
#include<algorithm>
#define clearAll(a) memset(a,0,sizeof(a))
#define sq(a) ((a)*(a))
#define eps 1e-8
#define maxn 100005
#define	oo 1000000000 
using namespace std;

typedef long long ll;

struct node
{
	int id;
	ll w;
};
node p[maxn];
int n,d;
int a,b;

bool cmp(node a,node b)
{	 return a.w<b.w;
}

int main()
{
	//freopen("input.txt","r",stdin);
	scanf("%d %d",&n,&d);
	scanf("%d %d",&a,&b);
	int x,y;
	for (int i=1;i<=n;i++)
	{
		scanf("%d %d",&x,&y);
		p[i].w=(ll)x*a+y*b;
		p[i].id=i;
	}
	sort(p+1,p+1+n,cmp);
	ll tot=0;
	int cnt=0;
	for (int i=1;i<=n;i++)
	if ((tot=tot+p[i].w)<=d)
	{
		cnt++;
	} else break;
	printf("%d\n",cnt);
	for (int i=1;i<=cnt;i++)
		printf("%d%c",p[i].id,(i==cnt)?'\n':' ');
	printf("\n");
	return 0;
}











