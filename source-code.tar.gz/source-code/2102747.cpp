//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <sstream>
#include <string>
#include <string.h>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <limits.h>

using namespace std;

#define ff(i,x,y) for(int i = (x);i < (y);++i)
#define rep(i,n) ff(i,0,n)
#define st(v) sort(v.begin(),v.end())
#define st2(v,f) sort(v.begin(),v.end(),f)
#define rvs(v) reverse(v.begin(),v.end())
#define pb push_back
bool myfunction (int i,int j) { return (i<j); }
#define fact(x) for(i=x-1;i>0;i--){x=x*i;}
#define MP make_pair
#define F first
#define S second
#define LL long long
#define ULL unsigned long long
#define SIZE(v) (int)v.size()
#define VI vector<int>
#define VVI vector<VI>

typedef long long ll;

ll t,a,b;

bool getAns(ll b, ll a, bool who)
{
	if(b==0||a==0) return !who;
	if(getAns(a,b%a,!who)==who) return who;
	ll p=b/a;
	if(p%(a+1)%2==0) return who;
	else return !who;
}

int main()
{
#ifdef LOCAL
	freopen("in.txt", "r", stdin);
#endif
	cin>>t;
	while(t--)
	{
		cin>>a>>b;
		if(getAns(max(a,b),min(a,b),1)) cout<<"First"<<endl;
		else cout<<"Second"<<endl;
	}
	return 0;
}