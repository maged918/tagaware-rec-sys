//Language: GNU C++


#include<stdio.h>
#include<iostream>
#include<string>
using namespace std;
int a,s,d,f,g,h,j,k,l,i,n,m;
string x,z=" ABSINTH, BEER, BRANDY, CHAMPAGNE, GIN, RUM, SAKE, TEQUILA, VODKA, WHISKEY, WINE,";
main(){
cin>>n;
for(i=0;i<n;i++){
cin>>x;

a=x.size();if(a>9) continue;
if(x[0]>='0' && x[0]<='9') {
k=1;f=0;
for(j=a-1;j>=0;j--){
f=f+(x[j]-48)*k;

x.erase(j,1);
k=k*10;}
if(f<18) {l++;}}
else {
x=' '+x+',';
s=z.find(x);
if(s!=-1) {l++;}}}
cout<<l;
//system("pause");
}
