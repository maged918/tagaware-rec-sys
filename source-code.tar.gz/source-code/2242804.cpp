//Language: GNU C++0x


#ifdef MY_SUPER_PUPER_ONLINE_JUDGE
#include <fstream>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
#else
#include <iostream>
using namespace std;
#endif
#include <algorithm>
#include <set>
#include <vector>

long long int pow(int a, int b, int m)
{
    if(b == 0) return 1;
    long long int t = pow(a, b / 2, m);
    t = (t * t) % m;
    if(b % 2 == 1) t = (t * a) % m;
    return t;
}

int main()
{
    int n, m;
    cin >> n >> m;
    cout << (pow(3, n, m) - 1 + m) % m;
}
