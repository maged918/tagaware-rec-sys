//Language: GNU C++


//By momo
#include<cstdio>
#include<algorithm>
using namespace std;
long long m;
long long solve(long long n){
	if(n == 1) return 3;
	long long x = solve(n/2) % m;
	if(n & 1) return (((x * x) % m) * 3) % m;
	else return (x * x) % m;
}
int main(){
	long long n;
	scanf("%I64d%I64d", &n, &m);
	printf("%I64d\n", (solve(n) - 1 + m) % m);
}
