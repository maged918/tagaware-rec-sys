//Language: MS C++


#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cmath>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>

using namespace std;

typedef vector< int > VI;
typedef vector< string > VS;        
typedef pair< int, int > II;
typedef long long LL;
#define FOR(i,b,e) for(int (i)=(int)(b);(i)<(int)(e);++(i)) 
#define FORIT(it,c) for(typeof((c).begin()) it=(c).begin();it!=(c).end();++it)
#define INF 987654321

int a[100007], pa[100007];
int main()
{
    int n;
    cin >> n;
    FOR(i, 0, n) {
        cin >> a[i];
        pa[a[i]] = i+1;
    }
    int m;
    cin >> m;
    LL c1 = 0, c2 = 0;
    FOR(i, 0, m) {
        int b;
        cin >> b;
        c1 += pa[b];
        c2 += n-pa[b]+1;
    }
    cout << c1 << " " << c2 << endl;
    return 0;
}