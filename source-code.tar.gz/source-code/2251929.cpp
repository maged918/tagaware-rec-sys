//Language: GNU C++


#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
using namespace std;

#define clr(p,v) memset(p,v,sizeof(p))
const int maxn = 100010 ;
typedef __int64 ll;

ll n,m;
ll d[maxn],sum[maxn],ans[maxn];

ll cmp(ll x,ll y)
{
    return x>y;
}

int main()
{
    scanf("%I64d",&n);
    for(ll i=0;i<n;i++) scanf("%I64d",&d[i]);
    sort(d,d+n,cmp);
    sum[0] = 0LL;
    for(ll i=1;i<=n;i++) sum[i] = sum[i-1]+d[i-1];
    scanf("%I64d",&m);
    clr(ans,0);
    while(m--)
    {
        ll x;
        scanf("%I64d",&x);
        if(ans[x] == 0)
        {
            ll step,l,r,uu;
            step = 0LL;
            uu = 1LL;
            if(x >= n-1) ans[x] = sum[n]-sum[1];
            else
            {
                for(l=0; l<n; l+=uu, uu*=x)
                {
                    r = min(n,l+uu);
                    ans[x] += (sum[r]-sum[l])*step;
                    step++;
                }
            }
        }
        printf("%I64d ",ans[x]);
    }
    puts("");
    return 0;
}