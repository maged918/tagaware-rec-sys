//Language: GNU C++


﻿#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <queue>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <memory.h>

using namespace std;

#define ABS(a) ((a>0)?a:-(a))
#define MIN(a,b) ((a<b)?(a):(b))
#define MAX(a,b) ((a<b)?(b):(a))
#define FOR(i,a,n) for (int i=(a);i<(n);++i)
#define FI(i,n) for (int i=0; i<(n); ++i)
#define pnt pair <int, int>
#define mp make_pair
#define PI 3.14159265358979
#define MEMS(a,b) memset(a,b,sizeof(a))
#define LL long long
#define U unsigned
char a[510][510];
int how[510][510][15];
bool check(int i, int j, int szs, int it, int mask)
{
	bool f=true;
	if (mask&1)
		f&=(how[i][j][it-1]==mask);
	else
		f&=(how[i][j][it-1]==0);


	if ((mask>>1)&1)
		f&=(how[i][j+szs][it-1]==mask);
	else
		f&=(how[i][j+szs][it-1]==0);


	if ((mask>>2)&1)
		f&=(how[i+szs][j][it-1]==mask);
	else
		f&=(how[i+szs][j][it-1]==0);


	if ((mask>>3)&1)
		f&=(how[i+szs][j+szs][it-1]==mask);
	else
		f&=(how[i+szs][j+szs][it-1]==0);
	return f;
}
int main()
{
#ifdef Fcdkbear
    freopen("in.txt","r",stdin);
    //freopen("out.txt","w",stdout);
    double beg=clock();

#endif
	MEMS(how,-1);
	int n,m;
	scanf("%d%d",&n,&m);
	FOR(i,0,n)
		scanf("%s",&a[i]);
	FOR(i,0,n-1)
		FOR(j,0,m-1)
		{
			int mask=0;
			if (a[i][j]=='.')
				mask|=1;
			if (a[i][j+1]=='.')
				mask|=2;
			if (a[i+1][j]=='.')
				mask|=4;
			if (a[i+1][j+1]=='.')
				mask|=8;
			how[i][j][0]=mask;
		}
	int res=0;
	FOR(it,1,12)
	{
		FOR(i,0,n)
			FOR(j,0,m)
			{
				if (how[i][j][it-1]==-1)
					continue;
				int sz=(1<<(it+1));
				if ((i+sz>n) || (j+sz>m))
					continue;
				int szs=sz/2;
				bool f=true;
				int mask=how[i][j][it-1];
				if (mask)
				{
					bool f=check(i,j,szs,it,mask);
					if (f)
					{
						res++;
						how[i][j][it]=mask;
					}
					else
						how[i][j][it]=-1;
				}
				else
				{
					if (how[i][j+szs][it-1]==-1)
						continue;
					if (how[i+szs][j][it-1]==-1)
						continue;
					if (how[i+szs][j+szs][it-1]==-1)
						continue;
					if (how[i][j+szs][it-1]!=0)
						mask=how[i][j+szs][it-1];
					if (how[i+szs][j][it-1]!=0)
						mask=how[i+szs][j][it-1];
					if (how[i+szs][j+szs][it-1]!=0)
						mask=how[i+szs][j+szs][it-1];
					bool f=check(i,j,szs,it,mask);
					if (f)
					{
						res++;
						how[i][j][it]=mask;
					}
					else
						how[i][j][it]=-1;
				}
			}
	}
	cout<<res<<endl;
#ifdef Fcdkbear
    double end=clock();
    fprintf(stderr,"*** Total time = %.3lf ***\n",(end-beg)/CLOCKS_PER_SEC);
#endif
	return 0;
}