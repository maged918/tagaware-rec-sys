//Language: GNU C++


#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxn=100005;

int s1[maxn],s2[maxn],a[maxn],b[maxn];
bool v[maxn];

int main(){
	int n,m,x;
	int i;
	char ch;
	while(scanf("%d%d",&n,&m)!=EOF){
		memset(s1,0,sizeof(s1));
		memset(s2,0,sizeof(s2));
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		memset(v,0,sizeof(v));
		for(i=1;i<=n;i++){
			getchar();
			scanf("%c%d",&ch,&x);
			if(ch=='+') a[x]++,s1[i]=x; 
			if(ch=='-') b[x]++,s2[i]=x;
		}
		int sum=0,num=0;
		for(i=1;i<=n;i++) sum+=b[i];
		for(i=1;i<=n;i++){
			if(a[i]+sum-b[i]==m) num++,v[i]=1;
		}
		for(i=1;i<=n;i++){
			if(s1[i]) {
				if(v[s1[i]]){
					if(num>1) puts("Not defined");
					else puts("Truth");
				}
				else puts("Lie");
			}
			else {
				if(v[s2[i]]) {
					if(num>1) puts("Not defined");
					else puts("Lie");
				}
				else puts("Truth");
			}
		}
	}
	return 0;
}