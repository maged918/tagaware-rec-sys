//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>

using namespace std;

int main(){
    long int n;
    int t=0,flag=0,m=0;
    string s[100005];
    cin >> n;
    t=1,m=1;
    for(int i=0;i<=n;i++){
        getline(cin,s[i]);

    }

    for(int j=1;j<=n;j++){
        if(s[j]==s[j-1]){
            flag =1;
        }
        else{
            flag=0;
            m=1;
        }
        if(flag==1){
            m++;
        }
        if(m>t)
        t=m;
    }
    cout << t << endl;

return 0;
}