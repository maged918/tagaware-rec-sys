//Language: MS C++


#include <stdio.h>
#include <algorithm>
#include <vector>
#include <math.h>
using namespace std;

vector <vector <pair<int,int> > > g;
vector <int> d0,d1,d2;
vector <bool> used;
int ans;
int min(int a,int b,int c){
    return min(a,min(b,c));
}
int min(int a,int b,int c,int d){
    return min(min(a,b,c),d);
}
void dfs0(int v)
{
    used[v]=true;
    int dt1=0,dt2=0; d0[v]=0;
    for (int i=0;i<g[v].size();i++){
        int to=g[v][i].first,ves=g[v][i].second;
        if (!used[to])
        {
            dfs0(to);
            d0[v]+=d0[to]+ves;
            dt1=min(dt1,d1[to]-2*ves+1-d0[to]);
            dt2=min(dt2,d2[to]-d0[to],d1[to]-d0[to]-ves);
        }
    }
    d1[v]=d0[v]+dt1;d2[v]=d0[v]+dt2;
}


int main()
{
int n;
//freopen("input.txt","r",stdin);
//freopen("output.txt","w",stdout);
scanf("%d",&n);
g.resize(n);
d0.resize(n,0);
d1.resize(n,0);
d2.resize(n,0);
ans=n;
for (int i=1;i<n;i++ )
{
    int a,b;
    scanf("%d%d",&a,&b);
    g[a-1].push_back(make_pair(b-1,0));
    g[b-1].push_back(make_pair(a-1,1));
}
for (int i=0; i<n; i++){
    used.assign(n,false);
    dfs0(i);
    ans=min(ans,d1[i],d2[i],d0[i]);

}
printf("%d",ans);
return 0;
}