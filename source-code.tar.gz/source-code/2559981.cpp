//Language: MS C++


#include<stdio.h>
#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>

using namespace std;
int was[10000], lnmin=11, lnmax, ln;

string a[10000], d, b[1000];
int main()
{
    int n, ln;
    cin >> n;

    for(int i=0; i<n; i++)
        
        {
            cin >> a[i];
            int aa=a[i].length();
            lnmin=min(lnmin, aa);
            lnmax=max(lnmax,aa);
        }

    cin >> d;

    sort(a, a+n);

    ln=lnmin+lnmax;
    int k=0;
    for(int i=0; i<n; i++)
    { if(was[i]==1) continue;
        for(int j=0; j<n; j++)
        {
            if(was[j]==0 && a[i].length()+a[j].length()==ln && i!=j)
            {
                was[i]=1;
                was[j]=1;
        if(a[i]+d+a[j]< a[j]+d+a[i])
        b[k]=a[i] + d + a[j];
        else
        b[k]= a[j] + d + a[i];
        k++;
        break;

            }
        }
    }

    sort(b, b+k);

    for(int h=0; h < n/2; h++)
        cout << b[h] << "\n";

return 0;
}

