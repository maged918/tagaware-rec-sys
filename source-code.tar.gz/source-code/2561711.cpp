//Language: GNU C++


//******************************************************************
// Coded by: Huynh Nhat Minh
// Problem Code: 242C - King's Path
// Verdict: 
//******************************************************************
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <cctype>
#include <deque>
#include <stack>
#include <queue>
#include <list>
#include <vector>
#include <map>
#include <sstream>
#include <cmath>
#include <bitset>
#include <utility>
#include <set>
#define i64 long long
#define u64 unsigned long long
#define PI 3.1415926535897932384626433832795
#define read(x) scanf("%d",&x)
#define out(x) printf("%d\n",x)
#define DEBUG(x) cout << #x << " = " << x << endl
#define FOR(i,a,b) for(int i = a ; i <= b ; i++)
#define mp make_pair
#define ff first
#define ss second
#define pb push_back
#define pf push_front
#define maxN 123456
#define INF 1000111222

using namespace std;

int dx[] = {-1,-1,-1, 0, 0, 1, 1, 1};
int dy[] = {-1, 0, 1,-1, 1,-1, 0, 1};

pair<int,int> st,ed;
int n;
set< pair<int,int> > s;
map< pair<int,int>,int > step;

int BFS()
{
    queue< pair<int,int> > q;
    q.push(st);
    step[st] = 1;
    
    while(!q.empty())
    {
        //cout << "AAAAAAAAAAAAAAAAA" << endl;
        int y = q.front().ff;
        int x = q.front().ss;
        
        if(ed.ss == x && ed.ff == y)
            return step[ed]-1;
            
        q.pop();
        
        for(int i = 0 ; i < 8 ; i++)
        {
            int yy = y + dy[i];
            int xx = x + dx[i];
            //DEBUG(yy);
            //DEBUG(xx);
            //cout << s.count(mp(yy,xx)) << endl;
            if(!step[mp(yy,xx)] && s.count(mp(yy,xx)))
            {
                step[mp(yy,xx)] = step[mp(y,x)] + 1;
                q.push(mp(yy,xx));
            }
        }
    }
    
    return -1;
}

int main()
{
    //freopen("242C - King's Path.INP","r",stdin);
    //freopen("242C - King's Path.OUT","w",stdout);
    
    scanf(" %d %d %d %d ",&st.ff,&st.ss,&ed.ff,&ed.ss);
    scanf(" %d ",&n);
    for(int i = 0 ; i < n ; i++)
    {
        int r,a,b;
        scanf(" %d %d %d ",&r,&a,&b);
        for(int j = a ; j <= b ; j++)
            s.insert(mp(r,j));
    }
    
    printf("%d\n",BFS());

    return 0;
}
