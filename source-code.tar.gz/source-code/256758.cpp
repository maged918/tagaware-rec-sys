//Language: GNU C++


//Seidazimov Nurbol
#include<iostream>
#include<math.h>
#include<vector>
#include<utility>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<string>
#include<string.h>
#include<sstream>
#include<map>
#include<set>
#include<stack>
#include<queue>
#include<deque>
#include<limits>
#include<list>
#include<functional>
#include<bitset>
#include<numeric>
#include<iomanip>
#include<cmath>
#include<ctime>
#define FOR(i,a,b) for(int i=a;i<=b;i++)
#define For(i,a,b) for(int i=a;i>=b;i--)
#define F first
#define S second
#define pb(x) push_back(x)
#define mp(x,y) make_pair(x,y)
#define INF numeric_limits<int>::max()
using namespace std;
string s;
int n,k=0;
int main()
{
 //freopen("input.txt","r",stdin);
 //freopen("output.txt","w",stdout);
  cin>>n;
  FOR(i,1,n)
  {
   cin>>s;
   if(s=="ABSINTH" || s=="BEER" || s=="BRANDY" || s=="CHAMPAGNE" || s=="WINE" || s=="WHISKEY" || s=="VODKA" || s=="TEQUILA" || s=="GIN" || s=="RUM" || s=="SAKE") k++;
   if(s=="0" || s=="1" || s=="2" || s=="3" || s=="4" || s=="5" || s=="6" || s=="7" || s=="8" || s=="9" || s=="10" || s=="11" || s=="12" || s=="13" || s=="14" || s=="15" || s=="16" || s=="17") k++;
  }
   cout<<k;
 //fclose(stdin);fclose(stdout);
return 0; 
}