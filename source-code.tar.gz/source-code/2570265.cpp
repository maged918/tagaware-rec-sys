//Language: MS C++


#include <iostream>
using namespace std;


bool marker[1000];
int ais[50];
int main()
{
	int k,n;
	cin >> n >> k;
	int a;
	int i;
	for(i=0;i<k;i++)
	{
		cin >> a;
		marker[a-1]=true;
		ais[i]=a;
	}
	int rem;
	rem=0;
	for(i=0;i<k;i++)
	{
		int j;
		cout << ais[i];
		for(j=0;j<n-1;j++)
		{
			cout << " ";
			for(;;rem++)
			{
				if(marker[rem]==false)break;
			}
			cout << ++rem;
		}
		cout << endl;
	}
	return 0;
}