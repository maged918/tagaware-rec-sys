//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

int s[55];
int n,m;

int main()
{
    int i,j,k,t1,t2,t3;
    scanf("%d%d",&n,&m);
    for (i=0;i!=n;++i) scanf("%d",&s[i]);
    sort(&s[0],&s[n]);
    i=0;
    while (i<m)
    {
        for (k=n;k!=0 && i!=m;--k)
        {
            for (j=0;j!=k && i!=m;++j)
            {
                printf("%d ",1+n-k);
                for (t1=n-1;t1>=k;--t1)
                {
                    printf("%d ",s[t1]);
                }
                printf("%d\n",s[j]);
                ++i;
            }
        }
    }
    //system("pause");
    return 0;
}
