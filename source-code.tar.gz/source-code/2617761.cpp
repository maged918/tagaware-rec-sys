//Language: GNU C++0x


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <numeric>
#include <complex>
#include <stack>
#include <queue>
#include <list>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <bitset>
#include <functional>
#include <iterator>

using namespace std;

#define dump(n) cout<<"# "<<#n<<'='<<(n)<<endl
#define repi(i,a,b) for(int i=int(a);i<int(b);i++)
#define peri(i,a,b) for(int i=int(b);i-->int(a);)
#define rep(i,n) repi(i,0,n)
#define per(i,n) peri(i,0,n)
#define all(c) begin(c),end(c)
#define mp make_pair

typedef unsigned int uint;
typedef long long ll;
typedef unsigned long long ull;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<double> vd;
typedef vector<vd> vvd;
typedef vector<string> vs;
typedef pair<int,int> pii;

const int INFTY=1<<29;
const double EPS=1e-9;

template<typename T1,typename T2>
ostream& operator<<(ostream& os,const pair<T1,T2>& p){
	return os<<'('<<p.first<<','<<p.second<<')';
}
template<typename T>
ostream& operator<<(ostream& os,const vector<T>& a){
	os<<'[';
	rep(i,a.size()) os<<(i?" ":"")<<a[i];
	return os<<']';
}

int main()
{
	for(int n,k;cin>>n>>k && n|k;){
		vi a(n);
		rep(i,n) cin>>a[i];
		
		unordered_set<int> flg;
		vi sum;
		vvi res;
		for(int i=0;i<n && res.size()<k;i++){
			per(j,sum.size()){
				if(!flg.count(sum[j]+a[i])){
					flg.insert(sum[j]+a[i]);
					sum.push_back(sum[j]+a[i]);
					res.push_back(res[j]);
					res.back().push_back(a[i]);
				}
			}
			if(!flg.count(a[i])){
				flg.insert(a[i]);
				sum.push_back(a[i]);
				res.emplace_back(1,a[i]);
			}
		}
		rep(i,k){
			cout<<res[i].size();
			rep(j,res[i].size())
				cout<<' '<<res[i][j];
			cout<<endl;
		}
	}
	
	return 0;
}
