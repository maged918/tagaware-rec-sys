//Language: MS C++


#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <list>
#include <map>
#include <deque>
#include <math.h>
using namespace std;
typedef pair<int,int> pii;
typedef map<pii,int> mpiii;
typedef vector<pii> vpii;
typedef vector<int> vi;
#define mp make_pair
#define pb push_back

int i,j,n,m;
int d=0,l=0,k=0;
double x=0,y=0,
	X0,Y0,
	X1,Y1,
	X2,Y2;

vector<int> a;
int cnt=0;



int main(){

#ifndef ONLINE_JUDGE
	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout);
#endif	
	ios_base::sync_with_stdio(false); cin.tie(NULL);
	double Yw,Xb,Yb,r;
	double Xw;
	cin>>Y1>>Y2>>Yw>>Xb>>Yb>>r;
	double Yc = (Y1+r);

	if(2.0*Yw-2.0*r-Yb-Yc == 0){
		cout<<-1;
		return 0;
	}

	Xw = (Xb*Yw-r*Xb-Yc*Xb) / (2.0*Yw-2.0*r-Yb-Yc);

	double d = Xb-Xw;
	double t = d*(Y2-Yc);
	d = sqrt( (Yw-r-Yb)*(Yw-r-Yb)+d*d );
	if(d==0){
		cout<<-1;
		return 0;
	}
	d = t/d;
	if(d+1e-8<r){
		cout<<-1;
		return 0;
	}
	cout.precision(20);
	cout<<Xw;
	return 0;
}