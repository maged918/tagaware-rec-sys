//Language: MS C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <map>
#include <vector>
using namespace std;
const int maxn = 100005;

struct Node{
    int co,val;
    void set(int a,int v){
        co = a;
        val = v;
    }
};
Node mat[maxn];
int n,k;
int a[maxn],bl;
int hash[maxn];
bool comp(const Node & t1,const Node & t2){
    if(t1.val != t2.val)
        return t1.val < t2.val;
    return t1.co < t2.co;
}
vector<int> v[maxn];
int main(int argc,char *argv[])
{
    int i,j,l,pos;
    int ret,retv,val;
    scanf("%d%d",&n,&k);
    bl = 0;
    for(i = 0;i < n;i ++){
        scanf("%d",&a[i]);
        if(i == 0) mat[0].set(a[i],1);
        else{
            if(a[i] == mat[bl].co) mat[bl].val ++;
            else{
                ++bl;
                mat[bl].set(a[i],1);
            }
        }
    }
    ++ bl;
    for(i = 0;i < bl;i ++){
        v[mat[i].co].push_back(i);
    }
    retv = bl;
    ret = 1;
    for(i = 1;i <= k;i ++){
        l = v[i].size();
        val = bl-1;
        for(j = 0;j < l;j ++){
            pos = v[i][j];
            if(v[i][j] == 0){
                val --;
            }else if(v[i][j] == bl-1){
                val --;
            }else{
                if(mat[pos-1].co == mat[pos+1].co){
                    val -= 2;
                }else val --;
            }
        }
        if(val < retv){
            retv = val;
            ret = i;
        }
    }
    printf("%d\n",ret);
    return 0;
}