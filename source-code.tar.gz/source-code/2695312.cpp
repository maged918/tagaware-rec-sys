//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <vector>
#include <list>
#include <queue>
#include <map>
#include <algorithm>
#include <set>
#include <cstring>
#include <string>
using namespace std;

typedef pair<int,int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef long long ll;

#define pb push_back
#define mp make_pair
#define ff first
#define ss second
#define Size(X) ((int)X.size())
#define reset(X) memset(X,0,sizeof(X))

#define MAXN 1005

int N, K;
string S;
int main(){
	//~ freopen("in.txt","r",stdin);
	//~ freopen("out.txt","w",stdout);
	scanf("%d%d", &N,&K);
	cin>>S;
	int cnt = 0;
	if (K==2){
		int c1 = 0, c2 = 0;
		for (int i = 0; i < S.size(); i++){
			if (S[i]!='A'+(i%2))
				c1++;
			else
				c2++;
		}
		if (c1<=c2){
			cnt = c1;
			for (int i = 0; i < S.size(); i++)
				S[i] = 'A'+(i%2);
		} else {
			cnt = c2;
			for (int i = 0; i < S.size(); i++)
				S[i] = 'A'+((i+1)%2);
		}
	} else {
		for (int i = 1; i < S.size(); i++){
			if (S[i]==S[i-1]){
				if (S[i]!='A' && (i==S.size()-1 || S[i+1]!='A'))
					S[i] = 'A';
				else if (S[i]=='A' && (i==S.size()-1 || S[i+1]!='B'))
					S[i] = 'B';
				else if (S[i]!='B' && (i==S.size()-1 || S[i+1]=='A'))
					S[i] = 'B';
				else
					S[i] = 'C';
				cnt++;
			}
		}
	}
	printf("%d\n%s\n", cnt, S.c_str());
	return 0;
}
