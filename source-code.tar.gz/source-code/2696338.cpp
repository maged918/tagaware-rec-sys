//Language: GNU C++


#include<iostream>
#include<cstring>
#include<cstdio>
#include<vector>
#include<algorithm>
#include<cmath>

using namespace std;

const int maxn = 100010;
int n, m, a, b;
int ly[maxn], ry[maxn], l[maxn];

int main()
{
    while(scanf("%d%d%d%d", &n, &m, &a, &b) == 4)
    {
        for(int i = 0; i < n; i++)
            scanf("%d", ly + i);    
        for(int i = 0; i < m; i++)
            scanf("%d", ry + i);
        for(int i = 0; i < m; i++)
            scanf("%d", l + i);
        
        int ai = 0, bi = 0;
        double ans = 1e100;
        for(int i = 0; i < m; i++)
        {
            double y = (double)ry[i] * a / b;
            int j = lower_bound(ly, ly + n, y) - ly;
            
            for(int k = max(j - 1, 0); k <= min(n - 1, j + 1); k++)
            {
                double tmp = sqrt((double)a * a + (double)ly[k] * ly[k]) + \
                sqrt((double)(b - a) * (b - a) + (double)(ly[k] - ry[i]) * (ly[k] - ry[i])) + l[i];
                
                if(tmp < ans)
                    ans = tmp, ai = k, bi = i;
            }   
        }
        
        printf("%d %d\n", ai + 1, bi + 1);
    }
    return 0;   
}
