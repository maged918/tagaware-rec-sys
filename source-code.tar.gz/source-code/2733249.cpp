//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <queue>
using namespace std ;

const int MAXN = 50010 ;
int N , M ;
int T , S , P , x ;
long long ed ;
struct point{
      int p , t , s , id , last ;
      friend bool operator < (const point &a , const point &b){
            return a.p < b.p ;
      }
};
bool cmp(const point &a , const point &b){
      return a.t < b.t ;
}
vector<point> a ;
vector<int> pro ;
vector<int> d ;
long long end[MAXN] ;

bool check(int pr){
      a[x].p = pr ;
      priority_queue<point> q ;
      point tp ;
      long long now = 0 ;
      for (int i = 0 ; i < N ; i++){
            while ((!q.empty()) && (now<a[i].t)){
                  tp = q.top() ; q.pop() ;
                  if (tp.last<=a[i].t-now){
                        now+=tp.last;
                        end[tp.id]=now ;
                  }else{
                        tp.last -= a[i].t-now ;
                        now = a[i].t ;
                        q.push(tp);
                  }
            }
            tp.id = a[i].id ; tp.last = a[i].s ; tp.p = a[i].p ;
            q.push(tp) ;
            now = a[i].t ;
      }
      while (!q.empty()){
            tp = q.top() ; q.pop();
            now += tp.last ;
            end[tp.id] = now ;
      }
      return (end[a[x].id]>=ed);
}

void solve1(){
      for (int i = 0 ; i < pro.size() ; i++){
            if (i==0){
                  if (pro[i]-1>=1)
                        d.push_back(pro[i]-1);
                  continue ;
            }
            if (pro[i]-1==pro[i-1]) continue ;
            d.push_back(pro[i]-1);
      }
      M = pro.size() ;
      if (pro[M-1] + 1 <= 1000000000)
            d.push_back(pro[M-1]+1) ;
      M = d.size() ;
}

void solve2(){
      int l = 0 , r = M-1 ;
      int ret = -1 ;
      while (l <= r){
            int mid = (l+r)>>1 ;
            if (check(d[mid])){
                  ret = mid ;
                  l = mid + 1 ;
            }else
                  r = mid - 1 ;
      }
      printf("%d\n",d[ret]) ;
      check(d[ret]);
      for (int i = 0 ; i < N ; i++)
            printf("%I64d ",end[i]);
      printf("\n");
}
int main(){
      freopen("input.txt","r",stdin);
      freopen("output.txt","w",stdout);
      scanf("%d",&N);
      for (int i = 1 ; i <= N ; i++){
            point temp ; temp.id = i-1 ;
            scanf("%d%d%d",&T,&S,&P);
            temp.t = T ; temp.s = S ; temp.p = P ;
            a.push_back(temp) ;
            if (P!=-1)
                  pro.push_back(P) ;
      }
      sort(pro.begin() , pro.end()) ;
      sort(a.begin() , a.end() , cmp) ;
      for (int i = 0 ; i < N ; i++)
            if (a[i].p == -1) x = i ;
      solve1();
      scanf("%I64d",&ed) ;
      solve2();
      return 0 ;
}

