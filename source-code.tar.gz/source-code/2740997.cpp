//Language: GNU C++


#include <iostream>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
#include <cstdio>
#include <cmath>
#include <iomanip>

using namespace std;

int ee[500][1000];
int di[500][1000], pp[500][1000], aa[500][1000];

int l[500], r[500], f[500], a[500], li[500], ok, z;

int n,i,m,v,h,j, have, ll, jj, anss;
int dp[500][1000], pred[500][1000], ge[500][1001];


int main()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);    
    cin >> n >> v;
    for (i=1;i<=n;i++) cin >> a[i];
    cin >> m;
    for (i=1;i<=m;i++) cin >> l[i] >> r[i] >> f[i];
    
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=m;j++)
          if ((l[j] <= i) && (i<=r[j]))
            for (h = 800;  h>= f[j]; h--)
             if (ee[i][h]<ee[i][h-f[j]] + 1) ee[i][h] = ee[i][h-f[j]] + 1;
    }
    for (i=1;i<=450;i++)
        for (j=0;j<=900;j++)
          dp[i][j] = -100000000;
          
    dp[1][0] = 0;
    
    for(i=1;i<=n;i++)
    {
                     for (j=0;j<=400;j++)
                     {
                         if (j+a[i]>=v)
                         {
                                       have = j + a[i] - v;
                                       for (ll=0;ll<=have;ll++)
                                       {
                                           z = min(have-ll,a[i]);
                                          if (dp[i][j]+ee[i][ll]>dp[i+1][z]) 
                                          {
                                                                                 dp[i+1][z] = dp[i][j]+ee[i][ll];
                                                                                 pred[i+1][z] = j;
                                                                                 ge[i+1][z] = ll;
                                          }
                                       }
                                       
                         }
                     }
    }
    anss = -1;
    for (j=0;j<=400;j++)
        if (dp[n+1][j] > anss)
        {
                       anss = dp[n+1][j];
                       jj = j;
        }
    cout << anss << endl;
    for (i=n+1;i>1;i--)
    {
        ll = ge[i][jj];
        jj = pred[i][jj];
        for (j=1;j<=m;j++)
        {
            
          if ((l[j] <= i-1) && (i-1<=r[j]))          ok = 1; else ok = 0;            
            for (h=0;h<=ll;h++)
            {
                di[j][h] = di[j-1][h];
                pp[j][h] = 0;
                
          if (ok)         
          if (h>=f[j])   
                if (di[j-1][h-f[j]]+1>di[j][h]) 
                {
                                                di[j][h] = di[j-1][h-f[j]] + 1;
                                                pp[j][h] = j;
                }
                
            }
        }
        for (j=m;j>0;j--)
        {
            if (pp[j][ll] != 0)
            {
                          ll = ll - f[j];
                          li[i-1]++;
                          aa[i-1][li[i-1]] = j;
            }
        }
    }
    for (i=1;i<=n;i++)
    {
        cout << li[i];
        for (j=1;j<=li[i];j++) cout << " " << aa[i][j];
        cout << endl;
    }
//    system("pause");
    return 0;
}
