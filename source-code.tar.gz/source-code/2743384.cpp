//Language: GNU C++


#include <limits.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <limits>
#include <cassert>
#include <string>
#include <vector>
#include <deque>
#include <fstream>
#include <algorithm>
#include <numeric>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <queue>
#include <iterator>
#include <set>
static const int INF = std::numeric_limits<int>::max();
int days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
int OFF = 500;
int tox(int m, int d)
{
  int x = d;
  for(int i = 0; i < m-1; ++i) {
    x += days[i];
  }
  return x+OFF;
}
int v[1000];
int main()
{
  std::ifstream cin("input.txt");
  std::ofstream cout("output.txt");
  int n;
  cin >> n;
  for(int i = 0; i < n; ++i) {
    int m, d, p, t;
    cin >> m >> d >> p >> t;
    int x = tox(m, d);
    for(int j = x-1, eoj = x-1-t; j > eoj; --j) {
      v[j] += p;
    }
  }
  int res = 0;
  for(int i = 0; i < 1000; ++i) {
    res = std::max(res, v[i]);
  }
  cout << res << std::endl;
}
