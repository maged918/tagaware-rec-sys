//Language: GNU C++


#include <map>
#include <set>
#include <cmath>
#include <stack>
#include <queue>
#include <string>
#include <vector>
#include <bitset>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <iostream>
#include <algorithm>
//#include <sys/time.h>
using namespace std;
#define li        long long int
#define rep(i,to) for(li i=0;i<((li)(to));++i)
#define pb        push_back
#define sz(v)     ((li)(v).size())
#define bit(n)    (1ll<<(li)(n))
#define all(vec)  (vec).begin(),(vec).end()
#define each(i,c) for(__typeof((c).begin()) i=(c).begin();i!=(c).end();i++)
#define MP        make_pair
#define F         first
#define S         second


#define MAX 4050
li n, a[MAX];
vector<li> v[MAX];
map<li, li> mp;

int main()
{
	cin >> n;
	rep(i, n) cin >> a[i];
	rep(i, n){
		if(mp.count(a[i]) == 0){
			li t = sz(mp);
			mp[a[i]] = t;
		}
		v[mp[a[i]]].pb(i);
	}
		
	li res = 1;
	rep(i, sz(mp))rep(j, sz(mp)){
		res = max(res, sz(v[j]));
		if(i == j) continue;
		li index0 = 0;
		li index1 = 0;
		li cnt = 0;
		li cur = -1;
		for(li step = 0; true; step++, cnt++){
			if(step % 2 == 0){
				while(index0 < sz(v[i]) && v[i][index0] <= cur) index0++;
				if(index0 == sz(v[i])) break;
				cur = v[i][index0];
			}else{
				while(index1 < sz(v[j]) && v[j][index1] <= cur) index1++;
				if(index1 == sz(v[j])) break;
				cur = v[j][index1];
			}
		}
		res = max(res, cnt);
	}
	cout << res << endl;
}
