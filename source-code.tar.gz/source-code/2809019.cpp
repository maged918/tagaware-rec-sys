//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <list>
#include <cstring>
#include <stack>
#include <bitset>

using namespace std;

#define NMAX 2147483647
#define LMAX 9223372036854775807LL
#define pb push_back
#define pob pop_back
#define mp make_pair
#define st first
#define nd second
#define LB lower_bound
#define NP next_permutation
#define BS binary_search
#define SZ(v) ((int)(v).size())
#define FOR(i,a,b) for(int i=(a);i<(b);++i)
#define FORD(i,a,b) for(int i=(a);i>(b);--i)
#define REP(i,n) FOR(i,0,n)
#define FORE(i,a,b) for(int i=(a);i<=(b);++i)
#define REPE(i,n) FORE(i,1,n)
#define ALL(z) z.begin(),z.end()
#define TR(c,it) for(typeof((c).begin()) it=(c).begin();it!=(c).end();it++)

template<class T> T gcd(T a,T b) { return (b==0)?a:gcd(b,a%b); }
template<class T> T lcm(T a,T b) { return a*(b/gcd(a,b)); }
typedef long long ll;
typedef vector<int> vi;
typedef vector<string> vs;
typedef pair<int,int> ii;
typedef vector<ii> vii;

using namespace std;

int arr[4][4], sum = 0;

bool cek()
{
  int tes[10];
  memset(tes,0,sizeof(tes));
  REP(i, 3)
  {
    tes[0] += arr[0][i];
    tes[1] += arr[1][i];
    tes[2] += arr[2][i];
  }
  REP(i, 3)
  {
    tes[3] += arr[i][0];
    tes[4] += arr[i][1];
    tes[5] += arr[i][2];
  }
  tes[6] = arr[0][0] + arr[1][1] + arr[2][2];
  tes[7] = arr[0][2] + arr[1][1] + arr[2][0];
  REP(i, 8) if(tes[i] != sum) return 0;
  return 1;
}

int main()
{
  //freopen("input.txt","r",stdin);
  //freopen("output.txt","w",stdout);
  REP(i, 3) REP(j, 3) scanf("%d",&arr[i][j]);
  int lo = 0, hi = 100000;
  REP(i, 100001)
  {
    arr[0][0] = i;
    sum = 0;
    REP(i, 3) sum += arr[0][i];
    arr[1][1] = sum - arr[1][0] - arr[1][2];
    arr[2][2] = sum - arr[2][0] - arr[2][1];
    if(cek()) break;
  }
  REP(i, 3) REP(j, 3)
    if(j == 2) cout << arr[i][j] << endl;
    else cout << arr[i][j] << " ";
  return 0;
}
