//Language: GNU C++


#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
char ch[100000+55];
int main()
{
  scanf("%s",ch);
  int s=strlen(ch);
  int i,j;
  for(i=0;i<s;i++)
	  if(ch[i]=='0')
		  break;
 if(i==s)
		  i--;
	  for(j=0;j<i;j++)
		  printf("%c",ch[j]);
	 
	  j=i+1;
	  for(;j<s;j++)
		  printf("%c",ch[j]);
	  puts("");
	return 0;

}
