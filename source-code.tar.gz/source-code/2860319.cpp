//Language: GNU C++0x


// 并查集
// 素集合データ構造

#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>

void Get(int &T)
{
	char C;bool F=0;
	for(;C=getchar(),C<'0'||C>'9';)if(C=='-')F=1;
	for(T=C-'0';C=getchar(),C>='0'&&C<='9';T=T*10+C-'0');
	F&&(T=-T);
}

int L[2005][2005];
int R[2005][2005];

bool Rot;

int N,M,K;

int GetL(int X,int Y)
{
	if(L[X][Y]==Y) return Y;
	return L[X][Y]=GetL(X,L[X][Y]);
}

int GetR(int X,int Y)
{
	if(R[X][Y]==Y) return Y;
	return R[X][Y]=GetR(X,R[X][Y]);
}

void Debug9()
{
	puts("========");
	
	for(int i=1;i<=N;i++)
	{
		for(int j=0;j<=M+1;j++)
		{
			int Ans=GetL(i,j);
			printf("%d ",Ans);
		}
		puts("");
	}
	
	puts("========");
	
	for(int i=1;i<=N;i++)
	{
		for(int j=0;j<=M+1;j++)
		{
			int Ans=GetR(i,j);
			printf("%d ",Ans);
		}
		puts("");
	}
	
	puts("========");
}

void Init()
{
	Get(N);Get(M);Get(K);
	
	if(N>M)
	{
		std::swap(N,M);
		Rot=1;
	}
	
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M+1;j++)
			L[i][j]=R[i][j]=j;
}

int Ans;
int AnsX,AnsY;
int X0,Y0;

void Fresh(int X,int Y)
{
	if(X<1||X>N) return;
	if(Y<1||Y>M) return;
		
	int Dis=std::abs(X-X0)+std::abs(Y-Y0);
	if(Rot)
	{
		std::swap(X,Y);
	}
	
	if(Ans>Dis)
	{
		Ans=Dis;
		AnsX=X;
		AnsY=Y;
	}
	else if(Ans==Dis)
	{
		if(AnsX>X)
		{
			AnsX=X;
			AnsY=Y;
		}
		else if(AnsX==X&&AnsY>Y)
		{
			AnsX=X;
			AnsY=Y;
		}
	}
}

void Work()
{
	for(int k=1;k<=K;k++)
	{
		Ans=0x2f2f2f2f;
		
		Get(X0);Get(Y0);
		if(Rot) std::swap(X0,Y0);
		
		for(int d=0;d<=Ans;d++)
		{
			int X;
			int Y;
			
			if(X0-d>0)
			{
				X=X0-d;
				Y=GetL(X,Y0);
				Fresh(X,Y);
				
				X=X0-d;
				Y=GetR(X,Y0);
				Fresh(X,Y);
			}
			
			if(X0+d<=N)
			{
				X=X0+d;
				Y=GetL(X,Y0);
				Fresh(X,Y);
				
				X=X0+d;
				Y=GetR(X,Y0);
				Fresh(X,Y);
			}
		}
		
		printf("%d %d\n",AnsX,AnsY);
		
		if(Rot)
		{
			std::swap(AnsX,AnsY);
		}
		
		L[AnsX][AnsY]=AnsY-1;
		R[AnsX][AnsY]=AnsY+1;
	}
}

int main()
{
	Init();
	Work();
}