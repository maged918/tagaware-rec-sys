//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <climits>
#include <list>
#include <map>
#include <cmath>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <cstdio>
#include <string>
#include <cstring>
#include <vector>
#include <numeric>

using namespace std;

#define REP(i,n) for(int i=0; i<(int)(n); i++)
#define FOR(i,b,e) for (int i=(int)(b); i<(int)(e); i++)
#define EACH(itr,c) for(__typeof((c).begin()) itr=(c).begin(); itr!=(c).end(); itr++)  

int n;
struct task {
    int t;  // time arrival
    int s;  // number of pages
    int p;  // priority
    int i;  // original index

    bool operator<(const task &tsk) const {
        return t < tsk.t;
    }
};

task v[50000];
long long tm[50000];
int rm[50000];

long long solve(int pos) {
    priority_queue<pair<int, int> > Q;
    int p = 0;
    long long t = 0;
    
    REP (i, n)
        rm[i] = v[i].s;

    while (p < n || !Q.empty()) {
        if (Q.empty()) {
            Q.push(make_pair(v[p].p, p));
            t = v[p].t;
            ++p;
        }

        int x = Q.top().second;
        long long u = (p < n) ? v[p].t - t : 1LL<<60;
        if (rm[x] <= u) {
            t += rm[x];
            rm[x] = 0;
            tm[x] = t;
            Q.pop();
        } else {
            t += u;
            rm[x] -= u;
            Q.push(make_pair(v[p].p, p));
            ++p;
        }
    }
    return tm[pos];
}

void printAns(int x) {
    static long long ans[50000];

    cout << v[x].p << endl;
    REP (i, n)
        ans[v[i].i] = tm[i];

    REP (i, n)
        cout << ans[i] << " ";
    cout << endl;
}

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    cin >> n;
    
    int x = -1;
    long long T;

    REP (i, n) {
        cin >> v[i].t >> v[i].s >> v[i].p;
        v[i].i = i;
    }

    cin >> T;
    sort(v, v+n);
    REP (i, n) if (v[i].p == -1) x = i;
    
    vector<int> pri;
    REP (i, n) pri.push_back(v[i].p);
    pri.push_back(0);
    pri.push_back(1e9+1);
    sort(pri.begin(), pri.end());
    
    vector<int> cand;
    FOR (i, 1, pri.size()) {
        if (pri[i] - pri[i-1] > 1)
            cand.push_back(pri[i-1]+1);
    }
    cand.push_back(1e9+1);

    int lo = 0;
    int hi = cand.size();
    
    while (true) {
        int mid = (lo+hi) >> 1;
        v[x].p = cand[mid];
        long long U = solve(x);
        if (U == T)
            break;
        else if (U < T)
            hi = mid;
        else
            lo = mid;
    }
    printAns(x);

    return 0;
}
