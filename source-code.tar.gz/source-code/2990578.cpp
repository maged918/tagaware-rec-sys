//Language: GNU C++


// INCLUDE LIST
#include <cstdio>
#include <bitset>
#include <iostream>
#include <queue>
#include <stack>
#include <string>
#include <cstring>
#include <algorithm>
#include <map>
#include <set>
#include <list>
#include <vector>
#include <cstdlib>
#include <cctype>
#include <cmath>
using namespace std;

// DEFINE LIST
#define REP(_I, _J, _K) for(_I = (_J) ; _I < (_K) ; _I++)
#define input(_A)       freopen(_A, "r", stdin);
#define output(_A)      freopen(_A, "w", stdout);
#define INPUT           input("in.txt");
#define OUTPUT          output("out.txt");
#define hold            {fflush(stdin); getchar();}
#define reset(_A, _B)   memset((_A), (_B), sizeof (_A));
#define debug           printf("<<TEST>>\n");
#define eps             1e-11
#define f_cmp(_A, _B)   (fabs((_A) - (_B)) < eps)
#define phi             acos(-1)
#define pb              push_back
#define value(_A)       cout << "Variabel -> " << #_A << " -> " << _A << endl;
#define st              first
#define nd              second

// TYPEDEF LIST
typedef pair<int, int>  ii;
typedef vector<int>     vi;
typedef vector<ii>      vii;
typedef long long       LL;

// VAR LIST
int MAX =               1000000;
int MIN =               -1000000;
int INF =               1000000000;
int x4[4] =             {0, 1, 0, -1};
int y4[4] =             {1, 0, -1, 0};
int x8[8] =             {0, 1, 1,  1,  0, -1, -1, -1};
int y8[8] =             {1, 1, 0, -1, -1, -1,  0,  1};
int i, j, k;

int n, mat[1010][1010];

void tukar(int A, int B) {
    int i, j;
    for(i=1;i<=n;i++) swap(mat[i][A], mat[i][B]);
    return;
}

// MAIN CODE
int main () {
    int kolom[2000], baris[2000], x, y, i, j;
    vector<pair<int, pair<int, int> > > v;
    reset(kolom, 0);
    reset(baris, 0);
    reset(mat, 0);
    cin >> n;
    REP(i, 0, n-1) {
        cin >> x >> y;
        mat[x][y] = 1;
    }
    for(i=1;i<=n;i++) {
        for(j=1;j<=n;j++) {
            if (mat[i][j] == 1) 
                kolom[j] = i;
        }
    }
    for(i=1;i<=n;i++) {
        int maks = 0;
        int indx = i;
        for(j=i;j<=n;j++) {
            if (kolom[j] >= maks) {
                maks = kolom[j];
                indx = j;
            }
        }
        if (indx != i) {
            v.pb(make_pair(2, make_pair(i, indx)));
            swap(kolom[i], kolom[indx]);
            tukar(i, indx);
        }
    }
    for(i=1;i<=n;i++) {
        for(j=1;j<=n;j++) {
            if (mat[i][j] == 1) 
                baris[i] = j;
        }
    }
    for(i=1;i<=n;i++) {
        int minim = INF;
        int indx = i;
        for(j=i;j<=n;j++) {
            if (baris[j] <= minim) {
                minim = baris[j];
                indx = j;
            }
        }
        if (indx != i) {
            v.pb(make_pair(1, make_pair(i, indx)));
            swap(baris[i], baris[indx]);
        }
    }
    cout << v.size() << endl;
    REP(i, 0, v.size()) cout << v[i].first << " " << v[i].second.first << " " << v[i].second.second << endl;
    hold;
    return 0;
}

// VINCENTIUS MADYA
// DARKSTALKER
// LANGUAGE : C++
