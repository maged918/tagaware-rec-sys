//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <cmath>
#include <queue>
#include <cstdio>
#include <set>
#include <map>
#include <cstdlib>
#include <cstring>
#include <stack>
#include <cassert>
#include <sstream>

using namespace std;

typedef unsigned long long ULL;
typedef long long LL;
typedef pair<int,int> pii;
typedef vector<int> vi;
typedef stringstream SS;

#define MIN(a,b) (((a)<(b))?(a):(b))
#define MAX(a,b) (((a)>(b))?(a):(b))
#define ABS(a) MAX(a,-(a))

#define SS(a) scanf("%d",&a)
#define SZ(a) ((int)a.size())
#define PB(a) push_back(a)
#define FOR(i,a,b) for(int i=(a);i<=(b);i++)
#define REP(i,n) FOR(i,0,(int)(n-1))
#define FORD(i,a,b) for(int i=(a);i>=(b);i--)
#define printv(v) REP(i,SZ(v))printf("%d ",v[i]);
#define mp(a,b) make_pair(a,b)
#define MOD 1000000007

void multiply(LL c[52][52],LL _a[52][52],LL _b[52][52],LL n)
{
    LL a[n][n],b[n][n];
    REP(i,n) REP(j,n) a[i][j] = _a[i][j],b[i][j] = _b[i][j];
    REP(i,n) REP(j,n) {
        LL sum = 0;
        REP(k,n) sum = (sum + ((LL)a[i][k]*(LL)b[k][j]))%MOD;
        c[i][j] = sum;
    }
}

int main(){
    LL n;
    int m,k;
    cin>>n>>m;
    LL matrix[52][52];
    REP(i,m) REP(j,m) matrix[i][j] = 1;
    cin>>k;
    REP(i,k){
        string temp;
        cin>>temp;
        int first,second;
        if (temp[0]>='a' && temp[0]<='z'){
            first = temp[0] - 'a';
        } else{
            first = temp[0] - 'A' + 26;
        }
        if (temp[1]>='a' && temp[1]<='z'){
            second = temp[1] - 'a';
        } else{
            second = temp[1] - 'A' + 26;
        }
        matrix[second][first] = 0;
    }
    n--;
    LL res[52][52];
    memset(res,0,sizeof(res));
    REP(i,m) res[i][i] = 1;
    while(n) {
        if (n&1) {
            multiply(res,matrix,res,m);
        }
        multiply(matrix,matrix,matrix,m);
        n >>= 1;
    }
    LL ans = 0;
    REP(i,m){
        REP(j,m){
            ans = (ans + res[i][j])%MOD;
        }
    }
    cout<<ans<<endl;
    return 0;
}
