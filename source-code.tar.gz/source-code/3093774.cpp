//Language: GNU C++


#include <cstdio>
#include <cmath>
#include <vector>
#include <iostream>
#include <algorithm>

#define fi first
#define se second

using namespace std;

typedef  pair<int,int> ii;

const int MAXN = 1e5+5;
const int inf = 1e9+5; 

int N,M;
int dad[MAXN];
int gdad[MAXN];
int dep[MAXN];
int K ; 
vector<int> v[MAXN];
vector<int> way[MAXN];
vector<int> root;
int tim;
int beg[MAXN];
int end[MAXN];
bool visit[MAXN];
int D; 

void rec(int node,int dp){
	//~ printf("node:%d dep:%d\n",node,dp);
	dep[node] = dp;
	D = max(D,dp);	

	visit[node] = true ;

	bool added = false ; 

	beg[node] = ++tim;
	v[dp].push_back(tim);

	for(int i=0;i<way[node].size();i++)	
		if(!visit[way[node][i]]){
			rec(way[node][i],dp+1);
			end[node] = max(end[node],++tim); 
		}

}

void eval(){

	for(int i=1;i<=N;i++){
		
		int node = i ; 
		
		for(int j=1;j<=K;j++)
			node = dad[node];
			
		gdad[i] = node ; 		
	
	}

}

int find(int x,int k){

	int node = x ;
	int h = dep[node]-k;

	if(h<1) return 0;
	
	while(gdad[node] && dep[gdad[node]]>=h) node = gdad[node];

	while(dep[dad[node]]>=h) node = dad[node];
	
	return node;

}

int solve(int node,int k){

	int b = beg[node];
	int e = end[node];
	
	return upper_bound(v[k].begin(),v[k].end(),e)-lower_bound(v[k].begin(),v[k].end(),b);

}

int main(){
	
	cin >> N ; 
	
	K = sqrt(N);
	
	for(int i=1;i<=N;i++){
		scanf(" %d",dad+i);
		if(dad[i]) way[dad[i]].push_back(i);
		else root.push_back(i);
		beg[i] = inf ; 
	}
	
	eval();
	
	for(int i=0;i<root.size();i++)
		rec(root[i],1);
	
	for(int i=1;i<=D;i++)
		sort(v[i].begin(),v[i].end());
		
	cin >> M ; 
	
	while(M--){
	
		int a,b;scanf(" %d %d",&a,&b);
		
		int node = find(a,b);
		printf("%d ",node? solve(node,dep[node]+b)-1 : 0 );
		
	}
	
	puts("");

	return 0;
}
