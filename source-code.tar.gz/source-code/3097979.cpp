//Language: GNU C++


#include <iostream>

using namespace std;

int main()
{
    int n ,k,i,j,num;
    cin >> n >> k;
    if (n<k*3)
        cout << -1 << endl;
    else {
        for (i=1;i<=k;i++)
            cout << i << ' ';
        for (i=1;i<=k;i++)
            cout << i << ' ';
        for (i=2;i<=k;i++)
            cout << i << ' ';
        cout << 1 << ' ';
        for (i=1;i<=n-k*3;i++)
            cout << 1 << ' ';
    }
    return 0;
}
