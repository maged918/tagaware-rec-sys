//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int a[202];

int main() {
    int n, k;
    scanf("%d %d", &n, &k);
    for (int i = 0; i < n; ++i)
        scanf("%d", &a[i]);
    for (int ans = 0; ; ++ans) {
        sort(a, a + n);
        if (a[0] == k) {
            printf("%d\n", ans);
            return 0;
        }
        for (int i = 0; i < n; ++i) {
            int j;
            for (j = i; j < n && a[j] == a[i]; ++j);
            a[i] = min(k, a[i]+1);
            i = j-1;
        }
    }
    return 0;
}
