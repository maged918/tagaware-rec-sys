//Language: MS C++


#include <stdio.h>

int main(){
	int a,b,c,d,e,f;
	scanf("%d", &a);
	d = 0;
	for(b = 0 ; b < a ; b++){
		scanf("%d", &c);
		d += c;
	}
	int p = d % (a+1);
	if(p + 5 > a+1){
		int cnt = 0;
		for(b = 1 ; b <= 5 ; b++){
			if((p+b)%(a+1)!=1)cnt++;
		}
		printf("%d", cnt);
	}
	else
		printf("%d", 5);


	return 0;
}