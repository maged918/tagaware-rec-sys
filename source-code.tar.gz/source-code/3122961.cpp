//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>

using namespace std;

struct coor{
    long long num,no;
};

coor a[200005];
long long n,m,sum=1;

bool cmp(const coor a,const coor b){
    if (a.num!=b.num) return a.num<b.num;
    return a.no<b.no;
}

long long calc(int tot,int same){
    long long re=1;
    if (tot==0) return 1;
    for (int i=tot;i;i--){
        int tmp=i;
        while ((tmp%2==0)&&(same!=0)){
            same--;
            tmp>>=1;
        }
        re*=tmp%m;
        re%=m;
    }
    return re;
}

int main(){
    cin>>n;
    int tmp;
    for (int i=1;i<=2*n;i++){
        scanf("%d",&tmp);
        a[i].num=tmp;
        a[i].no=i<=n?i:i-n;
    }
    cin>>m;
    sort(a+1,a+2*n+1,cmp);
    int prev=-1;
    int prevno=-1;
    int totnum=0;
    int samenum=0;
    for (int i=1;i<=2*n;i++){
        if (a[i].num!=prev){
            sum*=calc(totnum,samenum)%m;
            sum%=m;
            totnum=1;
            samenum=0;
            prev=a[i].num;
            prevno=a[i].no;
        }
        else if (a[i].no==prevno){
            samenum++;
            totnum++;
        }
        else{
            prevno=a[i].no;
            totnum++;
        }
    }
    sum*=calc(totnum,samenum)%m;
    sum%=m;
    cout<<sum<<endl;
    return 0;
}
