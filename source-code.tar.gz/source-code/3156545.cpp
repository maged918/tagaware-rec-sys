//Language: GNU C++


#include <iostream>
#include <vector>

using namespace std;

void toggle(int p[][3],int j, int k){
	p[j][k]=!p[j][k];
	return;
}

int main()
{
	int nf,s=0, nc=0;
	int iter1,iter2;
	int t[3][3],L[3][3];
	for(iter1=0; iter1<3; iter1++ ){
		for(iter2=0; iter2<3; iter2++ ){
			L[iter1][iter2]=1;
		}
	}
	for(iter1=0; iter1<3; iter1++ ){
		for(iter2=0; iter2<3; iter2++ ){
			cin >> t[iter1][iter2] ;
			if ((t[iter1][iter2]%2)!=0) {
				toggle(L,iter1,iter2);
				switch (iter1*3+iter2) {
					case 0:
						toggle(L,0,1);
						toggle(L,1,0);
						break;
					case 1:
						toggle(L,0,0);
						toggle(L,0,2);
						toggle(L,1,1);
						break;
					case 2:
						toggle(L,0,1);
						toggle(L,1,2);
						break;
					case 3:
						toggle(L,0,0);
						toggle(L,1,1);
						toggle(L,2,0);
						break;
					case 4:
						toggle(L,0,1);
						toggle(L,1,0);
						toggle(L,1,2);
						toggle(L,2,1);
						break;
					case 5:
						toggle(L,0,2);
						toggle(L,1,1);
						toggle(L,2,2);
						break;
					case 6:
						toggle(L,1,0);
						toggle(L,2,1);
						break;
					case 7:
						toggle(L,2,0);
						toggle(L,1,1);
						toggle(L,2,2);
						break;
					case 8:
						toggle(L,2,1);
						toggle(L,1,2);
						break;
				}
			}
		}
	}
	for(iter1=0; iter1<3; iter1++ ){
		for(iter2=0; iter2<3; iter2++ ){
			cout << L[iter1][iter2];
		}
		cout << "\n" ;
	}
	
	return 0;
}
