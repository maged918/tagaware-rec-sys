//Language: GNU C++


#include<map>
#include<cmath>
#include<ctime>
#include<vector>
#include<cstdio>
#include<string>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<string.h>
//#include<windows.h>
#include<algorithm>
#define y1 abcde
#define sqr(x) ((x)*(x)) 
#define INF 2000000000
using namespace std;
 
   long long n,i,a[200001],ans,k;      
   map<long long,bool> was;              
 
int main()
{
   //srand(GetTickCount());
   #ifndef ONLINE_JUDGE
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
   #endif

    cin>>n>>k;
    if (k == 1) cout<<n, exit(0);
    for(i = 1; i <= n; i++)
     scanf("%d",&a[i]), was[a[i]] = true;
     
     sort(a+1,a+n+1);
     ans = n;
     for(i = 1; i <= n; i++) 
     {   
             if (was[a[i]] == true && was[a[i]*k] == true) was[a[i]*k] = false, ans--;
     }   
      
       cout<<ans;
      
    return 0;
}
