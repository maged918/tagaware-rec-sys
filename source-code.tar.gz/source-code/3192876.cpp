//Language: GNU C++


#include <stdio.h>
#include <algorithm>
#include <string>
#include <iostream>
#define S(x) scanf("%d",&x)
#define P(x) printf("%d\n",x)
#define rep(i,a) for(int i=0;i<a;i++)
typedef long long int LL;
LL gcd(LL a,LL b) {
	LL c;
	while(1) {
		if(!b) return a;
		c=a%b;
		a=b;
		b=c;
	}
}

using namespace std;
int main() {
	double w;
	LL x,y,x1,y1,n,m,B[55]={0},k;
	int c;
	cin>>n>>w>>m;
	x=1;y=1;c=1;
	rep(i,m) {
		x1=n;y1=m;
		while(x1*y > y1*x) {
			B[c]++;
			c++;
			x1=x1*y-x*y1;
			y1=y1*y;
			k=gcd(x1,y1);
			x1/=k;y1/=k;
			x=1;y=1;
		}
		x=y1*x-x1*y;
		y=y1*y;
		k=gcd(x,y);
		x/=k;y/=k;
		B[c]++;
		if(x==0) {
			x=1;y=1;
			c++;
		}
	}
	for(int i=1;i<=n;i++) if(B[i]>2) {
		//printf("%d %lld\n",i,B[i]);
		printf("NO\n");
		return 0;
	}
	printf("YES\n");
	x=1;y=1;c=1;
	rep(i,m) {
		x1=n;y1=m;
		while(x1*y > y1*x) {
			B[c]++;
			x1=x1*y-x*y1;
			y1=y1*y;
			k=gcd(x1,y1);
			x1/=k;y1/=k;
			printf("%d %lf ",c,((double)x*w)/(double)y);
			c++;
			x=1;y=1;
		}
		x=y1*x-x1*y;
		y=y1*y;
		k=gcd(x,y);
		printf("%d %lf ",c,((double)x1*w)/(double)y1);
		x/=k;y/=k;
		B[c]++;
		//printf("%d %lld %lld\n",c,x,y);
		if(x==0) {
			x=1;y=1;
			c++;
		}
		printf("\n");
	}
	return 0;
}
