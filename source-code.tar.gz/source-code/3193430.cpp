//Language: GNU C++


#define _USE_MATH_DEFINES
#include <cstdio>
#include <iostream>
#include <sstream>
#include <string>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <cstdlib>
#include <queue>
#include <memory.h>
#include <list>

using namespace std;

#define ll long long
#define ld long double

struct rsq{
    int n;
    int *add;
    rsq(){add=NULL;}
    rsq(int n):n(n){
        add=new int[n*4];
        memset(add,0,sizeof(int)*n*4);
    }

    void update(int v, int tl, int tr, int l, int r, int x)
    {
        if(l>r) return;
        if(l==tl  && r==tr)
            add[v]+=x;
        else{
            int tm=(tl+tr)>>1;
            if(l<=tm) update(v<<1,tl,tm,l,min(tm,r),x);
            if(r>tm) update((v<<1)+1,tm+1,tr,max(l,tm+1),r,x);
        }
    }

    int get(int v, int tl, int tr, int pos)
    {
        if(tl==tr && tl==pos) return add[v];
        int tm=(tl+tr)>>1;
        if(pos<=tm)
            return get(v<<1,tl,tm,pos)+add[v];
        else return get((v<<1)+1,tm+1,tr,pos)+add[v];
    }

    void set(int l, int r, int x)
    {
        update(1,1,n,l,r,x);
    }
    int operator [](int pos)
    {
        return get(1,1,n,pos);
    }
};

int chN[110000];
int depth[110000];
int chS[110000];
vector<int> e[110000];

void dfs(int u, int par, int ch, int d=1)
{
    depth[u]=d;
    chN[u]=ch;
    ++chS[ch];
    for(int i=0; i<e[u].size(); ++i)
        if(e[u][i]!=par)
            dfs(e[u][i],u,ch,d+1);
}

int main()
{
    //freopen("input.txt","r",stdin);
    int n,q;
    cin >> n >> q;
    int a,b;
    for(int i=0; i<n-1; ++i)
    {
        cin >> a >> b;
        e[a].push_back(b);
        e[b].push_back(a);
    }
    rsq rs[110000];
    for(int i=0; i<e[1].size(); ++i)
    {
        dfs(e[1][i],1,i);
        rs[i]=rsq(chS[i]);  
    }
    rsq rs1(n);
    int type,v,x,d;
    for(int hod=0; hod<q; ++hod)
    {

        cin >> type;

        if(type==1)
        {
            cin >> v;
            int ans=0;
            if(v==1)
                ans=rs1[1];
            else    
                ans=rs[chN[v]][depth[v]]+rs1[depth[v]+1];
            cout << ans << endl;
            continue;
        }
        cin >> v >> x >> d;
        if(v==1)
            rs1.set(1,d+1,x);
        else{
            if(depth[v]>d)
            {
                rs[chN[v]].set(depth[v]-d,min(chS[chN[v]],depth[v]+d),x);
            }else{
                int to=d-depth[v]+1;
                rs1.set(1,to,x);
                rs[chN[v]].set(to,min(chS[chN[v]],depth[v]+d),x);
            }
        }
    }
}
