//Language: GNU C++


// {{{
#include <algorithm>
#include <iomanip>
#include <assert.h>
#include <cstdio>
#include <stack>
#include <cstdlib>
#include <cctype>
#include <queue>
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include <cstring>
#include <utility>
#include <vector>
#include <map>
#include <numeric>
#include <set>
#include <unistd.h>
#include <bitset>
using namespace std;


#define sz(a) int((a).size())
#define pb push_back
#define all(c) (c).begin(),(c).end()
#define present(c,x) ((c).find(x) != (c).end())
#define rep(i,a,b) for (int i = a; i < b; ++i)
#define tr(c,i)\
      for(typeof((c).begin()) i = (c).begin(); i != (c).end();i++)

#define unq(c) sort(c),(c).resize(unique(all(c))-(c).begin())
#define X first
#define Y second
#define pb push_back
#define mp make_pair


typedef long long LL;
typedef unsigned long long ULL;
typedef long double LD;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
const int INF = 1000000000; const LL INFLL = LL(INF) * LL(INF);

#define i(a) scanf("%d",&a)
#define iull(a) scanf("%llu",&a)
#define pull(a) printf("%llu\n",a)
#define db(a) scanf("%lf",&a)
#define pc(a) putchar(a)
#define pi(a) printf("%d\n",a)
#define pl(a) printf("%I64d\n",a)
#define pu(a) printf("%u\n",a)
#define pd(a) printf("%lf\n",a)
#define ps(a) puts(#a)
#define pts(a) puts(a)
#define MAX 200090
#define EPS 1e-7

// }}}


int A[MAX],idx[MAX];


int main(){


   #ifndef ONLINE_JUDGE
     //freopen("input.txt","r",stdin);
   #endif
   int n,q,l,r;
   i(n);
   i(q);
   rep(i,1,n+1)
       i(A[i]);

   rep(i,0,q){
      i(l);
      i(r);
      idx[l]++;
      idx[r+1]--;
   }
   rep(i,1,n+1)
      idx[i] += idx[i-1];

   sort(idx+1,idx+n+1);
   sort(A+1,A+n+1);
   LL ans = 0;
   rep(i,1,n+1)
      ans += (LL)A[i]*idx[i];
   pl(ans);

 return 0;

}