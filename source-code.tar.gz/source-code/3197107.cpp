//Language: MS C++


#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <functional>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <utility>
#include <stack>
#include <queue>
#include <deque>
#include <bitset>
#include <iomanip>

#define pi 3.1415926535897932
#define abs(x) ((x)>0?(x):-(x))
#define sqr(x) ((x)*(x))
#define fill(m,v) memset(m,v,sizeof(m))
#define SS(x) scanf("%d",&x)
#define SP(x) printf("%d\n",x)

#define inf 0x7fffffff
#define hinf 0x3f3f3f3f
#define fi first
#define se second
#define all(x) x.begin(), x.end()
#define rall(v) v.rbegin(),v.rend()
#define sz(v) ((int)v.size())
#define y0 stupid_cmath
#define y1 very_stupid_cmath
#define ll __int64
#define ull unsigned __int64
#define pb push_back
#define mp make_pair
#define FOR(i,a,b)		for(int i=(a); i<(b);i++)
#define FF(i,a)			for(int i=0; i<(a);i++)
#define FFD(i,a)		for(int i=(a)-1; i>=0;i--)
#define CC(m,what)		memset(m,what,sizeof(m))
#define SZ(a)			((int)a.size())
#define viewPP(a,n,m)	{puts("---");FF(i,n){FF(j,m) cout<<a[i][j] <<' ';puts("");}}
#define viewP(a, n)     {FF(i, n) {cout<<a[i]<<" ";} puts("");}

#define read			freopen("in.txt","r",stdin)
#define write			freopen("out.txt","w",stdout)
const double eps = 1e-11;
int dx[] = {-1, 0, 1, 0};//up Right down Left
int dy[] = {0,  1, 0, -1};

using namespace std;
const int maxn = 100005;
int n;
double ang[maxn];

int main()
{
#ifndef ONLINE_JUDGE
	freopen("in.txt", "r", stdin);
#endif
	while(scanf("%d", &n) == 1) {
		FF(i, n) {
			double x, y;
			scanf("%lf%lf", &x, &y);
			double t = atan2(y, x);
			ang[i] = t;
		}
		sort(ang, ang+n);
		double pre = ang[0], Max = -inf;
		for(int i = 1; i < n; i++) {
			double t = ang[i] - pre;
			if(t > Max)
				Max = t;
			pre = ang[i];
		}
		double tmp = 2*pi - (ang[n-1] - ang[0]);
		if(tmp > Max)
			Max = tmp;
		printf("%.10lf\n", (2*pi - Max) * 180.0 / pi);
	}
    return 0;
}
