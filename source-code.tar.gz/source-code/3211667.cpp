//Language: GNU C++


#include <iostream> 
using namespace std;

long len, map[210], sum, ans, p, q;

void Init() {
	sum = 0;
	for (int i=0; i<len; ++i) {
		cin >> map[i];
		map[i+len] = map[i];
		sum += map[i];
	}
	cin >> p >> q;	
	if (p > q)
		q += len;
}

void Solve() {
	ans = 0;
	for (int i=p-1; i<q-1; ++i)
		ans += (map[i]);
	ans = (sum-ans > ans ? ans : sum-ans);
}

int main(void){
	while (cin >> len) {
		Init();
		Solve();
		cout << ans << endl; 
	} 
	return 0;
}