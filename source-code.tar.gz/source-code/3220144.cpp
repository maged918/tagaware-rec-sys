//Language: GNU C++


#include <set>
#include <deque>
#include <stack>
#include <queue>
#include <cmath>
#include <vector>
#include <memory.h>
#include <stdio.h>
#include <fstream>
#include <string>
#include <iostream>
#include <algorithm>

using namespace std;

#define sc scanf
#define fi first
#define se second
#define pr printf
#define exp 1e-15
#define ll long long
#define mp make_pair
#define pb push_back
#define sqr(x) (x)*(x)
#define N (int)(1e+3)*1
#define mod (int)(1e+9)+9
#define inf (int)INFINITY
#define in(s) freopen(s, "r", stdin);
#define out(s) freopen(s, "w", stdout);

//upper_bound(), lower_bound()
//max_element(), min_element();

    int n, m;

int main(){
    int x, y, dx, i;
    sc("%d%d", &n, &m);

    if(m == 3){
        if(n == 3)
            pr("0 0\n1 0\n0 1");
        if(n == 4)
            pr("0 0\n3 0\n0 3\n1 1");
        if(n > 4)
            pr("-1");
        return 0;
    }

    x = y = (int)1e+8; dx = 1;
    for(i = 1; i <= m; i++){
        cout << x << ' ' << y << "\n";
        x -= dx; y--; dx++;
    }
    x = (int)1e+8; y = -x; dx = 1;
    for(i = m + 1; i <= n; i++){
        cout << x << ' ' << y << "\n";
        x -= dx; y++; dx++;
    }

    return 0;
}
