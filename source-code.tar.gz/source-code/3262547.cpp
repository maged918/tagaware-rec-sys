//Language: GNU C++


#include <iostream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <stdlib.h>
#include <math.h>
#include <iomanip>
using namespace std;

int main() {
    int a, b, c;
    cin >> a >> b >> c;
    int total_tiles = 0;
    int order_tiles = a;
    //first stage(expanding order)
    int borderMin, borderMax;
    if(b < c){
        borderMin = b;
        borderMax = c;
    } else {
        borderMin = c;
        borderMax = b;
    }
    for(int i = 0; i < borderMin; i++){
        total_tiles += order_tiles;
        order_tiles++;
    }order_tiles--;//recover extra +

    //second stage(constant order)
    int remain = borderMax - borderMin;
    for(int i = 0; i < remain; i++){
        total_tiles += order_tiles;
    }

    //ending stage(decreasing order)
    while(order_tiles > a){
        order_tiles--;
        total_tiles += order_tiles;
    }
    cout << total_tiles;
    return 0;
}