//Language: GNU C++0x


#include <iostream>
#include <sstream>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <map>
#include <queue>
using namespace std;

class Indexer {
  int _maxColor;
  int64_t _maxValue, _otherMax;
public:
  Indexer() : _maxColor(0), _maxValue(0), _otherMax(0) { }

  int64_t otherMax(int color) {
    if (_maxColor == color)
      return _otherMax;
    else
      return _maxValue;
  }

  void setMax(int color, int64_t value) {
    if (value < _otherMax)
      return;
    if (_maxColor == color) {
      _maxValue = max(_maxValue, value);
      return;
    }

    if (value > _maxValue) {
      _maxColor = color;
      _otherMax = _maxValue;
      _maxValue = value;
      return;
    }

    if (value > _otherMax)
      _otherMax = value;
  }
};

class ChoosingBalls {
  // dp[c] := the maximal value of a sequence whose last ball's color is c

public:
  vector<int64_t> solve(const vector<int> &values, const vector<int> &colors, const vector<int> &a, const vector<int> &b) {
    vector<int64_t> s(a.size());
    generate(s.begin(), s.end(), Score(values, colors, a, b));
    return s;
  }

  struct Score {
    const vector<int> &_values, &_colors, &_a, &_b;
    int _current;
    Score(const vector<int> &values, const vector<int> &colors, const vector<int> &a, const vector<int> &b) : _values(values), _colors(colors), _a(a), _b(b), _current(0) {
    }
    
    long long operator()() {
      vector<int64_t> dp(_values.size() + 1);
      vector<bool> used(_values.size() + 1);
      Indexer indexer;
      for (size_t i = 0; i < _values.size(); ++i) {
	if (!used[_colors[i]]) {
	  dp[_colors[i]] = int64_t(_values[i]) * _b[_current] + max(0LL, indexer.otherMax(_colors[i]));
	  used[_colors[i]] = true;
	} else {
	  dp[_colors[i]] = max(dp[_colors[i]] + max(0LL, int64_t(_values[i]) * _a[_current]), max(0LL, indexer.otherMax(_colors[i])) + int64_t(_values[i]) * _b[_current]);
	}

	indexer.setMax(_colors[i], dp[_colors[i]]);
      }
      //      cout << endl;
      ++_current;
      return *max_element(dp.begin(), dp.end());
    }
  };

};

  void solve(istream &in, ostream &out) {
    int n, q;
    in >> n >> q;

    vector<int> v(n);
    for (int i = 0; i < n; ++i)
      in >> v[i];

    vector<int> c(n);
    for (int i = 0; i < n; ++i)
      in >> c[i];
    
    vector<int> a(q), b(q);
    for (int i = 0; i < q; ++i)
      in >> a[i] >> b[i];

    ChoosingBalls cb;
    auto ans = cb.solve(v, c, a, b);
    
    for (int i = 0; i < q; ++i)
      out << ans[i] << endl;
  }

int main() {
  solve(cin, cout);
  return 0;
}
