//Language: GNU C++


//IN THE NAME OF GOD :)

// BY ALI MOHAMMADI GHANATGHESTANI SCRC

//PROB NAME :

#include <iostream>
#include <fstream>
#include <set>
#include <vector>
#include <cmath>
#include <string>
#include <queue>
#include <stack>
#include <algorithm>

using namespace std;
typedef vector<int> vin;
typedef vector<string> vst;
typedef vector<pair <int , int> > vpi;
typedef pair<int , int> pin;
typedef set<int> stin;
typedef set<pair <int , int> > stpi;
typedef queue<int> qin;
typedef stack<int> scin;
typedef stack<char> scch;
typedef long long unsigned llu;
typedef long long ll;
typedef vector<ll> vll;
typedef vector<llu> vllu;
typedef pair<ll , ll> pll;
typedef pair<llu , llu> pllu;
typedef vector<pll > vpll;
typedef vector<pllu > vpllu;
typedef set<pll > stpll;
typedef set<pllu > stpllu;
const int MAXn = 1e5 + 96;
#define mn MAXn
// the END of THIS :))
int n , x, y;
string s;
vpi v;

void in_put ()
{
  cin >>n;
  for (int i = 0; i < n; i++)
    {
      int a , b;
      cin >>a>>b;
      v.push_back (make_pair (a , b));
    }
  sort (v.begin () , v.end ());
}

int dif (int a , int b)
{
  int m = a - b;
  if (m < 0)
    m *= -1;
  return m;
}

void out_put ()
{
  for (int i = 0; i < v.size (); i++)
    {
      if (dif (x + v[i].first , y) <= 500)
	{
	  s += 'A';
	  x += v[i].first;
	}
      else
	{
	  s += 'G';
	  y += v[i].second;
	}
    }
  cout <<s<<endl;
}

int main ()
{
  in_put ();
  out_put ();
  return 0;
}
