//Language: GNU C++


#include <iostream>
#include <iomanip>
using namespace std;

int main ()
{
    int n,i;
    cin >> n;
    for (i=0 ; i <= ((n*2)+1)/2 ; i++)
    {
        int j;
        cout << setw(((n*2)+1)-(i*2));
        for ( j=0 ; j <= ((i*2)+1)/2 ; j++ )
        {
            if (j==0)
                cout << j;
            else
                cout << " " << j;
        }

        if(i!=0)
        {
            for (int k=j-2 ; k >=0  ; k-- )
                cout << " " << k;
        }

        cout << endl;
    }

    for (int l=i-2 ; l >= 0 ; l--)
    {
        int j;
        cout << setw(((n*2)+1)-(l*2));
        for ( j=0 ; j <= ((l*2)+1)/2 ; j++ )
        {
            if (j==0)
                cout << j;
            else
                cout << " " << j;
        }

        if(l!=0)
        {
            for (int k=j-2 ; k >=0  ; k-- )
                cout << " " << k;
        }

        cout << endl;
    }
}
