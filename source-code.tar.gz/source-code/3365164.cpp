//Language: GNU C++


#include <cstdio>
#include <cstring>

const int maxn = 200050;

int n;
bool vis[maxn][2];
long long a[maxn], dp[maxn][2];

long long dfs(int t, int flag)
{
	if(t < 1 || t > n)
		return 0;
	else if(dp[t][flag])
		return dp[t][flag];
	else if(vis[t][flag])
		return dp[t][flag] = -1;
	else
	{
		vis[t][flag] = true;
		long long temp = dfs(t+((!flag) ? a[t] : -a[t]), flag^1);
		vis[t][flag] = false;
		dp[t][flag] = (temp == -1) ? -1 : temp + a[t];
		return dp[t][flag];
	}
}

int main()
{
	scanf("%d", &n);
	for(int i = 2; i <= n; i++)
		scanf("%I64d", &a[i]);
	for(int i = 1; i < n; i++)
	{
		a[1] = i;
		dp[1][0] = dp[1][1] = 0;
		printf("%I64d\n", dfs(1, 0));
	}
	return 0;
}