//Language: GNU C++


#include<iostream>
#include<algorithm>
#include<stdlib.h>
using namespace std;
#define M 1<<19
long long a[M],n,sum;

int main()
{
    int i;
    cin>>n;
    for(i=0;i<n;i++)
        cin>>a[i];
    sort(a,a+n);
    for(i=0;i<n;i++)
        sum+=abs(a[i]-i-1);
    cout<<sum<<endl;
    return 0;
}