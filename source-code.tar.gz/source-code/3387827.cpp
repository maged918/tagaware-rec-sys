//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>


using namespace std;


int a[10];

int main()
{
	int i, n;
	scanf("%d", &n);
	for (i = 0; i < n; ++i) scanf("%d", &a[i]);
	if (n == 1)
	{
		if (a[0] != 0) printf("BitLGM\n");
		else printf("BitAryo\n");
	}
	else if (n == 2)
	{
		sort(a, a + n);
		int k, q;
		if (a[0] == 0 && a[1] == 0) {printf("BitAryo\n"); return 0;}
		k = ((double)(a[0] * 2) / (1 + sqrt(5)) + 1);
//		printf("k:%d\n", k);
		if (a[0] + k == a[1]) printf("BitAryo\n");
		else printf("BitLGM\n");
	}
	else
	{
		int k = a[0] ^ a[1] ^ a[2];
		if (k != 0) printf("BitLGM\n");
		else printf("BitAryo\n");

	}
	return 0;
}

 	 				   		   	 	     	  	