//Language: MS C++


/*
    Author: Nikolay Kuznetsov
    Dedicated to my Love, Kristina Dmitrashko
*/
#ifdef NALP_PROJECT
#pragma hdrstop
#else
#define _SECURE_SCL 0
#endif

#define _CRT_SECURE_NO_DEPRECATE
#pragma comment(linker, "/STACK:200000000")

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cctype>
#include <cmath>
#include <algorithm>
#include <utility>

#include <set>
#include <map>
#include <vector>
#include <string>
#include <queue>
#include <bitset>
#include <memory.h>

#include <iostream>
#include <sstream>

using namespace std;

typedef long long int64;

#define forn(i, n) for(int i = 0; i < (int)(n); i++)
#define ford(i, n) for(int i = (int)(n) - 1; i >= 0; i--)
#define pb push_back
#define mp make_pair
#define y1 YYYYYYYYYYYY1
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()

template<typename T> inline T Abs(T x) { return (x >= 0) ? x : -x; }
template<typename T> inline T sqr(T x) { return x * x; }
template<typename T> string toStr(T x) { stringstream st; st << x; string s; st >> s; return s; }

inline int nextInt() { int x; if (scanf("%d", &x) != 1) throw; return x; }
inline int64 nextInt64() { int64 x; if (scanf("%I64d", &x) != 1) throw; return x; }
inline double nextDouble() { double x; if (scanf("%lf", &x) != 1) throw; return x; }

const int INF = (int)1E9;
const int64 INF64 = (int64)1E18;
const long double EPS = 1E-9;
const long double PI = 3.1415926535897932384626433832795;

const int MAXN = 100100;

inline bool intersect(const pair<int, int> &a, const pair<int, int> &b) {
	return max(a.first, b.first) <= min(a.second, b.second);
}

int getFirst(const map<int, vector<pair<int, int> > > &m) {
	for(int i = 1; i < INF; i++)
		if (!m.count(i))
			return i;

	return -1;
}

map<int, vector<pair<int, int> > > mx, my;
int n, m, k, F, S;

int gran(vector<pair<int, int> > &a, int n, int len = 0) {
	sort(all(a));
	vector<pair<int, int> > t(1, a[0]);
	forn(i, a.size())
		if (intersect(t.back(), a[i]))
			t.back().second = max(t.back().second, a[i].second);
		else
			t.pb(a[i]);

	S = F = -1;
	int ans = t[0].first + (n - t.back().second);
	forn(i, t.size() - 1) {
		int cur = t[i + 1].first - t[i].second;
		ans += cur;
	}

	if (ans >= len) {
		F = 0;
		int tmp = min(len, t[0].first);
		if (tmp > 0) {
			len -= tmp;
			S = tmp;
		}

		forn(i, t.size() - 1) {
			int cur = t[i + 1].first - t[i].second, tmp = min(len, cur);
			if (tmp > 0) {
				len -= tmp;
				S = tmp + t[i].second;
			}
		}

		tmp = min(len, n - t.back().second);
		if (tmp > 0) {
			len -= tmp;
			S = tmp + t.back().second;
		}
	}

	return ans;
}

int main() {
#ifdef NALP_PROJECT
	freopen("input.txt", "rt", stdin);
//	freopen("output.txt", "wt", stdout);
#else
#endif

	n = nextInt();
	m = nextInt();
	k = nextInt();
	forn(i, k) {
		int x1 = nextInt();
		int y1 = nextInt();
		int x2 = nextInt();
		int y2 = nextInt();

		if (x1 > x2) swap(x1, x2);
		if (y1 > y2) swap(y1, y2);

		if (x1 == x2) my[x1].pb(mp(y1, y2));
		if (y1 == y2) mx[y1].pb(mp(x1, x2));
	}

	int g = 0;

	g ^= n * ((m - (int)mx.size() - 1) % 2);
	for(map<int, vector<pair<int, int> > >::iterator i = mx.begin(); i != mx.end(); i++)
		g ^= gran(i->second, n);

	g ^= m * ((n - (int)my.size() - 1) % 2);
	for(map<int, vector<pair<int, int> > >::iterator i = my.begin(); i != my.end(); i++)
		g ^= gran(i->second, m);

	if (g > 0) {
		if ((int)mx.size() != m - 1) {
			int ng = g ^ n;
			if (n > ng) {
				int y = getFirst(mx);
				cout << "FIRST" << endl;
				cout << 0 << " " << y << " " << n - ng << " " << y << endl;
				return 0;
			}
		}

		if ((int)my.size() != n - 1) {
			int ng = g ^ m;
			if (m > ng) {
				int x = getFirst(my);
				cout << "FIRST" << endl;
				cout << x << " " << 0 << " " << x << " " << m - ng << endl;
				return 0;
			}
		}

		for(map<int, vector<pair<int, int> > >::iterator i = mx.begin(); i != mx.end(); i++) {
			int t = gran(i->second, n, g);
			int ng = t ^ g;
			if (t < ng) continue;
			gran(i->second, n, t - ng);
			if (F != -1) {
				cout << "FIRST" << endl;
				cout << F << " " << i->first << " " << S << " " << i->first << endl;
				return 0;
			}
		}

		for(map<int, vector<pair<int, int> > >::iterator i = my.begin(); i != my.end(); i++) {
			int t = gran(i->second, m, g);
			int ng = t ^ g;
			if (t < ng) continue;
			gran(i->second, m, t - ng);
			if (F != -1) {
				cout << "FIRST" << endl;
				cout << i->first << " " << F << " " << i->first << " " << S << endl;
				return 0;
			}
		}
	}

	cout << "SECOND" << endl;

	return 0;
}
