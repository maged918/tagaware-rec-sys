//Language: GNU C++


#include<stdio.h>
#include<iostream>
using namespace std;
#include<algorithm>
	int n,m,a[10000];
int main()
{
while(cin>>n>>m)
{
	for(int i=0;i<n;i++)
	cin>>a[i];
	sort(a,a+n);
	int sum=0;
	for(int i=0;i<m&&a[i]<0;i++)
	sum+=a[i];
	cout<<-sum<<endl;
}

return 0;
}
  	 		 				      	 				  	