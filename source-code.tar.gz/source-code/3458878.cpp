//Language: GNU C++


/* Problem  : C. Polo the Penguin and Strings
** Time     : 15ms
** Algorithm: string
**/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
#define st first
#define nd second
#define read(x) scanf("%d",&x)
typedef long long int64;

int main (int argc, char const* argv[]){
    if ( argc == 3 ){
        freopen(argv[1],"r",stdin);
        freopen(argv[2],"w",stdout);
    }
    int n, k;read(n), read(k);
    if ( n < k || (k==1&&n>1) ){
        puts("-1");
    }else{
        if ( n == 1 ){
            puts("a");
            return 0;
        }
        for(int i = 0 ; i < n + 2 - k ; ++i){
            putchar(i%2+'a');
        }
        for(int i = 2 ; i < k ; ++i){
            putchar(i+'a');
        }
        putchar('\n');
    }
    return 0;
}

/* DOAN Minh Quy - mquy.doan@gmail.com */