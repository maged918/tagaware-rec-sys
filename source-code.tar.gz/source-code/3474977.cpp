//Language: GNU C++


#include <cstring>
#include <string.h>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <iostream>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <vector>
#include <set>
#include <complex>
#include <list>
#include <iomanip>
#include <stdio.h>

#define rep(i,m) for(unsigned int i = 0;i < m ;i++)
#define rep2(i,n,m) for(unsigned int i = n; i < m ;i++)
#define ui unsigned int
#define pb push_back

using namespace std;


int main() {
    ui n, k, a;
    vector<ui> dat;
    scanf("%d %d", &n, &k);
    rep(i, n){
        scanf("%d", &a);
        dat.pb(a);
    }
    sort(dat.begin(), dat.end());
    if(k <= n){
        rep(i, k)
            printf("1 %d\n", dat[i]);
        return 0;
    }
    
    ui amount = 1, acc = 0, nt = n;
    while(k > 0){
        rep(i, min(k, n)){
            printf("%d %d", amount, dat[i]);
            rep(j, acc){
                printf(" %d", dat[nt - 1 - j]);
            }
            printf("\n");
        }
        k -= min(k, n);
        acc ++;
        n--;
        amount++;
    }
    return 0;
}
