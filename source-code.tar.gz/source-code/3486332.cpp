//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>

#define fi first
#define se second
#define pb push_back
#define sz(a) (int)a.size()
#define Abs(a) ( (a)<0 ? ((a)*-1) : (a) )

using namespace std;

typedef long long Lint;
typedef pair<int,int> ii;

const int MAXN = 105;

int n,t1,t2,res=1e9;
int ar[MAXN];
int ar2[MAXN];

int main()
{
	cin >> n;
	for( int i=0,a,b ; i<n ; i++ ){
		scanf(" %d %d",&a,&b);
		if( a==1 )
			ar[++t1]=b;
		else
			ar2[++t2]=b;
	}
	
	sort( ar+1, ar+t1+1 );
	sort( ar2+1, ar2+t2+1 );
	
	//~ for( int i=1 ; i<=n ; i++ )
		//~ cout << ar[i].fi << ' ' << ar[i].se << endl;
	
	for( int i=1 ; i<=n ; i++ )
		for( int j=0 ; j<=i && j<=t1 ; j++ ){
			if( i-j > t2 )	continue;
			int d=0,u=0,l=i-j;
			d = j+(i-j)*2;
			for( int k=1 ; k<=t1-j ; k++ )
				u+=ar[k];
			for( int k=1 ; k<=t2-l ; k++ )
				u+=ar2[k];
			if( u<=d )
				res = min( res, d );
		}
	
	cout << res << endl;
	
	return 0;
}
