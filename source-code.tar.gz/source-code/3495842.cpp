//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#define INF 100
using namespace std;
#define N (1<<23)
int dp[2][N],pre[25][25],a[25],bit[N];
int main()
{
     //freopen("c.in","r",stdin);
     int i,j,k,n,now,next;
     while(scanf("%d",&n)==1)
     {
         for(i=0;i<n;i++)scanf("%d",a+i);
         memset(pre,-1,sizeof(pre));
         memset(dp,0,sizeof(dp));
         for(i=1;i<n;i++)
	     for(j=0;j<i;j++)
	       for(k=j;k<i;k++)
		    if(a[j]+a[k]==a[i])
			 pre[i][j]=k;
         dp[0][1]=1;next=now=0;
         for(i=1;i<n;i++)
         {
             now=(i-1)&1,next=i&1;
             memset(dp[next],0,sizeof(dp[next]));
             for(j=1;j<(1<<i);j++)
             {
                if(!dp[now][j])continue;
                int flag=0;
                for(k=0;k<i;k++)
                if(j&(1<<k)&&pre[i][k]!=-1&&j&(1<<(pre[i][k])))
                {
                 flag=1;break;
                }
                if(!flag)continue;
                for(k=0;k<i;k++)
                if(j&(1<<k))
                dp[next][j^(1<<k)|(1<<i)]=1;
                dp[next][j|(1<<i)]=1;
             }
         }

     int maxn,ans=INF;
     maxn=(1<<n);
     bit[0]=0;
     for(i=1;i<maxn;i++)
     bit[i]=bit[i-(i&(-i))]+1;
     for(i=0;i<maxn;i++)
     if(dp[next][i])
     {
         if(ans>bit[i])
         ans=bit[i];
     }
     if(ans!=INF)printf("%d\n",ans);
     else printf("%d\n",-1);
     }
     return 0;
}

 								  		 			   		   	