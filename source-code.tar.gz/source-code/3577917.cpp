//Language: GNU C++


#include <iostream>
#include <string>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <utility>
#include <algorithm>
#include <set>
#include <queue>
#include <stack>
#include <vector>
#include <map>
#include <list>

#define FORST(X,S,T) for(int X=S; X<=T; X++)  
#define RFORST(X,S,T) for(int X=S; X>=T; X--)  
#define FOR(X,XB) for(int X=0; X<XB; X++)
#define RFOR(X,XB) for(int X=(XB)-1; X>=0; X--)
#define FORSTL(X,C) for(X=C.begin();X!=C.end();X++)
#define SQR(X) ((X)*(X))
#define MID(X,Y) (((X)+(Y))/2)
#define FILL(X,V) memset(X,V,sizeof(X))
#define FILE_R(X) freopen(X, "r", stdin)  
#define FILE_W(X) freopen(X, "w", stdout)  
#define ERREQ(X,Y) (fabs((X)-(Y))<EPS)
#define DBGL cout << "here" << endl;
#define MIN(X,Y) ((X)<(Y)?(X):(Y))
#define MAX(X,Y) ((X)>(Y)?(X):(Y))
#define SZ(X) sizeof(X)
const double PI = acos(-1.0);
const double EPS = 1E-9;
const int INF = (int)1E9;
using namespace std;

#define MAXN 100005

int cmp(const void *a, const void *b){
	int *pa = (int *)a, *pb = (int *)b;
	return pa[0] - pb[0];
}
int N, M;
int s[MAXN][2], s1[MAXN], s2[MAXN];
set<int> set1, set2;

int main(){
	/*
	freopen("input", "w", stdout);
	cout << 100000 << endl;
	FOR(i, 100000) printf("%d ", i);
	*/

	cin >> N;
	M = N/3;
	if(N%3) M++;
	FOR(i, N){
		scanf("%d", &s[i][0]);	
		s[i][1] = i;
	}
	qsort(s, N, sizeof(s[0]), cmp);

	bool suc = 1;
	int a,b;
	int min2 = INF;
	int t;
	FOR(i, M){
		t = s[i][1];
		a = i;
		b = s[i][0] - a;
		s1[t] = a;
		s2[t] = b;
	}
	FOR(i, M){
		if(i+M>=N) break;
		t = s[i+M][1];
		a = M+i;
		b = s[i+M][0] - a;
		s1[t] = b;
		s2[t] = a;
		min2 = MIN(a, min2);
	}
	min2 --;
	FOR(i, N-2*M){
		if(i+2*M>=N) break;
		t = s[i+2*M][1];
		if(min2<0){
			cout << "NO" << endl;
			return 0;
		}
		b = min2--;
		a = s[i+2*M][0] - b;
		s1[t] = a;
		s2[t] = b;
	}
	cout << "YES" << endl;
	FOR(i, N) printf("%d ", s1[i]);
	cout << endl;
	FOR(i, N) printf("%d ", s2[i]);
	cout << endl;
	return 0;

}