//Language: GNU C++


#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
    int n;
    cin >> n;
    pair <int, int> s[n];
    int a[n], b[n];

    for (int i = 0; i < n; i++)
    {
        int x;
        cin >> x;
        s[i] = make_pair(x, i);
    }
    sort(s, s + n);

    for (int i = 0; i < n / 3; i++)
        a[s[i].second] = 0, b[s[i].second] = s[i].first;

    for (int i = n / 3; i < 2 * n / 3; i++)
        a[s[i].second] = i, b[s[i].second] = s[i].first - i;

    for (int i = 2 * n / 3; i < n; i++)
        a[s[i].second] = n - i - 1, b[s[i].second] = s[i].first - (n - i - 1);
    cout << "YES" << endl;

    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
    cout << endl;
    
    for (int i = 0; i < n; i++)
        cout << b[i] << " ";
    cout << endl;
}
