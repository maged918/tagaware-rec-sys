//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <vector>
#include <map>
#include <set>
#include <cmath>
#include <string>
#include <bitset>
#include <cstdio>
#include <ctime>
#include <stack>
#include <queue>
#include <deque>
#include <fstream>
#include <cstdlib>
#include <cctype>

using namespace std;

int i,j,x,y,n,nn,kol,k;

bool found;

int a[111][111];

int main()
{
    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);

    cin >> n;
    x=n;
    y=n;

    nn=n*2+1;

    for (i=0;i<nn*2;i++)
        for (j=0;j<nn*2;j++)
            a[i][j]=n-(abs(i-x)+abs(j-x));

    for (i=0;i<nn;i++){
        found = false;
        kol=0;
        for (j=0;j<nn;j++)
           if (a[i][j]<0 && found) break;
           else if (a[i][j]<0) kol++;
           else {
                if (!found){
                found = true;
                for (k=0;k<kol*2;k++)
                    cout << ' ';
                }
                cout << a[i][j];
                if (a[i][j+1]>=0) cout << ' ';
           }

        cout << '\n';
    }

    return 0;
}
