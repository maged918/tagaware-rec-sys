//Language: GNU C++


#include <iostream>
#include <string>

using namespace std;

int main()
{
    int m=0,n=1;
    string str;
    cin >> str;
    m = str[0];
    for (int i = 1;i < str.size();i++)
    {
        if (str[i] == m) n++;
        else
        {
            m = str[i];
            n = 1;
        }
        if(n >= 7)
            break;
    }
    if(n >= 7)
        cout << "YES";
    else
        cout << "NO";
    return 0;
}
