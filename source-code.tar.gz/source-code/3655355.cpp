//Language: GNU C++


#include<stdio.h>
#include<math.h>
int main()
{
	__int64 p,k,ans,a,b,c,n;
	__int64 x,y,i,j,q;
	scanf("%I64d",&n);
	if(n%3) 
	{
		printf("0\n");
		return 0;
	}
	n=n/3;	x=1;  ans=0;
	while((x+1)*(x+1)*(x+1)<=n)
		x++;	
	for(i=2;i<=x;i++)
	{
		if(n%i) continue;
		y=sqrt(n/i);q=sqrt(n/i)-i/2;
			for(j=i>q?i:q;j<=y;j++)
		{
			k=n/i/j;
			if(k<j) break;
			if(n/i%j) continue;			
			if((i+j+k)%2)continue;
			p=(i+j+k)/2;
			a=p-i;	b=p-j;	c=p-k;
			if(a<1||b<1||c<1) continue;
			if(a==b&&b==c)			ans++;
			else if(a==b||b==c)		ans+=3;
			else					ans+=6;
		}
	}
	printf("%I64d\n",ans);
	return 0;
}
								   	  	   		 			 	