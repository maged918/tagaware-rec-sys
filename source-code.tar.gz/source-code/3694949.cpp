//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <queue>
#include <map>
#include <string.h>
#include <vector>
#include <set>

const int N=200010;
const int inf=0x3f3f3f3f;

using namespace std;

#define pb push_back
#define sz(x) ((x).size())

int main(){
	cout << "??0>>0??" << endl;
	cout << "??1>>1??" << endl;
	cout << "??2>>2??" << endl;
	cout << "??3>>3??" << endl;
	cout << "??4>>4??" << endl;
	cout << "??5>>5??" << endl;
	cout << "??6>>6??" << endl;
	cout << "??7>>7??" << endl;
	cout << "??8>>8??" << endl;
	cout << "??9>>9??" << endl;
	cout << "??>>?" << endl;
	cout << "0?<>1" << endl;
	cout << "1?<>2" << endl;
	cout << "2?<>3" << endl;
	cout << "3?<>4" << endl;
	cout << "4?<>5" << endl;
	cout << "5?<>6" << endl;
	cout << "6?<>7" << endl;
	cout << "7?<>8" << endl;
	cout << "8?<>9" << endl;
	cout << "9?>>?0" << endl;
	cout << "?<>1" << endl;
	cout << "1>>1??" << endl;
	cout << "2>>2??" << endl;
	cout << "3>>3??" << endl;
	cout << "4>>4??" << endl;
	cout << "5>>5??" << endl;
	cout << "6>>6??" << endl;
	cout << "7>>7??" << endl;
	cout << "8>>8??" << endl;
	cout << "9>>9??" << endl;
	cout << "0>>0??" << endl;
	return 0;
}
