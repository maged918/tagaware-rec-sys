//Language: GNU C++


#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<algorithm>
#include<vector>
using namespace std;
#define N 100005

typedef long long ll;
int a[N],b[N],c[N];
int n;
int main(){
	while(cin>>n){
		if(n%2==0){
			cout<<-1<<endl;continue;
		}
		if(n==1){
			cout<<0<<endl;
			cout<<0<<endl;
			cout<<0<<endl;
			continue;
		}
		for(int i=0;i<n;i++)a[i] = i;
		b[0] = n-1;
		for(int i=1;i<(n+1)/2;i++) b[i] = b[i-1] - 2;
		b[(n+1)/2] = n-2;
		for(int i=(n+1)/2+1;i<n;i++) b[i] = b[i-1] -2;
		for(int i=0;i<n;i++)c[i] = (a[i]+b[i])%n;
		for(int i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
		for(int i=0;i<n;i++)cout<<b[i]<<" ";cout<<endl;
		for(int i=0;i<n;i++)cout<<c[i]<<" ";cout<<endl;
		
	}
	return 0;
}
