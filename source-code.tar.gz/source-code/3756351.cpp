//Language: GNU C++


#include<iostream>
#include<vector>
using namespace std;
typedef long long lld;
int br=0;
int euler(lld a[],lld p,lld q,int pos)
{
    if(q==0)return pos-1;
    a[pos]=p/q;
    if(q==1&&br==0)
    {
        return pos;
    }else if(q==1&&br==1){
        if(p!=1)
        {
            a[pos]=p-1;
            a[pos+1]=1;
            return pos+1;
        }else{
            a[pos]=1;

            return pos;
        }
    }
    return euler(a,q,p%q,pos+1);
}
int main()
{
    lld n,a[1000],p,q,d[1000];
    cin>>p>>q>>n;
    for(int i=0;i<n;i++)
    cin>>a[i];
    if(a[n-1]==1)br=1;
    if(euler(d,p,q,0)!=n-1)cout<<"NO";
    else
    {
        int wr=0;
        for(int i=0;i<n;i++)
        {
            if(a[i]!=d[i]){
                wr=1;
                break;
            }
        }
        if(wr==0)cout<<"YES";
        else cout<<"NO";
    }
    return 0;
}
