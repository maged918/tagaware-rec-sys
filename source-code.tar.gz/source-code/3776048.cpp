//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<vector>
#include<stack>
#include<utility>
#include<string>
#define pb push_back
using namespace std;
typedef long long LL;
typedef double db;
int n,k;
int main(){
	scanf("%d%d",&n,&k);
	if(n*(n-1)/2<=k) printf("no solution\n");
	else{
		int y=-1000000000;
		for(int i=1;i<=n;++i){
			printf("%d %d\n",i,y);
			y+=2013;
		}
	}
	return 0;
}
