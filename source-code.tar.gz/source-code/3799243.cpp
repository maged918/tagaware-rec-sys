//Language: GNU C++0x


#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

long long dp[305][305],at[305][305];
int x[100005],y[100005],c[100005];

int main(){
    int n,m,t;
    scanf("%d%d%d",&n,&m,&t);
    memset(dp,63,sizeof(dp));
    memset(at,63,sizeof(at));
    dp[0][0]=0;
    long long ans=1ll<<61;
    for(int i=0;i<m;i++){
        scanf("%d%d%d",x+i,y+i,c+i);
        x[i]--,y[i]--;
        at[x[i]][y[i]]=min(at[x[i]][y[i]],c[i]+0ll);
    }
    for(int i=0;i<n;i++) for(int j=1;j<=i;j++)
        at[j][i]=min(at[j-1][i],at[j][i]);
    for(int i=1;i<=n;i++) for(int j=0;j<=i;j++){
        if(j) dp[i][j]=min(dp[i][j],dp[i-1][j-1]);
        for(int k=i-1;~k;k--)
            dp[i][j]=min(dp[i][j],dp[k][j]+at[k][i-1]);
        if(i-j>=t) ans=min(ans,dp[i][j]);
    }
    if(ans>=305*1000000000ll) puts("-1"); else printf("%I64d\n",ans);
}
