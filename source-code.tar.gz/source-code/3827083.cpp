//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <string>
#include <cstring>

using namespace std;

string in(string s){
    string mm;
    for(int i=0;i<s.size();i++){
     string ll;
     while(s[i]!=':'&&i<s.size())
      ll+=s[i++];
     while(ll.size()<4)
      ll="0"+ll;
     if(i<s.size()-1)
      ll+=":";
     mm+=ll;
    }
    return mm;
}


int main(){
int tt;
scanf("%d\n",&tt);
string ss,tmp;

while(tt--){
cin>>ss;
bool full=true;
int index=0;
for(int i=0;i<ss.size()-1;i++)
 if(ss[i]==':'&&ss[i+1]==':'){
    index=i+1;
    full=false;
    break;
}
if(full){
   string ans=in(ss);
   cout<<ans;
}
else{
  if(index==ss.size()-1&&ss.size()>2){ // A::
    string aa1=ss.substr(0,ss.size()-2);
    string aa2=in(aa1);
    int oo=0;
    if(aa2.size()<24)
      oo=aa2.size()/4;
    else
      oo=aa2.size()/4-1;
  //  cout<<oo<<endl;
    string ans=aa2;
    for(int i=0;i<8-oo;i++)
     ans+=":0000";
    cout<<ans;
  }
  else if(index==ss.size()-1&&ss.size()==2){ // ::
   cout<<"0000:0000:0000:0000:0000:0000:0000:0000";
  }
  else if(index==1&&ss.size()>2){ // ::A
    string aa1=ss.substr(2,ss.size()-2);
    string aa2=in(aa1);
    int oo=0;
    if(aa2.size()<24)
      oo=aa2.size()/4;
    else
      oo=aa2.size()/4-1;
    string ans=aa2;
    for(int i=0;i<8-oo;i++)
     ans="0000:"+ans;
    cout<<ans;
  }
  else if(index!=1&&ss.size()>2){ //A::B
   string aa1,aa2;
   for(int i=0;i<=index-2;i++)
     aa1+=ss[i];
   for(int i=index+1;i<ss.size();i++)
     aa2+=ss[i];
   int oo1=0,oo2=0;
   aa1=in(aa1);
   aa2=in(aa2);
    if(aa1.size()<24)
      oo1=aa1.size()/4;
    else
      oo1=aa1.size()/4-1;
    if(aa2.size()<24)
      oo2=aa2.size()/4;
    else
      oo2=aa2.size()/4-1;
   int pp=8-oo1-oo2;
   string ans=aa1;
   for(int i=0;i<pp;i++)
    ans+=":0000";
   ans+=":"+aa2;
   cout<<ans;
   }
}
puts("");
}
return 0;
}
