//Language: GNU C++


#include <iostream>
#include <fstream>
#include <string.h>
#include <iomanip>
#include <math.h>
#include <algorithm>

using namespace std;

ifstream fin ("input.txt");
ofstream fout ("output.txt");

int main()
{
    int n, m;
    cin >> n >> m;
    string s;
    pair <int, int> b[111];
    for (int i = 0 ; i < n; i++){
        cin >> s >> b[i].second;
        if ( s[0] == 'D' ) b[i].first = 1;
        else b[i].first = 0;
    }
    sort ( b, b+n );

    int a[m];
    for (int i = 0 ; i < m; i++) cin >> a[i];
    sort ( a, a + m );

    bool used [111];
    int answer = 0 ;
    for (int i = 0 ; i < n; i++){
        memset ( used, false, sizeof ( used ));
        int temp = 0 ;
        bool ok = true;
        for (int j = 0; j <= i && ok ; j++ ) if ( b[j].first ) {
            int t = -1;
            for (int k = 0 ; k < m; k++)  if ( !used[k] && a[k] > b[j].second ) { t = k; break; }
            if ( t < 0 ) ok = false;
            else used [t] = true;
        }
        for (int j = i; j >=0 && ok ; j--) if ( b[j].first == 0 ){
            int t = -1;
            for (int k = m-1; k >=0; k-- ) if ( !used[k] && a[k] >= b[j].second ) { t=k; break; }
            if ( t < 0 ) ok = false;
            else {
                used [t] = true;
                temp += a[t] - b[j].second;
            }
        }
        if ( !ok ) continue;
        if ( i == n -1 ){
            for (int ii = 0 ; ii < m ; ii++ )
                if ( !used [ii] ) temp += a[ii];
        }
        if ( temp > answer ) answer = temp;

    }


    cout << answer;
    return 0;
}
