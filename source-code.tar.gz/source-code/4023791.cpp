//Language: GNU C++


#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <cctype>
#include <queue>
#include <stack>
#include <set>
//#include <alloc.h>
using namespace std;
            
int x[10000000];            
int main()
{
    int n,i,j,ans=0,zeros,ones=0;       
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&x[i]);
        if(x[i])
            ones++;
    }   
    for(i=0;i<n;i++)
    {
        zeros = 0;
        for(j=i;j<n;j++)
        {
            if(x[j])
                zeros--;
            else 
                zeros ++;   
            ans = max(ans , zeros + ones ); 
        }
    }           
    printf("%d\n",ans);     
            
            
    return 0;
}