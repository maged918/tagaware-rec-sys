//Language: GNU C++


#include"stdio.h"
#include"string.h"
#include"algorithm"
#include"math.h"
using namespace std;
int a[600];
int main()
{
        int i,n;
        int ans;
        int mj,mi;
        int x;
        int find;
        int f=0;
        int k;
        int ml,mr;
        find=0;
        scanf("%d%d",&n,&x);
        for(i=0;i<n;i++)
                {scanf("%d",&a[i]);
                if(a[i]==x) find=1;

                }
        sort(a,a+n);
        //for(i=0;i<n;i++)
       // printf("%d ",a[i]);
        //printf("\n");
        if(find==0&&a[n-1]<x)
                printf("%d",n+1);
        else if(find==0&&a[0]>x)
                printf("%d",n);
        else if(find==0)
        {
                for(i=0;i<n;i++)
                {
                        if(a[i]>x)
                        {
                                k=i;
                                break;
                        }
                }
                if(k==n/2) printf("1");
                if(k>n/2) printf("%d",2*k-n+1);
                if(k<n/2) printf("%d",1+n-k-k-1);
        }
        else
                {
                        ml=600;mr=600;
                        mi=mj=(n+1)/2+1;
                        for(i=(n+1)/2-1;i<n;i++)
                        {
                                if(a[i]==x)
                                {
                                        mr=i-(n+1)/2+1;
                                        mi=i;
                                        break;
                                }
                        }
                        for(i=(n+1)/2-1;i>=0;i--)
                        {
                                if(a[i]==x)
                                {
                                        ml=(n+1)/2-i-1;
                                        mj=i;
                                        break;
                                }

                        }//printf("mj=%d mi=%d\n",mj,mi);
                        //printf("mr=%d ml=%d\n",mr,ml);
                        if(mr<ml) {mj=mi;f=1;};
                        if(n==1)
                        {
                                //if()
                                ans=0;
                        }
                        else
                        {
                                 ans=n-1-mj;
                                // printf("%d\n",ans);
                        ans=abs(ans-(mj+1));
                        //printf("%d\n",ans);
                        }
//printf("f=%d\n",f);
if(a[(n+1)/2-1]==x) printf("0");
else
                        printf("%d",ans-f);
                }
        return 0;
}

			 		   	 		  		 	    	