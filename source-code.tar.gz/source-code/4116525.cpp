//Language: GNU C++0x


#include <bits/stdc++.h>

using namespace std;
typedef long long LL;
typedef unsigned long long ULL;
const int SIZE = 110;
char mas [SIZE][SIZE];

int main ()
{
    ios_base :: sync_with_stdio(0);
    //ifstream cin ("/home/misha/in2");
    int n;
    cin >> n;
    for (int i=1; i<=n ;++i)
        for (int j=1; j<=n; ++j)
            cin >> mas [i][j];
    bool clr = false, clc = false, temp;
    for (int i=1; i<=n ;++i)
    {
        temp = false;
        for (int j=1; j<=n; ++j)
            if (mas [i][j] == '.')
                temp = true;
        if (!temp) {clr = true; break;}
    }
    for (int i=1; i<=n ;++i)
    {
        temp = false;
        for (int j=1; j<=n; ++j)
            if (mas [j][i] == '.')
                temp = true;
        if (!temp) {clc = true; break;}
    }
    if (clc && clr) cout << -1 << endl;
    else if (clr) {
        for (int i=1;i<=n;++i)
            for (int j=1; j<=n; ++j)
                if (mas[j][i]=='.') {cout << j << " " << i << endl; break;}}
    else {
        for (int i=1;i<=n;++i)
            for (int j=1; j<=n; ++j)
                if (mas[i][j]=='.') {cout << i << " " << j << endl; break;}}
    return 0;
}
