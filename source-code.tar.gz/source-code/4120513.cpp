//Language: GNU C++0x


#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
const int maxn=1005;
char map[maxn][maxn];
int n,m;
int Div[5][3]={{1,0},{0,1},{-1,0},{0,-1} };
struct PP
{
	int x,y,step;
};
bool mark[maxn][maxn];
int bfs(int sx,int sy)
{
	int i,j,ans=0,st=100000005;
	queue<PP> Q;
	while(!Q.empty()) Q.pop();
	PP s;
	s.x=sx; s.y=sy; s.step=0;
	Q.push(s);
	memset(mark,false,sizeof(mark));
	mark[sx][sy]=true;
	while(!Q.empty())
	{
		s=Q.front();
		Q.pop();
		if(s.step>st){ 
			//printf("%d %d\n",st,s.step);
			return ans;
		}
		int temp=map[s.x][s.y]-'0';
		if(temp>=1&&temp<=9)
			ans+=temp;
		if(map[s.x][s.y]=='S') st=s.step;
		for(i=0;i<4;i++)
		{
			PP t;
			t.x=s.x+Div[i][0];
			t.y=s.y+Div[i][1];
			t.step=s.step+1;
			if(t.x<0||t.y<0||t.x>=n||t.y>=m||map[t.x][t.y]=='T'||mark[t.x][t.y])
				continue;
			
			mark[t.x][t.y]=1;
			Q.push(t);
		}
	}
	return ans;
}
int main()
{
	int i,j,sx,sy;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%s",map[i]);
		for(j=0;j<m;j++)
			if(map[i][j]=='E')
			{
				sx=i; sy=j;
			}
	}
	int ans=bfs(sx,sy);
	printf("%d\n",ans);
	return 0;
}
