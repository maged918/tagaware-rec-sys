//Language: MS C++


#include <iostream>
#include <set>
#include <vector>
using namespace std;
int n,m;
set<pair<int,int> > used;
int edges[100000];
bool found=false;
void solve(int x, int y, int mc){
	if(used.find(pair<int,int>(x+1,y+1)) == used.end() && edges[x]<2 && edges[y]<2){
		edges[x]++;
		edges[y]++;
		if(mc+1==m || found){
			found=true;}else{
		if(y<n-1 && edges[x]<2){
		solve(x,y+1,mc+1);
	}else if(x<n-2){
		solve(x+1,x+2,mc+1);}}
		if(found){
			cout<<x+1<<" "<<y+1<<endl;
		}
		edges[x]--;
		edges[y]--;
	}
	if(!found){
	if(y<n-1 && edges[x]<2){
		solve(x,y+1,mc);
	}else if(x<n-2){
		solve(x+1,x+2,mc);}}
}
int main(){
	cin>>n>>m;
	pair<int,int> temp;
	for(int x=0;x<m;x++){
		cin>>temp.first>>temp.second;
		if(temp.first>temp.second){
			swap(temp.first,temp.second);}
			used.insert(temp);
		
	}
	for(int x=0;x<n;x++){
		edges[x]=0;
	}
			solve(0,1,0);
		if(!found){
			cout<<-1<<endl;
		}
}