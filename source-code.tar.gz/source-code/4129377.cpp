//Language: GNU C++


#include<cstdio>
#include<cmath>
#include<iostream>
#include<string>
#include<fstream>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<queue>
#include<map>
using namespace std;
int main(){
	int flag=1;
	int n,i,count;
	char s[111];
	gets(s);
	n=strlen(s);
	count=0;
	for(i=0;i<n;i++)
	{
		if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u')
			count++;
	}
	if(count!=5)
		flag=0;
	gets(s);
	n=strlen(s);
	count=0;
	for(i=0;i<n;i++)
	{
		if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u')
			count++;
	}
	if(count!=7)
		flag=0;
	
	gets(s);
	n=strlen(s);
	count=0;
	for(i=0;i<n;i++)
	{
		if(s[i]=='a'||s[i]=='e'||s[i]=='i'||s[i]=='o'||s[i]=='u')
			count++;
	}
	if(count!=5)
		flag=0;
	if(flag)
		cout<<"YES"<<endl;
	else
		cout<<"NO"<<endl;
//	system("pause");
	return 0;
}