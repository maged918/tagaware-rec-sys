//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<iostream>
using namespace std;
int main()
{
    int a,b,c,d,flag=0;
    char str;
    cin>>a>>str>>b;
    while(flag==0)
    {
            b=b+1;
            if(b>=60)
            {
                     b=0;
                     a=a+1;
            };
            if(a>=24) a=0;
            if(b/10==a%10&&b%10==a/10)
            flag=1;
    }
    cout<<a/10<<a%10<<":"<<b/10<<b%10;
    return 0;
}
