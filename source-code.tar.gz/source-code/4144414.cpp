//Language: GNU C++


//contest/322/problem/D

#include <iostream>
#include <string.h>
#include <algorithm>
using namespace std;

int atk[110];
int def[110];
int ciel[110];

int compare(int a,int b){return a>b;}

int main()
{
	int n,m,i,j,n1=0,n2=0,d,st1=0,st2=0,ptr1,ptr2;
	string str;
	cin >> n >> m;
	for(i=1;i<=n;i++){
		cin >> str >> d;
		if(str=="ATK")
			atk[++n1]=d;
		else
			def[++n2]=d;
	}
	for(i=1;i<=m;i++)
		cin >> ciel[i];
	sort(atk+1,atk+n1+1,compare);
	sort(def+1,def+n2+1,compare);
	sort(ciel+1,ciel+m+1,compare);
	for(i=1;i<=min(m,n1);i++){
		if(ciel[i]<=atk[n1-i+1])
			break;
		st1+=ciel[i]-atk[n1-i+1];
	}
	ptr1=m;ptr2=n2;
	while(ptr1>=1 && ptr2 >=1)
	{
		if(ciel[ptr1]<=def[ptr2]){
			ptr1--;continue;}
		else{
			ciel[ptr1]=0;
			ptr1--;ptr2--;
		}
	}
	if(ptr1>=1){
		sort(ciel+1,ciel+m+1,compare);
		for(i=1;i<=min(n1,m);i++){
			if(ciel[i]<atk[i]){
				i=m+1;break;}
			st2+=ciel[i]-atk[i];
		}
		for(j=i;j<=m;j++)
			st2+=ciel[j];
	}
	cout << max(st1,st2) << endl;
	return 0;
}
