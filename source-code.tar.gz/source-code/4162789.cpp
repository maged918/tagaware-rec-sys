//Language: MS C++


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <string>
using namespace std; 

struct Order {
	int n, a, b;
} o[100010];

int comp1(const void *a, const void *b) {
	Order *A = (Order *)a, *B = (Order *)b;
	if (A->b != B->b)
		return B->b - A->b;
	if (A->a != B->a)
		return A->a - B->a;
	return A->n - B->n;
}

int comp2(const void *a, const void *b) {
	Order *A = (Order *)a, *B = (Order *)b;
	if (A->a != B->a)
		return A->a - B->a;
	if (A->b != B->b)
		return A->b - B->b;
	return A->n - B->n;
}

int n, p, k, bm, am, nm;

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	scanf("%d%d%d", &n, &p, &k);	
	for (int i = 0; i < n; i++) {
		o[i].n = i + 1;
		scanf("%d%d", &o[i].a, &o[i].b);
	}

	qsort(o, n, sizeof(Order), comp1);

	qsort(o, n - (p - k), sizeof(Order), comp2);

	for (int i = 0; i < k; i++) {
		printf("%d ", o[n - (p - k) - 1 - i].n);
		if (i == 0) {
			bm = o[n - (p - k) - 1 - i].b;
			am = o[n - (p - k) - 1 - i].a;
			nm = o[n - (p - k) - 1 - i].n;
		} else if (o[n - (p - k) - 1 - i].b < bm || (o[n - (p - k) - 1 - i].b == bm && o[n - (p - k) - 1 - i].a > am)) {
			bm = o[n - (p - k) - 1 - i].b;
			am = o[n - (p - k) - 1 - i].a;
			nm = o[n - (p - k) - 1 - i].n;
		}
	}

	qsort(o, n, sizeof(Order), comp1);

	int j = 0;
	while (o[j].n != nm)
		j++;
	j++;

	for (int i = 0; i < (p - k); i++) 
		printf("%d ", o[j + i].n);
	
	return 0;
}