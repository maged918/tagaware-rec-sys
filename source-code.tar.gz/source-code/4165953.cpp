//Language: GNU C++


                                              // created by Marchecnko Vadim [midav7]
// I did it just for fun =)
// v 0.9

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <algorithm>                                                                                                                       
#include <vector>
#include <cmath>
#include <map>
#include <set>
#include <climits>
#include <queue>
#include <set>

#define foread freopen("input.txt","r",stdin)
#define fowrite freopen("output.txt","w",stdout)
#define pi 3.141592
#define sqr(a) ( (a)*(a))
#define pb push_back
#define mp make_pair
#define fir first
#define sec second

using namespace std;

long long a[2000000],_time[2000000], was[20000000];
                 
int main(){
int n,m;
scanf("%d %d",&n,&m);
for (int i=1; i<=n; ++i) scanf("%d",&a[i]);
for (int i=1; i<=m; ++i){
  long long num, el, nw;
  cin >> num >> el;
  _time[i]=_time[i-1];
  if (num==1){
    cin >> nw;
    a[el]=nw;
    was[el]=i;
  }
  if (num==2)   _time[i]+=el;
  if (num==3)  cout << a[el]+_time[i]-_time[was[el]] << endl;
}
return 0;
} 