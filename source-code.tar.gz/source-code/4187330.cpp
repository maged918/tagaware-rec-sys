//Language: MS C++


#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <queue>

using namespace std;

const int MN = 1000 + 10;

bool str[MN], stb[MN];

#define pii pair <int, int>
#define mp make_pair

int main() {
#ifdef _DEBUG
    freopen("input.txt", "r", stdin);
#endif
    int n, m;
    cin >> n >> m;
    for(int i = 0; i < m; i ++) {
        int r, c;
        scanf("%d%d", &r, &c);
        str[r] = true;
        stb[c] = true;
    }
    if (n == 2) {
        cout << 0 << endl;
        return 0;
    }
    int ans = 0;
    for(int r = 2; r <= n / 2; r ++) {
        if (!str[r])
            ans ++;
        if (!stb[r])
            ans ++;
        if (!str[n - r + 1])
            ans ++;
        if (!stb[n - r + 1])
            ans ++;
    }
    if (n % 2 && (!str[(n + 1) / 2] || !stb[(n + 1) / 2]))
        ans ++;
    cout << ans << endl;
    return 0;
}