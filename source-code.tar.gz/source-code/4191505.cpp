//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cmath>
#include <set>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

int a[200000][2];
bool s[2000], t[2000], mmark[2000], nmark[2000];

int main()
{
    long long n, m, ans=0;
    cin >> n >> m;
    for(int i=0;i<m;i++)
    {
        cin >> a[i][0] >> a[i][1];
        mmark[a[i][0]]= nmark[a[i][1]] = 1;
    }
    for(int i=2;i<n;i++)
        if(!nmark[i] && !t[i])
        {
            t[i]=1;
            ans++;
        }
    for(int i=2;i<n;i++)
        if(!mmark[i] && !s[i])
        {
            s[i]=1;
            ans++;
        }
    /*
    for(int i=2;i<n;i++)
        if(!nmark[i] && !t[i])
        {
            t[i]=1;
            ans++;
        }
    for(int i=2;i<n;i++)
        if(!nmark[i] && !t[i])
        {
            t[i]=1;
            ans++;
        }
    */
    if(n%2 && nmark[n/2+1] == 0 && mmark[n/2+1] == 0)
        ans--;
    cout << ans << endl;
}