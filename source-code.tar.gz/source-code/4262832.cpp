//Language: GNU C++


//***************************************
//**copyright @HARSH RANJAN ... \m/******
//***************************************


//  ****HEADER FILES***

#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<utility>
#include<algorithm>
#include<iomanip>
#include<functional>
#include<limits>
#include<memory>
#include<cstdlib>
#include<cassert>
#include<cctype>
#include<cfloat>
#include<stack>
#include<queue>
#include<deque>
#include<iterator>
#include<list>
#include<vector>
#include<map>
#include<set>
#include<numeric>
#include<ctime>
#include<sstream>

using namespace std;

// ***COMMONLY USED MACROS***
#define MOD 1000000007
#define pb push_back
#define pob pop_back
#define pf push_front
#define pof pop_front
#define mp make_pair
#define minr min_element
#define maxr max_element
#define mh make_heap
#define ph push_heap
#define poh pop_heap
#define Sd(n) scanf("%d",&n)
#define Pd(n) printf("%d\n",n)
#define Sld(n) scanf("%lld",&n)
#define Pld printf("%lld\n",n)
#define Ss(s) scanf("%s\n",s)
#define Ps(s) printf("%s\n",s)
#define forn(i,n) for(int i=0;i<int(n);i++)
#define ford(i,n) for(int i=int(n);i>=0;i--)
#define all(a) a.begin(),a.end()
#define set(a,x) memset(a,x,sizeof(a))
//#define mod 10000007
#define getcx getchar_unlocked
//  ***FEW TYPEDEFINES**
typedef unsigned long long int uint64;
typedef long long int int64;
typedef pair<int64,int64> pii;

const long double pi = 3.1415926535897932384626433832795;
const long double eps = 1e-9;
int main(){
	int n,i;
	Sd(n);
	if(n%2!=0){
		printf("-1");
		return 0;
	}
	else{
		for(i=1;i<=n;i++){
			if(i%2!=0)
			printf("%d ",i+1);
			else
			printf("%d ",i-1);
		}
	}
		return 0;	
}