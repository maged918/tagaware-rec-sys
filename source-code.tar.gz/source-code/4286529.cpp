//Language: MS C++


#pragma warning( disable : 4996)
#pragma comment(linker, "/STACK:666000000")

#define bublic public

#include <algorithm>
#include <assert.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits.h>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <string>
#include <time.h>
#include <vector>
#include <stack>

#define nextLine() {for(int c=getchar(); c!='\n' && c!=EOF; c=getchar());}
#define sqr(a) ((a)*(a))
#define has(mask,i) (((mask) & (1<<(i))) == 0 ? false : true)
#define eprintf(...) fprintf(stderr, __VA_ARGS__)

#define TASK "file"

using namespace std;

#define mp(x, y) make_pair(x, y)
#define pb(_o_) push_back(_o_)

typedef long long LL;
typedef unsigned long long ULL;
typedef long double ldb;

typedef pair<int,int> pii;
typedef vector<int> vi;
typedef vector<vi> vvi;
#ifndef ONLINE_JUDGE
typedef vector<int> vc;
typedef vector<vc> vvc;
#else
typedef vector<char> vc;
typedef vector<char> vvc;
#endif

typedef list<int> li;

const int inf = (1 << 30) - 1;
const ldb eps = 1e-9;
const ldb pi = fabs(atan2(0.0, -1.0));

#ifndef ONLINE_JUDGE
#define parr(a,n,m) for(int i=0;i<n;i++){for(int j=0;j<m;j++)cout<<a[i][j]<<" ";puts("");}puts("");
#else
#define parr(a,n,m) for(int i=0;i<2;i++)i++;
#endif

void ML(const bool v)
{
    if (v)
        return;
    int *ass;
    for (;;)
    {
        ass = new int[2500000];
        for (int i = 0; i < 2500000; i++)
            ass[i] = rand();
    }
}

void TL(const bool v)
{
    if (v)
        return;
    int *ass;
        ass = new int[250];
    for (;;)
    {
        for (int i = 0; i < 250; i++)
            ass[i] = rand();
    }
}

void PE(const bool v)
{
    if (v)
        return;
    puts("ass 1 2 3 4 5 6 fuck");
    exit(0);
}

int n, b;
int a[2020];

void LoAd()
{
    cin >> n >> b;
    for (int i =0 ; i < n; i++)
        cin >> a[i];
}

void SoLvE()
{
    int res = b;
    for (int i = 0; i < n; i++)
        for (int j = i + 1; j < n; j++)
            if (b / a[i] * a[j] + b % a[i] > res)
                res = b / a[i] * a[j] + b % a[i];
    cout << res;
}

int main()
{
    srand( (int) time(NULL));
#ifndef ONLINE_JUDGE
    freopen(TASK".in","r",stdin);   freopen(TASK".out","w",stdout);
#endif
    LoAd();
    SoLvE();
    return 0;
}