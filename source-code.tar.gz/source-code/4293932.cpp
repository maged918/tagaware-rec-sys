//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<set>
#include<vector>
using namespace std;
#define sz 100010
int n,m,d;
int dp[sz];
int p[sz];
vector<int>nt[sz];
void dfs1(int who,int from)
{
    if(p[who])dp[who] = d;
    else dp[who]=0x3f3f3f3f;
    for(int i=0;i<nt[who].size();i++)
    {
        int to = nt[who][i];
        if(to==from)continue;
        dfs1(to,who);
        dp[who] = min(dp[who],dp[to]-1);
    }
}

int ret=0;
multiset<int>ss[sz];
void dfs(int who,int from,int len)
{
    if(p[who])len = min(len,d);
    if(dp[who]>=0&&len>=0)ret ++;

    multiset<int>&sa=ss[who];
    sa.insert(len);

    for(int i=0;i<nt[who].size();i++)
    {
        int to = nt[who][i];
        if(to==from)continue;
        sa.insert(dp[to] - 1);
    }

    for(int i=0;i<nt[who].size();i++)
    {
        int to = nt[who][i];
        if(to==from)continue;
        sa.erase(sa.find(dp[to] - 1));
        //printf("zzz%d\n",*sa.begin());
        if(*sa.begin()>0)dfs(to,who,*sa.begin()-1);

        sa.insert(dp[to] - 1);
    }
}
int main()
{
    scanf("%d%d%d",&n,&m,&d);
    for(int i=0;i<m;i++)
    {
        int tmp;scanf("%d",&tmp);
        p[tmp]=1;
    }
    for(int i=1;i<n;i++)
    {
        int a,b;scanf("%d%d",&a,&b);
        nt[a].push_back(b);
        nt[b].push_back(a);
    }
    dfs1(1,0);
    //for(int i=1;i<=n;i++)printf("%d ",dp[i]);
    dfs(1,0,0x3f3f3f3f);
    printf("%d\n",ret);
}
