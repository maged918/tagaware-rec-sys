//Language: GNU C++


#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <cmath>
using namespace std;

int main()
{

int n,i,j;
long long a,b;
cin>>n;

for(i=1;i<=n;i++)
{
cin>>a;
b=sqrtl(a);
for(j=2;j*j<=b;j++) if(b%j==0) break;
if(j*j>b && b*b==a && a>1) cout<<"YES" << endl;
else cout<<"NO"<<endl;
}
    return 0;
}