//Language: MS C++


#include <stdio.h>
#include <iostream>

using namespace std;

int main()
{
	long y, k, n;
	cin>>y>>k>>n;
	long ost = y % k;
	if(y >= n || k > n || (k - ost) + y > n)
	{
		cout<<-1;
		return 0;
	}
	for(long i = (k - ost); i + y <= n; i += k)
		cout<<i<<" ";
	return 0;
}