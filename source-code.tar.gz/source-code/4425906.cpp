//Language: MS C++


#if 1

#include <iostream>
#include <stdio.h>
#include <map>
#include <string>
#include <vector>
#include <stdlib.h>
#include <ctime>
#include <algorithm>
#include <cmath>
#include <queue>
#include <assert.h>
#include <set>
#include <stack>
#include <math.h>
#include <string.h>
#include <cstring>
#include <fstream>
#include <sstream>
#include <complex>

using namespace std;

typedef long double LD;
typedef long long LL;

#define pb push_back
#define mp make_pair
#define X first
#define Y second

const int inf = 1e9;
const LD eps = 1e-9;
const LD pi = acos(-1.0);


int xabs(int x) {return x < 0 ? -x : x;}

struct see
{
	int t, l, r;
	see() {}
	see(int t, int l, int r) :t(t), l(l), r(r) {}
};

int sign(int x)
{
	if (x == 0)
		return 0;
	return x < 0 ? -1 : 1;
}
int main()
{
	LL r, h;
	cin >> r >> h;
	h *= 2;
	r *= 2;

	LL cnt = 0;
	int c1 = (h + r / 2) / r;
	c1 *= 2;
	LL ost = (h + r / 2) % r;
	if ((ost + r / 2) * (ost + r /2) + (r / 2) * (r / 2) >= r * r)
		c1 += 1;
	cout << c1 << endl;
	return 0;
}

#endif