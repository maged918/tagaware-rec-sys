//Language: GNU C++0x


#include <iostream>
using namespace std;

int f(int n, int m, int a, int b)
{
	int aRow=(a-1)/m;
	int bRow=(b-1)/m;
	int aColumn=(a-1)%m;
	int bColumn=(b-1)%m;
	if(aRow==bRow) return 1;
	if(a==1 && b==n) return 1;
	else if(bRow==aRow+1)
	{
		if(bColumn==m-1 && aColumn==0) return 1;
		if(aColumn==0 && b==n) return 1;
		//if(b==n) return 1;
		else return 2;
	}
	else
	{
		if(bColumn==m-1 && aColumn==0) return 1;
		if(aColumn==0 && b==n) return 1;
		if(aColumn==bColumn+1) return 2;
		if(bColumn==m-1 || aColumn==0) return 2;
		if(b==n) return 2;
		return 3;
	}
}

int main()
{
	int n, m, a ,b;
	cin >> n >> m >> a >> b;
	cout << f(n, m ,a ,b);
	return 0;
}
