//Language: GNU C++


#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <deque>
#include <map>
#include <set>
#include <algorithm>
#include <climits>
using namespace std;

typedef long long Int;
typedef pair<int, int> pii;
typedef vector<int> Vi;
typedef map<int,int> Mii;

vector<Int> heads;
vector<Int> tracks;

bool check(Int k)
{
	
	int h = 0;
	int t = 0;
	
	Int r = k;
	Int d_left = -1;
	while(h < heads.size() && t < tracks.size())
	{
		if(tracks[t] <= heads[h])
		{
			if(d_left > -1)
			{
				t++;
			}
			else
			{
				if(heads[h] - tracks[t] > k)
				{
					return false;
				}
				else
				{
					d_left = heads[h] - tracks[t];
					t++;					
				}
			}
		}
		else
		{
			if(h + 1 < heads.size() && tracks[t] >= heads[h+1])
			{
				d_left = -1;
				h++;
			}
			else
			{
				Int cost_right = tracks[t] - heads[h];
				Int cost_left = d_left > -1 ? d_left : 0;
				Int cost = 2 * min(cost_left, cost_right) + max(cost_left, cost_right);
				
				if(cost > k)
				{
					if(h + 1 >= heads.size())
					{
						return false;
					}
					else
					{
						h++;
						d_left = -1;
					}
				}
				else
				{
					t++;
				}
			}
		}				
	}
	return true;
}

int main()
{

	int n,m;
	cin>>n>>m;
	heads.resize(n);
	for(int i = 0; i < n;i++)
	{
		cin>>heads[i];
	}
	tracks.resize(m);
	for(int i =0;i < m;i++)
	{
		cin>>tracks[i];
	}		
		
	Int lo = 0;
	Int hi = 2 * max(heads.back(), tracks.back());
	
	Int ans = -1;
	while(lo <= hi)
	{
		Int mid = lo + (hi - lo) / 2;
		if(check(mid))
		{
			ans = mid;
			hi = mid - 1;
		}
		else
		{
			lo = mid+1;
		}
	}
	
	cout<<ans<<endl;
	return 0;
}



