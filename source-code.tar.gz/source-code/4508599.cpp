//Language: GNU C++


#include<cstdio>
#include<cstdlib>
#include<cstring>

using namespace std;

#define inc(a,b) {a+=b;if (a>=mo) a-=mo;}

const int mo=1000000007;

int n,k,f[401][210][16],g[16][10][16],h[5][10][2][2][16],num[16];

int main()
{
	scanf("%d%d",&n,&k);
	for (int a=0;a<16;a++)
		for (int b=0;b<16;b++)
		{
			static int col[4];
			col[0]=col[1]=col[2]=col[3]=0;
			int cnt=0;
			for (int c=0;c<4;c++)
				col[c]=((a>>c)&1),cnt+=col[c];
			bool able=true;
			for (int c=0;c<4;c++)
				if ((b>>c)&1)
				{
					if (col[c] || col[(c+1)%4]) able=false;
					col[c]=col[(c+1)%4]=true;
					cnt++;
				}
			if (!able) continue;
			int news=0;
			for (int c=3;c>=0;c--)
				news=(news<<1)|col[c];
			f[0][cnt][news]++;
		}
	for (int a=0;a<16;a++)
	{
		int b=a,c=0;
		while (b)
			c+=b&1,b>>=1;
		 num[a]=c;
	}
	for (int a=0;a<(1<<4);a++)
	{
		memset(h,0,sizeof(h));
		h[1][0][0][0][a]=h[1][1][1][0][a|1]=h[1][2][1][1][a|1]=h[1][1][0][1][a|1]=1;
		if (!(a&1)) h[1][1][1][1][a|1]=1;
		for (int b=1;b<4;b++)
			for (int use=0;use<=8;use++)
				for (int last=0;last<=1;last++)
					for (int first=0;first<=1;first++)
						for (int s=0;s<16;s++)
							if (h[b][use][last][first][s])
								for (int use1=0;use1<2;use1++)
									for (int use2=0;use2<2;use2++)
									{
										if (!use1 && !use2 && !((s>>b)&1)) inc(h[b+1][use+1][1][first][s|(1<<b)],h[b][use][last][first][s]);
										inc(h[b+1][use+use1+use2][use2][first][s|((use1|use2)<<b)],h[b][use][last][first][s]);
										if (!last && !use1) inc(h[b+1][use+1+use2][use2][first][s|(1<<b)|(1<<(b-1))],h[b][use][last][first][s]);
										if (!use1 && !use2 && !((s>>b)&1) && !((s>>(b-1))&1)) inc(h[b+1][use+1][1][first|(b==1)][s|(1<<b)|(1<<(b-1))],h[b][use][last][first][s]);
									}
		for (int use=0;use<=8;use++)
			for (int s=0;s<16;s++)
				inc(h[4][use+1][1][1][s|9],h[4][use][0][0][s]);
		for (int use=0;use<=8;use++)
			for (int s=0;s<16;s++)
				if (!(s&1) && !(s&8)) inc(h[4][use+1][1][1][s|9],h[4][use][0][0][s]);
		for (int use=0;use<=8;use++)
			for (int last=0;last<=1;last++)
				for (int first=0;first<=1;first++)
					for (int s=0;s<16;s++)
						inc(g[a][use][s],h[4][use][last][first][s]);
	}
	for (int a=0;a<2*n;a++)
		for (int b=0;b<=k;b++)
			for (int c=0;c<16;c++)
				if (f[a][b][c])
					if (a&1)
					{
						for (int delta=0;delta<=8;delta++)
							for (int s=0;s<16;s++)
								inc(f[a+1][b+delta][s],(long long)f[a][b][c]*g[c][delta][s]%mo);
					}
					else
					{
						for (int d=0;d<16;d++)
							inc(f[a+1][b+num[d]][c|d],f[a][b][c]);
					}
	int ans=0;
	for (int a=0;a<16;a++)
		inc(ans,f[2*n][k][a]);
	for (int a=1;a<=k;a++)
		ans=(long long)ans*a%mo;
	printf("%d\n",ans);

	return 0;
}
