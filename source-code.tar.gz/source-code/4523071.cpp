//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <string>
#include <map>
#include <stack>
#include <vector>
#include <set>
#include <queue>
using namespace std;
typedef __int64 ll;
int gcd(int x,int y)
{
    return y==0?x:gcd(y,x%y);
}
int main()
{
    int n;
    cin>>n;
    int p;
    int mp=0;

    int d=0;
    for(int i=0;i<n;i++)
    {
         cin>>p;
         mp=max(p,mp);
          d=gcd(p,d);
    }
     if(((mp/d)-n)%2==0)
     {
         printf("Bob\n");
     }
     else
        printf("Alice\n");



}
