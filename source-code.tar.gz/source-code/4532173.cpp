//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<string.h>

using namespace std;

#define MX  100010
#define inf 2000000000

int main()
{
    int t,n,mx,gcd,x,nw;

    cin>>n;

    cin>>x;

    mx  = x;
    gcd = x;

    for(int i=2;i<=n;i++)
    {
        cin>>x;
        mx = max(mx,x);
        gcd = __gcd(gcd,x);
    }

    nw = mx/gcd - n;

    if(nw&1) cout<<"Alice"<<endl;
    else cout<<"Bob"<<endl;

  
    return 0;
}
