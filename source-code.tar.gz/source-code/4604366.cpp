//Language: GNU C++


#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int main()
{
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    int mi=0,a[100001],b[6000]={0},n,i;
   scanf("%d",&n);
    for(i=0;i<n;i++){scanf("%d",&a[i]);b[a[i]]++;}
    for(i=1;i<=5000;i++)b[i]+=b[i-1];
    sort(a,a+n);
    for(i=0;i<n;i++)
    {
                    mi=max(b[min(2*a[i],5000)]-b[a[i]-1],mi);
    }
    printf("%d\n",n-mi);
    return 0;
}
    
