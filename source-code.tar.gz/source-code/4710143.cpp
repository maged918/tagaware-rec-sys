//Language: GNU C++0x


#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Answer {
	int x, p;
	Answer(int x, int p = 0):
		x(x), p(p)
	{

	}
};
int main (){

	int n;
	cin >> n;

	vector<int> input(n + 1);

	int max = -1;
	for(int i = 1; i <= n; i++){
		cin >> input[i];
		if(input[i] > max){
			max = input[i];
		} 
	}



	vector< vector<int> > action(max + 1);
	
	for(int i = 1; i <= n; ++i){
		action[input[i]].push_back(i);
	}	

	//cout<< " asdfasdf\n";
	vector<Answer> answer;

	for(int i = 1; i <= max; i++){
		if(action[i].size() == 0){
			continue;
		}
		sort(begin(action[i]), end(action[i]));


		int diff = 0;
		if(action[i].size() == 1){
			answer.push_back({input[action[i][0]]});
		}
		else if(action[i].size() >= 2){
			diff = action[i][1] - action[i][0];
			/*if(action[i].size() == 2){
				answer.push_back({input[action[i][0]], diff});
			}*/
		}


		bool acc = true;
		for(int j = 1; j < (int) action[i].size() && acc; j++){
			acc = acc && (action[i][j] - action[i][j - 1] == diff); 

		}

		if(action[i].size() <= 1){
			acc = false;
		}

		if(acc){
			answer.push_back({input[action[i][0]], diff});
		}
	}

	cout << answer.size() << '\n';

	for(auto it: answer){
		cout << it.x << ' ' << it.p << '\n';
	}





	return 0;
}