//Language: GNU C++


#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;

const double pi = atan2(0.0, -1.0);
const int MAXN = 1e5 + 5;

int main(){
    int n;
    while (scanf("%d", &n) != EOF){
        double a[MAXN];
        for (int i = 0; i < n; i ++){
            int x, y;
            scanf("%d%d", &x, &y);
            a[i] = atan2((double)y, (double)x);
        }
        double ans = 0.0;
        sort(a, a + n);
        if (n == 1){
            ans = 0.0;
        }
        else if (n == 2){
            ans = min(a[1] - a[0], a[0] + 2.0 * pi - a[1]);
        }
        else{
            ans = a[0] + 2.0 * pi - a[n - 1];
            for (int i = 1; i < n; i ++){
                ans = max(a[i] - a[i - 1], ans);
            }
            ans = 2.0 * pi - ans;
        }
        printf("%.8lf\n", ans * 180.0 / pi);
    }
    return 0;
}