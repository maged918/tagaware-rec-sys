//Language: GNU C++


#include<cstdio>
#define maxn 105
using namespace std;

int n,x,y;

int main()
{
    scanf("%d",&n);
    int a=0,b=0,c=0;
    while(n--)
    {
        scanf("%d%d",&x,&y);
        a+=x,b+=y;
        c+=(y%2)!=(x%2);
    }
    if(a%2==0&&b%2==0)puts("0");
    else if(c%2==0&&c>0)puts("1");
    else puts("-1");
    return 0;
}
