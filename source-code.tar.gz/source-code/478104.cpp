//Language: GNU C++


/* 
 * File:   main.cpp
 * Author: Anton Boytsov
 *
 * Created on 7 Июнь 2011 г., 20:58
 */

#include <cstdlib>
#include <cstdio>
#include <iostream>
#include <math.h>
#include <algorithm>
#include <string.h>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <new>
#include <ctype.h>

using namespace std;

/*
 * 
 */

char keyb[50][50];
int n, m, x, q;
bool can1[500];
bool cans[500];
bool issh = false;

struct cell {
    int i, j;

    cell() : i(0), j(0) {
    };

    cell(int i, int j) : i(i), j(j) {
    };

};

int dist2(int i1, int j1, int i2, int j2) {

    return ((i1 - i2)*(i1 - i2) + (j1 - j2)*(j1 - j2));

}

vector <cell> shifts;

int main() {

#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif

    scanf("%d %d %d\n", &n, &m, &x);

    memset(can1, false, sizeof (can1));

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            scanf("%c", &keyb[i][j]);
            if (keyb[i][j] == 'S') {
                cell c(i, j);
                shifts.push_back(c);
                issh = true;
            } else {
                can1[keyb[i][j]] = true;
            }
        }
        scanf("\n");
    }

    memset(cans, false, sizeof (cans));

    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) {
            if (keyb[i][j] != 'S')
                for (int k = 0; k < shifts.size(); k++) {
                    if (dist2(i, j, shifts[k].i, shifts[k].j) <= x * x)
                        cans[keyb[i][j]] = true;
                }
        }

    int kk = 0;
    scanf("%d\n", &q);
    for (int i = 0; i < q; i++) {

        char ch;
        scanf("%c", &ch);
        if (islower(ch)) {
            if (!can1[ch]) {
                cout << "-1";
                return 0;
            }
        } else {

            if (!issh) {
                cout << "-1";
                return 0;
            }
            if (!can1[tolower(ch)]) {
                cout << "-1";
                return 0;
            }
            if (!cans[tolower(ch)])
                kk++;

        }

    }
    cout << kk;


    return 0;
}

