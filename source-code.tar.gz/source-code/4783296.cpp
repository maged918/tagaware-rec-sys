//Language: GNU C++


#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <list>
#include <map>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <cassert>
#include <cctype>
#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

#define FR(i, a, b)   for(int i = a; i < b; i++)
#define FOR(i, a, b)  for(int i = a; i <= b; i++)
#define LFOR(i, a, b) for(int i = a; i >= b; i--)
#define FRSZ(i, x)    for(int i = 0; i < x.size(); i++)
#define RP(i, n)      for(int i = 0; i < n; i++)

using namespace std;

typedef long long int64;
typedef unsigned long long qword;
typedef pair <int, int> TPair;

const int MAXN = 20, INF = 1000;

int n;

string ch[MAXN];

int f[2 * MAXN][1 << 20], pos[MAXN][MAXN];

vector <TPair> diag[2 * MAXN];

int score(char c) {
    if (c == 'a') return 1;
    if (c == 'b') return -1;
    return 0;
}

int Cal(int s, int mask) {
//    cout << s <<' '<<mask<<endl;
    if (f[s][mask] > -INF) return f[s][mask];
    if (s == 2 * (n - 1)) return f[s][mask] = 0;
    int t[26];
    memset(t, 0, sizeof t);
    FRSZ(i, diag[s]) {
        if (!(mask & (1 << i))) continue;
        int x = diag[s][i].first, y = diag[s][i].second;
        if (x < n - 1) {
            int p = pos[x + 1][y];
            int l = ch[x + 1][y] - 'a';
            t[l] |= (1 << p);
        }
        if (y < n - 1) {
            int p = pos[x][y + 1];
            int l = ch[x][y + 1] - 'a';
            t[l] |= (1 << p);
//            cout << s<<' '<<mask<<' '<<x<<' '<<y<<endl;
        }
    }
    int p = s % 2;
    int res = (p) ? -INF : INF;
    RP(i, 26) {
        if (t[i] == 0) continue;
//        cout << s<<' '<<mask<<' '<<i<<endl;
        int r = score(i + 'a') + Cal(s + 1, t[i]);
        if ((p && r > res) || (!p && r < res))
            res = r;
    }
//    cout << s<<' '<<mask<<' '<<res<<endl;
    return (f[s][mask] = res);
}

int main() {
    #ifndef ONLINE_JUDGE
        freopen("EXAMPLE.INP", "r", stdin);
    #endif
    scanf("%d\n", &n);
    RP(i, n)
        cin >> ch[i];
    RP(i, 2 * n - 1)
        RP(j, 1 << n)
            f[i][j] = -INF;
    RP(i, n)
        RP(j, n)
            if (i == n - 1 || j == 0) {
                int p = 0;
                int x = i, y = j;
                while (x >= 0 && y < n) {
                    diag[x + y].push_back(TPair(x, y));
                    pos[x][y] = p++;
                    x--, y++;
                }
            }
    int res = score(ch[0][0]) + Cal(0, 1);
//    cout << res << endl;
//    cout << Cal(0, 1) << endl;
    if (res < 0)
        puts("SECOND");
    else
        if (res > 0)
            puts("FIRST");
    else
        puts("DRAW");
}
