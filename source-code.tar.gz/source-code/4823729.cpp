//Language: MS C++


#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <sstream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <numeric>

#define rep(i, n) for(int i = 0; i < (n); i++)
#define FOR(i, a, b) for(int i = (a); i < (b); i++)
#define ALL(v) (v).begin(), (v).end()
#define REV(s) (s).rbegin(), (s).rend()
#define MP make_pair
#define X first
#define Y second

using namespace std;

static const double EPS = 1e-9;

typedef pair<int, int> P;
typedef long long ll;

pair<ll, int> ldp[200010];
pair<ll, int> rdp[200010];
int x[200010];
int main(){
	int n, k;
	cin >> n >> k;
	rep(i, n) cin >> x[i];

	ll sum = 0;
	rep(i, k-1) sum += x[i];
	ll best = 0, idx = 0;
	rep(i, n){
		sum += x[i+k-1];
		if(best < sum){
			best = sum;
			idx = i;
		}
		ldp[i].first = best;
		ldp[i].second = idx;
		sum -= x[i];
	}

	sum = best = idx = 0;
	for(int i = n-1; i > n-k; i--) sum += x[i];
	for(int i = n-k; i >= 0; i--){
		sum += x[i];
		if(best <= sum){
			best = sum;
			idx = i;
		}
		rdp[i].first = best;
		rdp[i].second = idx;
		sum -= x[i+k-1];
	}

	//rep(i, n) cout << ldp[i].first << endl;
	//cout << endl;
	//rep(i, n) cout << rdp[i].first << endl;

	best = 0;
	P ans;
	rep(i, n-k){
		if(ldp[i].first+rdp[i+k].first > best){
			best = ldp[i].first+rdp[i+k].first;
			ans = MP(ldp[i].second, rdp[i+k].second);
		}
	}
	cout << ans.first+1 << ' ' << ans.second+1 << endl;

	return 0;
}