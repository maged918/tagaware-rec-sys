//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
	int n,i,j,k=1;
	scanf("%d",&n);
	int a[100][100];
	for(j=0;j<n;j++)
	{
		if(j%2==0)
		for(i=0;i<n;i++)
		{
			a[i][j]=k++;
		}
		else
		for(i=n-1;i>=0;i--)
		{
			a[i][j]=k++;
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			printf("%d ",a[i][j]);
		}
		printf("\n");
	}
	return 0;
}
