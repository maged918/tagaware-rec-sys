//Language: GNU C++


#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <list>
#include <bitset>
#include <utility>

using namespace std;

#define dbg(x) cerr<<#x<<" : "<<x<<endl
#define inf (1<<30)
#define PB push_back
#define MP make_pair
#define mset(x,a) memset(x,(a),sizeof(x))
typedef long long LL;
#define twoL(X) (((LL)(1))<<(X))
const double PI = acos(-1.0);
const double eps = 1e-8;

template <class T> T sqr(T x)
{
    return x*x;
}

int gcd(int a, int b)
{
    return (b == 0) ? a : gcd(b, a % b);
}

#define FOREACH(it, a) for(typeof((a).begin()) it = (a).begin(); it!=(a).end(); ++it)
#define ALL(x) (x).begin(), (x).end()

double dist(int x1, int y1, int x2, int y2) {
	return sqrt(sqr(x1-x2) + sqr(y1-y2));
}

int main(int argc, char** argv)
{
    int n,m,X;
	scanf("%d%d%d", &n, &m, &X);
	char ch[55][55] = {0};
	for(int i=0; i<n; ++i) {
		scanf("%s", ch[i]);
	}

	int upp[26] = {0};
	bool ex[26] = {0};
	for(int i=0; i<26; ++i) upp[i] = inf;
	for(int i=0; i<n; ++i) {
		for(int j=0; j<m; ++j) {
			if(ch[i][j] == 'S') {
				for(int x = 0; x < n; ++x) {
					for(int y = 0; y < m; ++y) {
						if(ch[x][y] == 'S') continue;
						if(dist(i,j,x,y) <= X) upp[ch[x][y]-'a'] = 1;
						else if(upp[ch[x][y]-'a'] == inf) upp[ch[x][y]-'a'] = 0;
					}
				}
			}
			else {
				ex[ch[i][j]-'a'] = 1;
			}
		}
	}

	scanf("%d", &n);
	char str[500005] = "";
	scanf("%s", str);
	int ans = 0 ;
	for(int i=0; i<n; ++i) {
		if(str[i] >= 'A' && str[i] <= 'Z') {
			if(upp[str[i]-'A'] == 0) ++ans;
			else if(upp[str[i]-'A'] == inf) {
				puts("-1");
				goto badend;
			}
		} else {
			if(!ex[str[i]-'a']) {
				puts("-1");
				goto badend;
			}
		}
	}
	printf("%d\n", ans);
badend:
    return (EXIT_SUCCESS);
}

