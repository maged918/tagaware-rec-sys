//Language: GNU C++


#include<iostream>
using namespace std;
int main()
{
    int r, g, b, m, ans;
    cin >> r >> g >> b;
    r = r/2 + r%2;
    g = g/2 + g%2;
    b = b/2 + b%2;
    m = max(max(r,g),b);
    ans = 3*(m-1) + 30 -1;
    if(m == b)
      ans += 3;
    else if(m == g)
      ans += 2;
    else if(m == r)
      ans += 1;
    cout << ans << endl;
}
