//Language: GNU C++


#include <iostream>
#include <cstdio>

using namespace std;

int temp[8];

void input()
{
	int x, n;
	bool flag = true;
	
	cin >> n;
	
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &x);
		
		if (x == 1)
		{
			temp[1]++;
		}
		else if (x == 2)
		{
			temp[2]++;
		}
		else if (x == 3)
		{
			temp[3]++;
		}
		else if (x ==  4)
		{
			temp[4]++;
		}
		else if (x == 6)
		{
			temp[6]++;
		}
		else 
		{
			flag = false;
		}
	}
	
	if (temp[1] != n / 3 || temp[2] + temp[3] != n / 3 || temp[4] + temp[6] != n / 3 || temp[4] > temp[2])
	{
		flag = false;
	}
	
	if (flag)
	{
		for (int i = 0; i < temp[4]; i++)
		{
			printf("1 2 4\n");
		}
		for (int i = 0; i < temp[2] - temp[4]; i++)
		{
			printf("1 2 6\n");
		}
		for (int i = 0; i < temp[3]; i++)
		{
			printf("1 3 6\n");
		}
	}
	else 
	{
		cout << -1 << endl;
	}
}

int main()
{
	input();
	return 0;
}
		 	  	 	 		 				   			 	