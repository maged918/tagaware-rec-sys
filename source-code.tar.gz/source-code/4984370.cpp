//Language: MS C++


#include <iostream>
#include <stdio.h>
using namespace std;

int arr[200];

int main()
{
    #ifdef _DEBUG
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif

    int n;
    scanf("%d", &n);

    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &arr[i]);
        sum += arr[i];
    }

    int ans = 0;
    for (int i = 0; i < n; i++)
    {
        if ((sum - arr[i]) % 2 == 0)
            ans++;
    }

    printf("%d", ans);

    ////

    return 0;
}