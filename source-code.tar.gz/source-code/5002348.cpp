//Language: GNU C++0x


#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<int, int> PII;

#define sqr(x) ((x) * (x))
#define all(x) (x).begin(), (x).end()
#define clr(x) memset((x), 0, sizeof(x))
#define pb push_back
#define mp make_pair
#define x first
#define y second

int main()
{
    //freopen("jumps.in", "r", stdin);
    //freopen("jumps.out", "w", stdout);

    int k;
    cin >> k;
    string s;
    cin >> s;

    int n = s.length();
    int sum[n + 1];
    sum[0] = 0;
    for (int i = 0; i < n; ++i)
    {
        sum[i + 1] = sum[i] + (s[i] - '0');
    }
    int cnt[n + 1];
    clr(cnt);

    ll ans = 0;
    for (int i = 0; i <= n; ++i)
    {
        if (sum[i] >= k)
            ans += cnt[sum[i] - k];
        cnt[sum[i]]++;
    }
    cout << ans << endl;
    return 0;
}
