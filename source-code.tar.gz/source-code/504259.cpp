//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <set> 
#include <map>
#include <cstdio>
using namespace std;
const int MAXN = 100010;
int BIT[MAXN+1];

void update(int i){
//	cout << "Calling " << i << endl;
	while(i<=MAXN){
		BIT[i]++;
		i += i&(-i);
	}
}

int get(int i){
	int sum = 0;
	while(i > 0){
		sum += BIT[i];
		i -= i&(-i);
	}
	return sum;
}
	

int main()
{
	int n;
	cin >> n;
	vector< pair<int,int> > A(n);
	for (int i = 0; i < n; i++){
		cin >> A[i].first;
		A[i].second = i;
	}
	sort(A.begin(),A.end());
	vector<int> B(n);
	int j = 0;
	for (int i = 0; i < n; i++){
		if(i==0 or A[i].first != A[i-1].first){
			j++;
		}
		B[i] = j;
	}

	// for (int i = 0; i < n; i++){
	// 	cout << B[i] << ' ';
	// }
	// cout << endl;

	vector <int> D(n);
	int m = B[n-1];
	j = 0;
	for(int i=1;i<=m;i++) {
		for(int k=j; B[k]==i; k++){
			int index = A[k].second+1;
			int u = get(index);
			int v = get(n);
			if(u==v){
				D[index-1] = -1;
				continue;
			}
			// binary search for left most p such that get(p) = v (get(p-1)<v)
			// in range [index,n]
			int lo = index+1, hi = n, mi = lo;
			while(lo < hi){
				mi = (lo+hi)/2;
				// cout << mi << ' ' << get(mi) << ' ' << get(mi-1) << ' ' << v << endl; 
				if(get(mi)<v)
					lo = mi+1;
				else if((get(mi)>v) or ((get(mi)==v) and (get(mi-1)==v)))
					hi = mi-1;
				else
					break;
				// cout << lo << " and " << hi << endl;
			}
			mi = (lo+hi)/2;
			// must find!
			// cout << index+1 << ' ' << n << endl;
			// cout << "found " << index << ' ' <<  mi<< endl;
			D[index-1] = mi - (index + 1);
		}
		while(B[j] == i){
			update(A[j].second+1); // remember
			j++;
		}
		// for(int idx = 1; idx <= n; idx ++){
		// 	cout << get(idx) << ' ';
		// }
		// cout << endl;
	}

	for (int i = 0; i < n; i++){
		cout << D[i] << ' ';
	}
	cout << endl;
	
}
