//Language: GNU C++


#include<cstdio>
using namespace std;
char str[200001];
char ans[200001];
int top;
int main(){
	scanf("%s",str);
	bool flag=false;
	bool find=false;
	ans[top++]=str[0];
	for(int i=1;str[i];i++){
		if(str[i]==ans[top-1])find=true;
		else find=false;
			if(top>=2&&ans[top-2]==ans[top-3])flag=true;
			else if(find&&top>=2&&ans[top-1]==ans[top-2])flag=true;
			else flag=false;
		if(find&&flag);
		else{
			ans[top++]=str[i];
		}
	}
	printf("%s\n",ans);

}
