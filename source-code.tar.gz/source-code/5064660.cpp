//Language: GNU C++


#include <stdexcept>
#include <cstdarg>
#include <iostream>
#include <fstream>
#include <exception>
#include <memory>
#include <locale>
#include <sstream>
#include <set>
#include <list>
#include <bitset>
#include <fstream>
#include <numeric>
#include <iomanip>
#include <string>
#include <utility>
#include <cctype>
#include <climits>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <map>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <vector>
#include <queue>
#include <deque>
#include <cstdlib>
#include <stack>
#include <iterator>
#include <functional>
#include <complex>
#include <valarray>
//#include <bits/stdc++.h>


using namespace std;
map<int,int> tree;
map<int,int>::iterator iter;
int a;
int main()
{
    scanf("%d",&a);
    if(a==0)
    {
        printf("O-|-OOOO\n");
        return 0;
    }
    int z[20];
    int num=0;
    for(int q=0;a>0;q++)
    {
        z[num++]=a%10;
        a/=10;
        if(z[q]>=5)
        {
            printf("-O|");
            z[q]-=5;
        }
        else
            printf("O-|");

        for(int w=0;w<z[q];w++)
            printf("O");
        printf("-");
        for(int w=0;w<4-z[q];w++)
            printf("O");
        printf("\n");
    }
    
    
    
    
    return 0;
}