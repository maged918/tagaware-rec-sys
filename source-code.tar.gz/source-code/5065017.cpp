//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <cmath>
#include <queue>
#include <cstdlib>
#include <stack>
#include <algorithm>

using namespace std;
long long raha[100000];
long long pyora[100000];

bool pk(int a, int b)
{
    return a>b;
}
int main()
{
    long long n,m,a;
    cin>>n>>m>>a;
    for(int i=0;i<n;i++)
        cin>>raha[i];
    for(int i=0; i<m; i++)
        cin>>pyora[i];
    sort(pyora,pyora+m);
    sort(raha,raha+n,pk);
    long long ala=0,yla=min(n,m);
    while(ala!=yla)
    {
        long long k=(ala+yla+1)/2;
        long long kaytetty=0;
        for(int i=0; i<k; i++)
            kaytetty+=max((long long)(0),pyora[i]-raha[k-1-i]);
        if(kaytetty>a)
        {
            yla=k-1;
        }else{
            ala=k;
        }
    }

    long long r=ala,s=0;
    long long kaytetty=0;//sitä yhteistä
    long long omia=0;//no niita omia
    for(int i=0; i<ala;i++)
    {
        kaytetty+=max((long long)(0),pyora[i]-raha[r-1-i]);
        omia+=min(pyora[i],raha[r-1-i]);
    }
    s=max((long long)(0),omia-(a-kaytetty));
    cout<<r<<" "<<s<<endl;

    return 0;
}
