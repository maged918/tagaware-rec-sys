//Language: GNU C++


/** Author : Eopxt **/
/** Last Update : Sep. 30th 2013 **/ 
//{
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define DB double
#define lld long long
#define ull unsigned long long
#define infi 999999999
#define maxint 2147483647
#define sqr(x) ((x)*(x))
#define ABS(x) (((x)>0)?(x):(-(x)))
#define CLR(a,b) memset(a,b,sizeof(a))
#define RD scanf
#define OT printf
#define rep(i,n) for (int i=1; i<=n; i++)
#define For(i,l,r) for (int i=l; i<=r; i++)
#define Down(i,r,l) for (int i=r; i>=l; i--)
//}

const int N = 5010;
int n,sum,res=infi,cnt,a[N],lrg[N][N],sml[N][N];

int main() {
#ifndef ONLINE_JUDGE
    freopen("in.txt", "r", stdin);
    //freopen("out.txt", "w", stdout);
#endif
    RD("%d",&n);
    rep(i,n) RD("%d",&a[i]);
    rep(i,n) {
        rep(j,n) lrg[i][j]=lrg[i][j-1]+(a[j]>a[i]);
        Down(j,n,1) sml[i][j]=sml[i][j+1]+(a[j]<a[i]);
    }
    //lrg[i][p]  1..p中比a[i]大的数的个数 
    //sml[i][p]  p..n中比a[i]小的书的个数 
    rep(i,n) sum+=lrg[i][i];
    rep(i,n) 
        For(j,i+1,n) {
            int temp=sum-lrg[i][i]-lrg[j][j]-sml[i][i]-sml[j][j];
            temp=temp+lrg[i][j]+sml[i][j]+lrg[j][i-1]+sml[j][i];
            if (temp<res) {res=temp; cnt=1;}
                else if (temp==res) cnt++;
        }
    OT("%d %d\n",res,cnt);
    return 0;
}