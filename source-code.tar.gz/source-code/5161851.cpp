//Language: MS C++


#include <iostream>
#include <map>

using namespace std;

const int N = 4010;
char s[N];

int l;
long long x[N];

long long sum[N];

map<long long, long long> mmm;

int main()
{
    long long a;
    cin >> a;

    cin.getline(s, 10);
    cin.getline(s, N);

    int l = strlen(s);
    for(int i = 0; i < l; ++i)
        x[i] = s[i] - '0';

    sum[0] = x[0];
    for(int i = 1; i < l; ++i)
        sum[i] = sum[i-1] + x[i];

    for(int i = 0; i < l; ++i)
        for(int j = i; j < l; ++j)
            ++mmm[sum[j] - sum[i] + x[i]];

    if(a == 0) {
        long long ans = mmm[0] * mmm[0];
        for(map<long long, long long>::iterator i = mmm.begin(); i != mmm.end(); ++i) {
            if(i->first != 0)
                ans += 2 * i->second * mmm[0];
        }

        cout << ans;
        return 0;
    }

    long long ans = 0;
    for(int d = 1; d < (int)sqrt((double)a) + 1; ++d) {
        if(a % d == 0) {
            int d2 = a / d;
            if(d * d == a)
                ans += mmm[d] * mmm[d2];
            else
                ans += 2 * mmm[d] * mmm[d2];
        }
    }

    cout << ans;

    return 0;
}