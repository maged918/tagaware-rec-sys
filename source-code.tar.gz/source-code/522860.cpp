//Language: GNU C++


#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <vector>

#define rep(i,n) for(__typeof(n) i=0; i<(n); i++)
#define FOR(i,a,b) for(__typeof(b) i=(a); i<=(b); i++)
#define inf (1<<30)
#define eps 1e-9
#define pb push_back
#define clr clear()
#define all(x) x.begin(),x.end()
#define sz(x) (int)x.size()

#define read(x) freopen(x,"r",stdin);
#define rite(x) freopen(x,"w",stdout);

#define MAX(a,b) (a>b?a:b)
#define MIN(a,b) (a<b?a:b)

using namespace std;

typedef long long i64;
typedef unsigned long long ui64;
typedef string st;
typedef vector<int> vi;
typedef vector<st> vs;
typedef map<int,int> mii;
typedef map<st,int> msi;
typedef map<int,st> mis;

st itoa(i64 a){st ret;for(i64 i=a; i>0; i=i/10) ret+=((i%10)+48);reverse(all(ret));return ret;}
int toInt(st s){int r=0;istringstream sin(s);sin>>r;return r;}
i64 toInt64(st s){i64 r=0;istringstream sin(s);sin>>r;return r;}
double toDouble(st s){double r=0;istringstream sin(s);sin>>r;return r;}

template<class T> inline T gcd(T a,T b) {if(a<0)return gcd(-a,b);if(b<0)return gcd(a,-b);return (b==0)?a:gcd(b,a%b);}
template<class T> inline T lcm(T a,T b) {if(a<0)return lcm(-a,b);if(b<0)return lcm(a,-b);return a*(b/gcd(a,b));}
template<class T> inline T sqr(T x){return x*x;}
template<class T> inline T power(T x,T p){if(!p) return 1;return x*power(x,p-1);}

const int mx=0;

int main()
{
     //read("in"); rite("out");
     i64 n,m,a,b;
     while(cin>>n>>m>>a>>b)
     {
         if(a==b || (a==1 && b==n)) puts("1");
         else if(((b/m)-((a-1)/m))<2)
         {
             if(((b/m)-((a-1)/m))==0) puts("1");
             else if(((b/m)-((a-1)/m))==1 && b%m==0) puts("1");
             else if((a-1)%m==0 && ( b%m==0 || b==n) ) puts("1");
             else puts("2");
         }
         else if((a-1)%m==0 && ( b%m==0 || b==n) ) puts("1");
         else if((a-1)%m==0 || b%m==0) puts("2");
         else if((a-1)%m == b%m) puts("2");
         else if(b==n) puts("2");
         else puts("3");
     }
     return 0;
}
