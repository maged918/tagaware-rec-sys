//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#define N 2001
using namespace std;

int f[10][4];
int g[10][10];
int n , m , k , s;

int main(){
    int i , j , x , y;
    cin >> n >> m >> k >> s;
    for (i=1;i<=k;++i)
        for (j=0;j<=3;++j) f[i][j] = -0x7FFFFFFF;
    for (i=1;i<=n;++i)
        for (j=1;j<=m;++j){
            scanf("%d",&x);
            f[x][0] = max(f[x][0],i+j);
            f[x][1] = max(f[x][1],i-j);
            f[x][2] = max(f[x][2],-i+j);
            f[x][3] = max(f[x][3],-i-j);
        }
    memset(g,0,sizeof(g));
    for (i=1;i<=9;++i)
        for (j=1;j<=9;++j){
            g[i][j] = max(g[i][j],f[i][0]+f[j][3]);
            g[i][j] = max(g[i][j],f[i][1]+f[j][2]);
            g[i][j] = max(g[i][j],f[i][2]+f[j][1]);
            g[i][j] = max(g[i][j],f[i][3]+f[j][0]);
        }
    int ans = 0;
    scanf("%d",&x);
    for (i=1;i<s;++i){
        scanf("%d",&y);
        ans = max(ans,g[x][y]);
        x = y;
    }
    cout << ans << endl;
    cin >> n;
    return 0;
}