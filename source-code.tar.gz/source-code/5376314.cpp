//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <vector>
using namespace std;
int n,m,i,j,k,x,y,r,maxx,maxy,minx,miny;
string s[2100];
struct P{
	int x,y;
	P(int x,int y):x(x),y(y) {}
	bool check(int i,int j,int r) {
		if ((x<i)||(x>(i+r))) return false;
		if ((y<j)||(y>(j+r))) return false;
		if ((x==i)||(x==i+r)) return true;
		if ((y==j)||(y==j+r)) return true;
		return false;
	}
};
vector<P> a;
bool find(int x,int y,int r) {
	if (r>min(n,m)) return false;
	if ((x<0)||(y<0)) return false;
	if ((x+r>=n)||(y+r>=m)) return false;
	for (k=0;k<a.size();k++)
		if (!a[k].check(x,y,r)) return false;
	for (int i=0;i<n;i++) {
		for (int j=0;j<m;j++)
			if (s[i][j]!='w')
				if (P(i,j).check(x,y,r)) s[i][j]='+';
		cout << s[i] << endl;
	}
	return true;
}
int main() {
	cin >> n >> m;
	for (i=0;i<n;i++) cin >> s[i];
	maxx=maxy=0;minx=n;miny=m;
	for (i=0;i<n;i++)
		for (j=0;j<m;j++)
			if (s[i][j]=='w') {
				a.push_back(P(i,j));
				maxx=max(maxx,i);
				minx=min(minx,i);
				maxy=max(maxy,j);
				miny=min(miny,j);
			}
	r=max(maxy-miny,maxx-minx);
	x=minx;y=miny;
	if (find(x,y,r)) return 0;
	if (find(n-1-r,y,r)) return 0;
	if (find(x,m-1-r,r)) return 0;
	if (find(x-r,y,r)) return 0;
	if (find(x,y-r,r)) return 0;
	if (find(maxx-r,y,r)) return 0;
	if (find(x,maxy-y,r)) return 0;
	cout << -1 << endl;
	return 0;
}