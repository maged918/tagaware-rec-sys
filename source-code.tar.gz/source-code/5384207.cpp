//Language: GNU C++


//
// d.cpp
//
// Siwakorn Srisakaokul - ping128
// Written on Sunday,  8 December 2013.
//

#include <cstdio>
#include <iostream>
#include <sstream>
#include <cstdlib>
#include <string>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#include <list>
#include <cmath>
#include <algorithm>
#include <map>
#include <ctype.h>
#include <string.h>

#include <assert.h>

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
typedef pair<PII, int> PII2;

#define MAXN 200005

int a[MAXN];
int n;
int next[MAXN];
int ans[MAXN];

int main(){
    scanf("%d", &n);
    for(int i = 1; i <= n; i++ ){
        scanf("%d", &a[i]);
        next[i] = i + 1;
    }

    int Q;
    int oper;
    int x, v;
    scanf("%d", &Q);
    for(int q = 0; q < Q; q++ ){
        scanf("%d", &oper);
        if(oper == 2){
            scanf("%d", &x);
            printf("%d\n", ans[x]);
        } else {
            scanf("%d %d", &x, &v);
            if(v + ans[x] < a[x]){
                ans[x] += v;
            } else {
                v -= (a[x] - ans[x]);
                ans[x] = a[x];
                vector<int> f;
                f.push_back(x);
                while(v){
                    if(x == n + 1){
                        for(int i = 0; i < f.size(); i++ )
                            next[f[i]] = n + 1;
                        break;
                    }
                    int nx = next[x];
                    if(v + ans[nx] < a[nx]){
                        ans[nx] += v;
                        for(int i = 0; i < f.size(); i++ )
                            next[f[i]] = nx;
                        break;
                    } else {
                        f.push_back(nx);
                        v -= (a[nx] - ans[nx]);
                        ans[nx] = a[nx];
                        x = nx;
                    }
                }
            }   
        }
    }
    return 0;
}
