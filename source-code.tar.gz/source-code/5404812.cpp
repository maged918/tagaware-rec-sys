//Language: GNU C++


/**
 * Copyright (c) 2013 Authors. All rights reserved.
 * 
 * FileName: D.cpp
 * Author: Beiyu Li <sysulby@gmail.com>
 * Date: 2013-12-11
 */
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cstring>
#include <cctype>
#include <cmath>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <bitset>
#include <complex>

using namespace std;

typedef long long LL;
typedef pair<int, int> Pii;
typedef complex<double> Point;
typedef complex<double> Vector;
#define X real()
#define Y imag()

const int inf = 0x3f3f3f3f;
const LL infLL = 0x3f3f3f3f3f3f3f3fLL;
const int hash_mod = 1000037;
const double pi = acos(-1);
const double eps = 1e-10;

const int maxn = 200000 + 5;
const LL mod[3] = {1000003, 1000037, 1000000007};

// for a * x + b * y = c
void gcd(LL a, LL b, LL &d, LL &x0, LL &y0)
{
        if (!b) {
                d = a; x0 = 1; y0 = 0;
        } else {
                gcd(b, a % b, d, y0, x0);
                y0 -= x0 * (a / b);
        }
}
// x = x0 * (c / d) + (b / d) * t
// y = y0 * (c / d) - (a / d) * t
// t is integer

// for ax==1(mod m), return -1 if no
LL inv(LL a, LL m = hash_mod)
{
        LL d, x, y;
        gcd(a, m, d, x, y);
        return d == 1? (x + m) % m: -1;
}

// for (a + b) % m
LL add_mod(LL a, LL b, LL m = hash_mod)
{
        return (a + b) % m;
}

// for (a - b) % m
LL sub_mod(LL a, LL b, LL m = hash_mod)
{
        return ((a - b) % m + m) % m;
}

// for (a * b) % m
LL mul_mod(LL a, LL b, LL m = hash_mod)
{
        return a * b % m;
}

// for (a / b) % m
LL div_mod(LL a, LL b, LL m = hash_mod)
{
        return mul_mod(a % m, inv(b, m), m);
}

// for a^p % m
LL pow_mod(LL a, LL b, LL m = hash_mod)
{
        LL res = 1;
        while (b) {
                if (b & 1) res = res * a % m;
                a = a * a % m;
                b >>= 1;
        }
        return res;
}

int n, m, p;
int a[maxn], b[maxn];
LL ha[3], hm[3], ga[3][maxn], gm[3][maxn];
vector<int> vec;

int main()
{
        scanf("%d%d%d", &n, &m, &p);
        for (int i = 0; i < n; ++i)
                scanf("%d", &a[i]);
        for (int j = 0; j < 3; ++j) {
                ha[j] = 0; hm[j] = 1;
        }
        for (int i = 0; i < m; ++i) {
                scanf("%d", &b[i]);
                for (int j = 0; j < 3; ++j) {
                        ha[j] = (ha[j] + b[i]) % mod[j];
                        hm[j] = hm[j] * b[i] % mod[j];
                }
        }
        for (int i = 0; i < p && i + (LL)(m - 1) * p < n; ++i) {
                bool ok = true;
                for (int j = 0; j < 3; ++j) {
                        ga[j][i] = 0;
                        gm[j][i] = 1;
                        for (int k = 0; k < m; ++k) {
                                ga[j][i] = add_mod(ga[j][i], a[i+k*p], mod[j]);
                                gm[j][i] = mul_mod(gm[j][i], a[i+k*p], mod[j]);
                        }
                        if (ga[j][i] != ha[j] || gm[j][i] != hm[j]) ok = false;
                }
                if (ok) vec.push_back(i + 1);
        }
        for (int i = p; i + (LL)(m - 1) * p < n; ++i) {
                bool ok = true;
                int k = i % p;
                for (int j = 0; j < 3; ++j) {
                        ga[j][k] = sub_mod(ga[j][k], a[i-p], mod[j]);
                        ga[j][k] = add_mod(ga[j][k], a[i+(m-1)*p], mod[j]);
                        gm[j][k] = div_mod(gm[j][k], a[i-p], mod[j]);
                        gm[j][k] = mul_mod(gm[j][k], a[i+(m-1)*p], mod[j]);
                        if (ga[j][k] != ha[j] || gm[j][k] != hm[j]) ok = false;
                }
                if (ok) vec.push_back(i + 1);
        }
        printf("%d\n", vec.size());
        for (int i = 0; i < vec.size(); ++i)
                printf("%d ", vec[i]);

        return 0;
}
