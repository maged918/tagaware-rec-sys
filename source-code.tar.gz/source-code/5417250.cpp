//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <queue>
#include <map>
#include <stdio.h>
#include <string.h>
#include <memory.h>

using namespace std;

int main() {
//#ifndef ONLINE_JUDGE
    //freopen("test.in", "rt", stdin);
    //freopen( "test.out" , "wt" , stdout );
//#endif
    int n, k;
    cin >> n >> k;
    for (int i = n; i >= n - k + 1; i--) {
        if (i == n)
            cout << i;
        else
            cout << " " << i;
    }
    if (k == 0)
        cout << 1;
    else
        cout << " " << 1;
    for (int i = 2; i < n - k + 1; i++)
        cout << " " << i;
    cout << endl;
    return 0;
}
