//Language: GNU C++


#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int n;
vector <int> v;

bool check(int m) {
    for(int i = 0; i < m; i++) {
        if(v[i] * 2 > v[n - m + i])
            return 0;
    }
    return 1;
}

int main() {
    cin >> n;
    v.resize(n);
    for(int i = 0; i < n; i++) 
        cin >> v[i];
    sort(v.begin(), v.end());
    int l = 0; 
    int r = n / 2 + 1;

    while(l < r - 1) {
        int m = l + (r - l) / 2;
        if(check(m))
            l = m;
        else 
            r = m;
    }
    cout << n - l;
}
