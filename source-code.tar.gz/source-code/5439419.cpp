//Language: GNU C++


#include <cstdio>
#include <algorithm>

int n,count,_mid,a[500010];

void work(){
    std::sort(a,a+n);
    int mid = (n&1) ? (n-1)>>1 : n>>1;
    _mid = mid,count = 0;

    for (int i=0;i<mid;i++){
        for (int j=_mid;j<n;j++){

            if (2*a[i]<=a[j]){
                a[j] = -1,count++;
                _mid = j+1;
                break;
            }
            if ( _mid==n-1)
                return;
            if (j==n-1)
                return;
        }
    }
}

int main(){
  //  freopen("1.in","r",stdin);
    scanf("%d",&n);
    for (int i=0;i<n;i++)
        scanf("%d",&a[i]);
    work();
    printf("%d\n",n-count);
    return 0;
}
