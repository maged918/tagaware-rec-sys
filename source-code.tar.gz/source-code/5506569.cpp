//Language: GNU C++


#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <map>
#include <queue>
#include <vector>

using namespace std;

#define FOR(prom, a, b) for(int prom = (a); prom < (b); prom++)
#define FORD(prom, a, b) for(int prom = (a); prom > (b); prom--)
#define FORDE(prom, a, b) for(int prom = (a); prom >= (b); prom--)

#define PB push_back
#define MP make_pair

#define MM(co, cim) memset((co), (cim), sizeof((co)))

#define DEB(x) cerr << ">>> " << #x << " : " << x << endl;

int dyn[5007][5007];
string mp[5007];

int main ()
{
  MM(dyn,0);
  int R, C;
  cin >> R >> C;
  FOR(r,0,R) cin >> mp[r];
  FOR(r,0,R) {
  	int e = 0;
  	FOR(b,0,C) {
  		if(e < b) e = b;
  		while(e < C && mp[r][e] == '1') e++;
  		dyn[b][e]++;
  	}
  }
  int mx = 0;
  FOR(c,0,C) {
  	int cnt = 0;
  	FORDE(e,C,c) {
  		cnt += dyn[c][e];
  		mx = max(mx, cnt * (e-c));
  	}
  }
  cout << mx << endl;
  return 0;
}











