//Language: GNU C++


#include <iostream>
#include <cstring>
#include <string>
#include <algorithm>
#include <utility>
#include <cstdio>
#include <vector>
#define mp make_pair
using namespace std;

string str;
int arr_1[3000005],arr_2[3000005],dp[3000005];
int a,b,q;
pair<int,pair<int,int> > fun(int id, int left, int right)
{
    if(left==a && right==b)
        return mp(dp[id],mp(arr_1[id],arr_2[id]));
    else if(left>=a && right<=b)
        return mp(dp[id],mp(arr_1[id],arr_2[id]));
    else if(left>=right)
        return mp(0,mp(0,0));
    else if(left>b)
        return mp(0,mp(0,0));
    else if(right<a)
        return mp(0,mp(0,0));
    pair<int, pair<int,int> > myp1=fun(id*2,left,(left+right)/2);
    pair<int, pair<int,int> > myp2=fun(id*2+1,(left+right)/2+1,right);
    pair<int, pair<int,int> > myp3;
    myp3.first=myp1.first+myp2.first+min(myp1.second.first,myp2.second.second);
    myp3.second.first=myp1.second.first+myp2.second.first-min(myp1.second.first,myp2.second.second);
    myp3.second.second=myp1.second.second+myp2.second.second-min(myp1.second.first,myp2.second.second);
    return myp3;
}

void seg_tree(int id, int left, int right)
{
    if(left==right)
    {
        if(str[left]=='(')
            arr_1[id]=1;
        else
            arr_2[id]=1;
        dp[id]=0;
    }
    else
    {
        seg_tree(id*2,left,(left+right)/2);
        seg_tree(id*2+1,(left+right)/2+1,right);
        dp[id]=dp[id*2]+dp[id*2+1];
        dp[id]+=min(arr_1[id*2],arr_2[id*2+1]);
        arr_1[id]=arr_1[id*2]+arr_1[id*2+1]-min(arr_1[id*2],arr_2[id*2+1]);
        arr_2[id]=arr_2[id*2]+arr_2[id*2+1]-min(arr_1[id*2],arr_2[id*2+1]);
    }
}

int main()
{
    cin>>str;
    int d=str.size();
    seg_tree(1,0,d-1);
    scanf("%d",&q);
    while(q--)
    {
        scanf("%d%d",&a,&b);
        a--; b--;
        pair<int,pair<int,int> > dd=fun(1,0,d-1);
        printf("%d\n",dd.first*2);
    }

  return 0;
}