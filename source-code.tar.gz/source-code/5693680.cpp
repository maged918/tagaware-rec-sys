//Language: GNU C++


#include <cstdio>
#include <iostream>

using namespace std;

char A[2005];
int ctos, debe, va;
long long D[2005][2005], modd=1000000007, suma;

int main()
{
    scanf("%d%d%s",&ctos,&debe,A+1);
    for(int queda=0; queda<=debe; queda++){
        suma=0;
        if(queda==0)
            suma=1;
        for(int dnde=ctos+1; dnde>0; dnde--){
            if(queda==0 and dnde==ctos)
                D[dnde][queda]=A[dnde]-'a'+1;
            else if(dnde>ctos){
                D[dnde][queda]=0;
                if(queda==0)
                    D[dnde][queda]=1;
            }
            else {
                D[dnde][queda]=D[dnde][queda]+suma;
                D[dnde][queda]=D[dnde][queda]%modd;
            }
            suma=suma+D[dnde][queda]*(A[dnde-1]-'a');
            suma=suma%modd;
            va=dnde-1;
            for(int i=queda+ctos-dnde+2; i<=debe and va>0; i+=ctos-dnde+2){
                D[va][i]=D[va][i]+D[dnde][queda]*('z'-A[dnde-1]);
                D[va][i]=D[va][i]%modd;
                --va;
            }
        }
    }
    printf("%I64d\n",D[1][debe]);
    return 0;
}
