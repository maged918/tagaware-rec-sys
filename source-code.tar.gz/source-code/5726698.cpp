//Language: GNU C++0x


#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int TAM = 1000+10;
ll dp_time[TAM], dp_needed[TAM];

ll solve ( int b, const int x, const int w, int needed )
{
	if ( needed <= 0 ) return 0;
	memset ( dp_time, -1, sizeof ( dp_time ) );

	bool skip = true;
	ll t = 0;
	for ( ; needed > 0; t++ )
	{
		if ( b >= x ) {
			b -= x;
			needed--;
		} else b += w-x;//b = w-(x-b);

		if ( dp_time[b] != -1 && skip )
		{
			ll cycle_len = t - dp_time[b];
			ll cycle_val = dp_needed[b] - needed;

			ll times = needed/cycle_val;
			if ( times > 0 ) times--;
			needed -= times*cycle_val;
			t += times*cycle_len;
		
			skip = false;
		}
	
		dp_time[b] = t;
		dp_needed[b] = needed;
	}

	return t;
}

int main ( )
{
	cin.tie(0);
	ios_base::sync_with_stdio(0);

	int a, b, w, x, c;

	cin >> a >> b >> w >> x >> c;

	int needed = c-a;
	cout << solve(b,x,w,needed) << endl;

	return 0;
}
