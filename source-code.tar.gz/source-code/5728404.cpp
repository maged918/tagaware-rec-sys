//Language: MS C++


#include <iostream>
#include <algorithm>
using namespace std;
long long a[100100], n, d=1e9, r, b[5], i, c=1;
int main(){
	cin>>n;
	for(i=0;i<n;++i) cin>>a[i];
	sort(a, a+n);
	if(n==1) cout<<-1;
	else {
		for(i=1;i<n;++i) if(a[i-1]!=a[i]) c=0; 
		if(c) b[r++]=a[0];
		else{
		if(n==2 && (d=a[1]-a[0])%2==0)	b[r++]=a[0]+d/2;
		for(i=1;i<n;++i)	d=min(d, a[i]-a[i-1]);
		for(i=1;i<n;++i)
			if(a[i]-a[i-1]!=d) {
				if(a[i]-a[i-1]!=2*d){ r=1e9; break; }
				b[r++]=a[i-1]+d;
			}
		if(r>1) r=0;
		else if(!r || (r==1 && n==2))
			{	b[r++]=a[0]-d; b[r++]=a[n-1]+d;	}
		}
		sort(b,b+r);
		cout<<r<<endl;
		for(i=0;i<r;++i) cout<<b[i]<<" ";
	}
}

			
		
