//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS
#pragma comment(linker, "/STACK:64000000") 
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <math.h>
#include <conio.h>
#include <utility>
#include <set>
#include <time.h>
#include <list>
#include <typeinfo>
#include <cstdio>
#include <numeric>
#include <limits>
#include <functional>
#include <queue>
#include <stack>
using namespace std;
#define X first
#define Y second
#define sqr(x) ((x) * (x))
#define all(n) (n).begin(), (n).end()
#define srt(c) sort(all(c))
#define clr(x) memset(x, 0, sizeof(x))
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef vector<pii> vpii;
typedef pair<double, double> pdd;
typedef vector<pdd> vpdd;
typedef pair<float, float> pff;
const double PI = acos(-1.0);
const int MOD = (int)1e9 + 7;
typedef float real;
template<class T> inline bool mx(T &a, const T &b) { 
	if(a < b) {
		a = b; 
		return true;
	} 
	return false; 
}
template<class T> inline bool mn(T &a, const T &b) { 
	if(a > b) {
		a = b; 
		return true;
	} 
	return false; 
}

void load(int k = 1) {
	if (k == 1)	{
#ifndef ONLINE_JUDGE
		freopen("../../Common/in", "r", stdin);
		freopen("../../Common/out", "w", stdout);
#endif
	} else if (k == 2) {
		freopen("input.txt", "r", stdin);
		freopen("output.txt", "w", stdout);
	} else {
		freopen("../../Common/in", "w", stdout);
	}
}
// =============================================================================================================================================
const int N = (int)1e3 + 10;
//const int M = 1000;
int A[N];
//
bool done(int n) {
	for (int i = 0; i < n; ++i) {
		if (A[i]) {
			return false;
		}
	}
	return true;
}
const int LEFT = 0, RIGHT = 1;
void solve() {
	int n; cin >> n;
	int c0 = 0, c5 = 0;
	for (int i = 0; i < n; ++i) {
		cin >> A[i];
		c0 += A[i] == 0;
		c5 += A[i] == 5;
	}
	if (!c0) {
		cout << -1;
		return;
	}
	if (c5 < 9) {
		cout << 0;
		return;
	} 
	for (int i = 0; i < c5 / 9 * 9; ++i) {
		cout << 5;
	}
	for (int i = 0; i < c0; ++i) {
		cout << 0;
	}
}
// =============================================================================================================================================
void solve2() {
	load();
}

#define TIME_CHECK

int main() {
#ifndef ONLINE_JUDGE
#ifdef TIME_CHECK
	double c1 = clock();
#endif	
#endif

	load();
	solve();

#ifndef ONLINE_JUDGE
#ifdef TIME_CHECK
	double c2 = clock();
	cout << endl << "time: " << (c2 - c1) / (CLOCKS_PER_SEC / 1000);
#endif
#endif
	return 0;
}