//Language: GNU C++


#include <iostream>
#include<vector>
using namespace std;
vector<char> v;
int a[]={1869,8961,9186,6198,1698,1986,1896};
int b[]={1,3,2,6,4,5};
int c[10]={0};
int main()
{
    int z=0,i;
   string s;
   cin>>s;
   int len=s.length();
   for(i=0;i<len;i++)
   {
     if(s[i] == '0')
     z++;
     else if((s[i] == '1' || s[i] == '6' || s[i] =='8' || s[i] == '9') && (c[s[i]-'0'] == 0))
     {
         c[s[i]-'0']=1;
     }
     else
     {
         v.push_back(s[i]);
     }
   }
   //cout<<v.size()<<endl;
   int d,sum=0;
   d=4;
   for(i=v.size()-1;i>=0;i--)
   {
       sum=sum+(v[i]-'0')*b[d];
       d++;
       if(d == 6)
       d=0;
   }
   sum=sum%7;
   sum=7-sum;
   sum=sum%7;
   for(i=0;i<v.size();i++)
   cout<<v[i];
   cout<<a[sum];
   for(i=0;i<z;i++)
   cout<<'0';
   cout<<endl;
   
   return 0;
}