//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <limits.h>
#include <memory.h>
using namespace std;
int n,m,ms[101][101],cost[101],a,b;
int rez=INT_MAX,st;
bool used[101];

void dfs(int v,int k,int s)
{
    if (k==3)
    {
        if (ms[st][v])
        {rez=min(rez,s);}
    }
    else
    {
        used[v]=true;
        for (int i=1;i<=n;i++)
        {
            if ((ms[v][i])&&(!used[i]))
            {
                dfs(i,k+1,s+cost[i]);
            }
        }
    }
}

int main()
{
    cin>>n>>m;
    memset(ms,0,sizeof ms);
    for (int i=1; i<=n; i++)
    {
        cin>>cost[i];
    }
    for (int i=1; i<=m; i++)
    {
        cin>>a>>b;
        ms[a][b]=1;
        ms[b][a]=1;
    }
    for (int i=1; i<=n; i++)
    {
        memset(used,false,sizeof used);
        st=i;
        dfs(i,1,cost[i]);
    }
    if (rez!=INT_MAX)
    {
        cout<<rez<<endl;
    }
    else
    {
        cout<<"-1"<<endl;
    }
    return 0;
}
