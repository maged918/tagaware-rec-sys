//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>
using namespace std ;

const long long maxm = 1000 * 100 ;
const long long Mod = 1000000007 ;
long long n , m ;
struct interval {
	long long s , t ;
	bool operator < (const interval & b) const {
		if (t != b.t)
			return t < b.t ;
		return s < b.s ;
	}
} a[maxm] ;
vector <long long> wayn  ;
vector <long long> last ;
long long Num (long long p) {
	long long s = a[p].s ;
	long long l = -1 , m , r = last.size()-1 ;
	while (l < r) {
		m = (l+r+1)/2 ;
		if (last[m] < s)
			l = m ;
		else
			r = m-1 ;
	}
	if (r == -1)
		return 0 ;
	if (last[r] < s)
		return wayn[r] ;
	else
		return wayn[l] ;
}
int main() {
	cin >> n >> m ;
	for (long long i = 0 ; i < m ; ++i) {
		cin >> a[i].s >> a[i].t ;
	}
	sort (a , a+m) ;
	wayn.push_back (1) ;
	last.push_back (0) ;
	for (long long i = 0 ; i < m ; ++i) {
		long long p = wayn.back() ;
		if (i == 0 || a[i].t != a[i-1].t) {
			wayn.push_back (wayn.back()) ;
			last.push_back (a[i].t) ;
		}
	//	cout << "! ---> " << wayn.back() << "  &&  " << wayn[wayn.size()-2] << endl ;
		wayn.back() = (wayn.back() + wayn [wayn.size()-2] - Num (i)+Mod)%Mod ;
	//	cout << last.back() << "  " << wayn.back() << endl ;
	}
	if (last.back() != n)
		cout << 0 << endl ;
	else
		cout << (wayn.back()-wayn[wayn.size()-2]+Mod)%Mod << endl ;
	return 0 ;
}
