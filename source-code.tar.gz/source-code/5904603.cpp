//Language: GNU C++


#include <string>
#include <iostream>
using namespace std;

int main(){
    
    string s ;
    cin >> s;
    string sub;
    string mod;
    int ans = 0;
    int lastindex = s.length()-1;
    
    for(int i = lastindex; i > 0 ; i--){
        
        if(s[i] == '0')continue;
        else if(lastindex - i > i-1)break;
        else if(lastindex - i == i-1 && s.substr(0,i) < s.substr(i,lastindex-i+1))break;
        else lastindex = i-1,ans++; 
    }
    cout << ++ans;
    return 0;
}