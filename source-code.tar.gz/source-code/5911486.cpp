//Language: GNU C++0x


#include<cstdio>
#include<algorithm>
#include<iostream>
#include<set>
#define INF 1e7
#define SIZE 1000010
using namespace std;
bool used[SIZE];
int a[SIZE];
int idx[SIZE];
int tree[SIZE];
int n;
void tupdate(int idx,int val)
{
    while(idx <= n)
    {
        tree[idx]+=val;
        idx += (idx & -idx); // add the last non-zero digit
    }
}
int tread(int idx)
{
    int sum = 0;
    while(idx > 0)
    {
        sum+=tree[idx];
        idx -= (idx & -idx); // deduct the last non-zero digit
    }
    return sum;
}

int main()
{
    int k,t;
	
    scanf("%d %d",&n,&k);

    for(int i =1;i<=n;i++)
    {
        scanf("%d",&a[i]);
        idx[ a[i] ] = i;
    }
    for(int i =0;i<k;i++)
    {
        scanf("%d",&t);
        used[t]=true;
    }
    long long sol = 0;
    set<int> s;
    s.insert(0);
    s.insert(n+1);
    for(int i =1;i<=n;i++)
    {
        if(!used[i])
        {
            int l,r;
            r = *s.upper_bound(idx[i]);
            l=  *(--s.upper_bound(idx[i]));
            r--;l++;
         //   cout<<l<<' '<<r<<endl;
            int v = (r-l+1) - (tread(r) - tread(l-1));
            sol+=v;
            tupdate(idx[i],1);
        }
        else
        s.insert(idx[i]);
    }
    cout<<sol<<endl;
    return 0;
}
