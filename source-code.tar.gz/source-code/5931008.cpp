//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

#define rout(n) {cout << #n << '\n'; return 0;}
///#pragma comment(linker, "/STACK:512000000")
# define foreach(i, c) for(__typeof((c).begin()) i = (c).begin(); i != (c).end(); i++)
# define FF first
# define SS second
# define INF (1<<28)
# define sz(a) int((a).size())
# define mp make_pair
# define pb push_back
# define all(c) (c).begin(),(c).end()
# define All(c) (c).begin(),(c).end(),greater<int>()
typedef long double  ld;
typedef long long int ll;
typedef unsigned long long int ull;
typedef vector<int> vi;
typedef vector<vi > vvi;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int MAXN=100+10;

int main()
{
    ios_base::sync_with_stdio(false);
    int n,p,k;  cin>>n>>p>>k;
    if(p-k>1)
        cout<<"<< ";
    for(int i=0;i<k;i++)
        if(p-k+i>0)
            cout<<p-k+i<<' ';
    cout<<'('<<p<<") ";
    for(int i=0;i<k;i++)
        if(p+i+1<=n)
            cout<<p+i+1<<' ';
    if(p+k<n)
        cout<<">>\n";
    return 0;
}

