//Language: GNU C++


#include<cstdio>
#include<algorithm>
using namespace std;
int main()
{
    long long a,b;
    scanf("%I64d%I64d",&a,&b);
    long long ans=a*a-b*b,tot=1,num,cnt;
    for(int i=2; i<=min(a+1,b); ++i)
    {
        num=b/i;
        cnt=i-b%i;
        long long tans=(a-i+2)*(a-i+2)+i-2-num*num*cnt-(num+1)*(num+1)*(i-cnt);
        if(tans>ans)
        {
            ans=tans;
            tot=i;
        }
    }
    printf("%I64d\n",ans);
    if(tot==1)
    {
        for(int i=0; i<a; ++i)
            putchar('o');
        for(int i=0; i<b; ++i)
            putchar('x');
    }
    else
    {
        num=b/tot;
        cnt=tot-b%tot;
        for(int i=0; i<(0<cnt?num:num+1); ++i)
            putchar('x');
        for(int i=1; i<tot-1; ++i)
        {
            putchar('o');
            for(int j=0; j<(i<cnt?num:num+1); ++j)
                putchar('x');
        }
        for(int i=0; i<a-tot+2; ++i)
            putchar('o');
        for(int i=0; i<(tot==cnt?num:num+1); ++i)
            putchar('x');
    }
}
