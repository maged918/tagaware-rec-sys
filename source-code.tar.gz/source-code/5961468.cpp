//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <vector>
#include <set>

using namespace std;

typedef long long LL;
const int INF = 0x3f3f3f3f;
const int maxn = 100010;

int n, m; 

int a[maxn];
set<int>s[20];
set<int>::iterator it, pre, next;
LL ans;

int main()
{
    cin >> n >> m;
    ans = 0;
    int now;
    for (int i = 1; i <= n; i++) scanf("%d",&a[i]);

    for (int j = 0; j <= 18; j++)
    {

        s[j].insert(0);
        s[j].insert(n + 1);
        now = 0;

        for (int i = 1; i <= n; i++)
        {
            if (a[i] & (1 << j)) ans += 1LL * (i - now) * (1 << j);
            else s[j].insert(i), now = i;
        }
    }
    set<int> ss;
    LL tt = 0;
    for (int j = 0; j <= 18; j++)
    {

        ss.insert(0);
        ss.insert(n + 1);
        now = 0;

        for (int i = 1; i <= n; i++)
        {
            if (a[i] & (1 << j)) tt += 1LL * (i - now) * (1 << j);
            else ss.insert(i), now = i;
        }
    }
    while (m--)
    {
        int id, v;
        scanf("%d%d", &id, &v);
        for (int p = 0; p <= 18; p++)
        {
            if (  (a[id] & (1 << p)) == (v & (1 << p)) ) continue;
            else if (a[id] & (1 << p))
            {
                it = s[p].lower_bound(id);
                next = it;
                it--;
                pre = it;
                ans -= 1LL * ((*next) - id) * (id - (*pre)) * (1 << p);
                s[p].insert(id);
            }
            else
            {
                it = s[p].find(id);
                next = s[p].upper_bound(id);
                it--;
                pre = it;
                ans += 1LL * ((*next) - id) * (id - (*pre)) * (1 << p);
                s[p].erase(id);

            }
        }
        a[id] = v;
        cout << ans << endl;
    }

}
