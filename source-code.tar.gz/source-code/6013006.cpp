//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int a[110];

int main()
{
    int n;
    while(scanf("%d",&n)!=EOF)
    {
        int l,r;
        memset(a,0,sizeof(a));

        for(int i=0;i<n;i++)
        {
            scanf("%d%d",&l,&r);
            for(int j=l;j<r;j++)
                a[j]=i+1;
        }

        int cnt=0;
        for(int i=0;i<100;i++)if(a[i]==1) cnt++;
        printf("%d\n",cnt);
    }
    return 0;
}

 	 	 	   		  	  	 			    	