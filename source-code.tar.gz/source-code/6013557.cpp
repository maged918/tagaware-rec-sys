//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <list>
#include <map>
#include <set>
#include <bitset>
#include <string>
#include <iostream>
#include <cassert>
using namespace std;
typedef long long ll;
const double PI = acos(-1);
const double EPS = 1e-7;

#define PB push_back
#define MP make_pair
#define FOR(_i, _from, _to) for (int (_i) = (_from), (_batas) = (_to); (_i) <= (_batas); (_i)++)
#define REP(_i, _n) for (int (_i) = 0, (_batas) = (_n); (_i) < (_batas); (_i)++)
#define SZ(_x) ((int)(_x).size())

const int MAX_NCK = 15000;
const int MAX_N = 500;

const ll MOD = 1000000007;

map<int, int> primeFactors;
int data[MAX_N + 5];

ll nck[MAX_NCK + 5][MAX_N + 5];

void initNck() {
	nck[0][0] = 1LL;
	FOR(i, 1, MAX_NCK) {
		nck[i][0] = 1LL;
		FOR(j, 1, min(i, MAX_N)) nck[i][j] = (nck[i-1][j] + nck[i-1][j-1]) % MOD;
	}
}

int main() {
	initNck();
	
	int N;
	cin >> N;
	REP(i, N) cin >> data[i];
	
	REP(i, N) {
		if (data[i] < 2) continue;
		int tmp = data[i];
		for (int j = 2; j*j <= tmp; j++) {
			if (tmp % j == 0) {
				int &lho = primeFactors[j];
				while(tmp % j == 0) tmp /= j, lho++;
			}
		}
		if (tmp != 1) primeFactors[tmp]++;
	}
	
	ll ans = 1;
	for (map<int, int>::iterator it = primeFactors.begin(); it != primeFactors.end(); ++it) {
		//cout << "(" << it->first << ", " << it->second << ")" << endl;
		ans *= nck[(N-1) + it->second][(N-1)];
		ans %= MOD;
		//cout << "ans = " << ans << endl;
	}
	
	cout << ans << endl;
	return 0;
}
