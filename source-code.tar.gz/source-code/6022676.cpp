//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;

int main()
{
//femOZeCArKCpUiHYnbBPTIOFmsHmcpObtPYcLCdjFrUMIyqYzAokKUiiKZRouZiNMoiOuGVoQzaaCAOkquRjmmKKElLNqCnhGdQM
    char X[200];
    cin>>X;
    int k=0;
    char R[200];
    for(int i=0; i<strlen(X); i++)
    {
        int xi=(int)X[i];
        if(xi!=97 && xi!=101 && xi!=105 && xi!=111 && xi!=117 && xi!=121 && xi!=97-32 &&
           xi!=101-32 && xi!=105-32 && xi!=111-32 && xi!=117-32 && xi!=121-32)
        {
            if(xi>=65 && xi<=90)
            {
                xi+=32;
                R[k]=(char)(46);
                k++;
                //cout<<endl<<"adding "<<(char)46<<endl;
            }
            else if(xi>=97 && xi<=122)
            {
                R[k]=(char)46;
                k++;
                //cout<<endl<<"adding "<<(char)46<<endl;
            }
            R[k]=(char)xi;
            //cout<<" processed "<<R[k]<<endl;
            k++;
        }

    }
    for(int i=0; i<k; i++)
    {
        cout<<R[i];
    }
    cout<<endl;
    return 0;
}
