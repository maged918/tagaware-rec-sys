//Language: GNU C++0x


#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <functional>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <stdio.h>
#include <string>
#include <string.h>
#include <vector>

typedef long long LL;

int IntMaxVal = (int) 1e20;
LL LongMaxVal = (LL) 1e20;

#define FOR(i, a, b) for(int i = a; i < b + 1; ++i)
#define FORD(i, a, b) for(int i = a; i >= b; --i)

#define minimize(a, b) { a = min(a, b); }
#define maximize(a, b) { a = max(a, b); }

#define next(type, i) type i; cin >> i;
#define nextVector(type, v, size) vector<type> v(size); { for (int i = 0 ; i < size ; i++) cin >> v[i]; }

using namespace std;

map<string, int> types;

int main() {
    ios_base::sync_with_stdio(false);
    next(int, n);
    string err = "errtype";
    types["void"] = 0;
    while (n --> 0) {
    	next(string, op);
    	if (op == "typedef") {
    		next(string, t);
    		next(string, name);
    		int i1 = 0;
    		while (t[i1] == '&') i1++;
    		int i2 = t.length() - 1;
    		while (t[i2] == '*') i2--;
    		int modificator = t.length() - 1 - i2 - i1;
    		t = t.substr(i1, i2 - i1 + 1);
    		int newType;
    		if (t == err || !types.count(t)) newType = -1;
    		else {
    			newType = types[t];
    			if (newType != -1) newType += modificator;
    			if (newType < 0) newType = -1;
    		}
   			types[name] = newType;
    	} else {
    		next(string, t);

    		int i1 = 0;
    		while (t[i1] == '&') i1++;
    		int i2 = t.length() - 1;
    		while (t[i2] == '*') i2--;
    		int modificator = t.length() - 1 - i2 - i1;
    		t = t.substr(i1, i2 - i1 + 1);


    		if (!types.count(t)) cout << err;
    		else {
    			int type = types[t];
    			if (type == -1 || type + modificator < 0) cout << err;
    			else {
					type += modificator;
    				cout << "void";
    				FOR (i, 0, type - 1) cout << '*';
    			}
    		}
    		cout << '\n';
    	}
    }
}