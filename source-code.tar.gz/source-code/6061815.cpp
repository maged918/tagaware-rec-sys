//Language: GNU C++


#include<vector>
#include<cstring>
#include<algorithm>
#include<stdio.h>
#include<climits>
#include<set>
#include<cmath>
#include<list>
#include<bitset>
#include<map>
#include<iostream>
#include<queue>
#define test(t) while(t--)
#define s(n) scanf("%d",&n)
#define sl(n) scanf("%lld",&n)

#define p(n) printf("%d\n",n)
#define rep(i,a,n) for(i=a;i<=n;i++)
#define vi vector<int>
#define vii vector< vector<int> >
#define vpii vector< pair<int,int> >
#define mii map<int,int>
#define pb push_back
#define inf 1000000000LL
#define mp make_pair
#define imax (int) 1000000007
//#define inf 100000000
#define ill unsigned long long
#define gc getchar_unlocked
using namespace std;
int main()
{
	bool mark[26][26];
	int i,j;
	int t;
	s(t);
	while(t--)
	{
	for(i=1;i<=24;++i)
	{
		for(j=1;j<=24;++j)
		{
			mark[i][j]=false;
		}
	}
	int cnt;
	int n,p;
	s(n);s(p);
	for(i=1;i<=n;++i)
	{
		cnt=0;
		for(j=1;j<=n;++j)
		{
			if(mark[i][j]==false && i!=j)
			{
				mark[i][j]=mark[j][i]=true;
				cnt++;
			}
			if(cnt==2)
			break;
		}
	}
	cnt=0;
	for(i=1;i<=n;++i)
	{
		for(j=1;j<=n;++j)
		{
			if(mark[i][j]==false && i!=j)
			{
				mark[i][j]=mark[j][i]=true;
				cnt++;
			}
			if(cnt==p)
			break;
		}
		if(cnt==p)
		break;
	}
	for(i=1;i<=n;++i)
	{
		for(j=i+1;j<=n;++j)
		{
			if(mark[i][j]==true && i!=j)
			{
				printf("%d %d\n",i,j);
			}
		}
	}
 }
	return 0;
}
