//Language: GNU C++0x


#include <cmath>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <cassert>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <algorithm>
#ifdef LOCAL
#define eprintf(...) fprintf(stderr, __VA_ARGS__)
#else
#define eprintf(...) static_cast<void>(0)
#endif
#define endl '\n'
#define sz(c) ((int) (c).size())
#define pb push_back
#define mp make_pair
typedef long long int64;

using namespace std;

double dp[2222][2222];

int main() {
  int n, m;
  scanf("%d %d", &n, &m);
  set<int> cols, rows;
  for (int i = 0; i < m; ++i) {
    int r, c;
    scanf("%d %d", &r, &c);
    cols.insert(c);
    rows.insert(r);
  }
  int R = n - sz(rows);
  int C = n - sz(cols);
  dp[0][0] = 0;
  for (int i = 0; i <= R; ++i)
    for (int j = 0; j <= C; ++j) {
      if (i == 0 && j == 0)
        continue;
      double pUnRow = (double)i / n;
      double pUnCol = (double)j / n;
      dp[i][j] = 1;
      if (i > 0)
        dp[i][j] += pUnRow * (1 - pUnCol) * dp[i - 1][j];
      if (j > 0)
        dp[i][j] += (1 - pUnRow) * pUnCol * dp[i][j - 1];
      if (i > 0 && j > 0)
        dp[i][j] += pUnRow * pUnCol * dp[i - 1][j - 1];
      dp[i][j] = dp[i][j] / (1 - (1 - pUnRow) * (1 - pUnCol));
    }
  printf("%.10lf\n", dp[R][C]);
  return 0;
}
