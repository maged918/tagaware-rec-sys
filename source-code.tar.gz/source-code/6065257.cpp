//Language: GNU C++


/* Divanshu Garg */

#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <climits>
#include <cctype>
#include <cassert>

using namespace std;

#define ull unsigned long long
#define ill long long int
#define pii pair<int,int>
#define pb(x) push_back(x)
#define F(i,a,n) for(int i=(a);i<(n);++i)
#define FD(i,a,n) for(int i=(a);i>=(n);--i)
#define FE(it,x) for(it=x.begin();it!=x.end();++it)
#define V(x) vector<x>
#define S(x) scanf("%d",&x)
#define Sl(x) scanf("%lld",&x)
#define M(x,i) memset(x,i,sizeof(x))
#define debug(i,sz,x) F(i,0,sz){cout<<x[i]<<" ";}cout<<endl
ill ABS(ill a) { if ( a < 0 ) return (-a); return a; }
#define fr first
#define se second

/* Relevant code begins here */

/* Input from file or online */

void input() {
#ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
#endif
}

/* Input opener ends */

#define gc getchar//_unlocked
void readInt(int &n) {
    n = 0;
    char ch = gc();
    while ( !isdigit(ch) ) ch = gc();
    while ( isdigit(ch) ) {
        n = n*10 + ch-48;
        ch = gc();
    }
}

ill dp[1<<19][101];

int main() {
    input();
    ill n; int m; 
    string s;
    cin >> s >> m;
    // cout << n << m << endl;
    int digits = s.size();
    vector<int> d;
    F(i,0,s.size()) d.pb(s[i]-'0');
    // F(i,0,d.size()) cout << d[i] << " "; cout << endl;
    vector<int> v[19];
    vector< vector<int> > vv[19];
    int mx = (1<<digits);
    F(i,0,mx) {
        int c = 0;
        vector<int> on;
        F(j,0,digits) {
            if ( (i&(1<<j)) > 0 ) {
                 c++;
            } else on.pb(j);
        }
        bool good = 1;
        F(j,0,on.size()) {
            F(k,on[j]+1,digits) if ( ( (i&(1<<k)) > 0 ) && d[on[j]] == d[k] ) {
                good = 0; break;
            } if ( !good ) break;
        }
        if ( !good ) continue;
        v[c].pb(i);
        vv[c].pb(on);
    }
    // F(i,0,digits+1){
    //  // F(j,0,v[i].size()) cout << v[i][j] << " "; cout << endl;
    //  cout << v[i].size() << endl;
    // }
    F(i,0,m) dp[(1<<digits)-1][i] = 0;
    dp[(1<<digits)-1][0] = 1;

    FD(left,digits-1,0) {
        F(i,0,vv[left].size()) {
            int num = v[left][i];
            F(j,0,m) {
                dp[num][j] = 0;
            }       
            F(j,0,vv[left][i].size()) {
                int val = vv[left][i][j];
                if ( left == 0 && d[val] == 0 ) continue;
                F(k,0,m) {
                    dp[num][k] += dp[(num|(1<<val))][(k*10+d[val])%m];
                }
            }
        }
    }

    cout << dp[0][0] << endl;
    return 0;
}
