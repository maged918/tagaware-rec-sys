//Language: GNU C++


#define _CRT_SECURE_NO_WARNINGS
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <math.h>
#include <vector>
#include <string>
#include <stdio.h>
#include <time.h>
#include <sstream>
#include <cstdlib>
#include <string.h>
#include <limits.h>
#include <iostream>
#include <algorithm>
#include <functional>
//#include <bits/stdc++.h>
using namespace std;

#define M 1010
#define N 37
#define in "in.in"
#define out "out.in"
#define mp make_pair
#define si(a) scanf("%d",&a)
#define sc(a) scanf(" %c",&a)
#define sst(s) scanf("%s",s)
#define read freopen("in.in","r",stdin)
#define write freopen("out.i","w",stdout)
#define si2(a,b) scanf("%d%d",&a,&b)
#define rep(i,a,b) for(int i=a;i<b;++i)
#define rep_(i,a,b) for(int i=a;i>=b;--i)
#define Set(a,b) memset(a,b,sizeof a)
#define si3(a,b,c) scanf("%d%d%d",&a,&b,&c)
#define All(s) s.begin(),s.end()
#define Sz(a) a.size()

#define lli long long int
#define llu unsigned long long
#define Mit map<int ,int>::iterator
#define Sit set<char>::iterator
#define Vi vector<int>
#define Si set<lli>

#define _ ios_base::sync_with_stdio(0);cin.tie(0);

#define Vname(A) #A

#define Bug puts("bug")

int geti(){ int x; si(x); return x; }
int gcd(int a, int b){ return (a == 0) ? b : (b == 0) ? a : (a%b == 0) ? b : gcd(b, a%b); }

int div_str(char s[], int a){
    int y = 0, ln = strlen(s);
    rep(i, 0, ln) y = ((y * 10) + (s[i] - '0')) % a;
    return y;
}

int dx[] = { 1, 0, -1, 0 };
int dy[] = { 0, 1, 0, -1 };

char grid[305][305];

int main()
{
    //read;

    int n, f = 1;
    char s;
    si(n);
    rep(i, 0, n)rep(j, 0, n){ scanf(" %c", &grid[i][j]);  if (grid[i][j] != grid[0][0])s = grid[i][j]; }

    rep(i, 0, n)f &= (grid[i][i] == grid[0][0]);
    for (int i = n - 1; i >= 0; --i)f &= (grid[i][n - i - 1] == grid[0][0]);

    rep(i, 0, n)rep(j, 0, n)if (i != j && i != n - j - 1)f &= ((grid[i][j]) == s);
    printf("%s\n", (f) ? "YES" : "NO");

    return 0;
}
