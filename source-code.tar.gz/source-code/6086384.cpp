//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;

const int maxn = 1000 + 10;
int a[maxn];

int main()
{
    int n, k, i, j;
    while (scanf("%d%d", &n, &k) != EOF)
    {
        for (i = 1; i <= n; i++)
            scanf("%d", &a[i]);
        int p, tmp, cnt, mini;
        p = -1, mini = maxn;
        for (i = 1; i <= 1000; i++)
        {
            tmp = i, cnt = 0;
            for (j = 1; j <= n; j++)
            {
                if (a[j] != tmp)
                    cnt++;
                tmp += k;
            }
            if (cnt <= mini)
            {
                mini = cnt;
                p = i;
            }
        }
        printf("%d\n", mini);
        for (i = 1; i <= n; i++)
        {
            if (p != a[i])
            {
                if (p > a[i])
                    printf("+ %d %d\n", i, p-a[i]);
                else
                    printf("- %d %d\n", i, a[i]-p);
            }
            p += k;
        }
    }
    return 0;
}
