//Language: GNU C++


#include <iostream>
#include <algorithm>
using namespace std;
int i, n, m, k, l=1,p, n1[101];

//257A 
main ()
{
    cin>>n>>m>>k;
    
    for(i=0; i<n; i++)
        {
            cin>>n1[i];
        }
    
    
    if(m<=k)
        {
            cout<<"0";
            return 0;
        }
    sort(n1, n1+n);
    reverse(n1,n1+n);
    p=k+n1[0]-1;
    for(i=1; i<n; i++)
        {
            if(p>=m)
                {
                    cout<<l;
                    return 0;
                }
            else {
                p=p+n1[i]-1;
                l++;
            }
        }
        
    if(p<m)
        {
            cout<<"-1";
            return 0;
        }
        
    
    if(p>=m) cout<<l;
    
}