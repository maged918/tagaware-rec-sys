//Language: GNU C++


#include<stdio.h>
#include<string.h>
int k[1000];
int main()
{
    int i,j,n,x,tans,ans;
    ans = 1000000;
    tans = 0;
    scanf("%d",&n);
    memset(k,0,sizeof(k));
    for(i = 1; i <= n; i++)
    scanf("%d",&k[i]);
    for(i = 1; i <= n; i++)
    {
        tans = 0;
        for(j = 1; j <= k[i]; j++)
        {
            scanf("%d",&x);
            tans += 5*x;
        }
        tans += 15*k[i];
        if(tans < ans)
           ans = tans;
    }
    printf("%d\n",ans);
    return 0;
}
