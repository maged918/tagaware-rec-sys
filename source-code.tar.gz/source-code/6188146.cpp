//Language: GNU C++


#include <iostream>
#include <cstdio>

using namespace std;

typedef long long ll;

ll arr[1010],d[1010];

const ll mod=1e9+7;

int main()
{
	int n;
	cin>>n;
	ll in;
	for(int i=1;i<=n;++i)
	{
		cin>>in;
		if(in==i) arr[i]=2;
		else
		{
			for(int j=in;j<i;++j)
				arr[i]=(arr[i]+arr[j])%mod;
			arr[i]=(arr[i]+2)%mod;
		}
	}
	ll sum=0;
	for(int i=1;i<=n;++i)
		sum=(sum+arr[i])%mod;
	cout<<sum<<endl;
	return 0;
}
