//Language: MS C++


#include<cstdio>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<string>
#include<map>
#include<vector>
#include<set>
#include<queue>
#include<stack>
#pragma comment(linker, "/STACK:102400000,102400000")
#ifndef ONLINE_JUDGE
#define scanf scanf_s
#endif
using namespace std;
typedef long long LL;
#define lson l,mid,id<<1
#define rson mid+1,r,id<<1|1;
#define lowbit(x) (x&(-x))
const int MOD = 1000000007;
const int MAX_N = 2005;
int dp[MAX_N][MAX_N];
void DP(int n, int k){
	dp[0][1] = 1;
	for (int i = 1; i <= k; i++){
		for (int j = 1; j <= n; j++){
			for (int l = 1; j*l <= n; l++){
				dp[i][l*j] += dp[i - 1][j];
				while (dp[i][l*j] >= MOD){
					dp[i][l*j] -= MOD;
				}
			}
		}
	}
}
int main(){
	int n, k;
	cin >> n >> k;
	DP(n, k);
	int ans = 0;
	for (int i = 1; i <= n; i++){
		ans += dp[k][i];
		ans %= MOD;
	}
	cout << ans << endl;
#ifndef ONLINE_JUDGE
	system("pause");
#endif
	return 0;
}