//Language: GNU C++


#include <algorithm>
#include <stdio.h>
#include <memory.h>
#include <queue>

using namespace std;
#define NN 100000

typedef long long int64;
typedef pair<int64, int64> pii;
typedef pair<int64, pii> node;
typedef priority_queue<node> PQ;

PQ q;
int num, n;
int64 p[NN], t[NN], s[NN], fin[NN];
int64 id[NN];

bool cmp(int u, int v) {
	return t[u]<t[v];
}

int64 calc(int64 pr) {
	int64 j, i, pp, ss, ii, et;
	node f;
	p[num]=pr;
	q=PQ();
	for (j=0; j<n; j++) {
		i=id[j];
		while (!q.empty()) {
			f=q.top(); q.pop();
			pp=f.first; ss=f.second.first; ii=f.second.second;
			if (ss<=t[i]-et) {
				fin[ii]=et+ss; et+=ss;
			} else {
				ss-=t[i]-et; et=t[i];
				q.push(node(pp, pii(ss, ii)));
				break;
			}
		}
		if (q.empty()) et=t[i];
		q.push(node(p[i], pii(s[i], i)));
	}
	while (!q.empty()) {
		f=q.top(); q.pop();
		pp=f.first; ss=f.second.first; ii=f.second.second;
		fin[ii]=et+ss;
		et+=ss;
	}
	return fin[num];
}

int64 tp[NN], qr[NN];

int main() {
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

	int i;
	int64 T, m, ans, low, high, mid, tm;
	scanf("%d", &n);
	for (i=0; i<n; i++) {
		scanf("%I64d%I64d%I64d", t+i, s+i, p+i);
		tp[i]=p[i]; id[i]=i;
	}
	sort(id, id+n, cmp);
	scanf("%I64d", &T);
	for (i=0; i<n; i++) if (p[i]==-1) break;
	num=i;
	sort(tp, tp+n);
	tp[n]=tp[n-1]+2;
	m=0;
	if (tp[1]!=1) qr[m++]=1;
	for (i=1; i<n; i++) if (tp[i]+1!=tp[i+1]) qr[m++]=tp[i]+1;
	ans=-1;
	low=0; high=m-1;
	while (high-low>1) {
		mid=(high+low)/2;
		tm=calc(qr[mid]);
		if (tm==T) { ans=qr[mid]; break; }
		if (tm>T) low=mid;
		else high=mid;
	}
	if (ans==-1) {
		tm=calc(qr[low]);
		if (tm==T) ans=qr[low]; 
		else {
			ans=qr[high];
			tm=calc(ans);
		}
	}
	printf("%I64d\n", ans);
	for (i=0; i<n; i++) {
		if (i) printf(" ");
		printf("%I64d", fin[i]);
	}
	puts("");
	return 0;
}
