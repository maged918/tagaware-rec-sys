//Language: GNU C++


#include<iostream>
#include<string>
using namespace std;

main()
{
	string s;
	int n,i,l,r;
	cin>>s>>n;
	int d[100000]={0},a=0;
	d[0]=0;
	for(i=0;i<s.size()-1;i++)
	{
		if(s[i]==s[i+1]) d[i+1]=d[i]+1;
		else d[i+1]=d[i];
	}
	
	
	for(i=1;i<=n;i++)
	{
		cin>>l>>r;
		cout<<d[r-1]-d[l-1]<<endl;
	}
}
