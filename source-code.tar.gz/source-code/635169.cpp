//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <string>
#include <deque>
#include <stack>
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <limits.h>
#include <time.h>
#include <string.h>
using namespace std;

int lowbit(int t){return t&(-t);}
int countbit(int t){return (t==0)?0:(1+countbit(t&(t-1)));}
int gcd(int a,int b){return (b==0)?a:gcd(b,a%b);}
#define LL long long
#define PI acos(-1.0)
#define N  100001
#define Max INT_MAX
#define Min INT_MIN
#define eps 1e-8
#define FRE freopen("a.txt","r",stdin)
int a[N];
int main(){
    int n;
    while(scanf("%d",&n)!=EOF){
        int i,j;
        for(i=0;i<n;i++)
            scanf("%d",&a[i]);
        sort(a,a+n);
        int tag=0;
        for(i=0;i<n-1 && !tag;i++)
        if(a[i]!=a[i+1] && 2*a[i]>a[i+1])
        tag=1;
        if(tag)puts("YES");
        else
        puts("NO");
    }
    return 0;
}



