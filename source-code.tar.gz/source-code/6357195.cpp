//Language: GNU C++


#include <cstdio>
#include <algorithm>
using namespace std;
int paint[50001][10];
int main(){
    int m,n;
    scanf("%d%d",&m,&n);
    for(int i=1;i<=m;i++)
        for(int j=1;j<=n;j++)
            scanf("%d",&paint[i][j]);
   for(int i=2;i<=n;i++) paint[1][i]+=paint[1][i-1];
   for(int i=2;i<=m;i++) paint[i][1]+=paint[i-1][1];
   printf("%d ",paint[1][n]);
   for(int i=2;i<=m;i++){
      for(int j=2;j<=n;j++){
           paint[i][j]+=max(0,paint[i][j-1]-paint[i-1][j])+paint[i-1][j];
      }
      printf("%d ",paint[i][n]);
   }
   return 0;
}
