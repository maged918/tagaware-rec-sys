//Language: MS C++


#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <cstdio>
#include <queue>
#include <stack>
#include <cmath>

using namespace std;


int main()
{
	int n, m, a, b = 0, t;
	scanf("%d", &n);
	int ans = 1;
	for (int i = 0; i < n; i++) {
		scanf("%d", &a);
		if (i != 0 && a != b) ans++;
		b = a;		
	}
	cout << ans << endl;
	return 0;
}
  	 		   			 	 			 				  	