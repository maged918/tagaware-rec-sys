//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

#define GCD(a,b) __gcd(a, b)
#define mp make_pair
#define DEBUG(x) cout << x << "\n"

int dudes[100100];
int n, x, k;
int main() {
    ios_base::sync_with_stdio(false);
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> x >> k;
        if (x > dudes[k]) {
            cout << "NO\n";
            return 0;
        }
        if (x == dudes[k]) {
            dudes[k]++;
        }
    }
    cout << "YES\n";
}