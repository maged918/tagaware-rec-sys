//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <stack>
#include <queue>
#include <vector>
using namespace std;
struct node
{
    __int64 x,k,m;
};
node a[200];
__int64 i,j,n,m,b,mm,w,cost,dp[2100000];
bool cmp(node x1,node x2)
{
    return x1.k<x2.k;
}
int main()
{
    while (~scanf(" %I64d %I64d %I64d",&n,&m,&b))
    {
        memset(a,0,sizeof(a));
        for (i=1;i<=n;i++)
        {
            scanf(" %I64d %I64d %I64d",&a[i].x,&a[i].k,&mm);
            for (j=1;j<=mm;j++)
            {
                scanf(" %I64d",&w);
                a[i].m=a[i].m|(1<<(w-1));
            }
        }
        sort(a+1,a+1+n,cmp);
        memset(dp,-1,sizeof(dp));
        cost=-1; dp[0]=0;
        for (i=1;i<=n;i++)
        {
            for (j=(1<<m)-1;j>=0;j--)
            if (dp[j]!=-1)
            {
                if (dp[j|a[i].m]==-1)
                dp[j|a[i].m]=dp[j]+a[i].x;
                dp[j|a[i].m]=min(dp[j|a[i].m],dp[j]+a[i].x);
            }
            if (dp[(1<<m)-1]!=-1)
            {
                if (cost==-1) cost=dp[(1<<m)-1]+a[i].k*b;
                else cost=min(cost,dp[(1<<m)-1]+a[i].k*b);
            }
        }
        printf("%I64d\n",cost);
    }
    return 0;
}
