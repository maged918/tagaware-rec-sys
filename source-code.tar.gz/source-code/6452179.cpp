//Language: GNU C++


#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>

using namespace std;

const int T=1e5+5;

struct node
{
    int x,num;
}t;

vector < node > Q[T];
bool flag[T];

int dfs( int now )
{
    int l=(int)Q[now].size(),r,v1,v2;
    node k;
    queue < int > q;   // 注意==>是每个节点都有一个队列
    for(int i=0;i<l;i++)
    {
        k=Q[now][i];
        if( flag[k.num] ) continue;
        flag[k.num]=1;
        r = dfs( k.x );
        if( r ) printf("%d %d %d\n",now,k.x,r); // 说明 now 节点的子节点有一条未用的边
        else q.push( k.x );  //否则将这个节点存入到队列里
    }
    while( q.size() >= 2 )
    {
        v1=q.front();
        q.pop();
        v2=q.front();
        q.pop();
        printf("%d %d %d\n",v1,now,v2);
    }
    if( !q.empty() )
    {
        v1=q.front();
        return v1;  // 如果队列里面有剩余，则将此队列里的点返回回去和其父节点，父节点的父节点构成一个子图
    }
    return 0;
}

int main( )
{
    int n,m,a,b;
    while(~scanf("%d%d",&n,&m))
    {
        for(int i=0;i<=n;i++)
            Q[i].clear();
        for(int i=1;i<=m;i++)
        {
            scanf("%d%d",&a,&b);
            t.num=i;
            t.x=b;
            Q[a].push_back( t );
            t.x=a;
            Q[b].push_back( t );
        }
        if( m%2 ) printf("No solution\n");
        else{

            memset(flag,0,sizeof(flag));
            dfs( 1);
        }
    }
    return 0;
}

 	  						  	   		 	 		