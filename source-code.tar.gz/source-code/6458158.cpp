//Language: GNU C++


//IN THE NAME OF GOD
//BENYAM1N

#include <iostream>
#include <set>
#include <cstring>
#include <algorithm>
#include <string>
#include <fstream>
#include <cmath>
#include <queue>
#include <vector>
#include <map>
#include <set>

using namespace std;

#define lc(x) 2*x
#define rc(x) 2*x+1

const int MAX_N = 1000000+10;

typedef pair<int,int> pii;
typedef long long ll;

bool mark[MAX_N];
pair<bool,int>a[MAX_N];
int dp[MAX_N],dp1[MAX_N],aza[MAX_N];
int n,m;

int main()
{
    cin>>n>>m;

    for(int i = 0 ; i < MAX_N ; i++) mark[i] = true;
    for(int i = 1 ; i <= m ; i++)
    {
        char b;
        cin>>b>>a[i].second;
        if(b == '+')
        {
            a[i].first = true;
            dp1[a[i].second] = i;
        }
        else
        {
            dp[a[i].second] = i;
            a[i].first = false;
        }
    }
    if(m == 1)
    {
        int ans = 0;
    for(int i = 1 ; i <= n ; i++) if(mark[i]) ans++;
    cout<<ans<<endl;
    for(int i = 1 ; i <= n ; i++) if(mark[i]) cout<<i<<" ";

        return 0;
    }
    int p = 0;
    for(int i = 1 ; i <= n ; i++) if(dp1[i] > dp[i]) p++;
    aza[m] = p;
    for(int i = m-1 ; i >= 0 ; i--)
    {
        if(a[i+1].first == false) aza[i] = aza[i+1]+1;
        if(a[i+1].first == true)  aza[i] = aza[i+1]-1;
    }
    for(int i = 1 ; i <= m ; i++)
    {
        if(i == 1)
        {
            if(a[i].first == false)
            {
                if(a[i+1].second != a[i].second ||  aza[i] > 0) mark[a[i].second] = false;
                if(mark[a[i].second]) i++;
            }
            else
            {
                if(aza[i] > 1 ) mark[a[i].second] = false;
            }
            continue;
        }
        if(i == m)
        {

            if(a[i].first == true)
            {
                mark[a[i].second] = false;
                continue;
            }
            bool k;
            int u;
            bool sw = false;
            for(int j = 1 ; j <= m ; j++)
            {
                if(j!=m)
                {
                    if(a[j].second == a[m].second)
                    {
                        k = a[j].first;
                        u = j;
                        break;
                    }
                }
                if(j == m) sw = true;
            }
            if( u == 1)
            {
                if(aza[i] > 0 ) mark[a[i].second] = false;
                continue;
            }
            if(sw)
            {
                if(aza[i] > 0) mark[a[i].second] = false;
                continue;
            }
            k = !k;
            //cout<<u<<" ";

            if(k == false)
            {
                mark[a[i].second] = false;
                continue;
            }
            for(int j = 1 ; j <= m ; j++)
            {
                if(a[j].second == a[m].second)
                {
                    k = !k;
                    if(k == false && aza[j] > 0)
                    {
                        mark[a[j].second] = false;
                        break;
                    }
                }
            }
            continue;


        }
        if(a[i].first == true)
        {
            mark[a[i].second] = false;
        }
        if(a[i].first == false)
        {
            if(aza[i] > 0 || a[i+1].second != a[i].second) mark[a[i].second] = false;
            if(mark[a[i].second] == true) i++;
        }
    }
    int ans = 0;
    for(int i = 1 ; i <= n ; i++) if(mark[i]) ans++;
    cout<<ans<<endl;
    for(int i = 1 ; i <= n ; i++) if(mark[i]) cout<<i<<" ";


}
