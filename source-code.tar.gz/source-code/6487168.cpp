//Language: GNU C++


#include<cstdio>
#include<algorithm>
using namespace std;
int a[1000005];
int main(){
	int n,s;
	int max=0,sum=0;
	scanf("%d%d",&n,&s);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]>max) max=a[i];
		sum+=a[i];
	}
	if(s>=sum-max) printf("YES\n");
	else printf("NO\n");
	return 0;
} 