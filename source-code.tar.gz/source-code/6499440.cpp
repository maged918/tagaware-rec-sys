//Language: GNU C++


//#pragma comment(linker,"/STACK:102400000,102400000")
#include<stdio.h>
#include<iostream>
#include<string.h>
#include<queue>
#include<algorithm>
#include<string>
#include<map>
#include<set>
#include<fstream>
#include<cmath>
#include<iomanip>
using namespace std;
//#define eprintf(...) fprintf (stderr, __VA_ARGS__)
#define ll long long
#define ull unsigned long long
#define inf 2000000007
#define mod 1000000007
#define pii pair<int,int>
#define vi vector<int>
#define VS vector<string>
#define all(x) x.begin(),x.end()
#define mp make_pair
#define pb push_back
#define x first
#define y second
#define N 100010
#define pi 3.14159265358979323846
#define DBG(vari) cerr<<#vari<<"="<<(vari)<<endl;
#define FOREACH(i,t) for(typeof(t.begin()) i=t.begin();i!=t.end();i++)

int a[110][110],dp[101][1<<10],n,m;
int solve()
{
    int i,j,k;
    int ans=inf;
    for(i=0;i<n;i++)
    {
        int res=0;
        for(j=0;j<n;j++)
        {
            int p=0;
            for(k=0;k<m;k++)
            if(a[i][k]!=a[j][k])p++;
            res+=min(p,m-p);
        }
        ans=min(ans,res);
    }
    return ans;
}
void update(int &a,int b){if(a==-1||a>b)a=b;}
int main()
{   
    int i,j,k;
    while(~scanf("%d%d%d",&n,&m,&k))
    {
        for(i=0;i<n;i++)
        for(j=0;j<m;j++)scanf("%d",&a[i][j]);
        int ans=inf;
        if(n<=10)
        {
            memset(dp,-1,sizeof(dp));
            for(i=0;i<1<<n;i++)dp[0][i]=0;
            for(i=0;i<m;i++)
            for(j=0;j<1<<n;j++)
            if(dp[i][j]!=-1)
            {
                int p=0,q=0;
                for(int k=0;k<n;k++)
                {
                    if(j&(1<<k))
                    {
                        if(!a[k][i])p++;
                    }
                    else if(a[k][i])p++;
                }
                q=n-p;
                update(dp[i+1][j],dp[i][j]+p);
                update(dp[i+1][(1<<n)-1-j],dp[i][j]+q);
            }
            for(i=0;i<1<<n;i++)
            if(dp[m-1][i]!=-1)ans=min(ans,dp[m][i]);
        }
        
        else ans=solve();
        if(ans>k)ans=-1;
        printf("%d\n",ans);
    }   
}