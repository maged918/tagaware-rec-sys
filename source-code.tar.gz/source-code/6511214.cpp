//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

#define rep(i,n) for(int i=0;i<(n);++i)
#define lfo(i,a,b) for(int i=(a),_b=(b);i<=_b;++i)
#define rfo(i,a,b) for(int i=(a),_b=(b);i>=_b;--i)
#define lfoe(i,v) for(typeof((v).begin()) i = (v).begin(); i != (v).end(); ++i)
#define st first
#define nd second
#define pb push_back

int n,m,k,a[101][101];

int solve1(){
    int ans=100000;
    rep(t,n){
        int here=0,cur;
        rep(i,n){
            cur=0;
            rep(j,m) cur+=a[i][j]^a[t][j];
            here+=min(cur,m-cur);
        }
        ans=min(ans,here);
    }
    return (ans>k ? -1:ans);
}
bool get(int s,int pos){
    return (s&(1<<pos));
}
int solve2(){
    int ans=100000;
    for(int s=0,p=(1<<m);s<p;++s){
        int here=0,cur;
        rep(i,n){
            cur=0;
            rep(j,m) cur+=get(s,j)^a[i][j];
            here+=min(cur,m-cur);
        }
        ans=min(ans,here);
    }
    return (ans>k ? -1:ans);
}

int main(){
#ifndef ONLINE_JUDGE
    freopen("a.inp","r",stdin);
#endif // ONLINE_JUDGE
    ios::sync_with_stdio(false);
    cin>>n>>m>>k;
    rep(i,n) rep(j,m) cin>>a[i][j];
    if (m>10) cout<<solve1()<<'\n';
    else cout<<solve2()<<'\n';
    return 0;
}
