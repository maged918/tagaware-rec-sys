//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <vector>
#include <string.h>
#include <cmath>
#define INF 999999999
using namespace std;
typedef int lld;

lld MN(lld a, lld b)
{
    if (a < b) return a;
    return b;
}
lld MX(lld a, lld b)
{
    if (a > b) return a;
    return b;
}
lld eabs(lld num)
{
    if (num < 0) return -num;
    return num;
}
lld GOC(char a)
{
    return (a-'0');
}

lld n, arr[200002];
vector <lld> bd;
lld t, c;

lld Magic(lld num)
{
    if (num < 0) return 0;
    return num;
}

int main ()
{
    lld i, j, ii, jj, ind;
    lld from, to;
    lld ans=0;

    scanf("%d %d %d", &n, &t, &c);
    for (i=1; i<=n; i++)
    {
        scanf("%d", &arr[i]);

        if (arr[i] > t)
        {
            bd.push_back(i);
        }
    }
    bd.push_back(n+1);

    ind=0;
    for (i=1; i<=n; i++)
    {
        from = i;
        to = bd[ind]-1;

        if (from > to)
        {
            ind++;
            continue;
        }

        if (to-from+1 >= c)
        {
            ans++;
        }
    }

    printf("%d\n", ans);
}

