//Language: GNU C++


#include <iostream>

using namespace std;

int n, p, ans, temp;
int main()
{
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> temp;
        if (temp == -1) {
            if (!p)
                ans++;
            else
                p--;
        }
        else
            p += temp;
    }

    cout << ans;
    return 0;
}
