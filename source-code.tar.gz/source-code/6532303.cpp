//Language: GNU C++0x


#include <algorithm>
#include <bitset>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <deque>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <tuple>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<double> vd;
typedef vector<ll> vll;
typedef vector<string> vs;
typedef pair<int,int> pii;
#define range(i,a,b) for(auto i=(a);i<b;i++)
#define rep(i,n) range(i,0,n)
#define all(c) begin(c),end(c)
#define CLR(i,x) memset(i,x,sizeof(i))
#define clr0(i) CLR(i,0)
#define clr1(i) CLR(i,-1)
#define M(x) ((x)%MOD)
#define acc(f,x,y) x=f(x,y)

#define N 5005

string s, t;
int ms[N], mt[N], buf[N][N];

void shortest(string & s, int m[N])
{
	clr0(buf);
	for(int i = s.size() - 1; i >= 0; i--)
	for(int j = s.size() - 1; j >= 0; j--)
	if(s[i] == s[j] && i != j)
	{
		buf[i][j] = buf[i + 1][j + 1] + 1;
		m[i] = max(m[i], buf[i][j]);
	}
}

int main()
{
	cin >> s >> t;
	shortest(s, ms);
	shortest(t, mt);

	clr0(buf);
	int ans = N;
	for(int i = s.size() - 1; i >= 0; i--)
	for(int j = t.size() - 1; j >= 0; j--)
	if(s[i] == t[j])
	{
		buf[i][j] = buf[i + 1][j + 1] + 1;
		if(buf[i][j] > ms[i] && buf[i][j] > mt[j])
		{
			ans = min(ans, 1 + max(ms[i], mt[j]));
		}
	}

	cout << (ans < N ? ans : -1) << endl;

	return 0;
}
