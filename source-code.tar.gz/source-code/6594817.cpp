//Language: GNU C++


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <map>

using namespace std;

int n, mm, k;
int b[1000], a[1000], d[1000];
int pt;

void cop(){
	
	for(int i=1;i<=n;i++) b[i]=a[i];
}

void don(int dau,int cuoi){
	
	int tm, i;
	tm=cuoi+1;
	
	for(i=dau;i<=pt;i++)
	{
		b[i] = b[tm++];
	}
	
	pt = pt-(cuoi-dau+1);
}

int dem(int dau, int cuoi)
{
	int dem, i, maxx, luu, xp, kt, tong;
	tong = 0;
	maxx = 0;
	
	don(dau,cuoi);
	tong += cuoi-dau+1;
	
	while(1)
	{
		dem=1;
		memset(d, 0, 105*sizeof(int));
		maxx = 0;
		bool first = false;
		
		for(i=1;i<=pt;i++)
		{
			if(b[i-1] == b[i])
			{
				dem++;
				d[i]=dem;
			}
			else
			{
				dem=1;
				d[i]=dem;
			}
			
			if(maxx < d[i])
			{
				luu = b[i];
				maxx = d[i];
			}
			
		}
		
		if(maxx >=3)
		{
			
			for(i=1;i<=pt;i++)
			{
				if(d[i] == maxx)
				{
					kt = i;
					xp = i-maxx+1;
					break;
				}
			}
			tong+=kt-xp+1;
			don(xp, kt);
		}
		else
			return tong;
	}
	
	return tong;
}

void solve()
{
	int i, maxx;
	maxx = 0;
	for(i=1;i<=n;i++) scanf("%d",&a[i]);
	
	for(i=1;i<=n;i++)
	{
		
		if(a[i] == mm && a[i+1] == mm)
		{
			
			cop();
			pt=n;
			
			maxx = max(maxx, dem(i, i+1));
		}
	}
	
	printf("%d\n", maxx);
}

int main()
{
	
	//freopen("b.inp", "r", stdin);
	//freopen("b.out", "w", stdout);
	
	while(scanf("%d%d%d",&n,&k,&mm)>0)
		solve();
	return 0;
}