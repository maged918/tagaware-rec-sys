//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <string>
#include <queue>
#include <map>
#include <vector>
#include <algorithm>
#define DEBUG 0
#define LSON(x) (x) << 1
#define RSON(x) (x) << 1 | 1
#define INF 0x1fffffff
#define MAXN 100005


typedef long long LL;
using namespace std;

vector<int> vec[MAXN], ans;
int vis[MAXN] = {0};
int ori[MAXN], goal[MAXN];
int anscnt = 0;
void dfs(int id, int odd, int even, int change)
{
    vis[id] = 1;
    if(change)
        ori[id] = !ori[id];
    if(ori[id] != goal[id])
    {
        ori[id] = goal[id];
        anscnt ++;
        ans.push_back(id);
        for(int i = 0; i < vec[id].size(); i ++)
        {
            if(!vis[ vec[id][i] ])
                dfs(vec[id][i], !even, odd, odd);
        }
    }
    else
    {
        for(int i = 0; i < vec[id].size(); i ++)
        {
            if(!vis[ vec[id][i] ])
                dfs(vec[id][i], even, odd, odd);
        }
    }
}

int main()
{
    int n;
    scanf("%d", &n);
    for(int i = 0; i < n - 1; i ++)
    {
        int x, y;
        scanf("%d%d", &x, &y);
        vec[x].push_back(y);
        vec[y].push_back(x);
    }

    for(int i = 1; i <= n; i ++)
        scanf("%d", &ori[i]);
    for(int i = 1; i <= n; i ++)
        scanf("%d", &goal[i]);
    //cout << "h";
    dfs(1, 0, 0, 0);

    sort(ans.begin(), ans.end());

    printf("%d\n", anscnt);
    for(int i = 0; i < ans.size(); i ++)
        printf("%d\n", ans[i]);

    return 0;
}