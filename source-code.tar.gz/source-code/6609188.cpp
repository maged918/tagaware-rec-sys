//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <map>
#include <cmath>
#include <string>
#define pi acos(-1)
#define _max 25
#define inf 0xfffffff
#define eps 0.0001
#define lp(i,n) for(int i=0;i<n;i++)
#define lpb(i,n) for(int i=1;i<=n;i++)
#define smap(p,ma) for(p=ma.begin();p!=ma.end();p++)
#define MA(a,b) ((a)>(b)?(a):(b))
#define MI(a,b) ((a)<(b)?(a):(b))
#define PB push_back
#define FIR first
#define SEC second
using namespace std;

int n,a[30],v[30];

bool cal(int p,int sum,int child){
  if(p==n){
       return true;  
  } 
  if(sum+1==a[p]){
    if(child!=1) return cal(p+1,0,0);
    else return false;
  }
  int l =-1;
  for(int x=0;x<n;x++){
    if(v[x]==0 && a[x]+sum<a[p] &&l!=a[x] ){
      l=a[x];
      v[x]=1;
      if(cal(p,sum+a[x],child+1)) return true;
      v[x]=0;
    }
  }
  return false;
}
main(){
       
    scanf("%d",&n);
    
    lp(i,n){
      scanf("%d",a+i);
    }
    sort(a,a+n);
    if(a[n-1]==n&& cal(0,0,0) )printf("YES\n");
    else printf("NO\n");

}

