//Language: GNU C++0x


#include <bits/stdc++.h>
using namespace std;


int calc(int n, int *c, int pos, int x) {
    if (c[pos] != x) {
        return 0;
    }
    int res = 0;
    int l = pos, r = pos;
    while (l >= 0 && c[l] == x) {
        --l;
    }
    while (r < n && c[r] == x) {
        ++r;
    }
    int cnt = r - l - 1;
    if (cnt < 2) {
        return 0;
    }
    res += cnt;
    while (l >= 0 && r < n) {
        int cn = 0;
        int tmp = c[l];
        if (c[l] != c[r]) {
            break;
        }
        while (r < n && c[r] == tmp) {
            ++r;
            ++cn;
        }
        while (l >= 0 && c[l] == tmp) {
            --l;
            ++cn;
        }
        if (cn < 3) {
            break;
        }
        res += cn;
    }
    return res;
}

int main() {
    ios_base::sync_with_stdio(false);

    int n, k, x;
    cin >> n >> k >> x;
    --x;
    int c[n];
    for (int i = 0; i < n; ++i) {
        cin >> c[i];
        --c[i];
    }

    int ans = 0;
    for (int i = 0; i < n; ++i) {
        ans = max(ans, calc(n, c, i, x));
    }
    cout << ans << endl;
}
