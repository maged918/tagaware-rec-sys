//Language: GNU C++


#include <iostream>

using namespace std;

int main(){
    int n, k, m, i, con = 0;
    cin >> n >> k;
    for(i = 0; i < n; i++){
        cin >> m;
        if(m <= 5 - k)con++;
    }
    con = con / 3;
    cout << con;
    return 0;
}
