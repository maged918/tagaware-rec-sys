//Language: GNU C++


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct node
{
    int a,b;
}t[100050];
int main()
{
    int n,i,x;
    int num[100050];
    int ans[100050];
    memset(t,0,sizeof(t));
    memset(num,0,sizeof(num));
    scanf("%d",&n);
    for(i=0;i<n;i++)
        ans[i]=n-1;
    for(i=0;i<n;i++)
    {
        scanf("%d %d",&t[i].a,&t[i].b);
        num[t[i].a]++;
    }
    for(i=0;i<n;i++)
    {
        ans[i]+=num[t[i].b];
        x=2*(n-1)-ans[i];
        printf("%d %d\n",ans[i],x);
    }
}