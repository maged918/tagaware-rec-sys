//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>

#define FOR(i, a, b) for(int i = a; i <= b; ++i)
#define FRD(i, a, b) for(int i = a; i >= b; --i)
#define FR(i, a) for(int i = 0; i < a; ++i)
#define REP(i, a) for(int i = 0; i <= a; ++i)
#define bug(x) cout << #x << " = " << x << endl
#define bg(a, m, n) FOR(i, m, n) cout << a[i] << " "; cout << endl
#define reset(a, b) memset(a, b, sizeof a)
using namespace std;

const int maxN = 1e5 + 5;

struct Node {
    int v;
    Node *next;
};

Node *head[maxN];
int n, init[maxN], goal[maxN], cres, res[maxN], parent[maxN], change[maxN];
bool mark[maxN];

void PushHead(int x, int y) {
    Node *p = new Node;
    p->v = y; p->next = head[x];
    head[x] = p;
}

void Enter() {
    scanf("%d\n", &n);
    int x, y;
    FOR(i, 1, n - 1) {
        scanf("%d%d\n", &x, &y);
        PushHead(x, y); PushHead(y, x);
    }
    FOR(i, 1, n) scanf("%d ", &init[i]);
    FOR(i, 1, n) scanf("%d ", &goal[i]);
}

void DFS(int u) {
    Node *p = head[u];
    mark[u] = false;
    if (change[parent[parent[u]]]) {
        change[u] = change[parent[parent[u]]];
        init[u] = (init[u] + change[u]) % 2;
    }
    if (init[u] != goal[u]) {
        res[++cres] = u;
        change[u]++;
        init[u] = (init[u] + 1) % 2;
    }
    while (p != NULL) {
        int v = p->v;
        if (mark[v]) {
            parent[v] = u;
            DFS(v);
        }
        p = p->next;
    }
}

void Solve() {
    reset(mark, true); reset(change, 0); reset(parent, 0);
    DFS(1);
}

void Print() {
    printf("%d\n", cres);
    FOR(i, 1, cres) printf("%d\n", res[i]);
}

int main() {
#ifndef ONLINE_JUDGE
    freopen("C.INP", "r", stdin);
#else
    ios_base::sync_with_stdio(false);
#endif // ONLINE_JUDGE
    Enter();
    Solve();
    Print();
    return 0;
}
