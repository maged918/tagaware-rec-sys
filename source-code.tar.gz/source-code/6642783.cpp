//Language: GNU C++0x


#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <climits>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <memory.h>

#define pb push_back
#define ll long long
#define mp make_pair
#define f first
#define s second
#define all(x) x.begin(),x.end()
#define rall(x) x.rbegin(),x.rend()
#define pi acos(-1.0)
#define EPS 1e-9

using namespace std;

pair<int,int> v[100009];
int main()
{
	int n;scanf("%d",&n);for(int i=0;i<n;i++)scanf("%d",&v[i].f),v[i].s=(i+1);
	sort(v,v+n);vector<int> a,b;
	for(int i=0;i<n;i++){
		if(i%2==0)a.pb(v[i].s);
		else b.pb(v[i].s);
	}
	printf("%d\n",int(a.size()));for(int x:a)printf("%d ",x);
	printf("\n");
	printf("%d\n",int(b.size()));for(int x:b)printf("%d ",x);
	return 0;
}
