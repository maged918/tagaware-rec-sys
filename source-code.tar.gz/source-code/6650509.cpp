//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <time.h>
#include <queue>
#include <cctype>
#include <utility>
#include <numeric>
#include <cstdlib>
#include <iomanip>
#include <sstream>
#define Mod 1000000007
#define INT 2147483647
#define pi acos(-1.0)
#define eps 1e-4
#define lll __int64
#define ll long long
using namespace std;
#define N 100007

int dp[N][305];
int a[N],b[N];
std::vector<int> v[N];

int main()
{
    int n,m,s,e;
    int i,j;
    scanf("%d%d%d%d",&n,&m,&s,&e);
    for(i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for(i=1;i<=m;i++)
    {
        scanf("%d",&b[i]);
        v[b[i]].push_back(i);
    }
    int S = s/e;
    for(i=1;i<=n;i++)
    {
        dp[i][0] = -1;
        for(j=1;j<=S;j++)
            dp[i][j] = Mod;
    }
    for(i=1;i<=m;i++)
    {
        if(b[i] == a[1])
        {
            dp[1][1] = i;
            break;
        }
    }
    //meiju
    vector<int>::iterator it;
    for(i=2;i<=n;i++)
    {
        for(j=0;j<=S;j++)
        {
            dp[i][j] = min(dp[i][j],dp[i-1][j]);
            it = upper_bound(v[a[i]].begin(),v[a[i]].end(),dp[i-1][j]);
            if(it != v[a[i]].end())
                dp[i][j+1] = min(dp[i][j+1],*it);
        }
    }
    int res = -Mod;
    for(i=1;i<=n;i++)
    {
        for(j=0;j<=S;j++)
        {
            if(i + dp[i][j] + j*e <= s)
                res = max(res,j);
        }
    }
    printf("%d\n",res);
    return 0;
}
