//Language: GNU C++


/*
بسم الله الرحمن الرحيم

 Md: Rezaul Karim Rana
Islamic University , Kushtia

*/
#include <bits/stdc++.h>

using namespace std;

#define inf 1000000000000LL
#define eps 1e-11
#define open freopen("input.txt","r",stdin)
#define close freopen ("output.txt","w",stdout)
#define rep(i,n) for(__typeof(n) i=0; i<(n); i++)
#define rep1(i,n) for(__typeof(n) i=0; i<=(n); i++)
#define rep2(i,n) for(__typeof(n) i=1; i<=(n); i++)
#define rep3(i,a,b) for(__typeof(b) i=(a); i<=(b); i++)
#define repe(it,c)    for(__typeof((c).begin()) it=(c).begin();it!=(c).end();++it)
#define pi 3.14159265358979323846264338327950
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define sz size()
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(), (x).end()
#define mem(a,b) memset(a,b,sizeof(a))
int dx[] = {-1,0,1,1,1,0,-1,-1} , dy[] = {-1,-1,-1,0,1,1,1,0} ;
int cx[] = {1,1,2,2,-1,-1,-2,-2}, cy[] = {2,-2,1,-1,2,-2,1,-1};
template<class T> int len(const T&c){return (int)c.size();}
long long stoi(string s){long long n=0;rep(i,len(s))n=(n<<3)+(n<<1)+(s[i]-48);return n;}
string itos(long long n){ if(n==0) return "0"; string s;while(n){s+=(n%10+48);n/=10;}reverse(all(s));return s;}
int main()
{
    ios_base::sync_with_stdio(false);
    long n,k;
    while(cin>>n>>k)
    {
        long a[102]={0},c=0;
        rep(i,n)cin>>a[i];sort(a,a+n);
        for(int i=n-1;i>=0;i--)
        {
            c++;
            if(c==k)
            {
                cout<<a[i]<<" 0"<<endl;return 0;
            }
        }
        cout<<"-1"<<endl;
    }
    return 0;
}
