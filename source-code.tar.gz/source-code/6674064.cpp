//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cassert>
#include<cstring>
#include<ctime>
#include<cstdlib>
#include<cmath>
#include<string>
#include<sstream>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<vector>
#include<bitset>
#include<algorithm>
#pragma comment(linker, "/STACK:640000000")
#define pb push_back
#define ppb pop_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) (int)(x).size()
#define ll long long
#define bit __builtin_popcountll
#define sqr(x) (x) * (x)
#define forit(it,S) for(__typeof((S).begin()) it = (S).begin(); it != (S).end(); it++)
using namespace std;
typedef pair<int, int> pii;
const double eps = 1e-9;
const double pi = acos(-1.0);
const int maxn = (int)1e5 + 10;
int h[maxn],H[2 * maxn],p[maxn],x[maxn];
int type[maxn];
ll t[8 * maxn];
int cnt[8 * maxn];
ll v[maxn];
ll get(int l, int r, int cc, int idx) {
    if (l == r) return cc * 1LL * H[l];
    int m = (l + r) >> 1;
    if (cnt[2 * idx] >= cc) return get(l,m,cc,2 * idx);
    return t[2 * idx] + get(m + 1,r,cc - cnt[2 * idx],2 * idx + 1);
}
int kth(int l, int r, int cc, int idx) {
    if (l == r) return H[l];
    int m = (l + r) >> 1;
    if (cnt[2 * idx] >= cc) return kth(l,m,cc,2 * idx);
    return kth(m + 1,r,cc - cnt[2 * idx],2 * idx + 1);
}
void upd(int l, int r, int pos, int val, int idx) {
    if (pos < l || r < pos) return;
    if (l == r) {
        cnt[idx] += val;
        t[idx] += H[l] * val;
    } else {
        int m = (l + r) >> 1;
        upd(l,m,pos,val,2 * idx);
        upd(m + 1,r,pos,val,2 * idx + 1);
        cnt[idx] = cnt[2 * idx] + cnt[2 * idx + 1];
        t[idx] = t[2 * idx] + t[2 * idx + 1];
    }
}
int main() {
    #ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    #endif
    int n,q; cin >> n >> q;
    int m = 0;
    for (int i = 0; i < n; i++) {
        scanf("%d",&h[i]);
        H[m++] = h[i];
    }
    for (int i = 0; i < q; i++) {
        scanf("%d",&type[i]);
        if (type[i] == 1) {
            scanf("%d%d",&p[i],&x[i]); --p[i];
            H[m++] = x[i];
        } else {
            scanf("%I64d",&v[i]);
        }
    }
    sort(H,H + m);
    m = unique(H,H + m) - H;
    for (int i = 0; i < n; i++) {
        int id = lower_bound(H,H + m,h[i]) - H;
        upd(0,m - 1,id,1,1);
    }
    for (int i = 0; i < q; i++) {
        if (type[i] == 1) {
            int id1 = lower_bound(H,H + m,h[p[i]]) - H;
            int id2 = lower_bound(H,H + m,x[i]) - H;
            h[p[i]] = x[i];
            upd(0,m - 1,id1,-1,1);
            upd(0,m - 1,id2,1,1);
        } else {
            ll ma = get(0,m - 1,n,1);
            if (n * 1LL * kth(0,m - 1,n,1) - ma < v[i]) {
                printf("%.12lf\n",(v[i] + ma + 0.0) / n);
            } else {
                int l = 1;
                int r = n;
                while(l < r - 1) {
                    int mm = (l + r) >> 1;
                    ll cur = get(0,m - 1,mm,1);
                    if (mm * 1LL * kth(0,m - 1,mm,1) - cur < v[i]) {
                        l = mm;
                    } else {
                        r = mm;
                    }
                }               
                ll cur = get(0,m - 1,l,1);
                printf("%.12lf\n",(v[i] + cur + 0.0) / l);
            }
        }
    }
    return 0;
}
