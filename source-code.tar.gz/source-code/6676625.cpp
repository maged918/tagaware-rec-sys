//Language: GNU C++


//Solution by Miras Myrzakerey
//Look at my code
//My code is amazing

#include <cstdio>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <cassert>
#include <cmath>
#include <vector>
#include <map>
#include <cstring>
#include <set>
#include <ctime>
#include <queue>
#include <iomanip>

using namespace std;

#define INF 1000000001
#define sqr(x) (x) * (x)
#define maxn 220001
#define pb push_back
#define mp make_pair
#define mod 1000000007
#define all(a) a.begin(),a.end()
#define len(a) (int)(a.length())
#define F first
#define S second
#define pii pair<int,int>
#define LL long long
#define vi vector<int>
#define forn(xx,yy,zz) for(int zz = xx; zz <= yy; ++zz)
#define forl(xx,yy,zz) for(int zz = xx; zz >= yy; --zz)
#define str string
#define eps 1e-7
#define pi M_PI

struct node
{
	LL sum;
	int l, r;
}t[2][30 * maxn];

int sz = 1, n, m, a[maxn], tt, x, y;
LL v;

void update(bool st, int l, int r, int v, int pos, int val)
{
	if (l == r)
		t[st][v].sum += val;
	else
	{
		int m = (l + r) >> 1;

		if (pos <= m)
		{
			if (!t[st][v].l)
				t[st][v].l = ++sz;
			update(st, l, m, t[st][v].l, pos, val);
		}
		else
		{
			if (!t[st][v].r)
				t[st][v].r = ++sz;
			update(st, m + 1, r, t[st][v].r, pos, val);
		}

		t[st][v].sum = 0;
		t[st][v].sum += t[st][v].l ? t[st][t[st][v].l].sum : 0;
		t[st][v].sum += t[st][v].r ? t[st][t[st][v].r].sum : 0;
	}			
}

LL get(bool st, int tl, int tr, int v, int l, int r)
{
	if (!v || l > r)
		return 0;

	if (tl == l && tr == r)
		return t[st][v].sum;

	int td = (tl + tr) >> 1;

	return get(st, tl, td, t[st][v].l, l, min(r, td)) + get(st, td + 1, tr, t[st][v].r, max(l, td + 1), r);
}

bool check(double x)
{	
	LL nx = (LL)(x);
	if ((LL)(nx) != x)
		nx++;

	nx = min(nx, (LL)1e9);
	LL ls = get(0, 0, 1000000000, 1, 0, nx - 1);
	LL mr = get(1, 0, 1000000000, 1, 0, nx - 1);

	return ls * x - mr >= v;
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(0);

	#ifndef ONLINE_JUDGE
		freopen("in", "r", stdin);
	#endif

	scanf("%d%d", &n, &m);
	
	for (int i = 1; i <= n; ++i)
	{
		scanf("%d", &a[i]);
		update(0, 0, 1000000000, 1, a[i], 1);
		update(1, 0, 1000000000, 1, a[i], a[i]);
	}

	while (m--)
	{
		scanf("%d", &tt);

		if (tt == 1)
		{
			scanf("%d%d", &x, &y);
			update(0, 0, 1000000000, 1, a[x], -1);
			update(1, 0, 1000000000, 1, a[x], -a[x]);
			a[x] = y;
			update(0, 0, 1000000000, 1, a[x], 1);
			update(1, 0, 1000000000, 1, a[x], a[x]);
		}
		else
		{
			scanf("%I64d", &v);

			double l = 0, r = v + 1e9;

			for (int it = 0; it < 60; ++it)
			{
				double m = (l + r) * 0.5;

				if (check(m))
					r = m;
				else
					l = m;						
			}

			printf("%.7f\n", r);
		}
	}	
}