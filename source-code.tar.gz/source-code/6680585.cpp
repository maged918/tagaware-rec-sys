//Language: GNU C++


#include<stdio.h>
#include<algorithm>
#include<string.h>
#define mod  1000000007 
using namespace std;
int dp[200][200][200];
int main()
{
	int n,k,d;
	scanf("%d%d%d",&n,&k,&d);
	int i,j,w,h;
	for(i=1;i<=k;i++)
	dp[1][i][i]=1;
	for(i=2;i<=n;i++)
	for(j=1;j<=n;j++)
	for(w=1;w<=k;w++)
	{
		for(h=1;h<=k;h++)
		if(j+w<=n)
		dp[i][j+w][max(w,h)]=(dp[i][j+w][max(w,h)]+dp[i-1][j][h])%mod;
	}
	int ans=0;
	for(i=1;i<=n;i++)
	for(j=d;j<=k;j++)
	ans=(ans+dp[i][n][j])%mod;
	printf("%d\n",ans);
	
}
 