//Language: GNU C++0x


//In the name of God
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <climits>
#include <complex>
#include <fstream>
#include <cassert>
#include <cstdio>
#include <bitset>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <ctime>
#include <set>
#include <map>

// #define X first
// #define Y second
// #define X real()
// #define Y imag()
// #define cin fin
// #define cout fout

using namespace std;
typedef long long ll;
typedef long double ld;
typedef pair<ll, ll> pll;
typedef complex<ll> point;
typedef pair<int, int> pii;
typedef pair<pii, int> piii;
const int maxn = 100;
const ll inf = 1e18;

ll  k, m, c[maxn][maxn];

inline ll cnt (ll step, ll x, ll y)
{
  if(step < 0)
    return y == 0;
  if(y < 0)
    return 0;
  if(x & (((ll)1LL)<<step))
    return c[y][step] + cnt(step - 1LL, x, y - 1LL);
  else
    return cnt(step - 1LL, x, y);  
}

inline ll ok (ll x)
{
  return cnt(62, x, k) - cnt(62, x / 2, k);
}

inline ll BS (ll fi, ll se)
{  
  if(fi == se)
    return fi;
  ll mid = (fi + se) / 2;
  if(ok(mid * 2LL) >= m)
    return BS(fi, mid);
  return BS(mid + 1LL, se);
}

int main ()
{
  ios_base :: sync_with_stdio(0);
  for(int i = 0 ; i < maxn ; i++)
    c[0][i] = 1LL;
  for(int i = 1LL ; i < maxn ; i++)
    for(int j = 1LL ; j < maxn ; j++)
      c[i][j] = c[i][j - 1LL] + c[i - 1LL][j - 1LL];
  cin >> m >> k ;
  cout << BS(1, inf) << endl ;
}