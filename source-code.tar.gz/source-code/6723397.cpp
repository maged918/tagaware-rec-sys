//Language: GNU C++


/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.
   * File Name : ARRANGE.cpp
   * Creation Date : 19-12-2013
   * Last Modified : Wednesday 28 May 2014 12:53:03 AM IST

   _._._._._._._._._._._._._._._._._._._._._.*/
#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <ctime>

#define FREE(p) \
	    free(p);    \
    p = NULL;
#define sz(a) int((a).size())
#define tr(container,it) for(typeof(container.begin()) it = container.begin(); it != container.end(); it++) 
#define FILL(x,y) memset(&x,y,sizeof(x)) //example( FILL(buffer,-1) )
#define FOR(i,a,b) 	for(int i= (int )a ; i < (int )b ; i++)
#define rep(i,n) 	FOR(i,0,n)
#define si(n) scanf("%lld",&n)
#define pil(n) printf("%lld\n",n)//print integer
#define sl(n) scanf("%lld",&n)//long long int
#define sd(n) scanf("%lf",&n)//double
#define ss(n) scanf("%s",n)
#define sc(ch) scanf("%c",&ch)
#define ps(s) printf("%s\n",s)//print string
#define pc(s) printf("%c",s)//print character
#define sln printf("\n"); 
#define PB push_back
#define MP make_pair
#define scan(v,n)	vector<int> v;rep(i,n){ int j;si(j);v.PB(j);}
typedef long long int LL;
using namespace std;
typedef vector <int> VI;
typedef pair < int ,int > PII;
typedef vector < PII > VPII;

int main()
{
	LL i,n,l,r,type,m;
	si(n);
	LL a[n],cum[n],cost[n],b[n];
	rep(i,n)
	{
		si(a[i]);b[i]=a[i];
	}
	cum[0]=a[0];
	
	sort(b,b+n);

	cost[0]=b[0];
	for(i=1;i<n;i++)
	{
		cum[i]=cum[i-1]+a[i];
		cost[i]=cost[i-1]+b[i];
	}
	si(m);
	rep(i,m)
	{

		si(type);
		si(l);si(r);
		l--;r--;
		if(type==1)
			pil(cum[r]-cum[l]+a[l]);
		else
			pil(cost[r]-cost[l]+b[l]);
	}

		return 0;
}
