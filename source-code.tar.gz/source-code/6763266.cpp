//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS
//#pragma comment(linker, "/STACK:100000000")
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <stdio.h>
#include <vector>
#include <map>

#define ull unsigned ll
#define ll long long
#define ld long double
#define FOR(i, a, b) for(int i=(int)(a); i<(int)(b); ++i)
#define FORN(i, b) for(int i=0; i<(int) (b); i++)
#define FORZ(i, a, b) for (int i=(int)(a); i>(int)(b); --i)
#define mp make_pair
#define fs first
#define sc second
#define pii pair<int, int>
#define pll pair<ll, ll>
#define vii vector<int>
#define vll vector<ll>
#define pb push_back
#define ppb pop_back
#define bg begin()
#define ed end()
#define sz size()
#define rsz resize
#define all(a) (a).bg, (a).ed
#define len length()
#define ext return 0;
#define pi 3.1415
ll gcd(ll a, ll b) { if (a == 0 || b == 0) return (a + b); if (a > b) return (gcd(a%b, b)); return (gcd(a, b % a)); }

#define Nmax 100009
#define INF 1000000007
#define y1 yy1
#define eps 1e-5
void out() { std::cout << "NO\n"; exit(0); }
using namespace std;

string s;
int n;

string solve(string s, int n){
FOR(i, 0, s.len) {
int which=i;
    FOR(j, i, s.len){
       if (j-i>n) break;
       if (s[j]>s[which]) which=j;
    }

    n-=(which-i);
    FORZ(j, which, i)
      swap(s[j], s[j-1]);
}
return s;
}

int main(){
	ios::sync_with_stdio(0);

	cin >> s >> n;
	cout << solve(s, n) << endl;

	ext;
}
