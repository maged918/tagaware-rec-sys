//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int maxn = 100010;
int sum, limit, l;
int res[maxn], ans;
void dfs(int a, int b, int tt) {
    if(a < b) {
        if(tt <= limit && sum >= (1 << a)) {
            res[++ans] = tt;
            sum -= (1 << a);
        }
        return;
    }
    dfs(a - 1, b, tt | (1 << a));
    dfs(a - 1, b, tt);
    return;
}
int main() {
    scanf("%d%d", &sum, &limit);
    for(l = 0; (1 << l) <= limit; l ++);
    l --;
    for(int i = l; i >= 0; i --) {
        dfs(l, i + 1, (1 << i));
        if(!sum) break;
    }
    if(sum) {printf("-1\n"); return 0;}
    printf("%d\n", ans);
    for(int i = 1; i <= ans; i ++) printf("%d ", res[i]);
    return 0;
}
