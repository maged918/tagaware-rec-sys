//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <math.h>
#include <string>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;
int TC, N, M;
int arr[100001];
map<int, vector<int> > m;
int sum, limit;
int main(){
    //freopen("C:\\in.txt", "r", stdin);
    for(int i=0; i<=100000; ++i){
        arr[i] = ( i & ~(i-1) );
    }
    scanf("%d %d", &sum, &limit);
    for(int i=0; i<=limit; ++i){
        m[arr[i]].push_back(i);
    }
    vector<int> res;
    int need;
    while(sum!=0){
        int lowest = ( sum & ~(sum-1) );
        sum = sum & (sum-1);
        need = 1;
        //for(map<int, vector<int> >::iterator it = m.begin(); it!=m.end(); ++it){
         //   printf("M: %d ", it->first);
       // }
        while(need!=0 && lowest!=0){
            if(m.find(lowest)!=m.end() && m[lowest].size()!=0){
                for(int i=0; i<need && m[lowest].size()!=0; ++i){
                    need--;
                    res.push_back(m[lowest].back());
                    m[lowest].pop_back();
                }
            } else {
                lowest/=2;
                need*=2;
            }
        }
    }
    if(need>0){
        printf("-1\n");
    } else{

        printf("%d\n", res.size());
        for(int i=0; i<res.size(); ++i){
            if(i!=0){
                printf(" ");
            }
            printf("%d", res[i]);
        }
        printf("\n");
    }
    return 0;
}
