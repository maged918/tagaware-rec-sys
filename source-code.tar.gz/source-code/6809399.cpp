//Language: GNU C++


//Lasha Bukhnikashvili
#include<iostream>
#include<stdio.h>
#include<math.h>
#include<iomanip>
#include<algorithm>
#include<vector>
#include<map>
#include<queue>
#include<string>
#define F first
#define S second
#define Pi 3.14159265358
#define mod9 %1000000009
#define INF 1000000000
#define mod7 %1000000007
#define LL long long
#define time clock()/(double)CLOCKS_PER_SEC
using namespace std;
 LL l,r,mid,n,x,out,m,i,sum,ans,ind,j,a[200001],b[200001],suma[200001],sumb[200001];
 vector<LL> arr;
int main(){
#ifndef ONLINE_JUDGE
   freopen("input.txt","r",stdin);
   freopen("output.txt","w",stdout);
 #endif
    cin>>n>>m;
    for (i=1;i<=n;i++)
        cin>>a[i],arr.push_back(a[i]);
        for (j=1;j<=m;j++)
            cin>>b[j],arr.push_back(b[j]);
    sort(a+1,a+n+1);
    sort(b+1,b+m+1);
    for (i=1;i<=n;i++)
        suma[i]=suma[i-1]+a[i];
    if (a[1]>=b[m]){cout<<0; return 0;}
    sort(arr.begin(),arr.end());
    for (i=1;i<=m;i++)
        sumb[i]=sumb[i-1]+b[i];
    l=0; r=arr.size()-1;
    out=1000000000000000000LL;
    for (i=0;i<=arr.size()-1;i++){
        x=arr[i];
        l=1; r=n;
        while (l<r){
              if (l==r-1){
                 if (a[r]<=x) l=r;
                 break;
              };
              mid=(l+r)/2;
              if (a[mid]>x) r=mid-1; else l=mid;
        };
        ans+=l*x-suma[l];
        l=1; r=m;
        while (l<r){
              mid=(l+r)/2;
              if (b[mid]<x) l=mid+1; else r=mid;
        };
        ans+=(sumb[m]-sumb[r-1])-(m-r+1)*1ll*x;
       
        out=min(out,ans);
         ans=0;
    };cout<<out;
 return 0;
}


