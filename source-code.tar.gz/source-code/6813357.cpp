//Language: GNU C++


#include <cstdio>
#include <cassert>
#include <algorithm>
#include <cstring>
#include <vector>
#include <cstdlib>
#include <cmath>
using namespace std;
typedef long long i64;
const int MAX = 1e5 + 10;
const int oo = 1e9;
const double EPS = 1e-9;
const int MOD = 1e9 + 7;
#define MUL(a, b) ((i64)(a) * (b))%MOD
#define REST(a, b) ((i64)(a) - (b) + MOD)%MOD
int inv[MAX];
void inverse_sieve(){
	inv[0] = -1; inv[1] = 1;
	for(int i=2; i < MAX; i++){
		if(inv[MOD % i] == -1)inv[i] = -1;
		else inv[i] = (-(i64)(MOD/i) * inv[ MOD%i ])%MOD + MOD;
	}
}
int fac[MAX];
int ifac[MAX];
inline int comb(int a, int b){
	if(a < b)return 0;
	return MUL(fac[a], MUL(ifac[b], ifac[a - b]));
}
vector<int> divisors[MAX];
int mobius[MAX];
int main() {
	inverse_sieve();
	fac[0] = ifac[0] = 1;
	for(int i=1; i < MAX; i++){
		fac[i] = MUL(fac[i - 1], i);
		ifac[i] = MUL(ifac[i -1], inv[i]);
	}
	mobius[1] = 1;
	divisors[1].push_back(1);
	for(int i=2; i < MAX; i++){
		for(int j=1; j* j <= i; j++){
			if(i % j != 0)continue;
			divisors[i].push_back(j);
			if(j * j != i)divisors[i].push_back(i / j);
		}
		if(divisors[i].size() > 2){
			int j = divisors[i][2];
			if((i/j)%j == 0)mobius[i] = 0;
			else mobius[i] = mobius[i / j] * -1;
		}
		else mobius[i] = -1;
		//sort(divisors[i].begin(), divisors[i].end());
	}

	int q; scanf("%d", &q);
	while(q--){
		int n, f; scanf("%d%d", &n, &f);
		int sol = 0;
		for(int ii=0; ii <(int)divisors[n].size(); ii++){
			int i = divisors[n][ii];
			sol = ((sol + (i64)comb(i - 1, f - 1)*mobius[n / i])% MOD + MOD)%MOD;
		}
		printf("%d\n", sol);
	}
}
