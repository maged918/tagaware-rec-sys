//Language: MS C++


#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;

const int modl = 1e9 + 7;

vector<int> divisor[100010];
long long fact[100010], rfact[100010];

long long pow(long long n, int k) {
    if (k == 0) return 1;
    long long ret = pow(n, k/2);
    ret = (ret*ret) % modl;
    if (k&1) ret = (ret*n) % modl;
    return ret;
}
int C(int n, int k) {
    if (n < 0 || k < 0 || n < k) return 0;
    return (((fact[n] * rfact[k]) % modl) * rfact[n-k]) % modl;
}
int bit(int n, int k) {
    return (n>>k) & 1;
}

int main() {
    for (int i = 2; i <= 100000; i++) 
        if (divisor[i].empty()) 
            for(int j = i+i; j <= 100000; j += i)
                divisor[j].push_back(i);
    fact[0] = rfact[0] = 1;
    for (int i = 1; i <= 100000; i++) {
        fact[i] = (fact[i-1] * i) % modl;
        rfact[i] = pow(fact[i], modl-2);
    }
    // freopen("I.txt", "r", stdin);

    int q;
    scanf("%d", &q);
    for (int i = 0; i < q; i++) {
        int n, f;
        scanf("%d%d", &n, &f);
        int ret = 0;
        for (int t = 0; t < (1<<divisor[n].size()); t++) {
            int product = 1, cntBit = 0;
            for (int j = 0; j < divisor[n].size(); j++)
                if (bit(t, j)) {
                    cntBit++;
                    product *= divisor[n][j];
                }
            if (cntBit&1)
                ret = (ret - C(n/product-1, f-1)) % modl;
            else 
                ret = (ret + C(n/product-1, f-1)) % modl;
        }
        if (ret < 0) ret += modl;
        if (f == 1) ret = (n == 1);
        printf("%d\n", ret);
    }

}