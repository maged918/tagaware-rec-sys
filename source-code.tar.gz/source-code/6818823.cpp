//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#include <queue>
using namespace std;
typedef long long ll;
int a[100110];
int b[100110];
int main()
{
    int n;
    int k,p;
    cin >> n >>k>>p;
    int a_t=0;
    int b_t=0;
    for(int i=0;i<n;i++)
    {
        int kkkk;
        cin >>kkkk;
        if(kkkk%2==1)
        {
            a[a_t]=kkkk;
            a_t++;
        }
        else
        {
            b[b_t]=kkkk;
            b_t++;
        }
    }
    int oneed=p;
    int jneed=k-p;
    vector <int> anso;
    int ok=1;
    for(int  i=0;i<b_t && oneed>0;i++,oneed--)
    {
        anso.push_back(b[i]);
    }
    
    if(oneed>0)//no wan
    {
        if((a_t-jneed)>=2*oneed && (a_t%2==jneed%2) && ((a_t-jneed)%2==0))
        {
            cout<<"YES"<<endl;
            if(anso.size()!=0)
            {
            for(int i=0;i<anso.size();i++)
            {
                printf("1 %d\n",anso[i]);
            }
            }
            int j=0;
            while(oneed>1)
            {
                printf("2 %d %d\n",a[j],a[j+1]);
                j+=2;
                oneed--;
            }
            if(jneed==0)
            {
                printf("%d",a_t-j);
                for(;j<a_t;j++)
                    printf(" %d",a[j]);
                
                printf("\n");
                return 0;
            }
            else
            {
                printf("2 %d %d\n",a[j],a[j+1]);
                j+=2;
                oneed--;
            }
            for(int tt=0;tt<jneed-1;tt++,j++)
            {
                printf("1 %d\n",a[j]);
            }
            printf("%d",a_t-j);
            for(;j<a_t;j++)
            {
                printf(" %d",a[j]);
            }
            printf("\n");
        }
        else
        {
            puts("NO");
            ok=0;
        }
    }
    else
    {
        int ohave= b_t-p;
        if((a_t%2) == (jneed%2) && a_t >=jneed)
        {
            puts("YES");
            if(anso.size()!=0)
            {
            for(int tt=0;tt<anso.size()-1;tt++)
                printf("1 %d\n",anso[tt]);
            }
            int tt;
            if(jneed==0)
            {
                printf("%d",b_t - anso.size()+1+a_t);
                if(anso.size()!=0)
                {
                for(int i=anso.size()-1;i<b_t;i++)
                    {
                        printf(" %d",b[i]);
                    }
                }
                for(int i=0;i<a_t;i++)
                    printf(" %d",a[i]);
                printf("\n");
                return 0;
            }
            else
            {
                if(anso.size()!=0)
                {
                  printf("1 %d\n",anso[anso.size()-1]);
                }
            }
            for( tt=0;tt<jneed-1;tt++)
            {
                printf("1 %d\n",a[tt]);
            }
            printf("%d",a_t-tt+ohave);
            for(;tt<a_t;tt++)
            {
                printf(" %d",a[tt]);
            }
            int tmp=b_t-1;
            while(ohave>0)
            {
                printf(" %d",b[tmp]);
                ohave--;
                tmp--;
            }
            printf("\n");
            
        }
        else
        {
            puts("NO");
        }
    }
        
    return 0;
}













