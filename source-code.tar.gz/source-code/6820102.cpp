//Language: GNU C++


#pragma comment(linker,"/STACK:256000000")

#include <iostream>
#include <iomanip>
#include <cstdio>
#include <bitset>
#include <memory>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <list>
#include <string>
#include <cstring>
#include <fstream>
#include <functional>
#include <stack>
#include <complex>
#include <wchar.h>
#include <wctype.h>
#include <cmath>
#include <queue>
#include <ctime>
#include <numeric>

using namespace std;
const double PI = acos(-1.0);
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
typedef unsigned int ui;
typedef short int si;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef pair<ll,int> pli;
typedef pair<int,ll> pil;
typedef pair<double,int> pdi;
typedef pair<int,double> pid;
#define sqr(x) ((x)*(x))
//#define prob 
const int N=1e6;
int ma[N];
vector <int> v;
int main()
{
#ifdef SNELTYN
puts("Task C:");
	freopen("test.in","r",stdin);
	//freopen("test.out","w",stdout);
#endif
#ifdef prob
	freopen(prob".in","r",stdin);
	freopen(prob".out","w",stdout);
#endif
  int n;
  scanf("%d", &n);
  for(int i=0; i<n; i++)
    scanf("%d", ma+i);
  sort(ma, ma+n);
  for(int i=0; i<n; i++)
    v.push_back(ma[i]);
  for(int i=n/2-1; i>=0; i--){
    if(v[i]*2<=v.back()){
      if(!v.empty())
        v.pop_back();
      n--;
    }
  }
  cout<<n<<endl;
	return 0;
} 