//Language: GNU C++


#include<iostream>
#include<cstdlib>
using namespace std;

int compare (const void * a, const void * b)
{
  return ( *(int*)a - *(int*)b );
}


int main()
{
    long long int n,x,a[100000],ans=0,i,j,key;
     int y;
     cin>>n;
    cin>>x;
    for(int i=0;i<n;i++)
    {
            cin>>a[i]; 
     }
 qsort (a, n, sizeof(long long int), compare);

for(i=0;i<n;i++)
{     
    ans+=a[i]*x;
     if(x>1)
     x--;           
}
 
 cout<<ans;
return 0;
}
