//Language: GNU C++


#include <bits/stdc++.h>

#define pb push_back
#define mp make_pair
#define ll long long
#define ull unsigned long long

using namespace std;

const int nm=100002;

int n,m,a[nm],b[nm];

int main()
{
    #ifndef ONLINE_JUDGE
    freopen("vd.inp","r",stdin);
    freopen("vd.out","w",stdout);
    #endif
    scanf("%d%d",&m,&n);
    int i,j;
    for(i=1;i<=m;++i) scanf("%d",&a[i]);
    for(i=1;i<=n;++i) scanf("%d",&b[i]);
    sort(a+1,a+m+1);sort(b+1,b+n+1,greater<int>());
    ll kq=0;
    i=1;
    while (a[i]<b[i] && i<=m && j<=n)
    {
        kq+=(ll)(b[i]-a[i]);
        i++;
    }
    printf("%I64d",kq);
}
