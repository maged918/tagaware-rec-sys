//Language: GNU C++


#include <iostream>
#include <string>
#include <stdio.h>
using namespace std;

int main()
{
    bool flag = false;
    int n, d;
    scanf("%d%d", &n, &d);
    
    int sum=0;
    int song=0;
    for(int i=0; i<n; i++){
        scanf("%d",&song);
        sum += song;
        if(sum+(i*10)>d){
            cout << -1;
            flag = true;
            break;
        }
    }
    if(!flag){
        d-=sum;
        cout << d/5;
    }
    return 0;
}