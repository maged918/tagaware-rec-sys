//Language: GNU C++


/*ckpeteryu*/
#include<iostream>
#include<iomanip>
#include<sstream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cctype>
#include<climits>
#include<cmath>
#include<bitset>
#include<string>
#include<ctime>
#include<functional>
#include<map>
#include<set>
#include<vector>
#include<stack>
#include<queue>
#include<algorithm>
using namespace std;
#define FOR(i,s,e) for(int i=(s);i<(int)(e);i++)
#define FOE(i,s,e) for(int i=(s);i<=(int)(e);i++)
#define FOD(i,s,e) for(int i=(s);i>=(int)(e);i--)
#define FORVEC(i,a) for(int i=0;i<(int)((a).size());i++)
#define pb push_back
#define mp make_pair
#define CLR(s,x) memset(s,x,sizeof(s))
#define LL long long int
#define L long int

int main(int argc, char **argv){
		
	//ios_base::sync_with_stdio(false);
	
	
	int n,vv,num,t;
	vector<int> v;
	vector<int> ans;
	scanf("%d%d",&n,&vv);		
	FOE(k,1,n){
		scanf("%d",&num);
		FOR(i,0,num){
			scanf("%d",&t);
			v.pb(t);
		}
		sort(v.begin(),v.end());
		if(vv>v[0]){
			ans.pb(k);
		}
		v.clear();
	}
	int sz = ans.size();
	if(sz==0) printf("0");
	else{	
		printf("%d\n%d",ans.size(),ans[0]);
		if(sz>1){
			FOR(i,1,sz){
				printf(" %d",ans[i]);
			}
		}
	}
	
	ans.clear();
	
	
	
	
			
	
	
	//printf("Case #%d: Yes\n", i+1);	


	return 0;
}