//Language: GNU C++


//IN THE NAME OF GOD

#include <bits/stdc++.h>

#define F first
#define S second
#define MP make_pair
#define PB push_back
#define foro(i, a, b) for (int i = (int)(a); i < (int)(b); ++i)

using namespace std;
typedef long long ll;
typedef pair < int, int > pii;

const int Maxn = 3003;
int n, v[Maxn], num[Maxn], p, q, t, nxt = 2, st = 1;

void DFS (int st);

int main() {
    scanf ("%d", &n);
    foro(i, 1, n + 1)   scanf ("%d", &v[i]);
    cin >> q;
    foro(i, 1, n + 1)   if (!num[i])    ++p, DFS (i);
    cout << abs (n - p - q) << ' ';
    while (q < n - p) {
        while (1) {
            while(nxt <= n && num[st] != num[nxt]) ++nxt;
            if (nxt > n) {
                ++st;
                nxt = st + 1;
            }
            else    break;
        }
        printf ("%d %d ", st, nxt);
        swap (v[st], v[nxt]);
        ++p;
        DFS (nxt);
    }
    while (q > n - p) {
        while (1) {
            while(num[st] == num[nxt]) ++nxt;
            if (nxt > n) {
                ++st;
                nxt = st + 1;
            }
            else    break;
        }
        printf ("%d %d ", st, nxt);
        swap (v[st], v[nxt]);
        int a = p - 1;
        p = min (num[st], num[nxt]);
        DFS (st);DFS (nxt);    num[nxt] = st;
        p = a;
    }

    printf ("\n");

    return 0;
}

void DFS (int st) {
    num[st] = p;
    if (num[v[st]] != p)    DFS (v[st]);
}
