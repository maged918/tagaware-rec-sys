//Language: MS C++



#include <algorithm>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <bitset>
#include <sstream>

using namespace std;
int m,n,k,p[3005];
bool used[3005];

inline void use_cycle(int v){
	for(int i=v;!used[i];i=p[i])
		used[i]=true;
}
int main() {
	
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>p[i];
		p[i]--;
	}
	cin>>m;
	m=n-m;
	for(int i=0;i<n;i++){
		if(!used[i]){
			k++;
			use_cycle(i);
		}
	}
	for(int i=0;i<n;i++){
		used[i]=false;
	}
	cout<<(int)abs(k-m)<<endl;

	if(k>m){
		use_cycle(0);
		for(int i=1;i<n && k>m;i++){
			if(!used[i]){
				cout<<1<<" "<<i+1<<" ";
				k--;
				use_cycle(i);
			}
		}
	}
	if(k<m){
		for(int i=0;i<n && k<m;i++){
			vector<int>pos(n,-1);

			int cur=0;
			for(int j=p[i];j!=i;j=p[j])
				pos[j]=cur++;
			pos[i]=cur;
			
			cur=0;
			for(int j=i+1;j<n && k<m;j++){
				if(pos[j]>=cur){
					cout<<i+1<<" "<<j+1<<" ";
					k++;
					cur=pos[j]+1;
					swap(p[i],p[j]);
				}
			}
		}
	}

	return 0;
}