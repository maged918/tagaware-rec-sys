//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <queue>
#include <cstring>
#include <vector>
#include <set>
#include <map>
#include <deque>
#include <stack>
#define _USE_MATH_DEFINES
#include <math.h>
#include <assert.h>
#include <cstdlib>
#include <algorithm>
#include <list>

#define forn(i,n) for (int i=0;i<n;i++)
#define rforn(i,n) for (int i=n-1;i>=0;i--)
#define fori(i,a) for(auto i=a.begin(); i!=a.end(); ++i)
#define rfori(i,a) for(auto i=a.rbegin(); i!=a.rend(); ++i)
#define mp(a,b) make_pair(a,b)
#define LL long long
#define S(n) scanf("%d", &n)
#define Sa(n,i) scanf("%d", n+i)
#define N 100000
#define MOD 1000000007

using namespace std;

pair<int, int> s[N];
int a[N], b[N];

int main(){
#ifndef ONLINE_JUDGE
    freopen("input.txt","rt",stdin);
    //freopen("output.txt","wt",stdout);
#endif
    
    int n, u;
    cin >> n;
    forn(i, n) cin >> s[i].first, s[i].second = i;
    u = (n + 1) / 3;
    sort(s, s + n);
    forn(i, u) a[s[i].second] = i, b[s[i].second] = s[i].first - a[s[i].second];
    for(int i=u; i < 2*u; ++i) b[s[i].second] = i, a[s[i].second] = s[i].first - b[s[i].second];
    for(int i=2*u; i < n; ++i) b[s[i].second] = n - i - 1, a[s[i].second] = s[i].first - b[s[i].second];
    
    cout << "YES\n";
    forn(i, n) cout << a[i] << ' ';
    cout << '\n';
    forn(i, n) cout << b[i] << ' ';
    return 0;
}
