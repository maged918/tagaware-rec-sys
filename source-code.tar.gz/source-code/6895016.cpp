//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<cmath>
#include<iostream>
#include<string>
#include<deque>
#include<list>
#include<queue>
#include<vector>
#include<algorithm>
#include<map>
#include<stack>
#include<set>
using namespace std;
#define ll long long
#define lowbit(x) (x&-x)
#define f first
#define s second
#define pr pair<int,int>
#define mk(x,y) make_pair(x,y)
#define eps 1e-8
#define pi acos(-1.0)
#define square(x) ((x)*(x))
#define getvec(x,y) ((y)-(x))
#define xmul(x1,y1,x2,y2) ((x1)*(y2)-(x2)*(y1))
#define inf 0x3f3f3f3f
#define mod ((ll)1e9+7)
#define maxn 50

int n, a[maxn], path[maxn][maxn];
ll dp[maxn][maxn], p[maxn];
char ans[maxn];

int main()
{
#ifndef ONLINE_JUDGE
	freopen("G:\\ACM\\inandout\\in.txt","r",stdin);
//	freopen("G:\\ACM\\inandout\\out.txt","w",stdout);
#endif
    p[0] = 1; for(int i=1; i<=18; i++) p[i] = 10 * p[i-1];
    scanf("%d", &n);
    for(int i=1; i<=2*n; i++) scanf("%1d", a+i);
    memset( dp, -1, sizeof(dp));
    dp[1][1] = p[n-1]*a[1]; path[1][1] = 0;
    for(int i=1; i<2*n; i++) for(int j=0; j<=min(i,n); j++) if(dp[i][j]>=0) {
        if(j<n && dp[i][j] + p[n-j-1]*a[i+1] > dp[i+1][j+1]) {
            dp[i+1][j+1] = dp[i][j] + p[n-j-1]*a[i+1] ;
            path[i+1][j+1] = j;
        }
        if(i-j<n && dp[i][j] + p[n-i+j-1]*a[i+1] > dp[i+1][j]) {
            dp[i+1][j] = dp[i][j] + p[n-i+j-1]*a[i+1];
            path[i+1][j] = j;
        }
    }
    int x = n;
    for(int i=2*n; i>0; i--) {
        if(path[i][x] == x) ans[i] = 'M';
        else ans[i] = 'H';
        x = path[i][x];
    }
    printf("%s\n", ans+1);
	return 0;
}
