//Language: GNU C++0x


// IO
#include <iostream>

// containers
#include <array>
#include <deque>
#include <forward_list>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include <utility>

// C
#include <climits>
#include <cmath>
#include <cstring>


using namespace std;

#define setZero(g) memset(g, 0, sizeof(g))
#define FOR(i, n) for (int i = 0; i < n; ++i)
#define IFOR(i, n) for (int i = n - 1; i >= 0; --i)
#define pint pair <int, int>
#define mp(a, b) make_pair(a, b)
#define pb(a) push_back(a)
#define pbp(a, b) push_back(make_pair(a, b))
#define vsize(a) (int)a.size()

template <typename T>
void print1d(T *a, int n)
{
    FOR (i, n) {
        cout << a[i] << " ";
    }
}

template <typename T>
void print2d(T *a, int n, int m) {
    FOR (i, n) {
        FOR (j, m) {
            cout << a[i][j] << " ";
        }
        cout << "\n";
    }
}

void printVint(vector<int> v) {
    int s = vsize(v);
    FOR (i, s) {
        cout << v[i] << " ";
    }
    cout << "\n";
}

int main()
{
    int n, m, k;
    cin >> n >> m >> k;
    int g[301][301];
    setZero(g);
    
    int fill = 1;
    int cnt = 0;
    int eachSize = (n * m) / k;
    vector <int> sol;
    FOR (i, n) {
        if (i % 2 == 0) {
            FOR (j, m) {
                g[i][j] = fill;
                sol.pb(i + 1);
                sol.pb(j + 1);
                cnt++;
                if (cnt >= eachSize && fill < k) {
                    
                    cout << vsize(sol)/2 << " ";
                    printVint(sol);
                    sol.resize(0);
                    
                    fill++;
                    cnt = 0;
                }
            }
        } else {
            IFOR (j, m) {
                g[i][j] = fill;
                sol.pb(i + 1);
                sol.pb(j + 1);
                cnt++;
                if (cnt >= eachSize && fill < k) {
                    
                    cout << vsize(sol)/2 << " ";
                    printVint(sol);
                    sol.resize(0);
                    
                    fill++;
                    cnt = 0;
                }
            }
        }
    }
    cout << vsize(sol)/2 << " ";
    printVint(sol);
    
    return 0;
}
