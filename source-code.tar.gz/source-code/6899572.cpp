//Language: MS C++


#include <iostream>
#include <vector>

using namespace std;

int main()
{
    int n,v;
    vector <int> q;
    cin>>n>>v;
    q.push_back(0);
    for(int i=1;i<=n;i++)
    {
        int h;
        cin>>h;
        for(int j=0;j<h;j++)
        {
            int g;
            cin>>g;
            if(g<v&&q[q.size()-1]!=i)
            q.push_back(i);
        }
    }
    cout<<q.size()-1<<endl;
    for(int i=1;i<q.size();i++)
    {
        cout<<q[i]<<" ";
    }
    return 0;
}
