//Language: GNU C++


#include<iostream>
#include<cstring>
using namespace std;

int main()
{
	char s[201];
	int len,k,ans,i,j,t,m;
	cin>>s;
	cin>>k;
	len=strlen(s);
	ans=(len+k)/2;
	if(k>=len)
	{
		cout<<2*ans;
		return 0;
	}
	for(i=ans;i>k;i--)
	{
		for(j=0;j<=len+k-2*i;j++)
		{
//			cout<<i<<' '<<j<<'\n';
			for(t=j+i;t<len&&t<j+2*i;t++)
			{
				if(s[t]!=s[t-i])
				break;
			}
			if(t==len||t==j+2*i)
			{
				cout<<2*i;
				return 0;
			}
		}
	}
	cout<<2*i;
	return 0;
}