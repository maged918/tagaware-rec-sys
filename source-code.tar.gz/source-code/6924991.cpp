//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;

int main()
{
    ios::sync_with_stdio(false);
    int t=0,i=0,j=0,b,n=0,m,k=0,num=0,temp=0,ind;
    cin>>n;
    string str;
    double arr[102];
    for(i=0;i<n;++i)
    {
        cin>>arr[i];
    }
    sort(arr,arr+n);
    double cur=0.0,a,ans=0.0;
    for(i=n-1;i>=0;--i)
    {
        cur*=1-arr[i];
        a=arr[i];
        for(j=i+1;j<n;++j)
        {
            a*=1-arr[j];
        }
        cur+=a;
        ans=max(ans,cur);
    }
    printf("%0.9lf",ans);
    return 0;
}