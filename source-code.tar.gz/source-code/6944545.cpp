//Language: MS C++


#include <iostream>
using namespace std;

void main(){
    int n,i,sum,j,sum2;
    sum =0;
    int a[101];
    cin >> n;
    for (i = 0; i < n; i++) {
        cin >> a[i]; 
        sum += a[i];
    }
    for (i = 0; i < n-1; i++){
        for (j = i + 1; j < n; j++) { if (a[i]<a[j]) swap(a[i], a[j]); }
    }
    sum2 = a[0];
    for (i = 0; i < n; i++){
        if (sum2>(sum - sum2)) { cout << i + 1; break; }
        else sum2 += a[i + 1];
    }
}