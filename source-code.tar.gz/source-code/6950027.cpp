//Language: GNU C++



#include <bits/stdc++.h>
using namespace std;
#define rep(i, n) for (int (i) = 0; (i) < (n); (i) ++)
#define rep1(i, n) for (int (i) = 1; (i) <= (n); (i) ++)
#define For(i, a, b) for (int (i) = (a); (i) <= (b); (i) ++)
#define db(x) cout << #x << " = " << (x) << endl;
#define dba(a, x, y){cout << #a << " :";For(i, (x), (y))cout<<" "<<(a)[(i)];cout<<endl;}
#define dbp(p){cout << #p << " = (" << p.first << " " << p.second << endl;}
#define mp make_pair
#define pb push_back
#define ll long long
#define ld long double
#define pi 3.1415926535897932384626433832795028
const int INF = INT_MAX;
const ll INFL = LLONG_MAX;

int N, K, A[100100];
ll B[100100];
int okay(int index, int size)
{
    ll tot = B[index]-B[index-size];
    ll needed = A[index]*1LL*size;
    int ret = needed - tot <= K;
    return ret;
}
int binary_search(int index)
{
    int good = 1;
    int bad = index+1;
    while (good + 1 < bad)
    {
        int mid = (good+bad) >> 1;
        if (okay(index, mid)) good = mid;
        else bad = mid;
    }
    return good;
}
int main()
{
	ios_base::sync_with_stdio(0); cout.precision(15);
    cin >> N >> K;
    rep1(i, N) cin >> A[i];
    sort(A+1, A+N+1);
    rep1(i, N) B[i]=A[i]+B[i-1];
    int num_occ = 0;
    int number = 0;
    rep1(i, N)
    {
        int res = binary_search(i);
        if (res > num_occ)
        {
            num_occ=res;
            number=A[i];
        }
    }
//    dba(A, 1, N); dba(B, 1, N);
    cout << num_occ << " " << number << endl;
}
