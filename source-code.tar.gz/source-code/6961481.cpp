//Language: MS C++


//                                                      In the name of Allah
#include <iostream>
#include <algorithm>

using namespace std;

void main()
{
	int n;
	int a[105];
	cin >> n;
	for(int i = 0; i < n; i++)
		cin >> a[i];
	sort(a,a+n);
	for(int i = 0; i < n; i++)
		cout << a[i] << " ";
}   