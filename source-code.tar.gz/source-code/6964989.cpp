//Language: GNU C++


#include<iostream>
#include<string>
using namespace std;
int main()
{
    string arr[100002];
    int size;
    int counter1;
    while (cin >> size)
    {
        cin.ignore();
        counter1 = 1;
        for (int i = 0; i < size; i++)
            getline(cin, arr[i]);
        for (int i = 0; i < size; i++)
        {
            if ((arr[i] == "10" && arr[i + 1] == "01" )||( arr[i] == "01" && arr[i + 1] == "10"))
                counter1++;
        }
        cout << counter1 << endl;
    }
}