//Language: GNU C++


#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    int n,d,m=0;
    cin>>n>>d;
 int c;
 for(int i=0;i<n;i++){
 cin>>c;
 m+=c;
 }
 if(m-10 + n*10>d){cout <<-1;}
 else {cout <<(d-m)/5;}
}
