//Language: GNU C++


/*
Author: 1412kid1412@UESTC
*/

#include <stdexcept>
#include <cstdarg>
#include <iostream>
#include <fstream>
#include <exception>
#include <memory>
#include <locale>
#include <sstream>
#include <set>
#include <list>
#include <bitset>
#include <fstream>
#include <numeric>
#include <iomanip>
#include <string>
#include <utility>
#include <cctype>
#include <climits>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <map>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <vector>
#include <queue>
#include <deque>
#include <cstdlib>
#include <stack>
#include <iterator>
#include <functional>
#include <complex>
#include <valarray>
using namespace std;

const int N=510000;
int a[N],que[N];
int rear;

int main(){
    int n;
    scanf("%d",&n);
    long long ret=0;
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
        while(rear>=2&&que[rear-1]<=que[rear-2]&&que[rear-1]<=a[i]){
            ret+=min(que[rear-2],a[i]);
            rear--;
        }
        que[rear++]=a[i];
    }
    sort(que,que+rear);
    for(int i=0;i<rear-2;i++){
        ret+=que[i];
    }
    cout<<ret<<endl;
}