//Language: GNU C++


#include<iostream>
#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<math.h>
using namespace std;

void qsort(double a[],int l,int r,int b[])
{
	int i,j,tt;
	double temp,mid;
	i=l;
	j=r;
	mid=a[(l+r)/2];
	while(i<=j)
	{
		while(a[i]<mid) i++;
		while(a[j]>mid) j--;
		if (i<=j)
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
			tt=b[i];
			b[i]=b[j];
			b[j]=tt;
			i++;
			j--;
		}
	}
	if (l<j) qsort(a,l,j,b);
	if (i<r) qsort(a,i,r,b);
}

int main()
{
	long n,i,j,temp,s,x,y,q;
	double a[1005];
	int b[1005];
	cin>>n>>s;
	s=1000000-s;
	for(i=1;i<=n;i++)
	  {
	     scanf("%d %d %d",&x,&y,&b[i]);
	     a[i]=sqrt(x*x+y*y);
	  }
	qsort(a,1,n,b);
	temp=0;
	q=0;
	for(i=1;i<=n;i++)
 	{
	 	temp+=b[i];
	 	if(temp>=s) {q=i; break;}
	 }
	 if(temp>=s) printf("%.7f\n",a[q]);
	 else cout<<"-1"<<endl;
}
  		  	 		 				 		 	   	  	