//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <queue>
using namespace std;

const int N = 3003;
bool hash[30];
int main(){
    memset(hash, 0, sizeof(hash));
    char str[N];
    gets(str);
    int len = strlen(str);
    int  ans = 0;
    for(int i = 0; i < len; i ++) {
        if(str[i] >= 'a' && str[i] <= 'z'){
            int k = str[i] - 'a';
            if(!hash[k]) ans++;
            hash[k] = true;
        }
    }
    printf("%d\n",ans);
    return 0;
}
