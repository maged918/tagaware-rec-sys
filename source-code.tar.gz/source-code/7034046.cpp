//Language: GNU C++


#include <iostream>
#include <cstdio>
using namespace std;
struct edge
{
    int x,y,z;
}ed[130000];
int a[555];
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;i++) scanf("%d",&a[i]);
    double ans=0;
    for (int i=1;i<=m;i++)
    {
        int x,y;
        double z;
        scanf("%d%d%lf",&x,&y,&z);
        if ((a[x]+a[y])/z>ans) ans=(a[x]+a[y])/z;
    }
    printf("%.11f\n",ans);
    return 0;
}
