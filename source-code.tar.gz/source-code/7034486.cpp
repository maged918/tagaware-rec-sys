//Language: GNU C++


#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <ctime>
#include <utility>
#include <iterator>

using namespace std;

typedef long long ll;

#define clr(x,a) memset(x,a,sizeof(x))
#define sz(x) (int)x.size()
#define pb push_back
#define mp make_pair

#define REP(i,n) for(i=0;i<(n);++i)
#define FOR(i,l,h) for(i=(l);i<=(h);++i)
#define FORD(i,h,l) for(i=(h);i>=(l);--i)

#define lson l,m,root<<1
#define rson m+1,r,root<<1|1

#define MAXN 101100

int col[MAXN<<2];
ll val[MAXN<<2];
ll sum[MAXN<<2];

void push_up(int root){
    sum[root]=sum[root<<1]+sum[root<<1|1];
    if(col[root<<1]==col[root<<1|1])
        col[root]=col[root<<1];
    else
        col[root]=0;
}

void push_down(int root,int l,int r){
    if(val[root]){
        int m=(l+r)>>1;
        sum[root<<1]+=val[root]*(m-l+1);
        sum[root<<1|1]+=val[root]*(r-m);
        val[root<<1]+=val[root],
        val[root<<1|1]+=val[root];
        col[root<<1]=col[root<<1|1]=col[root];
        val[root]=0;
        col[root]=0;
    }
}

void build(int l,int r,int root){
    col[root]=sum[root]=val[root]=0;
    if(l==r){
        col[root]=l;
        return ;
    }
    int m=(l+r)>>1;
    build(lson);
    build(rson);
    push_up(root);
}

void update(int l,int r,int root,int L,int R,int a){
    if(L<=l&&r<=R&&col[root]){
        sum[root]+=fabs(col[root]-a)*(r-l+1);
        val[root]+=fabs(col[root]-a);
        col[root]=a;
        return;
    }
    int m=(l+r)>>1;
    push_down(root,l,r);
    if(L<=m) update(lson,L,R,a);
    if(R>m) update(rson,L,R,a);
    push_up(root);
}

ll query(int l,int r,int root,int L,int R){
    if(L<=l&&r<=R) return sum[root];
    int m=(l+r)>>1;
    push_down(root,l,r);
    ll res=0;
    if(L<=m) res+=query(lson,L,R);
    if(R>m) res+=query(rson,L,R);
    push_up(root);
    return res;
}

int main(){
    int a,b,c,d;
    int i,j,k;
    int n,m;
    while(~scanf("%d%d",&n,&m)){
        build(1,n,1);
        REP(i,m){
            scanf("%d",&a);
            if(a==1){
                scanf("%d%d%d",&b,&c,&d);
                update(1,n,1,b,c,d);
            }else{
                scanf("%d%d",&b,&c);
                printf("%I64d\n",query(1,n,1,b,c));
            }
        }
    }
    return 0;
}
