//Language: GNU C++


#include <stdio.h>
#include <cstring>
#include <cstdlib>
#include <algorithm>
           
using namespace std;
#define lson o<<1
#define rson o<<1|1
#define max(a,b) (a)>(b)?(a):(b)
#define min(a,b) (a)<(b)?(a):(b)
#define INF 200000000
#define MAX 100010           
typedef long long ll;
int color[MAX<<2];
ll val[MAX<<2],addo[MAX<<2];
int y1,y2,co;
int abs(int x){
    return x>0?x:-x;
}
void build(int o,int l,int r){
         val[o]=0;addo[o]=0;
          if(l==r)color[o]=l;
          else{
               int mid=(l+r)>>1;
               color[o]=0;
               build(lson,l,mid);
               build(rson,mid+1,r);
          }
}   
void addv(int o,ll v){
   val[o]+=v;
   if(o!=1){
         addv(o>>1,v);
   }
}
void down(int o,int l,int r){
   if(l<r){
           color[rson]=color[o];
           color[lson]=color[o];
           color[o]=0;
   }
}

void add(int o ,int l,int r,int ran){
     int mid=(l+r)>>1;
     if(ran){
        if(color[o]==0){
          add(lson,l,mid,ran);
          add(rson,mid+1,r,ran);
        }else{
          addo[o]+=abs(color[o]-co);
          addv(o,(ll)abs(color[o]-co)*(r-l+1));
        }
     }else{
     if(y1<=l&&y2>=r){
        if(color[o]==0){
          add(lson,l,mid,1);
          add(rson,mid+1,r,1);
          color[o]=co;
        }else{
          addo[o]+=abs(color[o]-co);
          addv(o,(ll)abs(color[o]-co)*(r-l+1));
          color[o]=co;
        }
     }else{
        if(color[o])down(o,l,r);
        if(y1<=mid)add(lson,l,mid,ran);
        if(y2>mid)add(rson,mid+1,r,ran);
     }
   }
}  
ll que(int o,int l,int r,ll ad){
    if(y1<=l&&y2>=r){
       return val[o]+ad*(r-l+1);
    }else{
          ll v=0;
          int mid=(l+r)>>1;
          if(y1<=mid)v+=que(lson,l,mid,ad+addo[o]);
          if(y2>mid)v+=que(rson,mid+1,r,ad+addo[o]);
          return v;
    }
}      
int main(){//freopen("e.in","r",stdin);freopen("e.out","w",stdout);
     int n,m;
     scanf("%d%d",&n,&m);
     build(1,1,n);
     int i;
     for(i=0;i<m;i++){
        int ty;
        scanf("%d",&ty);
        if(ty==1){
          scanf("%d%d%d",&y1,&y2,&co);
          add(1,1,n,0);
        }else{
              scanf("%d%d",&y1,&y2);
              printf("%I64d\n",que(1,1,n,0));
        }
     }
     //system("pause");
     return 0;
}
