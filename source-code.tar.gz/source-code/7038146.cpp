//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<cmath>
int che[1300];
int fri[1300];
int find(int a){
    int x = a;
    while(che[x] != x)
        x = che[x];
    return x;
}
void merge(int a,int b){
    int x, y;
    x = find(a);
    y = find(b);
    if(x != y)
    {
        che[x] = y;
        fri[y] += (fri[x]+1);
        fri[x] = 0;
    }
}
int main(){
    int n,m,i,j,a,b;
    unsigned long long sum;
    
    while(scanf("%d%d",&n,&m)!=EOF){
        memset(fri,0,sizeof(fri));
        for(i=1;i<=n;i++)
            che[i] = i;
        for(i=0;i<m;i++){
            scanf("%d%d",&a,&b);
            merge(a,b);
        }
        sum = 1;
        for(i=1;i<=n;i++)
            if(fri[i])
                sum *= (long long)pow(2,fri[i]);
        printf("%I64u\n",sum);
    }
    return 0;
}
