//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<algorithm>
#include<vector>
#include<set>
#include<utility>
#include<cstring>
#include<stack>
#include<queue>
#include<map>
#include<deque>
#include<cmath>
#include<map>
using namespace std;

typedef pair<int, int> pii;
typedef pair<int, pii> edge;
typedef long long LL;

const int maxn = 500003;
int n;
pii mat[maxn];
int arr[maxn];
int prev[maxn];
int nxt[maxn];

int main() {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
        mat[i] = pii(arr[i], i);
    }
    sort(mat, mat + n);
    for (int i = 0; i < n; i++) {
        prev[i] = i - 1;
        nxt[i] = i + 1;
    }
    LL ans = 0;
    for (int i = 0, lp = 0, rp = n - 1; i < n - 2; i++) {
        int ix = mat[i].second, val = mat[i].first;
        if (ix == lp) {
            ans += val;
            lp = nxt[lp];
        }
        else if (ix == rp) {
            ans += val;
            rp = prev[rp];
        }
        else {
            int a = arr[prev[ix]];
            int b = arr[nxt[ix]];
            ans += min(a, b);
            prev[nxt[ix]] = prev[ix];
            nxt[prev[ix]] = nxt[ix];
        }
    }
    cout << ans ;
}
