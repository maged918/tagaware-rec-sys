//Language: GNU C++


#include <bits/stdc++.h>
#define maxn 1010
#define f first
#define s second
#define mp make_pair

using namespace std;
typedef long long ll;
typedef pair <int,int> p1;
int n,dem,b[2][maxn],kt[maxn][maxn];
pair <int,p1> a[maxn*maxn];

void nhap()
{
    cin>>n;
    memset(kt,0,sizeof(kt));
    memset(b,0,sizeof(b));
    int u,v;
    for (int i=1 ; i<n ; i++)
    {
        cin>>u>>v;
        b[0][u]++;
        b[1][v]++;
        kt[u][v]=1;
    }
}

void cbi(int x)
{
    for (int i=1 ; i<x ; i++)
        if (kt[x][i]) b[1][i]--;
}

int tim(int x,int sh)
{
    for (int i=x ; i>=1 ; i--)
        if ((sh && !b[sh][i]) || (!sh && b[sh][i])) return i;
}

void xuli()
{
    int j;
    for (int i=n ; i>=2 ; i--)
    {
        j=tim(i,1);
        if (j!=i)
        {
            a[++dem]=mp(2,mp(j,i));
            swap(b[1][i],b[1][j]);
            for (int k=1 ; k<=i ; k++)
                swap(kt[k][i],kt[k][j]);
        }
        j=tim(i,0);
        if (j!=i)
        {
            a[++dem]=mp(1,mp(j,i));
            swap(b[0][i],b[0][j]);
            for (int k=1 ; k<i ; k++)
                swap(kt[i][k],kt[j][k]);
        }
        cbi(i);
    }
}

void ghikq()
{
    cout<<dem<<endl;
    for (int i=1 ; i<=dem ; i++)
        printf("%d %d %d\n",a[i].f,a[i].s.f,a[i].s.s);
}

int main()
{
    #ifndef ONLINE_JUDGE
    freopen("C.inp","r",stdin );
    freopen("C.out","w",stdout);
    #endif // ONLINE_JUDGE
    nhap();
    xuli();
    ghikq();
    return 0;
}
