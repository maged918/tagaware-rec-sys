//Language: GNU C++


/*
 * =====================================================================================
 *
 *       Filename:  dzy_loves_chessboard.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  07/11/2014 23:40:10
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */

#include <cstdio>
#define nmax 102

using namespace std;

void solve(char a[][nmax], char b[][nmax], int n, int m)
{
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			if (a[i][j] == '-')
				b[i][j] = a[i][j];
			else
				if ((i + j) % 2 == 0)
					b[i][j] = 'B';
				else
					b[i][j] = 'W';
}

int main()
{
	int n, m;
	char a[nmax][nmax], b[nmax][nmax];

	scanf("%d %d", &n, &m);

	for (int i = 1; i <= n; i++)
	{
		scanf("\n");
		for (int j = 1; j <= m; j++)
			scanf("%c", &a[i][j]);
	}
	

	solve(a, b, n, m);
	
	for (int i = 1; i <= n; i++)
	{
		printf("\n");
		for (int j = 1; j <= m; j++)
			printf("%c", b[i][j]);
	}

	return 0;
}

