//Language: GNU C++


//BISMILLAHIR RAHMANIR RAHIM
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
#include<queue>
#include<stack>
#include<map>
#include<string>
#include<vector>
#include<algorithm>


typedef long long  ll;
using namespace std;
struct T{
int a;
};
ll modd = 1e9 + 7;
map <int, int> M;
ll comb[20000][510];

ll rez = 1;
int main()
{
   int i, j, k, n, x;
      scanf("%d",&n);
      for(i=0;i<n;i++)
      {
          scanf("%d",&x);
          for(j=2;j*j<=x;j++)
              while(x%j==0)
              {
                  M[j]++;
                  x/=j;
              }
          if(x>1)
             M[x]++;
      }
      for(i=0;i<20000;i++)
        comb[i][0]=1;
      for(i=1;i<20000;i++)
      {
          for(j=1;j<=505;j++)
          {
              comb[i][j]=(comb[i-1][j]+comb[i-1][j-1])%modd;
          }
      }

      for (map <int, int>::iterator it = M.begin(); it != M.end(); it++)
        rez = (rez * comb[n + it->second - 1][n - 1]) % modd;

    printf("%I64d\n",rez);
    return 0;
}
