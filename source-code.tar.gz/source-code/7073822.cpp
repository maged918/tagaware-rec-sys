//Language: GNU C++


#include <iostream>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <iterator>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <map>

using namespace std;

const int MAXN=100002;

long long x;

long long get_next_x()
{
	x = (x * 37 + 10007) % 1000000007;
	return x;
}

int main()
{
	int i,j;
	int n,d;
	int a[MAXN],b_indexes[MAXN],a_indexes[MAXN];
	bool b[MAXN];
	cin >> n >> d >> x;
	for (i=0;i<n;i++)
		a[i]=i+1;
	for (i=0;i<n;i++)
		swap(a[i],a[get_next_x()%(i+1)]);
	for (i=0;i<d;i++)
		b[i]=true;
	for (i=d;i<n;i++)
		b[i]=false;
	for (i=0;i<n;i++)
		swap(b[i],b[get_next_x()%(i+1)]);
	/*
	for (i=0;i<n;i++)
		cout << a[i] << " ";
	cout << endl;
	for (i=0;i<n;i++)
		cout << b[i] << " ";
	cout << endl;
	*/
	j=0;
	for (i=0;i<n;i++)
	{
		a_indexes[a[i]]=i;
		if (b[i])
			b_indexes[j++]=i;
	}
	b_indexes[j]=MAXN+1;

	int s=40;
	for (i=0;i<n;i++)
	{
		int s2=min(s,n-1);
		for (j=n;j>=n-s2;j--)
		{
			if (a_indexes[j]<=i && b[i-a_indexes[j]])
			{
				printf("%d\n",j);
				break;
			}
		}
		if (j<n-s2)
		{
			int ans=0;
			for (j=0;b_indexes[j]<=i;j++)
			{
				int now=a[i-b_indexes[j]];
				if (now>ans)
					ans=now;
			}
			printf("%d\n",ans);
		}
	}
}