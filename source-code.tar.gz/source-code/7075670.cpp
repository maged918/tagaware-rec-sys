//Language: GNU C++


#include <bits/stdc++.h>
#include <fstream>
using namespace std;
typedef long long ll;
typedef long double ld;
typedef vector<int> vi;
typedef vector<long long> vll;
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;
#define repi(i,a,b) for(__typeof(b) i = a;i<b;i++)
#define to(a) __typeof(a)
#define all(vec)  vec.begin(),vec.end()
#define fill(a,val)  memset(a,val,sizeof(a))
#define repii(i,a,b) for(__typeof(b) i = a;i<=b;i++)
#define repr(i,b,a) for(__typeof(b) i = b;i>a;i--)
#define repri(i,b,a) for(__typeof(b) i = b;i>=a;i--)
#define tr(vec,it)  for(__typeof(vec.begin())  it = vec.begin();it!=vec.end();++it)
#define ff first
#define ss second
#define pb push_back
#define mp make_pair

int n,p,a,idx=-1;
bool hashed[301];
bool first=true;

int main()
{
  cin >> p >> n;
  repi(i,0,p)
    hashed[i]=false;
  repi(i,0,n)
  {
    cin >> a;
    if(hashed[a%p] && first)
    {
      idx=i+1;
      first=false;
    }
    else
      hashed[a%p]=true;
  }
  cout << idx << endl;
  return 0;
}
