//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
#define maxn 1005
#define maxk 1000005
#define LL long long
#define INF 1LL<<60
LL mp[maxn][maxn];
LL col[maxk],row[maxk];
priority_queue <LL> qr,qc;

int main()
{
    LL n,m,k,p;
    scanf("%I64d%I64d%I64d%I64d",&n,&m,&k,&p);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            scanf("%I64d",&mp[i][j]);

    for(int i=1;i<=n;i++)
    {
        LL tmp=0;
        for(int j=1;j<=m;j++)
            tmp+=mp[i][j];
        qr.push(tmp);
    }

    for(int j=1;j<=m;j++)
    {
        LL tmp=0;
        for(int i=1;i<=n;i++)
            tmp += mp[i][j];
        qc.push(tmp);
    }

    for(int i=1;i<=k;i++)
    {
        LL tmp = qr.top();
        qr.pop();
        row[i] = row[i-1]+tmp;
        qr.push(tmp-p*m);

        tmp = qc.top();
        qc.pop();
        col[i] = col[i-1]+tmp;
        qc.push(tmp-p*n);
    }
    LL res = -INF;
    for(int i=0;i<=k;i++)
        res = max(res,row[i]+col[k-i]-p*i*(k-i));
    printf("%I64d\n",res);
    return 0;
}
