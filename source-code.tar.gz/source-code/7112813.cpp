//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std ;

int a , k , P ;

double p ;

double f[210][210] ;

int main() {
    scanf("%d%d%d",&a,&k,&P) ;
    p = P/100.0 ;
    for(int i = 0 ; i <= k ; i++)
        for(int j = 0 ; j <= k ; j++) 
            if(!i) for(int t = a+j ; !(t&1) ; ++f[i][j] , t>>=1) ;
            else {
                f[i][j] += (1-p) * f[i-1][j+1] ;
                if(!(j&1)) {
                    f[i][j] += p * (f[i-1][j/2] + 1) ;
                }
            }
    printf("%.10f",f[k][0]) ;
    return 0 ;
}
