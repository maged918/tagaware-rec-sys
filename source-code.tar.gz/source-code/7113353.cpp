//Language: GNU C++0x


#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <vector>
#include <ctime>
#include <cmath>
#include <cstdio>
#include <string>
#include <cstring>
#include <cassert>
#include <numeric>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long       LL;
typedef pair<int, int>  PII;
typedef vector<int>     VI;
typedef vector<PII>     VPII;
#define MM(a,x) memset(a,x,sizeof(a));
#define ALL(x)  (x).begin(), (x).end()
#define P(x)	cerr<<"["#x<<" = "<<(x)<<"]"<<endl;
#define PP(x,i)	cerr<<"["#x<<i<<" = "<<x[i]<<"]"<<endl;
#define P2(x,y)	cerr<<"["#x" = "<<(x)<<", "#y" = "<<(y)<<"]"<<endl;
#define TM(a,b)	cerr<<"["#a" -> "#b": "<<1e3*(b-a)/CLOCKS_PER_SEC<<"ms]\n";
#define UN(v)   sort(ALL(v)), v.resize(unique(ALL(v))-v.begin())
#define mp make_pair
#define pb push_back
#define x first
#define y second
struct _ {_() {ios_base::sync_with_stdio(0);}} _;
template<class A, class B> ostream& operator<<(ostream &o, pair<A, B> t) {o << "(" << t.x << ", " << t.y << ")"; return o;}
template<class T> string tostring(T x, int len = 0, char c = '0') {stringstream ss; ss << x; string r = ss.str(); if(r.length() < len) r = string(len - r.length(), c) + r; return r;}
template<class T> void PV(T a, T b, int n = 0, int w = 0, string s = " ") {int c = 0; while(a != b) {cout << tostring(*a++, w, ' '); if(a != b && (n == 0 || ++c % n)) cout << s; else cout << endl;}}
template<class T> inline bool chmin(T &a, T b) {return a > b ? a = b, 1 : 0;}
template<class T> inline bool chmax(T &a, T b) {return a < b ? a = b, 1 : 0;}
const LL linf = 0x3f3f3f3f3f3f3f3fLL;
const int inf = 0x3f3f3f3f;
const int mod = int(1e9) + 7;

int n;
int a[23];

vector<bool> dp, ndp;
VPII v[23];

int main() {
	cin >> n;
	for(int i = 0; i < n; i++) cin >> a[i];

	for(int i = 1; i < n; i++)
		for(int j = 0; j < i; j++)
			for(int k = j; k < i; k++)
				if(a[j] + a[k] == a[i]) v[i].pb(mp(j, k));

	dp.resize(1 << 23);
	ndp.resize(1 << 23);
	
	int res = inf;
	dp[1] = 1;
	for(int i = 0; i + 1 <= n; i++) {
		fill(ALL(ndp), 0);
		for(int j = 0; j < (1 << (i + 1)); j++) {
			if(!dp[j]) continue;
			if(i + 1 == n) {
				chmin(res, (int) bitset<25>(j).count());
				continue;
			}
			for(auto o : v[i + 1]) {
				int x = o.x, y = o.y;
				if((j >> x & 1) && (j >> y & 1)) {
					int to = j + (1 << (i + 1));
					ndp[to] = 1;
					for(int k = 0; k <= i; k++) 
						if(j >> k & 1) ndp[to - (1 << k)] = 1;
					break;
				}
			}
		}
		dp.swap(ndp);
	}
	if(res == inf) res = -1;
	cout << res << endl;
	return 0;
}
