//Language: GNU C++


#include <iostream>
using namespace std;

int main()  {
    long long int all, num, now = 1, input, ans = 0;

    cin >> all >> num;


    for (int i = 0; i < num; i++)   {
        cin >> input;

        if (input >= now)
            ans += input - now;
        else
            ans += all - now + input;

        now = input;
    }

    cout << ans << endl;

    return 0;
}
