//Language: GNU C++


#include <cstdio>
#include <algorithm>
#define LL long long
#define REP(i,n) for (int i=1;i<=n;++i)
using namespace std;

LL x,k,leave;
LL b[1000010];

void Dfs(LL x,LL k) {
	if (!k) {
		if (!leave) return;
		printf("%I64d ",x);--leave;
		if (!leave) return;
		return;
	}
	if (!leave) return;
	if (x==1) {printf("1 ");--leave;return;}
	if (!leave) return;
	int num=0;
	REP(i,b[0]) {
		if (b[i]>x) break;
		if (x%b[i]==0) ++num;
	}
	if (num==2) {
		LL tmp=min(leave,k);
		REP(i,tmp) {
			if (!leave) return;
			printf("1 ");--leave;
			if (!leave) return;
		}
		if (!leave) return;
		printf("%I64d ",x);--leave;
		if (!leave) return;
	} else
		REP(i,b[0]) {
			if (b[i]>x) break;
			if (x%b[i]==0) Dfs(b[i],k-1);
		}
}

int main() {
	scanf("%I64d%I64d",&x,&k);
	if (x==1) {puts("1");return 0;}
	k=min(k,100000ll);
	for (LL i=1;i*i<=x;++i)
		if (x%i==0) {
			b[++b[0]]=i;
			if (i*i!=x) b[++b[0]]=x/i;
		}
	sort(b+1,b+b[0]+1);
	leave=100000;
	Dfs(x,k);
	return 0;
}