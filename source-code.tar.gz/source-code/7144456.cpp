//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <cassert>
#include <time.h>
#include <ctime>
#include <utility>
#define pb push_back
#define mp make_pair
#define INF 0x3f3f3f3f

using namespace std;
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

ll n, m, k;

ll f(ll x){
  ll ans = 0;
  for(ll i = 1LL; i <= n; i++)
    ans += min(m, (ll)x/i);
  return ans;
}

ll bsearch(ll b, ll e){
  ll ans = -1;

  while(b < e){
    ll mid = (b+e)/2;
    ans = f(mid);

    if(ans < k)
      b = mid+1;
    else
      e = mid;
  }
  return b;
}

int main(){

  cin >> n >> m >> k;
  ll ans = bsearch(1, (ll)n*m);
  cout << (ll)ans << endl;

  return 0;
}
