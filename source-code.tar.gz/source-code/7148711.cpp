//Language: GNU C++


#include<iostream>
#include<string>
using namespace std;
int main()
{
    string t,s;
    getline(cin,s);
    getline(cin,t);
	string scopy(s);
    bool automation = true;
    bool array = true;
    int pos = 0;
    int pos2 = 0;
    for(int i = 0;i < t.length();i++)
    {
        pos = s.find_first_of(t[i],pos);
		if(pos != -1)
			pos++;
        pos2 = scopy.find_first_of(t[i],0);
		if(pos == -1)
            automation = false;
        if(pos2 == -1)
            array = false;
		else
			scopy[pos2]='0';
    }
    if(s.length() < t.length())
    {
        cout <<"need tree";
        return 0;
    }
    if(automation)
    {
        cout <<"automaton";
        return 0;
    }
    if(array && s.length() == t.length())
    {
        cout << "array";
        return 0;
    }
    if(array)
    {
        cout << "both";
        return 0;
    }
    cout << "need tree";
    return 0;
}
