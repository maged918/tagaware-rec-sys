//Language: GNU C++


#include<iostream>
#include<cmath>
#include<algorithm>
#include<string>
#include<string.h>
#include<vector>
#include<set>
#include<map>
#include<cstdio>
#include<queue>
#include<sstream>
#include<list>
#include<bitset>
using namespace std;

typedef long long Int;
#define FOR(i,a,b) for(int i=(a); i<=(b);++i)
#define mp make_pair
#define pb push_back
#define sz(s) (int)((s).size())
const int inf = 1000000000;
const int MOD = 1000000007;
const double pi=acos(-1.0);


vector<int> g[100009];
vector<Int> ans;
map<Int,int> mem;
vector<Int> d;

void dfs(Int n, Int k) {
	if(sz(ans)>100000) return;
	if(n==1) {
		ans.pb(1);
		return ;
	}
	if(k==0) {
		ans.pb(n);
		return;
	}
	
	int id = mem[n];

	FOR(i,0,sz(g[id])-1) {
		dfs(d[g[id][i]], k-1);
	}
}

int main() {
	//freopen("input.txt","r",stdin);freopen("output.txt","w",stdout);
	Int n,k;
	cin>>n>>k;
	
	for(Int i=1; i*i<=n;++i)if(n%i==0) {
		d.pb(i);
		if(i*i!=n) d.pb(n/i);
	}
	sort(d.begin(), d.end());
	FOR(i,0,sz(d)-1) FOR(j,0,i) if(d[i]%d[j]==0) g[i].pb(j);
	
	FOR(i,0,sz(d)-1) mem[d[i]]=i;


	ans.clear();
	dfs(n, k);

	FOR(i,0,min(sz(ans)-1, 100000-1)) cout<<ans[i]<<" ";cout<<endl;
}