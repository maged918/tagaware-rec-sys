//Language: GNU C++


#include<iostream>
#include<iomanip>
#include<cstring>
#include<stdio.h>
#include<map>
#include<cmath>
#include<algorithm>
#include<vector>
#include<stack>
#include<fstream>
#include<queue>
#define rep(i,n) for(int i=0;i<n;i++)
#define fab(i,a,b) for(int i=(a);i<=(b);i++)
#define fba(i,b,a) for(int i=(b);i>=(a);i--)
#define MP make_pair
#define PB push_back
#define cls(x) memset(x,0,sizeof(x))
#define lowbit(x) x&-x
#define INF 0x7ffffff
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
#define LL long long
using namespace std;
typedef pair<int,int>PII;
const int N=100005;
int prime[N];
vector<PII>res;
bool used[N];
int n;
void init(){
    cls(used);
    cls(prime);
    prime[0]=prime[1]=1;
    fab(i,2,n){
        if(prime[i]==0){
            for(int j=i*i;j<=n;j+=i){
                prime[j]=1;
            }
        }
    }
}
int main(){
    ios::sync_with_stdio(false);
    scanf("%d",&n);
    for(int i=3;i<=n/2;i++){
        if(prime[i]==0){
            vector<int>t;
            for(int j=i;j<=n;j+=i){
                if(!used[j])t.PB(j);
            }
            if(t.size()%2==0){
                for(int j=0;j<t.size();j+=2){
                    res.PB(MP(t[j],t[j+1]));
                    used[t[j]]=used[t[j+1]]=1;
                }
            }else{
                rep(j,t.size()){
                    if(t[j]%2==0){
                        swap(t[j],t.back());
                        break;
                    }
                }
                for(int j=0;j<t.size()-1;j+=2){
                    res.PB(MP(t[j],t[j+1]));
                    used[t[j]]=used[t[j+1]]=1;
                }
            }
        }
    }
    vector<int>t;
    for(int i=2;i<=n;i++){
        if(!used[i]&&i%2==0){
            t.PB(i);
        }
    }
    if(t.size()%2)t.pop_back();
    for(int i=0;i<t.size();i+=2){
        res.PB(MP(t[i],t[i+1]));
    }
    printf("%d\n",res.size());
    rep(i,res.size()){
        printf("%d %d\n",res[i].first,res[i].second);
    }
}
