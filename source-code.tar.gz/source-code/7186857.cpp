//Language: GNU C++


#include<cstdio>
using namespace std;
typedef long long ll;
ll j,n,m,k,ans,i,d,dd,x,xx;
int main()
{
 scanf("%I64d%I64d%I64d",&n,&m,&k);ans=0;
 if (n+m-2<k){
  printf("-1\n");return 0;}
  else {
  for (i=1;i*i<=n;i++)if (n%i==0)
     {j=n/i;
      d=j-1;
      if (d<=k){
      dd=k-d;
      x=n/j;
      xx=m/(dd+1);
      if (x*xx>ans)ans=x*xx;
                     }
      
      j=i;
      d=j-1;if (d<=k){
      dd=k-d;x=n/j;
      xx=m/(dd+1);
      if (x*xx>ans)ans=x*xx;
                     }
     }
  for (i=1;i*i<=m;i++)if (m%i==0)
     {j=m/i;
      d=j-1;
      if (d<=k){
      dd=k-d;
      x=m/j;
      xx=n/(dd+1);
      if (x*xx>ans)ans=x*xx;
                     }
      
      j=i;
      d=j-1;if (d<=k){
      dd=k-d;x=m/j;
      xx=n/(dd+1);
      if (x*xx>ans)ans=x*xx;
                     }
     }
       }
  printf("%I64d\n",ans);
  return 0;
}
