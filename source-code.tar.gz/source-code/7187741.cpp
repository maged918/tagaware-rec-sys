//Language: GNU C++


#include <iostream>
using namespace std;
int n,m,sv=0;
pair <int, int> p [900000];
int main(){
	cin>>n>>m;
	for(int i=0;i<n;i++) cin>>p[i].first, p[i].second=i+1, sv++;
	for(int i=0;i<10000;i++){ if(p[i].first==0){ cout<<p[i-1].second; return 0; }           
	p[i].first-=m;
	if(p[i].first>0){ p[sv].first=p[i].first; p[sv].second=p[i].second; sv++; } 
	}
	return 0;
}