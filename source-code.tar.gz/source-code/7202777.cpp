//Language: GNU C++


#include<stdio.h>
long long MOD=1000000007;
int main()
{   long long x,y,n,f[4],a,count,ans;
    scanf("%lld %lld",&x,&y);
    f[3]=y-x;
    f[1]=x;
    f[2]=y;
    scanf("%lld",&n);
    if(n==1||n==2||n==3)
    {
        if(f[n]<0)
        {   if((-1)*(f[n])>MOD)
             f[n]=(3*MOD+f[n])%MOD;
             else
             f[n]=(MOD+f[n])%MOD;
        }
        printf("%lld\n",f[n]%MOD);
    }
    else
    {
    count=1;
    a=n-3;
    while(a!=1&&a!=2&&a!=3)
    {
        a=a-3;
        count++;
    }
    if(count%2==0)
    {
        ans=f[a];
        if(ans<0)
            ans=(3*MOD+ans)%MOD;
        printf("%lld\n",ans%MOD);
    }
    else
    {
      ans=f[a];
      if(ans>0)
      {    if(ans>MOD)
           ans=(3*MOD-ans)%MOD;
           else
           ans=(MOD-ans)%MOD;
      }
      else
        {
            ans=(-1)*ans;
            ans = ans%MOD;
        }
      printf("%lld\n",ans%MOD);
    }
    }
    return 0;
}
