//Language: MS C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>

using namespace std;

int main()
{
     long long int w,m,k,y=0,t=1,r=0;
     cin>>w>>m>>k;
     w/=k;
     while(m>t)
     {
          r++;
          t*=10;
     }
     while(w>=(t-m)*r)
     {
          y+=t-m;
          w-=(t-m)*r;
          m=t;
          t*=10;
          r++;
     }
     y+=w/r;
     cout<<y<<endl;
     return 0;
}
