//Language: GNU C++


#include<cstdio>
#include<algorithm>
#define N 8500
using namespace std;
typedef long long ll;
ll n,m,a[N];
int i,len,j,k;
short b[N][N];
void dfs(int x,int cen)
 { if (!len)return;
  if (x==1||cen==m)
      {printf("%I64d ",a[x]);
       len--;return;
      }
  for (int i=1;i<=*b[x];i++)dfs(b[x][i],cen+1);
 }
int main()
{
 scanf("%I64d%I64d",&n,&m);
 k=0;
 for (i=1;1ll*i*i<=n;i++)
    if (n%i==0){
     a[++k]=i;
     if ((n/i)!=i)a[++k]=n/i;
               }
 sort(a+1,a+k+1);
 for (i=1;i<=k;i++)
  for (j=1;j<=i;j++)if (a[i]%a[j]==0)b[i][++*b[i]]=j;
 len=100000;
 dfs(k,0);
 return 0; 
}