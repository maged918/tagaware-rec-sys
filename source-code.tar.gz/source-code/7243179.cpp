//Language: GNU C++


#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

const int BMAX = 350, NMAX = 100010;

int N, M, Q, K, Heavy[NMAX], Int[NMAX][BMAX];
bool Have[BMAX][NMAX];
vector<int> P[NMAX], HP;
long long InitAns[NMAX], Cnt[NMAX], Added[NMAX], V[NMAX], X;

int main()
{
   // ifstream cin("e.in");
   // ofstream cout("e.out");

    cin >> N >> M >> Q;
    for(int i = 1; i <= N; ++ i)
        cin >> V[i];

    for(int i = 1; i <= M; ++ i)
    {
        cin >> K;
        for(int j = 1; j <= K; ++ j)
        {
            cin >> X;
            P[i].push_back(X);
            InitAns[i] += V[X];
        }

        if(K >= BMAX)
        {
            Heavy[i] = 1;
            HP.push_back(i);
        }
    }

    for(int i = 0; i < HP.size(); ++ i)
        for(int j = 0; j < P[ HP[i] ].size(); ++ j)
            Have[i][ P[HP[i]][j] ] = 1;

    for(int i = 1; i <= M; ++ i)
        for(int j = 0; j < P[i].size(); ++ j)
            for(int k = 0; k < HP.size(); ++ k)
                if(Have[k][ P[i][j] ])
                    Int[i][k] ++;

    for(; Q; Q --)
    {
        char Type;
        cin >> Type;
        if(Type == '+')
        {
            cin >> K >> X;
            if(Heavy[K] == 0)
            {
                for(int i = 0; i < P[K].size(); ++ i)
                {
                    V[ P[K][i] ] += X;
                    Added[K] += X;
                }
                for(int i = 0; i < HP.size(); ++ i)
                    Added[ HP[i] ] += 1LL * Int[K][i] * X;
            }else
            {
                Cnt[K] += X;
            }
        }else
        {
            cin >> K;
            if(Heavy[K] == 0)
            {
                long long Ans = 0;
                for(int i = 0; i < P[K].size(); ++ i)
                    Ans += V[ P[K][i] ];
                for(int i = 0; i < HP.size(); ++ i)
                    Ans += 1LL * Cnt[ HP[i] ] * Int[K][i];
                cout << Ans << "\n";
            }else
            {
                long long Ans = InitAns[K] + 1LL * Cnt[K] * P[K].size() + Added[K];
                int IndexHP;

                for(int i = 0; i < HP.size(); ++ i)
                    if(HP[i] == K)
                        IndexHP = i;

                for(int i = 0; i < HP.size(); ++ i)
                    if(HP[i] != K)
                        Ans += 1LL * Cnt[ HP[i] ] * Int[ HP[i] ][IndexHP];
                cout << Ans << "\n";
            }
        }
    }
}
