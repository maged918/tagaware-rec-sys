//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define X first
#define Y second
#define Sz size()
#define spa <<" "
#define lin <<endl
#define mp make_pair
#define foreach(i, x) for(__typeof((x).begin()) i = (x).begin(); i != (x).end(); i ++)
#define Say(x) cerr << #x << " = " << x << endl
#define For(i, n) for(int i = 0; i < (n); i++)
#define All(x) ((x).begin(), (x).end())
typedef long long ll;
typedef vector <int> vint;
typedef pair <int,int> pii;

const int M = 500 * 1000 + 4, Inf = 1e9 + 10;
int a[M], b[M], nx[M], pr[M];
bool cmp(int x, int y)
{
	return (a[x] < a[y]);
}
int main()
{
	ios::sync_with_stdio(false);
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i], b[i] = i, nx[i] = i + 1, pr[i] = i - 1;
	ll ans = 0;
	sort(b + 1, b + n + 1, cmp);
	int mn = 0;
	for (int i = 1; i <= n; i++)
	{
		int tmp = ans;
		int j = b[i];
		ans += (a[j] - mn) * max(n - i - 1, 0);
		//cout << ans - tmp spa;
		mn = a[j];
		ans += max(min(a[pr[j]], a[nx[j]]) - mn, 0);
		pr[nx[j]] = pr[j];
		nx[pr[j]] = nx[j];
		//cout << a[j] spa << ans - tmp lin;
	}
	cout << ans lin;
	return 0;
}
