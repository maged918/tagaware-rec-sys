//Language: GNU C++


#include<stdio.h>
#include<string.h>
int a[101]= {0};
int main()
{
    int n,i,j=1,m,t=0,q=0;
    while(~scanf("%d",&n))
    {
        j=1;
        t=0;
        q=0;
        memset(a,0,sizeof(a));
        for(i=1; i<=n; i++)
        {
            scanf("%d",&m);
            if(m<0)
                t++;
            if(t>=3)
            {
                t=1;
                a[j++]=q;
                q=1;
            }
            else
                q++;
        }
        a[j]=q;
        printf("%d\n",j);
        for(i=1; i<=j; i++)
        {
            printf("%d ",a[i]);
            if(i!=j)
                printf(" ");
            else
                printf("\n");

        }
    }
    return 0;
}

  				   			 	 	 		 			