//Language: GNU C++0x


#include <iostream>
#include <queue>
#include <vector>

using namespace std;

#define REP(n) for(LL _i=0; _i<n; ++_i)
#define FOR(i,a,b) for(LL i=a; i<b; ++i)
#define FORE(i,a,b) for(LL i=a; i<=b; ++i)

typedef long long LL;

LL n, m, k, p, v, r, c, best = -1000000000000000000LL;
vector<LL> rs, cs, rp, cp; // row and column sums & pleasure values
priority_queue<LL> rq, cq; // "current" row and column sums queue

// Debug by stealing working solution
LL ans1[1000005];
LL ans2[1000005];
priority_queue<LL> pq;

void solve1() {
    while (!pq.empty()) pq.pop();
    int i;
    for (i=1;i<=n;i++) {
        pq.push(rs[i-1]);
    }
    ans1[0]=0;
    LL now=0;
    for (i=1;i<=k;i++) {
        LL tmp=pq.top();
        now+=tmp;
        pq.pop();
        pq.push(tmp-1LL*p*m);
        ans1[i]=now;
    }
}

void solve2() {
    while (!pq.empty()) pq.pop();
    int i;
    for (i=1;i<=m;i++) {
        pq.push(cs[i-1]);
    }
    ans2[0]=0;
    LL now=0;
    for (i=1;i<=k;i++) {
        LL tmp=pq.top();
        now+=tmp;
        pq.pop();
        pq.push(tmp-1LL*p*n);
        ans2[i]=now;
    }
}

LL ans;

void solve() {
    solve1();
    solve2();
    ans=-1000000000000000000LL;
    int i;
    for (i=0;i<=k;i++) {
        LL tmp=ans1[i]+ans2[k-i]-1LL*i*(k-i)*p;
        if (tmp>ans) ans=tmp;
    }
}

#include <stdio.h>

int main() {

    cin >> n >> m >> k >> p;

    rs.resize(n);
    cs.resize(m);

    rp.resize(k+1);
    cp.resize(k+1);

    FOR(i,0,n) FOR(j,0,m) {
        cin >> v;
        rs[i] += v;
        cs[j] += v;
    }

    solve();
    printf("%I64d\n",ans);
    return 0;

    FOR(i,0,n) rq.push(rs[i]);
    FOR(i,0,n) cq.push(cs[i]);

    rp[0] = cp[0] = 0;

    FORE(i, 1, k) {
        r = rq.top(); rq.pop(); rq.push(r - p * m);
        c = cq.top(); cq.pop(); cq.push(c - p * n);
        rp[i] = rp[i-1] + r;
        cp[i] = cp[i-1] + c;
    }

    for(LL i = 0; i <= k; ++i) {
        LL pl = cp[i] + rp[k-i] - i * (k-i) * p;
        if(pl > best) best = pl;
    }

    cout << best << endl;

    return 0;
}
