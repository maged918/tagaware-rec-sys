//Language: GNU C++0x



#include <iostream>


using namespace std;


int main()
{
	ios_base::sync_with_stdio(false);
	int n;
	int a[100001];
	cin>>n;
	for(int i = 0;i<n;i++)cin>>a[i];
	int f = 0;
	if(n == 2){
		if(a[0] > a[1])cout<<1;
		else cout<<0;
		return 0;
	}
	int ma = a[0], pos = 0;
	for(int i = 1;i<n;i++){
		if(f == 0){
			if(a[i] < a[i - 1]){
				
				f = 1;
				if(a[i] > ma){
					cout<<-1;
					return 0;
				}
				pos = i - 1;
			}
		}
		else{
			if(a[i] < a[i - 1]){
				cout<<-1;
				return 0;
			}
			else if(a[i] > ma){
				cout<<-1;
				return 0;
			}
		}
	}
	if(f == 0)cout<<0;
	else
	cout<<n - pos - 1;


	return 0;
}