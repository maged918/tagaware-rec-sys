//Language: GNU C++


#include <bits/stdc++.h>
#include<algorithm>
using namespace std;
bool isPrime(int x){
    if(x == 2) return true;
    for(int i = 2; i*i <= x; i++){
        if(x % i == 0) return false;
    }
    return true;
}
int primes[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53};
int divv[65];
int pos[65];
vector< int > A;
int dp[1 << 16][101];
int solve(int mask, int idx){
    if(idx == A.size()){
        return 0;
    }
    int& ret = dp[mask][idx];
    if(ret != -1) return ret;
    ret = 1e9;
    for(int i = 1, to = A[idx] - 1 + A[idx]; i <= to; i++){
        if((mask & divv[i])) continue;
        ret = min(ret, solve(mask | divv[i], idx + 1) + abs(i - A[idx]));
    }
    return ret;
}
vector< int > ans;
void recur(int mask, int idx){
    if(idx == A.size()){
        return;
    }
    int& ret1 = dp[mask][idx];
    for(int i = 1, to = A[idx] - 1 + A[idx]; i <= to; i++){
        if((mask & divv[i])) continue;
        if(solve(mask | divv[i], idx + 1) + abs(i - A[idx]) == ret1){
            ans.push_back(i);
            return recur(mask | divv[i], idx + 1);
        }
    }
    return;
}
main() {
    for(int i = 0; i < 16; i++){
        pos[primes[i]] = i;
    }
    for(int i = 2; i <= 59; i++){
        for(int j = 0; j < 16; j++){
            if(i % primes[j] == 0){
                divv[i] |= 1 << j;
            }
        }
    }
    int n, x;
    cin >> n;
    for(int i = 0; i < n; i++){
        cin >> x;
        A.push_back(x);
    }
    memset(dp, -1, sizeof dp);
    solve(0, 0);
    recur(0, 0);
    for(int i = 0; i < ans.size(); i++){
        if(i != 0) cout << " ";
        cout << ans[i];
    }
}