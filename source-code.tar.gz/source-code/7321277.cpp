//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
int main()
{
    int i,j,k,t,n,m=100001,a[100001],pos=0,b[100001];
    scanf("%d",&n);
    for(i=0;i<n;++i)
    {
        scanf("%d",&b[i]);
    }
    int ct=0;
    for(i=n-1;i>=1;--i)
        if(b[i]==b[0])
            ++ct;
        else
            break;
    for(i=0;i<ct;++i)
        a[i]=b[0];
    for(j=0;j<n-ct;++j,++i)
        a[i]=b[j];
    for(i=0;i<n;++i)
    {
        if(a[i]<m)
            {
                m=a[i];
                pos=i;
            }
    }
    int flag=0;
    for(i=0;i<n-1;++i)
    {
    if(i!=pos-1)
        if(a[i]>a[i+1])
        {
            flag=1;
            break;
        }
    }
    if(a[n-1]>a[0] && pos!=0)
        flag=1;
    if(flag==0)
    {
        if(pos==0)
        {
            if(ct==n-1)
                printf("0\n");
            else
                printf("%d\n",ct);
        }
        else
            printf("%d\n",ct+n-pos);
    }
    else
        printf("-1\n");
    return 0;
}