//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
using namespace std;
int n,m,root;
int du[100010];
bool vi[100010];
vector <int> edge[100010],path;
void add(int u)
{
    path.push_back(u);
    du[u]^=1;
}
void dfs(int u,int pre)
{
    vi[u]=1;
    add(u);
    for (int i=0;i<edge[u].size();i++)
    {
        if (!vi[edge[u][i]])
        {
            dfs(edge[u][i],u);
            add(u);
        }
    }
    if (du[u]&&u!=root)
    {
        add(pre);
        add(u);
    }
}
int main()
{
    scanf("%d%d",&n,&m);
    for (int i=1;i<=m;i++)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        edge[x].push_back(y);
        edge[y].push_back(x);
    }
    for (int i=1;i<=n;i++) scanf("%d",&du[i]);
    root=0;
    path.clear();
    memset(vi,0,sizeof(vi));
    for (int i=1;i<=n;i++)
        if (du[i])
        {
            root=i;
            dfs(i,0);
            break;
        }
    if (!root) printf("0\n");
    else
    {
        for (int i=1;i<=n;i++)
            if (du[i]&&!vi[i])
            {
                printf("-1\n");
                return 0;
            }
        if (du[root]) path.pop_back();
        printf("%d\n",path.size());
        for (int i=0;i<path.size();i++)
        {
            if (i==path.size()-1) printf("%d\n",path[i]);
            else printf("%d ",path[i]);
        }
    }
    return 0;
}
