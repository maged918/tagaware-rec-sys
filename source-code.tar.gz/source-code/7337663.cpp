//Language: GNU C++0x


// http://codeforces.com/problemset/problem/427/C
#include <iostream>
#include <cstdio>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

#define x first
#define y second
#define mk make_pair
typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<bool> vb;

typedef struct {int node, j, dir;} State;


#define MOD (1000000007LL)
enum {up, down};

int main() {
  //ios_base::sync_with_stdio(false)
  
  int n, m;
  cin >> n;
  vector<ll> costs(n);
  for (int i = 0; i < n; i++)
    cin >> costs[i];
  cin >> m;
  vector<vi> adj(n, vi());
  vector<vi> trans(n, vi());
  for (int i = 0; i < m; i++) {
    int a, b;
    cin >> a >> b;
    a -= 1; b -= 1;
    adj[a].push_back(b);
    trans[b].push_back(a);
  }

  // Find the SCCs
  vb seen(n, false);
  vector<State> dfsstk;
  vi sccstk;
  for (int i = 0; i < n; i++) {
    if (seen[i]) continue;
    dfsstk.push_back({i, 0, up});
    seen[i] = true;
    while (dfsstk.size()) {
      State state = dfsstk.back(); dfsstk.pop_back();
      if (state.dir == up) {
        if (state.j == adj[state.node].size()) {
          state.dir = down;
          dfsstk.push_back(state);
          continue;
        }
        dfsstk.push_back({state.node, state.j+1, state.dir});
        int neigh = adj[state.node][state.j];
        if (seen[neigh]) continue;
        dfsstk.push_back({neigh, 0, up});
        seen[neigh] = true;
      } else {
        sccstk.push_back(state.node);
      }
    }
  }
  seen.assign(n, false);
  vi stk;
  ll cost = 0, prod = 1;
  for (auto it = sccstk.rbegin(); it != sccstk.rend(); it++) {
    if (seen[*it]) continue;
    stk.push_back(*it);
    seen[*it] = true;
    vector<ll> scc;
    while (stk.size()) {
      int node = stk.back(); stk.pop_back();
      scc.push_back(costs[node]);
      for (auto it = trans[node].begin(); it != trans[node].end(); it++) {
        if (!seen[*it]) stk.push_back(*it);
        seen[*it] = true;
      }
    }
    ll count = 0;
    ll mmin = *min_element(scc.begin(), scc.end());
    for (int i = 0; i < scc.size(); i++) 
      if (scc[i] == mmin)
        count++;
    cost += mmin;
    prod = (prod * count) % MOD;
  }

  cout << cost << " " << prod << endl;
  return 0;
}
