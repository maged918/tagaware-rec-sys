//Language: GNU C++


#include<bits/stdc++.h>
#define x   first
#define y   second
using namespace std;
typedef long long ll;
typedef pair<int,int> ii;

int n, a[101], inv[60];
vector <int> primes;
int factors[60];
int getFactors(int x)
{
    int &ret = factors[x];
    if (ret) return ret;
    for (int i = 2; i*i <= x; i++) {
        while (x % i == 0) {
            x /= i;
            ret |= 1 << inv[i];
        }
    }
    if (x > 1) ret |= 1 << inv[x];
    return ret;
}

void makePrime(void) {
    bool notp[60] = {1,1};
    for (int i = 2; i < 60; i++) {
        if (notp[i]) continue;
        for (int j = i+i; j < 60; j+=i)
            notp[j] = 1;
        inv[i] = primes.size();
        primes.push_back(i);
    }
}

vector <ii> comb_res_cache[1<<17];
vector <ii>& getCombination(int arr[], int len)
{
    int mask = 0;
    for (int i = 0; i < len; i++) {
        mask |= (1 << inv[arr[i]]);
    }

    if (comb_res_cache[mask].size()) return comb_res_cache[mask];

    /*
    if (len > 0) {
        vector <ii>& except_last = getCombination(arr, len - 1);
        int mul = 1, last = 1 << inv[arr[len-1]];
        for (int k = 0; k <= 5; k++) {
            if (mul >= 60) break;
            for (int i = 0; i < except_last.size(); i++) {
                if (mul * except_last[i].first < 60) {
                    if (mul == 1) comb_res_cache[mask].push_back(make_pair(except_last[i].first, except_last[i].second));
                    else comb_res_cache[mask].push_back(make_pair(mul * except_last[i].first, except_last[i].second | last));
                }
            }
            mul *= arr[len-1];
        }
    } else {
        comb_res_cache[mask].push_back(make_pair(1, mask));
    }
    */

    for (int i = 2; i < 60; i++) {
        if ((getFactors(i) & mask) == getFactors(i))
            comb_res_cache[mask].push_back(make_pair(i, getFactors(i)));
    }

    //sort(comb_res_cache[mask].begin(), comb_res_cache[mask].end());
    return comb_res_cache[mask];
}

int d[101][1<<17], ans;
int go(int x, int state)
{
    if (x == n) return 0;
    int &ret = d[x][state];
    if (~ret) return ret;
    ret = (a[x] - 1) + go(x+1, state);

    int left[17] = {}, len = 0;
    for (int i = 0; i < 17; i++) {
        if (state & (1 << i)) left[len++] = primes[i];
    }

    if (len == 0) return ret;
    vector <ii> &all = getCombination(left, len);

    for (int i = 0; i < all.size(); i++) {
        if (a[x]+a[x] <= all[i].x) return ret;
        int t = go(x+1, state ^ all[i].y) + abs(a[x] - all[i].x);
        if (ret > t) ret = t;
    }

    return ret;
}

void traceAnswer(int x, int state)
{
    if (x == n) return;
    if (ans - (a[x] - 1) == go(x+1, state)) {
        ans -= (a[x] - 1);
        printf("%d ", 1);
        traceAnswer(x+1, state);
        return;
    }

    int left[17], len = 0;
    for (int i = 0; i < 17; i++) {
        if ((state >> i & 1) == 0) continue;
        left[len++] = primes[i];
    }

    if (len == 0) return;
    vector <ii> &all = getCombination(left, len);

    for (int i = 0; i < all.size(); i++) {
        if (a[x]+a[x] <= all[i].x) return;
        if (ans - abs(a[x] - all[i].x) == go(x+1, state ^ all[i].y)) {
            ans -= abs(a[x] - all[i].x);
            printf("%d ", all[i].x);
            traceAnswer(x+1, state ^ all[i].y);
            return;
        }
    }
}


int main()
{
    memset(d, -1, sizeof d);
    makePrime();
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d", a + i);
    }
    ans = go(0, (1<<17)-1);
    //printf("ans:%d\n", ans);
    traceAnswer(0, (1<<17)-1);
    puts("");
    return 0;
}