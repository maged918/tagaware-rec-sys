//Language: GNU C++


/*
ID: zako
PROG: 00000
LANG: C++13
addres :C:\Users\Nugo\Desktop\CodeForceCPP\codeforce\codeforce\
*/
#pragma comment(linker, "/STACK:16777216")
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <cstdlib>
#include <stdlib.h>
#include <string>
//#include <string.h>
#include <list>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <map>
#include <vector>
#include <iomanip>
#include <queue>
#include <deque>
#include <set>
#include <stack>
#include <sstream>
#include <iterator>
//#include <functional> //std::greater<int>
//#include <tuple>

//#include "Biginteger.cpp"
//#include "sqrt.cpp"
//#include "tree.cpp"
//#include "funcs.cpp"

typedef long long ll;
typedef std::pair<int, int> pii;
#define ALL(x)           (x).begin(), (x).end()
#define forn(N)          for(ll i = 0; i<(int)N; i++)
#define fornj(N)         for(ll j = 0; j<(int)N; j++)
#define fornk(N)         for(ll k = 0; k<(int)N; k++)
#define foreach(c,itr) for(auto itr=(c).begin();itr!=(c).end();itr++)
#define PI 3.1415926535897932384626433
#define LINF (1LL<<60)
#define INF (1<<30)
//#define MOD 1000007
//#define awesome vector<int> A(N); forn(N) scanf("%d", &A[i]);
//#define File "Patterns"

using namespace std;
int main()
{
	//ifstream fin("input.txt");
	int n,t=1; cin >> n;
	
	for (int i = 1; i <= n/2+1; i++){
		for (int j = 1; j <= n; j++){
			if (j <= (n-t)/2)
				cout << "*";
			else if (j > (n - t) / 2 + t)
				cout << "*";
			else
				cout << "D";
		}
		cout << endl;
		t += 2;
	}
	t = n - 2 ;
	for (int i = 1; i <= n/2; i++){
		for (int j = 1; j <= n; j++){
			if (j <= (n - t) / 2)
				cout << "*";
			else if (j >(n - t) / 2 + t)
				cout << "*";
			else
				cout << "D";
		}
		cout << endl;
		t -= 2;
	}


	//system("pause");
	return 0;
}