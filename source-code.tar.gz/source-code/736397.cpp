//Language: GNU C++


#include <cstdio>
int main()
{
    int arr[1005];
    int i,j,n;
    scanf("%d",&n);
    for(i=0;i<n;i++)scanf("%d",arr+i);
    int sum=0;
    for(i=0;i<n;i++)
    {
        int ans=0;
        for(j=i+1;j<n;j++)
        {
            if(arr[j]>arr[j-1])break;
        }
        ans+=j-i;
        for(j=i-1;j>=0;j--)
        {
            if(arr[j]>arr[j+1])break;
        }
        ans+=i-j-1;
        //printf("--- %d\n",ans);
        if(ans>sum)sum=ans;
    }
    printf("%d\n",sum);
    return 0;
}
