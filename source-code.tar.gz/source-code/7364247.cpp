//Language: GNU C++


#include<cmath>
#include<math.h>
#include<ctype.h>
#include<algorithm>
#include<bitset>
#include<cassert>
#include<cctype>
#include<cerrno>
#include<cfloat>
#include<ciso646>
#include<climits>
#include<clocale>
#include<complex>
#include<csetjmp>
#include<csignal>
#include<cstdarg>
#include<cstddef>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<cwchar>
#include<cwctype>
#include<deque>
#include<exception>
#include<fstream>
#include<functional>
#include<iomanip>
#include<ios>
#include<iosfwd>
#include<iostream>
#include<istream>
#include<iterator>
#include<limits>
#include<list>
#include<locale>
#include<map>
#include<memory>
#include<new>
#include<numeric>
#include<ostream>
#include<queue>
#include<set>
#include<sstream>
#include<stack>
#include<stdexcept>
#include<streambuf>
#include<string>
#include<typeinfo>
#include<utility>
#include<valarray>
#include<vector>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>
using namespace std;

map<string,int> m,points;

int main()
{
	string s;
    	points["posted"]=15;
    	points["commented"]=10;
    	points["likes"]=5;
    	cin>>s;
    	int num;
    	cin>>num;
    	while(num--)
    	{	
        	string fi,se,th,fo;
        	cin>>fi>>se;
        	
        	if(se[0]=='l')
          {  	
			cin>>fo;
		}
        	else 
		{
			cin>>fo>>fo;
		}
		
        	th=fo.substr(0,fo.size()-2);
        	
        	m[fi]+=0;
        	m[th]+=0;
        	
        	if(fi==s||th==s){
            	m[fi]+=points[se];
            	m[th]+=points[se];
        	}
        	
        	cin>>fo;
    	}
    	
    	vector<pair<int, string> > a;
    	
    	for(map<string,int>::iterator it=m.begin();it!=m.end();it++)
    	{
        	if(it->first!=s){
            a.push_back( make_pair(-(it->second), it->first));
		}
	}
	
    	sort(a.begin(),a.end());
    	
    	for(int i=0;i<a.size();i++)
    	{
        	cout << a[i].second << endl;
	}
	//system("pause");
    	return 0;
}
