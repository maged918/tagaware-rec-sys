//Language: GNU C++


#include<bits/stdc++.h>
using namespace std ;
int N , M ;
vector<int>G[100000] ;
int parity[100000] ;
vector<int>ans ;
int vis[100000];

void visit( int p ){
    vis[p] = 1 ;
    parity[p] = !parity[p] ;
    ans.push_back( p ) ;
}

void rec( int idx ){
    visit( idx ) ;
    for( int i = 0 ; i < G[idx].size() ; i++ ){
        if( vis[G[idx][i]] == 0 ){
            rec(G[idx][i]) ;
            visit(idx) ;
            if( parity[G[idx][i]] ){
                visit(G[idx][i]) ;
                visit(idx) ;
            }
        }
    }
}


int main(){

    cin >> N >> M ;

    for( int i = 0 ; i < M ; i++ ){
        int a , b ;
        cin >> a >> b ;
        a-- ;
        b-- ;
        G[a].push_back(b) ;
        G[b].push_back(a) ;
    }

    for( int i = 0 ;i < N ; i++ ){
        cin >> parity[i] ;
    }
    if( count ( parity , parity + N , 1 ) == 0 ){
        cout << "0" << "\n" ;
        return 0;
    }
    for( int i = 0 ; i < N ; i++ ){
        if( parity[i] ){
            rec(i);
            if( parity[i] ){
                ans.pop_back() ;
                parity[i] = 0 ;
            }
            break ;
        }
    }
//    for( int i = 0 ; i <N ; i++ ){
//        cout << parity[i] << " " ;
//    }cout << "\n" ;
    if( count ( parity , parity + N , 1 ) != 0 ){
        cout << "-1" << "\n" ;
        return 0;
    }
    cout << ans.size() << "\n" ;
    for( int i = 0 ; i < ans.size() ; i++ ){
        if( i )cout << " " ;
        cout << ans[i]+1 ;
    }cout << "\n" ;


return 0 ;
}
