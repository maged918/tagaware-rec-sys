//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cmath>
#define LL long long
using namespace std;

int main(){
    LL a,b,w,x,c;
    scanf("%lld%lld%lld%lld%lld",&a,&b,&w,&x,&c);
    if(c<=a) printf("0\n");
    else {
        LL cha=c-a;
        LL p1=(cha-b/x)*x-b%x;
        LL p2=w-x;
        LL p;
        if(p1%p2==0) p=p1/p2;
        else p=p1/p2+1;
        printf("%lld\n",cha+p);
    }
    return 0;
}

 	 				 	  					 	   			 	