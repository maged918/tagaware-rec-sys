//Language: GNU C++


/****** BISMILLAHIR RAHMANIR RAHIM ********
 *----------------------------------------*
 *|Author       : Golam Mazid            |*
 *|Algorithm    :                        |*
 *|                                      |*
 *|E-mail       : sajibcuet09@gmail.com  |*
 *----------------------------------------*
 ******************************************/

#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<memory.h>
#include<time.h>
#include<assert.h>
#include<iostream>
#include<sstream>
#include<fstream>
#include<string>
#include<map>
#include<set>
#include<stack>
#include<queue>
#include<vector>
#include<algorithm>
#include<deque>
#include<list>
#include<utility>
#include<iomanip>
#include<functional>
#include<numeric>
#include<bitset>
using namespace std;

//typedef __int64 LL;
//typedef long long LL;
typedef int LL;

typedef vector<LL> Vi;
typedef vector<string> Vs;
typedef map<LL,string> Mis;
typedef map<string,LL> Msi;
typedef map<LL,LL> Mii;

#define mem(x,y) memset(x,y,sizeof(x))
#define fr(i,a,b) for(i=a;i<=b;i++)
#define frd(i,a,b) for(i=a;i>=b;i--)
#define frit(it,x) for(__typeof((x).begin())it=(x.begin());it!=(x).end();++it)

#define sf1(a) scanf("%d",&a)
#define sf2(a,b) scanf("%d%d",&a,&b)
#define sf3(a,b,c) scanf("%d%d%d",&a,&b,&c)
#define dsf1(a) scanf("%lf",&a)
#define dsf2(a,b) scanf("%lf%lf",&a,&b)
#define dsf3(a,b,c) scanf("%lf%lf%lf",&a,&b,&c)
#define ssf1(a) scanf("%s",a)
#define ssf2(a,b) scanf("%s%s",a,b)
#define ssf3(a,b,c) scanf("%s%s%s",a,b,c)
#define csf(ch) ch=getchar()
#define cpf(ch) putchar(ch)
#define cspf(cs) printf("Case %d: ", cs)
#define pf(a) printf("%d",a)
#define spf(a) printf("%s",a)
#define pf1(a) printf("%d\n",a)
#define pf2(a,b) printf("%d %d\n",a,b)
#define pf3(a,b,c) printf("%d %d %d\n",a,b,c)
#define spf1(a) printf("%s\n",a)
#define spf2(a,b) printf("%s %s\n",a,b)

LL bigmod(LL b,LL p,LL m)
{
    LL res=1,x=b;
    while(p)
    {
        if(p&1)
            res=(res*x)%m;
        x=(x*x)%m;
        p>>=1;
    }
    return res;
}
LL ex_euc(LL aa,LL bb,LL *xx,LL *yy)
{
    LL x,y,u,v,m,n,a,b,q,r;
    x=0,y=1;
    u=1,v=0;
    for(a=aa,b=bb;a!=0;b=a,a=r,x=u,y=v,u=m,v=n)
    {
        q=b/a;
        r=b%a;
        m=x-(u*q);
        n=y-(v*q);
    }
    *xx=x;
    *yy=y;
    return b;
}
LL gcd(LL a,LL b)
{
    LL c;
    while(b)
    {
        c=a%b;
        a=b;
        b=c;
    }
    return a;
}
LL lcm(LL a,LL b)
{
    return (LL)(a*(b/gcd(a,b)));
}
LL Pow(LL a,LL p)
{
    LL res=1,x=a;
    while(p)
    {
        if(p&1)
            res=res*x;
        x=x*x;
        p >>= 1;
    }
    return res;
}
LL Max(LL a,LL b)
{
    return a>b?a:b;
}
LL Min(LL a,LL b)
{
    return a<b?a:b;
}
LL Abs(LL a)
{
    return a<0?-a:a;
}

//int month[]={-1,31,28,31,30,31,30,31,31,30,31,30,31};  //Not Leap Year

//int R[]={1,0,-1,0};int C[]={0,1,0,-1}; //4 Direction
//int R[]={1,1,0,-1,-1,-1,0,1};int C[]={0,1,1,1,0,-1,-1,-1};//8 direction
//int R[]={2,1,-1,-2,-2,-1,1,2};int C[]={1,2,2,1,-1,-2,-2,-1};//Knight Direction
//int R[]={-1,-1,+0,+1,+1,+0};int C[]={-1,+1,+2,+1,-1,-2}; //Hexagonal Direction

#define eps 1e-9
#define Pi 2*acos(0)
#define inf 1<<30
#define mod 1000000007
#define Sz 10000005

char s[Sz];
int two[]={1,2,4,3},three[]={1,3,4,2},four[]={1,4,1,4};
int main()
{
    LL l,num,i,ans;
    while(ssf1(s)==1)
    {
        l=strlen(s);
        num=0;
        fr(i,0,l-1)
        {
            num=(num*10)+(s[i]-48);
            num%=4;
        }
        ans=1+two[num]+three[num]+four[num],ans%=5;
        pf1(ans);
        //return 0;
    }
    return 0;
}
