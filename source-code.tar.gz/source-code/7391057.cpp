//Language: GNU C++


#include <cstdio>
#include <vector>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <iostream>

using namespace std;

int Z[300005], op, num, m;
int U[300005], Q[300005], V[300005], G[300005], D[300005], ctos, aristas, pregs, a, b, ult, g, son, mas, chico, quien;
vector<int> L[300005];

void up(int dnde){
    if(U[dnde]==dnde){
        ult=dnde;
    }
    else {
        up(U[dnde]);
        U[dnde]=ult;
    }
}

void une(int x, int y){
    up(x);
    up(y);
    if(U[x]==U[y]){
        return ;
    }
    x=U[x];
    y=U[y];


    G[y]=max(max(G[x], G[y]), V[x]+1+V[y]);

    m=V[x];
    V[x]=max(V[x], V[y]+1);
    V[y]=max(V[y], m+1);
    if(V[x]<V[y]){
        V[y]=V[x];
        Q[y]=Q[x];
    }

    U[x]=y;
}

void aslo(int dnde, int lleva){
    if(Z[dnde]==son)
        return ;
    Z[dnde]=son;
    if(lleva>mas){
        mas=lleva;
        g=dnde;
    }
    if(D[dnde]<lleva)
        D[dnde]=lleva;
    if(D[dnde]<chico){
        chico=D[dnde];
        quien=dnde;
    }
    for(int i=0; i<L[dnde].size(); i++){
        aslo(L[dnde][i], lleva+1);
    }
}

int main()
{
    scanf("%d%d%d",&ctos,&aristas,&pregs);
    for(int i=1; i<=ctos; i++){
        U[i]=i;
    }
    for(int i=1; i<=aristas; i++){
        scanf("%d%d",&a,&b);
        L[a].push_back(b);
        L[b].push_back(a);
        une(a, b);
    }

    for(int i=1; i<=ctos; i++){
        if(Z[i]==0){
            up(i);

            ++son;
            mas=-1;
            aslo(i, 0);
            ++son;
            mas=-1;
            aslo(g, 0);

            G[U[i]]=mas;

            ++son;
            mas=-1;
            chico=1000000000;
            aslo(g, 0);

            Q[U[i]]=quien;
            V[U[i]]=chico;
        }
    }
    for(int i=1; i<=pregs; i++){
        scanf("%d",&op);
        if(op==1){
            scanf("%d",&num);
            up(num);
            printf("%d\n",G[U[num]]);
        }
        else {
            scanf("%d%d",&a,&b);
            une(a, b);
        }
    }
    return 0;
}
