//Language: GNU C++0x


#pragma comment(linker, "/STACK:268435456")
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <algorithm>
#include <vector>
#include <math.h>
#include <set>
#include <map>
#include <queue>
#include <iomanip>
#include <assert.h>
#include <stack>
#include <deque>
#include <limits.h>
#include <memory.h>
#include <time.h>
//#include <unordered_map>
//#include <unordered_set>
using namespace std;

void prepare(string q)
{
#ifdef _DEBUG
	//system("color F0");
	freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);
#else
	if (q.size()!=0)
	{
		freopen((q+".in").c_str(),"r",stdin);
		freopen((q+".out").c_str(),"w",stdout);
	}
#endif
	cin.sync_with_stdio(false);
	cout.sync_with_stdio(false);
	cin.tie(false);
}

const int NMAX = 100010;
const int INF = 1000000000;
const long long INFL = 1000000000000000000L;
const long long M = 1000000009;

int n;
long long cnt[NMAX];
long long dp[NMAX];
long long p[NMAX];

void getData()
{
	cin >> n;

	int val;
	for (int i = 0; i < n; ++i) {
		cin >> val;
		cnt[val] ++;
	}
}

void solve()
{
	for (long long i = 1; i < NMAX; ++i) {
		dp[i] = i * cnt[i];
		if (i > 1)
			dp[i] += p[i-2];

		p[i] = max(dp[i], p[i-1]);
	}

	cout << max(dp[NMAX-2] , dp[NMAX-1]);
}

int main()
{
	prepare("");

	getData();
	solve();

	return 0;
}