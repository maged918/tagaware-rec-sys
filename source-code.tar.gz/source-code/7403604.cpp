//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <cassert>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <string>
#include <vector>
#include <cmath>
#include <ctime>
#include <queue>
#include <stack>
#include <map>
#include <set>

using namespace std;

#define endl '\n'
#define F first
#define S second
#define mp make_pair
#define ll long long
#define pb push_back
#define pii pair < int, int >
#define type(x) __typeof(x.begin())
#define foreach(i, x) for(type(x) i = x.begin(); i != x.end(); i++)
#define FOR(i, a, b) for(int i = a; i <= b; i++)
#define ROF(i, a, b) for(int i = a; i >= b; i--)
#define sol (root << 1)
#define sag (sol | 1)
#define orta ((bas + son) >> 1)
#define bit __builtin_popcount
#define dbgs(x) cerr << (#x) << " --> " << (x) << ' '
#define dbg(x) cerr << (#x) << " --> " << (x) << endl
#define TIME cerr << "Tooks " << (double) clock() / CLOCKS_PER_SEC << " seconds." << endl

const int inf = 1e9 + 5;
const ll linf = 1e18 + 5;

const int N = 1e5 + 5;
const int A = 26;

int n, m, size, a[N][26];
map < pii , int > dp, dp1;
string s;

bool can_win(int k, int t) {

	if(dp[mp(k, t)])
		return dp[mp(k, t)] == 2;

	bool ret = 0;

	FOR(i, 0, A - 1)
		if(a[t][i])
			ret |= !can_win(k + 1, a[t][i]);

	dp[mp(k, t)] = ret + 1;

	return ret;

}

bool can_lose(int k, int t) {

	if(dp1[mp(k, t)])
		return dp1[mp(k ,t)] == 2;

	bool ret = 0, flag = 0;

	FOR(i, 0, A - 1)
		if(a[t][i])
		{
			ret |= !can_lose(k + 1, a[t][i]);

			flag = 1;
		}

	if(!flag) ret = 1;

	dp[mp(k, t)] = ret + 1;

	return ret;

}

int main () {
    
    ios :: sync_with_stdio(0);
    
    cin >> n >> m;

	size = 1;

	FOR(i, 1, n)
	{
		cin >> s;

		int now = 1;

		foreach(it, s)
		{
			(*it) -= 'a';

			if(!a[now][*it])
				a[now][*it] = ++size;

			now = a[now][*it];
		}
	}

	bool win = can_win(1, 1);
	bool lose = can_lose(1, 1);

	dbgs(win), dbg(lose);

	if(win and lose) cout << "First" << endl;
	else if(!win and !lose) cout << "Second" << endl;
	else if(win and m & 1) cout << "First" << endl;
	else cout << "Second" << endl;

    TIME;
    
    return 0;
    
}
