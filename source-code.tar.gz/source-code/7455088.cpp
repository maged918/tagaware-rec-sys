//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <math.h>
#include <cmath>
#include <string.h>
#include <string>
#include <algorithm>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <limits.h>
#include <time.h>
#include <bitset>
#include <list>
#include <cassert>

#define EPS 1e-11
#define PI M_PI
#define LL long long
#define INF 1000000009
#define MP(a,b) make_pair(a,b)
#define PB(a) push_back(a)
#define swap(a,b) a=a^b, b=a^b, a=a^b;
#define OPENR(a) freopen(a,"r",stdin)
#define OPENW(a) freopen(a,"w",stdout)

int x4[4] = { 0, 0,-1, 1};
int y4[4] = {-1, 1, 0, 0};
int x8[8] = {-1,-1,-1, 0, 0, 1, 1, 1};
int y8[8] = {-1, 0, 1,-1, 1,-1, 0, 1};
int xhorse[8] = {1,2,1,2,-1,-2,-1,-2};
int yhorse[8] = {2,1,-2,-1,2,1,-2,-1};

using namespace std;

int x1,yy1,x2,y2;

int main()
{
	scanf("%d %d %d %d",&x1,&yy1,&x2,&y2);
	
	if (x1==x2)
	{
		int jarak = abs(yy1-y2);
		printf("%d %d %d %d\n",x1+jarak,yy1,x2+jarak,y2);
	}
	else if (yy1==y2)
	{
		int jarak = abs(x1-x2);
		printf("%d %d %d %d\n",x1,yy1+jarak,x2,y2+jarak);
	}
	else
	{
		if (x1>x2)
		{
			swap(x1,x2);
			swap(yy1,y2);
		}
	
		if (abs(x1-x2)!=abs(yy1-y2)) printf("-1\n");
		else
		{
			printf("%d %d %d %d\n",x1,y2,x2,yy1);
		}
	}
	
	return 0;
}

