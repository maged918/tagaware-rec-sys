//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstdlib>
#include<cctype>
#include<algorithm>
#include<limits>
#include<vector>
#include<stack>
#include<string>
#include<deque>
#include<set>
#include<list>
#include<bitset>
#include<ctime>
#include<functional>
#include<numeric>
#include<cfloat>
#include<sstream>
#include<complex>
#include<queue>
#include<cstring>
#include<stdexcept>
#include<utility>
#include<map>
#include<fstream>
#include<iomanip>
#include<cassert>
#define srt(v) srt(v.begin(),v.end())
#define area(x1,y1,x2,y2,x3,y3) ( x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2) )
#define distSqr(x1,y1,x2,y2) ( sqr(x1-x2) + sqr(y1-y2) )
#define pi acos(-1.0)
#define MAX(a,b) (a<b?b:a)
#define MIN(a,b) (a<b?a:b)
#define inf (1<<30)-1
#define SIZE 100000001
#define even(a) ((a)%2==0)
#define odd(a) ((a)%2==1)
const double E = 2.7182818284590452353602874713527;
using namespace std;
#define eps 1e-14
#define pf printf
#define sf scanf
#define ll long long
__int64 ara[1000010];
int main()
{
    __int64 res = 0, cnt = 0, sum = 0, num, len, i, j, k, y = 0, val, cnt1 = 0, n;
    sf("%I64d",&n);
    for(i = 0; i < n; i++)
    {
        sf("%I64d",&ara[i]);
    }
    sort(ara,ara+n);
    num = ara[0];
    for(i = 0; i < n; i++)
    {
        if(ara[i] == num)
        {
            cnt++;
        }
        else break;
    }
    if(ara[0] != ara[n-1])
    {
        y = 1;
        num = ara[n-1];
     for(i = n-1; i >= 0; i--)
     {
        if(ara[i] == num)
        {
            cnt1++;
        }
        else break;
     }
     res = ara[n-1] - ara[0];
     pf("%I64d %I64d\n",res, cnt*cnt1);
    }
    else{
        val = n-1;
        res = (val*(val+1));
        pf("0 %I64d\n", res / 2);
    }

    return 0;
}
