//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;
#include <queue>
#include <stack>
#include <vector>
#include <deque>
#include <set>
#include <map>
#define IN     freopen ("in.txt" , "r" , stdin);
#define OUT  freopen ("out.txt" , "w" , stdout);
typedef long long  LL;
const int MAXN = 250000;//点数的最大值
const int MAXM = 20006;//边数的最大值
const int INF = 11521204;
const int mod=1000000007;

int a[MAXN];
int main()
{
    int n;

    //  IN;
  while(scanf("%d",&n)!=EOF)
  {
//    map<int,int>m;
//    m.clear();
//    map<int,int >::iterator it;
    for(int i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    sort(a,a+n);
    int maxx=0;
    maxx=a[n-1]-a[0];
    int x2=a[0];
    LL sum1=0,sum2=0,sum3=0;
    for(int i=0;i<n;i++)
    {
        if(x2==a[i])
            sum1++;
    }
    int x1=a[n-1];
    for(int i=n-1;i>=0;i--)
    {
        if(x1==a[i])
            sum2++;
    }
    if(x1==x2)
    {
        printf("%d %I64d\n",0,(sum1)*(sum1-1)/2);
    }
    else
    printf("%d %I64d\n",x1-x2,sum1*sum2);
  }
    return 0;
}
