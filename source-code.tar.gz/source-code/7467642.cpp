//Language: GNU C++


#define filer() freopen("in.txt","r",stdin)
#define filew() freopen("out.txt","w",stdout)

#include<iostream>
#include<stdio.h>
#include<string.h>
#include<math.h>
#include<algorithm>
#include<queue>
#include<stack>
#include<vector>
#include <map>
#define INF 1<<29
#define SET(a, x) memset((a), (x), sizeof(a))
#define i64 long long
#define pb push_back
using namespace std;

struct node
{
    int v;
    int id;
    int new_val;
}A[1000009];

bool cmp(node a,node b)
{
    if(a.v==b.v)return a.id<b.id;
    return a.v<b.v;
}
int X[1000009],Y[1000009];

int MaxVal,tree[1000009];

int read(int idx){
	int sum = 0;
	while (idx > 0){
		sum += tree[idx];
		idx -= (idx & -idx);
	}
	return sum;
}

void update(int idx ,int val){
	while (idx <= MaxVal){
		tree[idx] += val;
		idx += (idx & -idx);
	}
}


int main()
{
    //filer();

    int i,j,k ,T,cas=0,n,m;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>A[i].v;
        A[i].id=i;
    }
    sort(A,A+n,cmp);

    int cnt=1;
    X[A[0].id]=1;
    for(i=1;i<n;i++)
    {
        if(A[i].v==A[i-1].v)cnt++;
        else cnt=1;
        X[A[i].id]=cnt;
    }
    cnt=1;
    Y[A[n-1].id]=1;
    for(i=n-2;i>=0;i--)
    {
        if(A[i].v==A[i+1].v)cnt++;
        else cnt=1;
        Y[A[i].id]=cnt;
    }
    //Debug
//    for(i=0;i<n;i++)cout<<X[i]<<" ";cout<<endl;
//    for(i=0;i<n;i++)cout<<Y[i]<<" ";cout<<endl;
    //
    MaxVal=n+5;
    i64 sum=0;
    for(i=0;i<n;i++)
    {
        update(Y[i],1);
    }
    i64 g;
    for(i=0;i<n-1;i++)
    {
        update(Y[i],-1);
        g=read(X[i]-1);
        sum+=g;
    }
    cout<<sum<<endl;
    return 0;

}

