//Language: MS C++


#define _CRT_SECURE_NO_DEPRECATE
#define _USE_MATH_DEFINES

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <string>
#include <cstring>
#include <set>
#include <map>
#include <queue>
#include <memory.h>

using namespace std;

#pragma comment(linker, "/STACK:128000000")

typedef pair<int, int> pii;
typedef long long int64;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<pii> vpii;
typedef vector<vpii> vvpii;
typedef pair<int,pii> piii;

int n;
vi a;
vi b;
vi c;

inline int find(int x)
{
    int l = 0, r = (int)b.size() - 1;
    while (l <= r)
    {
        int mid = (l + r) >> 1;
        if (b[mid] == x)
            return mid;
        if (b[mid] < x)
            l = mid + 1;
        else
            r = mid - 1;
    }
    return -1;
}

inline void init()
{
    scanf("%d", &n);
    a.resize(n);
    c.assign(n, 0);
    for (int i = 0; i < n; ++i)
        scanf("%d", &a[i]);
    b = a;
    sort(b.begin(), b.end());
}

int main()
{
    //freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);

    init();

    int res = b[(int)b.size() - 1] - b[0];
    for (int i = 0; i < n; ++i)
    {
        int p = find(a[i]);
        ++c[p];
    }

    int64 cnt = 0;
    if (!res)
    {
        cnt = ((int64)n * (int64)(n - 1)) / 2;
    } else {
        for (int i = 0; i < n; ++i)
        {
            int need = b[i] + res;
            int p = find(need);
            if (p == -1) continue;
            cnt += (int64)c[p];
        }
    }
    cout << res << " " << cnt << endl;

    return 0;
}