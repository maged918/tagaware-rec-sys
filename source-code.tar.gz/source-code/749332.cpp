//Language: MS C++


#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<vector>
using namespace std;

int dist(int r,int c,int n) {
	return abs(r-n)+abs(c-n);
}

int main() {
	//freopen("in.txt","r",stdin);
	int i,j,n;
	cin>>n;

	for(i=0;i<2*n+1;i++) {
		for(j=0;j<2*n+1;j++) {
			if(j>n&&dist(i,j,n)>n) {
				break;
			}
			if(j)
				cout<<" ";
			if(dist(i,j,n)>n) {
				cout<<" ";
				continue;
			}
			cout<<n-dist(i,j,n);
		}
		cout<<endl;
	}
}