//Language: GNU C++


#include <bits/stdc++.h>

#define LL int64_t 
#define DD double

using namespace std; 
int DEBUG = 0;

int main(int argc, char **argv) {
  DEBUG = (argc>=2) ? atoi(argv[1]) : 0;
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  int n, m;
  cin >> n >> m;
  int a=0;
  while (n>=m) {
    n=n-m+1;
    a+=m;
  }
  a+=n;
  cout << a << endl;
  return 0;
}

/*
g++ 460A.cpp; cat 460A.in1 | ./a.out 1
g++ 460A.cpp; cat 460A.in2 | ./a.out 1
g++ 460A.cpp; cat 460A.in3 | ./a.out 1
*/




