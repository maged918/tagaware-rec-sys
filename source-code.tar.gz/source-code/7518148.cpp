//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <cstdlib>
#include <climits>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <iterator>
#include <string>

using namespace std;

typedef long long int64;

#define mp make_pair
#define pb push_back
#define ms0(x) memset(x,0,sizeof(x));
#define ms1(x) memset(x,-1,sizeof(x));

#define mod 1
#define EPS 1e-8

//------------------------------------------------------------------------//

int main(){
    int n,m;
    cin >> n >> m;
    int ans=n;
    for(int i=m;i<=ans;i+=m){
        ans+=1;
    }
    printf("%d\n",ans);
    return 0;
}

