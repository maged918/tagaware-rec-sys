//Language: GNU C++


#include <iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<stdlib.h>
#include<vector>
#include<cmath>
#include<queue>
#include<set>
using namespace std;
#define N 100000
#define LL long long
#define INF 0xfffffff
const double eps = 1e-8;
const double pi = acos(-1.0);
const double inf = ~0u>>2;
int n,m;
int main()
{
    int n,m,i,j;
    cin>>n>>m;
    if(m>n)
    cout<<n<<endl;
    else
    {
        int o = 0;
        while(n)
        {
            n--;
            o++;
            if(o%m==0) n++;
        }
        cout<<o<<endl;
    }
    return 0;
}
