//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <map>
#include <iterator>
#include <list>
#include <set>
#include <queue>
#include <numeric>
#include <cstdlib>
#include <ctime>
#include <limits>

using namespace std;

typedef long long lli;
typedef long li;

template <class T>
T Maximize (T &v, T nv) { if (nv > v) v = nv; return v; }

template <class T>
T Minimize (T &v, T nv) { if (nv < v) v = nv; return v; }

template <class T>
T Mod (T &v, T mod) { return v = (v % mod + mod) % mod; }

const lli INFLL = numeric_limits<lli>::max();
const li INF = numeric_limits<li>::max(), N = (li)1e5 + 1;

class SegmentTree
{
	struct Node
	{
		li l, r, s, pd;
		Node *left, *right;

		Node (li l, li r, li s) : l(l), r(r), s(s), pd(0), left(0), right(0) {}
		Node (li l, li r, Node *left, Node *right) : l(l), r(r), s(left->s + right->s), pd(0), left(left), right(right) {}

		void Add (li d)
		{
			pd += d;
			s += d;
		}

		void Push ()
		{
			if (pd)
			{
				left->Add(pd);
				right->Add(pd);
				pd = 0;
			}
		}

		bool IsLeaf ()
		{
			return l == r;
		}
	};

	Node *root;

	Node* build (li l, li r, li *a)
	{
		return l == r ? new Node(l, r, a[l]) : new Node(l, r, build(l, (l + r) / 2, a), build((l + r) / 2 + 1, r, a));
	}

	void add (Node *v, li l, li r, li d)
	{
		if (v->l > r || v->r < l) return;
		if (v->l >= l && v->r <= r) return v->Add(d);
		v->Push();
		add(v->left, l, r, d), add(v->right, l, r, d);
	}

	li get (Node *v, li i)
	{
		if (v->IsLeaf()) return v->s;
		v->Push();
		if (i <= (v->l + v->r) / 2) return get(v->left, i);
		else return get(v->right, i);
	}
public:
	SegmentTree (li l, li r, li *a)
	{
		root = build(l, r, a);
	}

	void Add (li l, li r, li d)
	{
		add(root, l, r, d);
	}

	li Get (li i)
	{
		return get(root, i);
	}
};

li a[N];
li n, m, w;

bool ok (li x)
{
	li mm = m;
	SegmentTree *t = new SegmentTree(0, n - 1, a);

	for (li i = 0; i < n; ++ i)
	{
		li delta = x - t->Get(i);
		if (delta <= 0) continue;
		if (mm >= delta)
		{
			mm -= delta;
			li l = i, r = i + w - 1;
			if (r > n - 1)
			{
				l -= i + w - n;
				r -= i + w - n;
			}
			t->Add(l, r, delta);
		}
		else
		{
			delete t;
			return 0;
		}
	}

	delete t;
	return 1;
}

void solve ()
{
	scanf("%ld %ld %ld", &n, &m, &w);

	for (li i = 0; i < n; ++ i) scanf("%ld", a + i);

	li ans = -1;
	for (li l = 1, r = (li)(1e9 + 1e6); l < r;)
	{
		li mid = (l + r) / 2;
		if (ok(mid)) l = mid + 1, ans = mid;
		else r = mid;
	}

	printf("%ld\n", ans);
}

void init ()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
}

int main()
{
	init();
	solve();
	return 0;
}
