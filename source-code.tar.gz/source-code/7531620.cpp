//Language: GNU C++


#include <functional>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <numeric>
#include <cstdlib>
#include <cstring>
#include <climits>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <deque>
#include <stack>
#include <cmath>
#include <list>
#include <set>
#include <map>
//#include <ctime>
#define pb push_back
#define mp make_pair
#define sz(a) (int)(a).size()
#define ms0(x) memset((x),0,sizeof(x))
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()
#define rep(i,m,n) for(int i=(m),_end=(n);i < _end;++i)
#define repe(i,m,n) for(int i=(m), _end =(n);i <= _end;++i)
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
const int INF = (int) 1e9;
const long long INF64 = (long long) 1e18;
const long double eps = 1e-9;
const long double pi = 3.14159265358979323846;
using namespace std;

ll dsum(ll x){
	ll re = 0;
	for (;;){
		if (x >= 10){
			re += x % 10; x /= 10;
		}
		else{
			re += x % 10; break;
		}
	}
	return re;
}

ll mod_pow(ll x, ll n){
	if (n == 0) return 1;
	ll res = mod_pow(x*x, n / 2);
	if (n & 1) res = res*x;
	return res;
}

int main(){
	ll a, b, c;
	cin >> a >> b >> c;
	ll n = 0;
	vector<ll> st;
	repe(i, 1, 90){
		ll jud = b*mod_pow(i, a) + c;
		//cout << jud << endl;
		if(jud<1000000000 && jud>0) if (dsum(jud) == i){
			n++;
			st.push_back(jud);
		}
	}
	if (n == 0){
		cout << n << endl;
	}
	else {
		cout << n << endl;
		rep(i, 0, n){
			cout << st[i] << " ";
		}
		cout << endl;
	}
	return 0;
}