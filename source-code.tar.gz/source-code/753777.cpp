//Language: GNU C++


#include <string> 
#include <iostream> 
#include <vector> 
using namespace std;

string tolower(string s)
{
    for(int i = 0; i < s.size(); i++)
        if(s[i] >= 'A' && s[i] <= 'Z')
            s[i] += 'a' - 'A'; 

    return s; 
}

int main(void)
{
    int n;
    cin >> n; 
    vector<string> subs; 
    vector<bool> hit; 
    string curr, orig, cis; 
    char lucky; 

    for(int i = 0; i < n; i++)
    {
        cin >> curr; 
        subs.push_back(tolower(curr));
    }
    cin >> orig >> lucky; 
    if(lucky >= 'A' && lucky <= 'Z')
        lucky += 'a' - 'A'; 
    cis = tolower(orig); 
    hit = vector<bool>(orig.length(), false); 
    
    vector<pair<int, int> > indeces;
    for(int i = 0; i < subs.size(); i++)
    {
        int index = 0, newindex; 
        while(cis.find(subs[i], index) != string::npos)
        {
            newindex = cis.find(subs[i], index); 
            indeces.push_back(make_pair(newindex, newindex + subs[i].length()));
            index = newindex+1; 
            if(index >= cis.length())
                break;
        }
    }

    for(int i = 0; i < indeces.size(); i++)
    {
        for(int j = indeces[i].first; j < indeces[i].second; j++)
        {
            if(!hit[j])
            {
                char letter = lucky; 
                if(cis[j] == letter)
                {
                    letter = 'a'; 
                    while(cis[j] == letter)
                        letter++; 
                }
                cis[j] = letter; 
                hit[j] = true; 
            }
        }
    }

    for(int i = 0; i < orig.length(); i++)
    {
        if(orig[i] >= 'A' && orig[i] <= 'Z')
            cis[i] -= 'a' - 'A'; 
    }
    
    cout << cis << '\n';
    return 0; 
}
