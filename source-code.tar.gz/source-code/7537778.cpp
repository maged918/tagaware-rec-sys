//Language: GNU C++


#include <iostream>
#include<string>
#include<vector>
#include<stdio.h>
#include<algorithm>

using namespace std;

long long a[200002];
int main()
{

    long long n,maxi=0,mini=1000000001,count=0, numMx=0,numMn=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        if(maxi<a[i]) maxi=a[i];
        if(mini>a[i]) mini=a[i];
    }


    for(int i=0;i<n;i++)
    {
        if(a[i]==maxi ) numMx++;
            if( a[i] ==mini) numMn++;
    }


    if(maxi==mini){ cout<<maxi-mini<<" "<<n*(n-1)/2<<endl; return 0; }

    cout<< maxi-mini <<" "<<numMx* numMn <<endl;
    return 0;
}

