//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <math.h>
#include <iostream>
#include <algorithm>
#include <map>
#include <queue>
#include <stack>
#include <string>
#include <list>
using namespace std;
const int INF = 1888888888;
int n,af,bf,ag,bg;
int w[101010];
int s[101010];
int main(){
    //freopen("c.txt","r",stdin);
    scanf("%d%d%d%d%d", &n, &af, &ag, &bf, &bg);
    for ( int i(1);i<=n;i++) scanf("%d",&w[i]);
    s[0]=0;
    for ( int i(1);i<=n;i++){
        s[i] = s[i-1] + w[i];
    }
    int ans = INF;
    for ( int p(0);p<=n;p++){
        int ln = p-0;
        int rn = n-p;
        int s1 = s[ln]*af + (s[n]-s[ln])*ag;
        int s2 = 0;
        if ( rn-ln>1 ){
            s2 = (rn-ln-1) * bg;
        }
        if (ln-rn>1) {
            s2 = (ln-rn-1) * bf;
        }
       // printf("%d %d\n",s1,s2);
        if (s1+s2<ans) ans = s1+s2;
    }
    printf("%d\n",ans);
    return 0;
}
