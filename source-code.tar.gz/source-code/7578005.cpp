//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <vector>



using namespace std;

#define MAX 1000000000
#define pb push_back
#define mk make_pair
#define f first
#define s second


int des[2000000];
int a[2000000];
int fans;

vector <pair <int, int> > v;
int n, m, w;
bool can(int x)
{
    v.clear();
    int l = 0, r = 0;

    for (int i = 0; i <= n; i++)
        des[i] = 0;
    int add = 0;
    int ans = 0;
    
    for (int i = 1; i <= n; i++)
    {
        add -= des[i];
        if (a[i] + add < x)
        {
            des[i + w] += x - add - a[i];
            ans += x - add - a[i];
            if (ans > m) return 0;
            add += x - add - a[i];
        }
    }
    return ans <= m;
}
int main(){
    
    int l = 0, r = MAX + 1;
    int mi = (1 << 30);
    cin >> n >> m >> w;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        mi = min(mi, a[i]);
    }
    
    l = mi;
    r = mi + m + 20;

    while (r - l > 1)
    {
        int m = (l + r) / 2;
        if (can(m))
            l = m;
        else
            r = m;

    }
//  cout << fans << endl;
    cout << l << endl;
    return 0;
}