//Language: GNU C++


#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;

int main() {
    ll n;
    cin>>n;
    ll a[n + 1];
    a[0] = 0;
    ll sum[n + 1];
    for(int i = 1 ; i <= n; i++) {
        cin>>a[i];
    }
    sort(a, a + n + 1);
    ll ans = 0;
    sum[0] = a[0];
    for(int i = 1 ; i <= n ; i++) {
        sum[i] = sum[i - 1] + a[i]; 
    }
    for(int i = 0 ; i <= n; i++) {
        ans += a[i] + (sum[n] - sum[i]);
    }
    cout<<ans - a[n]<<"\n";
    return 0;
}