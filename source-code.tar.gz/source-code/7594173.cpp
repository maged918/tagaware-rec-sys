//Language: GNU C++


#include<iostream>
#include<stdio.h>
#include<stdlib.h>
using namespace std;
int compare(const void *a,const void *b)
{
return *(long long int *)a-*(long long int *)b;
}
int main()
{
int n,i,N;
scanf("%d",&n);
N=n;
long long int *a;
a=(long long int *)malloc(sizeof(long long int)*(n+1));
for(i=0;i<n;i++)
cin >> a[i];
qsort(a,n,sizeof(long long int),compare);
long long int result=0;
long long int temp=2;
for(i=0;i<N;i++)
{
result+=(a[i]*temp);
temp+=1;
}
result-=a[N-1];
cout << result << "\n";
return 0;
}

