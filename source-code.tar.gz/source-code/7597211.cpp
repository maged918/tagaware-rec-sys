//Language: MS C++


#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <map>
#include <cmath>
#include <string>
#include <algorithm>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector <long long> v(n, 0);
    for (int i = 0; i < n; i++)
        cin >> v[i];
    sort(v.begin(), v.end());
    long long ans = 0;
    for (int i = 2; i <= n; i++)
        ans += (long long)(i)*v[i - 2];
    cout << ans + n*v.back();
    return 0;
}
