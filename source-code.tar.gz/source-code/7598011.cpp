//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
#include<math.h>


int main()
{
    int n;
    scanf("%d", &n);
    int i, j,l, notOK = 0;
    char  c[100][100];
    int board[100][100];
    for (i = 0; i < n; i++)
    {
        scanf("%s", c[i]);
    }
    if (n>1){
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                if (i > 0 && i < n - 1 && j > 0 && j < n - 1)
                {
                    l = 0;
                    if (c[i - 1][j] == 'o')
                        l++;
                    if (c[i + 1][j] == 'o')
                        l++;
                    if (c[i][j - 1] == 'o')
                        l++;
                    if (c[i][j + 1] == 'o')
                        l++;
                    if (l == 1 || l == 3)
                        notOK = 1;
                }
                else if (i == 0)
                {
                    if (j > 0 && j < n - 1)
                    {
                        l = 0;
                        if (c[i + 1][j] == 'o')
                            l++;
                        if (c[i][j - 1] == 'o')
                            l++;
                        if (c[i][j + 1] == 'o')
                            l++;
                        if (l == 1 || l == 3)
                            notOK = 1;
                    }
                    else if (j == 0)
                    {
                        l = 0;
                        if (c[1][0] == 'o')
                            l++;
                        if (c[0][1] == 'o')
                            l++;
                        if (l == 1)
                            notOK = 1;
                    }
                    else
                    {
                        l = 0;
                        if (c[0][j - 1] == 'o')
                            l++;
                        if (c[1][j] == 'o')
                            l++;
                        if (l == 1)
                            notOK = 1;
                    }
                }
                else if (i == n - 1)
                {
                    if (j > 0 && j < n - 1)
                    {
                        l = 0;
                        if (c[i - 1][j] == 'o')
                            l++;
                        if (c[i][j - 1] == 'o')
                            l++;
                        if (c[i][j + 1] == 'o')
                            l++;
                        if (l == 1 || l == 3)
                            notOK = 1;
                    }
                    else if (j == 0)
                    {
                        l = 0;
                        if (c[i - 1][j] == 'o')
                            l++;
                        if (c[i][j + 1] == 'o')
                            l++;
                        if (l == 1)
                            notOK = 1;
                    }
                    else
                    {
                        l = 0;
                        if (c[i][j - 1] == 'o')
                            l++;
                        if (c[i - 1][j] == 'o')
                            l++;
                        if (l == 1)
                            notOK = 1;
                    }
                }
                else if (j == 0)
                {
                    if (i > 0 && i < n - 1)
                    {
                        l = 0;
                        if (c[i - 1][j] == 'o')
                            l++;
                        if (c[i + 1][j] == 'o')
                            l++;
                        if (c[i][j + 1] == 'o')
                            l++;
                        if (l == 1 || l == 3)
                            notOK = 1;
                    }
                }
                else
                {
                    if (i > 0 && i < n - 1)
                    {
                        l = 0;
                        if (c[i - 1][j] == 'o')
                            l++;
                        if (c[i + 1][j] == 'o')
                            l++;
                        if (c[i][j - 1] == 'o')
                            l++;
                        if (l == 1 || l == 3)
                            notOK = 1;
                    }
                }
            }
        }
    }
    if (notOK)
        printf("NO");
    else
        printf("YES");

    return 0;
}