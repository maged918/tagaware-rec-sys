//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;
typedef pair<int,int> per;
#define mp(a,b) make_pair(a,b)
#define INF 2123456789
#define T_val int
#define maxn 100100
#define root chd[0][1]
const int maxnode=maxn*2;
//伸展树维护序列，因为旋转操作不改变树的中序遍历，默认val为序列中的第几个
class SplayTree
{
private :
    int chd[maxnode][2];
    int sz[maxnode],fa[maxnode];
    T_val val[maxnode],que[maxnode];
    int rev[maxnode],sum[maxnode];//reversal标记
    int tot,nque;

    int n,m,cnt;
    T_val d[maxn];
public :
    void ReSet()//需要修改0结点的相关域
    {
        tot=0;
        chd[0][0]=chd[0][1]=0;
        sz[0]=0;//把0结点作为空节点使用，删除时赋值为0即可
        rev[0]=0;sum[0]=0;
        //序列操作可加两元素防止出现空树
        NewNode(root,0,0);//给该列元素前添加一个元素
        NewNode(chd[root][1],root,0);//给该列元素后添加一个元素
    }
    void Rotate(int x,int f)
    {
        int y,z;
        y=fa[x];z=fa[y];
        push_down(y);
        push_down(x);

        chd[y][!f]=chd[x][f];
        fa[ chd[x][f] ]=y;

        chd[x][f]=y;
        fa[y]=x;

        int fy=(chd[z][1]==y);
        chd[z][fy]=x;
        fa[x]=z;

        push_up(y);
    }
    void Splay(int x,int goal)
    {
        push_down(x);
        while (fa[x]!=goal) //fa[x] not x##########
        {
            int y,z,fx,fy;
            y=fa[x];
            z=fa[y];
            fx=(chd[y][1]==x);
            fy=(chd[z][1]==y);
            if (z==goal)
            {
                Rotate(x,!fx);
            }
            else
            {
                if (fx ^ fy)
                {
                    Rotate(x,!fx);Rotate(x,!fy);
                }
                else
                {
                    Rotate(y,!fy);Rotate(x,!fx);
                }
            }
        }
        push_up(x);
    }
    void NewNode(int &a,int _fa,T_val _val) //在此函数对结点的相关域赋初值
    {
        a=++tot;
        chd[a][0] = chd[a][1]=0;
        fa[a] = _fa;
        sz[a] = 1;
        rev[a]=0;sum[a]=_val;
        val[a]=_val;/*这是题目特定函数*/
    }
    void MakeTree(int &a,int _fa,int p,int q,T_val *st) {
        int mid = (p + q)>>1;
        NewNode(a,_fa,st[mid]);
        if(p==q)   return ;
        if (p<=mid-1) MakeTree(chd[a][0] ,a,p,mid-1,st);
        if (mid+1<=q) MakeTree(chd[a][1] ,a,mid+1,q,st);
        push_up(a);
    }
    void outAll()
    {
        nque=0;
        GetAll(root);
        for (int i=2;i<nque;i++) printf("%d ",que[i]);
        puts("");
    }
    void debug() {printf("root: %d\n",root);Treaval(root);}
    void Treaval(int x)
    {
        if(x) {
            Treaval(chd[x][0]);
            printf("结点%2d:左儿子 %2d 右儿子 %2d 父结点 %2d size = %2d val = %2d sum = %d\n",x,chd[x][0],chd[x][1],fa[x],sz[x],val[x],sum[x]);
            Treaval(chd[x][1]);
        }
    }
    int Size()
    {
        return sz[root]-2;
    }
    //以下函数传入参数的位置pos从1开始标号
    void Find(int k,int goal)//把整棵树中(不是序列)第k个元素旋转到相应位置(goal的儿子处)，默认k合法
    {
        int x = root;
        push_down(x);
        k--;
        while( sz[ chd[x][0] ] != k) {
            if(k < sz[ chd[x][0] ]) {
                x = chd[x][0];
            } else {
                k -= (sz[ chd[x][0] ] + 1);
                x = chd[x][1];
            }
            push_down(x);
        }
        Splay(x,goal);
    }
    void push_down(int x)
    {
        if (rev[x])
        {
            int temp=chd[x][0];chd[x][0]=chd[x][1];chd[x][1]=temp;
            rev[ chd[x][0] ]=rev[ chd[x][0] ]^rev[x];
            rev[ chd[x][1] ]=rev[ chd[x][1] ]^rev[x];
            rev[x]=0;
        }
    }
    void push_up(int x)
    {
        sz[x]=sz[chd[x][0]]+sz[chd[x][1]]+1;
        sum[x]=val[x]+sum[chd[x][0]]+sum[chd[x][1]];
    }
    //以下操作都需将元素编号改为实际树中编号（多加了两个元素）
    void Insert(int pos,T_val *st,int len)//在第pos个元素后插入一列元素 st数组从0开始存
    {
         pos++;
         Find(pos,0);
         Find(pos+1,root);
         int x=chd[root][1];
         MakeTree(chd[x][0],x,0,len-1,st);
         push_up(x);
         push_up(root);
    }
    void Delete(int p,int q)//删除第p到q的元素
    {
        p++;q++;
        Find(p-1,0);//处理区间应旋转区间两端外第一个元素 下面Reverse亦如此
        Find(q+1,root);
        int x=chd[root][1];
        chd[x][0]=0;
        push_up(x);
        push_up(root);
    }
    T_val Get(int pos)//得到第pos个元素
    {
        pos++;
        Find(pos,0);
        return val[root];
    }
    void GetAll(int x)//递归查询所有元素，初始时，nque初始化为0，外层传参root，结果在 que中
    {
        if (x==0) return ;
        push_down(x);
        GetAll(chd[x][0]);
        que[++nque]=val[x];
        GetAll(chd[x][1]);
        push_up(x);
    }
    void Reverse(int p,int q)//翻转第p到q的元素
    {
        p++;q++;
        Find(p-1,0);
        Find(q+1,root);
        int x=chd[ chd[root][1] ][0];
        rev[x]=rev[x]^1;
    }
    void gui_getqueue(int x)//递归查询所有元素，初始时，nque初始化为0，外层传参root，结果在 que中
    {
        if (x==0) return ;
        push_down(x);
        gui_getqueue(chd[x][0]);
        que[++nque]=x;
        gui_getqueue(chd[x][1]);
        push_up(x);
    }
    void gui_update(int x)//递归查询所有元素，初始时，nque初始化为0，外层传参root，结果在 que中
    {
        if (x==0||cnt>nque) return ;
        push_down(x);
        gui_update(chd[x][0]);
        if (++cnt<=nque) val[x]+=val[que[cnt]];
        gui_update(chd[x][1]);
        push_up(x);
    }
    void op1(int p)
    {
        p++;
        int x,y,S1,S2;
        Find(1,fa[root]);
        Find(p+1,root);
        x=chd[root][1];
        S1=chd[x][0];

        rev[S1]^=1;
        chd[x][0]=0;
        push_up(x);push_up(root);

        Find(sz[root],root);
        y=chd[root][1];
        S2=chd[y][0];

        if (sz[S1]<sz[S2]) swap(S1,S2);
        nque=0;
        gui_getqueue(S2);

        cnt=0;
        gui_update(S1);
        chd[y][0]=S1;
        fa[S1]=y;//添加注意fa域
        push_up(y);push_up(root);
    }
    void op2(int l,int r)
    {
        l++;r++;
        int y;
        Find(l-1,fa[root]);
        Find(r+1,root);
        y=chd[chd[root][1]][0];
        printf("%d\n",sum[y]);
    }
    void Work()
    {
        int i;
        scanf("%d%d",&n,&m);
        for (i=0;i<n;i++) d[i]=1;

        ReSet();
        Insert(0,d,n);
        while (m--)
        {
            int op,p,l,r;
            scanf("%d",&op);
            if (op==1)
            {
                scanf("%d",&p);
                op1(p);
            }else
            {
                scanf("%d%d",&l,&r);
                l++;
                op2(l,r);
            }
           // debug();
        }
    }
}spt;
int main()
{
   // freopen("in.txt","r",stdin);
   // freopen("out.txt","w",stdout);
    spt.Work();
    return 0;
}
