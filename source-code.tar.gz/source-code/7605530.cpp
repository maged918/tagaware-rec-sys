//Language: GNU C++


//#pragma comment(linker,"/STACK:100000000000,100000000000")

#include <string>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <set>
#include <utility>
#include <vector>
#include <algorithm>
#include <map>
#include <deque>
#include <iomanip>
#include <queue>
#include <iostream>
#include <ctime>
#include <fstream>
#include <functional>
#include <cstdlib>
#include <iterator>

#define ll long long
#define pb push_back
#define mp make_pair
#define D long double
#define pi pair<int,int>
#define si set <pi>
#define F first
#define S second
#define forn(i,n) for (int(i)=0;(i)<(n);i++)
#define forr(i,x,y) for (int(i)=(x);(i)<=(y);i++)
#define ford(i,x,y) for (int(i)=(x);(i)>=(y);i--)
#define rev reverse
#define in insert
#define er erase
#define all(n) (n).begin(),(n).end()
#define graf vector<vector<pi> >
#define graf1 vector<vector<ll> >
#define sqr(a) (a)*(a)

const ll INF=1000000007;
const D cp=2*asin(1.0);
const D eps=1e-9;
const ll mod=1000000007;

using namespace std;

int main()
{
    ll n, q;
    cin>>n>>q;
    map<ll,ll> f,s;
    f[n] = 1;
    forn(Q,q)
    {
        ll a;
        cin>>a;
        if (a==1)
        {
            ll p;
            cin>>p;
            s.clear();
            for (map<ll,ll>::iterator i=f.begin();i!=f.end();i++)
            {
                ll nq=(*i).F;
                ll w=(*i).S;
                if (nq<=p)
                {
                    s[p]+=w;
                    s[p-nq]-=w;
                    continue;
                }
                s[p]+=w;
                s[nq-p]+=w;
            }
            f=s;
        }
        else
        {
            ll l, r;
            cin>>l>>r;
            ll ans=0;
            for (map<ll,ll>::iterator i=f.begin();i!=f.end();i++)
            {
                ll nq=(*i).F;
                ll w=(*i).S;
                if (nq>=l)
                {
                    ll p=min(r,nq);
                    ans+=w*(p-l);
                }
            }
            cout<<ans<<endl;
        }
    }
    return 0;
}
