//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;

char arr[102][102];
vector< pair<int, int > > pvector;

int main(){
  int n;
  int ans, see = 0;
  cin >> n ;
  char t;
  for(int i=0; i<n; i++){
    for(int j=0; j<n; j++){
      cin >> t;
      if(n==1 && t=='o'){
        cout << "YES" << endl;
        return 0;
      }
      arr[i][j] = t;
      if(t=='o'){
        see++;
        pvector.push_back(make_pair(j, i));
        if(i==j)
          ans++;
      }
    }
  }
  if(!see){
    cout << "YES" << endl;
    return 0;
  }
  for(int i=0; i<pvector.size(); i++){
    if(arr[pvector[i].first][pvector[i].second]!= 'o'){
      cout << "NO" << endl;
      return 0;
    } 
  }
  if(!((pvector.size()-ans)%2) && pvector.size() >1)
    cout << "YES" << endl;
  else
    cout << "NO" << endl;
  return 0;
}
