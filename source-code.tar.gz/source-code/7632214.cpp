//Language: GNU C++


#include<stdio.h>

int n;

int main()
{
//    freopen("C:\\Users\\sony\\Desktop\\11.txt","r",stdin);
    scanf("%d",&n);
    int last=0,tmp;
    long long sum=0,ans=0;
    long temp;
    while(n--){
        scanf("%d",&tmp);
        temp=last-tmp;
        sum+=temp;
        if(sum<0){
            ans+=(0-sum);
            sum=0;
        }     
        last=tmp;
    }
    printf("%I64d\n",ans);
}