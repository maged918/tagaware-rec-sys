//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <functional>
#include <vector>

int main() {
    int n, s;
    std::cin >> n;
    std::cin >> s;
    std::vector<int> dollars;
    std::vector<int> cents;

    bool not_enough = true;
    for (int i = 0; i < n; ++i) {
        int d, c;
        std::cin >> d >> c;
        if ((d < s && c >= 0) || (c == 0 && d == s)) {
            not_enough = false;
            dollars.push_back(d);
            if (c != 0) {
                cents.push_back(100 - c);
            } else {
                cents.push_back(c);
            }
        }
    }

    if (not_enough) {
        std::cout << "-1" << std::endl;
        return 0;
    }

    std::vector<int>::iterator max = std::max_element(cents.begin(), cents.end(), std::less<int>());
    std::cout << *max << std::endl;

    return 0;
}
