//Language: GNU C++


#include <cstdio>

const int N = 1010, K = 5;

int a[K][N], f[K][N], u[N], n, i, j, k, t, m;

int main()
{
    scanf("%d%d", &n, &k);

    for (i = 0; i < k; i++)
        for (j = 0; j < n; j++)
        {
            scanf("%d", &a[i][j]);
            --a[i][j];
            f[i][a[i][j]] = j;
        }

    for (i = 0; i < n; i++)
    {
        for (j = 0; j < i; j++)
        {
            m = u[j] + 1;
            for (t = 1; t < k; t++)
                if (f[t][a[0][i]] < f[t][a[0][j]])
                    m = 0;
            if (m > u[i])
                u[i] = m;
        }
    }

    m = 0;
    for (i = 0; i < n; i++)
        if (u[i] > m)
            m = u[i];

    printf("%d\n", m + 1);

    return 0;
}
