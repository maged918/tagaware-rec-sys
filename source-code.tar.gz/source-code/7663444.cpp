//Language: GNU C++0x


#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <queue>
#include <deque>
#include <set>
#include <map>
using namespace std;

struct Debug {
    Debug() {}
    template <class T>
        inline Debug operator << (T a) {
            #ifndef ONLINE_JUDGE
                cout << "\033[31m" << a << "\033[0m";
            #endif
            return *this;
        }
} debug;

typedef long long int64;

struct Edge {
    int X, Y;
    int Cost;
    Edge() {}
    Edge(int x, int y, int cost):
        X(x),
        Y(y),
        Cost(cost) {}
    inline bool operator() (const Edge &A, const Edge &B) const {
        return A.Cost < B.Cost;
    }
};

static const int MAX = 3 * 1000 * 100 + 5;
int N, M, Ans;
int dp[MAX];
int Best[MAX];
Edge A[MAX];

int main() {
    cin >> N >> M;
    for (int i = 1; i <= M; ++i)
        cin >> A[i].X >> A[i].Y >> A[i].Cost;
    sort(A + 1, A + M + 1, Edge());
    for (int i = 1, Left = 1; i <= M; ++i) {
        while (A[Left].Cost < A[i].Cost)
            Best[A[Left].Y] = max(Best[A[Left].Y], dp[Left]), ++Left;
        dp[i] = max(1, Best[A[i].X] + 1);
    }
    for (int i = 1; i <= M; ++i)
        Ans = max(Ans, dp[i]);
    cout << Ans << '\n';
}
