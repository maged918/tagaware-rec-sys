//Language: GNU C++


#include <cstdio>
#include <string.h>
#include <iostream>
#include<algorithm>
#include <vector>
using namespace std;
const int MAX_N= 100005*2;
typedef __int64 ll;
struct point{
   int nu;
   ll val;
   bool operator <(const point A)const {
      return val>A.val||(val==A.val&&nu>A.nu);
   }
}E[MAX_N];
int first[MAX_N],next[MAX_N*2],ARR[MAX_N*2],numEdg=0;
ll V[MAX_N];
ll NUM[MAX_N];
int per[MAX_N];
int dfu(int x){
   if(per[x]==x) return per[x];
   else {
       per[x]=dfu(per[x]);
       return per[x];
   }
   int a;
}
void add(int a,int b){
     ARR[numEdg]=b;
     next[numEdg] = first[a];
     first[a]=numEdg++;
}
int main(){

     int N,m;
     while(scanf("%d%d",&N,&m)==2){
     numEdg=1;
     memset(first,0,sizeof(first));
     per[0]=0;
     for(int i=1; i<=N; ++i){
          per[i]=i;
          NUM[i]=1;
          scanf("%I64d",&V[i]);
          E[i].nu=i;
          E[i].val=V[i];
     }
     for(int i=0; i<m; ++i){
         int a,b;
         scanf("%d%d",&a,&b);
         if(a==b)continue;
           if( V[a]>V[b]||(b<a&&V[a]==V[b]) )
           add(b,a);
           else
           add(a,b);
     }
     sort(E+1,E+N+1);
     __int64 ans=0;
     for(int i=1; i<=N; i++){
         ll num=0;
         int from = E[i].nu;
         for(int j=first[from]; j!=0; j= next[j] ){
             int to =ARR[j];
             int x=dfu(to);
             if( x== from) continue;
             ans +=  NUM[x]*V[from]*2;
             ans +=  NUM[x]*num*V[from]*2;
             num+=NUM[x];
             per[x]=from;
           }
             NUM[from] += num;
         }
            double A = 1.0*ans/N;
            A = A/(N-1);
            printf("%.6lf\n",A);
     }
     return 0;

}