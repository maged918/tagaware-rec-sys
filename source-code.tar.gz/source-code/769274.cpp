//Language: MS C++


#include <cstdio>
int main(){long long n, k;int p;scanf("%I64d%I64d%d",&n,&k,&p);for(int i=0;i<p;i++){long long x;scanf("%I64d", &x);printf("%c", (((x == n) ? (n) : (1 + (x/2)*(n/2) - ((x-1)/2)*(n/2-1))) <= (n-k)) ? ('.') : ('X'));}return 0;}