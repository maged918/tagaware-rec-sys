//Language: GNU C++


#include <iostream>
#include <cmath>
#include <algorithm>
#include <vector>
#include <stdio.h>
#include <map>
#include <set>
#define tr 1000000007
#define mp make_pair
typedef long long ll;
using namespace std;
ll i,n,j,a[300500],m,x,y,z,rez;

int main()
{
    cin >> x >> y;
    if (min(x,y)%2)
       cout << "Akshat" << endl;
    else
        cout << "Malvika" << endl;
    return 0;
}
