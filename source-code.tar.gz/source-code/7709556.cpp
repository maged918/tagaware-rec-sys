//Language: GNU C++


#include<stdio.h>
#include<iostream>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<vector>
#include<queue>
#include<stack>
#include<algorithm>
#include<map>
#include<limits>

#define si(n) scanf("%d",&n)
#define sc(n) scanf("%c",&n)
#define sll(n) scanf("%lld",&n)
#define sull(n) scanf("%llu",&n)
#define ss(str) scanf("%s",str)
#define sf(n) scanf("%f",&n)
#define sd(n) scanf("%lf",&n)
#define I int
#define ll long long int
#define ull unsigned long long int
#define as_0 48
#define as_A 65
#define as_a 97
#define mem(a) memset(a,0,sizeof a)
#define INF (1<<30)
#define M 1000000009

using namespace std;

long long power(int a, int b)
{
    if( b == 0 )
        return a;
    else
        return a*power(a,b-1);
}

ll arr[8][3];
ll brr[8][3];

ll crr[3];
ll cnt[3];

int check()
{
    crr[0]=power(10000000,2);crr[1]=power(10000000,2);crr[2]=power(10000000,2);
    mem(cnt);

    int i,j;
    for(i=0;i<8;i++)
    {
        for(j=i+1;j<8;j++)
        {
            ll temp=(brr[i][0]-brr[j][0])*(brr[i][0]-brr[j][0])+(brr[i][1]-brr[j][1])*(brr[i][1]-brr[j][1])+(brr[i][2]-brr[j][2])*(brr[i][2]-brr[j][2]);
            if(crr[0]==power(10000000,2)) {crr[0]=temp;cnt[0]++;}
            else if(crr[0]==temp) cnt[0]++;
            else if(crr[1]==power(10000000,2)) {crr[1]=temp;cnt[1]++;}
            else if(crr[1]==temp) cnt[1]++;
            else if(crr[2]==power(10000000,2)) {crr[2]=temp;cnt[2]++;}
            else if(crr[2]==temp) cnt[2]++;
            else return 0;
        }
    }

        ll x,y,z;

    if(cnt[0]==12 && cnt[1]==12 && cnt[2]==4)
    {
        x=min(crr[0],crr[1]); y=max(crr[0],crr[1]); z=crr[2];
    }
    else if(cnt[0]==12 && cnt[1]==4 && cnt[2]==12)
    {
        x=min(crr[0],crr[2]); y=max(crr[0],crr[2]); z=crr[1];
    }
    else if(cnt[0]==4 && cnt[1]==12 && cnt[2]==12)
    {
        x=min(crr[2],crr[1]); y=max(crr[2],crr[1]); z=crr[0];
    }
    else return 0;

    //cout<<x<<" "<<y<<" "<<z<<"\n";

    if(y==2*x && z==y+x)
        return 1;
    return 0;
}

int func(int i)
{
    if(i==8)
    {
        if(check()) return 1;
        return 0;
    }

    brr[i][0]=arr[i][0]; brr[i][1]=arr[i][1]; brr[i][2]=arr[i][2];
    if(func(i+1)) return 1;
    brr[i][0]=arr[i][0]; brr[i][1]=arr[i][2]; brr[i][2]=arr[i][1];
    if(func(i+1)) return 1;
    brr[i][0]=arr[i][1]; brr[i][1]=arr[i][0]; brr[i][2]=arr[i][2];
    if(func(i+1)) return 1;
    brr[i][0]=arr[i][1]; brr[i][1]=arr[i][2]; brr[i][2]=arr[i][0];
    if(func(i+1)) return 1;
    brr[i][0]=arr[i][2]; brr[i][1]=arr[i][0]; brr[i][2]=arr[i][1];
    if(func(i+1)) return 1;
    brr[i][0]=arr[i][2]; brr[i][1]=arr[i][1]; brr[i][2]=arr[i][0];
    if(func(i+1)) return 1;

    return 0;


}

int main()
{
   //freopen("input.txt","r",stdin);
   //freopen("output.txt","w",stdout);

   ll i,j;
   for(i=0;i<8;i++)
    for(j=0;j<3;j++)
    sll(arr[i][j]);

   if(func(0))
   {
       cout<<"YES\n";
               for(i=0;i<8;i++)
            {
                for(j=0;j<3;j++)
                cout<<brr[i][j]<<" ";
                cout<<"\n";
            }
   }
   else cout<<"NO";




 return 0;
}
