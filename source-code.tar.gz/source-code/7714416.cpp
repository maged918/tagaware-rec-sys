//Language: MS C++


#include <cstdint>
#include <cstdio>
#include <iostream>
#include <vector>
#include <list>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <string>
#include <algorithm>


using namespace std;


uint32_t main()
{
	uint32_t n;
	cin >> n;

	vector< int64_t > h( n + 1 );
	int64_t power = 0;
	int64_t money = 0;
	for( uint32_t i = 1; i <= n; i++ )
	{
		cin >> h[i];
		power += h[i-1] - h[i];
		if( power < 0 )
		{
			money += -power;
			power = 0;
		}
	}

	cout << money;

	return EXIT_SUCCESS;
}