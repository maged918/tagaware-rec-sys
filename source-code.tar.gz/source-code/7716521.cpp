//Language: GNU C++


#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <cstring>
#include <vector>
#include <string>
#include <stack>
#include <queue>
#include <deque>
#include <map>
#include <set>
#include <list>
#include <algorithm>
#include <climits>
using namespace std;

typedef long long Int;
typedef pair<int,int> pii;
typedef vector<int> Vi;
typedef map<int,int> Mii;

int n = 8;
vector<Int> x(n);
vector<Int> y(n);
vector<Int> z(n);

vector<int> combs;

int cnt = 0;

Int point_dist(int ind1, int ind2)
{
	return 
		(x[ind1] - x[ind2]) * (x[ind1] - x[ind2]) +
		(y[ind1] - y[ind2]) * (y[ind1] - y[ind2]) +
		(z[ind1] - z[ind2]) * (z[ind1] - z[ind2]) 
		;
}

Int check_side(const Vi& side)
{
	set<Int> dist;

	dist.insert(point_dist(side[0], side[1]));
	dist.insert(point_dist(side[1], side[2]));
	dist.insert(point_dist(side[2], side[3]));
	dist.insert(point_dist(side[3], side[0]));
	if(dist.size() == 1 && (*dist.begin() > 0))
	{
		return *dist.begin();
	}
	else
	{
		return -1;
	}
}

bool check_cube(const Vi& side1, const Vi& side2, const Int& dist)
{
	if(point_dist(side1[0], side2[0]) != dist) return false;
	if(point_dist(side1[1], side2[1]) != dist) return false;
	if(point_dist(side1[2], side2[2]) != dist) return false;
	if(point_dist(side1[3], side2[3]) != dist) return false;
	return true;
}

bool search(int p)
{
	vector<Int> point(3);
	point[0] = x[p];
	point[1] = y[p];
	point[2] = z[p];
	sort(point.begin(), point.end());
	do
	{
		x[p] = point[0];
		y[p] = point[1];
		z[p] = point[2];

		if(p >= 3)
		{
			set<Int> dists;
			for(int i = 0; i < p; i++)
			{
				for(int j = i + 1; j < p; j++)
				{
					dists.insert(point_dist(i, j));
				}
			}
			if((dists.size() > 3) || (*dists.begin() == 0))
			{
				continue;
			}
			else if (dists.size() == 3)
			{
				set<Int>::iterator it = dists.begin();
				Int a = *it;
				Int d = *(++it);
				if(2 * a != d)
				{
					continue;
				}
			}
		}

		if(p < 7)
		{
			if(search(p+1))
			{
				return true;
			}
		}
		else
		{
			bool equal = false;	
	
			Vi side1(4);
			Vi side2(4);
			
			side1[0] = 0;
			for(int i3 = 1; i3 < 8; i3++)
			{
				for(int i2 = 1; i2 < 8; i2++)
				{
					if(i2 == i3)
					{
						continue;
					}
					for(int i4 = i2 + 1; i4 < 8; i4++)
					{
						if(i4 == i3)
						{
							continue;
						}
						side1[1] = i2;
						side1[2] = i3;
						side1[3] = i4;
						
						Int side_len = check_side(side1);
						if(side_len == -1)
						{
							continue;
						}
						
						side2.resize(0);
						for(int j = 1; j < 8; j++)
						{
							if(j != i2 && j!= i3 && j != i4)
							{
								side2.push_back(j);
							}
						}
						sort(side2.begin(),side2.end());
						do
						{
							if(check_side(side2) == side_len)
							{
								if(check_cube(side1, side2, side_len))
								{
									return true;
								}
							}
						}
						while(next_permutation(side2.begin(), side2.end()));
					}
				}	
			}
		}
	}
	while(next_permutation(point.begin(), point.end()));
	return false;
}

int main()
{
	for(int i = 0; i < n; i++)
	{
		cin >> x[i] >> y[i] >> z[i];
	}
	if(search(0))
	{
		cout<<"YES"<<endl;
		for(int i = 0;i < 8;i++)
		{
			cout<<x[i]<<" "<<y[i]<<" "<<z[i]<<endl;
		}
	}
	else
	{
		cout<<"NO"<<endl;
	}
    return 0;
}

