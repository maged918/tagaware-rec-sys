//Language: GNU C++


#include <iostream>
#include <string>
#include <cstdlib>

void check(std::string& s, int i, int n, int p) {
	for (int j = i; j < n; ++j) {
		char t;
		if (j == i) t = s[i] + 1; else t = 'a';
		while (t < 'a' + p && ((j > 0 && t == s[j - 1]) || (j > 1 && t == s[j - 2]))) t++;
		if (t - 'a' >= p) return;
		else s[j] = t;
	}
	std::cout << s << std::endl;
	exit(0);
}

int main() {
	int n, p;
	std::string s;
	std::cin >> n >> p >> s;
	for (int i = n - 1; i >= 0; --i) check(s, i, n, p);
	std::cout << "NO" << std::endl;
	return 0;
}
