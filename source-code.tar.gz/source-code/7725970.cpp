//Language: GNU C++


#define DeBUG
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <string>
#include <set>
#include <sstream>
#include <map>
#include <list>
#include <bitset>
using namespace std ;
#define zero {0}
#define INF 0x3f3f3f3f
#define EPS 1e-6
#define TRUE true
#define FALSE false
typedef long long LL;
const double PI = acos(-1.0);
//#pragma comment(linker, "/STACK:102400000,102400000")
inline int sgn(double x)
{
    return fabs(x) < EPS ? 0 : (x < 0 ? -1 : 1);
}
#define N 100005
struct Node
{
    int x[5];
    void sort1()
    {
        sort(x, x + 3);
    }
};
Node nn[10];
bool init()
{
    int i = 0;
    while (scanf("%d%d%d", &nn[i].x[0], &nn[i].x[1], &nn[i].x[2]) + 1)
    {
        i++;
        if (i == 8)
            break;
    }
    if (i == 8)
    {
        for (int j = 0; j < 8; j++)
        {
            nn[j].sort1();
        }
        return true;
    }
    else
        return false;
}
LL dis(Node a,Node b)
{
    long long ret=0;
    long long x=a.x[0]-b.x[0];
    long long y=a.x[1]-b.x[1];
    long long z=a.x[2]-b.x[2];
    ret=x*x+y*y+z*z;
    return ret;
}
bool check()
{
    long long dd[100]=zero;
    int num=0;
    for(int i=0;i<8;i++)
    {
        num=0;
        for(int j=0;j<8;j++)
        {
            if(i==j)
                continue;
            dd[num++]=dis(nn[i],nn[j]);
        }
        sort(dd,dd+num);
        long long d1=dd[0],d2=dd[0]*2,d3=dd[0]*3;
        if(d1==0||d1!=dd[1]||d1!=dd[2]||d2!=dd[3]||d2!=dd[4]||d2!=dd[5]||d3!=dd[6])
            return false;
    }
    return true;
}
int ans = 0;
bool dfs(int k)
{
    if (k == 8)
    {
        if (check())
            return true;
        return false;
    }
    do
    {
        if (dfs(k + 1))
            return true;
    }
    while (next_permutation(nn[k].x, nn[k].x + 3));
    return false;
}
int main()
{
#ifdef DeBUGs
    freopen("1.in", "r", stdin);
#endif
    while (init())
    {
        if (dfs(0))
        {
            printf("YES\n");
            for (int i = 0; i < 8; i++)
            {
                printf("%d %d %d\n", nn[i].x[0], nn[i].x[1], nn[i].x[2]);
            }
        }
        else
            printf("NO\n");
    }

    return 0;
}