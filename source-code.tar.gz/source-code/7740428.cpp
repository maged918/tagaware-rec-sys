//Language: GNU C++0x


#include <map>
#include <set>
#include <cmath>
#include <deque>
#include <limits>
#include <vector>
#include <string>
#include <iostream>
#include <cinttypes>
#include <algorithm>
#include <unordered_map>

using namespace std;

struct Input
{
    vector<int> s;

    friend std::istream& operator>>(
      std::istream& in, Input & v)
    {
        int n;
        in >> n;
        for (int i = 0; i < n; ++i)
        {
            int s;
            in >> s;
            v.s.push_back(s);
        }

        return in;
    }
};

struct Output
{
    size_t count;

    friend std::ostream& operator<<(
      std::ostream& out, Output const & v)
    {
        return out
            << v.count
            ;
    }

    friend bool operator==(
      Output const & l, Output const & r)
    {
        return true
            && l.count == r.count
            ;
    }
};

struct Solver
{
    Output solve(Input const& input)
    {
        vector<int> const & s = input.s;
        size_t N = s.size();
        deque<int> zs;
        size_t z = 0;
        size_t o = 0;

        for (int i = 0; i < N; ++i)
        {
            if (s[i] == 0)
            {
                z += 1;
            }
            else
            {
                if (z > 0) zs.push_back(z);
                z = 0;
                o += 1;
            }
        }
        if (z > 0) zs.push_back(z);
        //cerr << zs.size() << endl;
        if (0 == o) return Output{0ul};

        if (0 == zs.size()) return Output{o};
        if (s[0] == 0) zs.pop_front();
        if (0 == zs.size()) return Output{o};
        if (s[N-1] == 0) zs.pop_back();
        if (0 == zs.size()) return Output{o};

        return Output{o + zs.size()};
    }
};

int main()
{
    Solver solver;

    Input input;
    cin >> input;
    cout << solver.solve(input);

    return 0;
}

