//Language: MS C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <string>
#include <stack>
#include <queue>
#include <deque>

#define inf 1000000000
#define mod 1000000007
#define For(i, n) for(int (i) = 0; (i) < (n); (i)++)
#define FOR(i, x, n) for(int (i) = (x); i<(n); (i)++)


#define sqr(a) (a)*(a)

#define pb push_back
#define mp make_pair
#define ll long long 

#define MAX 1000
using namespace std;

ll binpow(ll a, ll n)
{
	ll b = 1;
	while(n>0)
	{
		if(n & 1)
			b *= a;
		a *= a;
		n >>= 1;
	}
	return b;
}

ll gcd(ll a, ll b)
{
	if(b == 0) return a;
	return gcd(b, a%b);
}




void solve()
{
	int m, n, a, b;
	cin >> n >> m >> a >> b;
	int res = 0;
	int tmp = 0;
	tmp = n / m;
	//if(n % m != 0) tmp++;
	res = min(a*(tmp*m), tmp*b);
	if(n % m != 0) 
	{
		res += min((n % m) * a, b);
	}
	cout << res << endl;




}


int main()
{
	ios_base::sync_with_stdio(0);
	solve();
	return 0;
}