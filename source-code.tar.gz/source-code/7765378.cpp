//Language: GNU C++



#include<iostream>
#include<stdio.h>
#include<math.h>
#include<string.h>
#include<algorithm>
#include<string>
#include<vector>
using namespace std;
#define MOD 1000000007
long long n,h,arr[11111],mem[2222][2222];
long long solve(int ind, int pre){

    //cout<<ind<<" "<<pre<<" "<<endl;
    if(ind==n &&pre==0)return 1;
    else if(ind==n) return 0;
    if(mem[ind][pre]!=-1)return mem[ind][pre];
    long long &ret=mem[ind][pre];
    ret=0;
    if(pre+arr[ind]==h){
        if(pre)ret=solve(ind+1,pre-1)*pre;
        ret%=MOD;
     //   cout<<ind<<" "<<pre<<"----"<<ret<<endl;
        ret+=solve(ind+1,pre);
      //  cout<<ind<<" "<<pre<<"===="<<ret<<endl;
        ret%=MOD;
    }
    else if(pre+arr[ind]==h-1){
        ret=solve(ind+1,pre)*(pre+1) ;
      //  cout<<ind<<" "<<pre<<"---"<<ret<<endl;
        ret%=MOD;
        ret+=solve(ind+1,pre+1) ;
       // cout<<ind<<" "<<pre<<"==="<<ret<<endl;
        ret%=MOD;
    }


   // cout<<ind<<" "<<pre<<" "<<ret<<endl;
    return ret;
}
int main()
{
    memset((mem),-1,sizeof(mem));
    cin>>n>>h;
    for(int i=0;i<n;i++){
        cin>>arr[i];

    }
    cout<<solve(0,0)<<endl;

    return 0;
}
