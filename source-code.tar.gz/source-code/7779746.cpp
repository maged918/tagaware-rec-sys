//Language: GNU C++


#include <stdio.h>

int t[5][1001], vt[5][1001], f[1001];

int main() {
	int n, k;
	scanf("%d%d", &n, &k);
	for (int i = 0; i < k; i++) {
		for (int j = 0; j < n; j++) {
			scanf("%d", &t[i][j]);
			vt[i][t[i][j]] = j;
		}
	}

	int res = 0;

	for (int i = 0; i < n; i++) {
		f[i] = 1;
		for (int j = 0; j < i; j++) {
			bool ok = true;
			for (int z = 0; z < k; z++)
				if (vt[z][t[0][i]] < vt[z][t[0][j]]) {
					ok = false;
					break;
				}
			if (ok && f[i] < f[j] + 1) f[i] = f[j] + 1;
		}
		if (res < f[i]) res = f[i];
	}

	printf("%d", res);
	return 0;
}