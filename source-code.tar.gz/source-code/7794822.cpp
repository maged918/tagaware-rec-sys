//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;
typedef __int64 lld;
const int N = 2002;
const int MAXN = N * 2 + 10;
const int MOD = 1000000007;

lld dp[MAXN][MAXN];
int a[MAXN];
int n, h;

int main() {
    scanf("%d%d", &n, &h);
    for (int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
    }
    dp[0][N] = 1;
    for (int i = 1; i <= n; i++) {
        int j = h - a[i] + N;
        if (j == N) {
            dp[i][j] = dp[i-1][j]; continue;
        }
        dp[i][j] = (dp[i-1][j] + dp[i-1][j-1]) % MOD; // _ && [
        if (j > N)dp[i][j-1] = (dp[i][j-1] + dp[i-1][j] * (j - N) % MOD) % MOD; // ]
        if (j-1 > N)dp[i][j-1] = (dp[i][j-1] + dp[i-1][j-1] * (j - 1 - N) % MOD) % MOD; // ][
        dp[i][j-1] = (dp[i][j-1] + dp[i-1][j-1]) % MOD; // []
    }
    printf("%I64d\n", dp[n][N]);
    return 0;
}
