//Language: GNU C++0x


#include <iostream>
#include <vector>
#include <map>

#include <cstdio>

using namespace std;

const int maxn = 100005;

int n, m, boss[maxn], t[maxn], x[maxn], y[maxn];

vector<int> g[maxn];

int T = 0, tin[maxn], tout[maxn];

void dfs(int v) {
  tin[v] = T++;
  for (int to : g[v]) dfs(to);
  tout[v] = T++;
}

map<int, pair<int, int>> docs[maxn];

int dsu[maxn];

int find(int v) {
  if (dsu[v] != v) dsu[v] = find(dsu[v]);
  return dsu[v];
}

void unite(int v, int to) {
  v = find(v);
  to = find(to);
  if (docs[v].size() < docs[to].size()) docs[v].swap(docs[to]);
  for (auto& z : docs[to]) docs[v][z.first] = z.second;
  docs[to].clear();
  dsu[to] = v;
}

bool isp(int v, int to) {
  return tin[v] <= tin[to] && tout[v] >= tout[to] && find(v) == find(to);
}

int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cin >> n >> m;
  for (int i = 0; i < n; ++i) dsu[i] = boss[i] = i;
  int doc = 0;
  for (int i = 0; i < m; ++i) {
    cin >> t[i] >> x[i];
    --x[i];
    if (t[i] != 2) {
      cin >> y[i];
      --y[i];
    } else {
      y[i] = doc++;
    }
    if (t[i] == 1) {
      boss[x[i]] = y[i];
      g[y[i]].push_back(x[i]);
    }
  }

  for (int i = 0; i < n; ++i)
    if (boss[i] == i) dfs(i);

  for (int i = 0; i < m; ++i)
    if (t[i] == 1) {
      unite(y[i], x[i]);
    } else if (t[i] == 2) {
      int z = find(x[i]);
      docs[z][y[i]] = {x[i], z};
    } else {
      int z = find(x[i]);
      auto it = docs[z].find(y[i]);
      if (it == docs[z].end() || !isp(x[i], it->second.first) ||
          !isp(it->second.second, x[i]))
        cout << "NO\n";
      else
        cout << "YES\n";
    }
}
