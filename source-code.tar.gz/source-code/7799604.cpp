//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll INF = 1000000000000000005;

int main()
{
	#ifdef LOCAL
	freopen("in", "r", stdin);
	#endif // LOCAL
	ll n, a, b;
	cin >> n >> a >> b;
	ll area = 6 * n;
	if(a * b >= area) {
		cout << a * b << endl;
		cout << a << ' ' << b << endl;
		return 0;
	}
	ll ans = INF, dx, dy;
	bool flag = 0;
	if(a > b) { swap(a, b); flag = 1; }
	for(ll x = a; x <= area; ++x) {
		ll y = (area + x - 1) / x;
		if(y < x) break;
//		if(x < a) x = a;
		if(y < b) y = b;
		if(x * y < ans) {
			ans = x * y;
			dx = x, dy = y;
		}
	}
	if(flag) swap(dx, dy);
	cout << ans << endl;
	cout << dx << ' ' << dy << endl;
	return 0;
}