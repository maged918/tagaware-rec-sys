//Language: GNU C++


//#include<iostream>
//using namespace std;
//
//int main()
//{
//    int n,val[101],i=0,j=0;
//    cin>>n;
//    for(int k=0;k<n;k++)
//    cin>>val[k];
//    for(int k=0;k<n;k++)
//    {
//        if(val[k]==0)
//        {
//            i=k;
//            break;
//        }
//    }
//
//    for(int k=n-1;k>=0;k--)
//    {
//        if(val[k]==0)
//        {
//            j=k;
//            break;
//        }
//    }
//
//    for(int k=i;k<=j;k++)
//    {
//        if(val[k]==0)
//        val[k]=1;
//        else
//        val[k]=0;
//    }
//    int one=0;
//    for(int k=0;k<n;k++)
//    {
//        if(val[k]==1)
//        one++;
//    }
//    cout<<one<<endl;
//    return 0;
//}
#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int flag[102];

int main()
{
    int n,m;
    cin>>n>>m;
    vector<int>ar,arr;

    for(int i=0;i<n;i++)
    {
        int j;
        cin>>j;
        ar.push_back(j);
    }
    arr = ar;
    sort(ar.begin(),ar.end());
    for(int i=0;i<n;i++)
        flag[ar[i]] = i%2;
    for(int i=0;i<n;i++)
        cout<<flag[arr[i]]<<" ";
    return 0;
}
