//Language: GNU C++


#include <iostream>
#include <cstdio>

using namespace std;

int n, p, q, cnt;

int main()
{
#ifdef LOCAL
	freopen("467A.in", "r", stdin);
#endif
	scanf("%d", &n);
	while(n--) {
		scanf("%d%d", &p, &q);
		if(q - p >= 2)	cnt++;
	}
	printf("%d\n", cnt);
	return 0;
}