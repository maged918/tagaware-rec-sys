//Language: GNU C++


#include <iostream>
using namespace std;

int n,m,k;
long long p[5001],su[5001],dp[5001][5001];

int main() {
    cin >> n >> m>> k;
    for (int i=1;i<=n;i++){
        cin >> p[i];
        su[i] = su[i-1] + p[i];
    }
    for (int i=m;i<=n;i++)
        for(int j=1;j<=k;j++)
        dp[i][j] = dp[i-1][j] > dp[i-m][j-1] + su[i] - su[i-m]?dp[i-1][j]:dp[i-m][j-1] + su[i] - su[i-m];
    cout << dp[n][k] << "\n";
    return 0;
}


