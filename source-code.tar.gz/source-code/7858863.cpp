//Language: GNU C++


#include <iostream>
#include <cstring>
#include <algorithm>
#include <cstdio>

using namespace std;

bool isKthBitSet(int x, int k)
{
    return (x & (1 << (k-1)))? true: false;
}

/*int amit(int x, int y, int k)
{
    int l = 0;

    for(i = 1; i < )
    {
        if (isKthBitSet(x, 1) != isKthBitSet(y, 1))
            return false;
        l++;
    }
    return true;
}*/

long long int NumberOfSetBits(long long int i)
{
     i = i - ((i >> 1) & 0x55555555);
     i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
     return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
}

int main()
{
    ios::sync_with_stdio(0);
    long long int n, a[111111], m, k, cnt = 0,i, j, z;
    cin >> n >> m >> k;
    for(i = 1; i <= m + 1; i++) {
        cin >> a[i];
        z = a[i];
    }

    for(i = 1; i < m + 1; i++) {
        j = a[i] ^ z;
        int set = 0
;        while (j) {
            if (j & 1) set++;
            j >>= 1;
        }
        if (set <= k) cnt++;
    }
    cout << cnt << endl;

}
