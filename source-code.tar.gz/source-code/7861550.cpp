//Language: GNU C++


#include<iostream>
#include<map>
#include<vector>
#define MAXN 500010
using namespace std;
int arr[MAXN];
vector<int> res;
map<int, int> pos;
map<int, int> cnt;
pair<int, int> st[MAXN];
int top;
int main() {
    int n;
    while (cin >> n) {
        for (int i = 0; i < n; i++) {
            cin >> arr[i];
        }
        pos.clear();
        res.clear();
        cnt.clear();
        top = -1;
        for (int i = 0; i < n; i++) {
            cnt[arr[i]]++;
            if (cnt[arr[i]] == 4) {
                for (int j = 0; j < 4; j++) {
                    res.push_back(arr[i]);
                }
                top = -1;
                pos.clear();
                cnt.clear();
            } else if (pos.count(arr[i])) {
                int j = pos[arr[i]];
                if (top < 0 || j > st[top].second) {
                    st[++top] = make_pair(j, i);
                } else {
                    for (int k = top; k >= 0; k--) {
                        if (st[k].first < j && st[k].second > j) {
                            res.push_back(arr[st[k].first]);
                            res.push_back(arr[j]);
                            res.push_back(arr[st[k].first]);
                            res.push_back(arr[j]);
                            top = -1;
                            pos.clear();
                            cnt.clear();
                            break;
                        } else if (st[k].first > j) {
                            top--;
                        } else {
                            st[++top] = make_pair(j, i);
                        }
                    }
                    if (top < 0) {
                        st[++top] = make_pair(j, i);
                    }
                }
            } else {
                pos[arr[i]] = i;
            }
        }
        cout << res.size() << endl;
        for (int i = 0; i < (int) res.size(); i++) {
            cout << res[i] << " ";
        }
        cout << endl;
    }
    return 0;
}
