//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;

int main()
{
    int n, m, k;
    double a, b;
    while (scanf("%d%d%lf%lf", &n, &m, &a, &b) != EOF)
    {
        int ans;
        if (n < m)
            ans = (a*n > b ? b : a*n);
        else if (a >= b/m)
        {
            ans = n/m * b;
            int r = n - n/m * m;
            if (r)
                ans += min(r*a, b);
        }
        else
            ans = n * a;
        printf("%d\n", ans);
    }
    return 0;
}
