//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,i,j,x,f[200];
int main()
{
	scanf("%d",&n);
	scanf("%d",&m);
	for(i=1;i<=n;i++)f[i]=1;
	for(i=1;i<=m;i++)
	{
		scanf("%d",&x);
		f[x]=0;
	}
	scanf("%d",&m);
	for(i=1;i<=m;i++)
	{
		scanf("%d",&x);
		f[x]=0;
	}
	for(i=1;i<=n;i++)if(f[i])break;
	if(i==n+1)puts("I become the guy.");
	else puts("Oh, my keyboard!");
}