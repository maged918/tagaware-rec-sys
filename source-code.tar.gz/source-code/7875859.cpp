//Language: GNU C++


#include <algorithm>
#include <bitset>
#include <deque>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <utility>
#include <vector>

#define fst first
#define snd second
#define all(x) (x).begin(), (x).end()
#define clr( a , v ) memset( a , v , sizeof(a) )
#define pb push_back
#define mp make_pair
#define sz size()
#define FORN( i , s , n ) for( int i = s ; i < (int)(n) ; i++ )
#define FOR( i , n ) FORN( i , 0 , n )
#define FORIT(i,x) for( typeof x.begin() i = x.begin() ; i != x.end() ; i++ )
#define trace(x)    cerr << #x << ": " << x << endl;
#define trace2(x, y) cerr << #x << ": " << x << " | " << #y << ": " << y << endl;
#define read ios::sync_with_stdio(false)

using namespace std;

typedef long long int64;
typedef vector <int> vi;
typedef pair <int,int> ii;
typedef vector <string> vs;
typedef vector <ii> vii;

void solve( int n ){
    if( n <= 3 ){
        puts("NO");
        return ;
    }
    if( n == 4 ){
        puts("YES");
        cout << "1 * 2 = 2" << endl;
        cout << "2 * 3 = 6" << endl;
        cout << "6 * 4 = 24" << endl;
        return ;
    }
    if( n == 5 ){
        puts("YES");
        cout << "5 - 1 = 4" << endl;
        cout << "4 - 2 = 2" << endl;
        cout << "4 * 2 = 8" << endl;
        cout << "8 * 3 = 24" << endl;
        return ;
    }
    if( n % 2 == 0 ){
        puts("YES");
        int aux = n;
        FOR( i , (n-4)/2 ){
            cout << aux << " - " << aux-1 << " = 1" << endl;
            aux -= 2;
        }
        FOR( i , (n-4)/2 - 1 ){
            cout << "1 * 1 = 1" << endl;
        }
        cout << "1 * 4 = 4" << endl;
        cout << "1 * 2 = 2" << endl;
        cout << "2 * 3 = 6" << endl;
        cout << "6 * 4 = 24" << endl;   
        return ;
    }
    if( n % 2 ){
        puts("YES");
        int aux = n;
        FOR( i , (n-5)/2 ){
            cout << aux << " - " << aux-1 << " = 1" << endl;
            aux -= 2;
        }
        FOR( i , (n-5)/2 - 1 ){
            cout << "1 * 1 = 1" << endl;
        }
        cout << "1 * 5 = 5" << endl;
        cout << "5 - 1 = 4" << endl;
        cout << "4 - 2 = 2" << endl;
        cout << "4 * 2 = 8" << endl;
        cout << "8 * 3 = 24" << endl;
        return ;
    }
    return ;
}

int main(){
    int n; cin >> n;
    solve(n);
    return 0;
}

