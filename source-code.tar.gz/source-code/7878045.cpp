//Language: GNU C++


#include <bits/stdc++.h>
#define f0(i,n) for(__typeof(n) i=0;i<n;i++)
#define rep(i,a,b) for(__typeof(b) i=a;i<=b;i++)
#define read(s) freopen(s , "r" ,stdin)
#define write(s) freopen(s , "w" , stdout)
#define BUG(x) cerr << #x << " = " << x << '\n'

using namespace std;

int p,q,l,r;

bool ck[100007];

int aa[1007],bb[1007];

int main(){

	scanf("%d %d %d %d" ,&p,&q,&l,&r);

	while(p--){

		int a,b;
		scanf("%d %d" ,&a,&b);
		rep(i,a,b) ck[i] = 1;
	}

	rep(i,1,q) scanf("%d %d" ,&aa[i],&bb[i]);
	int ans = 0;

	rep(i,l,r){

		bool ok = 0;
		for ( int j = 1 ; j <= q && ok == 0 ; j ++ ) rep(k,aa[j]+i,bb[j]+i) if (ck[k]){
			ans++;
			ok = 1;
			
			break;
		}
	}

	printf("%d\n", ans);
}