//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;
#define md int(42)
#define modul int(1e9+7)
#define FOR(i,a,b) for( int i=(a),_b=(b);i<=_b;i++)
#define DOW(i,b,a) for( int i=(b),_a=(a);i>=_a;i--)
int n,m,q;
char a[md][md];
int f[md][md][md][md];
bool t[md][md][md][md];
int main()
{
  //  freopen("inp.txt","r",stdin);
    scanf("%d%d%d",&n,&m,&q);
    FOR(i,1,n)
    scanf("%s",a[i]+1);
    memset(t,true,sizeof(t));
    FOR(x1,1,n)
    FOR(y1,1,m)
    {
        FOR(x2,x1,n)
        FOR(y2,y1,m)
        {
            if (x1==x2 && y1==y2)
            {
                if (a[x2][y2]=='1')
                {
                    t[x1][y1][x2][y2]=false;
                }
            }
            else
            {
                if (a[x2][y2]=='1' || t[x1][y1][x2-1][y2]==false || t[x1][y1][x2][y2-1]==false)
                t[x1][y1][x2][y2]=false;
            }
        }
    }
    FOR(x2,1,n)
    FOR(y2,1,m)
    {
        DOW(x1,x2,1)
        DOW(y1,y2,1)
        {
            f[x1][y1][x2][y2]+=f[x1+1][y1][x2][y2]+f[x1][y1+1][x2][y2]-f[x1+1][y1+1][x2][y2];
            if (t[x1][y1][x2][y2]) f[x1][y1][x2][y2]++;
        }
    }
    FOR(x1,1,n)
    FOR(y1,1,m)
    {
        FOR(x2,x1,n)
        FOR(y2,y1,m)
        {
            f[x1][y1][x2][y2]+=f[x1][y1][x2-1][y2]+f[x1][y1][x2][y2-1]-f[x1][y1][x2-1][y2-1];
        }
    }
    FOR(i,1,q)
    {
        int x1,y1,x2,y2;
        scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
        printf("%d\n",f[x1][y1][x2][y2]);
    }
}
