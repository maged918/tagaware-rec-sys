//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main()
{
    int n,a,b,i,c=0;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
      scanf("%d%d",&a,&b);
      
        if(a!=b)
        {
            c++;
        }

    }


    if(c!=0)
    {
        printf("Happy Alex\n");
    }
    else
    {
        printf("Poor Alex\n");
    }



    return 0;
}
