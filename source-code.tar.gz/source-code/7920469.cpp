//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <map>
#include <vector>
#include <string>
#include <cstring>
using namespace std;

const int N = 500010;

int a[N];

struct P {
    int l, r, x;
}p[N];

map<int, int> cnt, pos;
vector<int> o;
int np = 0;

void copy(int a, int b) {
    o.push_back(a);
    o.push_back(b);
    o.push_back(a);
    o.push_back(b);
    cnt.clear();
    pos.clear();
    np = 0;
}

int main() {
    int n;
    while( scanf("%d", &n) != EOF ) {
        for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
        for(int i = 1; i <= n; i++) {
            int x = a[i];
            if(cnt[x] != 0) cnt[x]++;
            else cnt[x] = 1;
            if(cnt[x] == 4) { copy(x, x); continue;}
            if(pos[x] == 0) { pos[x] = i; continue; }
            int l = pos[x], r = i;
            pos[x] = i;
            while(np > 0) {
                int nl = p[np - 1].l, nr = p[np - 1].r, nx = p[np - 1].x;
                if(nl < l && l < nr) { copy(nx, x); break; }
                else if(l <= nl) np--;
                else {
                    p[np].l = l, p[np].r = r, p[np++].x = x;
                    break;
                }
            }
            if(np == 0) p[np].l = l, p[np].r = r, p[np++].x = x;
        }
        printf("%d\n", (int)o.size());
        for(int i = 0; i < (int)o.size(); i++) printf("%d%c", o[i], i == (int)o.size() - 1?'\n':' ');
    }

    return 0;
}
