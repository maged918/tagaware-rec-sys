//Language: GNU C++


#include <map>
#include <set>
#include <list>
#include <cmath>
#include <ctime>
#include <stack>
#include <queue>
#include <vector>
#include <cstdio>
#include <string>
#include <bitset>
#include <climits>
#include <cstdlib>
#include <cstring>
#include <utility>
#include <sstream>
#include <iostream>
#include <algorithm>
#define sqr(x) ((x)*(x))
#define MIN(a, b) (((a) < (b)) ? (a) : (b))
#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#define ABS(a) (((a) > (0)) ? (a) : (-(a)))
#define eps (1e-9)
#define mp make_pair
#define pb push_back
#define Pair pair<int,int> //V W
#define xx first
#define yy second
#define equal(a,b) (ABS(a-b)<eps)
using namespace std;

template<class T> string tostring(T x) { ostringstream out; out<<x; return out.str();}
long long toint(string s) { istringstream in(s); long long x; in>>x; return x; }
#define Max 2001
/////////////////////////////////////////////////////////////////////////////////////////////////////
struct cmp{
   bool operator()(const Pair &a, const Pair &b)const{
       return a.yy>b.yy;
   }
};

int n;
vector<pair<int ,int > >ar;
vector<pair<int ,int > >ans[3];
pair<int ,int > pa;
int k=0;
int main(){
   // freopen("test.in","r",stdin);
    scanf("%d",&n);
    for (int i=0;i<n;i++){
        
        scanf("%d",&pa.xx);
        pa.yy=i+1;
        ar.pb(pa);
    }
    sort(ar.begin(),ar.end());
    ans[k]=ar;
    k++;
    int i=1;
    while(k!=3){
        while( ar[i].xx!=ar[i-1].xx && i<n)
            i++;
        
        if (i==n)
            break;
        ans[k]=ar;
        swap(ans[k][i-1],ans[k][i]);    
        k++;
        i++;
    }
    if(k==3){
        printf("YES\n");
        for (int i=0;i<3;i++,printf("\n")){
            for (int j=0;j<n;j++)
                printf("%d ",ans[i][j].yy);         
        }

    }
    else
        printf("NO");
    return 0;
}
