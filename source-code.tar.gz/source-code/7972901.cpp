//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
#define N 200001
int n,w;
int a[N],b[N],next[N];
int ans=0;
int main()
{
    int i,j;
    cin>>n>>w;
    for(i=0;i<n;i++) cin>>a[i];
    for(i=0;i<w;i++) cin>>b[i];
    for(i=0;i<n-1;i++) a[i]=a[i+1]-a[i];
    for(i=0;i<w-1;i++) b[i]=b[i+1]-b[i];
    n--;w--;
    if(w==0){
        cout<<n+1;
        return 0;
    }
    if(n<w){
        cout<<0;
        return 0;
    }
    next[0]=-1;
    j=-1;
    for(i=1;i<w;i++){
        while(j!=-1 && b[j+1]!=b[i]) j=next[j];
        if(b[j+1]==b[i]){
            ++j;
            next[i]=j;
        }
        else next[i]=-1;
    }
    j=-1;
    for(i=0;i<n;i++){
         while(j!=-1 && b[j+1]!=a[i]) j=next[j];
         if(b[j+1]==a[i]){
            ++j;
            if(j==w-1) {ans++;j=next[j];}
         }
    }
    cout<<ans;
    return 0;
}
