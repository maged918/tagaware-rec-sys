//Language: MS C++


// esta3anna 3al sha2a belAllah ..
#include<iostream>
#include<string>
#include<map>
#include<vector>
#include<queue>
#include<stack>
#include<set>
#include<algorithm>
#include<sstream>
#include<limits.h>
#include<iomanip>
#include<cstring>
#include<bitset>
#include<fstream>
#include<cmath>
#include<cassert>
#include <stdio.h>
#include<ctype.h>
using namespace std;
#define rep(i,n,m) for(int i = (int)(n), _m = (int)(m); i < _m; ++ i)
#define rrep(i,n,m) for(int i = (int)(n), _m = (int)(m); i >= _m; -- i)
#define foreach(i, c) for (__typeof((c).begin()) i = (c).begin(); i != (c).end(); i++)
#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define sz size()
#define pb push_back
#define mp make_pair
#define mems(arr, v) memset(arr, v, sizeof arr)
#define setBit(mask, bit) ((mask) | (1LL << (bit)))
#define resetBit(mask, bit) ((mask) & (~(1LL << (bit))))
#define flipBit(mask, bit) ((mask) ^ (1LL << (bit)))
#define is0(mask, bit)(((mask) & (1LL << (bit))) == 0)
#define is1(mask, bit)(((mask) & (1LL << (bit))) != 0)
#define removeLastBit(mask) ((mask) & ((mask) - 1LL))
#define firstBitOn(mask) ((mask) & ~((mask) - 1LL))
#define grayCode(mask) ((mask) ^ ((mask) << 1LL))
#define repSubMasks(subMask, mask) for(ll subMask = (ll)(mask), _mask = subMask; subMask; subMask = _mask & (subMask - 1))
int countBits(long long mask) {int res = 0; while(mask) mask &= (mask - 1), ++ res; return res;}
string toString(long long n) {stringstream ss; ss << n; return ss.str();}
long long toNumber(string s) {stringstream ss; long long n; ss << s; ss >> n; return n;}
#define INT_MAX  1000000000
#define INT_MIN -1000000000
#define INF 1000000000
#define EPS 1e-9
#define MOD 1000000007
#define debug(x) cout << #x << " : " << x << endl
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
#define Read() freopen("input.txt","r",stdin)
#define Write() freopen("output.txt","w",stdout)
bool parity[100001], visited[100001];
vector<vector<int> > adjList;
int n, m, a, b;
vector<int> path;
void rec(int node, int parent) {
    path.pb(node);
    parity[node] = 1 - parity[node];
    visited[node] = true;
    rep(i, 0, adjList[node].size()) {
        int nxt = adjList[node][i];
        if(!visited[nxt]) {
            rec(nxt, node);
            path.pb(node);
            parity[node] = 1 - parity[node];
        }
    }
    if(parity[node] && parent != -1) {
        path.pb(parent);
        path.pb(node);
        parity[parent] = 1 - parity[parent];
        parity[node] = 0;
    }
}
int main() {
 //   Read();
    while(cin >> n >> m) {
        adjList.clear();
        adjList.resize(n);
        path.clear();
        rep(i, 0, m) {
            cin >> a >> b;
            adjList[a - 1].pb(b - 1);
            adjList[b - 1].pb(a - 1);
        }
        int start = 0;
        rep(i, 0, n) {
            cin >> parity[i];
            if(parity[i]) start = i;
        }
        mems(visited, false);
        rec(start, -1);
        rep(i, 0, n)
            if(parity[i] && i != start) {
                cout << -1 << endl;
                goto end;
            }
        if(parity[start]) path.pop_back();
        cout << path.size() << endl;
        if(path.size()) cout << 1 + path[0];
        rep(i, 1, path.size())
            cout << ' ' << 1 + path[i];
        if(path.size()) cout << endl;
end:;
    }
}