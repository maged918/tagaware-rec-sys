//Language: GNU C++


/*
 * Author:  Eyelids
 * Created Time:  2014/9/30 16:02:40
 * File Name: A.cpp
 */
#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
using namespace std;
const double eps(1e-8);
typedef long long lint;
#define clr(x) memset( x , 0 , sizeof(x) )
#define sz(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
#define clrs( x , y ) memset( x , y , sizeof(x) )
typedef long long LL;
LL n;

int main() {
    cin >>n;
    LL l, m, ret, r;

    LL d = 3 - ( n % 3 );
    l = 0, r = (LL)1e6;

    ret = -1;
    //cout <<l<<" "<<r<<endl;
    while ( l <= r ) {
        m = ( l + r ) >> 1;
        LL h = m * 3 + d; 
        LL num = ( n + h ) / 3;
     
        if ( num > 0 && num >= h * (h + 1) / 2 ) {
            ret = m;
            l = m + 1;  
        } else {
            r = m - 1;    
        }
    }
    
    cout <<ret + 1<<endl;
     
    return 0;
}









