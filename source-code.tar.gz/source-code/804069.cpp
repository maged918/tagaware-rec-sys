//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<vector>
const int inf = 0x3f3f3f;
using namespace std;
int main()
{
    int n,k;
    char d[110000],x[100000];
    while(scanf("%d%d",&n,&k) != EOF)
    {
        scanf("%s",d);
        int m = 0;
        for(int i = 1 ; i <= k ; i++)
        {
            bool vis = 0;
            for(int j = m ; j < strlen(d) ; j++)
            {
                if(d[j] == '4' && d[j+1] == '7' && j+1 < strlen(d))
                {
                    if(d[j-1] == '4' && j-1 >= 0 && j%2 != 0)
                    {
                        if( (k - i + 1) % 2 == 0)
                        {
                            ;
                        }
                        else
                        {
                            d[j] = '7';
                        }
                    }
                    else
                    {
                    if( (j+1)%2 == 0)
                    {
                        d[j] = '7';
                        d[j+1] = '7';
                        if(d[j-1] == '4')m = j-1;
                        else m = j+2;
                    }
                    else
                    {
                        d[j] = '4';
                        d[j+1] = '4';
                        m = j+1;
                    }
                    vis = 1;
                    }
                    break;
                }
            }
            if(!vis)break;
        }
        printf("%s\n",d);
    }
}

