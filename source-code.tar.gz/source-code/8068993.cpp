//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int dx[] = {0, -1, 1, 0, 0};
const int dy[] = {0, 0, 0, -1, 1};
char ans[110][110];
int n, m;

char get(int x, int y) {
    if (ans[x][y])  return ans[x][y];
    char ch = 'A';
    while (1) {
        int ok = 1;
        for (int i = 1; i <= 4; i ++) {
            int nx = x + dx[i];
            int ny = y + dy[i];
            if (ans[nx][ny] == ch) {
                ok = 0;
            }
        }
        if (ok)  return ch;
        ch ++;
    }
}
int main() {
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i ++) {
        for (int j = 1; j <= m; j ++) {
            char ch = get(i, j);
            printf("%c", ch);
            if (ans[i][j])  continue;
            int len = 1;
            while (i + len <= n && j + len <= m) {
                if (get(i, j + len) != ch) {
                    break;
                }
                len ++;
            }
            len --;
            for (int x = i; x <= i + len; x ++) {
                for (int y = j; y <= j + len; y ++) {
                    ans[x][y] = ch;
                }
            }
        }
        puts("");
    }
    return 0;
}

			     	 		 	 			  	  			  	 	