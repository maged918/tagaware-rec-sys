//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <algorithm>
using namespace std;

int col[105] ;
int cnt[105] ;
int Index ;
int n , k , x ;

int cal( int id ) {
    int ans = 0 ;
    if( cnt[id] >= 2 ) {
        ans += 2 ;
    }else{
        return 0 ;
    }
    int l = id - 1 , r = id + 1 ;
    while( l > 0 && r <= Index && col[l] == col[r] && cnt[l] + cnt[r] >= 3 ) {
        ans += cnt[l] + cnt[r] ;l -- ; r ++ ;
    }
    return ans ;
}

int main(){
    
    while( scanf( "%d%d%d" , &n , &k , &x ) != EOF ) {
        Index = 0 ;
        for( int i = 1 ; i <= n ; i ++ ) {
            int c ; scanf( "%d" , &c ) ;
            if( c != col[Index] ) {
                Index ++ ;
                col[Index] = c ;
                cnt[Index] = 1 ;
            }else{
                cnt[Index] ++ ;
            }
        }
        int Max = 0 ;
        for( int i = 1 ; i <= Index ; i ++ ) {
            if( col[i] == x ) {
                Max = max( Max , cal( i ) );
            }
        }
        printf( "%d\n" , Max ) ;
    }
    return 0 ;
}