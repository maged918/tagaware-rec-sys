//Language: GNU C++0x


#include <cstdio>
#include <algorithm>
#include <cstring>
#include <map>
#include <vector>
#include <cstdlib>
// #include <cmath>
using namespace std;
typedef long long LL;
int n,d;
LL hi[101111];
int dp[101111], from[101111];

struct Pair{
    LL x,y;
    Pair(LL _x=0, LL _y=0):x(_x), y(_y){}
    bool operator <(const Pair &that)const{
        if(x!=that.x)return x<that.x;
        return y<that.y;
    }
};

struct SegTree{
    int n;
    int seg[801111];
    int num[801111];
    void init(int _n){
        n=_n;
        memset(seg,-1,sizeof(seg));
        memset(num,0,sizeof(num));
    }
    int qmax(int l, int r){
        if(l==r)return -1;
        int res=qmax(l, r, 0, n, 0);
        // printf("q %d, %d = %d\n",l,r,res);
        return res;
    }
    void update(int i, int x){
        // printf("[%d]=%d\n",i,x);
        update(i,x,0,n,0);
    }
    int qmax(int l, int r , int sl, int sr, int sk){
        if(sr<=l || r<=sl)return -1;
        // printf("seg %d %d %d\n",sl,sr,sk);
        if(l<=sl && sr<=r){ 
        //printf("k %d\n",seg[sk]);
            return seg[sk];
        }
        return mymax(
            qmax(l, r, sl, (sl+sr)/2, sk*2+1),
            qmax(l, r, (sl+sr)/2, sr, sk*2+2)
            );
    }
    void update(int i, int x, int sl, int sr, int sk){
        if(i<sl || sr<=i)return;
        if(sr-sl==1){
            seg[sk]=i;
            num[i]=x;
            return;
        }
        update(i, x, sl, (sl+sr)/2, sk*2+1);
        update(i, x, (sl+sr)/2, sr, sk*2+2);
        seg[sk] = mymax(seg[sk*2+1], seg[sk*2+2]);
        // printf("(%d) = %d\n",sk,seg[sk]);
    }
    int mymax(int a, int b){
        if(a<0)return b;
        if(b<0)return a;
        if(num[a]<num[b])return b;
        else return a;
    }
}st;


void input(){
    scanf("%d%d",&n,&d);
    for(int i=0; i<n; i++)
        scanf("%I64d",&hi[i]);
}

void solve(){
    vector<Pair> num;
    for(int i=0; i<n; i++)
        num.push_back(Pair(hi[i],i));
    sort(num.begin(), num.end());
    st.init(n);
    for(int i=0; i<n; i++){
        LL l = hi[i]-d, r=hi[i]+d;
        Pair pl(l, n), pr(r, -1);
        int il = upper_bound(num.begin(), num.end(), pl)-num.begin();
        int ir = lower_bound(num.begin(), num.end(), pr)-num.begin();
        int id = lower_bound(num.begin(), num.end(), Pair(hi[i],i))-num.begin();
        int ff = st.mymax(st.qmax(0,il), st.qmax(ir,n));
        from[i]= (ff==-1? -1: num[ff].y);
        // printf("l %d r %d ",il,ir);
        // printf("%d %d\n",ff, from[i]);
        dp[i] = (from[i]==-1?0:st.num[ff])+1;
        st.update(id, dp[i]);
    }
    int resi=0;
    for(int i=0; i<n; i++)
        if(dp[i]>dp[resi])resi=i;
    printf("%d\n",dp[resi]);
    vector<int>res;
    while(resi!=-1){
        // printf("%d ",resi);
        res.push_back(resi);
        resi=from[resi];
    }
    for(int i=res.size()-1; 0<=i; i--)
        printf("%d ",res[i]+1);
    printf("\n");
}
int main(){
    input();
    solve();
}
/*
5 2
1 3 6 7 4
10 3
2 1 3 6 9 11 7 3 20 18

*/