//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <queue>
#include <string>
#include <vector>
#include <cmath>
#define M 1000000007
using namespace std;
struct  point
{
    int x,y;
    point(int x=0,int y=0):x(x),y(y){}
};
typedef point vec;

vec operator - (point a,point b){
    return vec(a.x-b.x,a.y-b.y);
}

vec operator + (point a,point b){
    return vec(a.x+b.x,a.y+b.y);
}

vec operator * (vec a,int p){
    return vec(a.x*p,a.y*p);
}

vec operator / (vec a,int p){
    return vec(a.x/p,a.y/p);
}

bool operator < (const point& a,const point& b){
    return a.x<b.x||a.x==b.x&&a.y<b.y;
}
bool operator == (const point& a,const point& b){
    return a.x==b.x&&a.y==b.y;
}

//数量积
int dot(vec a,vec b){
    return a.x*b.x+a.y*b.y;
}
//求向量长度
int length(vec a){return sqrt(dot(a,a));}

//判断叉积符号
int dcmp(int x){
    if(fabs(x)<0)return 0;
    else return x<0?-1:1;
}

//叉积
int cross(vec a,vec b){
    return a.x*b.y-a.y*b.x;
}
//两条线交点（前提是有唯一交点）
point getLineIntersection(point p,vec v,point q,vec w){
    vec u=p-q;
    int t=cross(w,u)/cross(v,w);
    return p+v*t;
}
//给定两线段判断是否相交（交点不在端点）
bool segmentProperIntersection(point a1,point a2,point b1,point b2){
    int c1=cross(a2-a1,b1-a1),c2=cross(a2-a1,b2-a1),
            c3=cross(b2-b1,a1-b1),c4=cross(b2-b1,a2-b1);
    return dcmp(c1)*dcmp(c2)<0&&dcmp(c3)*dcmp(c4)<0;
}

//求两向量的夹角
int Angle(vec a,vec b){
    return acos(dot(a,b)/length(a)/length(b));
}

//一个向量逆时针偏转rad弧度之后的向量
vec Rotate(vec a,int rad){
    return vec(a.x*cos(rad)-a.y*sin(rad),a.x*sin(rad)+a.y*cos(rad));
}

//判断a点是否在线段bc上(包括端点)
bool onSegment(point a,point b,point c){
    return dcmp(cross(b-a,c-a))==0&&dcmp(dot(b-a,c-a))<=0;
}
//点p到线段ab的距离
int distancetosegment(point p,point a,point b){
    if(a==b)return length(p-a);
    vec v1=b-a,v2=p-a,v3=p-b;
    if(dcmp(dot(v1,v2))<0)return length(v2);
    else if(dcmp(dot(v1,v3))>0)return length(v3);
    else return fabs(cross(v1,v2))/length(v1);
}

//点到直线ab的距离
int distancetoline(point p,point a,point b)
{
    vec v1=b-a;
    vec v2=p-a;
    return fabs(cross(v1,v2))/length(v1);
}
point p[5][5],q[5];
bool square(int i,int j,int k,int l)
{
    point& p1=p[0][i];
    point& p2=p[1][j];
    point& p3=p[2][k];
    point& p4=p[3][l];
    if(cross(p1-p2,p3-p4)==0&&length(p1-p2)-length(p3-p4)==0&&length(p1-p2)>0)
    {
        vec pp=p1-p2;
        vec qq=p2-p4;
        if((pp.x*qq.x+pp.y*qq.y)==0&&length(pp)-length(qq)==0)
           return 1;
        pp=p1-p2;
        qq=p2-p3;
        if((pp.x*qq.x+pp.y*qq.y)==0&&length(pp)-length(qq)==0)
           return 1;
    }
    if(cross(p1-p3,p2-p4)==0&&length(p1-p3)-length(p2-p4)==0&&length(p1-p3)>0)
    {
        vec pp=p1-p3;
        vec qq=p3-p4;
        if((pp.x*qq.x+pp.y*qq.y)==0&&length(pp)-length(qq)==0)
           return 1;
        pp=p1-p3;
        qq=p1-p4;
        if((pp.x*qq.x+pp.y*qq.y)==0&&length(pp)-length(qq)==0)
           return 1;
    }
    return 0;
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
        for(int i=0;i<4;i++)
        {
            scanf("%d%d%d%d",&p[i][0].x,&p[i][0].y,&q[i].x,&q[i].y);
            for(int j=1;j<=3;j++)
            {
                point temp=p[i][j-1]-q[i],temp2;
                temp2.x=-temp.y;
                temp2.y=temp.x;
                p[i][j]=temp2+q[i];
            }
        }
        int ans=20;
        for(int i=0;i<4;i++)
        {
            for(int j=0;j<4;j++)
            {
                for(int k=0;k<4;k++)
                {
                    for(int l=0;l<4;l++)
                    {
                        if(square(i,j,k,l))
                        {

                            if(i+j+k+l<ans)
                            {
                                ans=i+j+k+l;
                                //cout<<i<<" "<<j<<" "<<k<<" "<<l<<endl;
                                //cout<<ans<<endl;
                            }
                        }
                    }
                }
            }
        }
        if(ans==20)puts("-1");
        else printf("%d\n",ans);
    }

    return 0;
}
