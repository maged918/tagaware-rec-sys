//Language: MS C++


#include <iostream>
#include <algorithm>
using namespace std;

int n, arr[100000], sum[100000], m, q;

void bs(int &l, int &r, int x)
{
	while (l <= r)
	{
		int m = (l + r) / 2;
		if (x < sum[m]) r = m - 1;
		else l = m + 1;
	}
}

int main()
{
	cin >> n;
	for (int i = 0; i < n; i++) cin >> arr[i];
	sum[0] = arr[0];
	for (int i = 1; i < n; i++) sum[i] = arr[i] + sum[i - 1];
	cin >> m;
	for (int i = 0; i < m; i++)
	{
		cin >> q;
		int l = 0, r = n - 1;
		bs(l, r, q);
		if (r >= 0 && sum[r] >= q) cout << r + 1 << endl;
		else cout << l + 1 << endl;
	}
	return 0;
}