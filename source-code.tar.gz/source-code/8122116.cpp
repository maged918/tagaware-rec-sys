//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct point{
  int x,y,ox,oy;
}p[4],q[4];

ll dis(point a,point b){
  int x1=a.x,y1=a.y,x2=b.x,y2=b.y;
  return 1LL*(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
}
bool ck(){
  int arr[4];arr[0]=0,arr[1]=1,arr[2]=2,arr[3]=3;
  do{
    ll s1=dis(q[arr[0]],q[arr[1]]);
    ll s2=dis(q[arr[1]],q[arr[2]]);
    ll s3=dis(q[arr[2]],q[arr[3]]);
    ll s4=dis(q[arr[3]],q[arr[0]]);
    ll s5=dis(q[arr[0]],q[arr[2]]);
    ll s6=dis(q[arr[1]],q[arr[3]]);
    if(s1>0&&s5>0&&s1==s2&&s1==s3&&s1==s4 && s5==s6){
      return 1;
    }
  }while(next_permutation(arr,arr+4));
  return 0;
}

void rc(int idx, int t){
  int x = q[idx].x - q[idx].ox;
  int y = q[idx].y - q[idx].oy;
  while (t--) {
    int v = x;
    x = -y;
    y = v;
  }
  q[idx].x = q[idx].ox + x;
  q[idx].y = q[idx].oy + y;
}

int main() {
  int n; scanf("%d", &n);
  while(n--){
    for(int i=0;i<4;++i){
      scanf("%d%d%d%d",&p[i].x,&p[i].y,&p[i].ox,&p[i].oy);
    }
    int ans=101010101;
    for(int i=0;i<4;++i){
      for(int j=0;j<4;++j){
        for(int k=0;k<4;++k){
          for(int l=0;l<4;++l){
            for(int u=0;u<4;++u)q[u]=p[u];
            rc(0,i); rc(1,j); rc(2,k); rc(3,l);
            if (ck()){
              ans = min(ans,i+j+k+l);
            }
          }
        }
      }
    }
    if (ans==101010101)ans=-1;
    cout<<ans<<endl;
  }
  
  return 0;
}
