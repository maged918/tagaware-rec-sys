//Language: GNU C++


#include<fstream>
#include<iostream>
#include<cstdio>
#include<ctime>
#include<cstdlib>
#include<set>
#define FIT(a,b) for(vector<int> ::iterator it=b.begin();it!=b.end();it++)
#include<stack>
#define ROF(a,b,c) for(register int a=b;a>=c;--a)
#include<vector>
#include<algorithm>
#define FOR(a,b,c) for(register int a=b;a<=c;++a)
#define REP(a,b) for(register int a=0;a<b;++a)
#include<cstring>
#include<bitset>
#include<cmath>
#include<iomanip>
#include<queue>
#define debug cerr<<"OK";
#define f cin
#define g cout
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define mod 1000000009
#define inf (1<<30)
#define N 100100
#define M 12
#define SQR 1000
#define DIM 1100100
using namespace std;
/*ifstream f("a.in");
ofstream g("a.out");*/
/*int dx[]={0,0,0,1,-1};
int dy[]={0,1,-1,0,0};*/
long long x,d;
vector<int> so;
int sol,come,co[N],maximu,pozitia,n,D[N];
struct Tr
{
    Tr *l,*r;
    long long key;
    int pr,best,ind,com;
    Tr(long long _key,int _pr,int _ind)
    {
        com=ind=_ind;
        pr=_pr;
        key=_key;
        best=1;
        l=r=NULL;
    }
};
#define T Tr*
T R;
int best(T t)
{
    if(!t)
        return 0;
    return t->best;
}
int com(T t)
{
    if(!t)
        return 0;
    return t->com;
}
void upd(T &t)
{
    if(!t)
        return;
    t->best=D[t->ind];
    t->com=t->ind;
    if(best(t->l)>t->best)
    {
        t->best=best(t->l);
        t->com=com(t->l);
    }
    if(best(t->r)>t->best)
    {
        t->best=best(t->r);
        t->com=com(t->r);
    }
}
void merge(T &t,T l,T r)
{
    if(!l||!r)
        t=l?l:r;
    else
    if(l->pr > r->pr)
        merge(l->r,l->r,r),t=l;
    else
        merge(r->l,l,r->l),t=r;
    upd(t);
}
void split(T t,T &l,T &r,long long k)
{
    if(!t)
        l=r=NULL;
    else
    if(k<=t->key)
        split(t->l,l,t->l,k),r=t;
    else
        split(t->r,t->r,r,k),l=t;
    upd(t);
}
void insert(T &t,T it)
{
    if(!t)
        t=it;
    else
    if(it->pr>t->pr)
        split(t,it->l,it->r,it->key),t=it;
    else
    if(it->key==t->key)
    {
        if(rand()%2)
            insert(t->l,it);
        else
            insert(t->r,it);
    }
    else
    if(it->key<t->key)
        insert(t->l,it);
    else
        insert(t->r,it);
    upd(t);
}
void queryb(long long val)
{
    Tr *t1,*t2;
    split(R,t1,t2,val);
    if(best(t2)+1>sol)
    {
        sol=best(t2)+1;
        come=com(t2);
    }
    merge(R,t1,t2);
}
void querys(long long val)
{
    Tr *t1,*t2;
    split(R,t1,t2,val+1);
    if(best(t1)+1>sol)
    {
        sol=best(t1)+1;
        come=com(t1);
    }
    merge(R,t1,t2);
}
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    #endif
    srand(time(0));
    scanf("%d%lld",&n,&d);
    FOR(i,1,n)
    {
        scanf("%lld",&x);
        sol=1;
        come=i;
        querys(x-d);
        queryb(x+d);
        T it=new Tr(x,rand(),i);
        
        D[i]=sol;
        co[i]=come;
        insert(R,it);
        if(D[i]>maximu)
        {
            maximu=D[i];
            pozitia=i;
        }
    }
    while(pozitia)
    {
        so.pb(pozitia);
        if(pozitia==co[pozitia])
            break;
        pozitia=co[pozitia];
    }
    printf("%d\n",maximu);
    ROF(i,maximu-1,0)
    printf("%d ",so[i]);
    return 0;
}
//Look at me! Look at me! The monster inside me has gown this big!
//P.S. Miriam e tare!