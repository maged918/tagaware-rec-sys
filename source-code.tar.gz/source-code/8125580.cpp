//Language: GNU C++


#include"stdio.h"
#include"string.h"
#include"iostream"
#include"queue"
#include<algorithm>
using namespace std;
#define N 100005
#define LL __int64
const int mod=1000000007 ;
LL a[N],dp[N];
int main()
{
    int i,j,n,m,t,l,r;
    while(scanf("%d",&n)!=-1)
    {
        memset(a,0,sizeof(a));
        memset(dp,0,sizeof(dp));
        for(i=1,r=0,l=N;i<=n;i++)
        {
            scanf("%d",&t);
            a[t]++;
            r=max(r,t);
            l=min(l,t);
        }
        dp[l]=l*a[l];
        LL ans=dp[l],tmp=0;
        for(i=l+1;i<=r;i++)
        {
            tmp=max(tmp,dp[i-2]);
            if(a[i]==0)
                continue;
            dp[i]=tmp+a[i]*i;
            ans=max(ans,dp[i]);
        }
        printf("%I64d\n",ans);
    }
    return 0;
}
