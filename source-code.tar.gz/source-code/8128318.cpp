//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <string>
#define X first
#define Y second
using namespace std;

inline void setIO(string a)
{
    string in=a+".in",out=a+".out";
    freopen(in.c_str(),"r",stdin);
    freopen(out.c_str(),"w",stdout);
}

int x[10005],y[10005],a[10005],b[10005];
int xx[5][10005],yy[5][10005],st[10005];
pair<int,int> A[10005];
int ans=1000000;

inline void Rot(int v,int pp)
{
    int dely=yy[pp-1][v]-b[v];
    int delx=xx[pp-1][v]-a[v];
    xx[pp][v]=a[v]-dely;
    yy[pp][v]=b[v]+delx;
}

inline int sqr(int x){return x*x;}

inline int dis(int x,int y,int dx,int dy)
{
    return sqr(x-dx)+sqr(y-dy);
}

int used[55],p[1005];

inline int dfs2(int v)
{
    if(v>4)
    {
        int sd=dis(A[p[1]].X,A[p[1]].Y,A[p[2]].X,A[p[2]].Y);
        p[5]=p[1];
        for(int i=2;i<=4;i++)
        {
            int D=dis(A[p[i]].X,A[p[i]].Y,A[p[i+1]].X,A[p[i+1]].Y);
            if(D!=sd)return 0;
        }
        int D=dis(A[p[1]].X,A[p[1]].Y,A[p[3]].X,A[p[3]].Y);
        if(D!=2*sd)return 0;
        D=dis(A[p[2]].X,A[p[2]].Y,A[p[4]].X,A[p[4]].Y);
        if(D!=2*sd)return 0;
        if(sd==0)return 0;
        return 1;
    }
    for(int i=1;i<=4;i++)
    if(!used[i])
    {
        used[i]=1;
        p[v]=i;
        if(dfs2(v+1))return 1;
        used[i]=0;
    }
    return 0;
}

inline int ck()
{
    return dfs2(1);
}

inline void dfs(int d,int mm)
{
    if(d>4)
    {
        if(ck())
            ans=min(ans,mm);
        return;
    }
    for(int i=0;i<4;i++)
    {
        A[d]=make_pair(xx[i][d],yy[i][d]);
        dfs(d+1,mm+i);
    }
}

int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        memset(used,0,sizeof(used));
        ans=1000000;
        for(int j=1;j<=4;j++)
        {
            scanf("%d%d%d%d",&x[j],&y[j],&a[j],&b[j]);
            xx[0][j]=x[j];yy[0][j]=y[j];
            for(int i=1;i<4;i++)Rot(j,i);
        }
        dfs(1,0);
        if(ans==1000000)puts("-1");else printf("%d\n",ans);
    }
    return 0;
}
