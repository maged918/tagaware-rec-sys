//Language: GNU C++0x


#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;

struct point{
    double x,y,a,b;
};

int n;

double dis(point i1,point i2){
    return sqrt((i1.x-i2.x)*(i1.x-i2.x)+(i1.y-i2.y)*(i1.y-i2.y));
}

bool vert(point i1,point i2,point i3,point i4){
    if((i1.x-i3.x)*(i2.x-i4.x)+(i1.y-i3.y)*(i2.y-i4.y)==0) return true;
    return false;
}

bool rho(point i1,point i2,point i3,point i4){
    if(dis(i1,i2)>0&&dis(i1,i2)==dis(i2,i3)&&dis(i2,i3)==dis(i3,i4)&&dis(i3,i4)==dis(i1,i4)&&dis(i2,i4)>0) return true;
    return false;
}

bool squ(point i1,point i2,point i3,point i4){
    if(rho(i1,i2,i3,i4)&&vert(i1,i2,i2,i3)) return true;
    else if(rho(i1,i2,i4,i3)&&vert(i1,i2,i2,i4)) return true;
      else if(rho(i1,i3,i2,i4)&&vert(i1,i3,i3,i2)) return true;
    return false;
}

point rotat(point i,int j){
    double x=i.x,y=i.y,a=i.a,b=i.b;
    if(j==3) i.x=a-b+y,i.y=a+b-x; //a-b+y,a+b-x
    else if(j==2) i.x=2*a-x,i.y=2*b-y;//2*a-x,2*b-y
    else if(j==1) i.x=a+b-y,i.y=b-a+x;//a+b-y,b-a+x
    return i;
}

void solve(){
    int res=100;
    point p[5];
    for(int i=0;i<4;i++)
        scanf("%lf%lf%lf%lf",&p[i].x,&p[i].y,&p[i].a,&p[i].b);
    for(int i=0;i<4;i++){
        for(int j=0;j<4;j++)
        for(int k=0;k<4;k++)
        for(int d=0;d<4;d++){
            point i1=p[0],i2=p[1],i3=p[2],i4=p[3];
            i1=rotat(i1,i);
            i2=rotat(i2,j);
            i3=rotat(i3,k);
            i4=rotat(i4,d);
            if(squ(i1,i2,i3,i4)){
            res=min(res,i+j+k+d);
            }
        }
    }
    if(res<100) printf("%d\n",res);
    else printf("-1\n");
}

int main(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        solve();
    }
    return 0;
}
