//Language: GNU C++



#include <iostream>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <climits>
#include <limits.h>
#include <string>
#include <stack>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <assert.h>
#include <cstring>
using namespace std;
#define rep(i, n) for (int (i) = 0, j1234 = n; (i) < j1234; (i) ++)
#define rep1(i, n) for (int (i) = 1, j1234 = n; (i) <= j1234; (i) ++)
#define For(i, a, b) for (int (i) = (a), ub1234=b; (i) <= ub1234; (i) ++)
#define db(x) {if(debug){cout << #x << " = " << (x) << endl;}}
#define dba(a, x, y) {if(debug){cout << #a << " :";For(i, (x), (y))cout<<" "<<(a)[(i)];cout<<endl;}}
#define clr(x) memset(x,0,sizeof(x));
#define mp make_pair
#define pb push_back
#define endl '\n'
#define ll long long
#define ld long double
#define pi 3.1415926535897932384626433832795028
const int INF = INT_MAX;
const ll INFL = LLONG_MAX;
const int output_precision = 15;
const bool debug = true;
// const ll MOD = ;

int N, S[100100], T, A[500100];

int gcd(int a, int b) { return b==0?a:gcd(b,a%b); }

int init(int a, int b, int n)
{
  if (a < b)
  {
    int m = (a + b) / 2;
    init(a,m,n*2);
    init(m+1,b,n*2+1);
    A[n]=gcd(A[n*2],A[n*2+1]);
  }
  else
  {
    A[n] = S[a];
  }
  return 0;
}
int q(int l, int r, int a, int b, int n)
{
  if (r < a || b < l) return 0;
  if (l <= a && b <= r) return A[n];
  int m = (a+b)/2;
  return gcd(q(l,r,a,m,n*2),q(l,r,m+1,b,n*2+1));
}

int q(int l, int r)
{
  return q(l,r,1,N,1);
}

vector< pair<int,int> > v;

// count number of numbers in v that are <= ub
int cnt(pair<int,int> ub)
{
  if (v[v.size()-1] <= ub) return v.size();
  if (v[0] > ub) return 0;
  int good = 0;
  int bad = v.size()-1;
  while (good + 1 < bad)
  {
    int m = (good + bad) / 2;
    if (v[m] <= ub)
      good = m;
    else
      bad = m;
  }
  return good + 1;
}
int main()
{
  ios_base::sync_with_stdio(0); cout.precision(output_precision); cout << fixed;
  cout.tie(0);
  cin >> N;
  rep1(i,N) cin >> S[i], v.pb(mp(S[i],i));
  sort(v.begin(), v.end());
  init(1,N,1);
  cin >> T;
  rep1(i,T)
  {
    int l, r;
    cin >> l >> r;
    int g = q(l,r);
    int release = 0;
    int s = cnt(mp(g,l-1));
    int b = cnt(mp(g,r));
    release = b - s;
    cout << (r-l+1-release) << endl;
  }
}
