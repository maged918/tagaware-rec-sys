//Language: GNU C++


#define _USE_MATH_DEFINES
#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
#include <algorithm>
#include <map>
#include <vector>
#include <iostream>
#include <set>
#include <cmath>
#include <cstring>
#include <bitset>
#include <deque>
using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pii;
typedef vector<pii> vpii;

#define mp make_pair
#define pb push_back
#define bpc(a) __builtin_popcount(a)
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
#define clr(ar,val) memset(ar, val, sizeof(ar))
#define forn(i,n) for(int i=0;i<(n);++i)
#define X first
#define Y second
#define debug(x) { cerr<<#x<<" = "<<(x)<<endl; }

const int mod = 1e9 + 7;
const int inf = 1e9;

ll powm(ll a,ll p,ll m){ll r=1 % m;while(p){if(p&1)r=r*a%m;p>>=1;a=a*a%m;}return r;}

int n, s[100000];
pii tree[400000];

pii build(int root, int l, int r)
{
    if(l == r)
        tree[root] = mp(s[l], 1);
    else
    {
        pii a = build(2 * root + 1, l, (l + r) / 2);
        pii b = build(2 * root + 2, (l + r) / 2 + 1, r);
        if(a.X == b.X)
            tree[root] = mp(a.X, a.Y + b.Y);
        else if(a.X % b.X == 0)
            tree[root] = b;
        else if(b.X % a.X == 0)
            tree[root] = a;
        else
            tree[root] = mp(__gcd(a.X, b.X), 0);
    }
    return tree[root];
}

pii query(int root, int l, int r, int ql, int qr)
{
    if(qr < l || ql > r)
        return mp(-1, 0);
    if(ql <= l && r <= qr)
        return root[tree];
    if(l < r)
    {
        pii a = query(2 * root + 1, l, (l + r) / 2, ql, qr);
        pii b = query(2 * root + 2, (l + r) / 2 + 1, r, ql, qr);
        if(a.X == -1)
            return b;
        if(b.X == -1)
            return a;
        if(a.X == b.X)
            return mp(a.X, a.Y + b.Y);
        if(a.X % b.X == 0)
            return b;
        if(b.X % a.X == 0)
            return a;
        return mp(__gcd(a.X, b.X), 0);
    }
    return mp(-1, 0);
}

int main()
{
    scanf("%d", &n);
    forn(i, n) scanf("%d", s + i);
    build(0, 0, n - 1);
    int t, l, r;
    scanf("%d", &t);
    for(; t; --t)
    {
        scanf("%d%d", &l, &r);
        pii res = query(0, 0, n - 1, l - 1, r - 1);
        printf("%d\n", r - l - res.Y + 1);
    }
    return 0;
}
