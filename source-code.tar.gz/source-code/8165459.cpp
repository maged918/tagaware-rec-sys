//Language: GNU C++


#include<cstdio>
#include<queue>
#include<cstring>
#include<vector>
#define INF 1LL<<60
#define N 210000
using namespace std;
typedef long long LL;
struct edge{int u, v; LL c;}E[N * 2];
int n, m, k, u, v, tot, i, sum;
LL d[N], deg[N], c;
bool vis[N], ts[N];
vector<int> G[N];
inline int getint()
{ 
	char ch=getchar(); 
	int s=0; 
	for (; ch>'9' || ch<'0'; ch=getchar()); 
	for (; '0'<=ch && ch<='9'; ch=getchar()) 
		s = s * 10 + ch - '0'; 
	return s;
}
int main()
{
	scanf("%d%d%d", &n, &m, &k);
	for (i = 1; i <= m; i++)
	{
		u = getint(), v = getint(), c = 1LL * getint();
		E[i] = (edge){u, v, c};
		G[u].push_back(i);
		G[v].push_back(i);
	}
	for (i = 1; i <= k; i++)
	{
		u = getint(), c = 1LL * getint();
		E[m + i] = (edge){1, u, c};
		G[u].push_back(m + i);
		G[1].push_back(m + i);
	}
	queue<int>qu;
	qu.push(1);
	vis[1]=true;
	for (i = 2; i <= n; i++) d[i]=INF;
	d[1]=0;
	while (!qu.empty())
	{
		u=qu.front();
		qu.pop();
		vis[u]=false;
		for (int i = 0; i < G[u].size(); i++)
		{
			v = E[G[u][i]].u + E[G[u][i]].v - u;
			if (E[G[u][i]].c + d[u] <= d[v])
			{
				d[v] = d[u] + E[G[u][i]].c;
				if (!vis[v]) qu.push(v), vis[v]=true;
			}
		}
	}
	for (i = 1; i <= m + k; i++)
		if (d[E[i].u] + E[i].c == d[E[i].v]) ts[i] = true, deg[E[i].v]++;
		else if (d[E[i].v] + E[i].c == d[E[i].u]) ts[i] = true, deg[E[i].u]++;
	for (i = m + 1; i <= m + k; i++)
		if (!ts[i]) ++sum;
		else if (deg[E[i].v] > 1) ++sum, --deg[E[i].v];
	printf("%d\n", sum);
}
		 