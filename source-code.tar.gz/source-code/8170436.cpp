//Language: GNU C++


#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<queue>
#include<map>
#include<set>
#include<string>
//#include<pair>

#define N 5005
#define M 1000005
#define mod 1000000007
//#define p 10000007
#define mod2 100000000
#define ll long long
#define LL long long
#define maxi(a,b) (a)>(b)? (a) : (b)
#define mini(a,b) (a)<(b)? (a) : (b)

using namespace std;

int n,m,k;
ll dp[N][N];
ll p[N];
ll ans;
ll sum[N];

void ini()
{
    memset(dp,0,sizeof(dp));
    memset(sum,0,sizeof(sum));
    int i;
    ll te=0;
    for(i=1;i<=n;i++){
        scanf("%I64d",&p[i]);
    }

    for(i=n-m+1;i<=n;i++){
        te+=p[i];
    }
    sum[n-m+1]=te;
    dp[n-m+1][1]=te;
   // ma=te;
    for(i=n-m;i>=1;i--){
        sum[i]=sum[i+1]+p[i]-p[i+m];
    }
    //for(i=1;i<=n;i++) printf(" i=%d sum=%I64d\n",i,sum[i]);
}

void solve()
{
    int i,j;
    dp[n][1]=sum[n];
    for(i=n-1;i>=1;i--){
        for(j=k;j>=1;j--){
            if(i+m<=n+1)
                dp[i][j]=max(dp[i+1][j],dp[i+m][j-1]+sum[i]);
            else
                dp[i][j]=dp[i+1][j];
        }
    }

}

void out()
{
    //for(int i=1;i<=n;i++){
    //    for(int j=0;j<=k;j++){
    //        printf(" i=%d j=%d dp=%I64d\n",i,j,DP(i,j));
    //    }
   // }
    printf("%I64d\n",dp[1][k]);
}

int main()
{
   // freopen("data.in","r",stdin);
    //freopen("data.out","w",stdout);
   // scanf("%d",&T);
   // for(int ccnt=1;ccnt<=T;ccnt++)
   // while(T--)
    while(scanf("%d%d%d",&n,&m,&k)!=EOF)
    {
        //if(n==0 && k==0 ) break;
        //printf("Case %d: ",ccnt);
        ini();
        solve();
        out();
    }

    return 0;
}
