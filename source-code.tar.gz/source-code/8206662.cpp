//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <iostream>

using namespace std;
const int MOD=1000000007;
int main()
{
    long long a,b;
    while(cin>>a>>b)
    {
        long long m=(1+b-1)*(b-1)/2%MOD;
        //cout<<m<<endl;
        long long sum=0;
        {
            for(long long i=1;i<=a;i++)
            {
                sum=(sum%MOD+m*((b*i)%MOD+1)%MOD)%MOD;
            }
        }
        cout<<sum<<endl;
    }
}
