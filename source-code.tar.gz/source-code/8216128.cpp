//Language: GNU C++


#include <cstring>
#include <bits/stdc++.h>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <memory.h>
#include <cassert>

using namespace std ;

//#ifndef ONLINE_JUDGE
    //freopen("input.txt", "r", stdin);
    //freopen("out.txt", "w", stdout);
//#endif




#define cin3(a,b,c) scanf("%d%d%d",&a,&b,&c)
#define cin4(a,b,c,d) scanf("%d%d%d%d",&a,&b,&c,&d)
#define cin5(a,b,c,d,e) scanf("%d%d%d%d",&a,&b,&c,&d,&e)
#define cin7(a,b,c,d,e,f,g) scanf("%lld%lld%lld%lld%lld%lld%lld",&a,&b,&c,&d,&e,&f,&g)
#define cin1(a) scanf("%d",&a)
#define cin2(a,b) scanf("%d%d",&a,&b)
#define for1(i,n) for(i=0;i<n;i++)
#define for2(i,n) for(i=1;i<=n;i++)
#define pb push_back
#define all(x) x.begin(),x.end()
#define dist(x1,y1,z1,x2,y2,z2) (x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(z1-z2)*(z1-z2)
#define inf int(2e9)
#define sin(s1) scanf("%s",s1)
#define MAX 100000
#define ll long long
#define Set(arr,k) memset(arr,k,sizeof arr)
#define db double
#define for0(i,st,en) for(i=st;i<=en;i++)
#define ull unsigned ll
#define ui unsigned int
#define lb lower_bound
#define ub upper_bound
#define gcd(a,b) __gcd(a,b)
#define mp make_pair
#define mod int(1e9+7)
#define F first
#define S second
#define pii pair<int,int>


ll p[8][3];

ll Dist(int x,int y)
{
    return dist(p[x][0],p[x][1],p[x][2],p[y][0],p[y][1],p[y][2]);
}

bool is_ok()
{
    int i,j,k=0;
    ll D[8];
    for(int i=0;i<8;i++)
    {
        for(j=0;j<8;j++) D[j]=Dist(i,j);
        sort(D,D+8);
        if(D[1]==0) return 0;
        if(D[1]==D[2]&&D[2]==D[3]&&D[4]==D[5]&&D[5]==D[6]) continue;
        return 0;
    }
    return 1;
}

bool scan()
{
    int i,j,k=0;
    while(scanf("%I64d%I64d%I64d",&p[k][0],&p[k][1],&p[k][2])==3)
    {
        k++;
        if(k==8) break;
    }
    return k>0;
}


bool flag=0;
ll count1;

void recur(int n)
{
    if(n==8)
    {
        flag = is_ok();
        return;
    }
    if(flag==1) return;
    recur(n+1);
    if(flag==1) return ;
    swap(p[n][1],p[n][2]);
    recur(n+1);
    if(flag==1) return ;
    swap(p[n][0],p[n][1]);
    recur(n+1);
    if(flag==1) return ;
    swap(p[n][1],p[n][2]);
    recur(n+1);
    if(flag==1) return ;
    swap(p[n][0],p[n][1]);
    recur(n+1);
    if(flag==1) return ;
    swap(p[n][1],p[n][2]);
    recur(n+1);
    if(flag==1) return ;
    swap(p[n][0],p[n][1]);
    swap(p[n][0],p[n][2]);
}

int main()
{
    int n,a,b,m;
    int i,j,k;

    while(scan())
    {
        //printf("yes\n");
        flag=0;
        recur(0);
        //printf("count=%I64d\n",count1);
        if(flag) printf("YES\n");
        else printf("NO\n");
        if(flag) for1(i,8) printf("%I64d %I64d %I64d\n",p[i][0],p[i][1],p[i][2]);
    }
}








