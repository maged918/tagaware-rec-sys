//Language: GNU C++0x


#include<bits/stdc++.h>
#define ll long long 
#define pb push_back
#define gc getchar_unlocked
#define pc putchar_unlocked
#define all(A) A.begin(),A.end()
#define mp make_pair
#define vi vector<int>
#define pii pair<int,int>
#define pic pair<int,char>
#define vpic vector< pic >
#define vpii vector< pii > 
using namespace std;

ll nCr[15][15],Q = 0,p = 0;
inline void pascal()
{
    for(int i=0;i<15;++i)
    {
        for(int j=0;j<15;++j)
        {
            if(j == 0 || j == i)
            nCr[i][j] = 1;
            else
            nCr[i][j] = nCr[i-1][j] + nCr[i-1][j-1];
        }
    }
}
int main()
{
    pascal();
    string A,B;
    cin>>A>>B;
    for(unsigned int i=0;i<B.length();++i)
    {
        if(B[i] == '?') ++Q;
        else if(B[i] == '+') --p;
    }
    for(unsigned int i=0;i<A.length();++i)
    if(A[i] == '+') ++p;
    if(p < 0)
    printf("0.000000000000");
    else
    printf("%.12lf",(1.0 * nCr[Q][p])/(1<<Q) );
    return 0;
}
