//Language: GNU C++


#include <iostream>

using namespace std;

int main() {
	int n; 
	cin >> n;
	int a[199999];
	for (int i = 0; i < n; i++) 
		cin >> a[i];
	int mini = -1;
	int sum = 0;
	for (int i = 0; i < n; i++) {
		if (a[i] % 2 == 1 && (mini == -1 || a[i] < mini)) {
			mini = a[i];
		}
		sum += a[i];
	}		
	
	if (mini == -1 && sum % 2 == 0)
		cout << 0;
	else if (sum % 2 == 1){
		cout << sum;	
	} else 
		cout << sum - mini;		
	return 0;
}
