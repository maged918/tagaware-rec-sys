//Language: MS C++


#include <algorithm>
#include <numeric>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <sstream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <vector>
#include <stdio.h>
#include <assert.h>
typedef long long ll;
#define mset(a, val) memset(a, val, sizeof(a))
#define up(i, s, t) for (ll i = (s); i < (t); i += 1)
#define down(i, s, t) for (ll i = (s); i > (t); i -= 1)
#define rd1(a) scanf("%d", &a)
#define rd2(a, b) scanf("%d %d", &a, &b)
#define rd3(a, b, c) scanf("%d %d %d", &a, &b, &c)
#define rd4(a, b, c, d) scanf("%d %d %d %d", &a, &b, &c, &d)
#define pii pair<int, int>

using namespace std;
const int MAXINT = 0x70707070;
const ll MAXLONG = (ll) 1 << 60;
const int MAXN = 2005;

int dp[MAXN][MAXN];
vector<int> pos[30];
char str[MAXN], pat[MAXN];
int ans[MAXN], jump[MAXN];
int n, m;

int calcJump(int is, int nn) {
	int it = 0;
	while (true) {
		it ++;
		if (it == m) {
			return is;
		}

		char ch = pat[it];
		vector<int>::iterator iter = upper_bound(pos[ch - 'a'].begin(), pos[ch - 'a'].end(), is);
		if (iter == pos[ch - 'a'].end()) {
			return -1;
		} else {
			is = *iter;
		}
	}
}

void init() {
	up(i, 0, 30) {
		pos[i].clear();
	}

	mset(dp, 0);
	mset(ans, 0);
	mset(jump, 0);
}

int main () {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	while (scanf("%s", str) != -1) {
		scanf("%s", pat);

		n = strlen(str);
		m = strlen(pat);

		
		init();

		up(i, 0, n) {
			char ch = str[i];
			pos[ch - 'a'].push_back(i);
		}

		down(i, n - 1, -1) {
			char ch = str[i];
			if (ch != pat[0]) {
				jump[i] = -1;
				continue;
			}

			int nxt = calcJump(i, n);
			jump[i] = nxt;
			if (nxt != -1) {
				jump[i] = nxt;
			}
		}

		
		up(i, 0, n) {
			up(j, 0, i + 1) {
				dp[i + 1][j] = max(dp[i + 1][j], dp[i][j]); // keep current char
				dp[i + 1][j + 1] = max(dp[i + 1][j + 1], dp[i][j]); // remove current char

				if (jump[i] != -1 && jump[i] < n) {
					int remove = jump[i] - i + 1 - m;
					dp[jump[i] + 1][j + remove] = max(dp[jump[i] + 1][j + remove], dp[i][j] + 1);
				}
			}
		}

		
		up(i, 0, n + 1) {
			printf("%d%c", dp[n][i], i + 1 == n + 1 ? '\n' : ' ');
		}
	}
	return 0;
}