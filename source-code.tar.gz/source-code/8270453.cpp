//Language: MS C++


//be name khoda

#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
using namespace std;

int a[500000],n;
pair <int,int> se[500000];

int gcd(int l,int r)
{
	if(r==0)
		return l;
	return gcd(r,l%r);
}

void make(int l,int r,int i)
{
	if(l==r)
	{
		se[i].first=a[l];
		se[i].second=1;
		return;
	}
	int m=(l+r)/2;
	make(l,m,i*2);
	make(m+1,r,i*2+1);
	int k=gcd(se[i*2].first,se[i*2+1].first);
	se[i].first=k;
	if(k==se[i*2].first)
		se[i].second+=se[i*2].second;
	if(k==se[i*2+1].first)
		se[i].second+=se[i*2+1].second;
}

int begard(int l,int r,int ln,int rn,int i)
{
	if(l<=ln && r>=rn)
		return se[i].first;
	int k=0;
	int m=(ln+rn)/2;
	if(l<=m)
		k=begard(l,r,ln,m,i*2);
	if(r>m)
	{
		if(k==0)
			k=begard(l,r,m+1,rn,i*2+1);
		else
			k=gcd(k,begard(l,r,m+1,rn,i*2+1));
	}
	return k;
}

int begard2(int l,int r,int ln,int rn,int i,int k2)
{
	if(l<=ln && r>=rn)
	{
		if(k2==se[i].first)
			return se[i].second;
		return 0;
	}
	int k=0;
	int m=(ln+rn)/2;
	if(l<=m)
		k=begard2(l,r,ln,m,i*2,k2);
	if(r>m)
		k+=begard2(l,r,m+1,rn,i*2+1,k2);
	return k;
}

void chap()
{
	for(int i=1;i<=2*n-1;i++)
		cout<<se[i].first<<" "<<se[i].second<<" "<<i<<endl;
}

int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	make(1,n,1);
	/*cout<<begard(1,1,1,n,1)<<" ";
	cout<<begard2(1,1,1,n,1,2)<<endl;*/
	int m;
	cin>>m;
	for(int i=0;i<m;i++)
	{
		int a,b;
		cin>>a>>b;
		int k=begard(a,b,1,n,1);
		cout<<b-a+1-begard2(a,b,1,n,1,k)<<endl;
	}
	return 0;
}