//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <vector>
#include <cstring>

using namespace std;

#define pb push_back
#define mp make_pair
#define ff first
#define ss second

typedef long long ll;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<ii> vii;

#define INF 200000*4

#define F(x) (((ll)(x))*(x-1)/2)
int main(){
    int a,b;
    scanf("%d%d", &a, &b);
    ll m, M = F(a-b+1);
    m = b*F(a/b)+(a/b)*(a%b);
    printf("%lld %lld\n", m, M);
    return 0;
}
