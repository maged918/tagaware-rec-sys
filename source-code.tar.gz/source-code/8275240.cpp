//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
using namespace std ;

#define rep( i , a , b ) for ( int i = a ; i < b ; ++ i )
#define For( i , a , b ) for ( int i = a ; i <= b ; ++ i )
#define rev( i , a , b ) for ( int i = a ; i >= b ; -- i )
#define clr( a , x ) memset ( a , x , sizeof a )

typedef long long LL ;

const int MAXN = 400005 ;
const int mod = 1e9 + 7 ;

int dp[MAXN] ;
int x , y ;

void solve () {
    if ( x < y ) swap ( x , y ) ;
    int h = 0 ;
    for ( int i = 1 ; i * ( i + 1 ) / 2 <= x + y ; ++ i ) ++ h ;
    clr ( dp , 0 ) ;
    dp[0] = 1 ;
    For ( i , 1 , h ) {
        rev ( j , y , i ) {
            dp[j] += dp[j - i] ;
            if ( dp[j] >= mod ) dp[j] -= mod ;
        }
    }
    int ans = 0 ;
    For ( i , max ( 0 , h * ( h + 1 ) / 2 - x ) , y ) {
        ans += dp[i] ;
        if ( ans >= mod ) ans -= mod ;
    }
    printf ( "%d\n" , ans ) ;
}

int main () {
    while ( ~scanf ( "%d%d" , &x , &y ) ) solve () ;
    return 0 ;
}