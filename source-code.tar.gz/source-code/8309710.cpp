//Language: GNU C++


//Éú³É×éºÏ
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <queue>
#include <stack>
#include <cassert>
#include <algorithm>
#include <cmath>
#include <set>
#include <list>
#include <map>
#include <limits>
using namespace std;

#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define REP(i, s, t) for(int (i)=(s);(i)<=(t);++(i))
#define UREP(i, s, t) for(int (i)=(s);(i)>=(t);--(i))
#define REPOK(i, s, t, o) for(int (i)=(s);(i)<=(t) && (o);++(i))

#define MAXN 100
#define MAXM 999999
#define MOD 10000000000007

#define PI 3.1415926535897932384626433832795
#define INF 0x7FFFFFFF

typedef long long LL;
typedef vector<int> veci;
typedef pair<int, int> pairi;

int arr[MAXN+5];
int _map[MAXN+5];

bool comp(int lhs, int rhs) {
    return arr[lhs] < arr[rhs];
}

int main() {
    //freopen("input.in", "r", stdin);
    int n, k, sum = 0;
    cin >> n >> k;
    REP(i, 0, n-1) {
        cin >> arr[i];
        sum += arr[i];
        _map[i] = i;
    }
    int lowest = sum/n;
    int highest = lowest + (sum%n ? 1 : 0);
    int cnt = 0;
    vector<pairi> ans;
    REP(i, 1, k) {
        sort(_map, _map+n, comp);
        if (arr[_map[0]] == lowest && arr[_map[n-1]] == highest)
            break;
        ans.push_back(make_pair(_map[n-1], _map[0]));
        arr[_map[0]]++;
        arr[_map[n-1]]--;
        cnt++;
    }
    sort(_map, _map+n, comp);
    cout << arr[_map[n-1]] - arr[_map[0]] << ' ' << cnt << '\n';
    int sz = ans.size();
    REP(i, 0, sz-1)
        cout << ans[i].first+1 << ' ' << ans[i].second+1 << '\n';
    return 0;
}
