//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

#define size(v) (int)v.size()
#define MOD 1000000007
#define MAX 100001
#define INF 1000000000//1e9
#define E6 1000000//1e6
#define E7 10000000//1e7
#define E8 100000000//1e8
#define E14 100000000000000//1e14
#define ulint unsigned long long int
#define lint long long int
#define mp make_pair
#define all(X) (X).begin(),(X).end()

int func(int N, int K);

int main(void) {
	vector<int> menor[8];
	vector<int> maior[8];
	std::vector<pair<int, int> > wave;
	for (int i = 1; i < 10; ++i) {
		maior[1].push_back(i);
		menor[1].push_back(i);
		wave.push_back(mp(i, 3));
	}
	for (int k = 1; k < 7; ++k) {
		for (int i = 0; i < size(menor[k]); ++i) {
			for (int j = menor[k][i]%10 + 1; j < 10; ++j) {
				maior[k+1].push_back(menor[k][i]*10 + j);
				wave.push_back(mp(menor[k][i]*10 + j, 2));
			}
		}
		for (int i = 0; i < size(maior[k]); ++i) {
			for (int j = 0; j < maior[k][i]%10; ++j) {
				menor[k+1].push_back(maior[k][i]*10 + j);
				wave.push_back(mp(maior[k][i]*10 + j, 1));
			}
		}
	}
	sort(all(wave));

	lint N, K;
	cin >> N >> K;
	if (N % 100 == 0 || K > E14/N){
		cout << "-1" << endl;
	} else {
		map<lint, vector<vector<int> > > modMenor;
		map<lint, vector<vector<int> > > modMaior;
		for (int i = 0; i < size(menor[6]); ++i){
			if (size(modMenor[menor[6][i] % N]) == 0){
				modMenor[menor[6][i] % N].resize(10);
			}
			modMenor[menor[6][i] % N][0].push_back(menor[6][i]);
		}
		for (int i = 0; i < size(menor[7]); ++i){
			if (size(modMenor[menor[7][i] % N]) == 0){
				modMenor[menor[7][i] % N].resize(10);
			}
			modMenor[menor[7][i] % N][menor[7][i]/E6].push_back(menor[7][i]);
		}
		for (int i = 0; i < size(maior[7]); ++i){
			if (size(modMaior[maior[7][i] % N]) == 0){
				modMaior[maior[7][i] % N].resize(10);
			}
			modMaior[maior[7][i] % N][maior[7][i]/E6].push_back(maior[7][i]);
		}
		for (map<lint, vector<vector<int> > >::iterator it = modMenor.begin(); it != modMenor.end(); ++it){
			for (vector<vector<int> >::iterator jt = (*it).second.begin(); jt != (*it).second.end(); ++jt){
				sort(all((*jt)));
			}
		}
		for (map<lint, vector<vector<int> > >::iterator it = modMaior.begin(); it != modMaior.end(); ++it){
			for (vector<vector<int> >::iterator jt = (*it).second.begin(); jt != (*it).second.end(); ++jt){
				sort(all((*jt)));
			}
		}
		lint sai;
		lint cont = 0;
		for (int i = 0; i < size(wave); ++i){
			if (wave[i].first % N == 0) {
				cont ++;
				sai = wave[i].first;
				if (cont == K) break;
			}
		}
		for (int i = 0; i < size(wave) && cont != K; ++i){
			lint lWave = (lint) wave[i].first;
			lint mod = (N - (lWave*E7 % N))%N;
			if (wave[i].second & 2){
				if (modMenor.count(mod) == 1){
					for (int j = 0; j < lWave%10; ++j){
						if(cont + size(modMenor[mod][j]) < K) cont += size(modMenor[mod][j]);
						else {
							sai = lWave*E7 + modMenor[mod][j][K - cont - 1];
							cont = K;
							break;
						}
					}
					if(cont == K) break;
				}
			}
			if (wave[i].second & 1){
				if (modMaior.count(mod) == 1){
					for (int j = lWave%10 + 1; j < 10; ++j){
						if(cont + size(modMaior[mod][j]) < K) cont += size(modMaior[mod][j]);
						else {
							sai = lWave*E7 + modMaior[mod][j][K - cont - 1];
							cont = K;
							break;
						}
					}
				}
			}
		}
		if (cont == K) {
			cout << sai << endl;
		} else {
			cout << "-1" << endl;
		}
	}
	return 0;
}
