//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <utility>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <cassert>
#include <vector>                              
#include <string>
#include <cstdio>
#include <cmath>
#include <queue>                                    	
#include <ctime>
#include <stack>
#include <set>
#include <map>

using namespace std;
 
#define ll long long
#define ull unsigned ll
#define inf 1000000000
#define INF 1000000000000000000ll
#define F first
#define S second
#define mp make_pair
#define pb push_back
#define ppb pop_back
#define mod 1000000007

const int N = 5005;

int n, a, b, k;
int d[3][N];
int sum[N];
int ans = 0;
int cur = 1;

int main(){	                                        
	#ifndef ONLINE_JUDGE                      
	freopen ("in","r",stdin);
	freopen ("out","w",stdout);
	#endif
	scanf("%d%d%d%d", &n, &a, &b, &k);
	d[0][a] = 1;
	for(int cnt = 1;cnt <= k;++ cnt){
	    for(int i = 1;i <= n;++ i)                    
	    	sum[i] = (sum[i - 1] + d[cur ^ 1][i]) % mod;
		for(int i = 1;i <= n;++ i){
			if(i == b)continue;
			if(i < b){
				int r = i + (b - i) / 2;
				if((b - i) % 2 == 0)-- r;
				d[cur][i] = (sum[r] - d[cur ^ 1][i] + mod) % mod;			
			}
			else {
				int l = i - (i - b) / 2;
				if((i - b) % 2 == 0)++ l;
				d[cur][i] = (((sum[n] - sum[l - 1] - d[cur ^ 1][i]) % mod) + mod) % mod;						
			}
		}	              
		cur ^= 1;
	}
	for(int i = 1;i <= n;++ i)
		ans = (ans + d[cur ^ 1][i]) % mod;
	printf("%d\n", ans);                                                                            
	return 0;
}