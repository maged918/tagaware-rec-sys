//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define si "test.inp"
#define so "test.out"
#define maxn 1010
#define maxc 256
#define oo 2000000000
#define forr(i, l, r) for (long i = l; i <= r; i++)

using namespace std;

void input(long &n) { scanf("%ld", &n); }
void output(long n) { printf("%ld", n); }

void input(long &n, char s[]){
    gets(s + 1); s[0] = 1;
    n = strlen(s) - 1;
}

bool isnt(long n){
    if (n < 2) return false;
    else if (n == 2 || n == 3) return true;
    else if (n % 2 == 0) return false;
    long i = 3;
    while (i * i <= n) {
        if (n % i == 0) return false;
        else i += 2;
    }
    return true;
}

long GetPosiblePos(long n, long pos[]){
    long res = 1; pos[0] = 1;
    forr(i, n / 2 + 1, n){
        if (isnt(i)) { pos[res++] = i; }
    }
    return res;
}

void GetDistribute(long n, char s[], long d[]){
    memset(d, 0, sizeof(d));
    forr(i, 1, n) d[s[i]]++;
}

char tmp[maxn + 1];
void output(long n, char s[], char c, long ipos, long pos[]){
    memset(tmp, 0, sizeof(tmp));
    long curpos = 0;
    long curtmp = 0;
    long j = 1;
    forr(i, 0, ipos - 1){
        while (s[j] == c && j <= n) j++;
        if (j > n) break;
        tmp[pos[i] - 1] = s[j++];
    }
    forr(i, 0, n - 1) if (tmp[i] == 0) tmp[i] = c;
    cout << tmp;
}

void solve(long n, char s[], long pos[], long d[]){
    long ipos = GetPosiblePos(n, pos);
    GetDistribute(n, s, d);
    long iequal = n - ipos;
    for(char c = 'a'; c <= 'z'; c++){
        if (d[c] >= iequal){
            cout << "YES\n";
            output(n, s, c, ipos, pos);
            return;
        }
    }
    cout << "NO";
}

long n;
char s[maxn + 1];
long d[maxc + 1];
long pos[maxn + 1];

main(){
    //freopen(si, "r", stdin); freopen(so, "w", stdout);
    input(n, s);
    solve(n, s, pos, d);
}
