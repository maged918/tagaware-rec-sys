//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#include<queue>
#include<map>
#include<set>
#include<time.h>
#include<string>
#define cl(a,b)	memset(a,b,sizeof(a))
#define max(x,y) ((x)>(y)?(x):(y))
#define min(x,y) ((x)<(y)?(x):(y))
#define REP(i,n) for(int i=0;i<n;++i)
#define REP1(i,a,b) for(int i=a;i<=b;++i)
#define REP2(i,a,b) for(int i=a;i>=b;--i)
#define MP make_pair
#define LL long long
#define ULL unsigned long long
#define X first
#define Y second
#define lson i<<1
#define rson i<<1|1
#define MAXN 2000050
using namespace std;
int a[MAXN],b[MAXN];
map<int,int>mp,cnt;
int st[MAXN];
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	int top=0,ans=0;
	for(int i=1;i<=n;++i)
	{
		if(mp[a[i]]!=0){

			b[ans++]=mp[a[i]];
			b[ans++]=a[i];
			mp.clear();
			cnt.clear();
			top=0;
			continue;
		}
		while(top>0&&((cnt[a[i]]>0&&st[top]!=a[i])||cnt[a[i]]>1)){
			cnt[st[top]]--;
			mp[st[top]]=a[i];
			top--;
		}
		st[++top]=a[i];
		cnt[a[i]]++;
	}
	printf("%d\n",ans*2);
	for(int i=0;i<ans;i+=2)
	{
		printf("%d %d %d %d",b[i],b[i+1],b[i],b[i+1]);
		if(i==ans-1)puts("");
		else
			printf(" ");
	}
}
