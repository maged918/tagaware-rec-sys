//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;

int a,x,y,ans;

int main()
{
  scanf("%d%d%d",&a,&x,&y);
  
  if(y%a==0)
  {
  	printf("-1\n");
  	return 0;
  }
  
  int ret=y/a+1;
  
  if(ret==1)
  {
  	if(x<=-(a+1)/2||x>=(a+1)/2)printf("-1\n");
  	else printf("1\n");
    return 0;
  }
  
  int t=ret/2-1;
  
  ans=3*t+ret%2+1;
  
  //printf("%d\n",ans);
  
  if(ret%2)
  {
  	if(x<=-a||x>=a||x==0)printf("-1\n");
  	else printf("%d\n",ans+1+(x>0));
  }
  else
  {
  	if(x<=-(a+1)/2||x>=(a+1)/2)printf("-1\n");
  	else printf("%d\n",ans+1);
  }
  
  return 0;
}

			  		   	 	  					 				  		 	