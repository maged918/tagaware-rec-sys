//Language: GNU C++0x


#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;
char s[2000][2000];
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("date.in","r",stdin);
        freopen("date.out","w",stdout);
    #endif
    cin.sync_with_stdio(false);
    int n;
    cin >> n;
    int spaces=2*n;
    for(int i=0;i<=n;++i,spaces-=2){
        int j = 0;
        for(j=0;j<spaces;++j)
            s[i][j] = ' ';
        for(int k = 0;k < i; ++k){
            s[i][j++] = k + '0';
            s[i][j++] =' ';
        }
        for(int k = i; k > 0; --k){
            s[i][j++] = k + '0';
            s[i][j++] =' ';
        }
        s[i][j++] = '0';
    }
    for(int i=0;i<n;++i)
        cout<<s[i]<<"\n";
    for(int i=n;i>0;--i)
        cout<<s[i]<<"\n";
    cout<<s[0];
    return 0;
}
