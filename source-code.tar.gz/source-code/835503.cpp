//Language: MS C++


#include <stdio.h>
#include <math.h>

#define MIN(a, b) ((a) < (b)? (a): (b))
#define ABS(a) ((a) < 0? -(a): a)

typedef long long int int64_t;

int n, k;

#define MAX_N 10
#define MAX_WIDTH 10
int digit[MAX_N][MAX_WIDTH];
int vector[MAX_WIDTH];

int64_t number(int index) {
	int64_t res = 0;
	int i;
	for (i = 0; i < k; ++i) {
		res *= 10;
		res += digit[index][vector[i]];
	}
	return res;
}

int64_t min() {
	int64_t res = 9999999999;
	int i;
	for (i = 0; i < n; ++i) {
		int64_t num = number(i);
		if (num < res) res = num;
	}
	return res;
}

int64_t max() {
	int64_t res = 0;
	int i;
	for (i = 0; i < n; ++i) {
		int64_t num = number(i);
		if (num > res) res = num;
	}
	return res;
}

int64_t result = 9999999999;

void check() {
	int64_t d = max() - min();
	if (d < result) result = d;
}

void replacements(int from) {
	int i;
	if (from == k) return check();
	for (i = 0; i < k; ++i) {
		int j;
		int is_good = 1;
		for (j = 0; j < from; ++j) if (vector[j] == i) {
			is_good = 0;
			break;
		}
		if (is_good) {
			vector[from] = i;
			replacements(from + 1);
		}
	}
}

int main() {
	int i;
	scanf("%d %d", &n, &k);
	for (i = 0; i < n; ++i) {
		int j;
		while (getchar() != '\n');
		for (j = 0; j < k; ++j)
			digit[i][j] = getchar() - '0';
	}
	
	replacements(0);

	printf("%lld", result);
	return 0;
}