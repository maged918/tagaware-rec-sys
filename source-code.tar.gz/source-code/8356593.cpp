//Language: GNU C++


    #include <bits/stdc++.h>
    using namespace std;

    int main(){
    int a, b, c;
    cin >> a >> b>> c;

    int max = 0;
    if (a>=b) if(a >= c) max=a; else max=c; else if(b>=c) max=b; else max=c;
    int o = -1; bool more = false;
    if(a == 1) { o=0;}
    if(b == 1) if(o==0) more=true; else o=1;
    if(c == 1) if(o==0 || o==1 ){ more = true; } else o=2;
    int res=0; bool side1 = false; bool side2=false;
    if(more) { if(a==1 && b==1) side1 =true; else if(b==1 && c==1) side2 =true;}
    if(a==1 && b==1 && c==1) {cout << a+b+c; return 0; }
    //cout << a<< " " << b << " " << c << " " << max << " " <<endl;
    if(more) if(side1) res= (a+b)*c; else if(side2) res = a* (b+c); else res = a+b+c;
    else if(max==a) if(o==0) res = a+b+c; else if(o==1 || o==2) res=a*(b + c); else res=a*b*c;
    else if(max == b) if(o==0) res = (a+b)*c; else  if(o==1) res=a+b+c; else if(o==2) res=a*(b + c); else res=a*b*c;
    else if(max == c) if(o==0) res = (a+ b)*c; else if(o==1) {if(a>c) {res=a* ( b + c); } else res=(a+b)*c; } else if(o==2) res=a+b+c; else res= a*b*c;//res = (a+b)*c;

    cout << res;

    }
