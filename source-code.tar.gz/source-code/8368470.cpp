//Language: GNU C++


#include <iostream>

using namespace std;

int a[100010];
long long d;
int n;

int main() {
	int m;
	cin >> n >> m;

	for (int i = 0; i < m; i++) 
		cin >> a[i];	

        int c = 1;
        for (int i = 0; i < m; i++) {
        	d += (n+a[i] - c)%n;
		c = a[i];
        }

        cout << d;

	return 0;
}