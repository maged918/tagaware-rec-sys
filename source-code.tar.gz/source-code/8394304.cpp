//Language: MS C++


//
//  main.cpp
//  A. Counterexample
//
//  Created by Erik Arakelyan on 10/24/14.
//  Copyright (c) 2014 Erik Arakelyan. All rights reserved.
//

#include <iostream>
using namespace std;
bool RelativelyPrime (long long int a, long long int b) { // Assumes a, b > 0
    for ( ; ; ) {
        if (!(a %= b)) return b == 1 ;
        if (!(b %= a)) return a == 1 ;
    }
}

int main() {
    long long int  l,r;
    long long int ce1,ce2,ce3,i,j;
    cin>>l>>r;
    bool exists;
    if(r-l+1>2)
    exists=true;
    else {cout<<-1<<endl;return 0;}
    
    
    for(ce1=l;ce1<=r;ce1++)
    for(ce2=ce1;ce2<=r;ce2++)
    for(ce3=ce2;ce3<=r;ce3++)
    if(RelativelyPrime(ce1, ce2) && RelativelyPrime(ce3, ce2) && !RelativelyPrime(ce1, ce3))
    {cout<<ce1<<" "<<ce2<<" "<<ce3<<endl;return 0;}
    
    cout<<-1<<endl;
    
    return 0;
}

