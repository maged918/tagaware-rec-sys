//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

struct query{
	int l, r, q;
	query(){}
	query(int ll, int rr, int qq) {
		l = ll;
		r = rr;
		q = qq;
	}
};

vector < query > Q;
int mat[33][111111];
long long sum[33][111111];

int main() {

	int n, m;
	int l, r, q;
	
	cin >> n >> m;
	
	for ( int i = 0; i < m; i ++ ) {
		cin >> l >> r >> q;
		Q.push_back(query(l, r, q));
		for ( int b = 0; b < 31; b ++ ) {
			if ( q & (1 << b) ) {
				mat[b][l] ++;
				mat[b][r + 1] --;
			}
		}
	}
	
	for ( int i = 0; i < 31; i ++ ) {
		int activos = 0;
		sum[i][0] = 0;
		for ( int j = 1; j <= n; j ++ ) {
			activos += mat[i][j];
			sum[i][j] = sum[i][j - 1];
			if ( activos ) sum[i][j] ++;
		}
	}
	
	for ( int i = 0; i < m; i ++ ) {
		l = Q[i].l; r = Q[i].r; q = Q[i].q;
		for ( int j = 0; j < 31; j ++ ) {
			if ( sum[j][r] - sum[j][l - 1] == r - l + 1 && (q & (1 << j)) == 0 ) {
				cout << "NO\n";
				return 0;
			}
		}
	}
	
	cout << "YES\n";
	
	for ( int i = 1; i <= n; i ++ ) {
		int x = 0;
		for ( int j = 0; j < 31; j ++ ) {
			if ( sum[j][i] == sum[j][i - 1] ) continue;
			x += (1<<j);
		}
		if ( i > 1 ) cout << " ";
		cout << x;
	}
	
	cout << "\n";

	return 0;
}
