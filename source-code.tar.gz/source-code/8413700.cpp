//Language: GNU C++0x


#include <vector>
#include <string>
#include <set>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <map>
#include <cstring>
#include <climits>
#include <deque>
#include <cmath>
#include <cstdio>
#include <limits>
#include <tuple>
#include <array>
#include <queue>

// ############ TASK E ##################

using namespace std;

typedef vector<int> vi;
typedef vector<string> vs;
typedef pair<int, int> pii;
typedef long long ll;

#define FV(i,v) for(int i=0; i<(int)(v).size(); i++)
#define FI(i,v) for(typeof(v.begin()) i = v.begin(); i != v.end(); ++i)
#define sz(v) (int)(v).size()
#define all(v) (v).begin(), (v).end()
#define REP(i,n) for(int (i) = 0; (i) < (n); (i)++)
#define FOR(i, st, en) for(int i=(st); i<(int)(en); i++)
#define CR(value) cout << value << endl; return
#define RV(v) FV(i,v) cin >> v[i];
#define DRV(v, n) vi (v)(n); RV((v));

const int cache_bits = 20;
const int cache_mask = (1 << cache_bits) - 1;
vector<ll> count_cache;

int count(ll x) {
    int s = 0;
    while (x) {
        s += count_cache[x & cache_mask];
        x >>= cache_bits;
    }
    return s;
}


void build_count_cache() {
    count_cache.resize(1 << cache_bits);
    FOR(i, 1, count_cache.size())
        count_cache[i] = count_cache[i & (i - 1)] + 1;
}

void solve() {
    build_count_cache();

    int n;
    cin >> n;
    vs S(n);
    REP(i, n) cin >> S[i];
    int m = S[0].size();

    vector<ll> mask_array(1 << m);
    REP(i, n) {
        FOR(j, i + 1, n) {
            ll s = 0;
            REP(k, m)
                if (S[i][k] == S[j][k])
                    s |= (1 << k);
            mask_array[s] |= (1LL << i) | (1LL << j);
        }
    }

    for(int i = mask_array.size() - 1; i; --i) {
        if (!mask_array[i]) {
            continue;
        }
        REP(bit_idx, m){
            ll bit = (1 << bit_idx);
            if (bit & i) {
                mask_array[i ^ bit] |= mask_array[i];
            }
        }
    }

    vector<double> subset_probs(m, 1.);
    FOR(k, 0, subset_probs.size()) {
        REP(i, k) {
            subset_probs[k] *= double(k - i) / (m - i);
        }
        subset_probs[k] /= (m - k);
    }

    vector<double> cnt_per_attemp(m);
    FV(i, mask_array) {
        if (!mask_array[i]) {
            continue;
        }
        int attemps = count(i);
        int unk_before = count(mask_array[i]);
        REP(bit_idx, m) {
            ll bit = 1 << bit_idx;
            if ((bit & i) == 0) {
                ll unk_after_mask = mask_array[i] & mask_array[(i | bit)];
                int unk_after = count(unk_after_mask);
                cnt_per_attemp[attemps] += (unk_before - unk_after);
            }
        }
    }

    double mexp = 0;
    REP(i, m)
        mexp += (i + 1) * subset_probs[i] * cnt_per_attemp[i] / n;

    cout.precision(15);
    cout << mexp;
}



#ifdef ONLINE_JUDGE
int main() { solve(); return 0; }
#else
void perform_testing(void (*solve)(), string problem, int itest);
int main() { perform_testing(solve, "E", -1); return 0; }
#endif // ONLINE_JUDGE
