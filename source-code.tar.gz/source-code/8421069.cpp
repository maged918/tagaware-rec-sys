//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <string>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include <set>

#define Zero(a) memset(a, 0, sizeof(a))
#define Neg(a)  memset(a, -1, sizeof(a))
#define All(a) a.begin(), a.end()
#define PB push_back
#define repf(i,a,b) for(i = a;i < b; i++)

using namespace std;
int num[1010];
int ans[3];
int main() {
	//freopen("data.out", "w", stdout);
	//freopen("data.in", "r", stdin);
	//cin.sync_with_stdio(false);
	int n, k;
	while (scanf("%d%d", &n, &k) != EOF){
		printf("1");
		int j = k + 1;
		int i = 2;
		bool prt = true;
		while (j > i){
			if (prt){
				printf(" %d", j--);
				prt = false;
			}
			else{
				printf(" %d", i++);
				prt = true;
			}
		}
		printf(" %d", (k + 1) / 2 + 1);
		for (i = k + 2; i <= n; i++){
			printf(" %d", i);
		}
		printf("\n");
	}
	return 0;
}
