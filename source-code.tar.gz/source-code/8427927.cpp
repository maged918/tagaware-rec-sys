//Language: GNU C++0x


#include <functional>
#include <algorithm>
#include <iostream>
#include <numeric>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <vector>
#include <math.h>
#include <queue>
#include <stack>
#include <set>
#include <map>

using namespace std;

#define all(p) (p).begin(), (p).end()
#define odd(x) ((x)&(1))
#define fi first
#define se second

typedef long long ll;

const int N = 111111;
const int INF = 1000000000, mod = 1000000007;
const ll LLINF = 1000000000000000000ll;

int l[N], r[N], q[N], a[N];
int add[30][N];

void upd(int l, int r, int q) {

    for (int i = 0; i < 30; ++i) {
        if (q & (1 << i)) {

            add[i][l]++;
            add[i][r + 1]--;

        }
    }

}

struct {

    int l, r;
    int And;

} t[4 * N];

void build(int v, int l, int r) {

    t[v].l = l;
    t[v].r = r;

    if (l == r) {

        t[v].And = a[l];

    } else {

        int mid = (l + r) >> 1;
        build(v << 1, l, mid);
        build(v << 1 | 1, mid + 1, r);
        t[v].And = (t[v << 1].And & t[v << 1 | 1].And);

    }

}

int query(int v, int l, int r) {

    if (l > t[v].r || r < t[v].l) return (1 << 30) - 1;
    if (l <= t[v].l && r >= t[v].r) return t[v].And;
    return (query(v << 1, l, r) & query(v << 1 | 1, l, r));

}

int main () {

    int n, m;
    scanf("%d%d", &n, &m);

    for (int i = 0; i < m; ++i) {
        scanf("%d%d%d", l + i, r + i, q + i);
        --l[i]; --r[i];

        upd(l[i], r[i], q[i]);
    }

    for (int i = 0; i < 30; ++i) {

        int cnt = 0;

        for (int j = 0; j < n; ++j) {

            if (cnt += add[i][j]) {
                a[j] |= 1 << i;
            }

        }

    }

    build(1, 0, n - 1);
    for (int i = 0; i < m; ++i) {

        if (query(1, l[i], r[i]) != q[i]) {

            puts("NO");
            return 0;

        }

    }

    puts("YES");
    for (int i = 0; i < n; ++i)
        printf("%d ", a[i]);

    return 0;
}
