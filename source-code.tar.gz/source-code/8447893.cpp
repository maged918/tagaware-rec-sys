//Language: GNU C++0x


#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;

typedef __int64 LL;

 LL cnt1,cnt2,x,y;
 LL tot;

 LL judge(LL now)
 {
     LL ret=now-now/x-now/y+now/(x*y);
     LL ans=0;
     ans+=(now/x-now/(x*y))>=cnt2?0:cnt2-(now/x-now/(x*y));
     ans+=(now/y-now/(x*y))>=cnt1?0:cnt1-(now/y-now/(x*y));
     if(ans<=ret)
        return 1;
     else
        return 0;
 }

 LL check(LL now)
 {
     LL ret=now-now/x;
     if(tot<=ret)
        return 1;
     return 0;
 }

 int main()
 {
     scanf("%I64d%I64d%I64d%I64d",&cnt1,&cnt2,&x,&y);
     tot=cnt1+cnt2;
     LL L=1,R=100000000000;
     LL ans;
     if(x==y)
     {
         while(L<=R)
         {
             LL mid=(L+R)/2;
             if(check(mid))
             {
                 ans=mid;
                 R=mid-1;
             }
             else
             {
                 L=mid+1;
             }
         }
     }
     else
     {
         while(L<=R)
        {
            LL mid=(L+R)/2;
            if(judge(mid))
            {
                R=mid-1;
                ans=mid;
            }
            else
            {
                L=mid+1;
            }
        }
     }
     printf("%I64d\n",ans);
     return 0;
 }

