//Language: GNU C++


#include <iostream>
#include <string>
#include <map>
#include <queue>
#include <stack>
#include <algorithm>
#include <list>
#include <set>
#include <cmath>
#include <cstring>
#include <stdio.h>
#include <string.h>
#include <sstream>
#include <stdlib.h>
#include <vector>
#include <iomanip>

using namespace std;

#ifdef __GNUC__
typedef long long ll;typedef unsigned long long ull;
#else
typedef __int64 ll;  typedef unsigned __int64 ull;
#endif

#define INF 1<<28
#define SIZE 100
#define PI 3.141592653590
#define REP(i,n) for (i=0;i<n;i++)
#define REPE(i,n) for (i=0;i<=n;i++)
#define REV(i,n) for (i=n;i>=0;i--)
#define FOR(i,p,k) for (i=p; i<k;i++)
#define FORE(i,a,b) for (int i=a; i<=b; i++)
#define FOREACH(it,x) for(__typeof((x).begin()) it=(x.begin()); it!=(x).end(); ++it)

#define bug(x)    cout<< "->" <<#x<<": "<<x<<endl
#define Sort(x) sort(x.begin(),x.end())
#define Reverse(x) reverse(x.begin(),x.end())
#define MP(a,b) make_pair(a,b)
#define Clear(x,with) memset(x,with,sizeof(x))
#define Copy(c,r)   memcpy(c,r,sizeof(r))
#define SZ(x) (int)x.size()
#define length(x) (int)x.length()
#define All(x) x.begin(),x.end()
#define pb push_back
#define popcount(i) __builtin_popcount(i)
#define gcd(a,b)    __gcd(a,b)
#define lcm(a,b)    (a*(b/gcd(a,b)))
#define fs first
#define sc second
#define two(X) (1<<(X))
#define twoL(X) (((int64)(1))<<(X))
#define contain(S,X) (((S)&two(X))!=0)
#define containL(S,X) (((S)&twoL(X))!=0)
#define maximum(v) *max_element(All(v))
#define minimum(v) *min_element(All(v))
#define CS c_str()
#define CL clear()
#define findx(a,x) (find(All(a),x)-a.begin())
#define ERR 1e-7
#define Unique(v) sort((v).begin(),(v).end()),v.erase(unique(v.begin(),v.end()),v.end())




double dis(int x1,int y1,int x2,int y2)
{
        return sqrt((double)(x1-x2)*(x1-x2)+(double)(y1-y2)*(y1-y2));
}
int main()
{
        int i,n,k;
        int xx[115],yy[115];
        double d,dd;
        while(scanf("%d %d",&n,&k)==2)
        {
                for(i=0;i<n;i++)
                scanf("%d %d",&xx[i],&yy[i]);
                d=0.0;
                for(i=0;i<n-1;i++)
                d+=dis(xx[i],yy[i],xx[i+1],yy[i+1]);
        dd=(d/50.0)*k;
        printf("%lf\n",dd);
      }
}
