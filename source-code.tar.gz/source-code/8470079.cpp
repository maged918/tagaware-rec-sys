//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;

#define MAXN 100005

int a[MAXN], ans[MAXN];
bool vis[MAXN];

int main() {
	int n, m;
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; i ++)
		scanf("%d", &a[i]);
	memset(vis, 0, sizeof(vis));
	memset(ans, 0, sizeof(ans));
	int cnt = 0;
	for(int i = n; i >= 1; i --) {
		if(!vis[a[i]]) {
			cnt ++;
			vis[a[i]] = true;
		}
		ans[i] = cnt;
	}
	int q;
	for(int i = 1; i <= m; i ++) {
		scanf("%d", &q);
		printf("%d\n", ans[q]);
	}
	return 0;
}


                                            