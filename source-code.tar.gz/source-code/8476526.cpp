//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
typedef long long LL;
LL a[100000], i, u, cnt, n, k;
void dfs(LL x, LL c)
{
	if (cnt >= 100000) return;
	if (c == k || x == 1)
	{
		printf("%I64d ", x);
		++cnt;
		return;
	}
	for (LL i = 1; i <= u && x >= a[i]; i++)
		if (x % a[i] == 0) dfs(a[i], c + 1);
}
int main()
{
	scanf("%I64d%I64d", &n, &k);
	LL w = sqrt(n);
	for (LL i = 1; i <= w; i++)
		if (n % i == 0) a[++u] = i, a[++u] = n / i;
	if (w * w == n) u--;
	sort(a + 1, a + u + 1);
	dfs(n, 0);
	return 0;
}