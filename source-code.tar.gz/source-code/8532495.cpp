//Language: GNU C++0x


#include <bits/stdc++.h>

using namespace std;

int main() {
    map<char, int> M;
    char s1[205], s2[205];
    gets(s1);
    gets(s2);
    for (int i = 0; i < strlen(s1); i++) M[s1[i]]++;
    M[' '] += 200;
    for (int i = 0; i < strlen(s2); i++) M[s2[i]]--;
    bool ok = true;
    for (int i = 0; i < 128; i++) if (M[char(i)] < 0) ok = false;
    if (ok) puts("YES"); else puts("NO");
    return 0;
}