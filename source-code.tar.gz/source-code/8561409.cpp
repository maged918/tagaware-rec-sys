//Language: GNU C++


#define _USE_MATH_DEFINES
#include <iostream>
#include <fstream>
#include <algorithm>
#include <iomanip>
#include <cstdio>
#include <vector>
#include <string>
#include <cstdlib>
#include <memory>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <limits.h>
#include <set>
#define pb push_back
#define mp make_pair
#define ll long long
#define vi vector<int>
#define f first
#define s second
using namespace std;
//__________________________
ll n, m, a;
set<int> s;
//__________________________

int main(){
    cin>>a>>m;
    while(1){
        a = (a+a)%m;
        if(a == 0){
            cout<<"Yes";
            return 0;
        }
        if(s.find(a) != s.end()){
            cout<<"No";
            return 0;
        }
        s.insert(a);
    }
    return 0;
}