//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<vector>
#include<map>
#include<set>
#define INF 1000000007
#define LL long long
#define pb push_back
#define mp make_pair
#define X first
#define Y second
using namespace std;
int n,m,x,y;
LL l,r,ans;
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        cin>>l>>r;
        ans=l;
        for(LL i=0;i<63;i++)
        {
            if(l&(1LL<<i))continue;
            l=l|(1LL<<i);
            if(l<=r)ans=l;
            else break;
        }
        cout<<ans<<endl;
    }
    return 0;
}
