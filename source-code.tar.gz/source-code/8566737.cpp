//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<vector>
#include<map>
using namespace std;


int main()
{
    ios_base::sync_with_stdio(false);

    long long l,r;
    int n;
    cin>>n;
    while(n--)
    {
        cin>>l>>r;
        long long ans = 0;

        long long tmp = (l^r);
        bool flag = false;

        for(int i=63;i>=0;i--)
        {
            if(flag)
            {
                ans|=(1LL<<i);
            }
            else if(tmp&(1LL<<i))
            {
                flag = true;
                long long tmp2 = (1LL<<(i+1))-1LL;
                if((r&tmp2) == tmp2)
                {
                    ans |= tmp2;
                    break;
                }
            }
            else
            {
                ans |= (l&(1LL<<i));
            }
        }

        cout<<ans<<endl;
    }
}
