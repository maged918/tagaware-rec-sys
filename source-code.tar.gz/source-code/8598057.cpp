//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string.h>
#include <algorithm>
using namespace std;
double dp[1<<22];
char str[55][22];
long long live[1<<22];
int main()
{
     int n;
     while(scanf("%d",&n)==1){
         memset(live,0,sizeof(live));
         memset(dp,0,sizeof(dp));
         for(int i=0; i<n; ++i){
             scanf("%s",str[i]);
         }
         int m=strlen(str[0]);
         for(int i=0; i<n; ++i){

              for(int j=i+1; j<n; ++j )
                 {
                     int S=0;
                   for(int k=0; k<m; ++k)
                     if(str[i][k]==str[j][k])
                       S|=(1<<k);
                    live[S]|=(1LL<<i)|(1LL<<j);
                 }
         }
         for(int S = (1<<m)-1; S>0; --S){
             for(int i=0; i<m; ++i)
                if(S&(1<<i)) live[S^(1<<i)]|=live[S];
         }
         dp[0]=1;
         double ans=0;
         for(int S=0; S<1<<m; ++S){
               int num=0;
               for(int i=0; i<n; ++i)
                 if(live[S]&(1LL<<i)) num++;
               ans+=dp[S]*num;
               num=0;
               for(int i=0; i<m; ++i)
                 if(S&(1<<i)) num++;
               for(int i=0; i<m; ++i)
                 if( (S&(1<<i)) == 0 )
                  dp[ S|(1<<i) ]+= dp[S]/(m-num);
         }
         printf("%.15lf\n",ans/n);
     }
     return 0;
}
