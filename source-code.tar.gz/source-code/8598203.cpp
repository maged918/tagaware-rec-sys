//Language: GNU C++


#include <map>
#include <set>
#include <list>
#include <ctime>
#include <cmath>
#include <queue>
#include <stack>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <sstream>
#include <utility>
#include <iostream>
#include <algorithm>
#include <functional>
#define PI 3.1415926535
#define MOD 1000000007
#define INF 0x3F3F3F3F
#define MAX 110
#define ALL(x) x.begin(), x.end()
#define SIZE(x) (int)(x.size())
#define FOR(i, s, e) for (int i = int(s); i != int(e); i++)
#define FORIT(i,c) for (__typeof((c).begin()) i = (c).begin(); i != (c).end(); i++)
using namespace std;

typedef long long LL;
typedef long double LD;
typedef pair<int, int> PII;

template<class T> void renew_min(T &a, T b) {
	if (b < a)
		a = b;
}
template<class T> void renew_max(T &a, T b) {
	if (b > a)
		a = b;
}

int d[MAX][MAX];

int main() {
	int n;
	scanf("%d", &n);
	getchar();
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			int ch = getchar();
			if (ch == 'o') {
				d[i][j] = 1;
			}
		}
		getchar();
	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			int cnt = d[i - 1][j] + d[i][j - 1] + d[i + 1][j] + d[i][j + 1];
			if (cnt & 1) {
				puts("NO");
				return 0;
			}
		}
	}
	puts("YES");
	return 0;
}
