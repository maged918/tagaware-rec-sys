//Language: GNU C++


#include <iostream>
#include <cmath>
using namespace std;

int main(){
	int n, m, a, b;
	cin >> n >> m >> a >> b;
	int ans, ans2;
	ans2=n*a;
	ans = n/m*b + min(n%m*a, b);
	cout << min(ans, ans2);
	return 0;
}