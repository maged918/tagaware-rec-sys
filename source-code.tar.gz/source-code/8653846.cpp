//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <map>
#include <cmath>
#include <vector>
#include <queue>

#define FOR(i,a,b) for (int i = a; i <= b; i++)
#define DFOR(i,a,b) for (int i = a; i >= b; i--)
#define LL long long

using namespace std;

const int MAX = 111;

int a[MAX][MAX], b[MAX][MAX];
int c[MAX][MAX];
int m,n;

main()
{
    cin >> m >> n;
    FOR(i,1,m)
    FOR(j,1,n)
    cin >> a[i][j];
    memset(b, 255, sizeof(b));
    FOR(i,1,m)
    FOR(j,1,n)
    if (a[i][j] == 0)
    {
        b[i][j] = 0;
    }
    FOR(i,1,m)
    FOR(j,1,n)
    if (a[i][j] > 0)
    {
        int u = 1;
        FOR(t,1,m)
        if (t != i) u &= a[t][j];
        int v = 1;
        FOR(t,1,n)
        if (t != j) v &= a[i][t];
        if ((u | v) == 0)
        {
            cout << "NO" << endl;
            return 0;
        }
        b[i][j] = (u & v);
    }
    FOR(i,1,m)
    FOR(j,1,n)
    {
        c[i][j] = 0;
        FOR(t,1,m) c[i][j] |= b[t][j];
        FOR(t,1,n) c[i][j] |= b[i][t];
        if (c[i][j] != a[i][j])
        {
            cout << "NO" << endl;
            return 0;
        }
    }
    cout << "YES" << endl;
    FOR(i,1,m)
    {
        FOR(j,1,n) cout << b[i][j] << " ";
        cout << endl;
    }
}