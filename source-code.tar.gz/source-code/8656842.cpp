//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <algorithm>

using namespace std;

#define rep(i,j) REP((i), 0, (j))
#define REP(i,j,k) for(int i=(j);(i)<(k);++i)
#define BW(a,x,b) ((a)<=(x)&&(x)<=(b))
#define ALL(v) (v).begin(), (v).end()
#define LENGTHOF(x) (sizeof(x) / sizeof(*(x)))
#define AFILL(a, b) fill((int*)a, (int*)(a + LENGTHOF(a)), b)
#define SQ(x) ((x)*(x))
#define Mod(x, mod) (((x)+(mod)%(mod))
#define MP make_pair
#define PB push_back
#define F first
#define S second
#define INF 1 << 30
#define EPS 1e-10
#define MOD 1000000007

typedef pair<int, int> pi;
typedef pair<int, pi> pii;
typedef vector<int> vi;
typedef queue<int> qi;
typedef long long ll;

int N, p;
string str;

int main(){
  cin >> N >> p >> str; p--;
  int h = N/2;
  if(p >= N/2) p = N-p-1;
  int l = N, r = -1;
  int res = 0;
  for(int i = p; i >= 0; i--){
    if(str[i]==str[N-i-1]) continue;
    res += min(abs(str[i]-str[N-i-1]), 26-abs(str[i]-str[N-i-1]));
    //    cout << abs(str[i]-str[N-i-1]) << " " << 26-abs(str[i]-str[N-i-1]) << endl;
    l = i;
  }
  //  cout << res << endl;
  for(int i = p+1; i < N/2; i++){
    if(str[i]==str[N-i-1]) continue;
    res += min(abs(str[i]-str[N-i-1]), 26-abs(str[i]-str[N-i-1]));

    r = i;
  }

  //  cout << res << endl;
  if(l==N&&r==-1){
    //    res = 0;
  }else if(l==N){
    res += abs(r-p);
  }else if(r==-1){
    res += abs(p-l);
  }else{
    res += min(abs(r-p), abs(p-l))*2 + max(abs(r-p), abs(p-l));
  }

  cout << res << endl;
  return 0;
}
