//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
using namespace std;

int n,m;
int mat[111][111];
int sum1[111];
int sum2[111];
int ans[111][111];
int sum3[111];
int sum4[111];
int ans2[111][111];

int main()
{
    ios_base::sync_with_stdio(false);
    cin>>n>>m;

    for(int i=0; i<n; i++)
        for(int j=0; j<m; j++)
        {
            cin>>mat[i][j];
            sum1[i]+=mat[i][j];
            sum2[j]+=mat[i][j];
        }

    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            ans[i][j] = ((sum1[i]+sum2[j])==(n+m))?1:0;
            sum3[i]=max(sum3[i],ans[i][j]);
            sum4[j]=max(sum4[j],ans[i][j]);
        }
    }


    bool flag = true;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if(mat[i][j]!=(sum3[i]|sum4[j]))
            {
                flag = false;
                break;
            }
        }
        if(!flag) break;
    }

    if(!flag) cout<<"NO"<<endl;
    else
    {
        cout<<"YES"<<endl;
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
            {
                cout<<ans[i][j]<<" ";
            }
            cout<<endl;
        }
    }
}
