//Language: GNU C++


#include <bits/stdc++.h>
using namespace std ;

typedef long long ll; ///NOTES:int64


const double eps = 1e-11; ///NOTES:eps
const int dx[] = {1, 0, -1, 0};
const int dy[] = {0, 1, 0, -1};
const double pi = acos(-1.0); ///NOTES:pi


#define SZ(x)           (int)x.size()
#define ALL(x)          (x).begin(),(x).end()
#define ALLR(x)         (x).rbegin(),(x).rend()
#define PB( x )         push_back(x)

class
CubeWalking
{
public :

};


int main()
{
    ///freopen("input.txt" , "rt" , stdin);
    string text  , fr , ls;
    int n , p ;
    cin >> n >> p >>text ;

    fr = text.substr(0 , n/2 ) ;

    ///odd
    if(n%2)

        ls = text.substr(n/2+1 , n/2);
    ///even
    else
        ls = text.substr(n/2 , n/2);

    reverse( ALL(ls) );


    int mn = 0 ;
    int z = ('z'-'a')+1 ;


    ///check p in any part
    p = p-1 ;

    set<int>posToBeChanged ;
    set<int> ::iterator it ;

    for(int i=0 ; i< SZ(fr) ; i++)
    {
        if(fr[i] != ls[i])
        {
            mn+=min( abs( (int)fr[i] - (int)ls[i] )  , ( (int)min(fr[i],ls[i])+z-(int)max(fr[i],ls[i]) ) );
            if(p >= n/2)
            {
                 posToBeChanged.insert(n-1-i);
            }
           else
             posToBeChanged.insert(i);
        }
    }



    int mnTextChanged[2] = {0 , 0 };

    vector<int>perv , next ;
    for(it = posToBeChanged.begin() ; it !=posToBeChanged.end() ; it++)
    {

        if(*it > p) next.PB(*it);
        else if(*it < p) perv.PB(*it);

    }



    int counterOverText ;

    ///first case
     counterOverText = p ;
    for(int i=0 ; i<SZ(next) ; i++)
    {
        mnTextChanged[0] += abs(counterOverText - next[i]);
        counterOverText = next[i] ;
    }

    for(int i = SZ(perv)-1 ; i >= 0 ;i--)
    {
        mnTextChanged[0] += abs(counterOverText - perv[i]);
        counterOverText =  perv[i] ;
    }

     ///second case
     counterOverText = p ;
    for(int i = SZ(perv)-1 ; i >= 0 ;i--)
    {
        mnTextChanged[1] += abs(counterOverText - perv[i]);
        counterOverText =  perv[i] ;
    }

    for(int i=0 ; i<SZ(next) ; i++)
    {
        mnTextChanged[1] += abs(counterOverText - next[i]);
        counterOverText = next[i] ;
    }


    cout << min(  mnTextChanged[0] , mnTextChanged[1]) + mn << endl ;
    return 0;
}
