//Language: GNU C++0x


#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
int a[150][150];
int b[150][150];
int main()
{
    int sign=1;
    int m,n;
    scanf("%d%d",&n,&m);
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=m; j++)
        {
            scanf("%d",&a[i][j]);
            //printf("%d ",a[i][j]);
        }
        //printf("\n");
    }
    for(int i=1;i<=n;i++)
    for(int j=1;j<=m;j++)
    b[i][j]=1;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            if(a[i][j]==0)
            {
                for(int k=1;k<=m;k++)
                b[i][k]=0;
                for(int k=1;k<=n;k++)
                b[k][j]=0;
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            int temp=0;
            for(int k=1;k<=m;k++)
            temp=(temp|b[i][k]);
            for(int k=1;k<=n;k++)
            temp=(temp|b[k][j]);
           // printf("%d %d\n",i,j);
            if(temp!=a[i][j])
            sign=0;
        }
        if(sign==0)
        break;
    }
    if(sign==0)
    printf("NO\n");
    else
    {
        printf("YES\n");
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
            {
                printf("%d ",b[i][j]);
            }
            printf("\n");
        }
    }
    return 0;
}
