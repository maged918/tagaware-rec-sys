//Language: GNU C++0x


#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <queue>
#include <utility>
#include <deque>
#include <stack>
using namespace std;
typedef long long LL;
const int maxn = (int)(211111);
const int mod = (int)(1e9+7);
const int N = (int)(1e5+1);
typedef vector<int>VI;
typedef vector<VI> VII;
#define lson l,m,rt<<1
#define rson m+1,r,rt<<1|1
struct SetTree{
    int maxv[maxn<<2];
    void pushup(int rt){
        maxv[rt]=max(maxv[rt<<1],maxv[rt<<1|1]);
    }
    void clear(){
        memset(maxv,0,sizeof(maxv));
    }
   
    void update(int p,int v,int l,int r,int rt){
        if(l==r){
            maxv[rt]=v;
            return;
        }
        int m=(l+r)>>1;
        if(p<=m){
            update(p,v,lson);
        }else{
            update(p,v,rson);
        }
        pushup(rt);
    }
    int query_max(int L,int R,int l,int r,int rt){
        if(L<=l&&r<=R){
            return maxv[rt];
        }
        int t=0;
        int m=(l+r)>>1;
        if(L<=m){
            t=max(t,query_max(L,R,lson));
        }
        if(m<R){
            t=max(t,query_max(L,R,rson));
        }
        return t;
    }
}seg1,seg2;
int c[maxn];
int x[maxn];
int y[maxn];
int a[maxn];
int ans[maxn];
int len[maxn];
bool f[maxn];
int main()
{
    ios::sync_with_stdio(false);
    int n,i;
    cin>>n;
    for(i=1;i<=n;++i){
        int &t=a[i];
        cin>>t;
        x[i]=1;
        if(t>1){
            int p=seg1.query_max(1,t-1,1,N,1);
            x[i]=max(x[i],p+1);
        }
        seg1.update(t,x[i],1,N,1);
    }
    for(i=n;i>=1;--i){
        int t=a[i];
        y[i]=1;
        if(t<N){
            int p=seg2.query_max(t+1,N,1,N,1);
            y[i]=max(y[i],p+1);
        }
        seg2.update(t,y[i],1,N,1);
    }
    int k=0;
    for(i=1;i<=n;++i){
        len[i]=x[i]+y[i]-1;
        k=max(k,len[i]);
        ans[i]=3;
    }
    for(i=1;i<=n;++i){
        if(k==len[i]){
            c[x[i]]++;
        }
    }
    for(i=1;i<=n;++i){
        if(k>len[i]){
            ans[i]=1;
        }else if(c[x[i]]^1){
            ans[i]=2;
        }
        cout<<ans[i];
    }
    return 0;
}