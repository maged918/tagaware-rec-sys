//Language: GNU C++


#include <cstdio>

#include <cstring>
#include <cmath>
#include <map>
using namespace std;
map<long long int, int> MM;
inline void maxt(int& u, int v) { if (u < v) u = v; }
class seg {
    private:
        int *data, size;
    public:
        inline void clear() { memset(data + 1, 0, sizeof(int) * (size << 1)); }
        seg(int si) {
            size = 1 << (int)ceil(log(si + 4) / log(2));
            data = new int[size << 1]; --data;
        }
        
        inline void modify(int p, int v) {
            maxt(data[p += size + 1], v);
            while (p >>= 1) data[p] = max(data[p << 1], data[1 + (p << 1)]);
        }
        int qry(int l, int r) {
            l += size; r += size + 2;
            int ans = 0;
            while ((l ^ r) != 1) {
                if (~l & 1) maxt(ans, data[l ^ 1]);
                if (r & 1) maxt(ans, data[r ^ 1]);
                l >>= 1; r >>= 1;    
            }
            return ans;
        }
};
typedef int arr[100086];
arr d, fron, back;

inline long long magic(int i) { return (long long)fron[i] << 32 | back[i]; }
int main() {
    
    int n; scanf("%d", &n);
    seg tree(100086);
    for (int i = 0; i < n; ++i) scanf("%d", d + i);
    tree.clear();
    for (int i = 0; i < n; ++i) {
        maxt(fron[i], tree.qry(0, d[i] - 1) + 1);
        tree.modify(d[i], fron[i]);
    }
    tree.clear();
    for (int i = n - 1; i >= 0; --i) {
        maxt(back[i], tree.qry(d[i] + 1, 100085) + 1);
        tree.modify(d[i], back[i]); 
    }
    int leng(0);
    for (int i = 0; i < n; ++i) maxt(leng, fron[i]);
    for (int i = 0; i < n; ++i) 
        ++MM[magic(i)];    
    for (int i = 0; i < n; ++i) {
        if (fron[i] + back[i] <= leng) putchar('1');
        else if (MM[magic(i)] > 1) putchar('2');
        else putchar('3');
    }
    putchar('\n');
    return 0;
}
