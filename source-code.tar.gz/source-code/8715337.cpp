//Language: GNU C++


#include<iostream>
using namespace std;
int main(){
	for(int n,m;cin>>n>>m;){
		int a=n%2,b=n/2,c,d,z=-1;
		if(n<m);
		else if(n>=m){
			if(a==0){
				c=b%m;
				if(c==0)z=b;
				else{
					d=m-c;
					z=b+d;
				}
			}
			else{
				c=(b+1)%m;
				if(c==0)z=b+1;
				else{
					d=m-c;
					z=b+d+1;
				}
			}
		}
		cout<<z<<endl;
	}
}
     	  	 	 	 		 		 					   	