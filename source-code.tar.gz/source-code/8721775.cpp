//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

int ab(int n)
{
    if (n >= 0)
        return n;
    return -n;
}

int main() {
    int n, m;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++)
        cin >> a[i];
    cin >> m;
    int b[m];
    for (int i = 0; i < m; i++)
        cin >> b[i];
    int c1[n], c2[m];
    for (int i = 0; i < n; i++)
        c1[i] = 0;
    for (int i = 0; i < m; i++)
        c2[i] = 0;
    int c = 0;
    sort(a, a + n);
    sort(b, b + m);
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
        {
            //cout << a[i] << " " << b[j] << " " << c1[i] << " " << c2[j] << "\n";
            if (ab(a[i] - b[j]) <= 1 && !c1[i] && !c2[j])
            {
                c++;
                c1[i]++;
                c2[j]++;
                break;
            }
        }
    cout << c;
    return 0;
}
