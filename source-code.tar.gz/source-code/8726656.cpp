//Language: GNU C++


#include <bits/stdc++.h>


using namespace std;


string maxi, mini;


int main()
{
    int m, s, s2;
    
    cin>>m>>s2;
    
    if((m == 1) && (s2 == 0))
      cout<<0<<" "<<0<<endl;
    
    else if(s2 == 0)
      {
          cout<<-1<<" "<<-1<<endl;
      }
    
    else if(s2 > 9 * m)
      cout<<-1<<" "<<-1<<endl;
    
    else
      {
          s = s2;
          
          if(s - 1 <= 9 * (m - 1))
            {
                s--;
                mini += '1';
            }
          
          else
            {
                mini += char((s - (9 * (m - 1))) + '0');
                s -= (s - (9 * (m - 1)));
            }
          
          for(int i = 1; i < m; i++)
            {
                if(s <= 9 * (m - i - 1))
                  {
                      mini += '0';
                  }
                
                else
                  {
                      mini += char((s - (9 * (m - i - 1))) + '0');
                      s -= (s - (9 * (m - i - 1)));
                  }
            }
          
          cout<<mini<<" ";
          
          s = s2;
          
          if(s - 9 >= 0)
                  {
                      s -= 9;
                      maxi += '9';
                  }
                
                else
                  {
                      maxi += char(s + '0');
                      s -= s;
                  }
          
          for(int i = 1; i < m; i++)
            {
                if(s - 9 >= 0)
                  {
                      s -= 9;
                      maxi += '9';
                  }
                
                else
                  {
                      maxi += char(s + '0');
                      s -= s;
                  }
            }
          
          cout<<maxi<<"\n";
      }
    

    return 0;
} 
