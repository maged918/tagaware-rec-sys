//Language: GNU C++0x


#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>
#include <cstring>
#include <set>
#include <ctime>
#include <stack>
using namespace std;

#define inf 2147483647
#define eps 0.0000001
#define pi 3.1415926535897932
#define mod 1000000007
#define LL long long
#define ULL unsigned long long
#define LD long double
#define ULD unsigned long double

//	memset(array, value, sizeof(array));
//	cout<<fixed<<setprecision(3)<<"\nExecution time="<<clock()/1000.0<<endl;
//	freopen("input.txt","r",stdin);
//	freopen("output.txt","w",stdout);

int n, m, i, j, k, q, s, w, v, ans;
vector < int > a[3010];
int b[3010];

int main()
{
	cin >> n >> m;
	for(i = 1; i <= m; i++)
	{
		int x, y;
		cin >> x >> y;
		a[x].push_back(y);
	}
	for(i = 1; i <= n; i++)
	{
		memset(b, 0, sizeof(b));
		for(j = 0; j < a[i].size(); j++)
		{
			int from = a[i][j];
			for(k = 0; k < a[from].size(); k++)
				if(a[from][k]!=i)
					b[a[from][k]]++;
		}
		for(j = 0; j <= 3000; j++)
			ans += b[j] * (b[j] - 1) / 2;
	}
	cout << ans << endl;
	return 0;
}
				

		