//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<queue>
#include<set>
#include<map>
#include<cstring>
#define rep(i,n) for(int i=0;i<n;i++)
#define foru(i,l,r) for(int i=l;i<=r;i++)
#define ford(i,r,l) for(int i=r;i>=l;i--)
typedef long long ll;
using namespace std;

const int maxn=505;
int n,m,sm,a[maxn],C[5][maxn],dem1,dem2;
ll dp[2][maxn*3][maxn];
char s[maxn];

void khoitao(){
	C[2][2]=1;
	foru(i,3,maxn-3) C[2][i]=(i-1+C[2][i-1])%sm;
}

int main(){
//    freopen("test.inp","r",stdin);
    scanf("%d%d%d\n",&n,&m,&sm);
    khoitao();
//    cout<<C[2][maxn-3]<<endl;
    rep(i,n) a[i]=2;
    rep(i,m) {
		scanf("%s",s);
    	rep(j,n) if (s[j]=='1') a[j]--;
    }
    rep(i,n) {
		if (a[i]<0) {
			cout<<0;
			return 0;
		}
		if (a[i]==1) dem1++;
		if (a[i]==2) dem2++;
    }
    dp[m&1][dem1][dem2]=1;
    int dpt=0;
    int l2=n*2-m*2;
    foru(i,m+1,n) {
		l2-=2;
    	foru(j,0,dem1+2*dem2) {
			int l=(l2-j)/2;
			long long s=((j>1?dp[(i+1)&1][j-2][l+2]:0)*C[2][l+2]%sm+dp[(i+1)&1][j][l+1]*j*(l+1)%sm)%sm+dp[(i+1)&1][j+2][l]*C[2][j+2]%sm;
			dp[i&1][j][l]=s%sm;
//			cout<<i<<" "<<j<<" "<<dp[i&1][j][l]<<endl;
    	}
    }
//    cout<<dpt<<endl;
    cout<<dp[n&1][0][0]<<endl;
}
