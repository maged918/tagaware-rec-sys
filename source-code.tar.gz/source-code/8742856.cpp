//Language: GNU C++


#include "stdio.h"
#include <iostream>
#include <string.h>
#include <string>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
#include <sstream>
#include <math.h>
#include <ctime>

#define S(x) scanf("%d", &x)
#define For(i, x, y) for(int i = x; i < y; ++i)
#define Fill(a, x) memset(a, x, sizeof(a))

void dout() { printf("\n"); }

template <typename Head, typename... Tail>
void dout(Head H, Tail... T) {
  #ifndef ONLINE_JUDGE
  	std::cerr << H << ' ';
  	dout(T...);
  #endif
}

using namespace std;

int main() {
	#ifndef ONLINE_JUDGE
		freopen("_in.txt", "r", stdin);
		//freopen("out.txt", "w", stdout);
		double beg=clock();
	#endif
	
	int m, s; S(m); S(s);

	if(m == 1 && s == 0) {
		printf("0 0");
		return 0;
	}
	
	string min = "1", max = "1";

	For(i, 1, m) {min += "0"; max += "0";}
	if (1 > s) {
		printf("-1 -1");
		return 0;
	}
	
	int need = s - 1;
	for (int i = m-1; i >= 0; --i){
		int canadd = int('9') - int(min[i]);
		if (need < canadd) canadd = need;
		min[i] = char(int(min[i]) + canadd);
		need -= canadd;
			
		if (need == 0) break;
	}

	if (need > 0) {
		printf("-1 -1");
		return 0;
	}

	need = s - 1;
	for (int i = 0; i <= m; ++i){
		int canadd = int('9') - int(max[i]);
		if (need < canadd) canadd = need;
		max[i] = char(int(max[i]) + canadd);
		need -= canadd;
			
		if (need == 0) break;
	}

	printf("%s %s", min.c_str(), max.c_str());

	#ifndef ONLINE_JUDGE
		double end=clock();
		printf("\n*** Total time = %.3lf ***\n",(end-beg)/CLOCKS_PER_SEC);
	#endif
	
	return 0;
}