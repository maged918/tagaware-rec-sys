//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<map>
#include<vector>
#include<stack>
#include<queue>
using namespace std;
int u[3000][3000], p[3000];
long long num[3000];
int main()
{
	int n, m, a, b;
	long long tot = 0;
	memset(u, 0, sizeof(u));
	memset(p, 0, sizeof(p));

	scanf("%d%d", &n, &m);
	for (int i = 0; i < m; i++){
		scanf("%d%d", &a, &b);
		u[a - 1][p[a - 1]] = b - 1;
		p[a - 1]++;
	}
	for (int i = 0; i < n; i++){
		memset(num, 0, sizeof(num));
		for (int j = 0; j < p[i]; j++){
			for (int k = 0; k < p[u[i][j]]; k++){
				num[u[u[i][j]][k]]++;
			}
		}
		for (int j = 0; j < n; j++){
			if (i == j)continue;
			tot += (num[j] * (num[j] - 1)) / 2;
		}
	}
	printf("%I64d\n", tot);
	return 0;
}

                                                   