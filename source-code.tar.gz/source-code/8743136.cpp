//Language: GNU C++


#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>

using namespace std;

int n,m;

struct seg{
    int l,r,v;
    void eat(){scanf("%d%d%d", &l,&r,&v);}
}arr[100005];

struct node{
    int l,r,v;
    node(){}
    node(int l,int r, int v):l(l), r(r), v(v){}
    int mid(){return (l+r)>>1;}
}Tree[100005 << 2];

bool ss(seg a, seg b){
    return a.r - a.l < b.r - b.l || (a.r - a.l == b.r - b.l && a.l < b.l);
}

void build(int nl, int nr, int cur){
    Tree[cur].l = nl; Tree[cur].r = nr; Tree[cur].v = -1;
    if(nl == nr) return;
    build(nl, Tree[cur].mid(), 2*cur);
    build(Tree[cur].mid()+1, nr, 2*cur + 1);
}

int update(int nl,int nr, int cur, int c){
    int cv = c;
    if(Tree[cur].v != -1) cv |= Tree[cur].v;
    if(Tree[cur].l == nl && Tree[cur].r == nr){
        Tree[cur].v = cv;
        return cv;
    }
    if(Tree[cur].v != -1){
        if(Tree[2*cur].v == -1) Tree[2*cur].v = Tree[cur].v;
        else Tree[2*cur].v = Tree[2*cur].v | Tree[cur].v;
    
        if(Tree[2*cur+1].v == -1) Tree[2*cur+1].v = Tree[cur].v;
        else Tree[2*cur+1].v = Tree[2*cur+1].v | Tree[cur].v;
    }
    
    if(Tree[cur].mid() >= nr)  update(nl,nr, 2*cur, cv);
    else if(Tree[cur].mid() < nl) update(nl,nr,2*cur+1, cv);
    else{
         update(nl, Tree[cur].mid(), 2*cur, cv);
         update(Tree[cur].mid()+1, nr, 2*cur+1, cv);
    }
    int ls = Tree[2*cur].v,rs = Tree[2*cur+1].v, cn =Tree[cur].v;
    if(ls != -1 && rs != -1)Tree[cur].v = ls & rs;
    else{
        if(cn != -1 && ls != -1) Tree[cur].v = cn & ls;
        if(cn != -1 && rs != -1) Tree[cur].v = cn & rs;
    }
    return Tree[cur].v;
}

int verify(int nl,int nr, int cur, int c){ 
    int cv = (c == -1? Tree[cur].v : c);
    if(Tree[cur].v != -1) cv |= Tree[cur].v;
    
    if(Tree[cur].l == nl && Tree[cur].r == nr) return cv;

    if(Tree[cur].mid() >= nr) return verify(nl,nr, 2*cur, cv);
    else if(Tree[cur].mid() < nl) return verify(nl,nr,2*cur+1, cv);
    else return verify(nl, Tree[cur].mid(), 2*cur, cv) & verify(Tree[cur].mid()+1, nr, 2*cur+1, cv);
}

void query(int x, int cur, int c){ 
    int cv = (c == -1? Tree[cur].v : c);
    if(Tree[cur].v != -1) cv |= Tree[cur].v;
   
    if(Tree[cur].l == x && Tree[cur].r == x){
       printf("%d ", cv != -1? cv : 1);
       return;
    }
    if(x <= Tree[cur].mid()) query(x, 2*cur, cv);
    else query(x, 2*cur+1, cv);
}

int main()
{
    scanf("%d%d", &n,&m);
    for(int i=0; i<m;i++) arr[i].eat();
    sort(arr, arr + m , ss);
    build(1,n, 1);

    for(int i=1; i<m;i++) 
        if(arr[i].l == arr[i-1].l && arr[i].r == arr[i-1].r && arr[i].v != arr[i-1].v){ printf("NO\n"); return 0;} 
    for(int i=0; i<m;i++) update(arr[i].l, arr[i].r,1,arr[i].v);
  
    for(int i=0; i<m;i++) 
        if(verify(arr[i].l, arr[i].r, 1, -1) != arr[i].v){printf("NO\n"); return 0;}
    printf("YES\n");
    for(int i=1; i<=n;i++) query(i, 1, -1);
    return 0;
}       