//Language: MS C++


#include <stdio.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <memory.h>
#include <string.h>
#include <string>
#include <algorithm>
using namespace std;
int m,n;
int v[300005];
pair<int,int> dp[300005];
map<string,int> mp;
map<string,int>::iterator it;
char str[500005];
int C;
vector<vector<int> > g,gg;
int len[300005],R[300005];
pair<int,int> cmp[300005];
int comp[300005];
bool vis[300005];
int dfs=1,low[300005],idx[300005];
int scc;
vector<int> S;
void toL(){
    for(int i=0;str[i];++i)
        str[i]|=32;
}
void set(){
    int i;
    for(i=0;str[i];++i)
        R[C]+=(str[i]|32)=='r';
    len[C]=i;
}
int Idx(){
    it=mp.find(str);
    if(it!=mp.end())
        return it->second;
    set();
    g.resize(C+1);
    return mp[str]=C++;
}
void DFS(int u){
    idx[u]=low[u]=dfs++;
    vis[u]=true;
    S.push_back(u);
    for(int v,i=0;i<g[u].size();++i){
        v=g[u][i];
        if(idx[v]==0)
            DFS(v);
        if(vis[v])
            low[u]=min(low[u],low[v]);
    }
    if(low[u]==idx[u]){
        int v=0;
        cmp[scc]=make_pair(1<<29,1<<29);
        while(true){
            v=S.back();
            S.pop_back();
            vis[v]=false;
            comp[v]=scc;
            cmp[scc]=min(cmp[scc],make_pair(R[v],len[v]));
            if(v==u)
                break;
        }
        ++scc;
    }
}
pair<int,int> calc(int u){
    if(dp[u].first!=-1)
        return dp[u];
    dp[u]=cmp[u];
    for(int i=0;i<gg[u].size();++i)
        dp[u]=min(dp[u],calc(gg[u][i]));
    return dp[u];
}
int main()
{
    scanf("%d",&m);
    for(int i=0;i<m;++i){
        scanf("%s",str);
        toL();
        v[i]=Idx();
    }
    scanf("%d",&n);
    for(int a,b,i=0;i<n;++i){
        scanf("%s",str);
        toL();
        a=Idx();
        scanf("%s",str);
        toL();
        b=Idx();
        g[a].push_back(b);
    }
    for(int i=0;i<g.size();++i)
        if(idx[i]==0)
            DFS(i);
    gg.resize(scc);
    for(int i=0;i<g.size();++i)
        for(int j=0;j<g[i].size();++j)
            if(comp[i]!=comp[g[i][j]])
                gg[comp[i]].push_back(comp[g[i][j]]);
    memset(dp,-1,sizeof(dp));
    long long mnR=0,mnL=0;
    pair<int,int> ret;
    for(int i=0;i<m;++i){
        ret=calc(comp[v[i]]);
        mnR+=ret.first;
        mnL+=ret.second;
    }
    printf("%lld %lld\n",mnR,mnL);
    return 0;
}