//Language: GNU C++


#include<iostream>
#include<cstdio>
using namespace std;
const int MaxN = 500 + 5;
int n,m,mod,h[MaxN],tmp,tot[3];
long long f[MaxN<<1][MaxN];
char ch;
void read(int &num){ch=0;while(ch<'0'||ch>'9') ch=getchar();num=ch-'0';}
int main()
{
	scanf("%d%d%d",&n,&m,&mod);
	for(int i=1;i<=m;i++)
		for(int j=1;j<=n;j++)
		{
			read(tmp);
			if(tmp) h[j]++;
		}
	for(int i=1;i<=n;i++) tot[h[i]]++;
	f[tot[1]][tot[0]]=1;
	for(int j=tot[0];j>=0;j--)
		for(int i=tot[1]+tot[0];i>=0;i--)
		{
			if(i>=2) f[i-2][j]=(f[i-2][j]+f[i][j]*(i*(i-1))/2)%mod;
			if(j>=1) f[i][j-1]=(f[i][j-1]+f[i][j]*i*j)%mod;
			if(j>=2) f[i+2][j-2]=(f[i+2][j-2]+f[i][j]*(j*(j-1))/2)%mod;
		}
	cout<<f[0][0];
	return 0;
}