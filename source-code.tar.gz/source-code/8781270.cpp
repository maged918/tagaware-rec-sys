//Language: GNU C++


#include <iostream>
using namespace::std;
#define abs(x) (x<0)?(-x):(x)
long long int solve(long long int a)
{
	long long int temp,ans=0;	
	bool done=false;
	while(!done)
	{
	
		temp=a;
		while(temp)
		{
			if( ((abs(temp))-8)%10==0)
			{
				//cout << "temp=" << temp << endl;
				done=true;
				break;
			}
			else
				temp/=10;
		}
		ans++;
		a++;
	}
	return ans-1;
}

int main()
{
	long long int a,ans=0;	
	cin >> a;
	ans=solve(a);
	if(ans!=0)
	{
		cout << ans << endl;
		return 0;
	}
	else
	{
		//cout << "Debug";
		cout << solve(a+1)+1 << endl;
		return 0;
	}	
}
