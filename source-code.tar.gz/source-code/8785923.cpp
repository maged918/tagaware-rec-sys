//Language: GNU C++0x


#include <bits/stdc++.h>
#include <ext/hash_map>
#include <ext/hash_set>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#include <ext/pb_ds/priority_queue.hpp>
using namespace std;
using namespace __gnu_cxx;
using namespace __gnu_pbds;
#define XINF INT_MAX
#define INF 0x3F3F3F3F
#define MP(X,Y) make_pair(X,Y)
#define PB(X) push_back(X)
#define REP(X,N) for(int X=0;X<N;X++)
#define REP2(X,L,R) for(int X=L;X<=R;X++)
#define DEP(X,R,L) for(int X=R;X>=L;X--)
#define CLR(A,X) memset(A,X,sizeof(A))
#define IT iterator
#define RIT reverse_iterator
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> PII;
typedef vector<PII> VII;
typedef vector<int> VI;
typedef tree<int, null_type, greater<int>, rb_tree_tag, tree_order_statistics_node_update > rb_tree_set;
typedef tree<int, int, greater<int>, rb_tree_tag, tree_order_statistics_node_update > rb_tree;
#define PQ std::priority_queue
#define HEAP __gnu_pbds::priority_queue
#define X first
#define Y second
#define lson(X) ((X)<<1)
#define rson(X) ((X)<<1|1)

int main()
{
    ios::sync_with_stdio(false);
    int h1,a1,d1;
    int h2,a2,d2;
    ll x,y,z;
    cin>>h1>>a1>>d1;
    cin>>h2>>a2>>d2;
    cin>>x>>y>>z;
    ll val = 0;
    int ma = a1-d2;
    if(a1-d2<=0) {
        val+=(d2-a1+1)*y;
        ma=1;
    }
    ll ans=LLONG_MAX;
    REP2(d,0,max(0,a2-d1)) { // add defense
        REP(a,20000) { // add attack
            int dec = a2-d1<=0?0:a2-d1-d;
            int t = (h2+a+ma-1)/(a+ma);
            int hx = dec*t+1;
            //cout<<d<<' '<<a<<' '<<max(0,hx-h1)*x + a*y + d*z<<endl;
            ans=min(ans, max(0,hx-h1)*x + a*y + d*z);
        }
    }
    cout<<ans+val<<endl;
    return 0;
}

