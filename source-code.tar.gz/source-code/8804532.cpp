//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

int h[2],a[2],d[2];
int ch,ca,cd;

bool bisa(int hx,int ax,int dx){
    int kurang = max(0,ax-d[1]);
    if(kurang <= 0) return false;
    int hm = h[1];
    while(hx > 0 && hm > 0){
        hm -= kurang;
        hx -= max(0,a[1]-dx);
    }
//  printf("%d %d | %d %d | %d %d\n",hx,hm,ax,dx,a[1],d[1]);
    if(hx > 0 && hm <= 0) return true;
    return false;
}

int main() {
    for(int i = 0; i < 2; i++) scanf("%d%d%d",&h[i],&a[i],&d[i]);
    scanf("%d%d%d",&ch,&ca,&cd);
    
    int res = 2123123123;
    for(int i = h[0]; i <= 3000; i++){
        for(int j = a[0]; j <= 200; j++){
            for(int k = d[0]; k <= 100; k++){
                if(bisa(i,j,k)){
                    res = min(res,(i-h[0])*ch + (j-a[0])*ca + (k-d[0])*cd);
                }
            }
        }
    }
    printf("%d\n",res);
    return 0;
}