//Language: GNU C++0x


#include <iostream>
#include <unordered_map>
#include <algorithm>
#include <vector>
using namespace std;
const int N = 1000006;
int nn[N], pp[N];
int main(){
	int n;
	cin >> n;
	unordered_map<int,int> nodes;
	for(int i = 0; i < 1000006; i++) nn[i] = -1;
	for(int i = 0; i < 1000006; i++) pp[i] = -1;
	for(int i = 0, a, b; i < n; i++){
		cin >> a >> b;
		nodes[a]++;
		nodes[b]++;
		nn[a] = b;
		pp[b] = a;
	}
	int start = nn[0];//not 0
	vector<int> r1;
	while(start != 0 && start != -1){
		r1.push_back(start);
		start = nn[start];
	}
	int tail;
	bool odd;
	if(start == 0){//odd
		odd = true;
		for(auto x : nodes){
			if(x.second == 1 && nn[x.first] == -1){
				tail = x.first;
				break;
			}
		}
	}else{
		odd = false;
		tail = pp[0];
	}
	vector<int> r2;
	while(tail != -1){
		r2.push_back(tail);
		tail = pp[tail];
	}
	reverse(r2.begin(), r2.end());
	vector<int> res;
	if(odd){
		res.push_back(r2[0]);
		for(int i = 0; i < r1.size(); i++){
			res.push_back(r1[i]);
			res.push_back(r2[i+1]);
		}
	}else{
		for(int i = 0; i < r1.size(); i++){
			res.push_back(r2[i]);
			res.push_back(r1[i]);
		}
	}
	for(auto x : res)
		cout << x << " ";
	cout << endl;
	return 0;
}
