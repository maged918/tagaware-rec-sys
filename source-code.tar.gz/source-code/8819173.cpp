//Language: GNU C++0x


#include <cstdio>
#include <cmath>
#include <iostream>
#include <set>
#include <algorithm>
#include <vector>
#include <map>
#include <cassert>
#include <string>
#include <cstring>
#include <queue>

using namespace std;

#define rep(i,a,b) for(int i = a; i < b; i++)
#define S(x) scanf("%d",&x)
#define P(x) printf("%d\n",x)

typedef long long int LL;
const int N = 100001;

string s;
string p;
vector<string > ans;

int main() {
	int n;
	S(n);
	rep(i,0,n) {
		cin >> s;
		if(s.size() > p.size()) {
			p = s;
			rep(j,0,p.size()) if(p[j] == '?') {
				if(!j) p[j] = '1';
				else p[j] = '0';
			}
		} else if(p.size() == s.size()) {
			bool flag = 0;
			vector<int > x,y;
			rep(j,0,p.size()) {
				if(s[j] == '?') {
					if(flag) s[j] = '0';
					else s[j] = p[j];
					x.push_back(j);
				}
				if(s[j] != p[j] && !flag) {
					if(s[j] > p[j]) flag = 1;
					else {
						flag = 1;
						while(x.size() ) {
							int idx = x.back();
							if(s[idx] != '9') {
								s[idx] = s[idx]+1;
								rep(itr,0,y.size()) s[y[itr]] = '0';
								break;
							}
							y.push_back(idx);
							x.pop_back();
						}
						if(!x.size()) {
							printf("NO\n");
							return 0;
						}
					}
				}
			}
			if(!flag) {
				while(x.size() ) {
					int idx = x.back();
					if(s[idx] != '9') {
						s[idx] = s[idx]+1;
						rep(itr,0,y.size()) s[y[itr]] = '0';
						break;
					}
					y.push_back(idx);
					x.pop_back();
				}
				if(!x.size()) {
					printf("NO\n");
					return 0;
				}
			}
			p = s;
		} else {
			printf("NO\n");
			return 0;
		}
		ans.push_back(p);
	}
	printf("YES\n");
	rep(i,0,n) cout << ans[i] << endl;

	return 0;
}