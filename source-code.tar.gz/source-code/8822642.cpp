//Language: GNU C++0x


#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <deque>
#include <bitset>
#include <complex>
#include <functional>
#include <numeric>
#include <limits>
#include <utility>

#include <array>
#include <unordered_map>
#include <unordered_set>
#include <tuple>

using namespace std;

typedef long long ll;

const int MAX_N = 110000;

int n;
string a[MAX_N];

int main() {
  cin >> n;
  for (int i = 0; i < n; i++) {
    string s;
    cin >> s;
    for (int j = 0; j < 8 - (int)s.size(); j++) {
      a[i].push_back('0');
    }
    a[i].append(s);
  }
  string prv = "00000000";
  bool good = true;
  for (int i = 0; i < n; i++) {
    string res = "";
    for (int p = 0; p < 8; p++) {
      bool head = true;
      string t = a[i];
      for (int k = 0; k < p; k++) {
        if (t[k] == '?') {
          if (head && prv[k] == '0') {
            t[k] = '1';
          } else {
            t[k] = prv[k];
          }
        }
        if (t[k] != '0') head = false;
      }
      if (t[p] == '?') {
        if (prv[p] == '9') {
          t[p] = '9';
        } else {
          t[p] = prv[p] + 1;
        }
      }
      if (t[p] != '0') head = false;
      for (int k = p + 1; k < 8; k++) {
        if (t[k] == '?') {
          t[k] = (head ? '1' : '0');
        }
        if (t[k] != '0') head = false;
      }
      int x1 = atoi(prv.c_str()), x2 = atoi(t.c_str());
      if (x1 < x2) {
        if (res == "") {
          res = t;
        } else {
          int x3 = atoi(res.c_str());
          if (x2 < x3) {
            res = t;
          }
        }
      }
    }
    if (res == "") {
      good = false;
      break;
    } else {
      a[i] = res;
      prv = res;
    }
  }
  if (!good) {
    cout << "NO" << endl;
  } else {
    cout << "YES" << endl;
    for (int i = 0; i < n; i++) {
      int p = 0;
      while (a[i][p] == '0') p++;
      cout << a[i].substr(p) << endl;
    }
  }
}
