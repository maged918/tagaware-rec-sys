//Language: GNU C++


#include <iostream>
using namespace std;
int main()
{
    int n,x;
    int j=0, num=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<3;j++)
        {
            cin>>x;
            if(x==1)
                num++;
        }
        if(num>1)
            j++;
        num=0;

    }
    cout<<j<<endl;
    return 0;
}