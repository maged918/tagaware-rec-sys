//Language: GNU C++


#include <stdio.h>
#include <utility>
#include <queue>
#include <cmath>
#include <cstring>

#define  mp make_pair

using namespace std;

long long int n;

long long int us(long long int i, int k)
{
	if (k == 0)return 1;
	if (k == 1)return (i)%n;
	if (k == 2)return (i*i)%n;
	return (us(us(i, k / 2)%n, 2)*(k % 2 ? i : 1))%n;
}
int main()
{
	scanf("%d", &n);
	if (n < 3)
	{
		printf("YES\n");
		for (int i = 1; i <= n; i++)
		{
			printf("%d\n", i);
		}
		getchar(); getchar(); getchar(); getchar(); getchar(); getchar();
		return 0;
	}
	if (n == 4)
	{
		printf("YES\n1\n3\n2\n4");
		getchar(); getchar(); getchar(); getchar(); getchar(); getchar();
		return 0;
	}
	int aak = sqrt(n);
	for (int i = 2; i <= aak; i++)
	{
		if (n%i == 0)
		{
			printf("NO");
			getchar(); getchar(); getchar(); getchar(); getchar(); getchar();
			return 0;
		}
	}
	printf("YES\n1\n");
	for (int i = 2; i < n; i++)
	{
		long long int a = (us(i - 1, n - 2)*i) % n;
		printf("%I64d\n", a);
	}
	printf("%d\n",n);
	getchar(); getchar(); getchar(); getchar(); getchar(); getchar();
	return 0;
}