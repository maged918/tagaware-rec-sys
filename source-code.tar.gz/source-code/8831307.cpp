//Language: MS C++


#include<stdio.h>
int main()
{
    int a,b;
    int c,d;
    int ans=0;
    scanf("%d %d", &a,&b);
    scanf("%d %d", &c,&d);
    long long area = (long long)a*b;
    long long area2 = (long long)c*d;
    int p=0,q=0,r=0,s=0;
    while(area%2==0){area/=2;p++;}
    while(area2%2==0){area2/=2;q++;}
    while(area%3==0){area/=3;r++;}
    while(area2%3==0){area2/=3;s++;}
    if(area!=area2){printf("-1");return 0;}
    if(r>s){
        ans=r-s;
        p=p+r-s;
        while(a%3==0 && r>s){
            a/=3;
            a*=2;
            r--;
        }
        while(b%3==0 && r>s){
            b/=3;
            b*=2;
            r--;
        }
    }
    else if(s>r){
        ans=s-r;
        q=q+s-r;
        while(c%3==0 && s>r){
            c/=3;
            c*=2;
            s--;
        }
        while(d%3==0 && s>r){
            d/=3;
            d*=2;
            s--;
        }
    }
    if(p>q){
        ans+=(p-q);
        while(a%2==0 && p>q){
            a/=2;
            p--;
        }
        while(b%2==0 && p>q){
            b/=2;
            p--;
        }
    }
    if(q>p){
        ans+=(q-p);
        while(c%2==0 && q>p){
            c/=2;
            q--;
        }
        while(d%2==0 && q>p){
            d/=2;
            q--;
        }
    }
    printf("%d\n", ans);
    printf("%d %d\n%d %d", a,b,c,d);
    return 0;
}