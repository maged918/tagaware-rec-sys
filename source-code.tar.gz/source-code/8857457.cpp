//Language: GNU C++


#include<bits/stdc++.h>

#define rep(i,n) for(int i=0;i<(int)n;i++)
#define all(c) (c).begin(),(c).end()
#define mp make_pair
#define pb push_back
#define each(i,c) for(__typeof((c).begin()) i=(c).begin();i!=(c).end();i++)
#define dbg(x) cerr<<__LINE__<<": "<<#x<<" = "<<(x)<<endl

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef pair<int,int> pi;
const int inf = (int)1e9;
const double INF = 1e12, EPS = 1e-9;

ll N, K;
vi wav[2][10000000];

void gen(int pos, int sum, int last, bool inc){
	
	if(pos && !(pos == 1 && inc)){
		int id = inc ^ (pos % 2);
		wav[1 - id][sum % N].pb(sum);
	}
	if(pos == 7) return;
	
	rep(i, 10) if(inc && last < i || !inc && last > i){
		if(i == 0 && pos == 0) continue;
		gen(pos + 1, sum * 10 + i, i, !inc);
	}
}
inline bool iswav(ll x){
	int n = 0, d[20];
	for(; x; x /= 10) d[n++] = x % 10;
	for(int i = 1; i < n - 1; i++){
		if(!(d[i - 1] < d[i] && d[i] > d[i + 1]) && !(d[i - 1] > d[i] && d[i] < d[i + 1])) return 0;
	}
	if(n == 2 && d[0] == d[1]) return 0;
	return 1;
}

int main(){
	cin >> N >> K;
	gen(0, 0, -1, 1);
	gen(0, 0, 10, 0);
	
	if(N >= 1e7){
		for(ll x = N; x <= 1e14; x += N) if(iswav(x) && --K == 0){
			cout << x << endl;
			return 0;
		}
		cout << -1 << endl;
		return 0;
	}
	/*
	if(N * K > 1e14){
		cout << -1 << endl;
		return 0;
	}
	*/
	
	rep(k, 2) rep(i, 1e7){
		sort(all(wav[k][i]));
		rep(j, (int)wav[k][i].size() - 1) assert(wav[k][i][j] != wav[k][i][j + 1]);
	}
	
	if(K <= wav[0][0].size() + wav[1][0].size()){
		vi v(wav[0][0].size() + wav[1][0].size());
		merge(all(wav[0][0]), all(wav[1][0]), v.begin());
		cout << v[K - 1] << endl;
		return 0;
	}
	/*
	vector<ll> anss;
	each(i, wav[0][0]) anss.pb(*i);
	each(i, wav[1][0]) anss.pb(*i);
	*/
	K -= wav[0][0].size() + wav[1][0].size();
	
	for(int x = 1; x <= 1e7; x++) if(iswav(x)){
		
		int L = (x % 10 + 1) * (ll)1e6;
		int R = (x % 10) * (ll)1e6;
		
		int mod = (N - x * (ll)1e7 % N) % N;
		int sml = lower_bound(all(wav[1][mod]), R) - lower_bound(all(wav[1][mod]), (ll)1e6);
		int big = wav[0][mod].end() - lower_bound(all(wav[0][mod]), L);
		
		sml += lower_bound(all(wav[0][mod]), (ll)1e6) - lower_bound(all(wav[0][mod]), (ll)1e5);
		
		if(x >= 10){
			if(x / 10 % 10 < x % 10) big = 0;
			else sml = 0;
		}
		
		
		if(sml + big < K){
			K -= sml + big;
			continue;
		}
		
		
		#if 0
		cerr<<"1"<<endl;
		each(i, wav[1][mod]) cerr<<*i<<endl;
		
		cerr<<"0"<<endl;
		each(i, wav[0][mod]) cerr<<*i<<endl;
		#endif
		
		vi v;
		vi::iterator it, it2;
		
		if(sml){
			
			it = lower_bound(all(wav[1][mod]), (ll)1e6);
			for(; it < wav[1][mod].end() && *it < R; ) v.pb(*it++);
			
			it = lower_bound(all(wav[0][mod]), (ll)1e5);
			for(; it < wav[0][mod].end() && *it < 1e6; ) v.pb(*it++);
		}
		if(big){
			it = lower_bound(all(wav[0][mod]), L);
			for(; it != wav[0][mod].end(); ) v.pb(*it++);
		}
		/*
		cerr<<"test:"<<endl;
		rep(i, v.size()) cerr<<x*(ll)1e7 + v[i]<<endl;
		cerr<<endl;
		each(i, v) anss.pb(x*(ll)1e7 + *i);
		*/
		sort(all(v));
		//assert(v.size() == sml + big);
		//if((K -= sml + big) < 0) break;
		
		cout << x * (ll)1e7 + v[K - 1] << endl;
		return 0;
	}
	/*
	sort(all(anss));
	int cnt = 0;
	for(ll i = 1; ; i++){
		ll x = i * N;
		if(!iswav(x)) continue;
		cerr<<anss[cnt]<<" "<<x<<" "<<i<<endl;
		
		if(anss[cnt]!=x) break;
		cnt++;
		if(cnt >= 460) break;
	}
	dbg(anss.size());
	*/
	
	cout << -1 << endl;
	
	return 0;
}
