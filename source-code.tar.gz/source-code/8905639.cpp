//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<complex>
#include<iterator>
#include<set>
#include<bitset>
#include<map>
#include<stack>
#include<list>
#include<queue>
#include<deque>
using namespace std;
typedef vector<int> VI;
typedef long long LL;
#define FOR(x, b, e) for(int x = b; x <= (e); ++x)
#define FORD(x, b, e) for(int x = e; x >= (b); --x)
#define REP(x, n) for(int x = 0; x < (n); ++x)
#define VAR(v, n) __typeof(n) v = (n)
#define ALL(c) (c).begin(), (c).end()
#define SIZE(x) ((int)(x).size())
#define FOREACH(i, c) for(VAR(i, (c).begin()); i != (c).end(); ++i)
#define PB push_back
#define ST first
#define ND second
const int INF = 1000000001;
const double EPS = 10e-12;
typedef vector<VI> VVI;
typedef vector<LL> VLL;
typedef vector<double> VD;
typedef vector<string> VS;
typedef pair<int, int> PII;
typedef vector<PII> VPII;
#define PF push_front
#define MP make_pair

double dp[210][260][2][265];
int x, k, p;
int zero[300];

int calczero(int a){
    int ans = 0;
    while(!(a & 1) && a){
        ++ans;
        a >>= 1;
    }
    return ans;
}

int main(){
    cin >> x >> k >> p;
    cout.precision(10);
    REP(i, 260) zero[i] = calczero(i);
    double pmul = (1.0 * p)/100;
    double padd = 1 - pmul;
    double pr;
    string s = "";
    while(x){
        s = s + (char)( (x % 2) + '0');
        x /= 2;
    }
//    cout << s << endl;
    int mask = 0;
    FORD(i, 0, min(7, SIZE(s) - 1)) mask = mask * 2 + (s[i] - '0');
    int last, len;
    len = 0;
    last = '0';
    if(SIZE(s) > 8){
        last = s[8];
        len = 1;
    }
    for(int i = 9; i < SIZE(s) && s[i] == s[i - 1]; ++i) ++len;
    dp[0][mask][last - '0'][len] = 1;
    FOR(i, 0, k - 1)
        FOR(mask, 0, 255)
            FOR(len, 0, 250)
                FOR(last, 0, 1){
                    if((dp[i][mask][last][len]) < EPS) continue;
                    pr = dp[i][mask][last][len] * padd;
                    if(mask == 255){
                        if(len == 0) dp[i + 1][0][1][1] += pr;
                        else{
                            if(last == 0) dp[i + 1][0][1][1] += pr;
                            else dp[i + 1][0][0][len] += pr;
                        }
                    }
                    else{
                        dp[i + 1][mask + 1][last][len] += pr;
                    }
                    pr = dp[i][mask][last][len] * pmul;
                    int lastinmask = mask >> 7;
                    if(len == 0){
                        if(lastinmask == 1) dp[i + 1][(mask << 1)%256][1][1] += pr;
                        else dp[i + 1][(mask << 1)%256][0][0] += pr;
                    }
                    else{
                        if(lastinmask == last) dp[i + 1][(mask << 1)%256][last][len + 1] += pr;
                        else dp[i + 1][(mask << 1)%256][1 - last][1] += pr;
                    }
                }
    double ans = 0;
    FOR(mask, 0, 255)
        FOR(len, 0, 250)
            FOR(last, 0, 1){
                if(dp[k][mask][last][len] < EPS) continue;
                pr = dp[k][mask][last][len];
                if(mask == 0)
                    if(last == 0)
                        ans += pr * (8 + len);
                    else ans += pr * 8;
                else{
                    ans += pr * zero[mask];
                }
            }
    cout << ans;
    return 0;
}
