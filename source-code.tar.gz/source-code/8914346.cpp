//Language: GNU C++


//
//  main.cpp
//  codeforces1
//
//  Created by Mobin Yahyazade on 9/10/1393 AP.
//  Copyright (c) 1393 Mobin Yahyazade. All rights reserved.
//

#include <algorithm>
#include <iostream>
#include <iomanip>

using namespace std;


int main()
{
    int n, l;
    cin >> n >> l;
    int A[10000];
    for (int i = 0; i < n; i++) {
        cin >> A[i];
    }
    sort(A,A+n);
    
    int maxDistance = 0;
    for (int i = 1; i < n; i++) {
        if ((A[i] - A[i-1])> maxDistance) {
            maxDistance = A[i] - A[i-1];
        }
    }
    double maxBord =  ((double) maxDistance) / 2;
    if (A[0] != 0) {
        if ((A[0] - 0) > maxBord) {
            maxBord = (A[0] - 0);
        }
    }
    if (A[n-1] != l) {
        if ((l - A[n-1]) > maxBord) {
            maxBord = l - A[n-1];
        }
    }
    
    cout <<  fixed << setprecision(9) << maxBord << endl;
    
    return 0;
}

