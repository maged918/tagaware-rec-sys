//Language: GNU C++0x


/****************************************/
/*****          Desgard_Duan        *****/
/****************************************/
//#pragma comment(linker, "/STACK:102400000,102400000")
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sstream>
#include <algorithm>
#include <stack>
#include <map>
#include <queue>
#include <vector>
#include <set>
#include <functional>
#include <cmath>
#include <numeric>
#include <iomanip>

using namespace std;

const int maxn = 1e5 + 10;

long long A[maxn];
struct  Node {
    long long x, y;
    bool operator < (const Node &a)const {
        return x < a.x;
    }
} b[maxn];
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    long long n, r, avg;
    cin >> n >> r >> avg;
    long long t = avg * n;
    for (int i = 1; i <= n; ++ i) {
        cin >> A[i] >> b[i].x;
        b[i].y = i;
        t -= A[i];
    }
    long long ans = 0;
    sort(b + 1, b + 1 + n);
    if(t > 0) {
        for(int i = 1; i <= n; i++) {
            long long xxxx = r - A[b[i].y];
            if(!xxxx)continue;
            if(t <= xxxx) {
                ans += t * b[i].x;  t = 0;
                break;
            } else {
                ans += xxxx * b[i].x; t -= xxxx;
            }
        }
    }
    if(t > 0) ans = -1;
    cout << ans << endl;

    return 0;
}
