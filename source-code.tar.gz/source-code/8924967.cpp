//Language: GNU C++


#include <iostream>
#include <algorithm>

using namespace std;

int hits[2000005];

int main()
{
    long long n, x, y, i, j, t, p;

    cin>>n>>x>>y;

    long long sumx = x, sumy = y;
    for ( i=0; ; i++)
    {
        if ( sumx < sumy ) { hits[i]=1; sumx+=x;}
        else if ( sumx > sumy  )  { hits[i]=0; sumy+=y;}
        else { hits[i]=2; hits[i+1]=2; i+=2; break; }
    }

    string str[] = { "Vanya","Vova","Both" };
    for (long long k=0; k<n; k++)
    {
            cin>>t;

            p = (t-1)%i;

            cout<<str[ hits[ p ] ]<<endl;
    }
    return 0;
}
