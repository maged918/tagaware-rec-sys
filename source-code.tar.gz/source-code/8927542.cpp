//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <set>
#include <iostream>
#include <algorithm>
using namespace std;
const int maxn = 100010;
const int INF = 1e9+7;
typedef long long ll;
bool p[maxn];
int inv[maxn];
void init(){
	memset(p, false, sizeof(p));
	for(int i = 2; i * i <= maxn; i++) if(!p[i])
		for(int j = i * 2; j < maxn; j += i) p[j] = true;
}
int fast_mod(int a, int k, int mod)
{
	int ret = 1;
	while(k > 0)
	{
		if(k & 1) ret = 1ll * ret * a%mod;
		k >>= 1;
		a = 1ll * a * a % mod;
	}
	return ret;
}
int main()
{
	//freopen("in.txt", "r", stdin);
	init();
	int n;
	scanf("%d", &n);
	if(n == 1) printf("YES\n1\n");
	else if(n == 4) printf("YES\n1\n3\n2\n4\n");
	else if(p[n]) printf("NO\n");
	else {
		//cout<<"Now "<<endl;
		inv[1] = 1;
		for(int i = 2; i <= n - 1; i++)
			inv[i] = fast_mod(i, n-2, n);
		printf("YES\n1\n");
		for(int i = 2; i <= n - 1; i++)
			printf("%d\n", 1ll * i * inv[i-1] % n);
		printf("%d\n", n);
	}
	//system("pause");
	return 0;
}
