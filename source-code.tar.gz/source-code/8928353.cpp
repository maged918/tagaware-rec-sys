//Language: GNU C++


#include <cstdio>
#include <cstring>

int a[100005];
char s[15];

int get_max(char *s)
{
    int ans = 0;
    for(int i = 0; i < strlen(s); i++)
    {
        if(s[i] != '?') 
            ans = ans * 10 + s[i] - 48;
        else 
            ans = ans * 10 + 9;
    }
    return ans;
}

int main()
{
    int n, cur = 0;
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
    {
        scanf("%s", s);
        if(get_max(s) <= cur)
        {
            printf("NO\n");
            return 0;
        }
        for(int j = 0; j < strlen(s); j++)
        {
            if(s[j] == '?')
            {
                for(int k = 0; k < 10; k++)
                {
                    if(j == 0 && k == 0) 
                        continue;
                    s[j] = k + 48;
                    if(get_max(s) > cur)
                        break;
                }
            }
        }
        a[i] = get_max(s);
        cur = a[i];
    }
    printf("YES\n");
    for(int i = 0; i < n; i++)
        printf("%d\n", a[i]);
}
  	  		 				    	 		  	