//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
long long a[1000006],b[1000006];
int main()
{
    long long n,m,dx,dy,i,x,y;
    cin>>n>>m>>dx>>dy;
    x=n-dx;
    while(x!=0)
    {
        b[x]=b[(x+dx)%n]+1;
        x=(x-dx+n)%n;
    }
    for(i=0;i<m;i++)
    {
        cin>>x>>y;
        a[(b[x]*dy+y)%n]++;
    }
    x=y=0;
    for(i=0;i<n;i++)
        if(a[y]<a[i])y=i;
    cout<<x<<" "<<y<<endl;
}
