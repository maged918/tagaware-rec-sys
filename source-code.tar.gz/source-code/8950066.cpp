//Language: GNU C++


//Author: Utkarsh $axena
#include<bits/stdc++.h>
#include<iostream>
using namespace std;
//miller rabin primality 7 set for 64 bit int {2, 325, 9375, 28178, 450775, 9780504, 1795265022}
#define abs(x) ((x)>0?(x):-(x))
#define M 1000000007
#define lld signed long long int
#define pp pop_back()
#define ps(x) push_back(x)
#define mpa make_pair
#define PII pair<int,int>
#define scan(x) scanf("%d",&x)
#define print(x) printf("%d\n",x)
#define scanll(x) scanf("%lld",&x)
#define printll(x) printf("%lld\n",x)
//vector<int> g[2*100000+5];int visited[2*100000+5];
int n,d[1000+5],p[1000+5],to[1002];
double cc,dp[1002],cost[1002][1002];
bool check(double ans)
{
    dp[n]=-ans*p[n];
    for(int i=n-1;i>=0;i--)
    {
        cc=1e10;
        for(int j=i+1;j<=n;++j)
        {
            if(cc>dp[j]+cost[i][j]-ans*p[i])
            {
                to[i]=j;
                cc=dp[j]+cost[i][j]-ans*p[i];
            }
        }
        dp[i]=cc;
    }
    if(dp[0]<=0)return 1;
    return 0;
}
int main()
{
    int l1;
    cin>>n>>l1;
    for(int i=1;i<=n;++i)
    {
        cin>>d[i]>>p[i];
    }
    for(int i=0;i<=n;++i)for(int j=0;j<=n;++j)cost[i][j]=sqrt(abs(l1-abs(d[i]-d[j])));
    int count=0;
    double l=0,r=1000000000000000000,m;
    while(r-l>= 1e-12)
    {
        m=(l+r)/2.0;
        if(check(m))r=m;
        else l=m;
    }
    int i=0;
    while(i!=n)
    {
        i=to[i];
        cout<<i<<' ';
    }
}
