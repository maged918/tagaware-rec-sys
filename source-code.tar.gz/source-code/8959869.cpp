//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;

int n, n1, n2;
int an1[200010], an2[200010];
long long sum1, sum2;

int main()
{
    scanf("%d",&n);
    n1 = 0, n2 = 0;
    int last;
    sum1 = sum2 = 0;
    int tp;
    for(int i = 0; i < n; i++)
    {
        scanf("%d",&tp);
        if(tp > 0)
        {
            sum1 += tp;
            an1[n1++] = tp;
            last = 1;
        }
        else
        {
            sum2 += (-tp);
            an2[n2++] = (-tp);
            last = 2;
        }
    }
    if(sum1 == sum2)
    {
        int i;
        for(i = 0; i < min(n1,n2); i++)
        {
            if(an1[i] > an2[i])
            {
                printf("first\n");
                break;
            }
            else if(an1[i] < an2[i])
            {
                printf("second\n");
                break;
            }
        }
        if(i == min(n1,n2))
        {
            if(last == 1) printf("first\n");
            else printf("second\n");
        }
    }
    else if(sum1 > sum2) printf("first\n");
    else printf("second\n");
    return 0;
}
