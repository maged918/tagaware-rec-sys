//Language: GNU C++0x


#include <iostream>
#include <unordered_map>
using namespace std;

typedef long long ll;
typedef pair<int, int> pii;

unordered_map<ll, int> cnt;

int main ()
{
    //ios::sync_with_stdio(false);

    int n, m; ll dx, dy;
    cin >> n >> m >> dx >> dy;

    int mx = 0; pii ans(0, 0);
    for (int i = 0; i < m; i ++)
    {
        ll x, y; cin >> x >> y;
        ll cur = x * dy - y * dx;
        cur = (cur % n + n) % n, cnt[cur] ++;
        if (cnt[cur] > mx)
        {
            mx = cnt[cur];
            ans = pii(x, y);
        }
    }
    cout << ans.first << ' ' << ans.second << endl;
    return 0;
}