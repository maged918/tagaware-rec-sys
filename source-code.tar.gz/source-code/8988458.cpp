//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <set>
#include <cmath>
#include <cstring>
#include <fstream>
#include <queue>
#include <ctime>
#include <stack>
#include <vector>
#define LL long long
#define INF 0x3f3f3f3f

using namespace std;

LL t,a,b,cnt,p;
LL ak[101],tot;

int main()
{
        cin>>t>>a>>b;
        if(t==a&&a==b)
        {
                if(t==1) cout<<"inf";
                else cout<<"2";
        }
        else if(a==b) cout<<"1";
        else
        {
                if(a==1) { cout<<"0"; return 0; }
                if(t==1)
                {
                        p=1;
                        while(p<b)
                        {
                                p*=a;
                                if(p==b) { cout<<"1"; return 0; }
                        }
                }
                memset(ak,0,sizeof(ak));
                tot=0; ak[tot]=b;
                while(ak[tot]/a)
                {
                        ak[tot+1]=ak[tot]/a;
                        ak[tot]%=a;
                        tot++;
                }
                cnt=0;p=1;
                for(int i=0;i<70;i++)
                {
                        if(ak[i]) cnt=cnt+ak[i]*p;
                        p*=t;
                }
                //cout<<a<<" "<<cnt;
                //for(int i=0;i<100;i++) cout<<ak[i]<<" ";
                if(cnt==a) cout<<"1";
                else cout<<"0";
        }
        return 0;
}

			 		  		   		 			 		   		 			