//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
int main()
{
    int i,j=0,k=0,l=0,h=0,n;
    char s[222];
    scanf("%d",&n);
    for(i=0;i<=n;i++)
    {
        scanf("%c",&s[i]);
    }
    for(i=1;i<=n;i++)
    {
        if(s[i]=='x')
        k++;
        else if(s[i]=='X')
        l++;
    }
    if(k==l)
    {
        printf("0\n");
        for(i=1;i<=n;i++)
        printf("%c",s[i]);
    }
    else if(k/2>l/2)
    {
        printf("%d\n",k/2-l/2);
        for(i=1;i<=n;i++)
        {
            if(s[i]=='x'&&h<k/2-l/2)
            {
                printf("X");
                h++;
            }
            else
            {
                printf("%c",s[i]);
            }
        }

    }
    else
    {
        printf("%d\n",l/2-k/2);
        for(i=1;i<=n;i++)
        {
            if(s[i]=='X'&&j<l/2-k/2)
            {
                printf("x");
                j++;
            }
            else
            {
                printf("%c",s[i]);
            }
        }
    }
}
