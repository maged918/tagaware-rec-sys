//Language: GNU C++


#include <iostream>
#include <algorithm>
using namespace std;

const int MAXn = 1e5;
struct Triple
{
	int ind, row, col;
	Triple() {}
	Triple(int ind, int row, int col):ind(ind),row(row),col(col) {}
	bool operator<(Triple t) const
	{
		if(row != t.row)
			return row < t.row;
		else if(col != t.col)
			return col < t.col;
		else
			return ind < t.ind;
	}
};
typedef pair<int,int> pii;
int n, m;
pii q[MAXn];
Triple tmp[MAXn];
int sol[MAXn];
int ans[9];

int main()
{
	ios::sync_with_stdio(false);
	cin >> m >> n;
	for(int i = 0; i < n; i++)
	{
		cin >> q[i].first >> q[i].second;
	}
	for(int i = 0; i < n; i++)
	{
		tmp[i].ind = i;
		tmp[i].row = q[i].first;
		tmp[i].col = q[i].second;
	}
	sort(tmp, tmp + n);
	for(int i = 0; i < n; i++)
	{
		if(i != 0 && tmp[i-1].row == tmp[i].row)
			sol[tmp[i].ind]++;
		if(i != n-1 && tmp[i+1].row == tmp[i].row)
			sol[tmp[i].ind]++;
	}
	for(int i = 0; i < n; i++)
	{
		tmp[i].ind = i;
		tmp[i].row = q[i].second;
		tmp[i].col = q[i].first;
	}
	sort(tmp, tmp + n);
	for(int i = 0; i < n; i++)
	{
		if(i != 0 && tmp[i-1].row == tmp[i].row)
			sol[tmp[i].ind]++;
		if(i != n-1 && tmp[i+1].row == tmp[i].row)
			sol[tmp[i].ind]++;
	}
	for(int i = 0; i < n; i++)
	{
		tmp[i].ind = i;
		tmp[i].row = q[i].second+q[i].first;
		tmp[i].col = q[i].first;
	}
	sort(tmp, tmp + n);
	for(int i = 0; i < n; i++)
	{
		if(i != 0 && tmp[i-1].row == tmp[i].row)
			sol[tmp[i].ind]++;
		if(i != n-1 && tmp[i+1].row == tmp[i].row)
			sol[tmp[i].ind]++;
	}
	for(int i = 0; i < n; i++)
	{
		tmp[i].ind = i;
		tmp[i].row = q[i].second-q[i].first;
		tmp[i].col = q[i].first;
	}
	sort(tmp, tmp + n);
	for(int i = 0; i < n; i++)
	{
		if(i != 0 && tmp[i-1].row == tmp[i].row)
			sol[tmp[i].ind]++;
		if(i != n-1 && tmp[i+1].row == tmp[i].row)
			sol[tmp[i].ind]++;
	}
	for(int i = 0; i < n; i++)
		 ans[sol[i]]++;
	for(int i = 0; i <= 8; i++)
		cout << ans[i] << ((i==8)?"\n":" ");
	//cout << endl;
	return 0;
}
