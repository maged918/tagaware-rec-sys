//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstdlib>

using namespace std;

#define F first
#define S second

int a[1000100], b[1000100], n, fu=0;
int ans[300000], x[300000], y[300000];

void f(int v){
    //cout << v << endl;
    b[v] = -1;
    int j;
    for (int i=fu; i<=n; i++)
    if (ans[i] == 0){
        j = i;
        fu = 1;
        break;
    }
    //cout << fu << endl;
    ans[j] = v;
    while (a[v] != -1){
        j += 2;
        ans[j] = a[v];
        v = a[v];
    }
}

int main(){
    //freopen ("input.txt", "r", stdin);
    //freopen ("output.txt", "w", stdout);
    cin >> n;
    for (int i=0; i<=1000000; i++)
        a[i] = -1;
    for (int i=0; i<n; i++){
        cin >> x[i] >> y[i];
        if (y[i] == 0) {
                if (b[x[i]] != -1) b[x[i]] = 1;
                continue;
        }
        a[x[i]] = y[i];
        if (b[x[i]] != -1) b[x[i]] = 1;
        b[y[i]] = -1;
    }
    for (int i=0; i<=1000000; i++)
        if (b[i] == 1) f(i);
    for (int i=1; i<=n; i++)
        cout << ans[i] << ' ';

    return 0;
}
