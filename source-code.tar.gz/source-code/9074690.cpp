//Language: GNU C++


#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <set>
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>
#include <memory.h>
#include <string>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <cassert>

using namespace std;

typedef long long LL;
typedef pair<LL,LL> PLL;
typedef pair<int,int> PII;

#define MP make_pair
#define PB push_back
#define FF first
#define SS second

#define MOD 1000000007
#define INF 2000000000

int n; LL s;

const int MAXF = 25;
LL f[MAXF], inv[MAXF];

LL comb(LL a, LL b) {
    LL res = 1LL; if (a == 0) return res;
    
    for (int i = 0; i < b; i++) {
        res = (res * ((a - i) % MOD)) % MOD;
    }

    for (int i = 1; i <= b; i++) {
        res = (res * inv[i]) % MOD;
    }

    return res;
}

int main() {
    cin >> n >> s;

    inv[1] = 1;

    for (int i = 2; i < MAXF; i++) {
        inv[i] = (MOD - (MOD/i) * inv[ MOD % i ] % MOD) % MOD;
    }

    for (int i = 0; i < n; i++) {
        cin >> f[i];
    }

    vector<PLL> poly; poly.PB(MP(0, 1));

    for (int i = 0; i < n; i++) {
        int psz = poly.size();

        for (int j = 0; j < psz; j++) {
            poly.PB(MP(poly[j].FF + f[i] + 1, -poly[j].SS));
        }
    }

    LL res = 0LL;

    for (int i = 0; i < poly.size(); i++) {
        //cout << poly[i].SS << " * x ^ " << poly[i].FF << endl;
        
        if (poly[i].FF <= s) {
            LL curr = ((poly[i].SS * comb(s - poly[i].FF + n - 1, n - 1)) % MOD + MOD) % MOD;
            res = (res + curr) % MOD;
        }
    }

    cout << res << endl;
    return 0;
}
