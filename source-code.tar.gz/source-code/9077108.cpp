//Language: GNU C++0x


#include <iostream>
#include <cmath>

using namespace std;

int main()
{
    int x,y;
    float sumx=0,sumy=0;
    int n;
    for(int i=0;i<3;i++)
    {
        cin>>x;
        sumx=sumx+x;
    }
    sumx=ceil(sumx/5);
    for(int i=0;i<3;i++)
    {
        cin>>y;
        sumy=sumy+y;
    }
    cin>>n;
    sumy=ceil(sumy/10);
    n=n-sumx;
    n=n-sumy;
    if(n<0){cout<<"NO";}
    else{cout<<"YES";}
    return 0;
}