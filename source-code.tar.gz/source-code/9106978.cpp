//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <algorithm>
using namespace std;
#define dprint(v) cerr << #v"=" << v << endl //;)
#define forr(i,a,b) for(int i=(a); i<(b); i++)
#define forn(i,n) forr(i,0,n)
#define dforn(i,n) for(int i=n-1; i>=0; i--)
#define forall(it,v) for(typeof(v.begin()) it=v.begin();it!=v.end();++it)
#define sz(c) ((int)c.size())
#define zero(v) memset(v, 0, sizeof(v))
#define fst first
#define snd second
#define mkp make_pair
#define pb push_back
typedef long long ll;
typedef pair<int,int> ii;


int main() {
	//~ freopen("b.in", "r", stdin);
	ll a,b;
	while(cin >> a >> b){
		ll d = abs(b-a);
		if (d==0) cout << "infinity" << endl; else {
			int s =0;
			for( ll i = 1 ; i*i<=d ; i++) {
				if (d%i==0) {
					if (a%i==b) s++;
					if (i*i<d && a%(d/i)==b) s++;
				}
			}
			cout << s << endl;
		}
	}
    return 0;
}
