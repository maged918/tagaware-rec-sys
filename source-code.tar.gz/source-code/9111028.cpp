//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cmath>
#include <string>
#include <cstring>
#include <set>
#include <queue>
#include <stack>
#include <deque>
#include <map>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <algorithm>
#define pb push_back
#define fname ""
#define ll long long
#define s second
#define f first
#define mp make_pair

using namespace std;

int a, b;

int main() { 
    #ifndef ONLINE_JUDGE
    freopen(fname"in", "r", stdin);
    freopen(fname"out", "w", stdout);
    #endif
    cin >> a >> b;
    a -= b;
    if (a == 0) {
        cout << "infinity";
        return 0;
    }
    int ans = 0;
    for (int i = 1; i * i <= a; i++) {
        if (a % i == 0) {
            if (i > b) ++ans;
            if (a/i != i && a/i > b) ++ans; 
        }
    }
    cout << ans;
    return 0;
}
    