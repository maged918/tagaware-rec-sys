//Language: MS C++


/////////////////////////////
//Just Smile, My Friend ^_^//
//By PloadyFree//////////////
//PloadyFree@gmail.com///////
/////////////////////////////

#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <iterator>
#include <set>
#include <cmath>
#include <ctime>
#include <stack>
#include <array>

using namespace std;
typedef unsigned long long ull;
typedef long long ll;
#define all(a)  a.begin(), a.end()
#define rall(a) a.rbegin(), a.rend()
#define Pause   cout << "\n\n"; system("pause");

void FAIL()
{
    cout << -1;
    //  Pause;
    exit(0);
}

void showRes(vector<int>&vi)
{
    for (int i = 0; i < vi.size(); i++)
        cout << vi[i] << endl;
}

void solve()
{
    string s;
    cin >> s;

    int cntOtkr(0),
        cnt = count(all(s), '#'),
        found(0);
    vector<int> res;

    int zakrSkobSprava(0);

    int num = s.size() - 1;

    while (s[num] != '#')
    {
        if (s[num] == '(') zakrSkobSprava--;
        else zakrSkobSprava++;
        num--;
        if (zakrSkobSprava < 0)
            FAIL();
    }

    if (zakrSkobSprava < 0)
        FAIL();

    int curnum(1);

    for (int i = 0; i < s.size(); i++)
    {
        switch (s[i])
        {
        case '(':
            cntOtkr++;
            break;

        case ')':
            cntOtkr--;
            if (cntOtkr < 0)
                FAIL();
            break;

        case '#':
            if (cntOtkr == 0)
                FAIL();
            else
                if (curnum != cnt)
                {
                    cntOtkr--;
                    res.push_back(1);
                    curnum++;
                }
                else
                {
                    if (cntOtkr <= zakrSkobSprava)
                        FAIL();
                    else
                    {
                        res.push_back(cntOtkr - zakrSkobSprava);
                        showRes(res);
                        return;
                    }
                }

        }
    }

}

int main()
{
    solve();
    //  Pause;
    return 0;
}