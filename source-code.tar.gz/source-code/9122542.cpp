//Language: GNU C++


#include <iostream>
#include <cstdio>
using namespace std;

int dp[2][512];
int col[512];

int main () {
    #ifdef ACMTUYO
        freopen("489f.in","r",stdin);
    #endif
    int n, m, mod;
    cin >> n >> m >> mod;
    
    // lectura de input
    for( int i = 0; i < n; i++ )
        col[i] = 2;
    
    char c;
    for( int i = 0; i < m; i++ ) {
        for( int j = 0; j < n; j++ ) {
            cin >> c;
            if( c == '1' )
                col[j]--;
        }
    }
    
    int col0 = 0, col1 = 0;
    for( int i = 0; i < n; i++ ) {
        if( col[i] == 0 )
            col0++;
        if( col[i] == 1 )
            col1++;
    }
    
    for( int c0 = 0; c0 <= n; c0++ )
		dp[m%2][c0] = 0LL;
    dp[m%2][col0] = 1LL;
    
    for( int f = m+1; f <= n; f++ ){
        for( int c0 = 0; c0 <= n; c0++ ) {
            int c1 = 2*f - 2*c0;
			long long aux = 0;
			dp[f%2][c0] = 0;
			int c2 = n-c0-c1;
			
			// tomo un 0 y un 1 (que eran un 1 y un 2)
			if( c0 >= 1 && c1 >= 1 ) {
				aux = ((long long) dp[(f-1)%2][c0-1])*c1*(c2+1);
				dp[f%2][c0] = aux%mod;
			}
			
			// tomo dos 1's (que eran dos 2)
			if( c1 >= 2 ) {
				aux = dp[(f-1)%2][c0];
				aux *= ((c2+2) * (c2+1))/2LL;
				aux %= mod;
				dp[f%2][c0] += aux;
				dp[f%2][c0] %= mod; 
			}
			
			// tomo dos 0's (que eran dos 1's)
			if( c0 >= 2 ) {
				aux = dp[(f-1)%2][c0-2];
				aux *= ((c1+2) * (c1+1))/2LL;
				aux %= mod;
				dp[f%2][c0] += aux;
				dp[f%2][c0] %= mod;
			}
        }
    }
    
    cout << dp[n%2][n]%mod << endl;
}
