//Language: GNU C++


#include <iostream>
#include <string>
#include <vector>
using namespace std;
int f[100005];
void kmp(string p,string t) {
	int n=p.size();
	vector<int> next(n+1,0);
	for(int i=1;i<n;i++) {
		int j=i;
		while(j>0) {
			j=next[j];
			if(p[j]==p[i]) {
				next[i+1]=j+1;
				break;
			}
		}
	}
	int m=t.size();
	for(int i=0,j=0;i<m;i++) {
		if(j<n&&t[i]==p[j]) {
			j++;
		}
		else {
			while(j>0) {
				j=next[j];
				if(t[i]==p[j]) {
					j++;break;
				}
			}
		}
		if(j==n) f[i+1]=1;
	}
}
typedef long long ll;
ll q1[100005];
ll q2[100005];
ll a[100005];
ll ans;
const ll mod=(ll)1e9+7;

int main() {
	string t,p;
	cin>>t>>p;
	int n=t.size();
	int m=p.size();
	kmp(p,t);
	for(int i=1;i<=n;i++) {
		if(!f[i]) a[i]=a[i-1];
		else {
			a[i]=(q2[i-m]+i-m+1)%mod;
		}
		q1[i]=(q1[i]+q1[i-1]+a[i])%mod;
		q2[i]=(q2[i]+q2[i-1]+q1[i])%mod;
	}
	for(int i=1;i<=n;i++) ans=(ans+a[i])%mod;
	cout<<ans<<endl;
	return 0;
}