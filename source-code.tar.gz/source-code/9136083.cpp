//Language: GNU C++


#include <iostream>
#include <iomanip>
#include <algorithm>
#include <vector>
using namespace std;
const int maxn=100005;
const int maxq=5002;
int a[maxn];
double p[maxq][maxq<<1];
struct seg {
    int l,r;
    double ppp;
    seg(int l,int r,double ppp):l(l),r(r),ppp(ppp) {}
    bool operator <(const seg& rhs) const {
        if(l!=rhs.l) return l<rhs.l;
        else return r>rhs.r;
    }
};
vector<seg> S;
int n,q;
int _max;
int solve(int u) {
    int tmp=-1;
    int l=S[u].l,r=S[u].r;
    double pp=S[u].ppp;
    for(int i=l;i<=r;i++) tmp=max(tmp,a[i]);
    for(int i=max(-1,tmp-_max+q);i>=0;i--) p[u][i]=1.0;
    int v=u+1;
    vector<int> idx;
    idx.push_back(u);
    while(v<q&&S[v].l<=S[u].r) {
        idx.push_back(v);
        tmp=solve(v);
        v=tmp;
    }
    int sz=idx.size();
    for(int i=0;i<=2*q;i++) {
        double res=1.0;
        for(int j=0;j<sz;j++) {
            res*=1-p[idx[j]][i];
            if(res<1e-30) break;
        }
        p[u][i]=1-res;
    }

    for(int i=2*q;i>0;i--) p[u][i]=p[u][i]*(1-pp)+p[u][i-1]*pp;
    return v;
}
int main() {
    cin>>n>>q;
    for(int i=0;i<n;i++) cin>>a[i],_max=max(_max,a[i]);
    int l,r;
    double ppp;
    for(int i=0;i<q;i++) {
        cin>>l>>r>>ppp;
        S.push_back(seg(l-1,r-1,ppp));
    }
    S.push_back(seg(0,n-1,0.0));
    q++;
    sort(S.begin(),S.end());
    solve(0);
    double res=_max;
    for(int i=q;i<=2*q;i++) res+=(p[0][i]-p[0][i+1])*(i-q);
    cout<<fixed<<setprecision(10)<<res<<endl;
    return 0;
}
