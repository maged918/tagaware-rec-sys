//Language: GNU C++


#include<bits/stdc++.h>
#define MOD 1000000007
using namespace std ;
int main()
{
    long long n , ans = 50000 , a[500] , i ,j,tmp , maxm ;
    cin >> n ;
    for(i=0; i < n ; i++)
    {
        cin >> a[i ] ;

    }
    for( i = 2 ; i < n ; i++ )
    {
         maxm = a[i] - a[i-2 ] ;
        for( j=1 ; j < n ; j++)
        {
            maxm = max( a[j] - a[j-1] , maxm  ) ;
        }
        ans = min( ans , maxm ) ;

    }
    cout << ans << endl ;
return 0 ;
}
