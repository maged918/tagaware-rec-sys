//Language: GNU C++


#include <cstdio>
#include <string>
#include <vector>
#include <cstring>
#include <algorithm>
#include <iostream>
using namespace std;
typedef long long ll;
const int maxn = 100010;
const int INF = 1e9+7;
const double eps = 1e-12;
int a[maxn], s1[maxn], s2[maxn], hs1[maxn], hs2[maxn];
struct Nd{
    int x, y;
    Nd(){}
    Nd(int xx, int yy)
    {
        x = xx, y = yy;
        // cout<<"Nd "<<x<<" "<<y<<endl;
    }
    friend bool operator< (const Nd & n1, const Nd & n2)
    {
        if(n1.x != n2.x) return n1.x < n2.x;
        return n1.y < n2.y;
    }
};
vector<Nd> ret;
int main()
{   
    int n;
    scanf("%d", &n);
    ret.clear();
    int c1 = 0, c2 = 0;
    memset(hs1, 0, sizeof(hs1));
    memset(hs2, 0, sizeof(hs2));
    for(int i = 1; i <= n; i++) 
    {
        scanf("%d", &a[i]);
        s1[i] = s1[i-1] + (a[i] == 1? 1 :0);
        s2[i] = s2[i-1] + (a[i] == 2? 1 :0);
        if(a[i] == 1)
        {
            c1++;
            hs1[s1[i]] = i;
        }
        else {
            c2++;
            hs2[s2[i]] = i;
        }
    }
    // cout<<"Now "<<c1<<" "<<c2<<endl;
    int T;
    if(a[n] == 1) T = c1;
    else T = c2;
    // for(int i = 1; i <= n; i++)
    //  cout<<s1[i]<<" "<<s2[i]<<endl;
    // for(int i = 1; i <= c1; i++)
    //  cout<<"Info 1: "<<hs1[i]<<endl;
    // for(int i = 1; i <= c2; i++)
    //  cout<<"Info 2: "<<hs2[i]<<endl;
    // cout<<T<<endl;
    // cout<<"----------test-------------"<<endl;
    int k1 = 0, k2 = 0;
    // cout<<T<<endl;
    for(int t = 1; t <= T; t++)
    {
        k1 = k2 = 0;
        int i = 1;
        int cnt = 10;
        while(i <= n)
        {   
            // if(cnt > 0) cout<<"here "<<i<<endl, cnt --;
            if(t + s1[i-1] > c1 && t + s2[i-1] > c2) break;
            if(t + s2[i-1] > c2 ||(t + s1[i-1] <= c1 && hs1[t + s1[i-1]] < hs2[t + s2[i-1]]))
            {
                k1++;
                i = hs1[t + s1[i-1]] + 1;
            }
            else if(t + s1[i-1] > c1 ||(t + s2[i-1] <= c2 && hs1[t + s1[i-1]] > hs2[t + s2[i-1]]))
            {
                k2++;
                // if(cnt > 0) cout<<"now "<<i<<" "<<hs2[t + s2[i-1]] + 1<<endl;
                i = hs2[t + s2[i-1]] + 1; 
            }
            else break;
        }
        if(i == n+1)
        {
            // cout<<"In "<<t<<" "<<k1<<endl;
            if(a[n] == 1 && k1 > k2) 
                ret.push_back(Nd(k1, t));
            else if(a[n] == 2 && k1 < k2)
                ret.push_back(Nd(k2, t));
        }
    }
    cout<<ret.size()<<endl;
    if(ret.size() >= 1)
    {
        sort(ret.begin(), ret.end());
        for(int i = 0; i < ret.size(); i++)
            cout<<ret[i].x<<" "<<ret[i].y<<endl;
    }
    // system("pause");
    return 0;
}
