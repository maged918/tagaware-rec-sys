//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <ctime>
#include <cmath>
#include <algorithm>

using namespace std;
typedef long long int ll;
typedef double lf;
typedef long double LF;
template <class Q> Q _max(Q a, Q b){return (a > b) ? a : b;}
template <class Q> Q _min(Q a, Q b){return (a < b) ? a : b;}
template <class Q> Q _abs(Q x){return (x > 0) ? x : -x;}
template <class Q> Q _sqr(Q x){return x * x;}
template <class Q> void gi(Q &x){
  char ch = getchar(); x = 0;
  while (ch < '0' || ch > '9') ch = getchar();
  while (ch >= '0' && ch <= '9') x = x * 10 + ch - 48, ch = getchar();
}
template <class Q> void pi(Q x){
  if (x > 9) pi(x / 10);
  putchar(x % 10 + 48);
}
template <class Q> void _swap(Q &x, Q &y){Q t = x; x = y; y = t;}

#define huge 1000000000
#define sz1 120
#define sz2 1200
#define sz3 10202
#define sz4 102202
#define sz5 524300
#define sz6 1049000
#define sz7 3002100
#define ljz7 1000000007
#define ljz9 1000000009
#define eps 1e-8
#define hugell (1ll << 61)
#define hugelf 1e40

int a[202020];
int n;
int p1[202020], p2[202020], q1[202020], q2[202020];
pair <int, int> ans[202020];
int i, j, k, l, r;
int A;

void pd(int t){
  int i, j, k, l1 = 0, l2 = 0, la = 0;
  for (i = 0; i < n; ){
    j = q1[i] + t; k = q2[i] + t;
    if (p1[j] == 0 && p2[k] == 0) return;
    if (p1[j] == 0) i = p2[k], l1++, la = l1;
    else if (p2[k] == 0) i = p1[j], l2++, la = l2;
    else if (p1[j] < p2[k]) i = p1[j], l2++, la = l2;
    else i = p2[k], l1++, la = l1;
  }
  if (l1 != l2 && la == max(l1, l2))
    ans[++A] = make_pair(max(l1, l2), t);
}

int main(){
  gi(n);
  for (i = 1; i <= n; i++) gi(a[i]);
  l = r = 0;
  for (i = 1; i <= n; i++){
    if (a[i] == 1) p1[++l] = i;
    else p2[++r] = i;
    q1[i] = l; q2[i] = r;
  }
  for (i = n; i; i--) pd(i);
  sort(ans + 1, ans + A + 1);
  printf("%d\n", A);
  for (i = 1; i <= A; i++) printf("%d %d\n", ans[i].first, ans[i].second);
  return 0;
}
