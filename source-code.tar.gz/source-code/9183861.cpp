//Language: GNU C++0x


#include <bits/stdc++.h>

using namespace std;

const int MaxN = (int)(1e5) + 256;

int a[MaxN], b[MaxN], last, n;

int getNext (int x) {
	int A = 0, B = 0, pos = 1;
	while (pos <= n) {
		int nxt1 = lower_bound (a + pos, a + n + 2, a[pos - 1] + x) - a;
		int nxt2 = lower_bound (b + pos, b + n + 2, b[pos - 1] + x) - b;
		if (nxt1 == n + 1 && nxt2 == n + 1)
			return -1;
		if(nxt1 < nxt2){
			pos = nxt1 + 1;
			A++;
		} else {
			pos = nxt2 + 1;
			B++;
		}
	}
	if (A > B && last == 1)
		return A;
	if (A < B && last == 2)
		return B;
	return -1;
}

int main () {
	#ifdef lcl
		freopen (".in", "r", stdin);
	#endif

	scanf ("%d", &n);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &last);
		a[i] = a[i - 1] + (last == 1);
		b[i] = b[i - 1] + (last == 2);
	}
	a[n + 1] = b[n + 1] = INT_MAX;
	set <pair <int, int> > S;
	for (int t = 1; t <= n; ++t) {
		int s = getNext (t);
		if (s > 0)
			S.insert (make_pair (s, t));
	}
	printf ("%d\n", (int)(S.size()));
	for (auto &i : S)
		printf ("%d %d\n", i.first, i.second);
    return 0;
}

