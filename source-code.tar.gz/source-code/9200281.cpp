//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS

#include <string>
#include <sstream>
#include <cstring>
#include <sstream>
#include <vector>
#include <algorithm>
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <ctime>
#include <cmath>
#include <math.h>
#include <set>
#include <map>
#include <list>
#include <iomanip>
#include <cstdio>
#include <algorithm>
using namespace std;

#define pp system("pause");
#define ct double ttme = clock()
#define p_ct cout << (clock() - ttme) / CLOCKS_PER_SEC << endl
#define all(c) (c).begin(),(c).end()
#define fft ifstream fin("input.txt"); ofstream fout("output.txt")
#define fft_c FILE *fin, *fout
#define fft_c_open fin = fopen("input.txt","r"); fout = fopen("output.txt","w")
#define fft_c_cl fclose(fin); fclose(fout)
#define pii pair<ll,ll>
#define pff pair<float,float>
#define piii pair<int,pair<int,int>>
#define M_PI 3.14159265358979323846
typedef unsigned long long ull;
typedef signed long long ll;
const int INF = 1e8;
const int MAXM = 1000000007;
const int MAX = 1e7;
const int des = 10000;


const int maxn = 10005;

int mass[4];

bool check() {
	double ms[4];
	ms[0] = mass[0];
	ms[1] = mass[1];
	ms[2] = mass[2];
	ms[3] = mass[3];
	sort(ms, ms+4);
	double a = (ms[0] + ms[1] + ms[2] + ms[3]) / 4.0;
	double b = (ms[1] + ms[2]) / 2.0;
	double c = (ms[3] - ms[0]);

	return (a == b && b == c);
}


int main() {

	int n;
	cin >> n;

	if(n == 0) {
		cout << "YES" << endl;
		cout << "1" << endl << "1" << endl << "3" << endl << "3";
		return 0;
	}

	mass[0] = 1;
	mass[1] = 1;
	mass[2] = 1;
	mass[3] = 1;

	for(int i = 0; i < n; i++)
		cin >> mass[i];

	if(n == 1 && mass[0] == 500) {
		cout << "YES" << endl << 500 << endl << 1500 << endl << 1500;
		return 0;
	}

	if(n == 2 && mass[0] == 500) {
		cout << "YES" << endl << 1491 << endl << 1488;
		return 0;
	}



	if(n == 4) {
		if(check()) {
			cout << "YES" << endl;
			return 0;
		}
	}


	if(n == 3) {

		for(int d = 1; d <= 500; d++) {
			mass[3] = d;

			if(check()) {
				cout << "YES" << endl;
				cout << d << endl;
				return 0;
			}
		}
	}

	if(n == 2) {

		for(int c = 1; c <= 500; c++) {
			mass[2] = c;
		for(int d = 1; d <= 500; d++) {
			mass[3] = d;

			if(check()) {
				cout << "YES" << endl;
				cout << c << endl;
				cout << d << endl;
				return 0;
			}
		}
		}

	}

	if(n == 1) {

		for(int a = 1; a <= 375; a++) {
			mass[1] = a;
		for(int c = 1; c <= 375; c++) {
			mass[2] = c;
		for(int d = 1; d <= 375; d++) {
			mass[3] = d;

			if(check()) {
				cout << "YES" << endl;
				cout << a << endl;
				cout << c << endl;
				cout << d << endl;
				return 0;
			}
		}
		}
		}
	}

	cout << "NO";

	//pp;
}