//Language: GNU C++


#include<stdio.h>
int main()
{
	long long int m,n,i,a,b,x,cnt=0;
	scanf("%lld%lld",&a,&b);x=a-b;
	if(a==b)
	{
		puts("infinity");
		return 0;
	}
	for(i=1;i*i<=x;i++)
		if(x%i==0)
		{
			m=i;
			n=x/i;
			if(m>b || n>b)
				if(m==n)
					cnt++;
				else
				{
					if(m>b)
						cnt++;
					if(n>b)
						cnt++;
				}
		}
	printf("%lld\n",cnt);
	return 0;
}
