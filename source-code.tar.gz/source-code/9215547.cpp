//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main(void){
	long n;
	cin >> n;
	vector<long> a(n);
	cin >> a[0];
	for (int i = 1; i < n; i++){
		cin >> a[i];
		a[i] += a[i - 1];
	}
	long m;
	cin >> m;
	vector<long> q(m);
	for (int i = 0; i < m; i++){
		cin >> q[i];
		cout << lower_bound(a.begin(), a.end(), q[i]) - a.begin() +1 << '\n';
	}
	return 0;
}