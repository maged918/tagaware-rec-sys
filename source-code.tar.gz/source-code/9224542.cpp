//Language: GNU C++0x


#include <iostream>
using namespace std;
int main()
{
	int a,i,b,j,n;
	cin >> n;
	int k  [10];
	k[0] = 2; k[1] =7;k[2] = 2;k[3] = 3;k[4] =3;k[5]=4;k[6]=2;k[7]=5;
	k[8] =1;k[9] =2; 
	int m  [2];
	m[0] = n / 10;
//	cout <<m[0]<<endl;
	n=n%10;
//	cout <<n<<endl;
	m[1] = n;
//	cout <<m[1];
	a =k[m[0]] * k[m[1]]; 
	cout <<a<<endl;
}

