//Language: GNU C++


#include <iostream>

using namespace std;

const int max_n = 100 + 12;
int n, m, ary[max_n];

int main(){
	cin >> n >> m;
	for(int i = 0; i < m; i++){
		int a;
		cin >> a;
		a--;
		for(int j = n - 1; j >= a; j--){
			if(ary[j] == 0)
				ary[j] = a + 1;
		}
	}
	for(int i = 0; i < n; i++)
		cout << ary[i] << " ";
	cout << endl;
	return 0;
}