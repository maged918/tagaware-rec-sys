//Language: GNU C++


#include <iostream>
using namespace std;

int main()
{
    int ara[3005],i,n,p,q,v;
    for(i=0;i<3005;i++)
        ara[i]=0;
    cin>>n>>v;
    for(i=0;i<n;i++){
        cin>>p>>q;
        ara[p]+=q;
    }
    int total=0;
    int _v;
    for(i=1;i<3005;i++){
        _v=v;
        if(_v>ara[i-1]){
            _v-=ara[i-1];
            total+=(ara[i-1]);
            if(_v>ara[i]){
                _v-=ara[i];
                total+=ara[i];
                ara[i]=0;
            }
            else{
                total+=_v;
                ara[i]-=_v;
            }
        }
        else{
            total+=_v;
        }
    }
    cout<<total<<endl;
    return 0;
}
