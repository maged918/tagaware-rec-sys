//Language: GNU C++


#include <bits/stdc++.h>
#define maxn 110
#define f first
#define s second
#define mp make_pair
#define pb push_back

using namespace std;
typedef long long ll;
typedef pair <int,int> p1;
int n,m,kq,ok,d[maxn];
string st[maxn];

void nhap()
{
    cin>>n>>m;
    for (int i=1 ; i<=n ; i++)
        cin>>st[i];
}

void cbi()
{
    kq=0;
    memset(d,0,sizeof(d));
}

bool check(int i,int j)
{
    if (st[i][j]<st[i-1][j])
    {
        ok=0;
        kq++;
        return 1;
    }
    return 0;
}

void xuli()
{
    for (int j=0 ; j<m ; j++)
    {
        ok=1;
        for (int i=2 ; i<=n ; i++)
        {
            if (d[i]) continue;
            if (check(i,j)) break;
        }
        if (ok)
        {
            for (int i=2 ; i<=n ; i++)
                if (st[i][j]!=st[i-1][j]) d[i]=1;
        }
    }
}

void ghikq()
{
    cout<<kq;
}

int main()
{
    #ifndef ONLINE_JUDGE
    freopen("C.inp","r",stdin );
    freopen("C.out","w",stdout);
    #endif // ONLINE_JUDGE
    nhap();
    cbi();
    xuli();
    ghikq();
    return 0;
}
