//Language: GNU C++


#include<iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<iomanip>
#include<map>
#include<algorithm>
#include<queue>
#include<set>
#define inf 10000000
#define PI acos(-1.0)
#define eps 1e-8
#define seed 131
using namespace std;
typedef unsigned long long ULL;
typedef long long LL;
typedef pair<int,int> pii;
const int maxn=100005;
const int mod=1000000007;
char s[maxn];
char t[maxn];
int next[maxn];
bool match[maxn];
int dp[maxn];
int ans[maxn];
int sum[maxn];
void get_next(char* str,int len)
{
    next[0]=-1;
    int i=0,j=-1;
    while(i<len)
    {
        if(j==-1||str[i]==str[j])
        {
            i++;j++;
            next[i]=j;
        }
        else
            j=next[j];
    }
}
void kmp(char* s1,int len1,char* sub,int len2)
{
    int i=0,j=0;
    while(i<len1)
    {
        if(j==-1||s1[i]==sub[j])
        {
            i++;j++;
            if(j==len2)
            {
                match[i-1]=1;
                j=next[j];
            }
        }
        else
            j=next[j];
    }
}
int main()
{
    scanf("%s",s);
    scanf("%s",t);
    memset(match,0,sizeof(match));
    get_next(t,strlen(t));
    kmp(s,strlen(s),t,strlen(t));
    int len=strlen(s);
    int m=strlen(t);
    if(match[0])
    {
        dp[0]=1;
        ans[0]=1;
        sum[0]=1;
    }
    else
    {
        dp[0]=0;
        ans[0]=0;
        sum[0]=0;
    }
    for(int i=1;i<len;i++)
    {
        if(match[i])
        {
            dp[i]=i-m+2;
            dp[i]=(dp[i]+sum[i-m])%mod;
            ans[i]=(ans[i-1]+dp[i])%mod;
            sum[i]=(sum[i-1]+ans[i])%mod;
        }
        else
        {
            dp[i]=dp[i-1];
            ans[i]=(ans[i-1]+dp[i])%mod;
            sum[i]=(sum[i-1]+ans[i])%mod;
        }
    }
    cout<<ans[len-1]<<endl;
    return 0;
}




















