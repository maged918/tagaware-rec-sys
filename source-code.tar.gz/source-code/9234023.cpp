//Language: GNU C++0x


#include <cstdio>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <algorithm>
#include <string>
#include <queue>
#include <stack>
#include <vector>
#include <unordered_map>
#include <map>
#include <set>
#include <math.h>
#define M_PI    3.14159265358979323846  /* pi */
#define ri(i) int i;cin>>i;
#define rii(i,j) int i,j;cin>>i>>j;
#define riii(i,j,k) int i,j,k;cin>>i>>j>>k;
#define rc(i) char i;cin>>i;
#define rll(i) long long i;cin>>i;
#define ff(i,s,n) for(int i=(s);i<(n);i++)
#define fff(i,s,n) for(i=(s);i<(n);i++)
#define fr(i,s,n) for(int i=(n-1);i>=(s);i--)
#define frf(i,s,n) for(i=(n-1);i>=(s);i--)
#define FF(i,s,n) for(int i=(s);i<=(n);i++)
#define FFf(i,s,n) for(i=(s);i<=(n);i++)
#define Fr(i,s,n) for(int i=(n);i>=(s);i--)
#define Frf(i,s,n) for(i=(n);i>=(s);i--)
#define mp(a,b) make_pair(a,b)
#define all(a) a.begin(),a.end()

template<typename T, typename U> inline void swap(T &a, U &b) {
    a = a^b;
    b = a^b;
    a = a^b;
}

inline void swap(int &a, int &b) {
    a = a^b;
    b = a^b;
    a = a^b;
}

inline void swap(long long &a, long long &b) {
    a = a^b;
    b = a^b;
    a = a^b;
}

template<typename T, typename U> inline void smax(T &a, U b) {
    if (b > a)a = b;
}

template<typename T, typename U> inline void smin(T &a, U b) {
    if (b < a)a = b;
}

inline int gcd(int a, int b) {
    if (a < b)swap(a, b);
    while (b > 0) {
        a %= b;
        swap(a, b);
    }
    return a;
}

long long nchose(int a, int b) {
    long long ans = 1;
    smax(a, b - a);
    int p = 2;

    FF(i, b - a + 1, b) {
        ans *= (long long) i;
        while (p <= a && ans % p == 0)ans /= p++;
    }
    return ans;
}

using namespace std;
static long long MOD = 1000000009;
typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<vll > vvll;
typedef pair<vi, vi> pvi;
typedef vector<vi > vvi;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<pair<string, string> > vpss;
typedef vector<pii > vpii;
typedef vector<pll > vpll;
typedef vector<vpii > vvpii;
typedef map<int, int> mii;
typedef unordered_map<int, int> imap;
typedef unordered_map<ll, ll> lmap;


int n,s,l, p1,p2,ans=-1;
multiset<ll> m;
vi jt,v;
vpii dp;
int main(){
    cin>>n>>s>>l;jt.resize(n,0),v.resize(n),dp.resize(n+1);
    for(int &i:v)cin>>i;
    for(;p2<n;p2++){
        m.insert(v[p2]);
        auto e=--m.end(),b=m.begin();
        for(;*e-*b>s;e=--m.end(),b=m.begin()){
            m.erase(m.find(v[p1++]));
        }
        if(p2-p1+1>=l)jt[p2]=p2-p1+1;
    }
    dp[0]=mp(n-1,n);
    FF(i,0,n){
        if(dp[i].first<0){
            ans=i;
            break;
        }
        fr(j,dp[i].first,dp[i].second){
            int t=jt[j];
            if(t){
                dp[i+1].first=j-t;
                smax(dp[i+1].second,j-l+1);
            }
        }
        smin(dp[i+1].second,dp[i+1].first+l+1);
    }
    cout<<ans;
}
