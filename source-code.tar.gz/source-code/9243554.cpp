//Language: GNU C++


#include <bits/stdc++.h>
#define ll long long
#define dbg(x) cout<<#x<<": "<<x<<endl
#define dbgv(x,i) cout<<#x<<"["<<i<<"]: "<< x[i]<<endl
#define maxx 99999999
#define minn -99999999
#define PB push_back
#define MP make_pair
#define ff first
#define ss second
#define mod 1000000007
#define f(i,a,b) for(i = a; i < b; i++)
#define sz(a) int((a).size())
#define all(c) (c).begin(),(c).end()
#define tr(c,i) for(typeof((c).begin() i = (c).begin(); i != (c).end(); i++)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())
using namespace std;
void fastInOut(){ios_base::sync_with_stdio(0);cin.tie(NULL),cout.tie(NULL);}
int a[105],sum[105];
int main()
{
    #ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    #endif
    int n,i,ans = maxx,j;
    cin>>n;
    f(i,0,n)    cin>>a[i];
    f(i,1,n-1)
    {
        int temp = 0;
        f(j,1,n)
        {
            if(j == i)  continue;
            if(j == i + 1)
                temp = max(temp,a[j] - a[j-2]);
            else    temp = max(temp,a[j] - a[j-1]);
        }
        ans = min(ans,temp);
    }
    cout<<ans<<endl;
    return 0;
}
