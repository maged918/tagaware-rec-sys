//Language: GNU C++


#include <bits/stdc++.h>
#define c cin
#define o cout
#define el endl
#define mss map<string,string>
using namespace std;

int main(){
	int n,m; c>>n>>m;
	mss comp; string x,y,out="";
	for(int i=0;i<m;i++){
		c>>x>>y;
		comp[x]=y;
	}
	for(int i=0;i<n-1;i++){
		c>>x;
		if(x.length()<=comp[x].length()) out+=x+' ';
		else if(x.length()>comp[x].length()) out+=comp[x]+' ';
	}
	c>>x;
	if(x.length()<=comp[x].length()) out+=x;
	else if(x.length()>comp[x].length()) out+=comp[x];
	o<<out<<el;
}
