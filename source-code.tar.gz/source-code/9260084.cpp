//Language: GNU C++


#include<bits/stdc++.h>         //i learnt never to give up and think simple
using namespace std;            // awsome question problemsetter
int main(){
	 long long x1,x2,y1,y2,n,a,b,c,line1,line2,ans = 0;
	 cin>>x1>>y1;
	 cin>>x2>>y2;
	 cin>>n;
	 for(int i=0;i<n;i++){
		  cin>>a>>b>>c;
		  line1 = a*x1 + b*y1 + c;
		  line2 = a*x2 + b*y2 + c;
		  if((line1>0 && line2<0)  || (line1 <0 && line2>0) ){
			   ++ans;
		  }
	 }
	 cout<<ans<<endl;
	 return 0;
}
