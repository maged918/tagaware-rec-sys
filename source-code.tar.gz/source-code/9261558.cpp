//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <iostream>
#include <sstream>
#include <vector>
#include <list>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <utility>
#include <algorithm>
#include <limits>
#include <iomanip>

#define INF 1000000000
#define Inf 1000000000000000000

using namespace std;

typedef long long ll;
typedef pair<int,int> ii;
typedef vector<ii> vii;
typedef vector<int> vi;
typedef vector<vi> vvi;
typedef vector<vii> vvii;

long double cross(pair<long double,long double> p, pair<long double,long double> q, pair<long double,long double> r) {
  return (r.first - q.first)*(p.second - q.second) - (r.second - q.second)*(p.first - q.first);
}

bool ccw(pair<long double,long double> p, pair<long double,long double> q, pair<long double,long double> r) {
  return cross(p,q,r) > 1e-9;
}

int main() {
  //freopen("in","r",stdin);
  pair<long double,long double> o,d;
  cin >> o.first >> o.second >> d.first >> d.second;
  int n,x,y,a,b,c;
  pair<long double,long double> p1,p2;
  scanf("%d",&n);
  int resp = 0;
  for(int i = 0; i < n; i++) {
    scanf("%d %d %d",&a,&b,&c);
    if (a == 0) {
      p1.first = 0;
      p1.second = (long double)-c/b;
      p2.first = 1;
      p2.second = (long double)-c/b;
    } else if (b == 0) {
      p1.first = (long double)-c/a;
      p1.second = 0;
      p2.first = (long double)-c/a;
      p2.second = 1;
    } else {
      p1.first = 1;
      p1.second = (long double)(-c-a)/b;
      p2.first = 0;
      p2.second = (long double)-c/b;;
    }
    if (ccw(p1,p2,o) != ccw(p1,p2,d))
      resp++;
  }
  cout << resp << endl;
  return 0;
}
