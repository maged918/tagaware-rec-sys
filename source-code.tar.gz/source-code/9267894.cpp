//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;

#define oo (1<<30)
const int MAXN = 100000;
class MaxFlow {
private:
    int *head, *headcpy, *to, *nxt, *cap, *vis, *Q, lst;
    int n, ID;
public:

    ~MaxFlow(void) {
        delete[] head;
        delete[] headcpy;
        delete[] to;
        delete[] nxt;
        delete[] cap;
        delete[] vis;
        delete[] Q;
    }

    void _init(int n, int m) {
        ID = 0;
        this->n = n;
        head = new int[n];
        headcpy = new int[n];
        memset(head, -1, n * sizeof(head[0]));
        to = new int[m];
        nxt = new int[m];
        cap = new int[m];
        vis = new int[m];
        memset(vis, -1, n * sizeof(vis[0]));
        Q = new int[m];
        lst = 0;
    }

    void addEdge(int f, int t, int cp) {
        nxt[lst] = head[f];
        to[lst] = t;
        cap[lst] = cp;
        head[f] = lst++;
    }
    int rank[MAXN];
    int ddfs(int cur, int snk, int minic = oo) {
        if (cur == snk)
            return minic;

        for (int &i = headcpy[cur]; i != -1; i = nxt[i]) {
            int t = to[i];
            if (!cap[i] || rank[t] != rank[cur] + 1)
                continue;

            int ret = ddfs(t, snk, min(minic, cap[i]));
            cap[i] -= ret;
            cap[i ^ 1] += ret;
            if (ret)
                return ret;
        }
        return 0;

    }
    bool dbfs(int src, int snk) {
        ID++;
        int Qi = 0;
        Q[Qi++] = src;
        vis[src] = ID;
        rank[src] = 0;

        for (int in = 0; in < Qi; in++) {
            int cur = Q[in];
            int r = rank[cur];
            for (int i = head[cur]; i != -1; i = nxt[i]) {
                int t = to[i];
                if (!cap[i] || vis[t] == ID)
                    continue;
                vis[t] = ID;
                rank[t] = r + 1;
                if (t == snk)
                    return 1;
                Q[Qi++] = t;
            }
        }

        return 0;

    }
    int dinic(int src, int snk) {
        if (src == snk)
            return oo;
        int ret = 0;
        while (dbfs(src, snk)) {
            int f;
            memcpy(headcpy, head, n * sizeof(head[0]));
            while (f = ddfs(src, snk), f)
                ret += f;
        }
        return ret;
    }
};

int *arr, *x, *y;
set<int> s;

void facto(int n) {
    for (int i = 2; i * (long long) i <= n; i++) {
        while (n % i == 0) {
            n /= i;
            s.insert(i);
        }
    }
    if (n != 1)
        s.insert(n);
}

#define GETCHAR getchar
void Read(int &x) {
    char c, r = 0, n = 0;
    x = 0;
    for (;;) {
        c = GETCHAR();
        if ((c == '-') && (!r))
            n = 1;
        else if ((c >= '0') && (c <= '9'))
            x = x * 10 + c - '0', r = 1;
        else if (r)
            break;
    }
    if (n)
        x = -x;
}

int main() {
    int n, m;
    Read(n);
    Read(m);
    //cin >> n >> m;
    arr = new int[n];
    x = new int[m];
    y = new int[m];
    for (int i = 0; i < n; i++) {
        //cin >> arr[i];
        Read(arr[i]);
        facto(arr[i]);
    }
    for (int i = 0; i < m; i++) {
//      cin >> x[i];
//      cin >> y[i];
        Read(x[i]);
        Read(y[i]);
        x[i]--, y[i]--;
        if (y[i] & 1)
            swap(x[i], y[i]);
    }

    set<int>::iterator it;
    int ans = 0;
    for (it = s.begin(); it != s.end(); it++) {
        int p = (*it);

        MaxFlow mf;
        mf._init(n + 2, 2 * m + 4 * n);

        for (int i = 0; i < n; i++) {
            int cnt = 0;
            int num = arr[i];
            while (num % p == 0)
                num /= p, cnt++;
            if (i & 1) {
                mf.addEdge(n, i, cnt);
                mf.addEdge(i, n, 0);
            } else {
                mf.addEdge(i, n + 1, cnt);
                mf.addEdge(n + 1, i, 0);
            }
        }
        for (int i = 0; i < m; i++) {
            mf.addEdge(x[i], y[i], 100);
            mf.addEdge(y[i], x[i], 0);
        }
        ans += mf.dinic(n, n + 1);
    }
    cout << ans << endl;
}