//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
int main()
{int i,j,l=-1,a[5][5],x[5]={0,1,2,3,4},sum=0,max=0;
for(i=0;i<5;i++)
for(j=0;j<5;j++)
cin>>a[i][j];
do
{sum=2*(a[x[2]][x[3]]+a[x[3]][x[2]]+a[x[3]][x[4]]+a[x[4]][x[3]])+(a[x[0]][x[1]]+a[x[1]][x[0]]+a[x[1]][x[2]]+a[x[2]][x[1]]);
//cout<<"sum="<<sum<<"  "<<"max="<<max<<endl;
if(max<sum)
max=sum;
}while(next_permutation(x,x+5));

cout<<max;
return 0;

}