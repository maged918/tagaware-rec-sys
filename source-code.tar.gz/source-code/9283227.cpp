//Language: GNU C++


#include<bits/stdc++.h>
#include<string>
using namespace std;
template< class T > T gcd(T a, T b) { return (b != 0 ? gcd<T>(b, a%b) : a); }
template< class T > T lcm(T a, T b) { return (a / gcd<T>(a, b) * b); }
#define traverse(container, it) \
  for(typeof(container.begin()) it = container.begin(); it != container.end(); it++)
#define         mp(x, y) make_pair(x, y)
#define         REV(s, e) reverse(s, e)
#define         CPY(d, s) memcpy(d, s, sizeof(s))
#define         READ(f) freopen(f, "r", stdin)
#define         WRITE(f) freopen(f, "w", stdout)
#define         ALL(c) c.begin(), c.end()
#define         SIZE(c) (int)c.size()
#define         pb(x) push_back(x)
//#define       map<char,int>::iterator it;
#define         ff first
#define         ss second
#define         ll long long
#define         ld long double
#define         pii pair< int, int >
#define         psi pair< string, int >
#define         p(n) printf("%d\n",n)
#define         p64(n) printf("%lld\n",n)
#define         s(n) scanf("%d",&n)
#define         s64(n) scanf("%I64d",&n)
#define         rep(i,a,b) for(i=a;i<b;i++)
#define         MOD (1000000007LL)


ll pwr(ll base, ll p){
    ll ans = 1;
    while(p){
        if(p&1) ans = (ans * base)%MOD;
        base = (base * base)%MOD;
        p>>=1;
    }
    return ans;
}

ll modInv(ll n, ll mod){
    return pwr(n, mod-2);
}


int bitCount(int n){

    int c = 0;
    while(n){
        c++;
        n &= n-1;
    }
    return c;
}



//////////////////////////////////////////////////////


int main()
{
        double n,m,cost;;
        int i,a,b;
        cin>>n>>m;
        int ver[100000];
        rep(i,1,n+1){
                s(ver[i]);
        }
        double ans=0;
        rep(i,0,m){
                cin>>a>>b>>cost;

                ans=max(ans,(ver[a]+ver[b])/cost);

        }
        printf("%.12lf\n",ans);
    return 0;
}
