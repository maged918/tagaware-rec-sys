//Language: GNU C++


#include <cstdio>
#include <cstring>

char str[100];

int main(){
    int n;
    scanf("%d", &n);
    for (int b = 1;;b++){
        sprintf(str, "%d", b + n);
        int len = strlen(str);
        bool good = 0;
        for (int i = 0; i < len; i++) if (str[i] == '8') good = 1;
        if (good) {printf("%d\n", b); return 0;}
    }
    return 0;
}