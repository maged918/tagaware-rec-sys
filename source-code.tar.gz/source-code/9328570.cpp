//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

int n,i;

int main(){
    //freopen("input.txt","r",stdin);
    scanf("%d",&n);
    for(i=1;i<=n/2;++i)printf("%d %d ",i,n-i+1);
    if(n&1)printf("%d\n",n/2+1);
    return 0;
}
