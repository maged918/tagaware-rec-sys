//Language: GNU C++


#include <algorithm>
#include <iterator>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <climits>
#include <iomanip>
#include <cassert>
#include <cstdio>
#include <vector>
#include <string>	
#include <stack>
#include <queue>
#include <ctime>
#include <cmath>
#include <list>
#include <map>
#include <set>

#define pb push_back
#define fi first
#define se second
#define mp make_pair
#define endl '\n' 
#define all(x) x.begin(),x.end()
#define fill(x,y) memset((x),(y) ,sizeof(x))
#define type(x) __typeof(x.begin())
#define sz(x) x.size()
#define o ((f+l)/2)
#define dg(x) #x << ": " << x << " " 
#define umax(x,y) (x)=max((x),(y))
#define NEW(x) (x *)calloc(1,sizeof(x))
#define umin(x,y) (x)=min((x),(y))
#define tmax(x,y,z) max((x),max((y),(z))) 
#define tmin(x,y,z) min((x),min((y),(z))) 
#define PI (M_PI)

using namespace std;
typedef pair<int,int> ii;
typedef pair<int,ii> iii;
typedef long long int Lint;
const int maxn = 510 ;
Lint N , M , MOD , dn[maxn][maxn] , used[maxn] ;

Lint f( int a , Lint k , Lint l )
{
	if( !a ){
		if( !k && !l ) return 1 ;
		else return 0 ;
	}
	if( dn[k][l] != -1 ) return dn[k][l] ;
	dn[k][l] = 0 ;
	if( k > 1 ) {
		dn[k][l] += ((k*(k-1)/2)%MOD * f( a-1 , k-2 , l+2 ))%MOD ;
		dn[k][l] %= MOD ; 
	}
	if( l > 1 ) {
		dn[k][l] += ((l*(l-1)/2)%MOD * f( a-1 , k , l-2 ))%MOD ;
		dn[k][l] %= MOD ; 
	}
	if( k >= 1 && l >= 1 ) {
		dn[k][l] += ((k*l)%MOD * f( a-1 , k-1 , l ))%MOD ;
		dn[k][l] %= MOD ; 
	}
	
	return dn[k][l] ;
}
int main()
{
	ios_base::sync_with_stdio(0) ;
	
	fill( dn , -1 ) ;
	
	cin >> N >> M >> MOD ;
	
	for( int i=1 ; i<=M ; i++ )
		for( int j=1 ; j<=N ; j++ ){
			char ch ;
			cin >> ch ;
			if( ch == '1' ) used[j]++ ;
		}
	
	int a=0 , b=0 ;
	for( int i=1 ; i<=N ; i++ )	
		if( used[i] == 1 ) b++ ;
		else if(used[i] == 0 ) a++ ;
 	
 	
 	
 	cout << f( N-M , a , b ) << endl  ;
 	
	return 0;
}
