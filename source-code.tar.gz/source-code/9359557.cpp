//Language: GNU C++


#include <cstdio>
#include <iostream>
using namespace std;
int main()
{
   int aY,dY,hpY,aM,dM,hpM;
   int h,a,d;
   cin>>hpY>>aY>>dY;
   cin>>hpM>>aM>>dM;
   cin>>h>>a>>d;
   int cost=0, minCost=1000000;
   int dInc, aInc, hpInc;
   int aN, dN, hpN;
   int roundY=0, roundM=0;

   roundM = aY>dM?(hpM-0.1)/(aY-dM)+1:110;
   roundY = aM>dY?(hpY-0.1)/(aM-dY)+1:110;
   if(roundY>roundM)
    minCost = 0;
   else if(aM<=dY)
   {
       cost = a*(dM-aY+1);
       if(cost<minCost)
        minCost = cost;
   }
   else
   {
       for (int round=1; round<=roundM; round++)
       {
           aN = (hpM-0.1)/round + dM + 1;
           aInc = aN>aY?aN-aY:0;

           int t = aM-dY;
           for(dInc=0; dInc<=t; dInc++)
           {
               hpN = 1 + round*(t-dInc);
               hpInc = hpN>hpY?hpN-hpY:0;
               cost = h*hpInc + a*aInc + d*dInc;
               if(cost<minCost)
                minCost = cost;
           }

       }
   }
   cout<<minCost<<endl;
   return 0;
}
