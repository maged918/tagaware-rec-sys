//Language: GNU C++


#include <stdio.h>
#include<math.h>
//using namespace std;
double l,d[5005][5005],ans,sum,p;
int main() {
    int a[5005],b[5005],n,t,c,i,j,k,x=0,y,z;
    scanf("%d %d",&n,&t);
    for(i=1;i<=n;++i){
        scanf("%d %d",&a[i],&b[i]);
        x=x+b[i];
    }
    x=0;
    double prev=0;
    d[0][0]=1;
    sum=0;
    for(i=1;i<=n;++i){
    //  printf()
        p=((double) a[i])/100;
        ans=0;
        l=1;
        //for(j=1;j<b[i]-1;++j){
        //  l=l*(1-p);
    //  }
    x=x+b[i];
    k=t;
    if(x<t){ k=x;}
        l=pow(1-p,b[i]-2);
        for(j=1;j<=k;++j){
            if(b[i]!=1){
            if(j<b[i]){
                ans=ans*(1-p)+d[i-1][j-1]*p;
            }else{
                ans-=d[i-1][j-b[i]]*l*p;
                ans+=d[i-1][j-b[i]]*l;
            //      printf("%lf %lf %lf %lfxx\n",d[i-1][j-b[i]]*l*p,d[i-1][j-b[i]]*l,d[i-1][j-1]*p,ans);
                ans=ans*(1-p)+d[i-1][j-1]*p;
                
            
            }
            }else{
                ans=d[i-1][j-1];
            }
            d[i][j]=ans;
            sum+=d[i][j];
            if(j>=b[i]) ans-=d[i-1][j-b[i]]*l*(1-p);
//  printf("%d %lf %.8lf %lf %lf\n",j,p,l,ans,sum);
        }
    
    }
    printf("%lf\n",sum);
    return 0;
}