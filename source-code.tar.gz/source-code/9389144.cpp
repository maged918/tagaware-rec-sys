//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define mp make_pair
#define pb push_back
#define gc getchar
#define repa(i,a,n) for(int i=a;i<n;i++)
#define rep(i,n) for(int i=0;i<n;i++)
#define fast() {cin.sync_with_stdio(false);cin.tie(false);cout.tie(false);}
//..........@@   take fast input with sign  @@...........//
int read() {
  char c = gc();
  int sign = 1;
  while((c<'0' || c>'9') && c!='-') c = gc();
  if(c=='-') {
    sign = -1;
    c = gc();
  }
  int ret = 0;
  while(c>='0' && c<='9' ) {
    ret = 10 * ret + c - 48;
    c = gc();
  }
  return ret*sign;
}
//........@@ To merge ranges  @@ .................//
struct node{
    int s;
    int e;
};
inline bool comp(node a, node b)
{
    return a.e<b.e;
}
int main()
{
    fast();
    int arr[]={2,7,2,3,3,4,2,5,1,2};
    int n;
    cin>>n;
    int ans = arr[(n/10)]*arr[n%10];
    cout<<ans<<endl;
    
    
} 