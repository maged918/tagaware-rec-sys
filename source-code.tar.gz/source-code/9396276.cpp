//Language: MS C++


#include <stdio.h>
#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <sstream>
#include <set>
#include <map>
#include <stack>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <string>
#include <deque>
using namespace std;

#define ll long long
#define pi pair<int,int>
#define pll pair<ll,ll>
#define pii pair<int,pi>
#define X first
#define Y second
#define pb push_back
#define ab(x) ((x)<0?(-(x)):(x))
#define xx(x) ((x)*(x))
#define mp make_pair
#define vi vector<int>
#define vll vector<ll>
#define vs vector<string>
#define vpi vector<pi>
#define vpll vector<pll>
#define ALL(x) (x).begin(),(x).end()
#define Max (1<<30)
#define LLMax (1ll<<60)
template<class T>string ToString(T t){stringstream s;s<<t;return s.str();}
template<class T>void ToOther(T&t,string a){stringstream s(a);s>>t;}



#define mod 1000000007


bool ck[100005];
int ff[100005];

int sum[100005];
int sum2[100005];
char s[100005]={0},p[100050]={0};
int n,m,Pi[1000000]={0};
void find_pi()
{
   int i=0,j=-1;
   Pi[0]=-1;
   while(i < m)
   {
      if(j==-1 || p[i]==p[j])
      {
         i++,j++;
         Pi[i]=j;
      }
      else j=Pi[j];
   }
}
void kmp()
{
   int i=0,j=0;
   while(i < n)
   {
      if(j==-1 || s[i]==p[j]) i++,j++;
      else j=Pi[j];
      if(j==m)
      {
		 ck[i-1] =1;
         j=Pi[j];
      }
   }
}
int main()
{
   scanf("%s",s);
   scanf("%s",p);
   n=strlen(s),m=strlen(p);
   find_pi();
   kmp();

   memset(ff,-1,sizeof(ff));


   for(int i = 0 ; i < n ; i ++ ){
	   if( ck[i] ) ff[i] = i - m + 1;
	   if(i) ff[i] = max(ff[i],ff[i-1]);
   }



   int r = 0 ;
   int now = 0;
   for(int i = 0 ; i < n ; i ++ ){

	   now = ff[i] + 1;

	   if( ff[i] - 1 >=0 ) now = (now + sum2[ ff[i] -1 ]) % mod;
	   /*
	   for( int k = ff[i] -1  ; k >= 0 ; k -- ){
		   now = (now + sum[k])%mod;
	   }
	   */

	   r = (r + now) % mod;

	   if(i)sum[i] = sum[i-1];
	   if(i)sum2[i] = sum2[i-1];

	   sum[i] = (sum[i] + now ) % mod;

	   sum2[i] = (sum2[i] + sum[i] ) %mod;
   }

   cout<<r<<endl;
}