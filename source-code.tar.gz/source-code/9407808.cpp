//Language: GNU C++


#include <cstdlib> 
#include <cstring> 
#include <cstdio> 
#include <cmath> 
#include <algorithm> 
#include <vector>
#include <string>
#include <map> 
#include <set> 
#include <queue> 
#include <stack> 
#include <list> 
#include <climits>

using namespace std;

int main() {
	int p1, p2, t1, t2;
	scanf ("%d%d%d%d", &p1, &p2, &t1, &t2);
	
	int x = max ((3 * p1) / 10, p1 - ((p1 / 250) * t1));
	int y = max ((3 * p2) / 10, p2 - ((p2 / 250) * t2));
	
	if (x > y) printf ("Misha\n");
	if (x < y) printf ("Vasya\n");
	if (x == y)printf ("Tie\n");
	return 0;
}