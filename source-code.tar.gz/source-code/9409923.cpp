//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <ctime>
#include <bitset>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <cassert>
#include <set>
#include <cmath>
#include <list>
#include <functional>
#include <utility>
#include <sstream>
#include <numeric>
#include <limits>
#include <fstream>

using namespace std;
 
/*
 @author Anwesh Mohanty
*/
int main(void)
{
    std::ios::sync_with_stdio(false);
    int n,i,j;
    cin>>n;
    pair<string,string> s[n];
    pair<string,string> x[n];
    int c=0;
    int f[n];
    memset(f,0,sizeof(f));
    string temp;
    for(i=0;i<n;i++)
    {
        cin>>s[i].first>>s[i].second;
    }
    for(i=0;i<n;i++)
    {
        temp=s[i].second;
        for(j=i+1;j<n;j++)
        {
            if(temp==s[j].first && s[j].first.length()!=0)
            {
                temp=s[j].second;
                s[j].first="";
            }
        }
        if(s[i].first.length()!=0)
        {
        x[c].first=s[i].first;
        x[c].second=temp;
        c++;
        }
    }
    cout<<c<<endl;
    for(i=0;i<c;i++)
        cout<<x[i].first<<" "<<x[i].second<<endl;
    return 0;
}
