//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstring>
#include <string>
#include <cstdio>
#include <queue>
#include <cmath>
#include <vector>
#include <set>
#include <bitset>
#include <map>
#define  pb push_back
#define  lson l,m,rt<<1
#define  rson m+1,r,rt<<1|1
typedef  long long LL;
using namespace std;
map<string,int>M1;
map<string,string>fa;
map<string,string>M3;
string ok[1010],a,b;
int main()
{
    int n;
    while(cin>>n)
    {
        M1.clear(),fa.clear(),M3.clear();
        int top=0;
        for(int i=0;i<n;i++)
        {
            cin>>a>>b;
            if(!M1[ a ])
            {
                top++;
                M1[ a ] = 1;
                M1[ b ] = 1;
                fa[b] = a;
                M3[ a ] = b;
            }
            else {
                string afa = fa[a];
                M1[b] = 1;
                fa[b] = afa;
                M3[afa] = b;
            }
        }
        cout<<top<<endl;
        for(map<string,string>::iterator it=M3.begin();it!=M3.end();it++)
        {
            cout<<it->first<<" "<<it->second<<endl;
        }
    }
    return 0;
}
