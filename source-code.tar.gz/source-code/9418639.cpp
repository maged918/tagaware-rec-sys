//Language: GNU C++


#include <bits/stdc++.h>
#define mp              make_pair
#define pb              push_back
#define mem(x, n)       memset(x, n, sizeof(x))
#define INF             0x3fffffff
#define read(x, n)      for ( int i = 0; i < n; i++ ) cin >> x[i]
#define print(x, n)     for ( int i = 0; i < n; i++ ) cout << x[i] << ' '
#define MAX             (1 << 16) + 5
#define MAX_VAL         1000
#define check(x, y)     board[y][x] == '.' && !seen[y][x]
#define add(x, y)       Q.push( mp(x, y) ); ans++; seen[y][x] = true

using namespace std;

int d[MAX], XOR[MAX];

int main ( ) {
    int n;
    cin >> n;
    queue<int> q;
    vector<pair<int, int> > ans;
    for ( int i = 0; i < n; i++ ) {
        cin >> d[i] >> XOR[i];
        if ( d[i] == 1 ) q.push(i);
    }

    while ( !q.empty() ) {
        int current = q.front();
        q.pop();
        int next = XOR[current];
        if ( d[current] == 0 ) continue;
        d[next]--;
        XOR[next] ^= current;
        ans.pb( mp(current, next) );
        if ( d[next] == 1 ) q.push(next);
    }

    cout << ans.size() << '\n';
    for ( int i = 0; i < ans.size(); i++ )
        cout << ans[i].first << ' ' << ans[i].second << '\n';
}
