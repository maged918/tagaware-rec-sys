//Language: GNU C++


#define _SCL_SECURE_NO_WARNINGS
#include <iostream>
#include <list>
#include <utility>
#include <vector>
#include <algorithm>
#include <sstream>
#include <string>
#include <map>
#include <ctime>
#include <cstdio>
#include <functional>
#include <iomanip>
#include <stack>
#include <queue>
#include <set>
#include <limits>

using namespace std;

#define test(s) #s,

string t1()
{
    ostringstream ss;
    return ss.str();
}

string t2()
{
    ostringstream ss;
    return ss.str();
}

const string tests[] = {
    test(14 34)
};

void solve(istream& cin)
{
    int a, b;
    cin >> a >> b;
    const int sz = 10000;
    vector<int> x, y, z;
    x.reserve(sz);
    y.reserve(sz);
    z.reserve(sz);

    for (int i = 0; a != 0; ++i) {
        x.push_back(a % 3);
        a /= 3;
    }
    for (int i = 0; b != 0; ++i) {
        y.push_back(b % 3);
        b /= 3;
    }
    for (int i = 0; i < (int) min(x.size(), y.size()); ++i) {
        z.push_back((3 - x[i] + y[i]) % 3);
    }
    for (int i = (int) x.size(); i < (int) y.size(); ++i) {
        z.push_back(y[i]);
    }
    for (int i = (int) y.size(); i < (int) x.size(); ++i) {
        z.push_back((3 - x[i]) % 3);
    }
    long long r = 0;
    for (int i = (int) z.size() - 1; i >= 0; --i) {
        r *= 3;
        r += z[i];
    }
    cout << r << endl;
}

int main()
{
    ios::sync_with_stdio(false);
#if defined(_DEBUG) && !defined(ONLINE_JUDGE)
    for (int i = 0; i < sizeof(tests) / sizeof(*tests); ++i) {
        istringstream ss(tests[i]);
        clock_t time = clock();
        solve(ss);
        cout << "<End-of-test> " << (float) (clock() - time) / CLOCKS_PER_SEC  << " secs" << endl;
    }
    system("pause");
#else
    solve(cin);
#endif
    return 0;
}
