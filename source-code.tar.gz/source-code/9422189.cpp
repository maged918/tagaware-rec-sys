//Language: GNU C++0x


#include <bits/stdc++.h>

using namespace std;

typedef pair<int,int>   PI;
typedef vector<int> VI;
typedef long long LL;

#define FOR(i,a,b) for(register int i=a;i<(b);i++)
#define FORE(i,a,b) FOR(i,a,(b)+1)
#define FORD(i,a,b) for(int i=a;i>=(b);i--)
#define REP(i,n) FOR(i,0,n)
#define PB push_back
#define mod 1000000007
#define MP make_pair
#define INF mod

int main()
{
#ifndef ONLINE_JUDGE
    freopen("a.in","r",stdin);
#endif
    ios_base::sync_with_stdio(0);
    map<string, string> m1, m2;
    int q;
    string x, y;
    for(cin >> q; q--;)
    {
        cin >> x >> y;
        if(!m2.count(x))
        {
            m1[x] = y;
            m2[y] = x;
        }
        else
        {
            string z = m2[x];
            m1[z] = y;
            m2.erase(x);
            m2[y] = z;
        }
    }
    cout << m1.size() << endl;
    for(auto x : m1)
    {
        cout << x.first << ' ' << x.second << endl;
    }
    return 0;
}
