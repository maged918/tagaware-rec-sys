//Language: GNU C++


#include <iostream>
#include <algorithm>

using namespace std;

int a,b,c,d;
float mi,va;

int main()
{
    cin >> a >> b >> c >> d;
    mi = max((3*a)/10,(a-a/250*c));
    va = max((3*b)/10,(b-b/250*d));
   // cout << mi << " " << va;
    if (mi > va)
        cout << "Misha";
    else if (mi == va)
        cout << "Tie";
    else
        cout << "Vasya";
    return 0;
}
