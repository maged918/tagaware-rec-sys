//Language: GNU C++


#include<stdio.h>
int main()
{
	int n,x,s,a,b,c;
	while(scanf("%d%d",&n,&x)!=EOF)
	{
	c=0;s=0;
	while(n--)
	{
		scanf("%d%d",&a,&b);
	s=s+(a-c-1)%x+b-a+1;
			c=b;
	}
	printf("%d\n",s);
	}
	return 0;
}
 		   					    			  			       	