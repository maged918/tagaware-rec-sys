//Language: MS C++


#include <stdio.h>

	int a[100001];
	int b[100001]={0};
	int c[100001]={0};

int main(void)
{
	int odd=0;
	long long int i;
	long long int n;
	
	scanf("%I64d",&n);

	for(i=0;i<n;i++)
	{
		int k;

		scanf("%d",&a[i]);

		k=a[i];

		b[k]++;

		if(b[a[i]] % 2== 1)
			odd++;

		else
			odd--;
	}

	if(odd>1)
		printf("0");

	else
	{
		long long int start=0,end=n-1,mid=n/2;

		for(i=0;i<mid;i++)
		{
			if(a[start+i]!=a[end-i])
				break;

			b[a[start+i]] -= 2;
		}

		start=(long long int)i;
		end = n-i-1;

		if(start==mid)
			printf("%I64d",(n*(n+1))/2);

		else
		{
			long long int count = 0;
			
			for(i=start;i<end;i++)
			{
				if(i<mid)
				{
					c[a[i]]++;

					if(c[a[i]]<=b[a[i]]/2)
						count++;

					else
						break;
				}

				else
				{
					if(a[i]==a[n-i-1])
						count++;

					else
						break;
				}
			}

			for(i=1;i<=n;i++)
				c[i]=0;

			for(i=end;i>start;i--)
			{
				if(i>mid || (i==mid && n%2==0))
				{
					c[a[i]]++;

					if(c[a[i]]<=b[a[i]]/2)
						count++;

					else
						break;
				}

				else
				{
					if(a[i]==a[n-i-1] && (n%2==0 || b[a[i]]%2))
						count++;

					else
						break;
				}
			}

			count *= (start+1);
			count += (start+1)*(start+1);

			printf("%I64d",count);
		}
	}

	return 0;
}