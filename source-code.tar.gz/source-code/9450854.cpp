//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <list>
#include <cstring>
using namespace std;
int N;
int Perm1[200005],Perm2[200005],Result1[200005],Result2[200005];
list <int> List;
int Lazy[800005],Arb[800005],Array[200005];
void Read()
{
    int i;
    cin>>N;
    for(i=1;i<=N;i++)
    {
        cin>>Perm1[i];
    }
    for(int i=1;i<=N;i++)
        cin>>Perm2[i];
}
void Build(long long K,long long L,long long R)
{
    if(L>R)
        return;
    if(L==R)
    {
        Arb[K]=Array[L];
        return;
    }
    Build(2*K,L,(L+R)/2);
    Build(2*K+1,(L+R)/2+1,R);
    Arb[K]=Arb[2*K]+Arb[2*K+1];
}
void Update(int K,int L,int R,int x,int y,int val)
{
    long long node=K;
    if(Lazy[node]!=0)
    {
        Arb[node]+=Lazy[node];
        if(L!=R)
        {
            Lazy[2*node]+=Lazy[node];
            Lazy[2*node+1]+=Lazy[node];
        }
        Lazy[node]=0;
    }
    if(L>R || L>y || R<x)
        return;
    if(x<=L && R<=y)
    {
        Arb[K]+=val;
        if(L==R)
            return;
        Lazy[K*2]+=val;
        Lazy[K*2+1]+=val;
        return;
    }

    Update(2*K,L,(L+R)/2,x,y,val);
    Update(2*K+1,(L+R)/2+1,R,x,y,val);
    Arb[K]=Arb[2*K]+Arb[2*K+1];
}
int Query(int K,int L,int R,int x,int y)
{
    long long node=K;
    if(Lazy[node]!=0)
    {
        Arb[node]+=Lazy[node];
        if(L!=R)
        {
            Lazy[2*node]+=Lazy[node];
            Lazy[2*node+1]+=Lazy[node];
        }
        Lazy[node]=0;
    }
    if(L>R || L>y || R<x)
        return 0;
    if(x<=L && R<=y)
    {
       return Arb[K];
    }
    return Query(2*K,L,(L+R)/2,x,y)+Query(2*K+1,(L+R)/2+1,R,x,y);
}
void Descomp(int Result[])
{
    for(int i=1;i<=N;i++)
        Array[i]=i-1;
    Build(1,1,N);

    for(int i=1;i<=N;i++)
    {
        int x=Perm1[i]+1;
        Result[++Result[0]]=Query(1,1,N,x,x);
        Update(1,1,N,x+1,N,-1);
    }
    reverse(Result+1,Result+Result[0]+1);
}

void add(int A[], int B[])
{
      int i, t = 0;
      for (i=1; t>0 || i<=A[0] || i<=B[0];i++)
      {
          A[i]=t+A[i]+B[i];
          t=A[i]/i;
          A[i]%=i;
      }
      A[0]=N;
}
void Inverse(int Result[])
{
    for(int i=1;i<=N;i++)
        Array[i]=i-1;
    Build(1,1,N);
    memset(Lazy,0,sizeof(Lazy));
    for(int i=N;i>=1;i--)
    {
        int x=Result[i];
        int left=1,right=N,sol;
        while(left<=right)
        {
            int mid=(left+right)/2;
            if(Query(1,1,N,mid,mid)<=x)
            {
                sol=mid;
                left=mid+1;
            }
            else
                right=mid-1;
        }
        cout<<sol-1<<" ";
        Update(1,1,N,sol+1,N,-1);
    }
}
int main()
{
    Read();
    Descomp(Result1);
    memcpy(Perm1,Perm2,sizeof(Perm2));
    memset(Lazy,0,sizeof(Lazy));
    Descomp(Result2);
    add(Result1,Result2);
    Inverse(Result1);
    return 0;
}

