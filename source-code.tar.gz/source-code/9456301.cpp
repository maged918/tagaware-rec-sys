//Language: GNU C++


#include <iostream>
#include <stack>
#include <set>
#include <vector>
#include <algorithm>
#include <queue>
#include <cstdio>
#include <cstring>
#include <string>
#include <map>

#define inf (1 << 30)
#define INF (1<<45LL)
#define pb push_back
#define mp make_pair
using namespace std;

typedef pair<int, int> pi;
typedef long long ll;

/*
 * 
 *      PUCMM PROGRAMMING FORCE
 * 
 * */


bool is_palindrome(string word){
    
    int j = word.length() - 1;
    for(int i=0; i < word.length(); i++, j--)
        if(word[i] != word[j]) return false;
    
    return true;
}
int main(){

    ios_base::sync_with_stdio(false);
    
    string w; 
    while(cin >> w){
        bool ok = false;
        for(int i=0; i < w.length()+1 && !ok; i++)
        {
            
            for(int j=0; j <= 25 && !ok; j++)
            {
                string au = w;
                string letter = "";
                letter.pb((char)('a' + j));
                au.insert(i, letter);
                
                //cout << au << endl;
                if(is_palindrome(au)){
                    cout << au << endl;
                    ok = true;
                    
                }
            }
        }
        if(!ok)cout << "NA" << endl;
    }
    return 0;
}
