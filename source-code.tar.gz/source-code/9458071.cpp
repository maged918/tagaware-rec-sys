//Language: GNU C++0x


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
#include <numeric>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <fstream>

#define REP(I, N) for (int I = 0; I < (N); ++I)
#define PER(I, N) for (int I = (N); I >= 0; --I)
#define PERR(I, A, B) for (int I = (A); I >= (B); --I)
#define REPP(I, A, B) for (int I = (A); I <  (B); ++I)
#define REPN(I, A, B) for (int I = (A); I <= (B); ++I)
#define REPC(I, A, C) for (int I = (A); (C); ++I)
#define REPPP(I, A, B, C) for (int I = (A); I <  (B); I += C)
#define RI(X) scanf("%d", &(X))
#define RII(X, Y) scanf("%d%d", &(X), &(Y))
#define RIII(X, Y, Z) scanf("%d%d%d", &(X), &(Y), &(Z))
#define RIIII(X, Y, Z, W) scanf("%d%d%d%d", &(X), &(Y), &(Z), &(W))
#define DRI(X) int (X); scanf("%d", &X)
#define DRII(X, Y) int X, Y; scanf("%d%d", &X, &Y)
#define DRIII(X, Y, Z) int X, Y, Z; scanf("%d%d%d", &X, &Y, &Z)
#define DRIIII(X, Y, Z, W) int X, Y, Z, W; scanf("%d%d%d%d", &X, &Y, &Z, &W)
#define RS(X) scanf("%s", (X))
#define LEN(X) int(strlen(X))
#define SZ(X) int((X).size())
#define SUM(X, N) accumulate(X, X + (N), 0)
#define MS0(X) memset((X), 0, sizeof(X))
#define MSI(X) memset((X), 0xFF, sizeof(X))
#define F first
#define S second
#define MP make_pair
#define PB push_back

#ifdef DK
const int MAX = 100 + 11;
#else
const int MAX = 1e2 + 11;
#endif

using namespace std;

vector<pair<int, int>> adj[MAX];
int N, M, K, W[MAX][MAX];

static int f(int v, const int &color, const int &end) {
  if (W[v][color]) {
    return 0;
  }
  if (v == end) {
    return 1;
  }
  W[v][color] = 1;
  int result = 0;
  REP(i, SZ(adj[v])) {
    if (adj[v][i].S == color) {
      result |= f(adj[v][i].F, color, end);
    }
  }
  return result;
}

static int f(int u, int w) {
  int result = 0;
  REP(i, SZ(adj[u])) {
    result += f(u, adj[u][i].S, w);
  }
  return result;
}

int main() {
#ifdef DK
  freopen("in.txt", "r", stdin);
//  freopen("out.txt", "w", stdout);
#endif
  RII(N, M);
  REP(i, M) {
    DRIII(x, y, c);
    adj[x].PB(MP(y, c));
    adj[y].PB(MP(x, c));
  }
  RI(K);
  REP(i, K) {
    DRII(x, y);
    MS0(W);
    printf("%d\n", f(x, y));
  }
  return 0;
}