//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define REP(i,n) for(int i=0; i<n; i++)
#define R(x) scanf("%d",&x)
typedef long long int64;
typedef pair<int,int> pii;

#define N 200100
vector<int> g[N],f[N],vc;
int us[N],vis[N],cyc;

void dfs(int x) {
	us[x]=1;
	REP(i,g[x].size()) {
		int y=g[x][i];

		if (us[y]==1) cyc=1;
		if (!us[y]) dfs(y);
	}
	us[x]=2;
}

void dfsu(int x) {
	if (vis[x]) return;
	vis[x]=1;

	vc.push_back(x);

	REP(i,f[x].size())
		dfsu(f[x][i]);
}

int main() {
	int n,m,a,b;

	while (R(n),R(m)==1) {
		REP(i,n) {
			g[i].clear();
			f[i].clear();
		}

		REP(i,m) {
			R(a),R(b);
			a--; b--;
			g[a].push_back(b);

			f[a].push_back(b);
			f[b].push_back(a);
		}

		int res=0;
		memset(us,0,sizeof(us));
		memset(vis,0,sizeof(vis));

		cyc=0;
		REP(i,n)
			if (!vis[i]) {
				cyc=0;
				vc.clear();
				dfsu(i);

				REP(j,vc.size())
					if (!us[vc[j]])
						dfs(vc[j]);

				res+=vc.size()-1+cyc;
			}

		printf("%d\n",res);
	}
	return 0;
}
