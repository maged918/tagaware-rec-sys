//Language: GNU C++


#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <cmath>
#include <climits>
#include <limits.h>
#include <string>
#include <stack>
#include <vector>
#include <set>
#include <map>
#include <queue>
#include <assert.h>
#include <cstring>
using namespace std;
#define rep(i, n) for (int (i) = 0, j1234 = n; (i) < j1234; (i) ++)
#define rep1(i, n) for (int (i) = 1, j1234 = n; (i) <= j1234; (i) ++)
#define For(i, a, b) for (int (i) = (a), ub1234=b; (i) <= ub1234; (i) ++)
#define db(x) {if(debug){cout << #x << " = " << (x) << endl;}}
#define dba(a, x, y) {if(debug){cout << #a << " :";For(i, (x), (y))cout<<" "<<(a)[(i)];cout<<endl;}}
#define clr(x) memset(x,0,sizeof(x));
#define mp make_pair
#define pb push_back
#define endl '\n'
#define ll long long
#define ld long double
const int INF = INT_MAX;
const ll INFL = LLONG_MAX;
const int output_precision = 15;
const ld pi = acos(-1);
const bool debug = true;
// const ll MOD = ;
unsigned ll combination(unsigned ll n, unsigned ll k) {
    if(k>n) return 0l;
    unsigned ll product = 1;
    for(unsigned ll i=1; i<=k; ++i) {
        product *= n--;
        product /= i;
    }
    return product;
}
int main() {
    ios_base::sync_with_stdio(0); cout.precision(output_precision); cout << fixed;
    cout.tie(0);
    
    int n, m;
    cin >> n >> m;
    
    int numPlayersPerTeam = n/m;
    int teamsWithExtra = n%m;
    int totalInSmaller = numPlayersPerTeam*(m-teamsWithExtra);
    int totalInLarger = (numPlayersPerTeam+1)*teamsWithExtra;
    ll numPairsSmall = (m-teamsWithExtra) * combination(numPlayersPerTeam, 2)+teamsWithExtra*combination(numPlayersPerTeam+1, 2);

    int playersLeftOver = n-(m-1);
    ll numPairsLarge = combination(playersLeftOver, 2);
    cout << numPairsSmall << " " << numPairsLarge << endl;

}