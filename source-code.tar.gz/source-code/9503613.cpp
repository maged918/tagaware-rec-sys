//Language: GNU C++0x


#include <iostream>
#include <string>

using namespace std;

int main() {
    string in;
    getline(cin, in);
    int right = in.size() - 1, left = 0, discrep_index = -1;
    char symb = in[in.size()/2];
    auto isPolyndrom = [](string& s, int ignor_pos) {
        int right = s.size() - 1, left = 0;
        while (right > left) {
            if (right == ignor_pos) right--;
            if (left == ignor_pos) left++;
            if (s[right] != s[left]) return false;
            --right;
            ++left;
        }
        return true;
    };
    while (right > left) {
        if (in[right] != in[left]) {
            if (isPolyndrom(in, right)) {
                symb = in[right];
                discrep_index = left;
                break;
            } else if (isPolyndrom(in, left)) {
                symb = in[left];
                discrep_index = right + 1;
                break;
            } else { cout << "NA" << endl; return 0; }
        } else { right--; left++; }
    }
    if (discrep_index == -1) { discrep_index = in.size() / 2; }
    in.insert(discrep_index, 1, symb);
    cout << in << endl;
    return 0;
}