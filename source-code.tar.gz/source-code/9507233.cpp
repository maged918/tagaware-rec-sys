//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;

int memo[30005][605];
int islands[30005],maxi,d,mid=300;

int solve(int curr,int last){
    //cout<<curr<<" "<<last<<endl;
    if(memo[curr][last+mid]!= -1)return memo[curr][last+mid];
    if(curr>maxi)return 0;
    int ans = 0;
    int sobra = d + last;
    for(int i=-1;i<2;i++){
        if(sobra+i > 0 and curr+sobra+i<30005)
        ans = max(ans,solve(curr+sobra+i,last+i)+islands[curr+sobra+i]);
    }
    return memo[curr][last+mid]=ans;
}

int main(){
    int n,t;cin>>n>>d;
    maxi = 0;
    memset(islands,0,sizeof islands);
    for(int i=0;i<n;i++){cin>>t;islands[t]++;maxi = max(maxi,t);}
    memset(memo,-1,sizeof memo);
    cout<<solve(d,0)+(islands[d])<<endl;
}
