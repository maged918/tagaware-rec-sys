//Language: MS C++


#include <iostream>
#include <map>
#include <vector>

using namespace std;

int main(){
	int n, k; cin >> n >> k;
	vector<int> m, mm; m.resize(n); mm.resize(n);
	map<int, int> mk;
	map <int, int>::iterator cur;
	for (int i = 0; i < n; i++){
		cin >> m[i];
		mm[i] = i;
	}
	for (int i = 0; i < n-1; i++)
	for (int j = 0; j < n-1; j++)
	if (m[j]>m[j + 1]){
			swap(m[j], m[j + 1]);
			swap(mm[j], mm[j + 1]);
		}
	int sum = 0;
	vector<int> jj;
	for (int i = 0; i < n;i++)
	if (sum + m[i] <= k){
		jj.push_back(mm[i]);
		sum += m[i];
	}
	cout << jj.size() << endl;
	for (int i = 0; i < jj.size(); i++)
		cout << jj[i]+1 << " ";
	return 0;
}