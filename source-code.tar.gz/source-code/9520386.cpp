//Language: GNU C++


#include<iostream>
#include<fstream>
#include<cstdio>
#include<vector>
#include<string>
#include<cstring>
#include<queue>
#include<map>
#include<set>
#include<algorithm>
#include<iomanip>
#include<bitset>
using namespace std;

const int N = 1000;
int n, k, x[N], p[N];

bool cmp(int a, int b) {
    return x[a] < x[b];
}

int main() {
    int i, j;
    //freopen("ttt", "r", stdin);

    cin >> n >> k;

    for(i = 1; i <= n; ++i) {
        cin >> x[i];
    p[i] = i;
    }

    sort(p + 1, p + n + 1, cmp);

    int sum = 0;
    vector<int> rez;
    for(i = 1; i <= n; ++i) {
        if(sum + x[p[i]] > k)
            break;
        rez.push_back(p[i]);
        sum += x[p[i]];
    }

    cout << rez.size() << "\n";

    for(i = 0; i < rez.size(); ++i)
        cout << rez[i] << " ";

    return 0;
}
