//Language: GNU C++


// Coded by Ankush Sharma .
// Library ...
#include<iostream>
#include<cstring>
#include<sstream>
#include<stdio.h>
#include<cstdlib>
#include<cmath>
#include<limits.h>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<algorithm>

#define ll long long
#define sf(a) scanf("%d",&a)
#define sf2(a,b) scanf("%d%d",&a,&b)
#define pf(a) printf("%d",a)
#define pf2(a,b) printf("%d%d",a,b)
#define sfc(a) scanf("%c",&a)
#define sfc2(a,b) scanf("%c%c",&a,&b)
#define pfc(a) printf("%c",a)
#define pfc2(a,b) printf("%c%c",a,b)
#define pfs(s) printf("%s",s)
using namespace std;
int k, n;
void  dp(int arr[], int n, int k)
{
    int memo[k+1][n+1];
    for(int i=0;i<=n;i++) memo[0][i]=0;
    for(int i=0;i<=k;i++) memo[i][0]=0;
    
    for(int i=1;i<=k;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(arr[j]<=i)
            {
                memo[i][j]=max(memo[i-arr[j]][j-1]+1, memo[i][j-1]);
            }
            else memo[i][j]=memo[i][j-1];
        }    
    }
    pf(memo[k][n]); pfs("\n");
    int ins=n, day=k;
    while(ins>0 && day>0)
    {
        while(ins-1>0 && memo[day][ins]==memo[day][ins-1]) 
            ins--;
        if(memo[day][ins])
            pf(ins); pfs(" ");
        day=day-arr[ins]; ins--; 
    }
    return ;
}

int main()
{
    sf2(n,k);
    int days[n+1]; days[0]=0;
    for(int i=1;i<=n;i++)
        sf(days[i]);
    dp(days,n,k);
    return 0;    
}
