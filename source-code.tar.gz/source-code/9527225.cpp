//Language: GNU C++0x


#include<iostream>
#include<string>
#include<map>
#include<vector>
#include<list>
#include<queue>
#include<stack>
#include<deque>
#include<set>
#include<bitset>
#include<functional>
#include<utility>
#include<iterator>
#include<algorithm>
#include<sstream>
#include<fstream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<ctime>
#include<cstring>
#include<iomanip>
using namespace std;
#define len(val) static_cast<int>(val.size())
#define rep(i, N) for(int i=0; i<N; i++)
typedef long long ll;
typedef pair<int, int> P;


int main()
{
    cin.tie(0);
    ios::sync_with_stdio(false);

    int h;
    ll n;
    cin >> h >> n;
    ll exits[h+1];
    {
        ll tmp = (ll)pow(2, h) + n - 1;
        int cnt = h;
        exits[cnt] = tmp;
        cnt--;
        while(tmp > 0){
            tmp /= 2;
            exits[cnt] = tmp;
            cnt--;
        }
    }
    //rep(i, h+1) cout << exits[i] << endl;
    ll now = 1;
    int height = 0;
    ll res = 0;
    int dir = -1;
    while(true){
        if(height == h && exits[height] == now) break;
        if(height > h) break;
        if(dir == -1){
            if(exits[height+1] == 2*now){
                now = 2*now;
                res += 1;
                dir = 1;
            }else{
                now = 2*now + 1;
                res++;
                res += (ll)pow(2, h-height) - 1;
                dir = -1;
            }
        }else{
            if(exits[height+1] == 2*now+1){
                now = 2*now + 1;
                res += 1;
                dir = -1;
            }else{
                now = 2*now;
                res++;
                res += (ll)pow(2, h-height) - 1;
                dir = 1;
            }
        }
        height++;
    }
    cout << res << endl;
}
