//Language: GNU C++0x


#include <iostream>
#include <cstdio>

using std::cin;
using std::cout;
using std::endl;

typedef long long ll;

ll *pow;

int main()
{
	/*
	#pragma message "FREOPEN"
	freopen("tmp", "r", stdin);
//	*/
	
	ll h, n;
	cin >> h >> n;
	--n;
	
	pow = new ll[h + 1];
	pow[0] = 1;
	for (int q = 1; q < h + 1; ++q)
		pow[q] = pow[q - 1] * 2;
	
	ll iter = 0;
	ll res = 0;
	bool left = true;
	while (iter != h)
	{
		ll curPow = pow[h - iter - 1];
//		cout << n << ' ' << curPow << ' ' << res << endl;
		if ((n >= curPow && left) || (n < curPow && !left))
			res += curPow * 2 - 1;
		else
			left = !left;
		n %= curPow;
		++iter;
	}
	
	cout << res + h << endl;
	
	return 0;
}
