//Language: GNU C++


//Pham Huu Canh
//D. The Maths Lecture

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>

#define max64 9223372036854775807LL
#define max32 2147483647
#define maxty 1001001001
#define max16 32767
#define EPS 1e-8
#define ll long long
#define ull unsigned long long
#define PB push_back
#define MP make_pair
#define PQ priority_queue
#define LB lower_bound
#define UB upper_bound
#define timmax(x, y)    ((x) > (y) ? (x) : (y))
#define timmin(x, y)    ((x) < (y) ? (x) : (y))
#define fori(i, n)      for((i) = 0; (i) < (n); (i)++)
#define ford(i, n)      for((i) = (n-1); (i) >= 0; (i)--)
#define repi(i, a, b)   for((i) = (a); (i) <= (b); (i)++)
#define repd(i, a, b)   for((i) = (a); (i) >= (b); (i)--)
#define _all(tmpv)      tmpv.begin(), tmpv.end()

#define fi "d.inp"
#define fo "d.out"

using namespace std;

ll dp[1002][102][2];
ll p[1002], p10[1002];
int n, nk, MOD;

ll dfs(int idx, int rem, int state){
    if (rem == 0 && state)  return (idx ? (p10[idx-1] * 9) % MOD : 1);
    if (idx == 0)   return 0;
    ll &res = dp[idx][rem][state];
    if (res != -1)  return res;
    res = 0;
    int i;
    fori(i, 10)
        res += dfs(idx-1, (rem + (i * p[idx]) % nk) % nk, state || i), res %= MOD;
    return res;
}

void input()
{
    int i;
    
    scanf("%d %d %d", &n, &nk, &MOD);
    
    p[n] = 1 % nk;
    repd(i, n-1, 1) p[i] = (p[i+1] * 10) % nk;
    p10[0] = 1 % MOD;
    repi(i, 1, n)   p10[i] = (p10[i-1] * 10) % MOD;
    
    memset(dp, -1, sizeof(dp));
    printf("%I64d\n", dfs(n, 0, 0));
}

int main()
{
    //freopen(fi,"r",stdin);
    //freopen(fo,"w",stdout);

    input();

    return 0;
}
