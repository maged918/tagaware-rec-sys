//Language: GNU C++0x


#include<bits/stdc++.h>
using namespace std;

#define PB                  push_back
#define MP                  make_pair
#define SZ                  size()
#define all(v)              v.begin(), v.end()
#define REP(i, n)           for(int i=0; i<(int)n; i++)
#define ITR(i, j, n)        for(int i=j ; i<(int)n; i++)
#define MEM(array, value)   memset(array, value, sizeof array)
#define READ(filename)      freopen(filename, "r", stdin)
#define WRITE(filename)     freopen(filename, "w", stdout)
#define PII                 pair<int, int>
#define FR                  first
#define SC                  second
#define LL                  long long
#define SI(a)               scanf("%d", &a)


vector<int> as(1000002);
vector<int>look(100002);

int bin_search(int high, int low, int target)
{
    int mid = (high + low) / 2;
    if(target <= as[mid] and target > as[mid-1]) return mid;

    else if(target > as[mid]) return bin_search(high, mid+1, target);

    else if(target < as[mid]) return bin_search(mid-1, low, target);
}


int main()
{
    //freopen("test.in", "r", stdin);
    //freopen("test.out", "w", stdout);
    int n, m, a; cin >> n;

    REP(i, n){
        cin >> as[i];
        if(i != 0){
            as[i] += as[i-1];
        }
    }

    cin >> m;

    REP(i, m) cin >> look[i];

    REP(i, m){
        if(look[i] <= as[0]) cout << "1" << endl;

        else cout << bin_search(n-1, 0, look[i]) + 1 << endl;
    }


    return 0;
}
