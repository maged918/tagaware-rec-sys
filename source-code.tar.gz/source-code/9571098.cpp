//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS
#include <functional>
#include <algorithm>
#include <memory.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <bitset>
#include <string>
#include <cstdio>
#include <vector>
#include <queue>
#include <stack>
#include <cmath>
#include <ctime>
#include <list>
#include <set>
#include <map>
using namespace std;

const int N = 100000;
int n, m;
vector < pair < int,int > > g[N];
pair < pair < int,int >,int > e[N];
int d[N];
bool used[N];
int dp[N];
int p[N];
set < pair < int,int > > a;

void bfs()
{
	d[0] = 0;
	used[0] = true;
	queue < int > q;
	q.push(0);
	while (!q.empty())
	{
		int v = q.front();
		q.pop();
		for (int i = 0; i < g[v].size(); i++)
		{
			int to = g[v][i].first;
			if (!used[to])
			{
				used[to] = true;
				d[to] = d[v] + 1;
				q.push(to);
			}
		}
	}
}

int solve(int v)
{
	if (dp[v] != -1) return dp[v];
	if (v == 0) return 0;
	int res = -1;
	for (int i = 0; i < g[v].size(); i++)
	{
		int to = g[v][i].first;
		if (d[v] == d[to] + 1)
		{
			int tmp = solve(to) + g[v][i].second;
			if (tmp > res)
			{
				res = tmp;
				p[v] = to;
			}
		}
	}
	return dp[v] = res;
}

int main()
{
#ifdef _DEBUG
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
	scanf("%d%d", &n, &m);
	for (int i = 0; i < m; i++)
	{
		int u, v, z; scanf("%d%d%d", &u, &v, &z); u--; v--;
		g[u].push_back(make_pair(v, z));
		g[v].push_back(make_pair(u, z));
		e[i] = make_pair(make_pair(min(u, v), max(u, v)), z);
	}
	bfs();
	memset(dp, -1, sizeof(dp));
	solve(n - 1);
	for (int v = n - 1; v > 0; v = p[v])
	{
		a.insert(make_pair(min(v, p[v]), max(v, p[v])));
	}
	int ans = 0;
	for (int i = 0; i < m; i++)
	{
		ans += (e[i].second == 0 && a.find(e[i].first) != a.end()) || (e[i].second == 1 && a.find(e[i].first) == a.end()) ? 1 : 0;
	}
	printf("%d\n", ans);
	for (int i = 0; i < m; i++)
	{
		if ((e[i].second == 0 && a.find(e[i].first) != a.end()) || (e[i].second == 1 && a.find(e[i].first) == a.end()))
		{
			printf("%d %d %d\n", e[i].first.first + 1, e[i].first.second + 1, 1 - e[i].second);
		}
	}
    return 0;
}