//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

int dp[1100];
int w[333];

int main()
{
    int m, t, r;
    while(scanf("%d %d %d",&m,&t,&r)!=EOF)
    {
        memset(dp, 0, sizeof dp);
        for(int i= 1; i<= m; i++)
            scanf("%d",&w[i]);
        if(t< r)
        {
            printf("-1\n");     
            continue;
        }
        int ans= 0;
        for(int i= 1; i<= m; i++)
        {
            int num= w[i]+ 300;
            int xu= r- dp[num];
        //  printf("%d\n",xu);
            if(xu> 0)
            {
                for(int j= 1; j<= xu; j++)
                {
                    ans++;
                    for(int u= num-j+1,s= 1; s<= t; u++,s++)
                        dp[u]++;
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}