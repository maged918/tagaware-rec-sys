//Language: GNU C++


    #include <algorithm>  
    #include <iostream>  
    #include <cstring>    
    #include <cstdio>    
    #include <vector>  
    #include <queue>  
    #include <map>  
      
    using namespace std;    
      
    const int MAX = 100010;  
    int n,m;  
    int U[MAX],V[MAX],C[MAX];//input  
    int au[MAX],av[MAX],ac[MAX];//output  
    int pre[MAX],dp[MAX];  
    int dis[MAX],vis[MAX];  
      
    struct edge{  
        int v,c;  
        edge() {}//构造函数  
        edge(int v, int c):v(v),c(c) {}//构造函数  
    };  
      
    vector <edge> vt[MAX];//邻接表  
    map <pair<int, int>, int> mp;//边的映射  
      
    void SPFA(){  
        memset(dis, 0x3f, sizeof(dis));  
        dis[1] = 0, vis[1] = 1;  
        queue <int> Q;  
        Q.push(1);  
        while(!Q.empty()){  
            int u = Q.front();  
            vis[u] = 0;  
            Q.pop();  
            for(int i=0; i<vt[u].size(); i++){  
                int v = vt[u][i].v, c = vt[u][i].c;  
                if(dis[v] > dis[u] + 1){//松弛操作1：最短路  
                    dis[v] = dis[u] + 1;  
                    if(!vis[v]){  
                        vis[v] = 1;  
                        Q.push(v);  
                    }  
                }  
                if(dis[v] == dis[u] + 1 && dp[u] + c >= dp[v]){//松弛操作2：最短路中可用的路最多  
                    dp[v] = dp[u] + c;  
                    pre[v] = u;//记录正确的前驱  
                }  
            }  
        }  
    }  
      
      
    int main(){  
        scanf("%d%d",&n,&m);  
        for(int i=1; i<=m; i++){  
            scanf("%d%d%d",&U[i], &V[i], &C[i]);  
            vt[U[i]].push_back(edge(V[i], C[i]));  
            vt[V[i]].push_back(edge(U[i], C[i]));  
        }  
        SPFA();  
        int now = n;  
        while(now != 1){//将最短路中的边放到映射里  
            mp[make_pair(now, pre[now])] = 1;  
            now = pre[now];  
        }  
        int len = 0;  
        for(int i=1; i<=m; i++){  
            bool flag = mp[make_pair(U[i],V[i])] || mp[make_pair(V[i], U[i])];  
            if(flag && C[i] == 0)  
                au[len] = U[i], av[len] = V[i], ac[len++] = !C[i];  
            else if(!flag && C[i] == 1)  
                au[len] = U[i], av[len] = V[i], ac[len++] = !C[i];  
        }  
        cout << len << endl;  
        for(int i=0; i<len; i++)  
            cout << au[i] << " " << av[i] << " " << ac[i] << endl;  
        return 0;  
    } 
			 	 			  	 			 			 	  		   	