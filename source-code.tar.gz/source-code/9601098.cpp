//Language: GNU C++


#include<iostream> 
#include<assert.h>
#include<algorithm>
#include<queue>
#include<stack>
#include<numeric>
#include<vector>
#include<set>
#include<sstream>
#include<cstring>
#include<string>
#include<stdio.h>
#include<cmath>
#include<cstdlib>
#include<map>
using namespace std;
#define eps 1e-8
#define inf (1<<30)
#define pi (2*acos(0.0))
#define all(a) a.begin(),a.end()
#define mem(a,v) memset(a,v,sizeof(a))
#define rep(i,b,e) for((i)=b;(i)<(e);(i)++)
#define rev(i,b,e) for((i)=e-1;(i)>=(b);(i)--)
#define fi(b,e) for((i)=b;(i)<(e);(i)++)
#define fj(b,e) for((j)=b;(j)<(e);(j)++)
typedef long long LL;
typedef vector<int>vi;
typedef vector<string>vs;
typedef pair<int,int>pri;
typedef map<string,int>msi;
typedef map<vector<int>,int>mvi;
inline bool iseq(double x,double y){if(fabs(x-y)<eps)return true;return false;} 
template<typename T>inline T hpt(T x1,T y1,T x2,T y2){return hypot(x1-x2,y1-y2);}
template<typename T>inline T gcd(T a,T b){if(!b)return a;else return gcd(b,a%b);}
template<typename T>inline void extended_euclid(T a,T b,T &x,T &y){if(a%b==0)x=0,y=1;else{extended_euclid(b,a%b,x,y);T temp=x;x=y;y=-y*(a/b)+temp;}}
template<typename T>inline T bigmod(T b,T p,T m){if(!p)return 1;else if(!(p%2)){T x=bigmod(b,p/2,m);return x*x;}else return ((b%m)*bigmod(b,p-1,m))%m;}
#define PS 5
int prime[PS/32+1];
void setbit(int i){int p=i>>5,q=i&31;prime[p]|=(1<<q);}
bool checkbit(int i){int p=i>>5,q=i&31;return prime[p]&(1<<q)?true:false;}
void buildprime(int n){int i,j,k=sqrt(double(n));prime[0]=3;for(i=4;i<n;i+=2)setbit(i);for(i=3;i<=k;i+=2){if(!checkbit(i)){int ii=i+i;for(j=i*i;j<n;j+=ii)setbit(j);}}}


int sum,r,n,N;
#define S 605
int dp[S][S],Next[S][S],L[S], R[S];
int tot;
int doit(int b, int e){
    int &ret = dp[b][e];
    if(ret > -1)return ret;
    ret = 0;
    if(b > e)return ret = 1;
    if(b == e){
        Next[b][e] = 0;
        if(1 >= L[e] && 1 <= R[e])return ret = 1;
        else {
            Next[b][e] = -1;
            return ret = 0;
        }    
    }
    for(int i = L[b]; i <= R[b]; ++i)if(i % 2){
        int koto = i / 2;
        if(koto > e - b)break; 
        int ra = doit(b + 1, b + koto);
        int rb = doit(b + koto + 1, e);
        if(ra && rb){
            ret = 1;
            Next[b][e] = koto;
            return ret;
        }
    }
    return ret;
}
void printString(int b, int e){
    if(b > e)return;
    int koto = Next[b][e];
    if(koto < 0)return;
    printf("(");
    //if(n != 600)printf("(");
    tot++;
    if(koto)printString(b + 1, b + koto);
    printf(")");
    //if(n != 600)printf(")");
    tot++;
    if(b + koto < e)printString(b + koto + 1, e);
}
int main() {
	int i,j,k;
    //freopen("1.txt", "r", stdin);
    while(scanf("%d",&n) == 1){
        tot = 0;
        fi(0, n)scanf("%d%d", &L[i], &R[i]);
        mem(dp, -1);
        mem(Next, -1);
        int ok = doit(0, n - 1);
        if(ok){
            printString(0, n - 1);
            printf("\n");
            //if(n == 600)printf("tot = %d\n", tot);
            //assert(tot == n * 2); 
        }else printf("IMPOSSIBLE\n");
    }
	return 0;
}








