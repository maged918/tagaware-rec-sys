//Language: MS C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <queue>
#include <cstring>
#define ll long long int
using namespace std;
int main()
{
   //freopen("in.txt", "r", stdin);
   ll n;
   int h;
   scanf("%d %I64d", &h, &n);
   vector<int> v;
   ll s = 1;
   for(int i = 0; i < h; i++) s *= 2;
   ll n2 = s + n - 1;
   ll n4 = n2;
   ll n3 = s * 2;
   while(n2 != 1)
   {
	   if(n2 % 2 != 0) v.push_back(1);
	   else v.push_back(0);
	   n2 = n2 / 2;
   }
   reverse(v.begin(), v.end());
   int j = 0;
   ll res = 1;
   ll pos = 1;
   for(int i = 0; i < v.size(); i++)
   {
	   if(v[i] != j) 
	   {
		   pos *= 2;
		   if(!j) pos++;
		   res += (n3 / 2);
		   if(pos == n4) 
		   {
			   res--;
			   break;
		   }
	   }
	   else
	   {
		   pos *= 2;
		   if(j) pos++;
		   res += 1;
		   if(pos == n4)
		   {
			   res--;
			   break;
		   }
		   if(j) j = 0;
		   else j = 1;
	   }
	   n3 = n3 / 2;
   }
   printf("%I64d\n", res);
   return 0;
}
