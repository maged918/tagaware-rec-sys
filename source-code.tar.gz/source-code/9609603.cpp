//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <string>
#include <map>
#include <vector>
#include <stack>
#include <queue>
#include <string.h>
#include <algorithm>
#include <math.h>

using namespace std;

int a[610];

int main(){
	int m,t,r;
	cin>>m>>t>>r;
	if(r>t){
		printf("-1\n");
		return 0;
	}
	for(int i=1;i<=m;i++){
		int w;
		cin>>w;
		int cnt=0;
		for(int i=1;i<=t;i++){
			cnt+=a[w+300-i];
		}
		for(int i=1;i<=r-cnt;i++){
			a[w+300-i]=1;
		//	cout<<w+300-i<<endl;
		}
	}
	int ans=0;
	for(int i=0;i<=600;i++){
		ans+=a[i];
	}
	printf("%d\n",ans);
	return 0;
}




