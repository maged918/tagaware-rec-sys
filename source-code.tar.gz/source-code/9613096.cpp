//Language: GNU C++


#include<iostream>
#include<cmath>
using namespace std;
int main(){
    int n;
    cin>>n;
    if(n<=10||21<n&&n<=25)
        cout<<0<<endl;
    if(n>10&&n<20)
        cout<<4<<endl;
    if(n==20)
        cout<<15<<endl;
    if(n==21)
        cout<<4<<endl;
    return 0;
}
