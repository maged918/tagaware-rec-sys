//Language: GNU C++


#pragma comment(linker,"/STACK:100000000000,100000000000")

#include <cstdio>
#include <cmath>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <ctime>

using namespace std;

#define sz(a) int((a).size())
#define F first
#define S second
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef unsigned long long ull;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;
typedef pair <double, double> pdd;

const double eps=1E-9;
const double Exp=2.718281828459045;
const double Pi=3.1415926535897932;

const int NMAX=1000 + 5;
const int MMAX=100 + 5;
const int INF=1000000000;
const int BS=1000000007;

template <typename T> inline T abs(const T a){
    if (a<0) return -a;
    return a;
}
template <typename T> inline T sqr(const T& a){
    return a*a;
}

int res[NMAX][MMAX][2]={0};

int main(){
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        freopen("output.txt","w",stdout);
    #endif
    ios::sync_with_stdio(false);
    int n,k,m;
    cin >> n >> k >> m;
    int i,j,t;
    int pw[NMAX];

    pw[0]=1;
    for (j=1;j<=n;j++){
        pw[j]=(pw[j-1]*10)%k;
    }

    for (i=1;i<=n;i++){
        for (j=1;j<=9;j++)
            res[i][(j*pw[i-1])%k][0]=(res[i][(j*pw[i-1])%k][0]+1)%m;
    }
    res[1][0][1]=1%m;

    for (i=1;i<n;i++){
        for (j=1;j<k;j++){
            for (t=1;t<=9;t++){
                res[i+1][(pw[i]*t+j)%k][0]=(res[i+1][(pw[i]*t+j)%k][0]+res[i][j][0]*1ll+res[i][j][1])%m;
            }
            res[i+1][j][1]=(res[i+1][j][1]*1ll+res[i][j][0]*1ll+1ll*res[i][j][1])%m;
        }
    }
    int dp=0;
    int sum=0;
    dp=(res[1][0][0])%m;
    sum=(dp)%m;
    for (i=2;i<=n;i++){
        dp=(9ll*sum+res[i][0][0])%m;
        sum=(sum*1ll+dp)%m;
    }
    cout << dp%m << endl;
    return 0;
}

