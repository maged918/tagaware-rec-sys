//Language: GNU C++0x


#include <string>
#include <vector>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <unordered_map>
using namespace std;

#define all(V) (V).begin(), (V).end()

typedef vector<int> vi;
typedef vector<vi> vvi;

bool isconnected(const vvi& graph, int v) {
	int N = graph.size();
	if (v == -1) v = 0;
	vector<bool> mark(N, false);
	queue<int> Q;
	Q.push(v);
	mark[v] = true;
	while (!Q.empty()) {
		int w = Q.front(); Q.pop();
		for (int x : graph[w]) if (!mark[x]) {
			mark[x] = true;
			Q.push(x);
		}
	}
	for (bool x : mark) if (!x) return false;
	return true;
}

void build(vi& ans, vvi& graph, int node) {
 	while (!graph[node].empty()) {
 		int x = graph[node].back(); graph[node].pop_back();
		build(ans, graph, x);
	}
	ans.push_back(node);
}

int main() {
	int n;
	scanf("%d", &n);
	vvi graph;
	vi indegree;
	unordered_map<string, int> mapa;
	for (int i = 0; i < n; ++i) {
		char buf[10];
		scanf(" %s", buf);
		char c = buf[2];
		buf[2] = '\0';
		int from = mapa.insert(make_pair(buf, mapa.size())).first->second;
		buf[2] = c;
		int to = mapa.insert(make_pair(buf+1, mapa.size())).first->second;
		if (from >= graph.size()) {
			graph.push_back(vi());
			indegree.push_back(0);
		}

		if (to >= graph.size()) {
			graph.push_back(vi());
			indegree.push_back(0);
		}
		graph[from].push_back(to);
		indegree[to]++;
	}
	int extra[2] = {-1,-1};
	for (int i = 0; i < graph.size(); ++i) {
		int x = graph[i].size() - indegree[i];
		if (x == 0) continue;
		if (abs(x) > 1) x = 300;
		x = (x+1)/2;
		if (x > 1 || extra[x] != -1) {
			printf("NO\n");
			return 0;
		}
		extra[x] = i;
	}
	if (!isconnected(graph, extra[1])) {
		printf("NO\n");
		return 0;
	}
	printf("YES\n");

	vi ans;
	build(ans, graph, max(0, extra[1]));
	reverse(all(ans));
	vector<string> mapainv(mapa.size());
	for (auto& x : mapa) mapainv[x.second] = x.first;
	string output(n+2, 'a');
	output[0] = mapainv[ans[0]][0];
	for (int i = 0; i < n+1; ++i) output[i+1] = mapainv[ans[i]][1];
	printf("%s\n", output.c_str());
	return 0;
}
