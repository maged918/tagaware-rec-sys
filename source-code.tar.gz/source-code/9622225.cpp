//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <vector>
#include <cmath>
#include <map>
#include <cstring>


using namespace std;

vector<int> e[66000];
int out[66000],in[66000],cnt[66000];
string ans;

void dfs(int i)
{
    while(cnt[i]<e[i].size())
    {
        dfs(e[i][cnt[i]++]);
    }
    ans+=(char)i%256;
}
int main()
{
    int n,u,v,start=0;
    scanf("%d",&n);
    string s;
    for(int i=0;i<n;++i)
    {
        cin>>s;
        u=s[0]*256+s[1];
        start=u;
        v=s[1]*256+s[2];
        e[u].push_back(v);
        out[u]++;in[v]++;
    }
    int l=0,r=0;
    for(int i=0;i<66000;++i)
    {
        int d=out[i]-in[i];
        if(d==1){ l++; start=i; }
        else if(d==-1) r++;
        else if(d!=0)
        {
            printf("NO\n");
            return 0;
        }
        if(l>1 || r>1)
        {
            printf("NO\n");
            return 0;
        }
    }
    dfs(start);
    ans+=(char)(start/256);
    reverse(ans.begin(),ans.end());
    if(ans.length()!=n+2) printf("NO\n");
    else cout<<"YES\n"<<ans<<endl;
    return 0;
}
