//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <set>
using namespace std;
#define MAXN 1<<16
struct Point {
    int id, num, xor_num;
    bool operator < (const Point& p) const {
        if (num != p.num)
            return num < p.num;
        return id < p.id;
    }
} p[MAXN];
set<Point> s;
set<Point>::iterator it;
set<int> ans[MAXN];
set<int>::iterator jt;
int n, m;
int main () {
//  freopen ("in.txt", "r", stdin);
    while (~scanf ("%d", &n)) {
        s.clear();
        m = 0;
        for (int i = 0; i < n; i ++) {
            scanf ("%d%d", &p[i].num, &p[i].xor_num);
            m += p[i].num;
            p[i].id = i;
            s.insert (p[i]);
            ans[i].clear();
        }
        Point temp;
        while (!s.empty()) {
            temp = *s.begin();
            s.erase(s.begin());
            if (temp.num) {
                if (temp.xor_num < temp.id) {
                    ans[temp.id].insert (temp.xor_num);
                }
                else if (temp.id < temp.xor_num) {
                    ans[temp.xor_num].insert (temp.id);
                }
                it = s.find(p[temp.xor_num]);
                if (it != s.end()) {
                    s.erase(it);
                    p[temp.xor_num].xor_num ^= temp.id;
                    p[temp.xor_num].num --;
                    s.insert (p[temp.xor_num]);
                }
            }
        }
        printf ("%d\n", m>>1);
        for (int i = 0; i < n; i ++) {
            for (jt = ans[i].begin(); jt != ans[i].end(); jt ++) {
                printf ("%d %d\n", i, *jt);
            }
        }
    }
    return 0;
}