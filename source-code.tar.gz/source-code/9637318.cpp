//Language: GNU C++


#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL n,k,m;
LL dp[1005][105];
LL tenm[1005];
int main()
{
//  freopen("input.txt","r",stdin);
    while(scanf("%I64d%I64d%I64d",&n,&k,&m)==3)
    {
        tenm[0]=1%k;
        for(int i=1;i<=1000;i++)tenm[i]=tenm[i-1]*10%k;
//      ninm[0]=1%m;
//      for(int i=1;i<=1000;i++)ninm[i]=ninm[i-1]*9%m;
        memset(dp,0,sizeof(dp));
//      for(int i=(n==1?1:0);i<10;i++)dp[1][i%k]++;
        dp[0][0]=1;
        for(int i=1;i<=n;i++)
        {
            dp[i-1][0]=1;
            for(int j=0;j<k;j++)
                for(int p=(i==n?1:0);p<10;p++)
                {
//                  cout<<(((j-tenm[i-1]*p)%k+k)%k)<<endl;
//                  cout<<dp[i][j]<<endl;
                    dp[i][j]=(dp[i][j]+dp[i-1][((j-tenm[i-1]*p)%k+k)%k])%m;
//                  cout<<dp[i][j]<<endl;
//                  cout<<endl;
                }
        }

        LL ans=0;
        LL tot=1;
        for(int i=1;i<=n;i++)tot=(tot*(i==n?9:10))%m;
//      cout<<tot<<endl;
        for(int i=1;i<k;i++)ans=(ans+dp[n][i])%m;
        cout<<((tot-ans)%m+m)%m<<endl;
    }
    return 0;
}
