//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS

#include <algorithm>  
#include <iostream>  
#include <iomanip>  
#include <cstring>  
#include <climits>  
#include <complex>  
#include <fstream>  
#include <cassert>  
#include <cstdio>  
#include <bitset>  
#include <vector>  
#include <deque>  
#include <queue>  
#include <stack>  
#include <ctime>  
#include <set>  
#include <map>  
#include <cmath>  
#include <functional>  
#include <numeric>  
#pragma comment(linker, "/STACK:1024000000,1024000000")  
  
  
using namespace std;  
  
typedef long long ll;  
typedef long double ld;  
typedef pair<ll, ll> pll;  
typedef complex<ld> point;  
typedef pair<int, int> pii;  
typedef pair<pii, int> piii;  
typedef vector<int> vi;  
  
#define CLR(x,y) memset(x,y,sizeof(x))  
#define mp(x,y) make_pair(x,y)  
#define pb(x) push_back(x)  
#define lowbit(x) (x&(-x))  
#define MID(x,y) (x+((y-x)>>1))  
#define eps 1e-9  
#define PI acos(-1.0)  
#define INF 0x3f3f3f3f  
#define LLINF 1LL<<62  
  
//#define maxn  100010
#define inf 2000000000
#define ll long long
using namespace std;
template<class T>  
inline bool read(T &n)  
{  
    T x = 0, tmp = 1; char c = getchar();  
    while((c < '0' || c > '9') && c != '-' && c != EOF) c = getchar();  
    if(c == EOF) return false;  
    if(c == '-') c = getchar(), tmp = -1;  
    while(c >= '0' && c <= '9') x *= 10, x += (c - '0'),c = getchar();  
    n = x*tmp;  
    return true;  
}  
template <class T>  
inline void write(T n)  
{  
    if(n < 0)  
    {  
        putchar('-');  
        n = -n;  
    }  
    int len = 0,data[20];  
    while(n)  
    {  
        data[len++] = n%10;  
        n /= 10;  
    }  
    if(!len) data[len++] = 0;  
    while(len--) putchar(data[len]+48);  
}  

const int maxn = 100100;
ll h[maxn],a[maxn],fin[maxn],p;
int n,m,k;
int cnt[maxn];

bool check(ll mid)
{
    ll t=0;
    for(int i=1;i<=n;i++)
        if(fin[i]>mid)
        t+=(fin[i]-mid-1)/p+1;
    if(t>m*k)return 0;
    memset(cnt,0,sizeof(cnt));
    for(int i=1;i<=n;i++)
    {
        if(fin[i]>mid)
        for(ll j=(fin[i]-mid-1)%p+1;j<=fin[i]-mid;j+=p)
        {
            if(j<=h[i])++cnt[0];
            else if(j-h[i]>a[i]*(m-1))return 0; 
            else ++cnt[(j-h[i]-1)/a[i]+1];
        }
    }
    int ok=0;
    for(int i=0;i<m;i++)ok=max(0,ok+cnt[i]-k);
    return !ok;
}
ll b_search(ll l,ll r)
{
    while(l<r)
    {
        ll mid = (l+r)/2;
        if(check(mid))r=mid;
        else l=mid+1;
    }
    return l;
}
int main()
{
    while(read(n)&&read(m)&&read(k)&&read(p))
    {
        ll maxx=-1;
        for(int i=1;i<=n;i++)
        {
            read(h[i]),read(a[i]);
            fin[i]=h[i]+m*a[i];
        }
        write(b_search(0,50000000000001LL));
        putchar('\n');
    }
}