//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

const int N = 100;

int n, k;
pair<int, int> inst[N];
vector<int> ans;

int main(){
    //freopen("input.txt", "r", stdin);
    cin >> n >> k;
    for (int i = 0; i < n; i++){
        cin >> inst[i].first;
        inst[i].second = i + 1;
    }
    sort(inst, inst + n);
    int useDay = 0;
    for (int i = 0; i < n; i++){
        if (useDay + inst[i].first <= k){
            useDay += inst[i].first;
            ans.push_back(inst[i].second);
        }
    }
    cout << ans.size() << endl;
    for (int i = 0; i < ans.size(); i++)
        cout << ans[i] << ' ';
    return 0;
}
