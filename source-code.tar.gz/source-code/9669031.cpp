//Language: GNU C++0x


#include <iostream>
#include <vector>
#include <cstring>
#include <string>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <utility>

using namespace std;

typedef long long ll;
typedef long double ld;

const ll q = (ll)(1e9) + 7LL;

vector <vector <int> > graph, gRev;
int n;
vector <ll> cost;
vector <bool> visited;
vector <int> topsorted;
vector <int> color;
int cl = 0;

void topsort(int v) {
	if (visited[v])
		return;
	visited[v] = 1;
	for (int to: graph[v])
		topsort(to);
	topsorted.push_back(v);
}

void dfs(int v) {
	visited[v] = 1;
	color[v] = cl;
	for (int to: gRev[v]) {
		if (!visited[to])
			dfs(to);
	}
}

int main() {
//	freopen("input.txt", "r", stdin);
	cin >> n;
	cost.resize(n);
	graph.resize(n);
	gRev.resize(n);
	color.resize(n);
	for (int i = 0; i < n; ++i)
		cin >> cost[i];
	int m;
	cin >> m;
	visited.assign(n, 0);
	for (int i = 0, a, b; i < m; ++i) {
		cin >> a >> b;
		--a, --b;
		graph[a].push_back(b);
		gRev[b].push_back(a);
	}
	for (int i = 0; i < n; ++i)
		topsort(i);
	reverse(topsorted.begin(), topsorted.end());
	visited.assign(n, 0);
	for (int v: topsorted) {
		if (!visited[v]) {
			dfs(v);
			cl++;
		}
	}
	vector <int> bestcost(cl, 2000000000);
	vector <int> numbest(cl);
	for (int v = 0; v < n; ++v) {
		if (cost[v] < bestcost[color[v]]) {
			bestcost[color[v]] = cost[v];
			numbest[color[v]] = 1;
		}
		else if (cost[v] == bestcost[color[v]]) {
			numbest[color[v]]++;
		}
	}
	ll cst = 0,
	   numWays = 1;
	for (int v = 0; v < cl; ++v) {
		cst += bestcost[v];
		numWays = (numWays * numbest[v]) % q;
	}
	cout << cst << " " << numWays << endl;
	return 0;
}
