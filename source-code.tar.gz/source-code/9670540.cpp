//Language: GNU C++


#include <bits/stdc++.h>
#define MAX 123456
#define ALPHA 26
typedef long long int LL;
using namespace std;

struct trie
{
    trie *next[ALPHA];
    bool win,lose;
    trie()
    {
        for(int i=0;i<ALPHA;i++)
            next[i]=NULL;
        win=false;
        lose=false;
    }
};
trie * root;
void add_trie(string str)
{
    trie *curr=root;
    for(int i=0;str[i];i++)
    {
        int p=str[i]-'a';
        if(curr->next[p]==NULL)
        {
           curr->next[p]=new trie();
        }
        curr=curr->next[p];
    }
}

void dfs(trie *node)
{
    node->win=false;
    node->lose=false;
    bool isleaf=true;
    for(int i=0;i<ALPHA;i++)
    {
        if(node->next[i]!=NULL)
        {
            isleaf=false;
            dfs(node->next[i]);
            node->win=(node->win)|(!(node->next[i]->win));
            node->lose=(node->lose)|(!(node->next[i]->lose));
        }
    }
    if(isleaf)
    {
        node->lose=true;
    }
}

int main()
{
  //freopen("input.txt","r",stdin);
  int n,k;
  string str;
  cin>>n>>k;
  root=new trie();
  for(int i=0;i<n;i++)
  {
      cin>>str;
      add_trie(str);
  }
  dfs(root);
  if(root->win==false)
    cout<<"Second";
  else if(root->win==true&&root->lose==true)
    cout<<"First";
  else if(root->win==true&&root->lose==false)
  {
      if(k%2==1)
        cout<<"First";
      else
        cout<<"Second";
  }
  return 0;
}