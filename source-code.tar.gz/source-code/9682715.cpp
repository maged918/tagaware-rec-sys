//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
char mapp[105][105];
int f[105][105];
int flag,sx,sy;int n,m,k;
int mx[]={-1,1,0,0},my[]={0,0,-1,1};
void dfs(int x,int y)
{
    if(flag)return;
    char c=mapp[x][y];
    for(int i=0;i<4;i++)
    {
        int tx=x+mx[i];
        int ty=y+my[i];
        if(tx==sx&&ty==sy&&k>=4)flag=1;
        if(flag)return;
        if(tx>=0&&tx<n&&ty>=0&&ty<m&&mapp[tx][ty]==c&&!f[tx][ty])
        {
            f[tx][ty]=1;
            k++;
            dfs(tx,ty);
            if(flag)return;
            f[tx][ty]=0;
            k--;
            //mapp[tx][ty]=c;
        }
    }
}
int main()
{
    while(~scanf("%d%d",&n,&m))
    {
        memset(f,0,sizeof(f));
        for(int i=0;i<n;i++)
            scanf("%s",mapp[i]);
        flag=0;
        for(int i=0;i<n;i++)
        {
            for(int j=0;j<m;j++)
            {
                k=1;
                sx=i,sy=j;
                f[i][j]=1;
                dfs(i,j);
                f[i][j]=0;
                if(flag)break;
            }
        }
        if(flag)printf("Yes\n");
        else printf("No\n");
    }
    return 0;
}
