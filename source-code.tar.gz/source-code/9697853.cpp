//Language: GNU C++0x


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#define eps 1e-9
#define FOR(x, s, e) for(int x = (s); x < (e); ++x)
#define FORc(x, s, e, c) for(int x = (s); x < (e) && (c); ++x)
#define STEP(x, s, e, d) for(int x = (s); x < (e); x+=(d))
#define ROF(x, s, e) for(int x = (s); x >= (e); --x)
#define ROFc(x, s, e, c) for(int x = (s); x >= (e) && (c); --x)
#define FOREACH(container, it) \
   for(typeof(container.begin()) it=container.begin(); it!=container.end(); it++)
#define EXP(i, s) for (int i = (s); i; i = qn[i])
#define vb vector<bool>
#define vi vector<int>
#define vii vector<pair<int, int> >
#define vs vector<string>
#define pb push_back
#define mp make_pair
#define ALL(X) X.begin(), X.end()
#define LL long long
#define pii pair<int, int>
#define x first
#define y second
#define gcd(x, y) __gcd((x), (y))
#define countbit(x) __builtin_popcount(x)

using namespace std;

#define MAXN 200000
LL H[MAXN], A[MAXN];
#define pr pair<LL, LL>

bool check(int N, int M, int K, int P, LL h) {
  LL H2[N];
  FOR(i, 0, N) {
    H2[i] = h;
  }
  priority_queue<pr, vector<pr>, greater<pr>> Q;  // (last day it remains +ve after shinking happens on that day, idx)
  FOR(i, 0, N) {
    if (H2[i] - M * A[i] < 0) {
      Q.push(mp(H2[i] / A[i] - 1, i));  // Also means the last day to beat it.
    }
  }
  LL beat = 0;
  for (; beat < M * K && !Q.empty(); ++beat) {
    pr t = Q.top();
    Q.pop();
    if (t.x < beat / K) {  // No more beat remains in that day.
      return false;
    }
    int i = t.y;
    H2[i] += P;
    if (H2[i] - M * A[i] < 0) {
      Q.push(mp(H2[i] / A[i] - 1, i));
    }
  }
  if (beat > M * K) {
    return false;
  }
  FOR(i, 0, N) {
    if (H2[i] - M * A[i] < H[i]) {
      LL t = (H[i] + M * A[i] - H2[i] + P - 1) / P;
      beat += t;
      if (beat > M * K) {
        return false;
      }
    }
  }
  return true;
}

int main(int argc, char **argv){
  LL N, M, K, P;
  cin >> N >> M >> K >> P;
  FOR(i, 0, N) {
    cin >> H[i] >> A[i];
  }
  LL lo = 0, hi = 1LL<<60;
  LL res = hi + 1;
  while (lo <= hi) {
    LL mi = (lo + hi) >> 1;
    if (check(N, M, K, P, mi)) {
      hi = mi - 1;
      res = min(res, mi);
    } else {
      lo = mi + 1;
    }
  }
  cout << res;
  return 0;
}