//Language: GNU C++


#include <iostream>
using namespace std;

int main() {
	long long int a, b, c, x1, y1, x2, y2, n, test1, test2, test, count=0;
	cin>>x1;
	cin>>y1;
	cin>>x2;
	cin>>y2;
	cin>>n;
	for (int i=0; i<n; i++){
		cin>>a;
		cin>>b;
		cin>>c;
		test1= a*x1+b*y1+c;
		test2= a*x2 + b*y2 + c;
		if (test1>0 and test2<0){
			count+=1;
		}
		else if (test1<0 and test2>0){
			count+=1;
		}
	}
	cout<<count<<endl;
	
	return 0;
}