//Language: GNU C++0x


#include<stdio.h>
#include<string.h>
#define nn 60
char ma[nn][nn];
int  main()
{
    int n,m;
    while(~scanf("%d%d",&n,&m))
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
            {
                ma[i][j]='#';
            }
        }
        int k=1;
        for(int i=2;i<=n;i+=2)
        {
            if(k%2)
                for(int j=1;j<m;j++)
                    ma[i][j]='.';
            else
            {
                for(int j=2;j<=m;j++)
                    ma[i][j]='.';
            }
            k++;
        }
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=m;j++)
            {
                printf("%c",ma[i][j]);
            }
            printf("\n");
        }
    }
    return 0;
}
