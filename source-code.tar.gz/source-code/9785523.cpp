//Language: GNU C++


// توكلنا علي الله
// SuperNova

#include <stdio.h>
#include <cstring>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <cmath>
#include <math.h>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <vector>
#include <set>
#include <list>
#include <climits>
#include <cctype>
#include <bitset>
#include <iostream>

using namespace std;

#define all(v) v.begin(), v.end()
#define rall(v) v.rbegin(), v.rend()
#define sz(v) ((ll)v.size())
#define clr(v, d) memset(v, d, sizeof(v))
#define rep(i, v)       for(int i=0;i<sz(v);++i)
#define lp(i, n)        for(int i=0;i<(int)(n);++i)
#define lpi(i, j, n)    for(int i=(j);i<(int)(n);++i)
#define lpd(i, j, n)    for(int i=(j);i>=(int)(n);--i)
#define pb                  push_back
#define MP                  make_pair
typedef long double ld;
typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef vector<double> vd;
typedef vector<vi> vvi;
typedef vector<vd> vvd;
typedef vector<string> vs;
typedef vector<pair<double, double> > vdd;
typedef vector<pair<pair<int, int>, int> > viii;
typedef vector<pair<pair<int, int>, double> > viid;
typedef pair<pair<int, int>, int> iii;
typedef pair<pair<int, int>, double> iid;
struct edje {
    int from, to;
    ll w;
    edje(int from, int to, ll w) :
            from(from), to(to), w(w) {
    }
    bool operator <(const edje & e) const {
        return w < e.w;
    }

};
int dx[] = { 1, -1, 0, 0 };
int dy[] = { 0, 0, 1, -1 };

const ll oo = (ll) ((1e18)+1);
const double eps = 1e-9;
const ll mod7 = 1000000007;
ll mod (ll a,ll b) {return  (a%b + b )%b ;}
string getstr (ll x) {stringstream ss;ss << x;string str = ss.str();return str ;}
int n , m , k ;
ll a [500005];
ll dp [500005][3];
ll needed = 0 ;
ll suff [500005];
ll solve (int taken , int idx) {
    if (idx>=n) return 0 ;
    if (taken == 2)return 1 ;
    if (dp [idx][taken] != -1) return dp [idx][taken] ;
     ll ret = solve (taken,idx+1) ;
    if (suff[idx]== (taken+1)*needed) ret += solve (taken+1,idx+1);
    return dp [idx][taken] = ret ;
}
int main()
{
    scanf("%d",&n);
    clr(dp,-1);
    lp(i,n){
        scanf("%I64d",&a[i]);
        needed+=a[i];
    }
    if (mod(needed,3) != 0) {
       printf("0\n");
       return 0 ;
    }
    suff[0] = a[0] ;
    lpi(i,1,n) suff [i] = suff [i-1] + a[i] ;
    needed/=3;
   ll ans  = solve (0,0);
   printf("%I64d\n",ans);

}
