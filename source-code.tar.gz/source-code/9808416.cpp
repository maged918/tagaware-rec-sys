//Language: GNU C++0x


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <queue>
#include <cstring>
#include <string>
#include <cmath>
#include <set>
#include <map>
#include <vector>
#include <climits>
#include <unordered_map>
#include <unordered_set>
using namespace std;
#define pb push_back
#define ALL(x) x.begin(),x.end()
#define VINT vector<int>
#define PII pair<int,int>
#define MP(x,y) make_pair((x),(y))
#define ll long long
#define ull unsigned long long
void showVector(vector<int > s){
        cout<<"----------"<<endl;for(auto x:s)cout<<x<<" ";cout<<endl<<"----------"<<endl;
}
/****************************************/
const int MAX_V=11;//SET THE MAX NUM OF VERTEX
int head[MAX_V];
struct EDGE{
        int u,v,w;
        EDGE(int tu=0,int tv=0,int tw=0){u=tu,v=tv,w=tw;}
};
struct Triple{int f,s,t;};
int gcd(int a,int b){return b==0?a:gcd(b,a%b);}
//////////////////////////////////////
int main(){
        #ifndef ONLINE_JUDGE
                freopen("in.txt","r",stdin);
        #endif // ONLINE_JUDGE
        int n;
        cin>>n;
        vector<double> f;
        for(int i=1;i<=n;i++){
                double x;cin>>x;
                if(x==1){
                        cout<<"1.0000000000000"<<endl;
                        return 0;
                }
                f.pb(x);
        }
        sort(ALL(f),[](double s1,double s2){return s1>s2;});
        double ansmax=f[0];
        vector<double >st;
        st.push_back(f[0]);
        for(int i=1;i<f.size();i++){
                double allf=1;
                double p=0;
                for(auto ele:st){
                        allf*=(1-ele);
                        p+=(ele/(1-ele));
                }

                if(1-p>0){
                        ansmax+=allf*(1-p)*f[i];
                        st.pb(f[i]);
                }else break;
        }

                double allf=1;
                double p=0;
                for(auto ele:st){
                        allf*=(1-ele);
                        p+=(ele/(1-ele));
                }
                ansmax=allf*p;
        printf("%.9f\n",ansmax);
        return 0;
}
