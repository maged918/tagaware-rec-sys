//Language: GNU C++


#include<iostream>
#include<cmath>

#define int long long

using namespace std;

const int MAXN = 100005, MAXS = 400, sq = 333;
int sum[MAXS], s[MAXS], lazy[MAXS], a[MAXN], ans[MAXN];

void update(int p1, int x)
{
	for(int i = p1 * sq; i < (p1 + 1) * sq; i++)
	{
		sum[p1] += abs(a[i] - x);
		ans[i] += abs(a[i] - x);
		a[i] = x;
	}
	s[p1] = x;
}

void update2(int p1)
{
	if(s[p1])
	{
		sum[p1] = 0;
		for(int i = p1 * sq; i < (p1 + 1) * sq; i++)
		{
			ans[i] += lazy[p1];
			sum[p1] += ans[i];
			a[i] = s[p1];
		}
		lazy[p1] = s[p1] = 0;
	}
}

void set(int l, int r, int x)
{
	int p1 = l /sq, p2 = r / sq;
	if(p1 == p2)
	{
		update2(p1);
		for(int i = l; i <= r; i++)
		{
			ans[i] += abs(a[i] - x);
			sum[p1] += abs(a[i] - x);
			a[i] = x;
		}
		return;
	}
	update2(p1);
	for(int i = l; i / sq == p1; i++)
	{
		ans[i] += abs(a[i] - x);
		sum[p1] += abs(a[i] - x);
		a[i] = x;
	}
	for(int i = p1 + 1; i < p2; i++)
	{
		if(s[i] == 0)
			update(i, x);
		else
		{
			lazy[i] += abs(s[i] - x);
			sum[i] += sq * abs(s[i] - x);
			s[i] = x;
		}
	}
	update2(p2);
	for(int i = r; i / sq == p2; i--)
	{
		ans[i] += abs(a[i] - x);
		sum[p2] += abs(a[i] - x);
		a[i] = x;
	}
}

int get(int l, int r)
{
	int p1 = l /sq, p2 = r / sq, cnt = 0;
	if(p1 == p2)
	{
		update2(p1);
		for(int i = l; i <= r; i++)
			cnt += ans[i];
		return cnt;
	}
	update2(p1);
	for(int i = l; i / sq == l / sq; i++)
		cnt += ans[i];
	for(int i = p1 + 1; i < p2; i++)
		cnt += sum[i];
	update2(p2);
	for(int i = r; i / sq == r / sq; i--)
		cnt += ans[i];
	return cnt;
}

main()
{
	int n, m;
	cin >> n >> m;
	for(int i = 0; i < n; i++)
		a[i] = i + 1;
	while(m--)
	{
		int t, l, r;
		cin >> t >> l >> r;
		l--, r--;
		if(t == 1)
		{
			int x;
			cin >> x;
			set(l, r, x);
		}
		else
		{
			cout << get(l, r) << endl;
		}
	}
	return 0;
}
