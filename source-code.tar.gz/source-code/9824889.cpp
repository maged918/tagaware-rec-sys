//Language: GNU C++0x


#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m;
    cin>>n>>m;cout<<min(m,n)+1<<endl;
        for(int i=0;i<min(m,n)+1;i++)
            cout<<i<<' '<<(min(m,n)-i)<<endl;
}
