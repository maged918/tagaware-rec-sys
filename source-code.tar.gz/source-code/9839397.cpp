//Language: GNU C++




#include <iostream>
#include <string>
using namespace std;
int main() {
std::ios::sync_with_stdio(false);
string s;
cin >> s;
bool D = 0;
for (int i = 0; i < s.size(); i++) {
int x = s[i] - 48;
if (x == 9 && !D) {
D = true;
continue;
}
x = min(x, 9 - x);
if (x) D = true;
s[i] = x + 48;
}
cout << s;

}