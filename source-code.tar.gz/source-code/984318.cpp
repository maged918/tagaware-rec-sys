//Language: GNU C++


# include<iostream>
# include<cstdio>
# include<cstring>
# include<cstdlib>
# include<algorithm>
# include<cmath>
using namespace std;
#define rep(i,l,r) for(int i=l;i<=r;i++)
#define drep(i,r,l) for(int i=r;i>=l;i--)
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define LL long long
#define Travel(u) for(int i=start[u],v;v=e[i].a,i;i=e[i].next)
int n , c1[15] , c2[15]; 
char s[200008] , s1[200008] , s2[200008];
int ans  , jl = -1, i1;
int main()
{
    scanf("%s" , &s[1]);
    n = strlen(&s[1]);
    rep(i,1,n)
      c1[s[i]-'0'] ++ , c2[s[i]-'0'] ++;
    rep(i,0,c1[0])
    {
        c1[0] -= i; c2[0] -= i;
        if (i > ans)
        {
           ans = i; i1 = i; jl = -1;      
        }
        rep(j,1,5)
          if (c1[j] && c2[10-j])
          {
             c1[j]--; c2[10-j]--;
             int sum  = 1 + i;
             rep(k,0,9)
               sum += min(c1[k] , c2[9-k]);
             if (sum > ans)
             {
                ans = sum; i1 = i , jl = j;
             }
             c1[j]++; c2[10-j]++;
          }
        c1[0] += i; c2[0] += i;
    }
    if (!ans)
      puts(&s[1]) , puts(&s[1]);
    else
    {
       drep(i,n,n-i1+1)
         s1[i] = '0' , s2[i] = '0';
       c1[0] -= i1; c2[0] -= i1;
       n -= i1;
       if (jl != -1)
       {
          s1[n] = jl + '0'; s2[n] = 10 - jl + '0';
          c1[jl]--; c2[10-jl]--;
       }
       else n++;
       rep(k,0,9)
       {
           int t = min(c1[k] , c2[9-k]);
           rep(i,1,t)
           {
               n--; s1[n] = k + '0'; s2[n] = 9-k + '0';                         
           }
           c1[k] -= t; c2[9-k] -= t;
       }       
       int n1 = n , n2 = n;
       rep(k,0,9)
       {
          rep(i,1,c1[k])
          {
             n1--;
             s1[n1] = k + '0';
          }
          rep(i,1,c2[k])
          {
              n2--; 
              s2[n2] = k + '0';              
          }
       }
       puts(&s1[1]); puts(&s2[1]);
    }
    return 0;
}
