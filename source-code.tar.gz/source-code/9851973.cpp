//Language: MS C++


#include<iostream>
#include<string.h>

using namespace std;
char a[100];

int main()
{
    long long n;
    int p,i;
    cin>>a;
    int l=strlen(a);
    if(a[0]!='9')
    
    {
        p=a[0]-48;
        if(p<9-p)cout<<a[0];
        else cout<<9-p;
        
    }
    else cout<<a[0];

    for(i=1;i<l;i++)
    {
        p=a[i]-48;
        if(p<=9-p)cout<<a[i];
        
        else cout<<9-p;
    }
    cout<<endl;

    //cin>>n;

    return 0;
}