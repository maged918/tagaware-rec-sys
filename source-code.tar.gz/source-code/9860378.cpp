//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;

int n;
const int max_n = 200010;
int fen[max_n];
int a[max_n],b[max_n],la[max_n],lb[max_n],lc[max_n];
void add(int p)
{
    for(;p<=n;p+=p&(-p))
        fen[p]+=1;
}
int sum(int p)
{
    int ans = 0;
    for(;p>0;p-=p&(-p))
        ans+=fen[p];
    return ans;
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        la[i] = a[i] - sum(a[i]);
        add(a[i]+1);
    }
    memset(fen,0,sizeof(fen));
    for(int i=0;i<n;i++)
    {
        cin>>b[i];
        lb[i] = b[i] -sum(b[i]);
        add(b[i]+1);
    }
    int r = 0;
    for(int i=n-1;i>=0;i--)
    {
        lc[i]=lb[i]+la[i]+r;
         r = lc[i]/(n-i);
        lc[i]%=n-i;
    }
    memset(fen,0,sizeof(fen));
    for(int i=0;i<n;i++)
    {
        int l =0,r = n;
        while(r-l>1)
        {
            int mid = (l+r)/2;
            if(mid -sum(mid)<=lc[i])
                l = mid;
            else 
                r = mid;
        }
        a[i] = l;
        add(a[i]+1);
    }
    for(int i=0;i<n;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    return 0;
}
