//Language: GNU C++


#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
int n,k,m,b[100005][6];
struct node
{
    int a[5];
    node()
    {
        memset(a,0,sizeof(a));
    }
    node(int b,int c,int d,int e,int f)
    {
        a[0]=b;
        a[1]=c;
        a[2]=d;
        a[3]=e;
        a[4]=f;
    }
}tree[4*100001];
void init(int n,int st,int ed)
{
    if(st==ed)
    {
        for(int i=0;i<m;i++)
            tree[n].a[i]=max(b[st][i],b[st][i]);
    }
    else
    {
        int mid=(st+ed)/2;
        int left=n*2;
        int right=left+1;
        init(left,st,mid);
        init(right,mid+1,ed);
        for(int i=0;i<m;i++)
        {
            tree[n].a[i]=max(tree[left].a[i],tree[right].a[i]);
            //cout<<tree[n].a[i]<<" "<<tree[left].a[n]<<" "<<tree[right].a[i];
        }
        //cout<<endl<<st<<" "<<ed<<endl;
    }
}
node query(int n,int st,int ed,int i,int j)
{
    if(i>ed||j<st)
        return node();
    if(st>=i && ed<=j)
        return tree[n];
    int mid=(st+ed)/2;
    int left=2*n;
    int right=left+1;
    node l=query(left,st,mid,i,j);
    node r=query(right,mid+1,ed,i,j);
    node temp;
    for(int z=0;z<m;z++)
        temp.a[z]=max(l.a[z],r.a[z]);
    return temp;

}
int main()
{
    int i,j,z,maxi,sum,range;
    cin>>n>>m>>k;
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
            cin>>b[i][j];
    }
    init(1,0,n-1);
    node ans;
    for(i=0,j=0,maxi=0;i<n && j< n;j++)
    {
        node temp=query(1,0,n-1,i,j);
        range=j-i+1;
        for(z=0,sum=0;z<m;z++)
        {
            sum+=temp.a[z];
            //cout<<temp.a[z]<<" ";
        }
       //cout<<endl;
        if(sum<=k)
        {
            //cout<<i<<" "<<j<<" "<<range<<endl;
            maxi=max(maxi,range);
            ans=temp;
        }
        else
            i++;

    }
    for(z=0;z<m;z++)
        cout<<ans.a[z]<<" ";
    cout<<endl;
    return 0;
}
