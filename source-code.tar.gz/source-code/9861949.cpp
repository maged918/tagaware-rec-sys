//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <ctime>
#include <queue>
#include <set>
#include <map>
#define REP(I,A,B) for(int I=A,END=B;I<=END;I++)
#define REPD(I,A,B) for(int I=A,END=B;I>=END;I--)
#define RI(X) scanf("%d",&X)
#define RS(X) scanf("%s",&X)
#define GCH getchar()
#define PCH(X) putchar(X)
#define MAX(A,B) (((A)>(B))?(A):(B))
#define MIN(A,B) (((A)<(B))?(A):(B))
#define MS(X,Y) memset(X,Y,sizeof(X))
#define MC(X,Y,var,len) memcpy((X),(Y),sizeof(var)*(len))
#define debug(...) fprintf(stderr,__VA_ARGS__)
#define MAXN 102
#define MOD 1000000007
struct matrix
{
  long long a[MAXN][MAXN];
}I={0},A={0},B={0};
int dp[MAXN]={0};
int visit[MAXN]={0};
int cnt[MAXN]={0};
int n,x;
using namespace std;
void open()
{
  freopen("E.in","r",stdin);
  freopen("E.out","w",stdout);
}
void close()
{
  fclose(stdin);
  fclose(stdout);
}
long long dfs(int i)
{
  if (i<0)
    return 0;
  if (i==0)
    return 1;
  if (visit[i]==1)
    return dp[i];
  REP(j,1,100)
    dp[i]=(dp[i]+cnt[j]*dfs(i-j))%MOD;
  visit[i]=1;
  return dp[i];
}
void init()
{
  REP(i,1,101)
    I.a[i][i]=1;
  RI(n);
  RI(x);
  int d;
  REP(i,1,n)
  {
    RI(d);
    cnt[d]++;
  }
  dp[0]=visit[0]=1;
  REPD(i,100,0)
    if (visit[i]==0)
      dp[i]=dfs(i);
    
  REP(i,1,99)
    B.a[i+1][i]=1;
  B.a[101][101]=1;
  REP(i,1,100)
    B.a[101-i][100]=B.a[101-i][101]=cnt[i];
  A.a[1][101]=dp[0];
  REP(i,1,100)
    A.a[1][i]=dp[i],A.a[1][101]=(A.a[1][101]+dp[i])%MOD;
}
matrix mul(matrix A,matrix B)
{
  matrix C={0};
  REP(i,1,101)
    REP(j,1,101)
      REP(k,1,101)
        C.a[i][j]=(C.a[i][j]+(long long)(A.a[i][k]*B.a[k][j])%MOD)%MOD;
  return C;
}
matrix power(matrix A,int k)
{
  matrix X=A;
  matrix O=I;
  while (k)
  {
    if (k&1)
      O=mul(O,X);
    X=mul(X,X);
    k>>=1;
  }
  return O;
}
int main()
{
  //open();
  init();
  if (x>100)
  {
    B=power(B,x-100);
	A=mul(A,B);
	printf("%I64d\n",A.a[1][101]); 
  }
  else 
  {
    int ans=0;
    REP(i,0,x)
      ans=(ans+dp[i])%MOD;
    printf("%d\n",ans);
  }
  close();
  return 0;
}
