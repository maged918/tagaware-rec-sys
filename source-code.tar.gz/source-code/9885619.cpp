//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#include<queue>
#include<vector>
#include<map>
using namespace std;
long long int a,b,s;
int main()
{
    cin>>a>>b>>s;
    if(a<0)
        a=-a;
    if(b<0)
        b=-b;
    if(s<a+b)
        cout<<"No";
    else if(s==a+b)
        cout<<"Yes";
    else if((a+b-s)%2==0)
        cout<<"Yes";
    else
        cout<<"No";
    
    return 0;
} 