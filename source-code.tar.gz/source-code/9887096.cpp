//Language: GNU C++0x


# include <iostream>
# include <cstdio>
# include <algorithm>
# include <cmath>
# include <string>
# include <cstring>
# include <vector>
# include <set>
# include <map>
# include <queue>
# include <cassert>

using namespace std;

int main() {
	int a, b, s;
	cin >> a >> b >> s;
	if (a < 0) a = -a;
	if (b < 0) b = -b;
	if (a + b <= s && (s - a - b) % 2 == 0)
		puts("YES");
	else
		puts("NO");

	return 0;
}