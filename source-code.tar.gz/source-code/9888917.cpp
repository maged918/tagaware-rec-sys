//Language: GNU C++0x


#include<stdio.h>

int n,m,b,g,tmp;
bool happyboy[101],happygirl[101];
bool state;

int gcd(int n,int m)
{
    if(n == 0 || m == 0) return n+m;
    if(n == 1 || m == 1) return 1;
    if(n > m) return gcd(m,n%m);
    return gcd(n,m%n);
}

int main()
{
    scanf("%d%d",&n,&m);
    scanf("%d",&b);
    for(int i=1;i<=b;i++)
    {
        scanf("%d",&tmp); happyboy[tmp] = true;
    }
    scanf("%d",&g);
    for(int i=1;i<=g;i++)
    {
        scanf("%d",&tmp); happygirl[tmp] = true;
    }
    
    int l = n*m/gcd(n,m);
    
    while(1)
    {
        state = false;
        
        for(int i=0;i<l;i++)
        {
            if(happyboy[i%n] == happygirl[i%m]) continue;
            state = 1;
            happyboy[i%n] = happygirl[i%m] = 1;
        }
        
        if(!state)
        {
            bool check = true;
            for(int i=0;i<n;i++) if(!happyboy[i]) check = false;
            for(int i=0;i<m;i++) if(!happygirl[i]) check = false;
            
            if(check) puts("Yes");
            else puts("No");
            break;
        }
    }
    
    return 0;
}