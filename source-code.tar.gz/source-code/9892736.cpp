//Language: MS C++


#include <iostream>
using namespace std;
int main(){
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	int a, b, c;
	cin >> a >> b >> c;
	a = abs(a) + abs(b);
	if (a > c || ((c - a) % 2 != 0 && c != a)) cout << "No";
	else {
		cout << "Yes";
	}
	return 0;
}