//Language: GNU C++0x


#include<cstdio>
#include<iostream>
#include<vector>
#include<cstring>
#include<algorithm>
#include<queue>
#include<set>
#include<cmath>
#include<bitset>
#include<stack>
#include<map>
#include<queue>
#define test(t) while(t--)
#define cin(n) scanf("%d",&n)
#define cinl(n) scanf("%lld",&n)
#define cout(n) printf("%d\n",n)
#define rep(i,a,n) for(i=a;i<=n;i++)
#define vi vector<int>
#include<assert.h>
#define vii vector< vector<int> >
#define vpii vector< pair<int,int> >
#define mii map<int,int>
#define pb push_back
#define inf 10000009
#define mp make_pair
#define imax (int) 1000000007
//#define inf 98765432
#define ill long long
#define getchar_unlocked() getchar()
#define inp(x) fi(&x)using namespace std;
#define mod 1000000007
#define gc getchar_unlocked
int fcin(){register int c = gc();int x = 0;for(;(c<48 || c>57);c = gc());for(;c>47 && c<58;c = gc()) {x = (x<<1) + (x<<3) + c - 48;}return x;}
using namespace std;

long long power(ill a,ill b)
{
ill ans=1LL;
while(b)
{
if(b&1)
ans=(ans*a)%mod;
a=(a*a)%mod;
b/=2;
}
return ans;


}
string s[2007];
int a[2007][2007],m,n,vis[2007][2007];

int check(int x,int y)
{
    if(x<0||y<0||x>=m||y>=n||vis[x][y])
        return 0;
    return a[x][y];
}    
int check2(int x,int y)
{
    if(x<0||y<0||x>=m||y>=n)
        return 0;
    return a[x][y];
}
int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};
int main()
{

    int t,i,j,k,l;
    cin(m);
    cin(n);
    memset(vis,0,sizeof(vis));
    for(i=0;i<m;i++)
    {
        cin>>s[i];
        for(j=0;j<n;j++)
            a[i][j]=(s[i][j]=='*')?0:1;
    }
    
    queue<pair<int,int> >q;
    int ans=2;
    int c=0;
    for(i=0;i<m;i++)
    {
        for(j=0;j<n;j++)
        {
            if(!a[i][j])
            {
                c++;
                continue;
            }
            int ne=0;
            for(k=0;k<4;k++)
            {
                if(check(i+dx[k],j+dy[k]))
                    ne++;
            }
            if(ne==0)
                ans=-1;
            if(ne==1)
                q.push(mp(i,j));
        }    
    }   
    if((m*n-c)&1)
        ans=-1;
    if(ans==-1)
    {
        cout<<"Not unique";
        return 0;
    }    
    vector<pair<pair<int,int>,pair<int,int> > >anss;
    while(q.size())
    {
        int x=q.front().first;
        int y=q.front().second;
        q.pop();
        
        if(vis[x][y])
            continue;
        vis[x][y]=1;
        int g=0;
        for(i=0;i<4;i++)
        {
            if(check(x+dx[i],y+dy[i]))
            {
                g=1;
                vis[x+dx[i]][y+dy[i]]=1;
                break;
            }
        }    
        if(!g)
            continue;
        anss.pb(mp(mp(x,y),mp(x+dx[i],y+dy[i])));
        x=x+dx[i];
        y=y+dy[i];
        
        for(i=0;i<4;i++)
        {
            int nx=x+dx[i];
            int ny=y+dy[i];
            if(!check(nx,ny))
                continue;
            int ne=0;
            for(j=0;j<4;j++)
            {
                if(check(nx+dx[j],ny+dy[j]))
                    ne++;
            }    
            if(ne==1)
                q.push(mp(nx,ny));
            
        }    
        
    }
if(2*anss.size()!=(m*n-c))
{
cout<<"Not unique";
return 0;
}    

    for(i=0;i<anss.size();i++)
    {
        int x=anss[i].first.first;
        int y=anss[i].first.second;
        int xx=anss[i].second.first;
        int yy=anss[i].second.second;
        
        if(x==xx)
        {
            if(yy<y)
                swap(y,yy);
            s[x][y]='<';
            s[x][yy]='>';
        }    
        else
        {
            if(xx<x)
                swap(x,xx);
            s[x][y]='^';
            s[xx][y]='v';
        }    
    }
    for(i=0;i<m;i++)
        cout<<s[i]<<"\n";


return 0;
}