//Language: GNU C++


#include <iostream>
#include <cstdio>
using namespace std;
int a[150];
int b[150];
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("date.in","r",stdin);
        freopen("date.out","w",stdout);
    #endif // ONLINE_JUDGE
    int n,m,y,x;
    cin>>n>>m;
    cin>>x;
    for(int i=1;i<=x;i++)
    {
        cin>>y;
        a[y]=1;
    }
    cin>>x;
    for(int i=1;i<=x;i++)
    {
        cin>>y;
        b[y]=1;
    }
    for(int i=1;i<=12000;i++)
    {
        x=i%n;
        y=i%m;
     if(a[x]+b[y]>0)
            a[x]=b[y]=1;
    }
    bool ok=1;
    for(int i=0;i<n;i++)
        if(a[i]==0)
            ok=0;
    for(int i=0;i<m;i++)
        if(b[i]==0)
            ok=0;
    if(ok==1)
        cout<<"Yes\n";
    else
        cout<<"No\n";
    return 0;
}
