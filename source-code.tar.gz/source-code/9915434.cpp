//Language: GNU C++0x


// Solution by Mukai Yersin
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cassert>
#include <cstdio>
#include <vector>
#include <queue>
#include <cmath>
#include <ctime>
#include <set>
#include <map>

#define sz 2015
#define SZ 5000015
#define mp make_pair
#define pb push_back
#define eps 1e-5
#define inf 1<<30
#define INF (long long)(1ll<<62)
#define rep(i, l, r) for (int i = l; i < r; i++)
#define irep(i, r, l) for (int i = r - 1; i >= l; i--)
#define F first
#define S second

typedef long long ll;

using namespace std;

char t[sz][sz];
int n, m, x, y, X, Y, v, to, toto, d[SZ];
bool was[SZ];
vector<pair<int, int> > ans;
vector<int> a[SZ];
queue<int> q;

void error() {
 	printf("Not unique");
 	exit(0);
}

int main()
{
	scanf("%d %d\n", &n, &m);	
	rep(i, 0, n)
		gets(t[i]);
	rep(i, 0, n)
		rep(j, 0, m) 
			if (t[i][j] == '.') {
				x = i * m + j;
			 	if (t[i][j + 1] == '.') a[x].pb(x + 1);
			 	if (t[i][j - 1] == '.') a[x].pb(x - 1);
			 	if (t[i + 1][j] == '.') a[x].pb(x + m);
			 	if (t[i - 1][j] == '.') a[x].pb(x - m);
			 	d[x] = a[x].size();
			 	if (d[x] == 1) q.push(x);
			 	if (d[x] < 1) error();
			}
	while (!q.empty()) {
	 	v = q.front();
	 	was[v] = 1;
	 	rep(i, 0, a[v].size()) {
	 		to = a[v][i];
	 		if (!was[to]) {
	 		 	was[to] = 1;
	 		 	ans.pb(mp(v, to));
	 		 	rep(j, 0, a[to].size()) {
	 		 		toto = a[to][j];
	 		 		if (!was[toto]) {
	 		 			d[toto]--;
	 		 			if (d[toto] == 1)
	 		 				q.push(toto);
	 		 		}
	 		 	}
	 		}
	 	}
	 	q.pop();
	}
	rep(i, 0, ans.size()) {
	 	x = ans[i].F / m;
	 	y = ans[i].F % m;
	 	X = ans[i].S / m;
	 	Y = ans[i].S % m;
	 	if (x == X) {
	 	 	t[x][min(y, Y)] = '<';
	 	 	t[x][max(y, Y)] = '>';
	 	} else if (y == Y) {
			t[min(x, X)][y] = '^';
			t[max(x, X)][y] = 'v';
	 	} else assert(0);
	}
	rep(i, 0, n)
		rep(j, 0, m)
			if (t[i][j] == '.') error();
	rep(i, 0, n)
		printf("%s\n", t[i]);
	return 0;
}
