//Language: GNU C++0x


#include<bits/stdc++.h>
using namespace std;
/*-----------------------------------------MACROS--------------------------*/
#define inf 1000000007
#define loop(i,n) for(int i=0;i<(int)n;i++)
#define iloop(i,n) for(int i=n;i>=1;i--)
#define FOR(i,a,b) for(int i=a;i<b;i++)
#define sz(a) int((a).size())
#define pb push_back
#define pf pop_front
#define all(c) (c).begin(),(c).end()
#define tr(c,i) for(auto i = (c).begin(); i != (c).end(); i++)
#define present(c,x) ((c).find(x) != (c).end())
#define cpresent(c,x) (find(all(c),x) != (c).end())
#define EPS 1e-9
#define ff first
#define ss second
#define gi(n) scanf("%d",&n)
#define gl(n) cin >> n
#define pi(n) printf("%d",n)
#define pl(n) cout << n
#define ps printf(" ")
#define pn printf("\n")
#define dg(n,s); printf("%s %d",s,n)
#define mp make_pair
#define UNVISITED -1
#define EXPLORED 0
#define VISITED 1
/*--------------------------------------------typedefs-------------------------*/
typedef vector<int> vi;
typedef vector<string> vs;
typedef vector< vi > vvi;
typedef pair<int,int> ii;
typedef vector< ii > vii;
typedef long long ll;
typedef vector< ll > vll;
 
/*-----------------------------------Graph helpers------------------*/
int x_disp[]={-1,0,1,0};
int y_disp[]={0,-1,0,1};
 
 
 
 
int main()
{
 
ios_base::sync_with_stdio(false);
int n;
long long num;
cin>>n>>num;
string ans;

while(num)
{
    if(num%10==0 || num%10==1)
    {
        num/=10;
        continue;
    }
    int cur=num%10;
    if(cur==4)
        ans+="322";
    else if(cur==6)
        ans+="53";
    else if(cur==8)
        ans+="7222";
    else if(cur==9)
        ans+="7332";
    else
        ans+=(char)('0'+cur);
    num/=10;

}

sort(ans.rbegin(),ans.rend());
cout<<ans<<endl;
return 0;
} 