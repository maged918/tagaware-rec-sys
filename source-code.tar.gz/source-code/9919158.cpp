//Language: MS C++


#define _USE_MATH_DEFINES 
#define _CRT_SECURE_NO_DEPRECATE 
#include <iostream> 
#include <cstdio> 
#include <cstdlib> 
#include <vector> 
#include <sstream> 
#include <string> 
#include <map> 
#include <set> 
#include <algorithm> 
#include <cmath> 
#include <cstring> 
#include <queue>
#include <time.h>
using namespace std; 
#define mp make_pair 
#define pb push_back 
#define all(C) (C).begin(), (C).end() 
#define sz(C) (int)(C).size() 
#define PRIME 1103 
#define PRIME1 31415 
typedef long long int64; 
typedef unsigned long long uint64; 
typedef pair<int, int> pii; 
typedef vector<int> vi; 
typedef vector<vector<int> > vvi; 
//------------------------------------------------------------ 
int n, m, k, r, en;
int boy[100];
int girl[100];

int main() 
{
#ifdef WIN32
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    cin >> n >> m;
    int b;
    cin >> b;
    for(int i = 0; i < b; ++i)
    {
        int t;
        cin >> t;
        boy[t] = 1;
    }
    cin >> b;
    for(int i = 0; i < b; ++i)
    {
        int t;
        cin >> t;
        girl[t] = 1;
    }
    
    for(int i = 0; i < 100000; ++i)
    {
        int q = girl[i % m] | boy[i % n];
        girl[i % m] = q;
        boy[i % n] = q;
    }
    for(int i = 0; i < n; ++i)
        if (!boy[i])
        {
            cout << "No";
            return 0;
        }
    for(int i = 0; i < m; ++i)
    {
        if (!girl[i])
        {
            cout << "No";
            return 0;
        }
    }
    cout << "Yes";
}
