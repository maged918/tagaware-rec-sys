//Language: GNU C++


#include<bits/stdc++.h>
#include<string>
using namespace std;
template< class T > T gcd(T a, T b) { return (b != 0 ? gcd<T>(b, a%b) : a); }
template< class T > T lcm(T a, T b) { return (a / gcd<T>(a, b) * b); }
#define traverse(container, it) \
  for(typeof(container.begin()) it = container.begin(); it != container.end(); it++)
#define         mp(x, y) make_pair(x, y)
#define         SIZE(c) (int)c.size()
#define         pb(x) push_back(x)
//#define       map<char,int>::iterator it;
#define         ff first
#define         ss second
#define         ll long long
#define         ld long double
#define         pii pair< int, int >
#define         psi pair< string, int >
#define         p(n) printf("%d\n",n)
#define         p64(n) printf("%lld\n",n)
#define         s(n) scanf("%d",&n)
#define         s64(n) scanf("%I64d",&n)
#define         rep(i,a,b) for(i=a;i<b;i++)
#define         MOD (1000000007LL)





////////////////////////////////////////////////////////

int n, m, k;

void outT(int t)
{
    int x=t/m+1, y=t%m+1;
    if (x%2==0) y=m+1-y;
    cout<<" "<<x<<" "<<y;
}

int main()
{
    int t, x, y, i, j;
    cin>>n>>m>>k;
    for (t=0,i=0; i<k; i++) {
        if (i<k-1) {
            cout<<2;
            outT(t++); outT(t++);
        }
        else {
            cout<<n*m-t;
            while (t<n*m) outT(t++);
        }
        cout<<endl;
    }
    return 0;
}
