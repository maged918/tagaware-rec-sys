//Language: GNU C++


//C. Number of Ways
#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    long long s = 0;
    vector < long long > v;
    vector < pair < int, int > > ans;

    cin >> n;

    for( int i = 0; i < n; ++i ) {
        int a;
        cin >> a;
        s += a;
        v.push_back(s);
    }

    if( s % 3  ) cout << 0 << endl;
    else {
        for( int i = 0; i < n; ++i ) {
            if( v[i] == s/3 ) {
                ans.push_back(make_pair(i,1));
            }
            if( v[i] == 2*(s/3) && i != n-1 ) {
                ans.push_back(make_pair(i,2));
            }
        }

        long long res = 0, cnt = 0;
        for( int i = 0; i < ans.size(); ++i ) {
            if( ans[i].second == 2 ) {
                if( i && ans[i-1].first == ans[i].first ) res += cnt-1;
                else res += cnt;
            }
            else                   ++cnt;
        }
        cout << res << endl;
    }

}
