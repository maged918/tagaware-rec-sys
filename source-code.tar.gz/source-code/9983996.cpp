//Language: GNU C++0x


#include <stdio.h>
#include <algorithm>
#include <string.h>
#include <iostream>
#define MAXN 105
using namespace std;
char s[MAXN], t[MAXN];
char ans[MAXN];
int main()
{
    int len;
    while(scanf("%s",s) != EOF)
    {
        scanf("%s",t);
        memset(ans, 0, sizeof(ans));
        len = strlen(s);
        for(int i = 0; i < len; i++) ans[i] = s[i];
        int j = len - 1;
        while(true)
        {
            if(j < 0) break;
            if(ans[j] != 'z')
            {
                ans[j]++;
                break;
            }
            else
            {
                ans[j] = 'a';
                j--;
            }
        }
        if(!strcmp(ans, t)) puts("No such string");
        else
            printf("%s\n",ans);
    }
    return 0;
}
