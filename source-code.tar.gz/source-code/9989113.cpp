//Language: GNU C++0x


#include <bits/stdc++.h>
using namespace std;
#define ll long long

double dp[2005][2005];
double p;
int n;

int main(){ 
  ios_base::sync_with_stdio(0);
  int t;
  cin>>n>>p>>t;
  for(int i=1; i<=n; i++) {
    for(int j=1; j<=t; j++) {
      dp[i][j] = p*(1+dp[i-1][j-1]) + (1.0-p)*dp[i][j-1];
    }
  }
  printf("%.9f\n",dp[n][t]);
  return 0;
}