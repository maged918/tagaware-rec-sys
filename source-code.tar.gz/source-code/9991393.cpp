//Language: GNU C++


/*
    Look at me!
    Look at me!
    Look at how large the monster inside me has become!
*/

#include<fstream>
#include<iostream>
#include<cstdio>
#include<map>
#include<set>
#define FIT(a,b) for(vector<int >::iterator a=b.begin();a!=b.end();a++)
#define FITP(a,b) for(vector<pair<int,int> >::iterator a=b.begin();a!=b.end();a++)
#define RIT(a,b) for(vector<int>::reverse_iterator a=b.end();a!=b.begin();++a)
#include<stack>
#define ROF(a,b,c) for(int a=b;a>=c;--a)
#include<vector>
#include<algorithm>
#define FOR(a,b,c) for(int a=b;a<=c;++a)
#define REP(a,b) for(register int a=0;a<b;++a)
#include<cstring>
#include<ctime>
#include<bitset>
#include<cmath>
#include<iomanip>
#include<set>
#define f cin
#define g cout
#include<queue>
#define debug cerr<<"OK";
#define pii pair<int,int>
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define ull unsigned long long
#define mod 1000000009LL
#define N 2010
#define SQR 350
#define inf 1<<30
#define div fdasfasd
#define hash dsafdsfds
#define od 666013
#define mod 1000000007
#define DIM 600100
using namespace std;
/*
    int dx[]={0,0,0,1,-1};
    int dy[]={0,1,-1,0,0};
*/

double p,sol,D[N][N];
int n,t;
int main ()
{
    #ifndef ONLINE_JUDGE
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    #endif

    f>>n>>p>>t;
    D[0][n]=1.0;
    FOR(ti,0,t-1)
    FOR(j,0,n)
    {
        D[ti+1][j]+=D[ti][j]*(1.0-p);
        if(j)
        D[ti+1][j-1]+=D[ti][j]*p;
        else
        D[ti+1][j]+=D[ti][j]*p;
    }
    FOR(i,0,n)
    sol+=i*D[t][i];
    g<<fixed<<setprecision(7)<<n-sol;
    return 0;
}
