//Language: GNU C++


#include<vector>
#include<stack>
#include<set>
#include<map>
#include<queue>
#include<deque>
#include<string>
#include<iostream>
#include<sstream>
#include<algorithm>
#include<cstring>
#include<cassert>
#include<cstdlib>
#include<cstdio>
#include<cmath>

using namespace std;

// Input macross
#define s(n)                        scanf("%d",&n)
#define sc(n)                       scanf("%c",&n)
#define sl(n)                       scanf("%lld",&n)
#define sf(n)                       scanf("%lf",&n)
#define ss(n)                       scanf("%s",n)

// Useful constants
#define INF                         (int)1e9
#define EPS                         1e-9

// Useful hardware instructions
#define bitcount                    __builtin_popcount
#define gcd                         __gcd

// Useful container manipulation / traversal macross
#define forall(i,a,b)               for(int i=a;i<b;i++)
#define foreach(v, c)               for( typeof( (c).begin()) v = (c).begin();  v != (c).end(); ++v)
#define whole(a)                    a.begin(), a.end()
#define pb                          push_back
#define fill(a,v)                   memset(a, v, sizeof a)
#define sz(a)                       ((int)(a.size()))
#define mp                          make_pair

// Some common useful functions
#define maX(a,b)                    ( (a) > (b) ? (a) : (b))
#define miN(a,b)                    ( (a) < (b) ? (a) : (b))
#define checkbit(n,b)               ( (n >> b) & 1)

using namespace std;

#if DEBUG && !ONLINE_JUDGE

    #define debug(args...)     (Debugger()) , args

    class Debugger
    {
        public:
        Debugger(const std::string& _separator = ", ") :
        first(true), separator(_separator){}

        template<typename ObjectType>
        Debugger& operator , (const ObjectType& v)
        {
            if(!first)
                std:cerr << separator;
            std::cerr << v;
            first = false;
            return *this;
        }
        ~Debugger() {  std:cerr << endl;}

        private:
        bool first;
        std::string separator;
    };

//     template <typename T1, typename T2>
//     inline std::osstream& operator << (std::osstream& oss, const std::pair<T1, T2>& p)
//     {
//         return oss << "(" << p.first << ", " << p.second << ")";
//     }
// 
//     template<typename T>
//     inline std::osstream &operator << (std::osstream & oss,const std::vector<T>& v)
//     {
//         bool first = true;
//         oss << "[";
//         for(unsigned int i = 0; i < v.size(); i++)
//         {
//             if(!first)
//                 oss << ", ";
//             oss << v[i];
//             first = false;
//         }
//         return oss << "]";
//     }
// 
//     template<typename T>
//     inline std::osstream &operator << (std::osstream & oss,const std::set<T>& v)
//     {
//         bool first = true;
//         oss << "[";
//         for (typename std::set<T>::const_iterator ii = v.begin(); ii != v.end(); ++ii)
//         {
//             if(!first)
//                 oss << ", ";
//             oss << *ii;
//             first = false;
//         }
//         return oss << "]";
//     }
// 
//     template<typename T1, typename T2>
//     inline std::osstream &operator << (std::osstream & oss,const std::map<T1, T2>& v)
//     {
//         bool first = true;
//         oss << "[";
//         for (typename std::map<T1, T2>::const_iterator ii = v.begin(); ii != v.end(); ++ii)
//         {
//             if(!first)
//                 oss << ", ";
//             oss << *ii ;
//             first = false;
//         }
//         return oss << "]";
//     }

#else
    #define debug(args...)                  // Just strip off all debug tokens
#endif

typedef long long LL;

typedef pair<int, int> PII;
typedef pair<int, LL> PIL;
typedef pair<LL, int> PLI;
typedef pair<LL, LL> PLL;

typedef vector<int> VI;
typedef vector<LL> VL;
typedef vector<vector<int> > VVI;
typedef vector<VL> VVL;


int ni()
{
    int _num; s(_num);
    return _num;
}

/*-------------------------Main code begins now ------------------------------*/
int testnum;

void preprocess()
{

}
string s, t;

bool dfs(int i, int four, int seven, bool slack)
{
    if(four == 0 && seven == 0) return true;
    if(slack)
    {
        t.insert(t.end(), four, '4');
        t.insert(t.end(), seven, '7');
        return true;
    }
    
    if(four && s[i] <= '4')
    {
        t.insert(i,1,'4');
        if(s[i] < '4')
            return dfs(i+1, four-1, seven, true);
        
        if(dfs(i+1, four-1, seven, false))
            return true;
        t.erase(sz(t)-1);
    }
    if(seven && s[i] <= '7')
    {
        t.insert(i, 1,'7');
        if(s[i] < '7')
            return dfs(i+1, four, seven-1, true);
        if(dfs(i+1, four, seven-1, false))
            return true;
        t.erase(sz(t)-1);
    }
    return false;
}

void solve()
{
    if(sz(s) % 2)
        s = '0' + s;
    while(true)
    {
        int L = sz(s);
        if(dfs(0, L/2, L/2, false)) break;
        s = "00" + s;
    }
    cout << t << endl;
}

bool input()
{
    cin>>s;
    return true;
}


int main()
{
    preprocess();
    int T = 1;
    for(testnum=1;testnum<=T;testnum++)
    {
        if(!input()) break;
        solve();
    }
}
