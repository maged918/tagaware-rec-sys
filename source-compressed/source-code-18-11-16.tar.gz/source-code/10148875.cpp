//Language: GNU C++


#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <ctime>
#define fi first
#define se second
#define PA pair<int,int>
#define VI vector<int>
#define VP vector<PA >
#define mk(x,y) make_pair(x,y)
#define N (1<<25)
#define int64 long long
#define mo 1051131
#define For(i,x,y) for (i=x;i<=y;i++)
using namespace std;
int i,j,k,n,m,phi,nn,p2,an;
int a[N],re[N];
int64 T;
inline int64 pow(int64 x,int64 y) {
	int64 an=1;
	for (;y;y/=2) {
		if (y&1) an=an*x%mo;
		x=x*x%mo;
	}
	return an;
}
void work(int m,int p,int q) {
	if (m==0) {
		re[0]=1ll*pow(p+q,T)*a[0]%mo;
		return;
	}
	int G=(1<<m-1)-1,n=1<<m,i,nn=1<<m-1;
	For(i,0,nn-1) a[i]=(a[i]+a[i+nn])%mo;
	work(m-1,p*2%mo,(1ll*p*G+q)%mo);
	int zhi=(-1ll*p*G+q)%mo;
	zhi=pow(zhi,T);
	For(i,0,nn-1) {
		a[i]=(a[i]-a[i+nn])%mo;
		int B=1ll*(a[i]-a[i+nn])*zhi%mo,ge=re[i];
		re[i+nn]=(re[i]-B)%mo;
		re[i]=(B+re[i])%mo;
	}
	For(i,0,n-1) re[i]=1ll*p2*re[i]%mo;
}
int main() {
	for (k=mo,phi=1,i=2;i<=k;i++) if (k%i==0) {
		int s=0;
		for (;k%i==0;k/=i) s++;
		phi*=i-1;
		For(j,2,s) phi*=i;
	}
	scanf("%d%I64d%d",&n,&T,&m); T%=phi;
	nn=1<<n; p2=pow(2,phi-1);
	For(i,0,m-1) scanf("%d",&a[i]);
	For(i,m,nn-1) a[i]=(101*a[i-m]+10007)%mo;
	work(n,1,0);
	For(i,0,nn-1) an^=(re[i]+mo)%mo;
	//For(i,0,nn-1) printf("%d ",re[i]); printf("\n");
	printf("%d\n",an);
	return 0;
}
