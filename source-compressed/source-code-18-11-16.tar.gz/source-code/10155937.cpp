//Language: GNU C++


#include<cstdio>
#include<vector>
#include<algorithm>
#define N 100005
#define pb push_back
#define mk make_pair
using namespace std;
vector<int>a[N];long long ans,tmp;
pair<int,int>A[N],B[N];
int Pow[N],Rev[N],son[N],val[N],vis[N],ma[N],OUT[N],IN[N];
int sum,P,n,i,x,y,M,tot,X;
inline int Q_pow(int a,int b)
{
  int res=1;
  for (;b;b>>=1,a=a*1ll*a%P) if (b&1) res=res*1ll*a%P;
  return res;
}
inline int get_root(int k,int fa)//note that it must know "sum"
{
  son[k]=1;int res=0;
  for (int i=0,go;i<a[k].size();i++)
  {
    if (vis[go=a[k][i]]||go==fa) continue;
    int tmp=get_root(go,k);
    son[k]+=son[go];ma[k]=max(ma[k],son[go]);
    if (ma[tmp]<ma[res]||!res) res=tmp;
  }
  ma[k]=max(ma[k],sum-son[k]);
  if (ma[k]<ma[res]||!res) res=k;
  return res;
}
inline void dfs(int k,int out,int in,int fa,int deep) //define out cannot include root
{
  out=(out*1ll*M%P+val[k])%P;in=(in+Pow[deep]*1ll*val[k]%P)%P;
  A[++tot]=mk((X-out+P)*1ll*Rev[deep]%P,k);
  B[tot]=mk(in,k);
  for (int i=0,go;i<a[k].size();i++)
  {
    if (vis[go=a[k][i]]||go==fa) continue;
    dfs(go,out,in,k,deep+1);
  }
}
inline void calc(int L,int R,int m)
{
  #define x first
  #define y second
  sort(A+L,A+R+1);
  sort(B+L,B+R+1);
  int j=L,p,q;
  for (int i=L;i<=R;)
  {
    for (p=i;p<=R&&A[p].x==A[i].x;p++);
    for (;j<=R&&B[j].x<A[i].x;j++);
    for (q=j;q<=R&&B[q].x==A[i].x;q++);
    for (int k=i;k<p;k++) OUT[A[k].y]+=m*(q-j);
    for (int k=j;k<q;k++) IN[B[k].y]+=m*(p-i);
    i=p;j=q;
  }
  #undef x
  #undef y
}
inline void divide(int k)
{
  vis[k]=1;tot=0;
  for (int i=0,go;i<a[k].size();i++)
  {
    if (vis[go=a[k][i]]) continue;
    int tmp=tot;
    dfs(go,val[k],0,k,1);
    calc(tmp+1,tot,-1);
  }
  A[++tot]=mk((X-val[k]+P)%P,k);
  B[tot]=mk(0,k);
  calc(1,tot,1);
  for (int i=0,go;i<a[k].size();i++)
    if (!vis[go=a[k][i]]) sum=son[go],divide(get_root(go,-1));
}
int main()
{
  scanf("%d%d%d%d",&n,&P,&M,&X);
  for (i=1;i<=n;i++) scanf("%d",&val[i]);
  for (i=1;i<n;i++)
    scanf("%d%d",&x,&y),a[x].pb(y),a[y].pb(x);
  for (i=Pow[0]=1;i<=n;i++) Pow[i]=Pow[i-1]*1ll*M%P;
  for (i=Rev[0]=1;i<=n;i++) Rev[i]=Q_pow(Pow[i],P-2);
  sum=n;divide(get_root(1,-1));
  ans=n*1ll*n*1ll*n;
  for (i=1;i<=n;i++)
  {
    //printf("%d %d\n",IN[i],OUT[i]);
    tmp+=2ll*OUT[i]*1ll*(n-OUT[i]);
    tmp+=2ll*IN[i]*1ll*(n-IN[i]);
    tmp+=IN[i]*1ll*(n-OUT[i]);
    tmp+=OUT[i]*1ll*(n-IN[i]);
  }
  ans-=tmp/2ll;  
  printf("%I64d\n",ans);
}
