//Language: GNU C++


/* ***********************************************
Author        :CKboss
Created Time  :2015年03月10日 星期二 21时54分06秒
File Name     :CF484D_2.cpp
************************************************ */

#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <string>
#include <cmath>
#include <cstdlib>
#include <vector>
#include <queue>
#include <set>
#include <map>

using namespace std;

typedef long long int LL;

const int maxn=1009000;
int n;
LL a[maxn],dp[maxn];

LL getLL()
{
	char ch; bool flag=true;
	LL ret=0; LL fg=1;
	while(ch=getchar())
	{
		if((ch>='0'&&ch<='9')||ch=='-') 
		{
			if(flag) flag=false;
			if(ch=='-') fg=-1;
			else ret=ret*10LL+ch-'0';
		}
		else if(flag==false) break;
	}
	return ret*fg;
}

int main()
{
    //freopen("in.txt","r",stdin);
    //freopen("out.txt","w",stdout);

	scanf("%d",&n);
	getchar();
	for(int i=1;i<=n;i++) a[i]=getLL();

	int gd=1;
	bool up;
	if(a[2]>a[1]) up=true;
	else up=false;

	for(int i=2;i<=n;i++)
	{
		if(a[i-1]<a[i]) /// up
		{
			if(up==true)
			{
				dp[i]=max(a[i]-a[gd]+dp[gd-1],a[i]-a[gd+1]+dp[gd]);
			}
			else if(up==false) /// change gd
			{
				up=true; gd=i-1;
				dp[i]=max(dp[gd],dp[gd-1]+a[i]-a[gd]);
			}
		}
		else if(a[i-1]>a[i]) /// down
		{
			if(up==true) /// change gd
			{
				up=false; gd=i-1;
				dp[i]=max(dp[gd],dp[gd-1]+a[gd]-a[i]);
			}
			else if(up==false)
			{
				dp[i]=max(a[gd]-a[i]+dp[gd-1],a[gd+1]-a[i]+dp[gd]);
			}
		}
		else if(a[i-1]==a[i])
		{
			/// new gd
			gd=i; up=true;
			dp[i]=dp[i-1];
		}
	}
	cout<<dp[n]<<endl;
  
    return 0;
}
