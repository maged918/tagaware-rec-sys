//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <stack>
#include <bitset>
#define INF 0x3f3f3f3f
#define eps 1e-8
#define FI first
#define SE second
using namespace std;
typedef long long LL;
const int N = 1e5 + 5;
int F[N], sz[N];

int findroot(int x) {
    return F[x] == x ? x : F[x] = findroot(F[x]);
}

int main() {
    int n, m, mod;
    scanf("%d%d%d", &n, &m, &mod);
    for(int i = 1; i <= n; ++i) F[i] = i, sz[i] = 1;
    for(int u, v, i = 0; i < m; ++i) {
        scanf("%d%d", &u, &v);
        if(findroot(u) == findroot(v)) continue;
        sz[findroot(u)] += sz[findroot(v)];
        F[findroot(v)] = findroot(u);
    }
    int cnt = 0;
    LL ans = 1;
    for(int i = 1; i <= n; ++i) {
        if(findroot(i) != i) continue;
        ++cnt;
        ans = ans * sz[i] % mod;
    }
    if(cnt == 1) {
        printf("%d\n", 1 % mod);
        return 0;
    }
    for(int i = 0; i < cnt - 2; ++i) ans = ans * n % mod;
    printf("%I64d\n", ans);
    return 0;
}

		 		   	 				 		  	 		  					