//Language: MS C++


//http://codeforces.com/contest/519/problem/C?locale=en
//C. A and B and Team Training


#include <iostream>
using namespace std;


int count(int& n, int& m){
    int count = 0;
    while (n > 0 && m > 0){
        if ((n > 1 && m > 0) || (n > 0 && m > 1)){
            if (n > m){

                n -= 2;
                m--;
            }
            else{
                n--;
                m -= 2;
            }
            count++;
        }
        else break;
    }
    return count;
}

int main(){
    int n, m;
    cin >> n >> m;
    cout << count(n, m) << endl;
    return 0;
}