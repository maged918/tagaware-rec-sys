//Language: GNU C++11


#include<iostream>
#include<math.h>
#include<string>
#include<algorithm>

using namespace std;

int main()
{
    int n,a=0;
    unsigned long long x=0,y=0;
    string s;
    cin>>n;
    cin>>s;
    for(int i=0;i<s.size();i++)
    {
        if(s[i]!='7'&&s[i]!='4')
        {
            a=-1;
            break;
        }
        a=0;
    }
        if(a==-1)
            cout<<"NO";
        else
        {
            for(int i=0,j=s.size()-1;i<s.size()/2;i++,j--)
            {
                x+=s[i]-'0';
                y+=s[j]-'0';
            }
            if(x==y)
                cout<<"YES";
            else
                cout<<"NO";
        }



    return 0;
}
