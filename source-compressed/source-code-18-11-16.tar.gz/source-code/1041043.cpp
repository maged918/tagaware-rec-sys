//Language: GNU C++


#include <iostream>
#include <string>
#include <string.h>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <stdio.h>
#include <math.h>
using namespace std;
 
const int MAX = 100005;
 
typedef __int64 int64;
 
vector<int> tree[MAX];
int n, val[MAX];
 
void dfs(int f, int u, int64& max_get, int& left)
{
    vector<int> v_left;
    vector<int64> v_get;
 
    for(int i = 0; i < tree[u].size(); i++)
    {
        int v = tree[u][i];
        if(v != f && val[v])    //val[v]要有值才可达
        {
            int c_left = val[v] - 1;
            int64 c_get;
            dfs(u, v, c_get, c_left);
 
            v_get.push_back(c_get);
            v_left.push_back(c_left);
        }
    }
 
    sort(v_get.begin(), v_get.end());
 
    max_get = 0;
 
    for(int i = v_get.size() - 1; left && i >= 0; i--)
    {
        left--;
        max_get += v_get[i] + 2;    
    }
 
    for(int i = 0; i < v_left.size() && left; i++)
    {
        int t = min(left, v_left[i]);
        left -= t;
        max_get += 2 * t; 
    }
 
    //printf("%d get %I64d left %d\n", u, max_get, left);
 
}
 
int main()
{
    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
        scanf("%d", &val[i]);
 
    for(int i = 1; i < n; i++)
    {
        int a, b;
        scanf("%d%d", &a, &b);
        tree[a].push_back(b);
        tree[b].push_back(a);
    }                                              
 
    int root;
    scanf("%d", &root);
 
    int64 ans;
    dfs(0, root, ans, val[root]);
 
    printf("%I64d\n", ans);
}

		 			  	 	  		  	  	    	