//Language: GNU C++


#include <iostream>
#include<cstring>
#include<string>
#include<cmath>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<set>
#include<queue>
#include<algorithm>
#include<map>
using namespace std;

int main()
{
    string s;
    int n;
    int k;
    cin >> s;
    cin >> n;
    int m = s.length();
    int arr[s.size()];
    memset(arr, 0, sizeof(arr));
    for(int i = 0; i < n; i++){
        cin >> k;
        arr[k-1]++;
    }

    int sum = 0;
    for(int i = 0; i < s.size()/2; i++){
        sum+=arr[i];
        if(sum%2){
            char tmp = s[i];
            s[i] = s[s.size() - 1 - i];
            s[s.size() - 1 - i] = tmp;
        }
    }

    cout << s << endl;
    return 0;
}
