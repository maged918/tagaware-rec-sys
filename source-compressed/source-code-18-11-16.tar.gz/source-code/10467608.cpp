//Language: GNU C++


# include <bits/stdc++.h>


//Defines
# define Pi 3.14159265358979323846
# define pf first
# define ps second
# define mp make_pair
# define pb push_back

/*NOTES
    %I64d
*/

using namespace std;

    typedef long long ll;
    typedef long double ld;

    //Variables!!!
            string sss;
            char s[200002];
            vector <int> a;
            int i, k, l, m, n, o, p;
    //End of Variables

    //Functions!!!

    //End of Functions!!!

int main(){

//    freopen ("input.txt", "r", stdin);
//    freopen ("output.txt", "w", stdout);

    scanf ("%s", &s);
    sss=string(s);
    m=sss.size();
    a.resize(m+1);
    scanf ("%d", &n);
    for (int i=0; i<n; i++){
        scanf ("%d", &k);
        k--;
        a[k]++;
    }
    k=0;
    for (int i=0; i<m/2; i++){
        k+=a[i];
        if (k%2) swap(s[i], s[m-i-1]);
    }
    printf("%s", s);

    return 0;
}
