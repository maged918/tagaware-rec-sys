//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<vector>
#include<cmath>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<algorithm>
using namespace std;
const int maxn=200010;
char s[maxn],ans[maxn];
int op[maxn];
int M;
int main()
{
    while(scanf("%s",s+1)!=EOF)
    {
        scanf("%d",&M);
        for(int i=1;i<=M;i++)scanf("%d",&op[i]);
        sort(op+1,op+M+1);
        memset(ans,0,sizeof(ans));
        int len=strlen(s+1);
        //cout<<len<<endl;
        op[0]=1;
        op[M+1]=len/2+1;
        for(int i=0;i<=M+1;i++)
        {
            if(i&1)
            {
                for(int j=op[i];j<op[i+1];j++)
                    ans[j]=s[len-j+1],ans[len-j+1]=s[j];
            }
            else
                for(int j=op[i];j<op[i+1];j++)
                    ans[j]=s[j],ans[len-j+1]=s[len-j+1];
        }
        if(len&1)ans[len/2+1]=s[len/2+1];
        for(int i=1;i<=len;i++)
            printf("%c",ans[i]);
        printf("\n");
        //printf("%s\n",ans+1);
    }
    return 0;
}
