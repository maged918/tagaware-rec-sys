//Language: GNU C++11


#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <memory.h>
#include <algorithm>
#include <vector>
#include <queue>
#include <map>
#include <string>
#include <set>
#include <stack>
#include <utility>
#include <bitset>
#include <cassert>
#include <climits>
#include <functional>
#include <sstream>

using namespace std;

#define X first
#define Y second
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(), (x).end()
#define rall(x) (x).rbegin(), (x).rend()

typedef long long ll;
typedef unsigned long long ull;

const double eps = 1e-9;
const double pi = 3.14159265359;
const ll inf = 1000000000000000000LL;

void update(int a, multiset<int>& lengths, set<int>& pieces) {
    auto it = pieces.insert(a).X;

    int l = *(--it);
    int r = *(++(++it));

    lengths.erase(lengths.find(r - l));
    lengths.insert(a - l);
    lengths.insert(r - a);
}

int main() {
    //freopen(".in", "r", stdin); freopen(".out", "w", stdout);
    int w, h, n;

    scanf("%d %d %d", &w, &h, &n);

    multiset<int> lengths[2];
    lengths[0].insert(w);
    lengths[1].insert(h);

    set<int> pieces[2];
    pieces[0].insert(0);
    pieces[0].insert(w);
    pieces[1].insert(0);
    pieces[1].insert(h);

    while (n--) {
        char c;
        int a;

        scanf(" %c %d", &c, &a);
        
        update(a, lengths[c == 'H'], pieces[c == 'H']);

        printf("%I64d\n", (ll)(*lengths[0].rbegin()) * (*lengths[1].rbegin()));
    }
    return 0;
}
