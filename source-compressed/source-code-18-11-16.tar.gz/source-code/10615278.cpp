//Language: GNU C++


#include <iostream>
#include <math.h>
using namespace std;
bool primes[1000001];
int main()
{
    int t;
    long long num,p;
    for(int i=2;i*i<1000001;i++){
        if(!primes[i]){
            for(int j=i*i;j<1000001;j+=i)
                primes[j]=true;
        }
    }
    cin>>t;
    for(int k=0;k<t;k++){
        cin>>num;
        if(num==1){
        cout<<"NO"<<endl;
        continue;
        }
        p=(long long)sqrt(num);
        if(p*p==num){
            if(!primes[p])
            cout<<"YES"<<endl;
            else
            cout<<"NO"<<endl;
        } else {
            cout << "NO" << endl;
        }
        
    }
    return 0;
}