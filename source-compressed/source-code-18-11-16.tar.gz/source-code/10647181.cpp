//Language: GNU C++


#include <iostream>
#include <cmath>
#include <string>
#include <vector>
#include <cstring>
#include <cstdio>
#include <map>
#include <set>
#include <algorithm>

using namespace std;

#define f first
#define s second
#define mk make_pair
#define pb push_back
#define all(a) a.begin(), a.end()
#define sqr(x) (x) * (x)
#define forn(i, l, r) for(int i = l; i < r; i ++)
#define forit(it, s) for(__typeof(s.begin()) it = s.begin(); it != s.end(); it ++)
#define y1 salnk
#define sz 100100              


const int inf = (int)1e9;
const int mod = inf + 7;
const double pi = acos(-1.0);
const double eps = 1e-9;


vector <int> a[sz];
int cp, n, m, u, v, mp[sz], used[sz], dp[sz], pd[sz];
vector <int> tv, tu;

bool pretty(int x) {
    while (x) {
        if ((x % 10) != 4 && (x % 10) != 7) return 0;
        x /= 10;
    }
    return 1;
}
void dfs(int v) {
    used[v] = 1;
    cp++;
    for (int i = 0; i < a[v].size(); i++) {
        int to = a[v][i];
        if (!used[to])
            dfs(to);
    }
}
int main () {
//  freopen("in", "r", stdin);
    scanf("%d%d\n", &n, &m);
    for (int i = 0; i < m; i++) {
        scanf("%d%d", &u, &v);
        a[u].pb(v);
        a[v].pb(u);
    }   
    for (int i = 1; i <= n; i++)
        if (!used[i]) {
            cp = 0;
            dfs(i);
            mp[cp]++;
        }

    dp[0] = 1;
    for (int num = 1; num <= 77777; num++) {
        if (mp[num] == 0) continue;
        int x = mp[num], j = 0;
        while (x) {
            if ((1 << j) > x) {
                break;
            }
            x -= (1 << j);
            tv.pb((1 << j) * num);
            tu.pb((1 << j));
            j++;
        }
        if (x > 0) {
            tv.pb(x * num);
            tu.pb(x);
        }


    }
    for (int i = 0; i < tv.size(); i++)
            for (int j = 77777-tv[i]; j >= 0; j--)
                if (dp[j]) {
                    if (dp[j + tv[i]]) {
                        pd[j + tv[i]] = min(pd[j + tv[i]], pd[j] + tu[i]);
                    } else {
                        dp[j + tv[i]] = 1;
                        pd[j + tv[i]] = pd[j] + tu[i];
                    }
                }
    
    int ma = (1 << 30);


    for (int i = 1; i <=77777; i++) {
        if (!pretty(i) || !dp[i]) continue;
        if (pd[i] < ma) {
            ma = pd[i];
        }
    }
    if (ma == (1 << 30)) 
        cout << -1;
    else
        cout << ma-1;   
    return 0;
}