//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

vector <int> a, b;
vector <pair<int,int>> o;

int main() {
	int n, win = -1;
	cin >> n;
	for (int i=0,x; i<n; ++i) {
		cin >> x;
		if (x == 1) a.push_back(i);
		else b.push_back(i);
		if (i == n - 1) win = x;
	}
	int la = (int)a.size(), lb = (int)b.size();
	for (int t=1,i,j; t<=n; ++t) {
		int sa = 0, sb = 0;
		for (i=j=0; i<la||j<lb; ) {
			int ed_i = i + t - 1, ed_j = j + t - 1;
			if (ed_i >= la && ed_j >= lb) break;
			if (ed_i < la && (ed_j >= lb || a[ed_i] < b[ed_j])) {
				++sa;
				i = ed_i + 1;
				j = lower_bound(b.begin(), b.end(), a[ed_i]) - b.begin();
			} else {
				++sb;
				j = ed_j + 1;
				i = lower_bound(a.begin(), a.end(), b[ed_j]) - a.begin();
			}
		}
//		printf("%d %d %d\n", t, sa, sb);
		if (win == 1 && i == la && sa > sb) o.push_back({sa, t});
		if (win == 2 && j == lb && sb > sa) o.push_back({sb, t});
	}
	cout << o.size() << endl;
	sort(o.begin(), o.end());
	for (auto &p: o) cout << p.first << ' ' << p.second << endl;
	return 0;
}
