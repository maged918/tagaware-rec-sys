//Language: GNU C++11


#include <bits/stdc++.h>
#define all(a) (a).begin(),(a).end()
#define ld long double
#define ll long long
#define sqr(a) (a)*(a)
#define mp make_pair
#define pb push_back
#define x first
#define y second
#define inf (int)1e9
#define pi pair<int,int>
#define y1 fdfs
using namespace std;
const int N=2e5+1;
int n,x,cur=-1;
vector<int>a[N],v;
int main()
{
    //freopen("components.in","r",stdin);
    //freopen("components.out","w",stdout);
    ios_base::sync_with_stdio(0);
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>x;
        a[x].pb(i);
    }
    for(int i=1;i<=n;i++)
    {
        cur++;
        while(cur>=3)
            if(a[cur].size()) break;
            else cur-=3;
        if(a[cur].empty()) return cout<<"Impossible",0;
        v.pb(a[cur].back());
        a[cur].pop_back();
    }
    cout<<"Possible\n";
    for(int i=0;i<n;i++)
        cout<<v[i]<<' ';
}
