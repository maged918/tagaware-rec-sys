//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll get_eq(ll a,ll b,ll c){

    double z=(double)sqrt((double)(b*b)- 4.0*a*c );

    double ret1= (-b + z)/(2.0*a);
    double ret2= (-b - z)/(2.0*a);
    
    return max(ret1,ret2);
}
int main(){
   ll A,B,l,t,m;
   int n;
   cin>>A>>B>>n;

   for(int i=0;i<n;i++){

      cin>>l>>t>>m;

      ll Hi=A+(l-1)*B;
      if(Hi>t){
          cout<<"-1\n";
          continue;
      }
      ll N1,N2,N;

       N1=get_eq(B,B+2LL*Hi,-2LL*(t*m-Hi));

      N2=(t-Hi)/B;

      N=min(N1,N2);

      cout<<N+l<<"\n";

   }

   return 0;
}