//Language: GNU C++11


//In the name of ALLAH
//Blood Cousins Return -246E
//solution by fenwick is faster

#include <iostream>
#include <cstdio>
#include <vector>
#include <cstring>
#include <queue>
#include <algorithm>
#include <map>
#include <string>
using namespace std;

#define err(x) cout << #x << ":" << x << '\n';
typedef pair<int,int> pii;
const int N = 200010, LOG = 30, INF = 100000100;

int n, pi[N][LOG], c[N], dep[N], st[N], en[N];
map<string,int> mp;
map<pii,int> cache;
vector<pii> vec[N];
vector<int> adj[N];
int nex[N], last[N];
int fen[N];

int dfst = 0, h;

inline void dfs(int v, int d = 0){
    h = h < d ? d: h;
    vec[dep[v] = d].push_back({st[v] = ++dfst, c[v]});
    for (int u:adj[v])
        dfs(u, d+1);
    en[v] = dfst;
}

inline int kthpar(int v, int k){
    for (int j=LOG-1;j>=0;j--)
        if (k>>j&1)
            v = pi[v][j];
    return v;
}

vector<pair<pii,int> > que[N];
int ans[N], cnt[N];


inline bool cmp(const pair<pii,int>& x, const pair<pii,int>& y){
    if (x.first.second != y.first.second)
        return x.first.second < y.first.second;
    return x.first.first < y.first.first;
}

inline void add(int sz, int i, int val){
    for (;i<=sz;i+=i&-i)
        fen[i] += val;
}

inline int ask(int sz, int i){
    int res = 0;
    for(;i>0;i^=i&-i)
        res += fen[i];
    return res;
}

inline void solve(int d){
    sort(que[d].begin(), que[d].end(), cmp);
    for (int i=0;i<=(int)vec[d].size();i++){
        cnt[i] = fen[i] = 0;
        if (i < (int)vec[d].size()) last[vec[d][i].second] = -1;
    }
    int ptr = 0;
    int u;

    for (int i=0;i<(int)vec[d].size();i++){
        u = vec[d][i].second;
        if (last[u] != -1){
            cnt[last[u]]--;
            add((int)vec[d].size(),last[u],-1);
        }
        cnt[last[u] = i+1]++;
        add((int)vec[d].size(),last[u],1);

        while (ptr < (int)que[d].size() && que[d][ptr].first.second == i+1){
            ans[que[d][ptr].second] = ask((int)vec[d].size(),i+1) - ask((int)vec[d].size(), que[d][ptr].first.first - 1);
            ptr++;
        }
    }
}

int main(){
    scanf("%d",&n);
    int r, nexfree = 0;
    string s;
    for (int i=1;i<=n;i++){
        cin >> s;
        scanf("%d",&r);
        pi[i][0] = r;
        if (r) adj[r].push_back(i);
        if (mp.find(s) == mp.end())
            mp[s] = ++nexfree;
        c[i] = mp[s];
    }

    for (int i=1;i<=n;i++)
        if (!pi[i][0])
            dfs(i);
    for (int i=1;i<=n;i++)
        for (int j=1;j<LOG;j++)
            pi[i][j] = pi[pi[i][j-1]][j-1];

    for (int i=0;i<=h;i++)
        sort(vec[i].begin(), vec[i].end());

    int q, v, k, d;
    int beg, fin;
    scanf("%d",&q);
    for (int i=1; i <= q; i++){
        scanf("%d%d",&v,&k);
        d = dep[v] + k;
        if (d > h || (int)vec[d].size() == 0){
            ans[i] = 0;
            continue;
        }
        beg = lower_bound(vec[d].begin(), vec[d].end(), pii(st[v], -1)) - vec[d].begin() + 1;
        fin = upper_bound(vec[d].begin(), vec[d].end(), pii(en[v], INF)) - vec[d].begin() + 1;
        --fin;

        if (beg > fin){
            ans[i] = 0;
            continue;
        }
        else que[d].push_back({{beg,fin},i});
    }

    for (int i=0;i<=h;i++)
        solve(i);
    for (int i=1;i<=q;i++)
        printf("%d\n", ans[i]);

    return 0;
}
