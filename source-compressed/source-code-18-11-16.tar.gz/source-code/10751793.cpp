//Language: GNU C++11


#include <bits\stdc++.h>

using namespace std;
int64_t ma[200005];
int v[200005];
int main()
{
    double sum = 0; int n , SZ = 1; cin >> n;
    int a , x;
    for(int i = 0; i < n; i ++)
    {
        int c; scanf("%d",&c);
        if(c == 1)
        {
            scanf("%d%d",&a,&x);
            ma[a-1] += x;
            sum += (x*a);
        }
        else if(c == 2)
        {
            scanf("%d",&x);
            v[SZ++] = x;
            sum += x;
        }
        else
        {
            ma[SZ-2] += ma[SZ-1];
            sum -= (v[SZ-1]+ma[SZ-1]);
            ma[SZ-1] = 0;
            SZ--;
        }
        printf("%.6f\n",sum/SZ);
    }
}
