//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <climits>

using namespace std;

typedef long long ll;

ll f[1 << 22];
int len, n;
char st[55][55];
double ans, g[1 << 22];

int main()
{	
	while (scanf("%d", &n) != EOF)
		{
			for (int i = 1; i <= n; i ++) scanf("%s", st[i] + 1);
			len = strlen(st[1] + 1);
			
			memset(f, 0, sizeof(f)); memset(g, 0, sizeof(g));
			ans = 0;
			for (int i = 1; i <= n; i ++)
				for (int j = 1; j <= n; j ++)
					if (i != j) {
						int ss = 0;
						for (int k = 1; k <= len; k ++)
							if (st[i][k] == st[j][k]) ss |= 1 << (k - 1);
						f[ss] |= 1LL << (j - 1);
					}
			for (int i = (1 << len) - 1; i; i --)
				for (int j = 1; j <= len; j ++)
					if (i & (1 << (j - 1)))
						f[i ^ (1 << (j - 1))] |= f[i];

			int l = 1 << len; g[0] = 1;
			for (int i = 0; i < l; i ++)
				{
					int cnt = len; for (int tt = i; tt; tt -= tt & -tt) cnt --;
					for (int j = 1; j <= len; j ++)
						if (!(i & (1 << (j - 1)))) g[i | (1 << (j - 1))] += (double)g[i] / cnt;
					for (int j = 1; j <= n; j ++)
						if (f[i] & (1LL << (j - 1))) ans += g[i];
				}
			printf("%.10Lf\n", ans / n);
		}
	return 0;
}
