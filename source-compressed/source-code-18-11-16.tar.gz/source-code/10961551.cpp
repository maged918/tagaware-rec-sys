//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <stack>
#include <bitset>
#define INF 0x3f3f3f3f
#define eps 1e-8
#define FI first
#define SE second
using namespace std;
typedef long long LL;
const int N = 100005;
int head[N];
struct Edge {
    int nxt, to;
} ed[N * 2];
int ecnt;

void addedge(int u, int v) {
    ed[ecnt].nxt = head[u];
    ed[ecnt].to = v;
    head[u] = ecnt++;
}

bool done[N];
int sz[N], mx[N], pt[N], cc;
void get_sz(int u, int fa) {
    pt[cc++] = u;
    sz[u] = 1; mx[u] = 0;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v] || v == fa) continue;
        get_sz(v, u);
        sz[u] += sz[v];
        mx[u] = max(mx[u], sz[v]);
    }
}

int get_center(int u) {
    cc = 0;
    get_sz(u, u);
    int center, mi = INF;
    for(int i = 0; i < cc; ++i) {
        int v = max(mx[pt[i]], sz[u] - sz[pt[i]]);
        if(v < mi) {
            mi = v;
            center = pt[i];
        }
    }
    return center;
}

int Mod, P, Goal;
LL pw[N], inv[N];
int w[N], in[N], out[N];
map <int, int> mp;

void dfs1(int u, int fa, int val, int dep) {
    val = (1LL * val * P + w[u]) % Mod;
    int x = (Goal - val + Mod) % Mod;
    x = x * inv[dep] % Mod;
    map <int, int>::iterator it = mp.find(x);
    if(it != mp.end()) out[u] += it->SE;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v] || v == fa) continue;
        dfs1(v, u, val, dep + 1);
    }
}

void dfs2(int u, int fa, int val, int dep) {
    val = (val + w[u] * pw[dep]) % Mod;
    mp[val]++;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v] || v == fa) continue;
        dfs2(v, u, val, dep + 1);
    }
}

int son[N];
void cal_out(int u) {
    int cnt = 0;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v]) continue;
        son[cnt++] = v;
    }
    mp.clear();
    for(int i = 0; i < cnt; ++i) {
        int v = son[i];
        dfs1(v, u, w[u], 2);
        dfs2(v, u, 0, 0);
    }
    mp.clear(); mp[0] = 1;
    for(int i = cnt - 1; i >= 0; --i) {
        int v = son[i];
        dfs1(v, u, w[u], 2);
        dfs2(v, u, 0, 0);
    }
    int x = (Goal - w[u] + Mod) % Mod;
    x = x * inv[1] % Mod;
    out[u] += mp[x];
}

void dfs3(int u, int fa, int val, int dep) {
    val = (val + w[u] * pw[dep]) % Mod;
    map <int, int>::iterator it = mp.find(val);
    if(it != mp.end()) in[u] += it->SE;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v] || v == fa) continue;
        dfs3(v, u, val, dep + 1);
    }
}

void dfs4(int u, int fa, int val, int dep) {
    val = (1LL * val * P + w[u]) % Mod;
    int x = (Goal - val + Mod) % Mod;
    x = x * inv[dep] % Mod;
    mp[x]++;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v] || v == fa) continue;
        dfs4(v, u, val, dep + 1);
    }
}

void cal_in(int u) {
    int cnt = 0;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v]) continue;
        son[cnt++] = v;
    }
    int x = (Goal - w[u] + Mod) % Mod;
    x = x * inv[1] % Mod;
    mp.clear();
    for(int i = 0; i < cnt; ++i) {
        int v = son[i];
        dfs3(v, u, 0, 0);
        dfs4(v, u, w[u], 2);
    }
    mp.clear(); mp[x] = 1;
    for(int i = cnt - 1; i >= 0; --i) {
        int v = son[i];
        dfs3(v, u, 0, 0);
        dfs4(v, u, w[u], 2);
    }
    in[u] += mp[0];
}

void solve(int u) {
    cal_out(u); cal_in(u);
    done[u] = 1;
    for(int e = head[u]; ~e; e = ed[e].nxt) {
        int v = ed[e].to;
        if(done[v]) continue;
        solve(get_center(v));
    }
}

inline int Exp(int a, int p) {
    int res = 1;
    while(p) {
        if(p & 1) res = (LL)res * a % Mod;
        p >>= 1;
        a = (LL)a * a % Mod;
    }
    return res;
}

int main() {
    int n;
    scanf("%d%d%d%d", &n, &Mod, &P, &Goal);
    pw[0] = 1;
    for(int i = 1; i <= n; ++i) pw[i] = pw[i - 1] * P % Mod;
    for(int i = 0; i <= n; ++i) inv[i] = Exp(pw[i], Mod - 2);
    memset(head, -1, sizeof(head));
    for(int i = 1; i <= n; ++i) scanf("%d", w + i);
    for(int u, v, i = 1; i < n; ++i) {
        scanf("%d%d", &u, &v);
        addedge(u, v);
        addedge(v, u);
    }
    solve(get_center(1));
    LL ans = 0;
    for(int i = 1; i <= n; ++i) {
        ans += 2LL * in[i] * (n - in[i]);
        ans += 2LL * out[i] * (n - out[i]);
        ans += 1LL * in[i] * (n - out[i]);
        ans += 1LL * (n - in[i]) * out[i];
    }
    ans = 1LL * n * n * n - ans / 2;
    printf("%I64d\n", ans);
    return 0;
}
