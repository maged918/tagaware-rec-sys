//Language: GNU C++11


//Adilkhan Kozhakhmetov
#include <bits/stdc++.h>

#define ll long long
#define pb push_back
#define endl "\n"
#define mp make_pair 
#define f first
#define s second
#define all(x) x.begin(), x.end()
#define fname ""
#define sz(x) (int)(x.size())

using namespace std;
                                            
const int Maxn = int (1e5) + 256;
const int INF = int(1e9);

string s;
int n, l, r, res, k, z;
char q;
vector <int> v;
set <char> S;

int main () {
	ios_base :: sync_with_stdio (false);
	cin.tie(0);
	//freopen (fname".in","r",stdin);
	//freopen (fname".out","w",stdout);
	cin >> k;
	cin >> s;
	for (int i = 0; i < s.size(); ++i) {
		S.insert(s[i]);
	}
	if (S.size() < k) {
		cout << "NO";
		return 0;
	}    
	S.clear();
	for (int i = 0; i < s.size(); ++i) {
		if (S.find(s[i]) == S.end()) {
			v.pb(i);
			S.insert(s[i]);
			k--;
		}		
		if (k == 0) {
			break;
		}
	}                    
	cout << "YES" << endl;
	v.pb(s.size());
	for (int i = 0; i < v.size() - 1; ++i) {
		for (int j = v[i]; j < v[i + 1]; ++j) {
			cout << s[j];
		}
		cout << endl;
	}
	return 0;          	
}