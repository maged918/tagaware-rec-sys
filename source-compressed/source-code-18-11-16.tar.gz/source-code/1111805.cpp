//Language: MS C++


#include<iostream>
#include<cstring>
#include<algorithm>
#define ll __int64
#define MOD 1000000007
using namespace std;
struct Unit{
    int n,v;
    bool friend operator<(Unit a,Unit b){
        return a.v<b.v;
    }
};
int N,K,other;
Unit num[100000];
bool islucky(int x){
    if(!x)return 0;
    while(x){
        if(x%10!=4&&x%10!=7)return 0;
        x/=10;
    }
    return 1;
}
void get_data(){
    int tn,n,i;
    scanf("%d%d",&tn,&K);N=0;other=0;
    while(tn--){
        scanf("%d",&n);
        if(islucky(n)){
            num[++N].v=n;
            num[N].n=1;
        }else other++;
    }
    sort(num+1,num+1+N);
    tn=1;
    for(i=2;i<=N;i++){
        if(num[i].v==num[tn].v)num[tn].n++;
        else num[++tn]=num[i];
    }
    N=tn;
}
ll dp[100000],C[100005];
ll f_pow(ll x,int n){
    ll res=1;
    while(n){
        if(n&1)res=(res*x)%MOD;
        n>>=1;
        x=(x*x)%MOD;
    }
    return res;
}
void get_C(int x){
    C[0]=1;
    int i;
    for(i=1;i<=x;i++){
        C[i]=(C[i-1]*(x+1-i))%MOD*f_pow(i,MOD-2)%MOD;
    }
}
void run(){
    if(K>N+other){printf("0\n");return;}
    //dp[i][j]=dp[i-1][j-1]*num[i]+dp[i-1][j];
    int i,j,lim=N<K?N:K;
    dp[0]=1;
    for(j=1;j<=lim;j++)dp[j]=0;
    for(i=1;i<=N;i++){
        for(j=lim;j>0;j--){
            dp[j]+=dp[j-1]*num[i].n;
            dp[j]%=MOD;
        }
    }
    ll res=0;
    get_C(other);
//  printf("%d %d %I64d %I64d\n",N,other,dp[0],dp[1]);
    for(i=0;i<=lim;i++){
        if(K-i>other)continue;
        res+=dp[i]*C[K-i];
        res%=MOD;
    }
    printf("%I64d\n",res);
}
int main(){
    get_data();
    run();
    return 0;
}