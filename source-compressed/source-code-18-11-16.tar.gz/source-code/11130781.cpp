//Language: GNU C++


#include <stdio.h>
#include <vector>
#include<queue>
#include <cmath>
using namespace std;

const int N=208;

struct point
{
	int r_loc;
	int c_loc;
};

struct condition
{
	point location;
	int cost;
	bool operator<(const condition & c)const
	{
		return cost>c.cost;
	}
};

int visit[N][N]={0};
int r_diff[4]={1,-1,0,0};
int c_diff[4]={0,0,1,-1};
int graph[N][N]={0};
int time_inc[N] =
{ 0 };
int c_cordinate[N] =
{ 0 };
int r_cordinate[N] =
{ 0 };

int n_point, cost;


bool is_legal(condition&c)
{
	if(c.location.c_loc<0||c.location.r_loc<0)
	{
		return 0;
	}
	if(c.location.r_loc>=N||c.location.c_loc>=N)
	{
		return 0;
	}
	if(visit[c.location.r_loc][c.location.c_loc]==1)
	{
		return 0;
	}
	visit[c.location.r_loc][c.location.c_loc]=1;
	return 1;

}
int ext_bfs(point & start,point& end)///another version of floyd~
{
	priority_queue<condition> pq;
	condition now;
	condition next;
	now.location=start;
	now.cost=0;
	pq.push(now);
	while(!pq.empty())
	{
		now=pq.top();
		pq.pop();
		if(now.location.r_loc==end.r_loc&&now.location.c_loc==end.c_loc)
			return now.cost;
		now.cost+=cost;
		for(int i=0;i<4;i++)
		{
			next=now;
			next.location.r_loc+=r_diff[i];
			next.location.c_loc+=c_diff[i];
			if(is_legal(next))
			{
				next.cost-=graph[next.location.r_loc][next.location.c_loc];

				pq.push(next);
			}

		}
	}
}

int main()
{
	scanf("%d%d", &n_point, &cost);

	for (int i = 1; i < n_point - 1; i++)
	{
		scanf("%d", time_inc + i);
	}
	for (int i = 0; i < n_point; i++)
	{
		scanf("%d%d", c_cordinate + i, r_cordinate + i);
		c_cordinate[i] += 100;
		r_cordinate[i] += 100;
	}

	for (int i = 1; i < n_point - 1; i++)
	{
		graph[r_cordinate[i]][c_cordinate[i]] = time_inc[i];
	}

	if (c_cordinate[0] > c_cordinate[n_point - 1])
	{
		swap(c_cordinate[0], c_cordinate[n_point - 1]);
		swap(r_cordinate[0], r_cordinate[n_point - 1]);
	}
	point start,end;
	start.r_loc=r_cordinate[0];
	start.c_loc=c_cordinate[0];

	end.r_loc=r_cordinate[n_point-1];
	end.c_loc=c_cordinate[n_point-1];

	printf("%d\n",ext_bfs(start,end));

}

  		  	 		 	  			 		  			   	 	