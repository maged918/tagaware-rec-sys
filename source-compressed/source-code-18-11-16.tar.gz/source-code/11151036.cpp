//Language: GNU C++11


#include <stdio.h>
#include <algorithm>
#include <vector>
#include <set>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <utility>
#include <queue>
#include <stack>
#include <map>
#include <math.h>
#include <iostream>

using namespace std;

#define X first
#define Y second
#define mp make_pair
#define pb push_back
#define piii pair<pair<int,int>,int>
#define pii pair<int,int>
#define pdd pair<double,double>
#define MAXN 100010

int N, a[MAXN];

void Debug()
{
}

void Read()
{
    cin >> N;
    for(int i=1; i<=N; ++i)
        cin >> a[i];

    sort(a+1, a+N+1);
}

void Solve()
{
    int sum=0, out=0;
    for(int i=1; i<=N; ++i)
    {
        if(a[i] >= sum)
        {
            ++out;
            sum += a[i];
        }
    }

    cout << out << "\n";
}

int main()
{
    Read();
    Solve();
    Debug();
    return 0;
}
