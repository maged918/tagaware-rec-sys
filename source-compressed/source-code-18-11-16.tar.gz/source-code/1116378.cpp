//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <queue>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <ctime>

using namespace std;

const long long inf = 1000000000000000001LL;

pair<int, int> order[200];
long long f[200][100];
char know[200];

long long solve(int n) {
	memset(f, 0, sizeof(f));
	f[0][0] = 1;
	for (int i = 0; i < n; i ++)
		for (int j = 0; j <= n / 2; j ++)
			if (f[i][j] > 0) {
				if (know[i] != ')' && j < n / 2) {
					f[i+1][j+1] += f[i][j];
					if (f[i+1][j+1] > inf) f[i+1][j+1] = inf;
				}
				if (know[i] != '(' && j > 0) {
					f[i+1][j-1] += f[i][j];
					if (f[i+1][j-1] > inf) f[i+1][j-1] = inf;
				}
			}
	return f[n][0];
}

int main() {
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	
	int n, m;
	long long k;
	scanf("%d%d%I64d", &n, &m, &k);
	for (int i = 0; i < n + m - 1; i ++)
		order[i] = make_pair(n * m + 1, i);
	for (int i = 0; i < n; i ++)
		for (int j = 0; j < m; j ++) {
			int x;
			scanf("%d", &x);
			order[i + j].first = min(order[i + j].first, x);
		}
	
	sort(order, order + n + m - 1);
	memset(know, '.', sizeof(know));
	for (int i = 0; i < n + m - 1; i ++) {
		int cur = order[i].second;
		know[cur] = '(';
		long long tmp = solve(n + m - 1);
		if (k > tmp) {
			k -= tmp;
			know[cur] = ')';
		}
	}
	
	for (int i = 0; i < n; i ++) {
		for (int j = 0; j < m; j ++)
			printf("%c", know[i + j]);
		printf("\n");
	}
	
	return 0;
}
