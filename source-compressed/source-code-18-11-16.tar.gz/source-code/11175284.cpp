//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
#define ll long long
// Useful constants
#define INF (int)1e6
#define INFL (long long)1e18
#define EPS 1e-9
// Useful hardware instructions
#define bitcount __builtin_popcount
#define gcd __gcd
// Useful container manipulation / traversal macros
#define all(a) a.begin(), a.end()
#define in(a,b) ( (b).find(a) != (b).end())
#define pb push_back
#define fill(a,v) memset(a, v, sizeof a)// fill originally
#define mp make_pair

// Input macros
#define s(n)                        scanf("%d",&n)
#define sc(n)                       scanf("%c",&n)
#define sl(n)                       scanf("%lld",&n)
#define sf(n)                       scanf("%lf",&n)
#define ss(n)                       scanf("%s",n)

#if defined(_MSC_VER) || __cplusplus > 199711L
#define aut(r,v) auto r = (v)
#else
#define aut(r,v) typeof(v) r = (v)
#endif
#define tr(container, it) for(aut(it,container.begin()); it != container.end(); it++)


#define llu long long unsigned
#define ld long


#define DEBUG 1
#define debug(x) {if (DEBUG)cout <<#x <<" = " <<x <<endl; }
#define debugv(x) {if (DEBUG) {cout <<#x <<" = "; tr((x),it) cout <<*it <<", "; cout <<endl; }}


#define checkbit(n,b) ( (n >> b) & 1)
#define setbit(n,b) (n | ((1 << b)))
#define revbit(n,b) (n ^ ((1 << b)))
#define unsetbit(n,b) (n & (~(1 << b)))
#define rep(i,n) for(int i=0; i<(int)n;i++)
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
#define mod (1000000007L)

//typedef pair<int,pair<int,pair<int,int> > >  pp;

//freopen (fname"in","r",stdin);
//freopen (fname"out","w",stdout);

int n,m,k;
ll fac[100009],invfac[100009];

vector<int> divs[100009];

unordered_map<ll , ll> mem;

ll modpow(ll base,ll power)
{
    ll ret=1;

    while(power>0)
    {
        if(power%2==1)
        {
            ret=(ret*base)%mod;
        }
        power=power>>1;
        base = (base*base)%mod;
    }
    return ret;
}

ll ncr(ll n,ll r)
{

    ll ret = fac[n];
    ll t = invfac[r];
    ll tt=invfac[n-r];
    ret = (ret*t)%mod;
    ret=(ret*tt)%mod;
    return ret;
}

void seive()
{
    fac[0]=1;
    invfac[0]=1;
    fac[1]=invfac[1]=1;
    for(int i=2;i<100001;i++)
    {
        fac[i]=(fac[i-1]*i)%mod;
                invfac[i] = modpow(fac[i],mod-2);
        for(int j=2*i;j<100001;j += i)
        {
            divs[j].pb(i);
        }
    }
}

//F(n,f,1) = P(n,f) - sum(F(n,f,g)) // g is gcd which will basically be divisor of n, a1 + a2 +..+af = n, g is gcd of(a1,a2,..,af) => g divides n
ll solve(int n,int f,int g=1)
{
    if(n<f)return 0;
    ll key = n*1000000+f;
if(mem.find(key) != mem.end())
    {
        return mem[key];
    }

    ll &ret = mem[key];


    ret = ncr(n-1,f-1);

    tr(divs[n],it)
    {

        ret = (ret - solve(*it,f));
        if(ret < -10000000) ret +=mod;
    }

    return ret;
}

int main()
{
    int t;
    s(t);
seive();

int itr=0;
    while(t--)
    {
        itr++;
        s(n);s(m);

        if(itr>111)
        {itr=0;
        mem.clear();
        }

        if(m==1&&n==1)
        {
            cout<<1<<endl;
            continue;
        }
        else if(m==1)
        {
            cout<<0<<endl;continue;
        }
        else if(n==m)
        {
            cout<<1<<endl;continue;
        }

        cout<<(mod+solve(n,m))%mod<<endl;

    }
}
