//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
int c[5000001];
int f[5000001];
void era()
{
    int i,j;
    c[0]=c[1]=1;
    for(i=2;i<=5000000;i++)
    {
        if(c[i]!=0) continue;
        for(j=i;j<=5000000;j+=i)
            c[j]=i;
    }
}
void prep()
{
    for(int i=2;i<=5000000;i++)
    {
        if(f[i]) continue;
        f[i]=f[i/c[i]]+1;
        //if(i<=10) cout<<f[i]<<'\n';
    }
    for(int i=2;i<=5000000;i++)
        f[i]+=f[i-1];
}
int main()
{
    era();
    prep();
    int t,a,b;
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d%d",&b,&a);
        cout<<f[b]-f[a]<<'\n';
    }
}