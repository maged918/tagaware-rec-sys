//Language: GNU C++11


#include <iostream>
#include <string>
#include <vector>
#include <utility>
#include <set>
#include <deque>
#include <cstdlib>
#include <algorithm>
#include <iomanip>
#include <map>
#include <queue>

using namespace std;

typedef long long LL;

int main(){
    std::ios_base::sync_with_stdio(false);
    cin.tie(false);
    int n_max = 1e6 * 5;
    vector<LL> nDivs(n_max + 10);
    for(int d = 2; d <= n_max; d++){
        if(nDivs[d] != 0) continue; // Not prime
        for(int n = d; n <= n_max; n += d){
            int t = n;
            while(t % d == 0){
                nDivs[n]++;
                t /= d;
            }
        }
    }
    for(int i = 1; i <= n_max; i++){
        nDivs[i] += nDivs[i-1]; // Sum up to this far
    }
    
    int nGames; cin >> nGames;
    for(int i = 0; i < nGames; i++){
        int from, to;
        cin >> to >> from;
        from++;
        cout << nDivs[to] - nDivs[from-1] << "\n";
    }
}