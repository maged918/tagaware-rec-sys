//Language: GNU C++


#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
typedef long long ll;
const int MAX_N=100000+10;
const int MOD=1000000007;
int x, y;
int N, K, M;
int tot;
int a[MAX_N];
int w[MAX_N];
ll f[2][MAX_N];

int Check_Lucky(int x){
    while (x){
        if (x%10!=7 && x%10!=4) return 0;
        x/=10;
    }
    return 1;
}

void Ex_Gcd(ll a, ll b){
    if (!b) {x=1; y=0; return; }
    Ex_Gcd(b,a%b);
    ll tmp=x;
    x=y;
    y=tmp-a/b*y;
}

ll Get_Anti(ll a){
    Ex_Gcd(a,MOD);
    if (x<0) x+=MOD;
    return x;
}

void Div(ll &t, int p){
    ll anti=Get_Anti(p);
    t=t*anti%MOD;
}

void Calc(){
    f[0][0] = 1;
    for(int i = 1; i<=min(K,M); ++i) {
        f[0][i]=f[0][i - 1]*(M-i+1)%MOD;
        Div(f[0][i],i);
    }
}

void Solve(){
    Calc();
    int now = 0, pre;
    for(int i = 1; i<=tot; ++i) {
        pre=now; now^=1;
        //cout << now << " " << endl;
        f[now][0]=1;
        for(int j=1; j<=K; ++j)
            f[now][j]=(f[pre][j]+f[pre][j-1]*w[i])%MOD;
    }
//  for (int i=1; i<=K; ++i)
 //       cout << f[0][i] <<" "<<f[1][i]<<endl;
    cout << f[now][K] << endl;
}

void Init(){
    scanf("%d%d",&N,&K);
    for(int i=1; i<=N; ++i) scanf("%d",&a[i]);
    sort(a+1,a+N+1);
    for(int i=1; i<=N; ++i)
        if ((i==1 || a[i]!=a[i-1]) && Check_Lucky(a[i])) {
            ++tot;
            w[tot]++;
            while (i<N && a[i]==a[i+1]) {
                ++w[tot];
                ++i;
            }
        }
        else ++M;
}

int main()
{
    Init();
    Solve();
    return 0;
}

