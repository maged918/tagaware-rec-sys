//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

const int MXN = 1e6 + 1;
int n, m;

int main() {
    cin >> n >> m;
                   
    if(m > n + n + 2 || n > m + 1) cout << -1, exit(0);
    if(n == m || n == m + 1) {
        for(int i = 0; i < n + m; i++) cout << i % 2;   
        return 0;
    }        
    m = m - n;
    for(int i = 0; i < n; i++) {
        cout << 1;
        if(m) {
            cout << 1;
            m--;
        }
        cout << 0;
    }
    while(m--) cout << 1;
    return 0;
}