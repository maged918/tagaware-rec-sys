//Language: GNU C++11


#include <bits/stdc++.h>
#ifdef BUG
    #include "debug.hpp"
#else
    #define DEBUG(var)
    #define EXPECT(expr)
#endif
#define NO_IO_TIE ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

using namespace std;
template< class T1, class T2 > inline istream &
operator>>( istream & fin, pair< T1, T2 > & pr )
{ fin >> pr.first >> pr.second; return fin; }
template< class T0, class T1, class T2 > inline istream &
operator>>( istream & fin, tuple< T0, T1, T2 > & t )
{ fin >> get<0>(t) >> get<1>(t) >> get<2>(t); return fin; }
template< class T > inline istream &
operator>>( istream & fin, vector< T > & a ) {
if(! a.size()){ size_t n; fin >> n; a.resize( n ); }
for( auto & u: a) fin >> u; return fin; }
/* @@@ ----------------------------------- */

/**
 * given distances/depth & parents returns the data-structure
 * for lowest common ancesstor calculations
 * all vectors end w/ root node as long as par[root] = root;
 */
inline vector<vector<size_t>>
lca(const vector<size_t> & dist,
    const vector<size_t> & par)
{
    const auto n = dist.size();
    const size_t root = find(begin(dist), end(dist), 0) - begin(dist);

    /* last node is root which should be excluded */
    vector<vector<size_t>> out(n);
    for(size_t i = 0; i < n; ++i)
        out[i].push_back(par[i]);

    /* bottom up order of processing nodes in tree */
    const auto comp = [&dist](const size_t i, const size_t j){
        return dist[j] < dist[i];
    };

    /* exclude root & all immediate nodes below it */
    vector<size_t> ord;
    for(size_t i = 0; i < n; ++i)
        if(i != root && par[i] != root)
            ord.push_back(i);

    sort(begin(ord), end(ord), comp);

    while(!ord.empty())
    {
        auto iter = begin(ord);
        for(const auto i: ord)
        {
            /* append the last node of the last node */
            const auto inc = out[out[i].back()].back();
            out[i].push_back(inc);
            if(inc) /* not hit the root yet */
                *iter++ = i;
        }
        ord.erase(iter, end(ord));
    }
    return out;
}


/* both nodes are @ the same depth but not same nodes */
size_t xsolve1(size_t u, size_t v,
        const vector<vector<size_t>> & xpar,
        const vector<size_t> & subtree)
{
    /* find the nodes right below common parent */
    while(xpar[u][0] != xpar[v][0])
    {
        size_t i = 1;
        while(i < xpar[u].size() && xpar[u][i] != xpar[v][i])
            ++ i;

        u = xpar[u][i-1];
        v = xpar[v][i-1];
    }

    /* u & v are right bellow their common parent */
    /* every node which is not in sub-tree of u or v is in exact middle */
    const auto n = subtree.size();
    return n - subtree[u] - subtree[v];
}

/* lowest common ancesstor */
size_t lca(size_t u, size_t v,
           const vector<size_t> & dist,
           const vector<vector<size_t>> & par)
{
    /* first bring them to same height */
    if(dist[u] < dist[v])
        swap(u, v);

    while(dist[v] < dist[u]) {
        size_t i = 1;
        while(i < par[u].size() && dist[v] < dist[par[u][i]] + 1)
            ++ i;

        u = par[u][i-1];
    }

    if(u == v) /* u was in sub-tree of v */
        return u;

    /* u & v are @ same level but not same nodes */
    /* find the nodes right below their lowest common ancesstor */
    while (par[u][0] != par[v][0]) {
        size_t i = 1;
        while(i < par[u].size() && par[u][i] != par[v][i])
            ++ i;

        u = par[u][i - 1];
        v = par[v][i - 1];
    }

    return par[u][0];
}


size_t xsolve2(size_t u, size_t v,
               const vector<size_t> & dist,
               const vector<vector<size_t>> & xpar,
               const vector<size_t> & subtree)
{
    if(dist[u] < dist[v])
        swap(u, v);

    const auto a = lca(u, v, dist, xpar);
    /* distance of the node on shorted path */
    const auto d = dist[a] + ((dist[u] - dist[v]) >> 1);

    /* find the node right below that */
    size_t w = u;
    while(d + 1 != dist[w])
    {
        size_t i = 1;
        while(i < xpar[w].size() && d < dist[xpar[w][i]])
            ++ i;

        w = xpar[w][i - 1];
    }

    /*
     * any node in sub-tree of par of w which is not
     * in sub-tree of w, is in the middle of u & v
     */
    return subtree[xpar[w][0]] - subtree[w];
}


void e519()
{
    size_t n;
    cin >> n;
    vector<vector<size_t>> adj(n);
    for(size_t i = 0; i + 1 < n; ++i )
    {
        size_t u, v;
        cin >> u >> v;
        --u; --v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    const auto inf = numeric_limits<size_t>::max() >> 3;

    /* distance from root a.k.a depth */
    vector<size_t> dist(n, inf);

    /* zero is its own parent */
    vector<size_t> par(n);

    queue<size_t> q;
    dist[0] = 0;
    q.push(0);

    while(!q.empty())
    {
        const auto u = q.front();
        q.pop();

        for(const auto v: adj[u])
            if(dist[v] == inf)
                dist[v] = dist[u] + 1,
                    par[v] = u,
                    q.push(v);
    }

    /* bottom up order of processing nodes in tree */
    vector<size_t> ord(n);
    iota(begin(ord), end(ord), 0);
    const auto comp = [&dist](const size_t i, const size_t j){
        return dist[j] < dist[i];
    };
    sort(begin(ord), end(ord), comp);

    /* size of subtree of each node */
    vector<size_t> subtree(n, 1);
    for(const auto u: ord)
        for(const auto v: adj[u])
            if(v != par[u])
                subtree[u] += subtree[v];

    /* grand parents with jumps of size 1 << i */
    const auto xpar = lca(dist, par);
    DEBUG(xpar);

    size_t m;
    for(cin >> m; m; --m, cout << '\n')
    {
        size_t u, v;
        cin >> u >> v;
        --u; --v;

        if(u == v)
            cout << n;
        else if((dist[u] ^ dist[v]) & 1)
            cout << 0;
        else if(dist[u] == dist[v])
            cout << xsolve1(u, v, xpar, subtree);
        else
            cout << xsolve2(u, v, dist, xpar, subtree);
    }
}

int main( const int argc, char * argv [])
{
    // NO_IO_TIE;
    e519();

    return EXIT_SUCCESS;
}
