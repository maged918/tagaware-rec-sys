//Language: MS C++


﻿#pragma comment (linker,"/stack:102400000,102400000")
#include <cstdio>
#include <map>
#include <vector>
#include <stack>
#include <queue>
#include <cstring>
#include <algorithm>
#include <string>
#include <cstdlib>
#include <iostream>
#include <cmath>
#include <set>
#include <ctime>

using namespace std;

#define ll long long
#define ull unsigned long long
#define ls (root << 1)
#define rs (root << 1 | 1)
#define lson l, mid, ls
#define rson mid + 1, r, rs
#define MID mid = ((l + r) >> 1)
#define PR pair<int, int>
#define MP make_pair
#define sqr(x) ((x) * (x))

int lowbit(int x) {return (x & -x);}
//int sgn(double x) {return (x > eps) - (x < -eps);}
template <class T_> T_ f_abs(T_ x) {return x < 0 ? -x : x;}
template <class T_> T_ f_max(T_ a, T_ b) {return a > b ? a : b;}
template <class T_> T_ f_min(T_ a, T_ b) {return a < b ? a : b;}
template <class T_> T_ gcd(T_ a, T_ b) {while(T_ t = a % b) a = b, b = t; return b;}
template <class T_> void f_swap(T_ &a, T_ &b) {T_ t = a; a = b; b = t;}

const double eps = 1e-9;
const int dx[] = {-1, 1, 0, 0, -1, -1, 1, 1}, dy[] = {0, 0, -1, 1, -1, 1, -1, 1};//UDLR
const int inf = 0x7fffffff;
const int mod = 1000000007;
const int N = 200003;
struct Point {
	int x, y, id;
	bool operator < (const Point &tt) {
		if(x != tt.x) return x > tt.x;
		return y > tt.y;
	}
}a[N], pt[N];
int n, m, top, stk[N];
bool sel[N];

void Init() {
	m = 0;
	memset(sel, false, sizeof(sel));
}

void GetData() {
	for(int i = 0; i < n; ++i) {
		scanf("%d%d", &a[i].x, &a[i].y);
		a[i].id = i;
	}
}

bool Check(int x1, int y1, int x2, int y2, int x3, int y3) {
	return (ll)(x1 * x2 - x2 * x3) * (y1 * y3 - y2 * y3) - (ll)(x1 * x3 - x2 * x3) * (y1 * y2 - y2 * y3) > 0;
}

void Solve() {
	int i, cur = -1;
	sort(a, a + n);
	for(i = 0; i < n; ++i) {
		if(a[i].y > cur) {
			cur = a[i].y;
			pt[m++] = a[i];
		}
	}
	top = 0;
	for(i = 0; i < m; ++i) {
		for(; top > 1; ) {
			if(Check(pt[stk[top - 2]].x, pt[stk[top - 2]].y, pt[stk[top - 1]].x, pt[stk[top - 1]].y, pt[i].x, pt[i].y)) --top;
			else break;
		}
		stk[top++] = i;
	}
	for(i = 0; i < top; ++i) sel[pt[stk[i]].id] = true;
	for(i = 1; i < n; ++i) {
		if(sel[a[i - 1].id] && a[i].x == a[i - 1].x && a[i].y == a[i - 1].y)
			sel[a[i].id] = true;
	}
	for(i = 0; i < n; ++i)
		if(sel[i]) printf("%d ", i + 1);
}

int main() {
	while(~scanf("%d", &n)) {
		Init();
		GetData();
		Solve();
	}
	return 0;
}