//Language: MS C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include<algorithm>
using namespace std;

int main()
{
	int n,a,b;
	scanf("%d%d%d",&n,&a,&b);
	
	int i,s=1;

	if(n==1&&!a&&!b)
	{
		printf("1\n");
		return 0;
	}

	if(n==a+1&&b==0)
	{
		printf("-1\n");
		return 0;
	}
	if(!b)
	{
		printf("2 ");
		n--;
		for(i=1;i<=a+1;i++)
			printf("%d ",i+1);
		for(i=1;i<n-a;i++)
			printf("%d ",1);

		printf("\n");
	}
	else
	{
		printf("1");
		n--;
		s=2;
		for(i=1;i<=b;i++)
		{
			printf(" %d",s);
			s*=2;
		}
		s/=2;
		for(i=1;i<=a;i++)
		{
			s++;
			printf(" %d",s);
		}
		for(i=1;i<=n-a-b;i++)
			printf(" 1");
		printf("\n");
	}
}