//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
int main(){
  string s;
  cin>>s;
  int i,j,a=0,b=0,st=0;
  int l=s.length();
  for(i=1;i<l;i++){
     if(s[i]=='B' && s[i-1]=='A'){
         a=i;
         st=1;
         break;
     }
  }
  for(i=l-2;i>a;i--){
      if(s[i]=='B' && s[i+1]=='A'){
         b=i;  
         if(st==1)
           st=2; 
        // cout<<s[i]<<"  ";
         break;
      }
  }
  // cout<<s[a]<<" "<<s[b]<<endl;
  if(st!=2){
      st=0;
      for(i=1;i<l;i++){
        if(s[i]=='A' && s[i-1]=='B'){
         a=i;
         st=1; 
         break;
        }
     }
     for(i=l-2;i>a;i--){
        if(s[i]=='A' && s[i+1]=='B'){
         b=i; 
         if(st==1)
           st=2;   
         break;
        }
     }       
  }
  //cout<<l<<endl;
 // cout<<s[a]<<" "<<s[b]<<endl;
  if(st==2)
    cout<<"YES\n";
  else
    cout<<"NO\n";
  return 0;
}   