//Language: GNU C++11


//Author: Václav Volhejn (-Wave-)
#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <string>
#include <set>
#include <map>
using namespace std;
#define rep(i,a,n) for (int i=a;i<n;i++)
#define per(i,a,n) for (int i=n-1;i>=a;i--)
typedef long long ll;

int main() {
#ifdef LOCAL
    freopen("in.txt", "r", stdin);
#endif
    ios_base::sync_with_stdio(false);
    int n;
    cin >> n;
    bool input[n];
    rep(i, 0, n) cin >> input[i];
    if(input[n - 1]) {
        cout << "NO" << endl;
        return 0;
    }
    if(n == 1 && !input[0]) {
        cout << "YES\n0\n";
        return 0;
    }
    if(input[n - 2]) {
        cout << "YES" << endl;
        rep(i, 0, n) cout << (i ? "->" : "") << input[i];
        cout << endl;
        return 0;
    }
    per(i, 0, n - 2) {
        if(!input[i]) {
            cout << "YES" << endl;
            rep(j, 0, n) {
                cout << (j ? "->" : "");
                if(j == i + 1 || j == i) cout << "(";
                cout << input[j];
                if(j == n - 2) cout << "))";
            }
            cout << endl;
            return 0;
        }
    }
    cout << "NO" << endl;
    return 0;
}
