//Language: GNU C++


#include<bits/stdc++.h>

using namespace std;

#define pb push_back

int n,x,y;

double sum;

vector<int> V[100005];


void dfs(int x,int depth,int root){
	sum+=1.0/depth;

	for(int i=0 ; i<V[x].size() ; i++)
		if(V[x][i]!=root)
			dfs(V[x][i],depth+1,x);
}

int main(){

	cin>>n;

	for(int i=1 ; i<n ; i++){
		scanf("%d %d",&x,&y);
		V[x].pb(y);
		V[y].pb(x);
	}

	dfs(1,1,-1);

	printf("%.8lf",sum);
	
	return 0;
}
