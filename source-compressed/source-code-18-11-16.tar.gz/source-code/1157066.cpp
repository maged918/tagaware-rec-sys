//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <cmath>
#include <string>
using namespace std;
int ans, i, j, n, c;
string st;
int main()
{
//  freopen("in","r",stdin);
//  freopen("out","w", stdout);
  getline(cin, st);
  i = 0;
  n = st.length();

  while (i < st.length())
  {
     j = i;
     c = 1;
     while (st[j] == st[j+1] && j < st.length() && c < 5)
     {
        c++;
        j++;
     }
     i = j +1;
     ans++;
  }
  printf("%d", ans);
  return 0;
}
