//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;
const double Eps = 1e-9;
double f[81][81][81];
double ans[85][85];
int a[200], vis[81][81][81];
int i,j,n,m,tot,k1,k2,cnt;
struct arr
{
  int l, r, num;
} A[85], B[85];

void wokao(int t,int x){
  swap(A[x], A[tot]);
  vis[0][0][0] = ++cnt;
  int z = x;
  if (x==tot) z=1;
  for (int j=0;j<z;j++)
    for (int k=0;k+j<z;k++)
      vis[z-1][j][k] = cnt;
  for (int i=z;i<tot;i++){
    int len = (a[A[i].r]-a[A[i].l]);
    for (int j=0;j<i;j++)
      for (int k=0;k+j<i;k++)
      if (vis[i-1][j][k]==cnt && f[i-1][j][k] > Eps){
        if (vis[i][j+1][k]<cnt) f[i][j+1][k]=0, vis[i][j+1][k]=cnt;
        f[i][j+1][k] += f[i-1][j][k]*(a[t]-a[A[i].l])/len;
        if (vis[i][j][k+1]<cnt) f[i][j][k+1]=0, vis[i][j][k+1]=cnt;
        f[i][j][k+1] += f[i-1][j][k]*(a[t+1]-a[t])/len;
        if (vis[i][j][k]<cnt) f[i][j][k]=0, vis[i][j][k]=cnt;
        f[i][j][k] += f[i-1][j][k]*(a[A[i].r]-a[t+1])/len;
      }
  }
  for (int j=0;j<tot;j++)
    for (int k=0;j+k<tot;k++)
    if (vis[tot-1][j][k]==cnt && f[tot-1][j][k]>Eps)
      for (int i=j+1;i<=j+k+1;i++)
        ans[A[tot].num][k1+i] += f[tot-1][j][k]/(k+1)*(a[t+1]-a[t]);
  swap(A[x], A[tot]);
}

void dp(int t){
  tot = 0; k1=k2=0;
  for (int j=1;j<=n;j++)
  {
    if (B[j].r<=t) k1++;
      else if (B[j].l>=t+1) k2++;
        else A[++tot]=B[j];
  }
  f[0][0][0] = 1;
  for (int i=1;i<=tot;i++)
    for (int j=0;j<=i;j++)
      for (int k=0;j+k<=i;k++)
        f[i][j][k] = 0;
  for (int i=tot;i>0;i--)
    wokao(t,i);
}

int main(){
  scanf("%d",&n);
  for (i=1;i<=n;i++){
    scanf("%d%d",&B[i].l,&B[i].r);
    a[i] = B[i].l; a[i+n] = B[i].r;
    B[i].num = i;
  }
  sort(a+1,a+n+n+1);
  m  = unique(a+1,a+n+n+1)-a-1;
  for (i=1;i<=n;i++){
    B[i].l = lower_bound(a+1,a+m+1,B[i].l)-a;
    B[i].r = lower_bound(a+1,a+m+1,B[i].r)-a;
  }
  for (i=1;i<m;i++)
    dp(i);
  for (i=1;i<=n;i++){
    for (j=1;j<n;j++)
      printf("%.7lf ", ans[i][j]/(a[B[i].r]-a[B[i].l]) );
    printf("%.7lf\n", ans[i][n]/(a[B[i].r]-a[B[i].l]) );
  }
  return 0;
}