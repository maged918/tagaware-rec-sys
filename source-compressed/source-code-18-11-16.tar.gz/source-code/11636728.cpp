//Language: GNU C++11


#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <vector>
#include <string>
#include <time.h>
#include <math.h>
#include <queue>
#include <stack>
#include <set>
#include <map>
#define INF 0x3f3f3f3f3f3f3f3f
#define inf 0x3f3f3f3f
#define Zero(x)  memset((x),0, sizeof(x))
#define Neg(x) memset((x), -1, sizeof(x))
#define dg(x) cout << #x << " = " << x << endl
#define pk(x)   push_back(x)
#define pok()   pop_back()
#define eps 1e-8
#define pii pair<int, int>
#define pi acos(-1.0)
using namespace std;
typedef long long ll;
bool debug = true;


int main(){
    //freopen("data.in","r",stdin);
    //freopen("data.out","w",stdout);
    //cin.sync_with_stdio(false);
    int n;
    int x1, y1, x2, y2;
    int ans = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; ++i){
        scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
        ans += (abs(x1 - x2 ) + 1) *(abs(y1 - y2) + 1);
    }
    cout << ans << endl;
    return 0;
}

