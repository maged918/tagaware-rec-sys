//Language: GNU C++


#include <cstdio>
#include <algorithm>
#define FOR(x,y,z) for(int x=y;x<=z;++x)
using namespace std;
int n,b[100005],a[100005],x[100005],y[100005],sx=0,sy=0,M=0;
int abs(int x){
	return x>0?x:-x;
}
bool cmp(int x,int y){
	return b[x-1]<b[y-1];
}
int main(){
	scanf("%d",&n);
	FOR(i,0,n-1) scanf("%d",&b[i]),a[i]=i+1;
	sort(a,a+n,cmp);
	int sum=0,i;
	for(i=n-1;i>=1;i-=2){
		x[++sx]=a[i];
		y[++sy]=a[i-1];
	}
	if (i==0) y[++sy]=a[0];
	printf("%d\n",sx);
	FOR(i,1,sx)
		if (i<sx) printf("%d ",x[i]);
		else printf("%d\n",x[i]);
	printf("%d\n",sy);
	FOR(i,1,sy)
		if (i<sy) printf("%d ",y[i]);
		else printf("%d\n",y[i]);
	return 0;
}
