//Language: GNU C++11


#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef pair<ll,ll> ii;
int n;
ll x,y,den,nom;
int ok(ll a, ll b){
    return (a/x+a/y) >= b;
}

string solve(int a){
    if(a%den ==0 || (a+1)%den == 0){
        return "Both";
    }
    a=a%den;
    //cout<<a<<endl;
    ll st = 0,nd = 1000000000000LL , md;
    while(st < nd){
        md = st + (nd - st) / 2;
        if(ok(md,a)){
            nd = md;
        } else {
            st = md+1;
        }
    }
    //cout<<st<<endl;
    if(st%x ==0 && st%y==0) return "Both";
    return ((st)%x) ? "Vanya" : "Vova";
}
ll gcd(ll a,ll b){return  a ? gcd(b%a,a) : b;}
int main(){
    cin>>n>>x>>y;
    den =x+y;//__gcd(x,y)*(x+y);
    nom = x/(gcd(x,y))*y;
    ll a;
    for(int i = 0; i <n ; i++){
        cin>>a;
        cout<<solve(a)<<"\n";
    }
    return 0;
}
