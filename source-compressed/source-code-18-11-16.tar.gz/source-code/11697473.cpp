//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

#define forall(i,a,b)           for(int i=a;i<b;++i)
#define max(a,b)                ( (a) > (b) ? (a) : (b))
#define abs(x)                  ( (x) > 0 ? (x) : (-x))
#define PI                      3.14159265
#define EPSILON                 0.000000001
#define endl                    "\n"

int main(){
    ios_base::sync_with_stdio(false);cin.tie(0);
    int m; cin >> m;
    int temp,a[100001],min=1000000;
    forall(i,0,m) {
        cin >> temp;
        if(min > temp) min = temp;
    }
    int n,ans=0;cin >> n;
    forall(i,0,n) cin >> a[i];
    sort(a,a+n);
    while(n>=min){
        forall(i,0,min){
            if(n>=1){
                ans+= a[n-1];
                --n;
            }
        }
        n-= 2;
    }
    while(n>0) {
        ans+= a[n-1];
        --n;
    }
    cout << ans << endl;
}