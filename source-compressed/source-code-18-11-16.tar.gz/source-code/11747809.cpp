//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    ll n,i,count=1,top=0,j;
    cin>>n;
    vector <string> v(n);
    for(i=0;i<n;i++)
        cin>>v[i];
    for(i=0;i<n-1;i++)
    {
        for(j=i+1;j<n;j++)
        {
        if(v[i]==v[j])
            count++;
        }
        if(count>top)
            top=count;
        count=1;
    }
                if(count>top)
            top=count;
    cout<<top;
    return 0;
}
