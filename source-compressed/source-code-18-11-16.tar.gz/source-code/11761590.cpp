//Language: GNU C++


#include <cstdio>
#include <cstdlib>
const int ljz = 1000000007;

void MOD(int &x){if (x >= ljz) x -= ljz; if (x < 0) x += ljz;}
int Tm(int a, int b){long long x = a, y = b; return (x * y) % ljz;}
int Tm(int a, int b, int c, int d){return Tm(Tm(a, b), Tm(c, d));}
int ny(int x){int p = 1, s = x; for (int y = ljz - 2; y; y >>= 1){if (y & 1) p = Tm(p, s); s = Tm(s, s);} return p;}
int n, k;
int C[51][51];
int F[51][51][51];

int main(){
  int sl, fl, gl, sr, fr, gr, s, f, g;
  scanf("%d %d", &n, &k);
  for (int i = C[0][0] = 1; i <= n; i++){
    C[i][0] = C[i][i] = 1;
    for (int j = 1; j < i; j++)
      MOD(C[i][j] = C[i - 1][j] + C[i - 1][j - 1]);
  }

  F[0][0][0] = F[1][0][0] = 1;
  for (s = 2; s <= n; s++)
    for (sl = 1; sl < s; sl++){
      sr = s - sl - 1;
      for (gl = 0; gl + gl <= sl; gl++)
	for (fl = gl - 1; fl <= gl; fl++)
	  if (fl >= 0)
	    for (gr = 0; gr + gr <= sr; gr++)
	      for (fr = gr - 1; fr <= gr; fr++)
		if (fr >= 0){
		  f = gl + gr;
		  g = gl + gr;
		  if (sl && fl + gr + 1 >= g) g = fl + gr + 1;
		  if (sr && fr + gl + 1 >= g) g = fr + gl + 1;
		  MOD(F[s][f][g] += Tm(s, C[s - 2][sr], F[sl][fl][gl], F[sr][fr][gr]));
		}
    }
  printf("%d", Tm((F[n][k - 1][k] + F[n][k][k]) % ljz, ny(n)));

  return 0;
}
