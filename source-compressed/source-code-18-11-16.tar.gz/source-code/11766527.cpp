//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;
int main()
{
    int n ;
    long long k ;
    cin >> n >> k ;
    long long fib[n+1] ;
    fib[1] = fib[2] = 1 ;
    for(int i = 3 ;i <= n ; i++){
        fib[i] = (fib[i-1]+fib[i-2]) ;
    }
    int i = 1 ;
    while(i <= n){
        if(int x = fib[n-i+1] < k){
            k -= fib[n-i+1] ;
            cout << i+1 << " " << i << " " ;
            i += 2 ;
        }
        else {
            cout << i << " " ;
            i ++ ;
        }
    }
    return 0;
}
