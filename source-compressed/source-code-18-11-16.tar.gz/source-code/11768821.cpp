//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <ctime>
#include <set>
#include <map>
#define REP(I,A,B) for (int I=A,END=B;I<=END;I++)
#define REPD(I,A,B) for (int I=A,END=B;I>=END;I--)
#define RI(X) scanf("%d",&X)
#define RS(X) scanf("%s",X)
#define RD(X) scanf("%lf",&X)
#define RLL(X) scanf("%I64d",&X)
#define GCH getchar()
#define PCH(X) putchar(X)
#define MS(X,Y) memset(X,Y,sizeof(X))
#define MC(X,Y,var,len) memcpy(X,Y,sizeof(var)*(len))
#define debug(...) fprintf(stderr,__VA_ARGS__)
using namespace std;

const int MAXN =55;

long long sum[MAXN]={0};
int a[MAXN]={0};

int n;
long long k;

void open()
{
    freopen("B.in","r",stdin);
    freopen("B.out","w",stdout);
}
void close()
{
    fclose(stdin);
    fclose(stdout);
}

void init()
{
    cin >> n >> k;
}

void prepare()
{
    sum[0]=1;
    sum[1]=1;
    sum[2]=2;
    REP(i,3,50)
    {
        sum[i]=sum[i-1]+sum[i-2];
    }
}

void work(int now,long long done)
{
    if (now<=n)
    for (int i=now;i<=now+1;i++)
    {
        done+=sum[n-i];
        if (done >=k)
        {
            printf("%d ",i);
            REP(j,now,i-1)
                printf("%d ",j);
            work(i+1,done-sum[n-i]);
            return ;
        }
    }
}

int main()
{
    prepare();
    init();
    work(1,0);
    close();
    return 0;
}