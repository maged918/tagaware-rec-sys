//Language: GNU C++


#include<bits/stdc++.h>
#define rep(i,x,y) for(i=x;i<y;i++)
#define rrep(i,x,y) for(i=x;i>=y;i--)
#define trv(y,x) for(typeof(x.begin())y=x.begin();y!=x.end();y++)
#define trvr(y,x) for(typeof(x.rbegin())y=x.rbegin();y!=x.rend();y++)
#define pb(f) push_back(f)
#define pi(a) printf("%d\n",a)
#define pil(a) printf("%lld\n",a)
#define pi_ printf("\n")
#define pil(a) printf("%lld\n",a)
#define sc(a) scanf("%d",&a)
#define ll long long
#define scl(a) scanf("%lld",&a)
#define scs(a) scanf("%s",a)
#define mp make_pair
#define F first
#define Se second
using namespace std;
#define mod 1000000007
//#include<windows.h>
//FILE *fin = freopen("nice.in","r",stdin);
//FILE *fout = freopen("nice.out","w",stdout);

typedef pair<int,int> pii;
typedef vector<int> vi;
typedef vector< pii > vpii;
struct p
{
    int parent,rank;
}subsets[100005];
struct st
{
    int x,y,c;
}lovers[100005];
int color[100005];
int find(int x)
{
    if(subsets[x].parent!=x)
    subsets[x].parent=find(subsets[x].parent);
    return subsets[x].parent;
}
void Union(int x,int y)
{
    int xset=find(x);
    int yset=find(y);
    if(xset!=yset)
    {
        if(subsets[xset].rank>subsets[yset].rank)
        subsets[yset].parent=xset;
        else if(subsets[xset].rank<subsets[yset].rank)
        subsets[xset].parent=yset;
        else
        {
            subsets[yset].parent=xset;
            subsets[xset].rank++;
        }
    }
}

bool vis[100005];
vector<int> graph[100005];

bool dfs(int i, int colo)
{
    if(!vis[i])
    {
        vis[i]=true;
        color[i]=colo;
    }
    else
    {
        if(color[i]==1-colo)
        return false;
        return true;
    }
    trv(it,graph[i])
    {
        int v=*it;
        if(!dfs(v,1-colo))
        return false;
    }
    return true;
    
}
int main()
{
    //ios_base::sync_with_stdio(false);
    //cin.tie(NULL);
    int n,m,i,j,k;
    sc(n);
    sc(m);
    rep(i,1,m+1)
    {
        int x,y,c;
        sc(x);sc(y);sc(c);
        lovers[i].x=x;lovers[i].y=y;lovers[i].c=c;
    }
    rep(i,1,n+1)
    {
        subsets[i].parent=i;
        subsets[i].rank=0;
    }
    rep(i,1,m+1)
    {
        if(lovers[i].c)
        {
            Union(lovers[i].x,lovers[i].y);
        }
    }
    rep(i,1,m+1)
    {
        if(!lovers[i].c)
        {
            int xset=find(lovers[i].x);
            int yset=find(lovers[i].y);
            if(xset==yset)
            {
                printf("0\n");
                return 0;
            }
            graph[xset].pb(yset);
            graph[yset].pb(xset);
        }
    }
    int count=0;
    rep(i,1,n+1)
    {
        //cout<<find(i)<<endl;
        if(find(i)==i&&vis[i]==false)
        {
            if(!dfs(i,0))
            {
                printf("0\n");
                return 0;
            }
            count++;
        //  cout<<"yolo";
        }
    }
//  cout<<count<<endl;
    ll res=1;
    for(i=1;i<count;i++)
    {
        res*=2LL;
        res%=mod;
    }
    printf("%I64d\n",res);
}
