//Language: GNU C++


////============================================================================
//// Name        : Test.cpp
//// Author      : khaled
//// Version     :
//// Copyright   : Your copyright notice
//// Description : Hello World in C++, Ansi-style
////============================================================================

#include <iostream>
#include <algorithm>
#include <ctype.h>
#include <vector>
#include <fstream>

using namespace std;

int main() {

    int n, k;
    cin >> n >> k;

    int* input = new int[n];
    for (int i = 0; i < n; i++)
        cin >> input[i];

    sort(input, input + n);

    int count = 0;

    for (int i = 0; i <= n - 3; ) {

        int max = *std::max_element(input + i, input + i + 3);
        //  cout << i << " " << i + 3<<endl;

//      for (int j = i; j < i + 3; j++)
//          cout << input[j] << " ";
//      cout << "max "<<max<<endl;

        if (max <= 5 - k) {
            count++;
        }
    //  cout<<"-->"<<i<<endl;
        i += 3;
    }

    cout << count;

    return 0;
}
