//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
typedef pair<LL,LL> PI;
typedef double D;
#define FI first
#define SE second
#define MP make_pair
#define PB push_back
#define R(I,N) for(int I=0;I<N;I++)
#define F(I,A,B) for(int I=A;I<B;I++)
#define FD(I,N) for(int I=N-1;I>=0;I--)
#define make(A) scanf("%lld",&A)
#define make2(A,B) scanf("%lld%lld",&A,&B)
#define ALL(x) (x).begin(), (x).end()
#define SZ(x) ((int)(x).size())
#define db if(1)printf
template<typename C> void MA(C& a,C b){if(a<b)a=b;}
template<typename C> void MI(C& a,C b){if(a>b)a=b;}
#define MAX 200100
LL n,m;
LL wyn[MAX];
pair<PI,LL> t1[MAX];
PI t2[MAX];
void nie(){
  puts("No");
  exit(0);
}
main(){
  make2(n,m);
  LL o1,o2;
  make2(o1,o2);
  R(i,n-1){
    LL a1,a2;
    make2(a1,a2);
    t1[i] = MP(MP(a1-o2,a2-o1),i);
    o1 = a1;
    o2 = a2;
  }
  R(i,m){
    LL pom;make(pom);
    t2[i] = MP(pom,i);
  }
  n--;
  sort(t1,t1+n);
  sort(t2,t2+m);
//   R(i,n){
//     printf("%d %d %d\n",t1[i].FI.FI,t1[i].FI.SE,t1[i].SE);
//   }
  LL i = 0,j= 0;
  set<PI> s;
  while(j < m){
    if(i < n && t1[i].FI.FI <= t2[j].FI){
      s.insert({t1[i].FI.SE,t1[i].SE});
      i++;
    }else{
      if(!s.empty()){
        PI pom = *s.begin();
        s.erase(s.begin());
        if(pom.FI < t2[j].FI)nie();
        //printf("lacz %d %d\n",pom.SE,t2[j].SE);
        wyn[pom.SE] = t2[j].SE+1;
      }
      j++;
    }
  }
  if(!s.empty() || i != n)nie();
  puts("Yes");
  R(i,n)printf("%lld ",wyn[i]);
  puts("");
}
