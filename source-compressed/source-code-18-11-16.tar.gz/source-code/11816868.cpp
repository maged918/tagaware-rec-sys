//Language: GNU C++11


#include <bits/stdc++.h>
#define f first
#define s second
#define mp make_pair
#define pb push_back
#define INF 1000000009
#define MOD 1000000007
#define ll long long

using namespace std;

int n, k, m, c, ans, a[100001];

int main()
{
    cin >> n >> k;
    while(k--) {
        cin >> m;
        for (int i = 1; i <= m; i++)
            cin >> a[i];
        if (a[1] != 1) {
            ans += (m - 1) * 2 + 1;
            continue;
        }
        int p = 1;
        for (int i = 2; i <= m; i++)
            if (a[i] - 1 == a[i - 1]) p++;
            else break;
        ans += (m - p) * 2 + 1;
    }
    ans--;
    cout << ans << endl;

    return 0;
}
