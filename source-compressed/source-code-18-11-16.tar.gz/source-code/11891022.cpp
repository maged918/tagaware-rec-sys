//Language: GNU C++


// TestPrj.cpp : main project file.

//#include "stdafx.h"

/*
ID: Tariqul
PROG: 
LANG: C++
*/

#include <algorithm> 
#include <cctype> 
//#include <cmath> 
#include <cstdio> 
#include <cstdlib> 
#include <cstring> 
#include <deque> 
#include <iostream> 
#include <list> 
#include <map> 
#include <numeric> 
#include <queue> 
#include <set> 
#include <sstream> 
#include <stack> 
#include <string> 
#include <vector>

using namespace std; 

#define fo(i,j,n) for(i=j;i<n;++i)
#define Fo(i,j,n) for(i=n-1;i>=j;--i)
#define foo(i,j,v) fo(i,j,sz(v))
#define Foo(i,j,v) Fo(i,j,sz(v))
#define li(v) v.begin(),v.end()
#define sz(v) ((int)v.size())
#define CLR(a,v) memset((a),(v),sizeof(a))
#define inf 1000000001
typedef long long Long;
//typedef __int64 Long;
#define pi (2*acos(0))
#define eps 1e-9

#define two(X) (1<<(X))
#define twoL(X) (((Long)(1))<<(X))
#define contain(S,X) (((S)&two(X))!=0)
#define containL(S,X) (((S)&twoL(X))!=0)

char BUFFER[100000 + 5];
bool readn(int &n)	{ return scanf("%d",&n) == 1; } 
bool readl(Long &n)	{ return scanf("%I64d",&n) == 1; } 
bool readd(double &n){ return scanf("%lf",&n) == 1; } 
bool reads(string &s){ s = ""; int n = scanf("%s",BUFFER); if(n == 1)s = BUFFER; return n == 1; }
bool readln(string &s){ char *valid = gets(BUFFER); if(valid)s = BUFFER; return ((bool)valid); }

const int maxn = 1e5 + 10;
int sum[maxn];
vector<int> v;
vector<pair<int,int> > ans;

void getv(int i, int j, int &n1, int &n0)
{
	if(i < 0)n1 = sum[j];
	else n1 = sum[j] - sum[i-1];
	n0 = j - i + 1  - n1;
}

int getPos(int from, int target, int &n1, int &n0)
{
	int n = sz(v), to = from - 1;
	n1 = 0, n0 = 0;
	while(1)
	{
		to += (target - max(n1,n0));
		if(to >= n)return -1;
		getv(from,to,n1,n0);
		if(n1 == target)
		{
			if(v[to] == 0)return -1;
			return to;
		}
		if(n0 == target)
		{
			if(v[to] == 1)return -1;
			return to;
		}		
	}

}

bool valid(int t,int &s)
{
	int i = 0,n1,n0,s1 = 0,s0 = 0;	
	foo(i,0,v)
	{
		i = getPos(i, t, n1, n0);
		if( -1 == i)return false;
		if(n1 > n0)s1++;
		else s0++;
	}	
	if(s1 > s0)
	{
		if(v.back() == 0)return false;
		s = s1; return true;
	}
	if(s0 > s1)
	{
		if(v.back() == 1)return false;
		s = s0; return true;
	}
	return false;
}

int main()
{
	#ifdef localhost
	freopen("E://input.txt","r",stdin);
	//freopen("E://output.txt","w",stdout);
	#endif
	CLR(sum,0); ans.clear();
	int i, n, t, s;
	cin >> n; v.resize(n); foo(i,0,v){ cin >> v[i]; v[i] %= 2; }
	sum[0] = v[0]; foo(i,1,v)sum[i] = sum[i-1] + v[i];
	fo(t,1,n+1)
	{
		if(valid(t,s))ans.push_back(make_pair(s,t));
	}
	sort(li(ans));
	cout << sz(ans) << endl;
	foo(i,0,ans)cout << ans[i].first << " " << ans[i].second << endl;

	return 0;
} 