//Language: GNU C++11


#include <bits/stdc++.h>
#include <ext/algorithm>
#include <ext/numeric>

using namespace std;
using namespace __gnu_cxx;

#define endl '\n'

typedef long long i64;

const i64 oo = 0x3f3f3f3f3f3f3f3f;
const int N = 100000 + 100;

int n, m, k, p;
i64 h[N], a[N];

bool check(i64 H)
{
	multiset<int> ms;
	for (int i = 0; i < m; ++i)
		for (int j = 0; j < k; ++j)
			ms.insert(i);

	for (int i = 0; i < n; ++i)
	{
		i64 fh = H;

		while (fh - a[i] * m < h[i])
		{
			i64 d = fh / a[i];
			auto it = ms.lower_bound(d);

			if (it == ms.begin())
				return false;

			ms.erase(--it);
			fh += p;
		}
	}

	return true;
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);

	cin >> n >> m >> k >> p;

	for (int i = 0; i < n; ++i)
		cin >> h[i] >> a[i];

	i64 lo = 0, hi = oo;

	while (lo < hi)
	{
		i64 mid = (lo + hi) / 2;

		if (check(mid)) hi = mid;
		else lo = mid + 1;
	}

	cout << lo << endl;
	
	return 0;
}
