//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<map>
#include<set>
#include<queue>
#include<list>
#include<deque>
#include<stack>
#include<bitset>
#include<vector>
#include<utility>
#include<sstream>
#include<iterator>
#include<functional>
#include<numeric>
#include<iomanip>
#include<ctime>
#include<climits>
#include<cctype>
#include<cassert>
#include<complex>
#include<stdlib.h>
using namespace std;
#define FASTER ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL)
#define pb push_back
#define mp make_pair
#define pd(x) printf("%d", x)
#define pdn(x) printf("%d\n", x)
#define plld(x) printf("%I64d", x)
#define plldn(x) printf("%I64d\n", x)
#define sd(x) scanf("%d",&x)
#define sd2(x,y) scanf("%d%d",&x,&y);
#define sd3(x,y,z) scanf("%d%d%d",&x,&y,&z); //spaces should not be there to avoid tle
#define slld(x) scanf("%I64d",&x)
/*
ifstream fin("input.txt");
ofstream fout("output.txt");
freopen("input.txt", "r", stdin);
freopen("output.txt", "w", stdout);
*/

int main()
{
    FASTER;
    string str;
    int n, i;
    stack<char> s;
    cin>>str;
    n = str.length();
    for(i = 0; i < n; i++)
    if(!s.empty() and s.top() == str[i]) //LIFO, s.top() == str[i] means it can be untangled by just lifting that segment of wire
        s.pop();
    else 
        s.push(str[i]);
    if(s.empty())
        puts("Yes");
    else 
        puts("No");
    return 0;
}