//Language: GNU C++


#include <stdio.h>
#include <string.h>

int c[151];
int dp[151][151][151];
int ddp[151];
char str[160];

int calc(int x,int y,int z){
    if(dp[x][y][z]!=-1) return dp[x][y][z];
    int d,i;
    dp[x][y][z]=-500000000;
    if(z<0) return dp[x][y][z];
    if(x==y+1 && z==0){
        dp[x][y][z]=0;
        return dp[x][y][z];
    }
    if(x==y && z==1){
        dp[x][y][z]=0;
        return dp[x][y][z];
    }
    if(z>y-x+1){
        dp[x][y][z]=-500000000;
        return dp[x][y][z];
    }
    if(z==0){
        dp[x][y][z]=-500000000;
        for(i=1;i<=y-x+1;i++){
            if(c[i]!=-1){
                d=calc(x,y,i)+c[i];
                if(d>dp[x][y][z]) dp[x][y][z]=d;
            }
        }
    }else{
        if(str[x]==str[y]){
            dp[x][y][z]=calc(x+1,y-1,z-2);
        }
        for(i=x;i<y;i++){
            d=calc(x,i,0)+calc(i+1,y,z);
            if(d>dp[x][y][z]) dp[x][y][z]=d;
            d=calc(x,i,z)+calc(i+1,y,0);
            if(d>dp[x][y][z]) dp[x][y][z]=d;
        }
    }
    return dp[x][y][z];
}

int main(){
    int n,i,j,md,d;
    memset(dp,-1,sizeof(dp));
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%d",&c[i]);
    }
    scanf("%s",str+1);
    ddp[0]=0;
    for(i=1;i<=n;i++){
        ddp[i]=ddp[i-1];
        for(j=1;j<=i;j++){
            d=calc(j,i,0)+ddp[j-1];
            //printf("%d %d %d\n",j,i,d);
            if(d>ddp[i]) ddp[i]=d;
        }
    }
    printf("%d\n",ddp[n]);
    return 0;
}

