//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <algorithm>
#include <string>
#include <set>
#include <map>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
using namespace std;

typedef pair<int,int> pii;
#define ll long long
#define dou double
#define mp make_pair
#define mpii make_pair<int,int>
#define st first
#define nd second
#define For(_i,a,b) for (int _i=(a),_n=(b); _i<=_n; _i++)
#define Rof(_i,a,b) for (int _i=(a),_n=(b); _i>=_n; _i--)
#define Mem(a,b) memset(a,b,sizeof(a))
#define Cpy(a,b) memcpy(a,b,sizeof(b))

long long N,K;
int L,modd;

void mul(int A[2],int B[2][2])
{
    static int C[2];
    Mem(C,0);
    for (int i=0; i<2; i++)
        for (int j=0; j<2; j++)
            C[j]=((ll)C[j]+(ll)A[i]*(ll)B[i][j] %modd) %modd;
    Cpy(A,C);
}

void mul(int A[2][2],int B[2][2])
{
    static int C[2][2];
    Mem(C,0);
    for (int i=0; i<2; i++)
        for (int j=0; j<2; j++)
            for (int k=0; k<2; k++)
                C[i][k]=((ll)C[i][k]+(ll)A[i][j]*(ll)B[j][k] %modd) %modd;
    Cpy(A,C);
}

int calcpower(int a,ll x)
{
    long long s=a,ret=1;
    for (; x;x>>=1)
    {
        if (x&1) ret=ret*s %modd;
        s=s*s %modd;
    }
    return (int)ret;
}
void work()
{
    static int A[2],B[2][2];
    if (L<63 && (1LL<<L)<=K || (L==0 && K!=0)) { printf("0\n"); return ; }
    A[0]=1,A[1]=1;
    B[0][0]=1,B[0][1]=1,B[1][0]=1,B[1][1]=0;
    for (ll x=N; x; x>>=1)
    {
        if (x&1) mul(A,B);
        mul(B,B);
    }
    long long ans0=A[0],ans1=(calcpower(2,N)-A[0]+modd) %modd;
//cout<<ans0<<' '<<ans1<<endl;
    long long Ans=1,x=1;
    for (int i=0; i<L; i++)
    {
        if (x&K) Ans=Ans*ans1 %modd;
         else Ans=Ans*ans0 %modd;
        x<<=1;
    }
    printf("%d\n",(int)Ans %modd);
}

int main()
{
    
    while(cin>>N>>K>>L>>modd) work();
    
    return 0;
}
