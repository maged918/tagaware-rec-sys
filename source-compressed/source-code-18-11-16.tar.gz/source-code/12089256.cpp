//Language: MS C++



#include <stdio.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <math.h>
#include <queue>
#include <bitset>
#include <string.h>

using namespace std;
//typedef long long ll;

int main()
{
	int n;
	scanf("%d\n", &n);

	map<string, int> Count;

	for (int i = 0; i < n; i++)
	{
		char line[120];
		gets(line);
		string s = line;
		if (Count.find(s) != Count.end())
		{
			Count[s] += 1;
		}
		else
		{
			Count[s] = 1;
		}
	}

	int Maximo = 1;

	for (map<string, int>::iterator i = Count.begin();i!=Count.end(); i++)
	{
		if (i->second > Maximo)
			Maximo = i->second;
	}

	printf("%d", Maximo);
	return 0;
}