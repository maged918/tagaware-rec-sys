//Language: GNU C++


/*
*Author : Flint_x 
*Created Time : 2015-07-19 15:13:49 
*File name : 2015_summer_warmupC.cpp 
*/

#include<iostream>
#include<sstream>
#include<fstream>
#include<vector>
#include<list>
#include<deque>
#include<queue>
#include<stack>
#include<map>
#include<set>
#include<bitset>
#include<algorithm>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<cmath>
#include<ctime>
#include<iomanip>
using namespace std;
const double eps(1e-8);
typedef long long lint;

#define cls(a) memset(a,0,sizeof(a))
#define rise(i,a,b) for(lint i = a ; i <= b ; i++)
#define fall(i,a,b) for(lint i = a ; i >= b ; i--)

lint f(lint x) {return x*x;}

int main(){
//    freopen("input.txt","r",stdin);
//  freopen("output.txt","w",stdout);
	lint a,b;
	while(cin >> a >> b){
		if(a == 0){
			cout << - f(b) << endl;
			rise(i,1,b) putchar('x');
		}
		else if(b <= 1){
			cout << f(a) - f(b) << endl;
			rise(i,1,a) putchar('o');
			rise(i,1,b) putchar('x');
		}
		else{
			lint ans = -f(a+b);
			lint res_w,res_l;
			rise(i,1,min(a,b)){
				rise(j,i-1,i+1)
					if(j >= 1 && j <= b){
						lint pos = f(a - (i-1)) + (i-1);
						lint neg = (b % j) * f(b / j + 1) + (j - b%j) * f(b / j);
						lint value = pos - neg;
						if(ans < value){
							ans = value;
							res_w = i;res_l = j;
						}
					}
			}
//			cout << res_w  << endl;
//			cout << res_l  << endl;
			cout << ans << endl;
			if(res_w >= res_l) {
				rise(i,0,res_w-1){
					lint wlen = (i > 0) ? 1 : a - (res_w-1);
					rise(j,0,wlen-1) putchar('x');
					lint llen = (i < b % res_l) ? (b / res_l + 1) : (b / res_l);
					if(i < res_l) rise(j,0,llen-1) putchar('o');
				}
			}	
			else {
				rise(i,0,res_l-1) {
					lint llen = (i < b % res_l) ? (b / res_l + 1) : (b / res_l);
					if(i < res_l) rise(j,0,llen-1) putchar('x');
					lint wlen = (i > 0) ? 1 : a - (res_w-1);
					if(i < res_w) rise(j,0,wlen-1) putchar('o');
				}
			}
			cout<< endl;
		}
	}
	return 0;
}
        


				 	  		 	 				       	 			