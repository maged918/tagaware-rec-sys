//Language: GNU C++11


/*
    Author: Maksym Strelbitskyi
    Vinnytsia - 2015
*/

#define _CRT_DISABLE_PERFCRIT_LOCKS
#define _CRT_SECURE_NO_WARNINGS
#pragma comment (linker, "/STACK:64000000")

#include <climits>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <algorithm>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <vector>

using namespace std;

#define forn(m,n) for (int i=m; i<n; i++)
#define form(k,m) for (int j=k; j<m; j++)
#define uint unsigned int
#define int64 long long int
#define uint64 unsigned long long int
#define vi vector<int>
#define vi64 vector<long long int>
#define si set<int>
#define pi pair<int,int>
#define mp make_pair

template <class T> T gcd(T a, T b) {
    while (b) { a %= b; swap(a, b); } return a;
}

void solve() {
    // solution
    int n, k;
    cin >> n;
    vi a(n);
    forn(0, n) cin >> a[i];
    k = (n - a[0]) % n;
    forn(0, n) {
        if (i % 2) a[i] = (a[i] - k + n) % n;
        else a[i] = (a[i] + k) % n;
    }
    forn(0, n) 
    if (a[i] != i)
    {
        cout << "No";
        return;
    }
    cout << "Yes";
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
#ifdef MYDEBUG
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
    unsigned int start = clock(), fin;
#endif
    solve();
#ifdef MYDEBUG
    fin = clock();
    cout << "\n\nTime: " << fin - start << " ms.";
#endif
    return 0;
}