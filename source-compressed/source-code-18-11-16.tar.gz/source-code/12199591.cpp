//Language: GNU C++11


#include<iostream>
#include<cstdio>
#include<vector>
#include<queue>

#include<map>
#include<set>
#include<string>
#include<algorithm>
#include<functional>
using namespace std;
#define FOR(i,a,b) for (int i=(a);i<(b);i++)
#define RFOR(i,a,b) for (int i=(b)-1;i>=(a);i--)
#define REP(i,n) for (int i=0;i<(n);i++)
#define RREP(i,n) for (int i=(n)-1;i>=0;i--)
#define INF 1<<30
#define MP make_pair
#define mp make_pair
#define pb push_back
#define PB push_back
#define DEBUG(x) cout<<#x<<": "<<x<<endl
#define ll long long
#define ull unsigned long long

int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);
	int n,k,p,x,y;cin>>n>>k>>p>>x>>y;
	vector<int> tes;
	vector<int> mem;
	REP(i,k){ int tmp;cin>>tmp;tes.pb(tmp);}
	int sum=0;REP(i,k)sum+=tes[i];
	if(sum+n-k > x) {cout<<-1<<endl;return 0;}
	FOR(i,k,n){
		if(sum+n-i-1 + y <= x){ sum+=y;tes.pb(y); mem.pb(y);}
		else {sum+=1;tes.pb(1);mem.pb(1);}
	}
	sort(tes.begin(),tes.end());
	if(tes[tes.size()/2]>=y) {
		REP(i,mem.size()) {cout<<mem[i]<<" ";}
		cout<<endl;
	}else{cout<<-1<<endl;return 0;}


}
