//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
#include <ctype.h>
#include <vector>
#include <algorithm>
#include <set>
#include <utility>
#include <stack>
#include <queue>
#include <sstream>
#include <cmath>
#include <time.h>
#include <bitset>
#include <map>

using namespace std;
#define rep(i,n) for(int i=0; i<n; i++)
#define repe(i,n) for(int i=1; i<=n; i++)
#define mst(A,k) memset(A,k,sizeof(A))
#define lo o<<1
#define ro (o<<1)|1
typedef long long ll;
const double eps = 1e-9;
const ll INF = 1e15;
const ll MOD = 1e9+7;
const int N = 1000005;
const int M = 600000;

struct Point{
    int x,v;
    Point(){}
    Point(int x,int v):x(x),v(v){}
    bool operator<(const Point& a)const
    {
        return v > a.v;
    }
    void read(int o)
    {
        x = o;
        scanf("%d",&v);
    }
}p[200005];
int n,A[200005];
int Mx[600000],L[200005],R[200005];
int ans[200005];

void Add(int l,int r,int o,int L,int R,int v)
{
    if(L <= l && r <= R)
    {
        Mx[o] = max(Mx[o],v);
        return;
    }
    int mid = (l + r) >> 1;
    if(L <= mid) Add(l,mid,lo,L,R,v);
    if(mid < R) Add(mid+1,r,ro,L,R,v);
}
void Final(int l,int r,int o)
{
    if(l == r)
    {
        ans[l] = Mx[o];
        return;
    }
    int mid = (l + r) >> 1;
    if(Mx[o])
    {
        Mx[lo] = max(Mx[o],Mx[lo]);
        Mx[ro] = max(Mx[o],Mx[ro]);
    }
    Final(l,mid,lo);
    Final(mid+1,r,ro);
}
int main()
{
    scanf("%d",&n);
    for(int i=0; i<n; i++) p[i].read(i),A[i] = p[i].v;
    sort(p,p+n);
    mst(L,-1);mst(R,-1);
    mst(Mx,0);
    for(int i=0; i<n; i++)
    {
        int l = p[i].x,r = p[i].x;
        if(p[i].x && L[p[i].x-1] != -1)
        {
            l = L[p[i].x-1];
        }
        if(p[i].x < n - 1 && R[p[i].x+1] != -1)
        {
            r = R[p[i].x+1];
        }
        Add(0,n-1,1,0,r-l,p[i].v);
        R[l] = r;L[r] = l;
    }
    Final(0,n-1,1);
    for(int i=0; i<n; i++)
    {
        if(i) printf(" ");
        printf("%d",ans[i]);
    }printf("\n");
    return 0;
}