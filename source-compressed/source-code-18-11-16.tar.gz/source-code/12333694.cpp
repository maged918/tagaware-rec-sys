//Language: GNU C++11


#include<stdio.h>
#include<string.h>
#include <algorithm>
#include <bits/stdc++.h>
using namespace std;

int main()
{
    int a1,a2,a3,a4,a5,a6;
    int i;
    int sum=0;
    scanf("%d%d%d%d%d%d",&a1,&a2,&a3,&a4,&a5,&a6);
    sum+= (a2+a1)*(a6+a1)*2-a1*a1-a4*a4;
    printf("%d\n",sum);
    return 0;
}
