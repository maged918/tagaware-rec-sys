//Language: GNU C++


#include<cstdio>
#include<algorithm>

using namespace std;

int n,m;
double f[1010][1010];
bool flag[1010][1010];

inline double DP(int n,int m)
{
    if(flag[n][m])return f[n][m];

    flag[n][m]=true;

    if(!n||!m)return f[n][m]=1.0/(m+1);

    double a1=1;
    double a2=1-DP(m,n-1);
    double b1=(double)m/(m+1)*(1-DP(m-1,n));
    double b2=1-(double)m/(m+1)*DP(m-1,n);
    double p=(a1-b1)/(a1+b2-a2-b1);

    return f[n][m]=max(1.0/(m+1),1-p*DP(m,n-1));
}

int main()
{
    scanf("%d%d",&n,&m);

    printf("%.10lf %.10lf\n",DP(n,m),1-DP(n,m));

    return 0;
}
