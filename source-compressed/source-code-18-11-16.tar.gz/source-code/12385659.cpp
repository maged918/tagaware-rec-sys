//Language: GNU C++11


#include <iostream>
#include <algorithm>
#include <memory>

int n, k, a;

int f(int d, int a) {
	int c = d / (a + 1);
	d -= c * (a + 1);
	if (d >= a) c += 1;
	return c;
}

struct node {
	std::shared_ptr<node> left;
	std::shared_ptr<node> right;

	int from;
	int to;
	int order;

	node(int pfrom, int pto)
		: from(pfrom)
		, to(pto)
		, left(nullptr)
		, right(nullptr)
		, order(f(to - from + 1, a))
	{}

	bool leaf() const {
		return left == nullptr
			&& right == nullptr;
	}

	void split(int x) {
		if (leaf()) {
			if (x == from) {
				from++;
				order = f(to - from + 1, a);
			} else if (x == to) {
				to--;
				order = f(to - from + 1, a);
			} else {
				left  = std::make_shared<node>(from, x - 1);
				right = std::make_shared<node>(x + 1, to);
				order = left->order + right->order;
			}
		} else {
			if (left->from <= x && x <= left->to)
				left->split(x);
			else if (right->from <= x && x <= right->to)
				right->split(x);
			order = left->order + right->order;
		}
	}
};

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	std::cin >> n >> k >> a;

	node tree(1, n);
	int ans = -1;
	
	int m; std::cin >> m;
	for (int i = 0; i < m; ++i) {
		int x; std::cin >> x;
		if (ans != (-1)) continue;
		tree.split(x);
		if (tree.order < k)
			ans = (i+1);
	}

	std::cout << ans << '\n';
	return 0;
}