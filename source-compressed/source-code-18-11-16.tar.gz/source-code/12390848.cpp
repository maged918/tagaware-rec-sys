//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

int n, k, a;

int pos [200100];

int howmany (int len) {
	if (len >= 1)
		return (len + 1) / (a + 1);
	else	
		return 0;
}

int solve (int x) {
	vector <int> q;
	for (int i = 0; i < x; i++)
		q.push_back (pos[i]);
	sort (q.begin(), q.end());
	int ans = 0;
	for (int i = 0; i < q.size(); i++)
		if (i == 0) {
			ans += howmany (q[i] - 1);
		} else
			ans += howmany (q[i] - q[i - 1] - 1);
	ans += howmany (n - q[q.size() - 1]);
	return ans;
}

int main () {
	cin >> n >> k >> a;
	int m;
	cin >> m;
	int l = 1; 
	int r = m;
	for (int i = 0; i < m; i++) {
		scanf ("%d", &pos[i]);
//		cout << solve (i + 1) << endl;
	}
	while (r - l > 1) {
		int mid = (r + l) / 2;
		if (solve (mid) >= k)
			l = mid;
		else
			r = mid;
	}
	if (solve (m) >= k) {
		cout << "-1";
		return 0;
	}
	if (solve (l) >= k)
		cout << r;
	else
		cout << l;
}

