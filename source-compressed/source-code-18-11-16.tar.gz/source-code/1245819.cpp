//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
const double pi = 3.14159265358979323846364338321;
int n, a[1000], ans, k;
int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    sort(a + 1, a + n + 1);
    k = 1;
    for (int i = n; i; i--)
    {
        ans += a[i] * a[i] * k;
        k = -k;
    }
    printf("%lf", pi * ans);
    return 0;
}
