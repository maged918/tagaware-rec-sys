//Language: GNU C++11


#include <iostream>
#include <map>
#include <vector>
#include <cmath>
#include <algorithm>
#include <set>

using namespace std;

int main() {
    int t, s, q;
    cin >> t >> s >> q;
    int n = 0;
    while (s < t) {
        s *= q;
        ++n;
    }
    cout << n << endl;

    return 0;
}
