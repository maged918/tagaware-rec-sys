//Language: GNU C++


#include <stdio.h>
#include <cstring>
#include <cstdlib>

char s[2005],u[2005];


int main()
{
    scanf("%s",&s);
    scanf("%s",&u);
    int l1=strlen(s),l2=strlen(u);
    int ans=l2;
    for(int i=-l2+1;i<l1;i++)
    {
      int cnt=0;      
      for(int j=0;j-i<l2&&j+i<l1;j++)
      {
         if(i<0&&s[j]==u[j-i]) cnt++;
         else if(i>=0&&s[j+i]==u[j]) cnt++;
      }
      if(l2-cnt<ans) ans=l2-cnt;
    }
    printf("%d\n",ans);
  // system("PAUSE");
}
