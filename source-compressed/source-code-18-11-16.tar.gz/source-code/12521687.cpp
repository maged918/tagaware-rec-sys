//Language: GNU C++


#include<iostream>
using namespace std;

int main()
{
	int n,m,i,j,max,t,a1[20000]={0};
	long a;
	cin>>n>>m;
	for(i=1;i<=m;i++)
	{
		max=-1,t=0;
		for(j=1;j<=n;j++)
		{
			cin>>a;
			if(max<a) { max=a; t=j; }
		}
		a1[t]++;
	}
	max=0;
	for(i=1;i<=n;i++)
		if(max<a1[i]) { max=a1[i]; t=i;}
	cout<<t;
	return 0;
}
			
			
	
