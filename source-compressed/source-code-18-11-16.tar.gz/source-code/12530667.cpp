//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
using namespace std;

#define MP make_pair
#define PB push_back
typedef pair<int, int> pii;

inline int read()
{
    int x = 0, f = 1, t = getchar();
    while(t < '0' || t > '9') {
        if(t == '-') f = -1;
        t = getchar();
    }
    while(t >= '0' && t <= '9') {
        x = (x << 1) + (x << 3) + t - '0';
        t = getchar();
    }
    return x * f;
}

const int maxn = 500005;

int n, m, q, dfs_clock;
char c[maxn];
int head[maxn], fa[maxn];
int u[maxn], v[maxn], next[maxn];
int in[maxn], out[maxn];
vector<pii> h[maxn];

inline void addedge(int a, int b)
{
    u[m] = a; v[m] = b; next[m] = head[a]; head[a] = m++;
}
void dfs(int x, int d)
{
    in[x] = ++dfs_clock;
    h[d].PB(MP(in[x], h[d].back().second ^ (1 << c[x] - 'a')));
    for(int i = head[x], k; ~i; i = next[i])
        if((k = v[i]) != fa[x])
            dfs(v[i], d + 1);
    out[x] = ++dfs_clock;
}
int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    
    n = read(); q = read();
    memset(head, -1, sizeof(head));
    for(int i = 1; i <= n; ++i) h[i].resize(1);
    for(int i = 2; i <= n; ++i)
        addedge(fa[i] = read(), i);
    scanf("%s", c + 1);
    
    dfs(1, 1);
    
    while(q--) {
        int x = read();
        int d = read();
        int l = lower_bound(h[d].begin(), h[d].end(), MP(in[x], -1)) - h[d].begin() - 1;
        int r = lower_bound(h[d].begin(), h[d].end(), MP(out[x], -1)) - h[d].begin() - 1;
        int t = h[d][l].second ^ h[d][r].second;
        int ok = t == (t & -t);
        puts(ok ? "Yes" : "No");
    }
    
    
#ifndef ONLINE_JUDGE
    fclose(stdin), fclose(stdout);
#endif
    return 0;
}
