//Language: GNU C++11


//#define PC

/*	IN THE NAME OF GOD	*/
	
#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
#include <map>
#include <sstream>
#include <set>
#include <iomanip>
#include <list>
#include <stack>
#include <queue>
#include <bitset>
#include <functional>

#include <cstdio>
#include <cmath>
#include <climits>
#include <cstring>
#include <cctype>
#include <cstdlib>

using namespace std;
#define FI              freopen("in.txt", "r", stdin);
#define FO              freopen("out.txt", "w", stdout);

bool istrue(vector <int> b){
    for(int i = 0; i < b.size(); i++){
        if(b[i] != i)
            return false;
    }
    return true;
}

int main(){ 
    #ifdef PC
    	FI FO
    #endif
    ios::sync_with_stdio(false);
    cin.tie(0);
    int n;
    cin >> n;
    vector <int> a(n);

    for(int i = 0; i < n; i++){
        cin >> a[i];
    }

    for(int i = 0; i < n; i++){
        for(int j = 0; j < n; j++){
            if(j&1){
                a[j]--;
                if(a[j] < 0){
                    a[j] += n;
                }
            }
            else a[j]++;
            a[j] %= n;
        }


        if(istrue(a)){
            cout << "Yes" << endl;
            return 0;
        }
    }
    cout << "No" << endl;
    return 0;
}