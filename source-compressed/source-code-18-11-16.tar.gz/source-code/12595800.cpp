//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <ctime>
#include <iostream>
#include <algorithm>
#include <queue>
#include <map>
#include <set>
#include <vector>
#include <stack>
#include <string>

using namespace std;

#define PI acos(-1.0)
#define INF 0x3f3f3f3f
#define inf 0x3f
#define rst(a, b) memset(a, b, sizeof(a))
#define mp(a, b) make_pair(a, b)
#define pb(a) push_back(a)
#define MOD 1000000007
#define EPS 1e-6
#define ok puts("ok");

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> pii;

const int maxn = 1005;
const int maxm = 1000005;

struct Point {
    int x, y;
    int r;
}arr[maxn];

int dis(Point a, pii b) {
    return (a.x-b.first)*(a.x-b.first) + (a.y-b.second)*(a.y-b.second);
}

void solve() {
    int r1, r2, c1, c2, d1, d2;
    scanf("%d %d %d %d %d %d", &r1, &r2, &c1, &c2, &d1, &d2);
    int a, b, c, d;
    for(a = 1; a <= 9; a++) {
        for(b = 1; b <= 9; b++) {
            if(a == b) continue;
            for(c = 1; c <= 9; c++) {
                if(a == c || b == c) continue;
                for(d = 1; d <= 9; d++) {
                    if(a == d || b == d || c == d) continue;
                    if(a + b == r1 && c + d == r2 &&
                       a + c == c1 && b + d == c2 &&
                       a + d == d1 && b + c == d2) {
                        printf("%d %d\n%d %d\n", a, b, c, d);
                        return;
                       }
                }
            }
        }
    }
    puts("-1");
}

int main() {
    solve();
    return 0;
}

			   	  	   			   			 	 		   	