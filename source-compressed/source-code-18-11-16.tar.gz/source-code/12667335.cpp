//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

const int maxn=1e6;

long long n,k,a[maxn],j,i,b[maxn],f[5007][5007],maxt,t;
long long res;

long long dp(int i, int t, int k)
{
    if (k==0 && i>0) return 1000000000000;
    if (t>0 && i<=0) return 1000000000000;
    if (i==0) return 0;
    if (f[k][t]==-1)
    {
        if (i-maxt+1>0)
        f[k][t]=dp(i-maxt,t,k-1)+abs(a[i]-a[i-maxt+1]);
        else f[k][t]=10000000000000;
        if (t>0 && i-maxt+2>0) f[k][t]=min(f[k][t],dp(i-maxt+1,t-1,k-1)+abs(a[i]-a[i-maxt+2]));
    }
    return f[k][t];
}
int main()
{
    cin >> n >> k;
    for (int i=1; i<=n; ++i)
    {
        scanf("%I64d",&a[i]);
    }
    sort(a+1,a+n+1);
    maxt=(n-1)/k;
    for (int i=1; i<=k; ++i)
        if ((n-i)/k!=maxt) t++;
    maxt++;
    for (int i=0; i<=k; i++)
        for (int j=0; j<=k; ++j) f[i][j]=-1;
    res=dp(n,t,k);
    cout << res;
}
