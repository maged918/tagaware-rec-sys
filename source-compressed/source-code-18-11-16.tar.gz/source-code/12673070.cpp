//Language: MS C++


#include <cstdio>
#include <iostream>
#include <fstream>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>
#define rep(i,n) for(int i=0;i<n;i++)

using namespace std;

int n, k;
vector<long long> arr;

//map< pair<int, int>, long long> dp;
long long dp[5001][5001];
int Lle, Sle;

long long solve(int L, int S) {
    //if (dp.count(make_pair(L,S))>0) return dp[make_pair(L,S)];
    if (dp[L][S]!=-1) return dp[L][S];
    if (L==0 && S==0) return 0;
    if (L==1 && S==0) {
        long long ret = 0;
        //for(int i=1;i<Lle;++i) ret += arr[i] - arr[i-1];
        ret += arr[Lle-1] - arr[0];
        //return dp[make_pair(L,S)] = ret;
        return dp[L][S] = ret;
    }
    if (L==0 && S==1) {
        long long ret = 0;
        //for(int i=1;i<Sle;++i) ret += arr[i] - arr[i-1];
        ret += arr[Sle-1] - arr[0];
        //return dp[make_pair(L,S)] = ret;
        return dp[L][S] = ret;
    }
    long long ret1 = 0, ret2 = 0;
    if (L>0) {
        //for(int i=Lle*(L-1) + Sle*S + 1;i<Lle*L+Sle*S;++i)
        //  ret1 += arr[i] - arr[i-1];
        ret1 += arr[Lle*L+Sle*S-1] - arr[Lle*(L-1) + Sle*S];
        ret1 += solve(L-1,S);
    }
    if (S>0) {
        //for(int i=Lle*L + Sle*(S-1) + 1;i<Lle*L+Sle*S;++i)
        //  ret2 += arr[i] - arr[i-1];
        ret2 += arr[Lle*L+Sle*S-1] - arr[Lle*L + Sle*(S-1)];
        ret2 += solve(L,S-1);
    }
    if (L==0) ret1 = ret2;
    else if (S==0) ret2 = ret1;
    //return dp[make_pair(L,S)] = min(ret1, ret2);
    return dp[L][S] = min(ret1, ret2);
}

int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);
#endif

    cin >> n >> k;
    arr.resize(n);
    rep(i,n) cin >> arr[i];
    sort(arr.begin(), arr.end());

    //dp.clear();
    rep(i,5001)
        rep(j,5001)
            dp[i][j] = -1;
    Lle = n/k + 1;
    Sle = n/k;

    long long ret = solve(n%k, k - (n%k));

    /*vector<int> sizes(0);
    rep(i,k)
        if ((n%k)>i) sizes.push_back(n/k + 1);
        else sizes.push_back(n/k);

    long long ret = 0;
    vector<int> flags(n, 0);
    rep(i,k) {
        int cin = -1;
        long long cadd = 0;
        rep(j,n)
            if (flags[j]==0) {
                long long tsz = 1, tadd = 0;
                int ti = j + 1, tprev = j;
                while (ti<n && tsz<sizes[i]) {
                    while (ti<n && flags[ti]) ti++;
                    if (ti>=n) break;
                    tadd += abs(arr[ti] - arr[tprev]);
                    tprev = ti;
                    tsz++;
                }
                if (tsz==sizes[i] && (cin==-1 || tadd<cadd)) {
                    cin = j;
                    cadd = tadd;
                }
            }

        ret += cadd;
        flags[cin] = 1;
        int ti = cin + 1, tsz = 1;
        while (ti<n && tsz<sizes[i]) {
            while (ti<n && flags[ti]) ti++;
            if (ti>=n) break;
            flags[ti] = 1;
            tsz++;
        }
    }*/
    
    cout << ret << "\n";
    
#ifndef ONLINE_JUDGE
    cout << "running time=" << clock()/(double)CLOCKS_PER_SEC << " s\n";
#endif
    return 0;
}
