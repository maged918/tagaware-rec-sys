//Language: GNU C++



#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <queue>
#include <vector>
#include <stack>
#include <map>
#include <set>
#include <string>
#include <cstring>
using namespace std;

#define N (1<<19)
#define M (5007)
#define INF (1<<30)

const long long INFL = 1152921504606846976ll; //2^60

int a[N];
long long dp[M][M];

int n,k;

int main()
{
	scanf("%d%d",&n,&k);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	sort(a,a+n);
	
	for(int i=0;i<=k;i++)
	{
		for(int j=0;j<=k;j++)
		{
			dp[i][j]=INFL;
		}
	}
	dp[0][0]=0ll;
	
	for(int i=1;i<=k;i++)
	{
		for(int j=0;j<=k;j++)
		{
			dp[i][j]=dp[i-1][j]+abs(a[(n/k)*i+j-1]-a[(n/k)*(i-1)+j]);
			if(j>0)
			{
				dp[i][j]=min(dp[i][j],dp[i-1][j-1]+abs(a[(n/k)*i+j-1]-a[(n/k)*(i-1)+j-1]));
			}
		}
	}
	
	long long Ans=0ll;
	Ans=dp[k][n%k];
	
	printf("%I64d\n",Ans);
	return 0;
}

