//Language: GNU C++11


#pragma comment(linker, "/STACK:66777216")
#define _CRT_SECURE_NO_WARNINGS
//#include <unordered_set>
//#include <unordered_map>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cassert>
#include <iomanip>
#include <complex>
#include <cstring>
#include <cstdio>
#include <bitset>
#include <string>
#include <vector>
#include <ctime>
#include <queue>
#include <stack>
#include <cmath>
#include <set>
#include <map>	
#include <complex>
using namespace std;

#define FOR(i, n) for (int i = 0; i < (n); ++i)
typedef long long LL;
typedef long double LD;
#define pb push_back
#define mp make_pair
#define all(v) (v).begin(), (v).end()
#define sz(v) (int)(v).size()

const int N = 500007;
int n, q, a[N], b[N];
char ty[N];
bool alive[N];
int top, L[N + N], R[N + N], head[N];
int lu[N], ru[N], lm[N], rm[N];
int univ_pos[N], mil_pos[N];

void dfs(int u, vector<int> &order) {
   if (u <= n) {
      order.pb(u);
      return;
   }
   dfs(L[u], order);
   dfs(R[u], order);
}

vector<int> get_order(char type) {
   for (int i = 1; i <= n; ++i) {
      alive[i] = true;
      head[i] = i;
      L[i] = R[i] = 0;
   }
   top = n + 1;
   FOR(iter, q) {
      if (ty[iter] != type) continue;
      int u = a[iter];
      int v = b[iter];
      alive[v] = false;
      L[top] = head[u];
      R[top] = head[v];
      head[u] = top;
      ++top;
   }
   vector<int> order;
   for (int i = 1; i <= n; ++i) {
      if (alive[i]) dfs(head[i], order);
   }
   return order;
}

vector<int> univ_update[4 * N];
vector<LL> pref_sum[4 * N];
int mil_update[4 * N];

void update(int v, int tl, int tr, int l, int r, int type, int iter, int cnt) {
   if (tl == l && tr == r) {
      if (type == 1) {
         univ_update[v].pb(iter);
         pref_sum[v].pb(cnt + (pref_sum[v].empty() ? 0 : pref_sum[v].back()));
      }
      else mil_update[v] = max(mil_update[v], iter);
      return;
   }
   int tm = (tl + tr) / 2;
   if (r <= tm) update(2 * v, tl, tm, l, r, type, iter, cnt);
   else if (l > tm) update(2 * v + 1, tm + 1, tr, l, r, type, iter, cnt);
   else {
      update(2 * v, tl, tm, l, tm, type, iter, cnt);
      update(2 * v + 1, tm + 1, tr, tm + 1, r, type, iter, cnt);
   }
}

int mil_get(int v, int tl, int tr, int pos, int up) {
   if (tl == tr) return max(up, mil_update[v]);
   up = max(up, mil_update[v]);
   int tm = (tl + tr) / 2;
   if (pos <= tm) return mil_get(2 * v, tl, tm, pos, up);
   return mil_get(2 * v + 1, tm + 1, tr, pos, up);
}

LL univ_get(int v, int tl, int tr, int pos, int iter, LL add) {
   int index = lower_bound(all(univ_update[v]), iter) - univ_update[v].begin();
   if (index != sz(univ_update[v])) {
      add += pref_sum[v].back();
      if (index) add -= pref_sum[v][index - 1];
   }
   if (tl == tr) return add;
   int tm = (tl + tr) / 2;
   if (pos <= tm) return univ_get(2 * v, tl, tm, pos, iter, add);
   return univ_get(2 * v + 1, tm + 1, tr, pos, iter, add);
}

void solve() {
   scanf("%d%d", &n, &q);
   FOR(i, q) {
      scanf(" %c", &ty[i]);
      if (ty[i] == 'U' || ty[i] == 'M') scanf("%d%d", &a[i], &b[i]);
      else scanf("%d", &a[i]);
   }
   vector<int> univ = get_order('U');
   vector<int> mil = get_order('M');

   FOR(i, n) {
      lu[univ[i]] = i;
      ru[univ[i]] = i;
      univ_pos[univ[i]] = i;
      lm[mil[i]] = i;
      rm[mil[i]] = i;
      mil_pos[mil[i]] = i;
   }

   FOR(iter, q) {
      int u = a[iter];
      int v = b[iter];
      if (ty[iter] == 'Q') {
         int pos = mil_pos[u];
         int last_zero = mil_get(1, 0, n - 1, pos, 0);
         pos = univ_pos[u];
         LL ans = univ_get(1, 0, n - 1, pos, last_zero, 0);
         printf("%lld\n", ans);
      }
      if (ty[iter] == 'U') {
         assert(ru[u] + 1 == lu[v]);
         ru[u] = ru[v];
      }
      if (ty[iter] == 'M') {
         assert(rm[u] + 1 == lm[v]);
         rm[u] = rm[v];
      }
      if (ty[iter] == 'A') {
         update(1, 0, n - 1, lu[u], ru[u], 1, iter + 1, ru[u] - lu[u] + 1);
      }
      if (ty[iter] == 'Z') {
         update(1, 0, n - 1, lm[u], rm[u], 2, iter + 1, -1);
      }
   }
}

void testGen() {
   FILE *f = fopen("input.txt", "w");
   fclose(f);
}

int main() {
#ifdef harhro94
   //testGen();
   freopen("input.txt", "r", stdin);
   //freopen("output.txt", "w", stdout);
#else
#define task "genome"
   //freopen(task".in", "r", stdin);
   //freopen(task".out", "w", stdout);
#endif

   cerr << fixed;
   cerr.precision(3);
   cout << fixed;
   cout.precision(9);

   solve();

#ifdef harhro94
   cerr << fixed << setprecision(3) << "\nExecution time = "
      << clock() / (double)CLOCKS_PER_SEC << "s\n";
#endif
   return 0;
}