//Language: GNU C++


// be namee khoda

#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <queue>
#include <stack>

using namespace std;

#define pb push_back
#define mp make_pair
#define F first
#define S second

typedef long long ll;
typedef pair <int, int> pii;

const int maxn = 2e5 + 10;

int n, m, deg[maxn], val[maxn], d[maxn];
vector <pii> adj[maxn], moj[maxn];
vector <int> cadj[maxn];
bool mark[maxn], markv[maxn];
queue <int> Q;

void input ()
{
    cin >> n >> m;
    for (int i = 0; i < n; i++)
    {
        int k;
        cin >> k;
        if(k == 1)
            Q.push(i);
        deg[i] = k;
        while(k--)
        {
            int v;
            cin >> v;
            cadj[i].pb(v);
            adj[abs(v) - 1].pb(mp(i, v / abs(v)));
        }
        deg[i] = cadj[i].size();
    }
    for (int i = 0; i < m; i++)
        d[i] = adj[i].size();
}

void popQ ()
{
    while(!Q.empty())
    {
        int now = Q.front();
        Q.pop();
        if(mark[now])
            continue;
        bool f = 0;
        for (int i = 0; i < cadj[now].size(); i++)
        {
            int nv = cadj[now][i];
            if(markv[abs(nv) - 1])
                continue;
            f = 1;
            mark[now] = markv[abs(nv) - 1] = 1;
            d[abs(nv) - 1]--;
            val[abs(nv) - 1] = (nv / abs(nv) == 1 ? 1 : 0);
            if(adj[abs(nv) - 1].size() == 2)
                for (int j = 0; j < adj[abs(nv) - 1].size(); j++)
                {
                    int ng = adj[abs(nv) - 1][j].F;
                    if(nv / abs(nv) == adj[abs(nv) - 1][j].S && ng != now)
                    {
                        mark[ng] = 1;
                        d[abs(nv) - 1]--;
                    }
                    else if(ng != now) {
                        deg[ng]--;
                        if(!deg[ng] && !mark[ng])
                            exit( cout << "NO\n" ? 0:0);
                        else if(deg[ng] == 1)
                            Q.push(ng);
                    }
                }
            break;
        }
        if(!f)
            exit (cout << "NO\n" ? 0:0);
    }
}

int findadj (int v)
{
    for (int i = 0; i < adj[v].size(); i++)
        if(!mark[adj[v][i].F])
            return i;
}

void decdeg (int v)
{
    for (int i = 0; i < cadj[v].size(); i++)
        if(!markv[cadj[v][i]])
            d[cadj[v][i]]--;
}

void make_adj()
{
    for (int i = 0; i < m; i++)
        if(!markv[i])
        {
            if(d[i] == 0)
                markv[i] = 1;
            else if(d[i] == 1)
            {
                int ind = findadj(i);
                val[i] = (adj[i][ind].S == 1 ? 1 : 0);
                markv[i] = mark[adj[i][ind].F] = 1;
                decdeg(adj[i][ind].F);
            }
            else
            {
                int u, v;
                v = adj[i][0].F;
                u = adj[i][1].F;
                moj[v].pb( mp(u, adj[i][0].S * (i + 1)) );
                moj[u].pb( mp(v, adj[i][1].S * (i + 1)) );
            }
        }
}

vector <int> barg;

void dfs_visit(int v)
{
    mark[v] = 1;
    bool f = 0;
    for (int i = 0; i < moj[v].size(); i++)
    {
        int nv = moj[v][i].F;
        if(!mark[nv])
        {
            dfs_visit(nv);
            val[abs(moj[v][i].S) - 1] = (moj[v][i].S / abs(moj[v][i].S) == 1 ? 1 : 0);
            markv[abs(moj[v][i].S) - 1] = 1;
            f = 1;
        }
    }
    if(!f)
        barg.pb(v);
}

void dfs ()
{
    for (int i = 0; i < n; i++)
        if(!mark[i])
            dfs_visit(i);
}

void sat_barg ()
{
    for (int i = 0; i < barg.size(); i++)
    {
        int v = barg[i];
        for (int j = 0; j < moj[v].size(); j++)
        {
            int x = moj[v][j].S;
            if(!markv[abs(x) - 1])
            {
                val[abs(x) - 1] = (x / abs(x) == 1 ? 1 : 0);
                markv[abs(x) - 1] = 1;
                mark[v] = 1;
            }
        }
    }
}

void solve ()
{
    popQ();
    make_adj();
    dfs();
    sat_barg();
}

void output()
{
    for (int i = 0; i < n; i++)
        if(!mark[i])
            exit (cout << "NO\n" ? 0 : 0);
    cout << "YES" << endl;
    for (int i = 0; i < m; i++)
        cout << val[i];
    cout << endl;
}

int main()
{
    ios_base::sync_with_stdio(0);
    input();
    solve();
    output();
}