//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cctype>
#include<algorithm>
#include<cstdlib>
#include<string>
#include<ctime>
#include<map>
#include<set>
#include<vector>
#include<list>
#include<stack>
#include<queue>
#include<utility>
using namespace std;
#define ULL unsigned long long
#define LL long long
#define INF 0x3f3f3f3f
#define ccc 2147483646
#define maxn 25000000
#define mod 1000000007LL
#define rep(i,n) for(int i = 0; i < n; ++i)
#define Rep(i,n) for(int i = 1; i <= n; ++i)
#pragma comment(linker, "/STACK:1024000000,1024000000")

struct edge{
    int u, v;
    edge(){}
    edge(int u, int v):u(u), v(v){}
}e[100100];

int color[100100] = {0}, fa[100100], first[100100], vv[200200], nxt[200200], tot = 0, cnt = 0;
LL ans = 1;

int f(int x) {
    return fa[x] == x ? x : fa[x] = f(fa[x]);
}

void add(int u, int v) {
    vv[tot] = v;
    nxt[tot] = first[u];
    first[u] = tot++;
}

void dfs(int u, int c) {
    color[u] = c;
    for(int i = first[u]; ~i; i = nxt[i]) {
        int v = vv[i];
        if(!color[v]) dfs(v, 3-c);
        else if(color[v] == color[u]) ans = 0;
    }
}

int main()
{
    int n, m;
    cin >> n >> m;
    Rep(i,n) fa[i] = i;
    int u, v, type;
    while(m--) {
        scanf("%d%d%d",&u,&v,&type);
        if(type) {
            int fu = f(u), fv = f(v);
            fa[fu] = fv;
        }
        else e[cnt++] = edge(u, v);
    }
    memset(first, -1, sizeof(first));
    rep(i,cnt) {
        u = f(e[i].u); v = f(e[i].v);
        if(u == v) {ans = 0; continue;}
        add(u, v);
        add(v, u);
    }
    cnt = -1;
    Rep(i,n) {
        int fu = f(i);
        if(color[fu]) continue;
        dfs(fu, 1);
        ++cnt;
    }
    while(cnt--) ans = ans * 2 % mod;
    cout << ans << endl;
    return 0;
}
