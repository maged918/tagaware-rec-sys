//Language: MS C++


#pragma comment(linker, "/STACK:16777216")
#include <cctype>
#include <iostream>
#include <fstream>
#include <string.h>
#include <algorithm>
#include <vector>
#include <math.h>
#include <time.h>
#include <cmath>
#include <vector>
#include <stack>
#include <queue>
#include <deque>
#include <map>
#include <string>
#include <list>
#include <iomanip>
#include <set>
#include <string>
#include <iterator>

#define forn(i, n) for (i64 i = 0; i < n; ++i)
#define revn(i, n) for (i64 i = n-1; i>=0; --i)
#define cyc(i, s, n) for (i64 i = s; i <= n; ++i)
#define pb push_back
#define mp(a,b) make_pair(a,b)
#define all(x) x.begin(), x.end()
#define F first
#define S second
#define eps 1e-12
#define inf 1000000007
#define debug(x) cout << x << endl;


using namespace std;
typedef unsigned long long u64;
typedef long long i64;
typedef long double ld;
typedef vector < i64 > vi64;
typedef vector < u64 > vu64;
typedef pair < i64, i64 > pi64;
typedef vector < vi64 > graph;
typedef int huint;

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

inline i64 nextInt() {
    i64 s = 1, x = 0, c = getc(stdin);
    while (c <= 32)
        c = getc(stdin);
    if (c == '-')
        s = -1, c = getc(stdin);
    while ('0' <= c && c <= '9')
        x = x * 10 + c - '0', c = getc(stdin);
    return x * s;
}

inline void printInt(i64 x) {
    if (x < 0)
        putc('-', stdout), x = -x;
    char s[20];
    i64 n = 0;
    while (x || !n)
        s[n++] = '0' + x % 10, x /= 10;
    while (n--)
        putc(s[n], stdout);
}

inline void NextString( char *s ) {
    int c = getc(stdin);
    while (c <= 32)
        c = getc(stdin);
    while (c > 32)
        *s++ = c, c = getc(stdin);
    *s = 0;
}

inline void writeWord( char *s ) {
    while (*s)
        putchar(*s++);
}

i64 binpow (i64 a, i64 n) {
    i64 res = 1;
    while (n) {
        if (n&1) res *= a;
        a *= a;
        n >>= 1;
    } return res;
}

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

i64 gcd(i64 a, i64 b) {
    return b?gcd(b, a%b):a;
}

int main() {
    //freopen("funny.in", "r", stdin);
    //freopen("funny.out", "w", stdout);
    i64 n = nextInt();
    vi64 v(n);
    forn(i, n) v[i] = nextInt();
    i64 g = v[0];
    forn(i, n-1) {
        g = gcd(g, v[i+1]);
    }
    forn(i, n) v[i] /= g;
    forn(i, n) {
        while (!(v[i]%2)) {
            v[i]/=2;
        }
        while (!(v[i]%3)) {
            v[i]/=3;
        }
    }
    bool ok = true;
    forn(i, n) ok &= (v[i]==1);
    if (ok) cout << "Yes";
    else cout << "No";
}











