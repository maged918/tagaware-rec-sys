//Language: GNU C++11


//============================================================================
// Name        : Pasha.cpp
// Author      : khaled
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
int n,m,k;
int main() {
	cin>>n>>m>>k;
	int arr[n+1][m+1];
	bool q=false;
	int out=0;
	int a,b;
	for (int i = 0; i < n+1; ++i) {
		for (int j = 0; j < m+1; ++j) {
			arr[i][j]=0;
		}
	}
	for (int i = 0; i < k; ++i) {
		cin>>a>>b;
		arr[a][b]=1;
		if(q==false)
		{
			if(a<n&&b<m)
				if(arr[a][b]&&arr[a+1][b]&&arr[a][b+1]&&arr[a+1][b+1])
				{
					q=true;
					out=i+1;
				}
			if(a>1&&b<m)
				if(arr[a][b]==1&&arr[a-1][b]&&arr[a][b+1]&&arr[a-1][b+1])
				{
					q=true;
					out=i+1;
				}
			if(a<n&&b>1)
				if(arr[a][b]&&arr[a+1][b]&&arr[a][b-1]&&arr[a+1][b-1])
				{
					q=true;
					out=i+1;
				}
			if(a>1&&b>1)
				if(arr[a][b]&&arr[a-1][b]&&arr[a][b-1]&&arr[a-1][b-1])
				{
					q=true;
					out=i+1;
				}
		}
	}
	if(q==true)
		cout<<out<<endl;
	else
		cout<<"0"<<endl;
	return 0;
}
