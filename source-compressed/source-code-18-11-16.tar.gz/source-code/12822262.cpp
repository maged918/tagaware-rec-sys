//Language: GNU C++11



#include<iostream>
#include<map>
#include<math.h>
#include<algorithm>
#include<stdio.h>
using namespace std;

long long b[100001],a[100001];

int main()
{double a1,a2,a3,a4,a5,a6,y=0,x1,x2,x3,p;
cin>>a1>>a2>>a3>>a4>>a5>>a6;
y+=0.5*a1*a2*sqrt(3.0)/2;
y+=0.5*a3*a4*sqrt(3.0)/2;
 y+=0.5*a5*a6*sqrt(3.0)/2;
       x1=sqrt(a1*a1+a2*a2+a1*a2);
       x2=sqrt(a3*a3+a4*a4+a3*a4);
       x3=sqrt(a5*a5+a6*a6+a5*a6);
p=(x1+x2+x3)/2;
y+=sqrt(p*(p-x1)*(p-x2)*(p-x3));
cout<<(int)(4*y/sqrt(3.0));


    return 0;

}
