//Language: GNU C++


#include<iostream>
using namespace std;
int main()
{

    int Hy,Ay,Dy,Hm,Am,Dm,h,a,d;

    cin>>Hy>>Ay>>Dy;
    cin>>Hm>>Am>>Dm;
    cin>>h>>a>>d;

    int ans=10000000000;

    for(int i=0; i<=200; i++)

        for(int j=0; j<=200; j++)
        {

            int X=Ay+i-Dm;

            int Y=Am-(Dy+j);

            if  (X<=0) continue;

            int hp=((Hm/X+(int)(Hm%X!=0))*Y) +1;

            int k=max(hp-Hy,0);
            ans=min(ans,a*i+d*j+h*k);
        }
    cout<<ans<<endl;
}
