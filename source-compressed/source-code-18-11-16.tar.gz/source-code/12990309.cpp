//Language: GNU C++11


#include"bits/stdc++.h"
using namespace std;

int main()
{

	int n;
	scanf("%d",&n);
	vector<int> p(n+1,0);
	int cycle = 0;
	for(int i = 1;i<=n;++i)
	{
		scanf("%d",&p[i]);
		if(p[i] == i)
		{
			cycle = i;
		}
	}

	//If there is a lenght 1 cycle do it
	if(cycle != 0)
	{
		printf("YES\n");
		for(int i =1;i<=n;++i)
		{
			if(i!=cycle)
			{
				cout<<i<<' '<<cycle<<'\n';
			}
		}
		return 0;
	}

	for(int i = 1;i<=n;++i)
	{
		if(p[p[i]] == i)
		{
			cycle = i;
			break;
		}
	}

	if(cycle != 0)
	{
		vector<pair<int,int>> edges;
		vector<bool> visited(n+1,false);
		
		int c1 = cycle;
		int c2 = p[cycle];
		visited[c1] = visited[c2] = true;
		edges.push_back({c1,c2});

		for(int i = 1;i<=n;++i)
		{
			if(!visited[i])
			{
				int cl = 0;
				int pres = i;
				while(!visited[pres])
				{
					visited[pres] = true;
					if(cl%2 == 0)
					{
						edges.push_back({c1,pres});
					}
					else
					{
						edges.push_back({c2,pres});
					}
					pres = p[pres];
					cl++;
				}
				if(cl%2 != 0)
				{
					cout<<"NO\n";
					return 0;
				}
			}
		}
		cout<<"YES\n";
		for(auto e:edges)
		{
			printf("%d %d\n",e.first,e.second);
		}
		return 0;
	}
	else
	{
		printf("NO\n");
		return 0;
	}
	
	return 0;
}
