//Language: GNU C++11


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <queue>
#include<ctime>
#define Inf 0x3f3f3f3f
using namespace std;
int a[200220];int n,i;double r,l,mid1,mid2;
double check(double o){
    double tem=0.0;
    double ma=-Inf*1.0;
    for(i=1;i<=n;++i){
        tem+=a[i]-o;
        ma=max(ma,tem);
        if(tem<0)tem=0.0;
    }
    tem=0.0;
    double mi=Inf;
    for(i=1;i<=n;++i){
        tem+=a[i]-o;
        mi=min(mi,tem);
        if(tem>0)tem=0.0;
    }
    return max(ma,-mi);
}
int main(){
    scanf("%d",&n);
    for(i=1;i<=n;++i)scanf("%d",&a[i]);
    r=20000.0;l=-20000.0;
    while(clock()<1900){
        mid1=(l+l+r)/3.0;
        mid2=(l+r+r)/3.0;
        if(check(mid1)>=check(mid2)){
            l=mid1;
        }else{
            r=mid2;
        }
    }
    printf("%.10lf\n",check((l+r)/2.0));
    return 0;
}