//Language: GNU C++11


#include "bits/stdc++.h"
using namespace std;

typedef long double LD;
typedef long long int LL;

#define F first
#define S second

int n, T[250005];
vector<int> numbers;
unordered_map<int,int> gcd_numbers, gcd_current;

int Gcd(int x, int y) {
  if (y == 0) return x;
  return Gcd(y, x % y);
}

int main() {
  scanf("%d", &n);
  for (int i = 0; i < n*n; i++)
    scanf("%d", &T[i]);

  sort(T, T+n*n);
  reverse(T, T+n*n);

  /*printf("nums: ");
  for (int i = 0; i < n*n; i++)
    printf("%d ", T[i]);
  printf("\n");*/

  for (int i = 0; i < n*n; i++) {
    int cur = T[i];
    /*printf("cur = %d\n", cur);
    for (const auto& xx : gcd_current) {
      printf("%d: %d\n", xx.first, xx.second);
    }*/
    if (gcd_numbers[cur] + 1 > gcd_current[cur]) {
      //printf("adding number %d\n", cur);
      for (int j = 0; j < numbers.size(); j++) {
        gcd_current[Gcd(numbers[j], cur)] += 2;
      }
      numbers.push_back(cur);
      gcd_current[cur]++;
    }
    gcd_numbers[cur]++;
    //printf("\n");
  }

  for (int i = 0; i < numbers.size(); i++)
    printf("%d ", numbers[i]);
  printf("\n");

  return 0;
}
