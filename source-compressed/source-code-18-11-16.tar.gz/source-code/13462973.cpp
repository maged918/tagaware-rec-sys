//Language: GNU C++11


#include <stdio.h>
#include <string.h>
#include <string>
#include <algorithm>
#include <vector>
#include <iostream>
#include  <sstream>
#include <complex>
#include <stack>
#include <map>
using namespace std;
 
typedef complex<double> point;

#define X real()
#define Y imag()
#define vec(a,b) ((b)-(a))
#define length(a) (hypot((a).X,(a).Y))
#define  angle(a) (atan2((a).Y,(a).X))
#define rotate(v,t) ((v)*exp(point(0,t)))
#define cross(a,b) ((conj(a)*(b)).imag())
#define   dot(a,b) ((conj(a)*(b)).real())
#define PI (acos(0)*2.000000000)

int main () {
	vector <point> p;

	double l, ang = 0;
	point cur = point (0, 0);
	for (int i=0;i<6;i++) {
		p.push_back(cur);
		//cout << cur << " " << ang*180.000000000/PI << endl;
		scanf ("%lf", &l);
		point v = point (1.000000000, 0.000000000);
		v *= l;
		v = rotate(v, ang);
		cur = v + cur;
		ang += PI / 3.000000000;
	}
	//cout << cur << " " << ang << endl;

	point ref = point (-1, -1);
	double area = 0;

	for (int i=0;i<6;i++) {
		area += (cross(vec(ref, p[i]), vec(ref, p[(i+1)%6]))) / 2.000000000;
	}
	area = fabs(area);
	double ans = area / (sin(PI/3.000000000)/2.000000000);

	//cout << ans << endl;
	printf ("%.0lf\n", ans);

	return 0;
}