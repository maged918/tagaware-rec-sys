//Language: GNU C++11


#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <vector>

using namespace std;

const int ERROR = -1;
const int MAXN = 1e5 + 10;

int n, t;
char str1[MAXN], str2[MAXN], str3[MAXN];
vector<int> isti, raz;

int main(){
    scanf("%d %d", &n, &t);
    scanf("%s", &str1);
    scanf("%s", &str2);

    for(int i = 0; i < n; i++){
         if(str1[i] == str2[i]){
               isti.push_back(i);
               str3[i] = str1[i];
         }

         else{
               for(char zn = 'a'; zn <= 'z'; zn++)
                 if(str1[i] != zn && str2[i] != zn){
                        str3[i] = zn;
                        raz.push_back(i);
                        break;
                 }
         }
    }

    int br = (int)raz.size();
    for(int i = 0; i < (int)isti.size() && br < t; i++){
                for(char zn = 'a'; zn <= 'z'; zn++){
                       if(str1[isti[i]] != zn){
                             str3[isti[i]] = zn;
                             break;
                       }
                }

                br++;
    }

    bool bul = true;
    for(int i = 0; i < (int)raz.size() && br > t; i++){
        if(bul){
              str3[raz[i]] = str1[raz[i]];
        }
        else{
              str3[raz[i]] = str2[raz[i]];
              br--;
        }
        bul = !bul;
    }

    if(br != t){
          printf("%d\n", ERROR);
    }

    else{
          for(int i = 0; i < n; i++)
            printf("%c", str3[i]);
    }

    return 0;
}
