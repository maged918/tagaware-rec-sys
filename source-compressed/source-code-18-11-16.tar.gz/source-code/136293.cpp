//Language: GNU C++


#include<iostream>
#include<vector>
#include<algorithm>
#include<utility>
#include<map>
#include<set>
#include<cmath>
#include<cstdio>
#include<sstream>
#include<string>
#include<queue>
#include<stack>
#include<cstdlib>
#include<cstring>

#define FRR(i,n) for(int i=0; i<(int) n; i++) 
#define mp make_pair
#define pb push_back

using namespace std;

int main()
{
	int n;
	cin>>n;
	pair<int, int> aa[5001];
	FRR(i,n){
		cin>>aa[i].first>>aa[i].second;
	}

	vector<int> v;

	pair<int, int> bb[5001];

	FRR(i,n){
		int m=0;
		FRR(j,n)  if(i!=j) bb[m++]=aa[j];
		sort(bb,bb+m);
		int s1=-1;
		int flag=0;
		FRR(j,m){
			if(s1 > bb[j].first){
				flag=1;
				break;
			}
			s1=bb[j].second;
		}
		if(!flag) v.pb(i+1);
	}

	cout<<v.size()<<endl;
	FRR(i,v.size()) cout<<v[i]<<" ";
	if(v.size()) cout<<endl;
}
