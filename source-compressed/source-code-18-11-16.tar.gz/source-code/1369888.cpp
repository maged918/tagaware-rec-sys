//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <vector>
#include <iostream>
#include <cstring>
#include <map>
#include <set>
#include <queue>
#include <bitset>
using namespace std;
typedef long long LL;
#define FOR(x, b, e) for (int x = (b); x <= (e); ++x)
#define FORD(x, b, e) for (int x = (b); x >= (e); --x)
#define REP(x, n) for (int x = 0; x < (n); ++x)
#define VAR(v, n) typeof(n) v = (n)
#define ALL(c) (c).begin(), (c).end()
#define SIZE(x) ((int) (x).size())
#define EACH(i, c) for (VAR(i, (c).begin()); i != (c).end(); ++i)
#define REACH(i, c) for (VAR(i,(c).rbegin()); i != (c).rend(); ++i)
#define UNIQUE(v) do { sort(ALL(v)); (v).resize(unique(ALL(v)) - (v).begin()); } while (0)
#define PB push_back
#define ST first
#define ND second
#define MP make_pair
#define skip continue
const int INF = 1000000001;

#define GET(x)		(scanf("%d", &(x)) == 1)
#define GETS(x)		(scanf("%s", (x)) == 1)
#define DGET(x)		int x; GET(x);

#define DISP_LINE ""
//~ #define DISP_LINE __LINE__ << " "
#define DEB_COND 1
#define db(x) { if (DEB_COND) { cerr << DISP_LINE << #x << " " << x << endl; } }
#define dbv(x) { if (DEB_COND) { cerr << DISP_LINE << #x << ": "; EACH (__i, x) cerr << *__i << " "; cerr << endl; } }
#define dbf(x, b, e) { if (DEB_COND) { cerr << DISP_LINE << #x << ": "; FOR (__i, (b), (e)) cerr << x[__i] << " "; cerr << endl; } }
#define dbm(x) { if (DEB_COND) { cerr << DISP_LINE << #x << endl; } }

const int N = 1000005;
char IN[N];

int one[N];

int main()
{
	DGET(k);
	GETS(IN);
	
	int o = 0;
	for (char *i = IN; *i; ++i) {
		if (*i == '1') {
			one[++o] = i - IN;
		}
	}
	one[0] = -1;
	one[o+1] = one[o];
	for (char *i = IN + one[o]; *i; ++i) {
		one[o+1]++;
	}
	
	dbf(one, 0, o+1)
	
	LL sol = 0;
	if (k) {
		FOR (i, 1, o-k+1) {
			sol += (LL) (one[i]-one[i-1]) * (one[i+k-1+1]-one[i+k-1]);
		}
	} else {
		if (!o) {
			o = strlen(IN);
			sol += (LL) o * (o + 1) / 2;
		} else {
			FOR (i, 1, o+1) {
				sol += (LL) (one[i]-one[i-1]-1) * (one[i]-one[i-1]) / 2;
			}
		}
	}
	cout << sol << '\n';
}
