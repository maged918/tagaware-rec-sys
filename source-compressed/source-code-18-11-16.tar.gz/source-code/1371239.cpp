//Language: GNU C++


#include <iostream>
#include <cmath>

using namespace std;

bool sum(int current_v, int k, int s,int n){
	int x = current_v/k;
	while(x && s < n ){
		s = s + x;
		x = x/k;
	}
	if( s >= n)
		return true;
	else 
		return false;
}


int main(){
	int n,k;
	cin >> n >> k;
	int min_v = n;
	int begin  = 1, end = n;
	int current_v = (begin + end)/2;
	while((current_v != end) && (current_v != begin)){
		//cout << begin << " " << current_v << " "<< end << " "<< endl;
		if(sum(current_v, k, current_v,n)){
			min_v = current_v;
			end = current_v;
		}
		else
			begin = current_v;
		
		current_v = (begin + end)/2;
	}
	cout << min_v << endl;
} 