//Language: GNU C++


#include<cstdio>
#include<cstring>

using namespace std;
const int N = 100006;

char a[N],b[N],c[N];

int main()
{
    int n,t;
    
    scanf("%d %d",&n,&t);
    scanf("%s %s",a,b);
    memset(c,'.',sizeof(c));
    t=n-t;
    int x=0,y=0;
    for(int i=0;i<n;i++)
    {
        if(a[i]!=b[i]) continue;
        if(x==t && y==t)
        {
            if(a[i]=='z') c[i]='a';
            else c[i]=a[i]+1;
        }
        else
        {
            c[i]=a[i];
            x++,y++;
        }
    }
    for(int i=0;i<n;i++)
    {
        if(a[i]==b[i]) continue;
        if(x==t && y==t)
        {
            for(int j='a';j<='z';j++)
            {
                if(j!=a[i] && j!=b[i])
                {
                    c[i]=j;
                    break;
                }
            }
        }
        else if(x<y)
        {
            c[i]=a[i];
            x++;
        }
        else
        {
            c[i]=b[i];
            y++;
        }
    }
    c[n]=0;
    if(x==t && y==t) puts(c);
    else puts("-1");
    return 0;
}