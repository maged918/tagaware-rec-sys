//Language: GNU C++11


/* sourav_v @ codeforces */
    
#include<bits/stdc++.h>
#define ll long long int
using namespace std;

#define M 500090
int main()
{
    int n,a[M],b[M],p=0,c,d; scanf("%d",&n);
    for(int i=1;i<=n;i++) 
        scanf("%d",&a[i]);
    b[1]=1;
    for(int i=2;i<=n;i++) {
        if(a[i]!=a[i-1]) b[i]=b[i-1]+1;
        else b[i]=1;
        // no of iterations 
        p=max(p,b[i]);
    }
    
    if(p%2==0) p=(p-1)/2;
    else p/=2;
    printf("%d\n",p);
    for(int i=1;i<=n;i++){
        if(b[i+1]<b[i] && b[i]%2==1) {
            c=a[i];
            //reverse lookup
            for(int j=i;j>=i-b[i]+1;j--) a[j]=c;
        }
        else if(b[i+1]<b[i] && b[i]%2==0) {
            c=a[i];
            d=a[i-b[i]+1];
            //reverse lookup 
            for(int j=i;j>=i-b[i]/2+1;j--) a[j]=c;
            //reverse lookup
            for(int j=i-b[i]/2;j>=i-b[i]+1;j--) a[j]=d;
        }
    }
    for(int i=1;i<=n;i++) cout<<a[i]<<" ";
    return 0;
}