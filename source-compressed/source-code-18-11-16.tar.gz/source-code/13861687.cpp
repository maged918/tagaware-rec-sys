//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define pii pair<int,int>
#define pll pair<ll,ll>
#define pdd pair<double,double>
#define X first
#define Y second
#define REP(i,a) for(int i=0;i<a;++i)
#define REPP(i,a,b) for(int i=a;i<b;++i)
#define FILL(a,x) memset(a,x,sizeof(a))
#define	foreach( gg,itit )	for( typeof(gg.begin()) itit=gg.begin();itit!=gg.end();itit++ )
#define	mp make_pair
#define	pb push_back
#define sz(a) int((a).size())
#define all(a)  a.begin(), a.end()
#define	debug(ccc)	cout << #ccc << " = " << ccc << endl;
#define present(c,x) ((c).find(x) != (c).end())
const double eps = 1e-8;
#define EQ(a,b) (fabs((a)-(b))<eps)
inline int max(int a,int b){return a<b?b:a;}
inline int min(int a,int b){return a>b?b:a;}
inline ll max(ll a,ll b){return a<b?b:a;}
inline ll min(ll a,ll b){return a>b?b:a;}
const int mod = 1e9+7;
const int N = 1e6+10;
const ll inf = 1e18;
ll fl(ll x, ll y) {
    if (x >= 0) return x / y;	return x / y - (x % y ? 1 : 0);
}
ll cl(ll x, ll y) {
    if (x >= 0) return (x + y - 1) / y;    return x / y;
}

ll power(ll a,ll n){
	if(n==0){
		return 1;
	}
	ll b = power(a,n/2);
	b = b*b%mod;
	if(n%2) b= b*a%mod;
	return b;
}

int n,m;
char mat[1010][1010];
ll dis[1010][1010][4],vis[1010][1010];

void bfs(int val){
	REP(i,n)	REP(j,m)	dis[i][j][val]=mod;
	queue < pii> Q;
	//Q.clear();
	memset(vis,0,sizeof(vis));
	REP(i,n)	REP(j,m){
		if(mat[i][j]=='0'+val){
			dis[i][j][val]=0;
			Q.push(mp(i,j));
			vis[i][j]=1;
		}
	}
	while(!Q.empty()){
		pii a = Q.front();
		Q.pop();
		REPP(i,-1,2)	REPP(j,-1,2){
			int ii = a.X+i,jj = a.Y+j;
			if(ii<0 || ii>=n || jj<0 || jj>=m )	continue;
			if(a.X!=ii && a.Y!=jj)	continue;
			if(a.X==ii && a.Y==jj)	continue;
			if(vis[ii][jj])	continue;
			vis[ii][jj]=1;
			if(mat[ii][jj]=='#')	continue;
			if(dis[ii][jj][val] >dis[a.X][a.Y][val]+1){
				dis[ii][jj][val] =dis[a.X][a.Y][val]+1;
				Q.push(mp(ii,jj));
			}

		}
	}
	
}

int main(){
	
	scanf("%d %d",&n,&m);
	REP(i,n){
		scanf("%s",mat[i]);
	}
	bfs(1);
	bfs(2);
	bfs(3);
	int mask=0;
	ll mn12,mn13,mn23;
	mn12=mn13=mn23=mod;
	REP(i,n){
		REP(j,m){
			if(mat[i][j]=='2'){
				if(dis[i][j][1]==1){
					mask|=1;
				}
				mn12 = min(mn12,dis[i][j][1]);
			}
			if(mat[i][j]=='3'){
				if(dis[i][j][1]==1){
					mask|=2;
				}
				if(dis[i][j][2]==1){
					mask|=4;
				}
				mn23 = min(mn23,dis[i][j][2]);
				mn13 = min(mn13,dis[i][j][1]);
			}

		}
	}
  	mn12--;
  	mn13--;
  	mn23--;
  //	printf("%d\n",mask);
  //	printf("%d %d %d\n",mn12,mn13,mn23);
  	ll ans=mod;
  	if(mask==0){
  		
  		REP(i,n)	REP(j,m){
  			if(mat[i][j]=='.'){
  				ans = min(ans,dis[i][j][1]+dis[i][j][2]+dis[i][j][3]-2);
  			}	
  		}
  		ans = min(ans,mn12+mn13);
  		ans = min(ans,mn12+mn23);
  		ans = min(ans,mn13+mn23);
  	//	printf("%d\n",ans);
  	}else if(mask==1){
  		ans = (min(mn23,mn13));
  	}else if(mask==2){
  		ans = (min(mn12,mn23));
  	}else if(mask==4){
  		ans=(min(mn12,mn13));
  	}else ans=0;

  	//printf("%d\n",ans);
  	if(ans>1e7){
  		printf("-1\n");
  	}else{
  		printf("%lld\n",ans);
  	}
	return 0;
}
