//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>
#include <map>
#define INF 1000000002
int scan()
{ int noRead=0;
    char p= getchar();
    for(;p<33;)
    { p=getchar(); }
    while(p>32)
        {
            noRead = (noRead << 3) + (noRead << 1) + (p - '0');
            p=getchar();
        }
    return noRead;
}

using namespace std;

bool check(string a, string b, int n) {
    //cout<<"a and b "<<a <<" "<<b<<endl;
    if(n%2 != 0) {
        if(a != b)  return false;
    }
    if(a == b)  return true;
    return ( (check(a.substr(0, n/2), b.substr(n/2, n/2), n/2) && check(a.substr(n/2, n/2), b.substr(0, n/2), n/2)) ||
            (check(a.substr(0, n/2), b.substr(0, n/2), n/2) && check(a.substr(n/2, n/2), b.substr(n/2, n/2), n/2)) );
}


int main(void){
    ios_base::sync_with_stdio(false);
    string a,b;

    cin>>a>>b;

    int na = a.size();
    int nb = b.size();
    if(na != nb) {
        cout<<"NO";
        return 0;
    }
    if(na%2 != 0) {
        if(a != b) {
            cout<<"NO";
            return 0;
        }
    }

    if(check(a,b,na))  cout<<"YES";
    else    cout<<"NO";

    return 0;

}

