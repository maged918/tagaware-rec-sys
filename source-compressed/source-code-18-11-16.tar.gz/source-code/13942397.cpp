//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <cmath>
#include <map>
#include <queue>
#include <vector>
#define max(x,y) ((x)>(y)?(x):(y))
#define min(x,y) ((x)<(y)?(x):(y))
#define INF 1000000000
#define LL long long
#define P pair<int,int>
#define MP make_pair
#define eps 1e-15
#define MAXN 1000050
#define MOD 1000000007
using namespace std;

int main() {
	int a,b,k;
	scanf("%d%d",&a,&b);
	if(a<b){
		puts("-1");
		return 0;
	}
	k=(a-b)/(2*b);
	double ans=-1;
	for(int i=max(1,k-10);i<=k+10;++i){
		double x=(a-b)*1.0/(2.0*i);
		if(x<b-eps)break;
		if(ans<0||ans>x)
			ans=x;
	}
	k=(a+b)/(2*b)-1;
	for(int i=max(0,k-10);i<=k+10;++i){
		double x=(a+b)*1.0/(2.0*(i+1));
		if(x<b-eps)break;
		if(ans<0||ans>x)
			ans=x;
	}
	printf("%.10lf\n",ans);
}
