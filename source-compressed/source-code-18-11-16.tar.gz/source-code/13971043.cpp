//Language: GNU C++


#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <string>
#include <memory.h>
#include <map>
#include <set>
#include <stdio.h>

using namespace std;

typedef long long LL;

const int M = 1000 * 1000 * 1000 + 7;

void add(int &x, int y)
{
    x += y;
    if (x >= M)
        x -= M;
}

string str;

const int N = 1005;
const int K = 52;

struct S
{
    const char* s;
    int len;
};

int d;
string x;
string y;
vector<S> ar;

int trie_cnt;
int trie[26 * 1005][10];
int Len[26 * 1005];
const char* Start[26 * 1005];
int g[26 * 1005][10];

int dp[52][26 * 1005][2][2][2];

void Zer(string& s) {
    for (int i = 0; i < (int)s.size(); ++i)
        s[i] -= '0';
}

int D(int pos, int id, int px, int py, int good)
{
    if (pos == x.size()) {
        return good;
    }
    int& res = dp[pos][id][px][py][good];
    if (res != -1)
        return res;
    int js = 0;
    int je = 9;
    if (px)
        js = x[pos];
    if (py)
        je = y[pos];
    res = 0;
    for (int j = js; j <= je; ++j)
        add(res, D(pos + 1, g[id][j], px && x[pos] == j, py && y[pos] == j, good || Len[g[id][j]] == d));
    return res;
}

int main()
{
    cin >> str;
    cin >> x >> y;
    d = x.size() / 2;

    Zer(str);
    Zer(x);
    Zer(y);

    const int root = trie_cnt++;

    for (int i = 0; i < (int)str.size(); ++i) {
        int len = 1;
        int t = root;
        for (int j = i; j >= 0 && len <= d; --j, ++len) {
            int &tt = trie[t][str[j]];
            if (tt == 0) {
                tt = trie_cnt++;
                Len[tt] = len;
                Start[tt] = str.c_str() + i;
            }
            t = tt;
        }
    }
    for (int i = root; i < trie_cnt; ++i) {
        if (Len[i] == d) {
            for (int j = 0; j < 10; ++j)
                g[i][j] = trie_cnt;
        } else {
            int len = Len[i];
            for (int j = 0; j < 10; ++j) {
                const char* s = Start[i];
                int t = trie[root][j];
                if (t) {
                    for (int k = 0; k < len; ++k) {
                        int tt = trie[t][s[-k]];
                        if (tt != root) {
                            t = tt;
                        } else  {
                            break;
                        }
                    }
                }
                g[i][j] = t;
            }
        }
    }

    memset(dp, 0xFF, sizeof(dp));
    int res = D(0, root, 1, 1, 0);

    cout << res << "\n";

    return 0;
}
