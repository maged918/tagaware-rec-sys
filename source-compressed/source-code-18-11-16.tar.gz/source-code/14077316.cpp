//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

const int maxn = 100005;
typedef long long T;
T x1, x2;
bool one = false;
struct Line{
  T k,b;
  int idx;
  bool operator<(const Line& l)const{
    T r1 = k*x1+b, r2 = l.k*x1+l.b; 
    if(r1==r2)
      return (one==false?k<l.k:k>l.k);
    return r1<r2;
  }
  bool operator==(const Line& l)const{
    return idx==l.idx;
  }
};

int main(){
  ios_base::sync_with_stdio(0);
  int n;
  T k,b;
  cin>>n>>x1>>x2;
  vector<Line> l1,l2; 
  for(int i=0;i<n;i++){
    cin>>k>>b;
    l1.push_back({k,b, i});
    l2.push_back({k,b, i});
  }
  sort(l1.begin(), l1.end());
  x1 = x2;
  one = true;
  sort(l2.begin(), l2.end());
  if(l1==l2)
    cout<<"NO"<<endl;
  else
    cout<<"YES"<<endl;
  return 0;
}
