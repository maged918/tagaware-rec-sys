//Language: GNU C++0x


#ifdef MY_SUPER_PUPER_ONLINE_JUDGE
#include <fstream>
using namespace std;
ifstream cin("input.txt");
ofstream cout("output.txt");
#else
#include <iostream>
using namespace std;
#endif
#include <vector>
#include <iterator>
#include <algorithm>

int main()
{
    std::istream_iterator<int> it(cin);
    int n = *it++, a = *it++, b = *it++;
    vector<int> v(n);
    for(int i = 0; i < n; i++) v[i] = *it++;
    sort(v.begin(), v.end());
    cout << v[b] - v[b - 1];
}
