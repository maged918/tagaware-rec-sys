//Language: MS C++


#include <cstdio>
#include <iostream>
#include <string>
#include <algorithm>
#include <cmath>
#include <vector>
#include <stack>
#include <queue>
#include <list>
#include <map>
#include <set>
#include <stdlib.h>
#include <sstream>
#include <assert.h>
#include <memory.h>
#include <time.h>
#pragma comment(linker, "/STACK:20000000")

#define mp make_pair
#define pb push_back
#define ll long long
#define ull unsigned long long
#define sz(x) (int)(x).size()
using namespace std;

ll gcd(ll a, ll b) {
	if(!a) return b;
	return gcd(b % a, a);
}

vector<pair<ll, ll> > path;

void gcd2(ll a, ll b, bool rev = false) {
	if(!a) {
		if(b) path.pb(mp(rev, b));
		return;
	}
	if(a == 1) {
		if(b > 1) path.pb(mp(rev, b - 1));
		return;
	}
	if(b / a > 0) path.pb(mp(rev, b / a));
	gcd2(b % a, a, !rev);
}


int main() {
	//freopen("input.txt", "rt", stdin);
	//freopen("anagrams2.in", "rt", stdin);
	//freopen("anagrams2.out", "wt", stdout);
	
	ll a, b;
	cin >> a >> b;
	ll d = gcd(a, b);
	if(d != 1) {
		printf("Impossible\n");
		return 0;
	}

	gcd2(a, b, true);
	for(int i = 0; i < sz(path); i++) {
		if(path[i].first == 0) {
			printf("%lldA", path[i].second);
		}
		else {
			printf("%lldB", path[i].second);
		}
	}

	return 0;
}