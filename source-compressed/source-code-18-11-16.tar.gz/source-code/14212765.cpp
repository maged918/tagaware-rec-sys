//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

const int N = 2*1000+10;

vector< int > g[N];
bool vs[N];
int dp[N];

int dfs(int v){
    if(vs[v] == true)
        return dp[v];
    vs[v] = true;
    int mx = 0;
    for(auto u: g[v])
        mx = max( mx , dfs(u) );
    dp[v] = mx + 1;
    return dp[v];
}

int main(){
    int n;cin >> n;
    for(int i=0 ; i<n ; i++){
        int d;cin >> d; d--;
        if(d >= 0){
            g[d].push_back(i);
        }
    }
    int ans=-1;
    for(int i=0 ; i<n ; i++)
        ans = max(ans , dfs(i));
    cout << ans << endl;
}
   	  	 							        						