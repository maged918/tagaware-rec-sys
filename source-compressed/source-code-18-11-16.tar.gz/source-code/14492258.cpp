//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
int i,j,k,l,n,m,s,an,K,X,tot=1,oo,sum;
const int N=210000;
int a[N],g[N];
int main()
{
    scanf("%d",&n);
    for (int i=1;i<=n;i++)
    scanf("%d",&a[i]);
    sort(&a[1],&a[n+1]);
    /*for (int i=1;i<=n;i++)
    g[i]=g[i-1]+a[i];*/
    int s=n-(n-2+1)/2;
    an=a[n];
    for (int i=s;i<=n;i++)
    an=min(an,a[i]-a[i-s+1]);
    printf("%d\n",an);
}