//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
const long long MAX=1e5+9,MOD=1e9+7;
vector<pair<int,bool> > g[MAX];
int n,k,c,col[MAX];
bool dfs(int v)
{
	for (auto u:g[v])
		if (!col[u.first])
		{
			if (u.second)
			{
				col[u.first]=3-col[v];
				if (!dfs(u.first)) return false;
			}
			else
			{
				col[u.first]=col[v];
				if (!dfs(u.first)) return false;
			}
		}
		else if ((col[u.first]==col[v] && u.second) || (col[u.first]!=col[v] && !u.second)) return false;
	return true;
}
int main()
{
	cin>>n>>k;
	for (int i=0;i<k;i++)
	{	
		char ch;
		int u,v,l,r;
		cin>>u>>v>>ch,u--,v--;
		l=abs(u-v),r=u+v;
		if (r>n-1) r=2*(n-1)-(u+v);
		g[r+2].push_back({l,ch=='o'});
		g[l].push_back({r+2,ch=='o'});
	}
	long long ans=1,cnt=0;
	for (int i=0;i<n+2;i++)
		if (!col[i])
		{
			col[i]=1;
			if (!dfs(i)) return cout<<0,0;
			cnt++;
			if (cnt>2) ans=ans*2%MOD;
		}
	cout<<ans;
}
