//Language: GNU C++


#include<iostream>
#include<sstream>
#include<cstdio>
#include<cstring>
#include<string>
#include<vector>
#include<list>
#include<queue>
#include<utility>
#include <iterator>
#include <fstream>
#include<set>
#include<stack>
#include<map>
#include<cctype>
#include<cmath>
#include<algorithm>
using namespace std;


#define RALL(x) (x).rbegin(),(x).rend()
#define ALL(x) (x).begin(),(x).end()
#define repp(i,n) for(int (i)=1;(i)<=(n);(i)++)
#define rep(i,n) for(int (i)=0;(i)<(n);(i)++)
#define rev(i,n) for(int (i)=(n-1);(i)>=0;(i)--)
#define clr(a) memset((a), 0 ,sizeof(a))

typedef pair<int,int> P;
typedef vector<pair<int,string> > pii;
typedef map<string,int> mi;



// all...   495 
// a0.5-, b2.0-, c6.0-


int n,i,j,x;
int main(){
    vector<int> v;
    cin >> n;
    for(i=2;i<=n;i++){
        x=i;
        for(j=2;j<=n;j++) 
            if(i%j==0){
                while(x%j==0)
                    x/=j;
                break;
                }
        if(x==1) v.push_back(i);
    }
    cout << v.size() << endl;
    for(i=0;i<v.size();i++){
        if(i>0) cout << " ";
        cout << v[i];
    }
    cout << endl;
    return 0;
}