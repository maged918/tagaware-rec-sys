//Language: GNU C++


#include <iostream>
#include"stdio.h"
#include"string.h"
#include"math.h"


using namespace std;

int main()
{
    int n,x,y;
    while(scanf("%d%d%d",&n,&x,&y)==3){
        double pneed=(double )(n*y)/(double)100.0;
        int kx=ceil(pneed);
        if(kx>x){
            cout<<kx-x<<endl;
        }
        else {cout<<0<<endl;}
    }
    return 0;
}

	  		 				 	  	  			 	