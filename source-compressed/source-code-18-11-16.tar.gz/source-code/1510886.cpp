//Language: GNU C++


#include <iostream>
#include <cmath>

using namespace std;

long long N,X,Y;

void solve()
{
	if (sqrt(X-N+1)>Y-N+1||Y-N+1<=0)
	{
		cout << -1 << endl;
		return;
	}
	for (int i=0;i<N-1;i++)
		cout << 1 << endl;
	cout << Y-N+1 << endl;
}

int main()
{
	cin >> N >> X >> Y;
	solve();
	return 0;
}