//Language: GNU C++11


#include <bits/stdc++.h>
using namespace std;

const int MAXN = 100000;

int donde_izq[MAXN + 2];
int donde_der[MAXN + 2];
long long int max_izq[MAXN + 2];
long long int max_der[MAXN + 2];
long long int val_izq[MAXN + 2];
long long int val_der[MAXN + 2];
long long int a[MAXN + 2];
int n;

void g(int *donde, long long int *arr, int ini, int fin, int inc, int dist){
    for(int i = fin; i != ini; i -= inc){
        arr[i] = a[i + dist];
        if((arr[i] & 1) > 0){
            if(arr[i] > 2){
                arr[i] += arr[i + inc] - 2;
                donde[i] = donde[i + inc];
            }else if(arr[i] > 0){
                donde[i] = i;
                arr[i]--;
            }
        }else{
            if(arr[i] > 1){
                arr[i] += arr[i + inc] - 1;
                if(a[i + dist] > arr[i]){
                    arr[i] = a[i + dist];
                    donde[i] = i;
                }else{
                    donde[i] = donde[i + inc];
                }
            }
        }
    }
}

int main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;
    for(int i = 1; i < n; i++){
        cin >> a[i];
    }
    donde_der[n] = n;
    donde_izq[1] = 1;
    g(donde_der, max_der, 0, n - 1, 1, 0);
    g(donde_izq, max_izq, n + 1, 2, -1, -1);
    long long int aux;
    for(int i = n - 1; i >= 1; i--){
        val_der[i] = a[i];
        if((a[i] & 1) == 0){
            val_der[i]--;
        }
        val_der[i] += val_der[i + 1];
        val_der[i] = max(val_der[i], a[i]);
        aux = max_der[i] + i - donde_der[i];
        val_der[i] = max(val_der[i], aux);
    }
    for(int i = 2; i <= n; i++){
        val_izq[i] = a[i - 1];
        if((a[i - 1] & 1) == 0){
            val_izq[i]--;
        }
        val_izq[i] += val_izq[i - 1];
        val_izq[i] = max(val_izq[i], a[i - 1]);
        aux = max_izq[i] + i - donde_izq[i];
        val_izq[i] = max(val_izq[i], aux);
    }
    long long int res = 0;
    long long int izq, der;
    for(int i = 1; i <= n; i++){
        izq = i - donde_izq[i] + max_izq[i] + val_der[i];
        der = donde_der[i] - i + max_der[i] + val_izq[i];
        aux = max(izq, der);
        res = max(aux, res);
    }
    cout << res << "\n";
    return 0;
}
