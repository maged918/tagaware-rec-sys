//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
struct data{  
    int pos;  
    int le;  
}d[100002]; 
int numline[1000011]={0};
int cmp(const void *p1,const void *p2)  
{  
    data *ps=(data *)p1,*pe=(data *)p2;    
    return (ps->pos)-(pe->pos);  
}  
int main()
{
	int n;
	int j=0,i,num[100002]={0},max=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d%d",&d[i].pos,&d[i].le);
		d[i].le=d[i].pos-d[i].le;
	}
	qsort(&d[1],n,sizeof(data),cmp);
	for(i=1;i<=n;i++){
		while(j<=d[i].pos)
			numline[j++]=i;
		if(d[i].le<0) 
			num[i]=1;
		else num[i]=num[numline[d[i].le]-1]+1;
		if(max<num[i]) 
			max=num[i];	
	}
	printf("%d",n-max);
	return 0;
} 
     		 	 			  	   	 			   		 	