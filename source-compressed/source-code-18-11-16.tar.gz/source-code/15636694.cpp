//Language: GNU C++11


#include <functional>
#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <numeric>
#include <iomanip>
#include <stdio.h>
#include <cstring>
#include <cassert>
#include <bitset>
#include <vector>
#include <math.h>
#include <queue>
#include <stack>
#include <ctime>
#include <set>
#include <map>

using namespace std;

typedef long long ll;

template <typename T>
T nextInt() {
    T x = 0, p = 1;
    char ch;
    do { ch = getchar(); } while(ch <= ' ');
    if (ch == '-') {
        p = -1;
        ch = getchar();
    }
    while(ch >= '0' && ch <= '9') {
        x = x * 10 + (ch - '0');
        ch = getchar();
    }
    return x * p;
}

const int maxN = 5e2 + 10;
const int INF = (int)1e9;
const int mod = (int)1e9 + 7;
const ll LLINF = (ll)1e18;

void add(int &x, int y) {
    x += y;
    if (x >= mod) {
        x -= mod;
    }
}

int n, m;
int dp0[maxN][maxN];
int dp1[maxN][maxN];
char s[maxN][maxN];

bool ok(int x, int y, int a, int b) {
    if (x < 0 || x >= n) return false;
    if (a < 0 || a >= n) return false;
    if (y < 0 || y >= m) return false;
    if (b < 0 || y >= m) return false;
    return (s[x][y] == s[a][b]);
}

int main() {

    //freopen(".in", "r", stdin);
    //freopen(".out", "w", stdout);

    n = nextInt<int>();
    m = nextInt<int>();

    for (int i = 0; i < n; ++i) {
        gets(s[i]);
    }

    dp0[n - 1][m - 1] = ok(0, 0, n - 1, m - 1);
    int res = 0;
    for (int x1 = 0; x1 < n; ++x1) {
        for(int x2 = n - 1; x2 >= 0; --x2) {
            for (int y2 = m - 1; y2 >= 0; --y2) {
                int y1 = n + m - 2 - x1 - x2 - y2;
                if (y1 < 0 || y1 >= m) continue;
                if (dp0[x2][y2] == 0) continue;
                if (abs(x1 - x2) + abs(y1 - y2) <= 1 && x1 <= x2 && y1 <= y2) {
                    add(res, dp0[x2][y2]);
                }
                if (x1 + 1 < n && x2 > 0 && s[x1 + 1][y1] == s[x2 - 1][y2]) add(dp1[x2 - 1][y2], dp0[x2][y2]);
                if (x1 + 1 < n && y2 > 0 && s[x1 + 1][y1] == s[x2][y2 - 1]) add(dp1[x2][y2 - 1], dp0[x2][y2]);
                if (y1 + 1 < m && y2 > 0 && s[x1][y1 + 1] == s[x2][y2 - 1]) add(dp0[x2][y2 - 1], dp0[x2][y2]);
                if (y1 + 1 < m && x2 > 0 && s[x1][y1 + 1] == s[x2 - 1][y2]) add(dp0[x2 - 1][y2], dp0[x2][y2]);
            }
        }
        memcpy(dp0, dp1, sizeof dp1);
        memset(dp1, 0, sizeof dp1);
    }

    printf("%d\n", res);
    return 0;
}
