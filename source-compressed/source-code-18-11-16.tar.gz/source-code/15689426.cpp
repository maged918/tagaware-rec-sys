//Language: GNU C++11


#define _CRT_SECURE_NO_WARNINGS
#pragma comment(linker, "/STACK:134217728")
#include <iostream>
#include <utility>
#include <algorithm>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <climits>
#include <cstring>
#include <cmath>
#include <queue>
#include <cstdio>
#include <cassert>
#include <stack>
#include <ctime>
#include <bitset>
#include <sstream>
#include <random>

#define mp make_pair
#define mt(x,y,z) mp((x), mp((y), (z)))
#define ZERO(x) memset((x), 0, sizeof(x))
#define NEGATE(x) memset((x), 255, sizeof(x))

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> ii;
typedef pair<int, ii> iii;

double pi = atan(1.0) * 4.0;

struct point
{
	double x, y;
	point()
	{
		x = y = 0;
	}
	point(double x, double y) : x(x), y(y) {}
	void get()
	{
		cin >> x >> y;
	}
};

point operator -(point a, point b)
{
	return point(a.x - b.x, a.y - b.y);
}

ll operator %(point a, point b)
{
	return a.x * b.x + a.y * b.y;
}

point operator *(double x, point p)
{
	return point(x * p.x, x * p.y);
}

point operator +(point a, point b)
{
	return point(a.x + b.x, a.y + b.y);
}

double dst(point a, point b)
{
	return sqrt(max(0.0, (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y)));
}

double distance(point P, point P0, point P1)
{
	point v = P1 - P0;
	point w = P - P0;
	double c1 = w % v;
	if (c1 <= 0)
		return dst(P, P0);
	double c2 = v % v;
	if (c2 <= c1)
		return dst(P, P1);
	double b = c1 / c2;
	point Pb = P0 + b * v;
	return dst(P, Pb);
}

double area(double r)
{
	return pi * r * r;
}

int main()
{
#ifdef XXX
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif

	int n;
	cin >> n;
	point p;
	p.get();
	vector<point> v(n);
	for (int i = 0; i < n; i++)
	{
		v[i].get();
	}

	double minr = 1e200, maxr = -1e200;

	for (int i = 0; i < n; i++)
	{
		double r = dst(p, v[i]);
		minr = min(r, minr);
		maxr = max(r, maxr);
	}

	for (int i = 0; i < n; i++)
	{
		minr = min(minr, distance(p, v[i], v[(i + 1) % v.size()]));
	}

	double add = area(maxr);
	double sub = area(minr);

	printf("%.15lf", add - sub);

	return 0;
}