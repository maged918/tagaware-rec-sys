//Language: GNU C++11


#include <cstdio>

const int N = 110;
const int IT = 500000;

int a[N];
double p[N];
long double v[N];
int n;

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; ++i)
        scanf("%d", &a[i]);

    double u = 1.0;
    for (int i = 0; i < n; ++i)
    {
        p[i] = (double) a[i] / 100.0;
        v[i] = p[i];
        u *= v[i];
    }

    double pu = 0.0, s = 0.0;
    for (int it = n; it < IT; ++it)
    {
        int k = 0;
        long double bd = 0.0;
        for (int i = 0; i < n; ++i)
        {
            long double cd = (v[i] + (1.0 - v[i]) * p[i]) / v[i];
            if (cd > bd)
            {
                bd = cd;
                k = i;
            }
        }
        s += it * (u - pu);
        pu = u;
        u /= v[k];
        v[k] += (1.0 - v[k]) * p[k];
        u *= v[k];
    }

    printf("%.12lf\n", s);

    return 0;
}