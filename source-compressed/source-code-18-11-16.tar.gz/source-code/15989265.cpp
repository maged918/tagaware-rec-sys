//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
#define rep(i, x, y) for(int i = x; i < y; ++ i)
#define pb push_back
#define mk make_pair

typedef double R;
const R PI = acos(-1.);

//y = k x + b
//(y - py) ^ 2 + (x - px) ^ 2 = r ^ 2
//
//(k x + b - py) ^ 2 + (x - px) ^ 2 = r ^ 2
//k^2 x^2 + b^2 + py^2 + 2kb x - 2k py x - 2 py b +  x ^ 2 - 2 px x + px ^ 2 = r ^ 2
//
//(k^2+1)x + 2(k b- k py - px) x +b^2 + py^2 + px^2 + -2 py b - r ^ 2 = 0

bool calc(R a, R b, R c, R &x1, R &x2) { // ax^2 + bx + c = 0
	R delta = b * b - 4 * a * c;
	if (delta < 1e-8)
		return false;
	delta = sqrt(delta);
	x1 = (-b - delta) / a / 2;
	x2 = (-b + delta) / a / 2;
	return true;
}

R norm(R a) {
	while (a >= PI)
		a -= 2 * PI;
	while (a < -PI)
		a += 2 * PI;
	return a;
}

R getDist(R x, R y) {
	return sqrt(x * x + y * y);
}

struct Line { // 1000 y = kx + b
	int k, b;
	void read() {
		scanf("%d%d", &k, &b);
	}
	bool operator <(const Line &A) const {
		return k == A.k ? b < A.b : k < A.k;
	}
	bool intersect(const Line &A, R &x, R &y) const {
		if (k == A.k)
			return false;
		x = (b - A.b) / R(A.k - k);
		y = at(x);
		return true;
	}
	bool intersect(R x, R y, R r, R &ang1, R &ang2) const {
		R x1, x2, y1, y2;
		if (!calc(R(k) * k + 1e6, 2 * (R(k) * b - k * y - x * 1e3),
				R(b) * b + y * y + x * x - 2 * y * b - r * r * 1e6, x1, x2))
			return false;
		y1 = at(x1), y2 = at(x2);
		x /= 1e3, y /= 1e3;
		ang1 = norm(atan2(y1 - y, x1 - x));
		ang2 = norm(atan2(y2 - y, x2 - x));
		if (ang1 > ang2)
			swap(ang1, ang2);
		assert(abs(getDist(x - x1, y - y1) - r) < 1e-3);
		assert(abs(getDist(x - x2, y - y2) - r) < 1e-3);
		return true;
	}
	R at(R x) const {
		return (k * x + b) / 1000.;
	}
};

typedef pair<R, int> data;
const int N = 51234;
int n, m;
int x, y;
Line a[N];
R ans;
set<data> lines;
int p[N], c[N * 2];
R le[N], ri[N], v[N * 2];

bool cmp(const int i, const int j) {
	return le[i] < le[j];
}

bool solve(R r, bool flag = false, R real = -1.) {
	int cnt = 0, real_cnt = 0;
	int s = 0, t = 0;
	rep(i, 0, n)
	{
		if (a[i].intersect(x, y, r, le[i], ri[i]))
			v[t++] = le[i], v[t++] = ri[i], p[s++] = i;
	}
	if (s == 0)
		return false;
	sort(v, v + t);
	t = unique(v, v + t) - v;
	rep(i,0,t+1)
		c[i] = 0;
	sort(p, p + s, cmp);
	if (flag) {
		ans = 0;
		lines.clear();
	}
	rep(j,0,s)
	{
		int i = p[j];
		int u = lower_bound(v, v + t, le[i]) - v + 1;
		for (int k = u; k > 0; k -= k & -k)
			cnt -= c[k];
		int w = lower_bound(v, v + t, ri[i]) - v + 1;
		for (int k = w; k > 0; k -= k & -k)
			cnt += c[k];
		for (int k = w; k <= t; k += k & -k)
			++c[k];
		if (flag) {
			R xx, yy;
			set<data>::iterator it = lines.lower_bound(mk(le[i], i));
			for (; it != lines.end(); ++it) {
				if (it->first >= ri[i])
					break;
				a[i].intersect(a[it->second], xx, yy);
				ans += getDist(x / 1e3 - xx, y / 1e3 - yy);
				++real_cnt;
			}
			lines.insert(mk(ri[i], i));
		}
	}
//	printf("%d %d %lf\n",cnt,m, double(ans));
	if (flag)
		ans -= (real_cnt - m) * real;
	return cnt >= m;
}

int main() {
#ifdef LOCAL
	freopen("in","r",stdin);
#endif
	scanf("%d%d%d%d", &n, &x, &y, &m);
	rep(i, 0, n)
		a[i].read();
	double l = 0, r = 1e10;
	rep(_,0,80)
	{
		double mid = (l + r) / 2.0;
		if (solve(mid))
			r = mid;
		else
			l = mid;
	}
	if (l < 1e-8)
		ans = 0;
	else
		solve(l - 1e-8, true, l);
//	printf("%.9lf\n", double(r));
	printf("%.9lf\n", double(ans));
	return 0;
}
