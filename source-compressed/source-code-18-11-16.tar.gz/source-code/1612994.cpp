//Language: MS C++


#include<iostream>
using namespace std;
int n,m;

int main(){
    int x1,y1,x2,y2;
    while(cin>>n>>m>>x1>>y1>>x2>>y2){
        int dx = abs(x1-x2),dy = abs(y1-y2);
        if(dx>4 || dy>4 || dx+dy>6) puts("Second");
        else puts("First");
    }
    return 0;
}