//Language: GNU C++


#include <set>
#include <map>
#include <ctime>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
using namespace std;
int N;
int a[200010],b[200010],c[200010];
void work(int a[]){
	int len=0;
	int pos=0;
	for (int i=1;i<=N;i++)
		if (a[i]){
			a[++len]=a[i];
			if (a[i]==1)pos=len;
		}
	for (int i=1;i<=len;i++){
		c[i]=a[pos];
		pos++;
		if (pos>len)pos=1;
	}
	for (int i=1;i<=len;i++)a[i]=c[i];
}
int main(){
	scanf("%d",&N);
	for (int i=1;i<=N;i++)scanf("%d",&a[i]);
	work(a);
	for (int i=1;i<=N;i++)scanf("%d",&b[i]);
	work(b);
	for (int i=1;i<N;i++)
		if (a[i]!=b[i]){
			printf("NO\n");
			return 0;
		}
	printf("YES\n");
}