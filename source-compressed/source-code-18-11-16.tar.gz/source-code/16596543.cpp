//Language: GNU C++


#include<bits/stdc++.h>
#define N 200010
using namespace std;
int n,m,A[N];

#define each(u) for (int e=head[u],v=li[e].v;e;e=li[e].la,v=li[e].v)
int head[N],cnt_li,ok[N];
struct LI {int la,v;}li[N<<1];
void add(int a,int b) {li[++cnt_li]=(LI){head[a],b};head[a]=cnt_li;}

int s,Max,op,son[N],V[N],vis[N],up[N],fa[N],q[N];


int dfs0(int u) {
	vis[u]=1;
	each(u) if (v!=fa[u]) {
		if (ok[v]) {
			fa[v]=u;
			dfs0(v);
		} else s=u;
	}
	
}
int dfs1(int u) {
	son[u]=0;
	V[u]=1;
	int leave=1;
	each(u) if (v!=fa[u]) {
		son[u]++;
		leave=0;
		if (ok[v]) {
			fa[v]=u;
			dfs1(v);
		}
	}
	if (leave) q[++op]=u;

}
int down[N];
int dfs2(int u) {
	down[u]=V[u];
	each(u) if (v!=fa[u]&&ok[v]) {
		dfs2(v);
		Max=max(Max,down[u]+down[v]);
		down[u]=max(down[u],down[v]+V[u]);
	}
	Max=max(Max,down[u]);
}
int dfs3(int u) {
	Max=max(Max,up[u]+V[u]);
	int mx1=0,mx2=0;
	each(u) if (v!=fa[u]&&ok[v]) {
		if (down[v]>mx1) mx2=mx1,mx1=down[v];
		else if (down[v]>mx2) mx2=down[v];
	}
	
	each(u) if (v!=fa[u]&&ok[v]) {
		up[v]=max(up[u],down[v]==mx1? mx2:mx1)+V[u];
		dfs3(v);
	}
}

int OK(int L) {
	for (int i=1;i<=n;++i) ok[i] = A[i]>=L;
	memset(vis,0,sizeof(vis));
	Max=0;
	for (int i=1;i<=n;++i) if (ok[i]&&!vis[i]) {
		s=0;
		fa[i]=0,dfs0(i);
		if (!s) {Max=n;break;}
		
		op=0;
		fa[s]=0,dfs1(s);
		for (int cl=1;cl<=op;++cl) {
			int u=q[cl];
			ok[u]=0;
			V[fa[u]]+=V[u];
			Max=max(Max,V[fa[u]]);
			if (!(--son[fa[u]])) q[++op]=fa[u];
		}
		dfs2(s);
		up[s]=0,dfs3(s);
	}
	return Max>=m;
}

int main()
{
//	freopen("E.in","r",stdin);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i) scanf("%d",&A[i]);
	for (int i=1,a,b;i<n;++i) {
		scanf("%d%d",&a,&b);
		add(a,b),add(b,a);
	}
	int l=1,r=1000000+1;
	while (l<r) {
		int mid=(l+r)>>1;
		if (OK(mid)) l=mid+1;
		else r=mid;
	}
	
	printf("%d\n",l-1);
	return 0;
}
