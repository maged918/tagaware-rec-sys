//Language: GNU C++


/*
ID: duongthan4
LANG: C++
TASK: test
*/
#include <iostream>
#include <vector>
#include <stack>
#include <set>
#include <map>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <algorithm>
#include <bitset>
#define FOR(i,n) for (int i=0;i<n;i++)
#define FORF(i,a,n) for (int i=a;i<=n;i++)
#define FORR(i,n) for (int i=n-1;i>=0;i--)
#define RI(a) scanf("%d", &a);
#define RS(a) scanf("%s", &a);
#define RC(a) scanf("%c", &a);
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define all(a) a.begin(),a.end()
#define pii pair<int,int>
#define piii pair<pair<int,int>,int>
#define INFY 1000000000
#define MAXN 100000
using namespace std;
typedef long long LL;

int main(){
    int s, a, b, c;
    double x, y, z;
    RI(s);RI(a);RI(b);RI(c);
    if((a+b+c)==0){
        cout<<0<<" "<<0<<" "<<0;
    }
    else{
        x = (double)a*s/(a+b+c);
        y = (double)b*s/(a+b+c);
        z = (double)c*s/(a+b+c);
        printf("%.18lf %.18lf %.18lf", x, y, z);
    }    
    return 0;
}
