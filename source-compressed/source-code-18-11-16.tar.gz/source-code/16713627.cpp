//Language: GNU C++11


#pragma comment(linker, "/STACK:1024000000,1024000000")
#include <cstdio>
#include <cstring>
#include <string>
#include <cmath>
#include <ctime>
#include <iostream>
#include <vector>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <set>
#include <complex>
#include <map>
#include <bitset>
#define LL long long
#define ULL unsigned long long 
#define INF 1<<30 
#define INFL 0x3f3f3f3f3f3f3f3f
#define Mod 1000000007 
#define PII pair<int,int>
#define mk make_pair
#define mt make_tuple
#define Min(a,b) (a<b?a:b)
#define Max(a,b) (a<b?b:a) 
using namespace std; 
const double PI=acos(-1.0);
const double EPS=1e-10;

inline int read() {
    static char ch;
    bool sgn = false;
    while (ch = getchar(), ch < '0' || ch > '9') if (ch == '-') sgn = true;
    int res = ch - 48;
    while (ch = getchar(), ch >= '0' && ch <= '9') res = res * 10 + ch - 48;
    return sgn ? -res : res;
}

const int N=151;

int n,m,ans,dp[N][2][2][N][N],s[N][2][2][N][N];

void prepare(int i) {
	for(int l=0;l<2;l++)
		for(int r=0;r<2;r++)
			for(int j=1;j<=m;j++)
				for(int k=1;k<=m;k++) 
					(s[i][l][r][j][k]+=(s[i][l][r][j-1][k]+s[i][l][r][j][k-1]-s[i][l][r][j-1][k-1])%Mod+dp[i][l][r][j][k])%=Mod,
					(s[i][l][r][j][k]+=Mod)%=Mod;
}

int cal(int k,int l,int r,int x,int y,int xx,int yy) {
	return ((s[k][l][r][xx][yy]+s[k][l][r][x-1][y-1]-s[k][l][r][x-1][yy]-s[k][l][r][xx][y-1])%Mod+Mod)%Mod;	
}

int main() {
	n=read(),m=read();
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) {
			for(int k=j;k<=m;k++) {
				dp[i][0][0][j][k]=1;
				/*for(int jj=j;jj<=k;jj++) 
					for(int kk=j;kk<=k;kk++) 
						(dp[i][0][0][j][k]+=dp[i-1][0][0][jj][kk])%=Mod;*/ 	(dp[i][0][0][j][k]+=cal(i-1,0,0,j,j,k,k))%=Mod;
				
						
				ans+=dp[i][0][0][j][k]; ans%=Mod;
				////////////////////////////////
				/*for(int jj=j;jj<=k;jj++) 
					for(int kk=k;kk<=m;kk++)
						(dp[i][0][1][j][k]+=dp[i-1][0][1][jj][kk])%=Mod;*/  (dp[i][0][1][j][k]+=cal(i-1,0,1,j,k,k,m))%=Mod;
				
				/*for(int jj=j;jj<=k;jj++)
					for(int kk=k+1;kk<=m;kk++)
						(dp[i][0][1][j][k]+=dp[i-1][0][0][jj][kk])%=Mod;*/  (dp[i][0][1][j][k]+=cal(i-1,0,0,j,k+1,k,m))%=Mod;
				
				ans+=dp[i][0][1][j][k]; ans%=Mod;
				////////////////////////////////
				/*for(int jj=1;jj<=j;jj++) 
					for(int kk=j;kk<=k;kk++)
						(dp[i][1][0][j][k]+=dp[i-1][1][0][jj][kk])%=Mod;*/ (dp[i][1][0][j][k]+=cal(i-1,1,0,1,j,j,k))%=Mod;
				
				/*for(int jj=1;jj<=j-1;jj++)
					for(int kk=j;kk<=k;kk++)
						(dp[i][1][0][j][k]+=dp[i-1][0][0][jj][kk])%=Mod;*/ (dp[i][1][0][j][k]+=cal(i-1,0,0,1,j,j-1,k))%=Mod;
				
				ans+=dp[i][1][0][j][k]; ans%=Mod;
				////////////////////////////////
				/*for(int jj=1;jj<=j-1;jj++)
					for(int kk=k+1;kk<=m;kk++) 
						(dp[i][1][1][j][k]+=dp[i-1][0][0][jj][kk])%=Mod;*/ (dp[i][1][1][j][k]+=cal(i-1,0,0,1,k+1,j-1,m))%=Mod;
				
				/*for(int jj=1;jj<=j;jj++)
					for(int kk=k;kk<=m;kk++)
						(dp[i][1][1][j][k]+=dp[i-1][1][1][jj][kk])%=Mod;*/ (dp[i][1][1][j][k]+=cal(i-1,1,1,1,k,j,m))%=Mod;
						
				/*for(int jj=1;jj<=j;jj++)
					for(int kk=k+1;kk<=m;kk++)
						(dp[i][1][1][j][k]+=dp[i-1][1][0][jj][kk])%=Mod;*/ (dp[i][1][1][j][k]+=cal(i-1,1,0,1,k+1,j,m))%=Mod;
						
				/*for(int jj=1;jj<=j-1;jj++)		
					for(int kk=k;kk<=m;kk++)
						(dp[i][1][1][j][k]+=dp[i-1][0][1][jj][kk])%=Mod;*/ 	(dp[i][1][1][j][k]+=cal(i-1,0,1,1,k,j-1,m))%=Mod;
				
				ans+=dp[i][1][1][j][k]; ans%=Mod;
				/////////////////////////////
			}
		}
		prepare(i);
	}
	cout<<(ans+Mod)%Mod;
}