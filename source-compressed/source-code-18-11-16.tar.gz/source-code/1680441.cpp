//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <memory.h>
#define MAXN 110010
#define MAXM 440010
using namespace std;
int st[MAXN],ed[MAXN],up[MAXN],rank[MAXN],eng[MAXN],vol[MAXN],sou[MAXN];
int to[MAXM],next[MAXM],que[MAXM*4];
bool state[MAXN],isv[MAXN];
int noe,n,m,k,head,tail,s,t,i,x,y,l,r,mid,j;
void Add_Edge(int x,int y)
{
	to[++noe]=y;
	if(st[x]) next[ed[x]]=noe;
        else st[x]=noe;
	ed[x]=noe;
}
int Find(int x)
{
	if(up[x]==x) return x;
	return up[x]=Find(up[x]);
}
void Union(int x,int y)
{
	x=Find(x); y=Find(y); 
//	if(x==y) {return;}
//	if(rank[x]<rank[y]) swap(x,y);
	up[y]=x;
//	rank[x]=max(rank[x],rank[y]+1);
}
bool check(int q)
{
	int i,j,u,v;
	memset(que,0,sizeof(que));
	memset(eng,0,sizeof(eng));
	memset(sou,0,sizeof(sou));
//	memset(rank,0,sizeof(rank));
	memset(state,0,sizeof(state));
	for(i=1;i<=n;i++) up[i]=i;
	for(i=1;i<=k;i++)
	{
		que[i]=vol[i];
//		eng[vol[i]]=q;
		sou[vol[i]]=vol[i];
		state[vol[i]]=1;
	}
	head=0; tail=k; sou[t]=t; eng[t]=0; state[t]=1;
	while(head<tail)
	{
		u=que[++head];
                if(eng[u] == q) break;
		for(v=to[j=st[u]];j;v=to[j=next[j]])
			if(state[v])
			{
				if(eng[u]+eng[v] < q) Union(sou[u],sou[v]);
//				if((v==t) && (eng[u]>0)) Union(sou[u],sou[v]);
			}
			else
			{
				state[v]=1;
				eng[v]=eng[u]+1;
				sou[v]=sou[u];
				que[++tail]=v;
			}
	}
//	memset(state,0,sizeof(state));
//	head=0; tail=1; que[1]=t; eng[t]=q; state[t]=1;
//	while(head<tail)
//	{
//		u=que[++head];
//		for(v=to[j=st[u]];j;v=to[j=next[j]])
//			if(!state[v])
//			{
//				state[v]=1;
//				eng[v]=eng[u]-1;
//				que[++tail]=v;
//				if(isv[v] && (eng[u]>0)) Union(t,v);
//			}
//	}
	if(state[s] && state[t] && Find(s)==Find(t)) return 1; else return 0;
}
int main()
{
//    freopen("in","r",stdin);
	scanf("%d%d%d",&n,&m,&k);
	for(i=1;i<=k;i++) 
		scanf("%d",&vol[i]);
	for(i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		Add_Edge(x,y);
		Add_Edge(y,x);
	}
	scanf("%d%d",&s,&t);
//	for(i=1;i<=k;i++)
//		if(vol[i]==t)
//		{
//			for(j=i;j<k;j++) vol[j]=vol[j+1];
//			k--;
//		}
//	for(i=1;i<=k;i++) isv[vol[i]]=1;
	l=1; r=n;
	while(r>=l)
	{
            	mid=(l+r)>>1;
		if(check(mid)) r=mid-1;
                else l=mid+1;
	}
	if(l>n) l=-1;
	printf("%d\n",l);
	//system("pause");
	return 0;
}