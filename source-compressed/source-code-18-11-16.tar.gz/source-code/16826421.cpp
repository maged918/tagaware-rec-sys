//Language: GNU C++11


#include <iostream>
#include <cstdio>
#include <ctime>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
using namespace std;

const int N = 57;
const int M = 507;
long long cap[N][N];
long long flo[N];
int unde[N];
int ea[M];
int eb[M];
long long ec[M];
int odl[N];
int inf = 1e9;
int n, m, k;

long long flow() {
	long long wynik = 0;
	while(1) {
		for(int i = 0; i <= n; ++i) odl[i] = inf;
		vector <int> q;
		q.push_back(0);
		odl[0] = 0;
		flo[0] = inf;
		for(int i = 0; i < q.size(); ++i) {
			int v = q[i];
			for(int j = 1; j <= n; ++j) {
				if(cap[v][j] > 0 && odl[v] + 1 < odl[j]) {
					odl[j] = odl[v] + 1;
					flo[j] = min(flo[v], cap[v][j]);
					unde[j] = v;
					q.push_back(j);
				}
			}
		}

		int x = n;
		long long ile = flo[x];
		if(odl[x] == inf) return wynik;
		while(x != 0) {
			int v = unde[x];
			cap[v][x] -= ile;
			cap[x][v] += ile;
			x = v;
		}
		wynik += ile;
	}
}

bool check(double s) {
	for(int i = 0; i <= n; ++i) for(int j = 0; j <= n; ++j) cap[i][j] = 0;
	for(int i = 1; i <= m; ++i) {
		double ww = double (ec[i]) / s;
		if(ww > k + 1.0) ww = k + 1.0;
		long long xx = int (ww);
		cap[ea[i]][eb[i]] = xx;
	}
	cap[0][1] = k;
	return flow() == k;
}

int main() {
	ios_base::sync_with_stdio(0);
	cin >> n >> m >> k;
	for(int i = 1; i <= m; ++i) cin >> ea[i] >> eb[i] >> ec[i];

	double pp = 1e-6;
	double kk = 1000000.0;
	double wynik = 0;
	int it = 0;
	while(pp + 1e-11 < kk && it < 55) {
		it++;
		double s = (pp + kk) * 0.5;
		if(check(s)) {
			//cout << "ok dla " << s << endl;
			wynik = max(wynik, s);
			pp = s;
		}
		else {
			//cout << "nie ok dla " << s << endl;
			kk = s;
		}
	}

	wynik *= double (k);
	cout.precision(15);
	cout << fixed;
	cout << wynik << endl;
	//system("pause");
	return 0;
}