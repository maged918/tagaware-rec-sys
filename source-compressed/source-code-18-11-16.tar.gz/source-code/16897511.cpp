//Language: GNU C++11


#include <bits/stdc++.h>
#define SZ(x) (int)x.size()
typedef long long ll;
const int SZ=3e5+5;
using namespace std;

int n,m,k;
map< pair<int,int>,bool > NotConnect;
set<int> available_Node;

void DFS(int x)
{
    vector<int> deleted_node;
    for(auto i:available_Node)
        if(NotConnect[{i,x}]==0)
            deleted_node.push_back(i);

    for(int i=0;i<SZ(deleted_node);i++)
        available_Node.erase(deleted_node[i]);
    for(int i=0;i<SZ(deleted_node);i++)
        DFS(deleted_node[i]);
}

int main()
{
    scanf("%d%d%d",&n,&m,&k);
    for(int i=2;i<=n;i++)
        available_Node.insert(i);
    
    int num_connect=n-1;
    for(int i=0;i<m;i++)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        NotConnect[{x,y}]=1;
        NotConnect[{y,x}]=1;
        num_connect-=(x==1||y==1);
    }
    
    int vis=0;
    for(int i=2;i<=n;i++)
    {
        if( NotConnect[{1,i}]==0 && 
            available_Node.find(i)!=available_Node.end() )
            DFS(i), vis++;
    }
    
    if(SZ(available_Node)>0 || vis>k || num_connect<k)
        cout<<"impossible";
    else
        cout<<"possible";
}