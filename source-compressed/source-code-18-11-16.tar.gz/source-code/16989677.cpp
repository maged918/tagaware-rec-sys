//Language: GNU C++


#include<stdio.h>
#include<string.h>
int a[1010];
int main(){
    int n;
    while(scanf("%d",&n)!=EOF){
         int k=0;
         memset(a,0,sizeof(a));
         while(n--){
             int x;
             scanf("%d",&x);
             a[x]=1;}
         for(int i=1;i<1000;i++)
             if(a[i]==1&&a[i+1]==1&&a[i+2]==1){k=1;break;}
         if(k) printf("YES\n");
         else printf("NO\n");
     }
}
    	 	 			 		 	 		 		  		 		