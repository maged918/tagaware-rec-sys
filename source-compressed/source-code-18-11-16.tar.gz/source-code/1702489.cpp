//Language: GNU C++


#include <stdio.h>
#include <cmath>
#include <string>
#include <cstring>

using namespace std;
const int maxn=100010;
int n,a[maxn],b[maxn],ans[maxn];
int main(){
    int i,x;
    while(~scanf("%d",&n)){
        printf("1");
        int head=2,tail=n;
        for(i=2;i<=n;i++){
            if(i%2==0)
            printf(" %d",tail--);
            else printf(" %d",head++);
        }
        putchar(10);
    }
    getchar();getchar();
    return 0;
}
