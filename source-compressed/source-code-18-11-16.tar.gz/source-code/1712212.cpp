//Language: GNU C++


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<queue>
#include<map>
#include<algorithm>
using namespace std;
typedef long long ll;

int dp[1<<22];
int a[1000010];
int main(){
	int n;
	int mask=(1<<22)-1;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		dp[a[i]]=a[i];
	}
	for(int i=0;i<=mask;i++){
		for(int j=i;!dp[i]&&j;j&=j-1){
			dp[i]=dp[i^(j&-j)];
		}
	}
	for(int i=0;i<n;i++){
		if(dp[mask^a[i]])
			printf("%d ",dp[mask^a[i]]);
		else
			printf("-1 ");
	}
}
