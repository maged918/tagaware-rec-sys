//Language: GNU C++11


#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<stdio.h>
#include<cassert>
#include<set>
#include<vector>
using namespace std;
int f[20][401000],lg[410000],n,num_q;
const int inf=1e9;
struct query
{
	int r1,c1,r2,c2,id;
	bool operator <(const query &temp)const
	{
	    return r2<temp.r2;
	}
};
bool cmp(query a,query b)
{
	return a.r1<b.r1;
}
query qy[410000];
int vs[410000],a[410000],stk[410000],ans[410000],top,vl[410000],sk[410000],tk;
int lb_bound(int left,int right,int stk[],int c2,int pos)
{
	int mid;
	while(left<=right)
	{
		mid=(left+right)>>1;
	    if(a[stk[mid]]>=c2&&stk[mid]>=pos)
	       right=mid-1;
        else
           left=mid+1;
	}
	return left;
}
int lb(int left,int right,int stk[],int c2)
{
	int mid;
	while(left<=right)
	{
		mid=(left+right)>>1;
		if(a[stk[mid]]<=c2)
		   left=mid+1;
        else
           right=mid-1;
	}
	return right;
}
void solve()
{
	int i,j,s,p,q,pj,id,ip,wl;
	pj=-1;
	top=0;
	for(i=0;i<num_q;i++)
	{
		if(qy[i].r1>qy[i].r2)
		   continue;
		for(j=pj+1;j<=qy[i].r2;j++)
		{
			while(top&&a[stk[top-1]]>=a[j])
			   top--;
            stk[top++]=j;
		}
		id=lb_bound(0,top-1,stk,qy[i].c2,qy[i].r1);
		int min_value=inf;
		ip=lg[qy[i].r2-qy[i].r1+1];
		assert(qy[i].r1+(1<<ip)<=qy[i].r2+1);
		vl[qy[i].id]=min(a[f[ip][qy[i].r2+1-(1<<ip)]],a[f[ip][qy[i].r1]]);
		vs[qy[i].id]=vl[qy[i].id];
		vl[qy[i].id]=min(vl[qy[i].id],qy[i].c1);
		if(id<top)
		{
			min_value=a[stk[id]]-qy[i].c2;
			if(vl[qy[i].id]<a[stk[id]])
			   min_value++;
		}
		id--;
		if(id>=0&&stk[id]>=qy[i].r1)
		{
			 wl=qy[i].c2-a[stk[id]];
			 if(vl[qy[i].id]<a[stk[id]])
			     wl++;
             if(min_value>wl)
                min_value=wl;
		}
		if(min_value>(qy[i].c1!=0)+abs(qy[i].c2))
		    min_value=(qy[i].c1!=0)+abs(qy[i].c2);
        if(vl[qy[i].id]>=qy[i].c1)
        {
        	if(min_value>abs(qy[i].c1-qy[i].c2))
        	   min_value=abs(qy[i].c1-qy[i].c2);
        }
		ans[qy[i].id]=min(ans[qy[i].id],abs(qy[i].r1-qy[i].r2)+min_value);
        pj=qy[i].r2;
	}
	top=0;
	pj=n;
	for(i=num_q-1;i>=0;i--)
	{
	    if(qy[i].r1>qy[i].r2)
	       continue;
	    for(j=pj-1;j>=qy[i].r2;j--)
	    {
    		while(top>0&&a[stk[top-1]]>=a[j])
    		   top--;
 		    stk[top++]=j;
    	}
    	id=lb(0,top-1,stk,qy[i].c2);
    	int min_value=inf;
    	if(id>=0)
    	{
	    	min_value=qy[i].r2-qy[i].r1+2*(stk[id]-qy[i].r2)+qy[i].c2-a[stk[id]];
	    	if(vl[qy[i].id]<a[stk[id]])
	    	    min_value++;
	    }
	    if(ans[qy[i].id]>min_value)
	       ans[qy[i].id]=min_value;
		pj=qy[i].r2;   
	}
	top=0;
	pj=n;
	for(i=num_q-1;i>=0;i--)
	{
		if(qy[i].r1>qy[i].r2)
		    continue;
        for(j=pj-1;j>=qy[i].r2;j--)
        {
        	 while(top>0&&a[stk[top-1]]+2*stk[top-1]>=a[j]+2*j)
        	     top--;
    	     stk[top++]=j;
        }
        id=lb_bound(0,top-1,stk,qy[i].c2,qy[i].r2);
        int min_value=inf;
        if(id<top)
        {
        	min_value=qy[i].r2-qy[i].r1+2*(stk[id]-qy[i].r2)+a[stk[id]]-qy[i].c2;
        	if(vl[qy[i].id]<a[stk[id]])
        	    min_value++;
    	    if(ans[qy[i].id]>min_value)
    	       ans[qy[i].id]=min_value;
        }
        pj=qy[i].r2;
	}
	sort(qy,qy+num_q,cmp);
	top=0;
	pj=-1;
	for(i=0;i<num_q;i++)
	{
		if(qy[i].r1>qy[i].r2)
		   continue;
        for(j=pj+1;j<=qy[i].r1;j++)
        {
        	while(top>0&&a[stk[top-1]]>=a[j])
        	   top--;
    	    stk[top++]=j;
        }
        int min_value;
        id=lb(0,top-1,stk,min(qy[i].c2,vs[qy[i].id]));
        if(id>=0)
        { 
            min_value=2*(qy[i].r1-stk[id])+qy[i].r2-qy[i].r1+qy[i].c2-a[stk[id]];
            if(qy[i].c1<a[stk[id]])
               min_value++;
		    if(ans[qy[i].id]>min_value)
               ans[qy[i].id]=min_value;
		}
        pj=qy[i].r1;
	}
	top=tk=0;
	pj=-1;
	for(i=0;i<num_q;i++)
	{
		if(qy[i].r1>qy[i].r2)
		   continue;
        for(j=pj+1;j<=qy[i].r1;j++)
        {
        	while(top>0&&a[stk[top-1]]-2*stk[top-1]>=a[j]-2*j)
        	   top--;
    	    stk[top++]=j;
    	    while(tk>0&&a[sk[tk-1]]>=a[j])
    	        tk--;
	        sk[tk++]=j;
        }
        id=lb_bound(0,top-1,stk,qy[i].c2,-1);
        int min_value;
        if(id<top&&a[stk[id]]<=vs[qy[i].id])
        {
        	min_value=2*(qy[i].r1-stk[id])+qy[i].r2-qy[i].r1+a[stk[id]]-qy[i].c2;
        	if(qy[i].c1<a[stk[id]])
        	   min_value++;
       	    if(ans[qy[i].id]>min_value)
               ans[qy[i].id]=min_value;
        }
        else
        {
             ip=lb(0,tk-1,sk,vs[qy[i].id]-1);
             for(j=ip;j>=0&&a[sk[j]]>=qy[i].c2;j--)
             {
             	 min_value=2*(qy[i].r1-sk[j])+qy[i].r2-qy[i].r1+a[sk[j]]-qy[i].c2;
             	 if(qy[i].c1<a[stk[j]])
             	    min_value++;
             	 //assert(qy[i].id!=210482);
             	 if(ans[qy[i].id]>min_value)
             	    ans[qy[i].id]=min_value;
             }
        }
        pj=qy[i].r1;
	}
}
void pre_pare()
{
	int i,j,s,p,q,k;
	for(i=0;i<n;i++)
	   f[0][i]=i;
    for(k=1;(1<<k)<=n;k++)
    	for(i=0;i+(1<<k)<=n;i++)
    	{
    		f[k][i]=f[k-1][i];
	        if(a[f[k-1][i]]>a[f[k-1][i+(1<<(k-1))]])
		       	f[k][i]=f[k-1][i+(1<<(k-1))];
	    }
    
}
int main()
{
	int i,j,s,p,q;
  // n=1000;//
   	scanf("%d",&n);
	lg[1]=0;
	for(i=2;i<=n;i++)
	   lg[i]=lg[i/2]+1;
	for(i=0;i<n;i++)
	   scanf("%d",&a[i]);
    pre_pare();
   // num_q=1000;//
   scanf("%d",&num_q);
    for(i=0;i<num_q;i++)
    {
    	// qy[i].r1=rand()%n+1;
    	// qy[i].r2=rand()%n+1;
    	// qy[i].c1=rand()%a[qy[i].r1-1]+1;
    	// qy[i].c2=rand()%a[qy[i].r2-1]+1;
        scanf("%d%d%d%d",&qy[i].r1,&qy[i].c1,&qy[i].r2,&qy[i].c2);
        qy[i].id=i;
		qy[i].r1--;
        qy[i].r2--;
    }
    sort(qy,qy+num_q);
    for(i=0;i<num_q;i++)
        ans[i]=inf;
    solve();
    for(i=0;i<n/2;i++)
       swap(a[i],a[n-1-i]);
    pre_pare();
    //for(i=0;i<n;i++)
    //   printf("%d ",a[i]);
    //printf("\n");
    for(i=0;i<num_q;i++)
    {
    	qy[i].r1=n-1-qy[i].r1;
    	qy[i].r2=n-1-qy[i].r2;
    //	if(qy[i].r1<qy[i].r2)
    //	printf("%d %d\n",qy[i].r1,qy[i].r2);
    //	printf("r1=%d,c1=%d,r2=%d,c2=%d\n",qy[i].r1,qy[i].c1,qy[i].r2,qy[i].c2);
    }
    sort(qy,qy+num_q);
    solve();
    for(i=0;i<num_q;i++)
       printf("%d\n",ans[i]);
	return 0;
}
/*
9
1 3 5 3 1 3 5 3 1
1
7 3 3 3

*/