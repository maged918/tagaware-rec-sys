//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

#define fru(j,n) for(int j=0; j<(n); ++j)
#define tr(it,v) for(typeof((v).begin()) it=(v).begin(); it!=(v).end(); ++it)
#define x first
#define y second
#define pb push_back
#define ALL(V) (V).begin(),(V).end()
#if 1
	#define DEB printf
#else
	#define DEB(...)
#endif

typedef long long ll;
typedef double D;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<int> vi;

const int mod = 1000000007;
const int MAXN = 2006;//10^6

char str[MAXN];
int Pw[MAXN],Pm[MAXN];
int DP[MAXN][MAXN],S[MAXN][MAXN];
void solve() {
	int n,k;
	scanf("%d%d",&n,&k);
	scanf("%s",str);
	fru(i,n)Pw[i]='z'-str[i];
	fru(i,n)Pm[i]=str[i]-'a';
	DP[n][0]=1;
	for(int i=n-1;i>=0;i--)
	fru(h,k+1){
		//fill DP[i][h]
		S[i][h]=S[i+1][h]+1LL*DP[i+1][h]*Pm[i]%mod;
		if(S[i][h]>=mod)S[i][h]-=mod;
		DP[i][h]+=S[i][h];
		if(DP[i][h]>=mod)DP[i][h]-=mod;
		if(h==0)DP[i][h]++;
		if(DP[i][h]>=mod)DP[i][h]-=mod;
		int lastj=-1;
		for(int j=n-i-1;j>=0;j--){
			int u=(j+1)*(n-i-j);
			if(u>h){
				lastj=j;
				break;
			}
			DP[i][h]+=1LL*DP[i+j+1][h-u]*Pw[i+j]%mod;
			if(DP[i][h]>=mod)DP[i][h]-=mod;
		}
		for(int j=0;j+i<n && j<lastj;j++){
			int u=(j+1)*(n-i-j);
			if(u>h){break;}
			DP[i][h]+=1LL*DP[i+j+1][h-u]*Pw[i+j]%mod;
			if(DP[i][h]>=mod)DP[i][h]-=mod;
		}
	}	
	printf("%d\n",DP[0][k]);
}

int main(){
	//freopen("input.in", "r", stdin);
	//freopen("output.out", "w", stdout);
	int t=1;//scanf("%d",&t);
	fru(i,t) solve();
	return 0;
}
