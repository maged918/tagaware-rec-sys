//Language: GNU C++


#include <iostream>
#include <cstdio>
using namespace std;
int main(){
	int n,k;
	cin>>n>>k;
	int x1,x2,x3,x4;
	int mini=-1;
	for(x1=0;x1<=n;x1++){
		for(x2=0;x2<=n;x2++){
			for(x3=0;x3<=n;x3++){
				int i=(k-3*x1-4*x2-5*x3);
				if(((i%2)==0)&&(i>=0)){
					x4=(i/2);
					if(((mini==-1)||(mini>x4))&&((x1+x2+x3+x4)==n)){
						mini=x4;
					}
				}
			}
		}
	}
	if(mini==-1){
		cout<<"0\n";
	}
	else{
		cout<<mini<<"\n";
	}
	return(0);
}	
