//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int main(){
    int operacoes=0;
    char *num=new char[1000000];
    num[0]='0';
    cin>>num+1;
    int tam=0;
    while(num[tam]!='\0')
        tam++;
    tam--;
    
    int carry=0;
    for(int i=tam;i>=1;){
        if(i==1 && num[0]=='0' && carry==0){operacoes; break;}
        
        if(carry==0){
           if(num[i]=='0'){ operacoes++; i--;}
           else{carry=1; operacoes+=2; i--;}
        }
        else{
            if(num[i]=='0'){num[i]='1'; carry=0;}
            else{i--;operacoes++; carry=1;}
        }
    }
    cout<<operacoes;
    return 0;
    
}