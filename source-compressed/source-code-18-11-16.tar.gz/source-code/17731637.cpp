//Language: GNU C++11


#pragma comment(linker, "/STACK:64000000")
#include <iostream>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cassert>
#include <ctime>
#include <sstream>
#include <algorithm>
#include <functional>
#include <numeric>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>

using namespace std;

#define f first
#define s second
#define pb push_back
#define mp make_pair
#define ll long long
#define pii pair < int, int >
#define pll pair < long long, long long>
#define ull unsigned long long
#define y1 stupid_cmath
#define left stupid_left
#define right stupid_right
#define vi vector <int>
#define sz(a) (int)a.size()
#define forit(it, s) for(__typeof(s.begin()) it = s.begin(); it != s.end(); it++)
#define all(a) a.begin(), a.end()
#define sqr(x) ((x) * (x))

const int inf = (int)1e9;
const int mod = inf + 7;
const double eps = 1e-9;
const double pi = acos(-1.0);

int n, m, p;
string s, T;
int t[5 * 500500], col[5 * 500500];
int nxt[500500], pre[500500];

void build(int v, int tl, int tr) {
    if (tl == tr) {
        t[v] = 1;
    } else {
        int mid = (tl + tr) >> 1;
        build(2 * v, tl, mid);
        build(2 * v + 1, mid + 1, tr);
        t[v] = t[2 * v] + t[2 * v + 1];
    }
}

void update(int v, int tl, int tr, int l, int r) {
    if (r < tl || l > tr) return;
    if (l <= tl && tr <= r) {
        col[v] = 1;
        t[v] = 0;
        return;
    }
    if (col[v]) {
        t[v] = 0;
        return;
    }
    int mid = (tl + tr) >> 1;
    update(2 * v, tl, mid, l, r);
    update(2 * v + 1, mid + 1, tr, l, r);
    t[v] = t[2 * v] + t[2 * v + 1];
}

int find_kth_right(int v, int tl, int tr, int k) {
    if (col[v] || !t[v]) return -1;
    if (tl == tr) return tl;
    int mid = (tl + tr) >> 1;
    if (t[2 * v + 1] >= k) return find_kth_right(2 * v + 1, mid + 1, tr, k);
    return find_kth_right(2 * v, tl, mid, k - t[2 * v + 1]);
}

int get(int v, int tl, int tr, int l, int r) {
    if (col[v]) return 0;
    if (r < tl || l > tr) return 0;
    if (l <= tl && tr <= r) return t[v];
    int mid = (tl + tr) >> 1;
    return get(2 * v, tl, mid, l, r) + get(2 * v + 1, mid + 1, tr, l, r);
}

void doIt(char c) {
    if (c == 'L') {
        int cur = get(1, 0, n - 1, p, n - 1);
        p = find_kth_right(1, 0, n - 1, cur + 1);
    } else if (c == 'R') {
        int cur = get(1, 0, n - 1, p, n - 1);
        p = find_kth_right(1, 0, n - 1, cur - 1);
    } else {
        if (nxt[p] != -1) {
            update(1, 0, n - 1, p, nxt[p]);
        } else {
            update(1, 0, n - 1, pre[p], p);
        }
        int cur = get(1, 0, n - 1, p, n - 1);
        if (cur == 0) p = find_kth_right(1, 0, n - 1, 1);
        else p = find_kth_right(1, 0, n - 1, cur);
    }
}

int main(){
    
    scanf("%d %d %d\n", &n, &m, &p);
    p--;
    getline(cin, s);
    getline(cin, T);
    
    build(1, 0, n - 1);
    
    stack <int> st;
    
    memset(nxt, -1, sizeof nxt);
    memset(pre, -1, sizeof pre);
    for (int i = 0; i < n; i++) {
        if (s[i] == '(') st.push(i);
        else {
            nxt[st.top()] = i;
            pre[i] = st.top();
            st.pop();
        }
    }
    
    for (int i = 0; i < m; i++) {
        char c = T[i];
        doIt(c);
    }
    
    for (int i = 0; i < n; i++) {
        if (get(1, 0, n - 1, i, i)) {
            printf("%c", s[i]);
        }
    }
    printf("\n");
    
    return 0;
}
