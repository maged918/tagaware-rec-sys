//Language: GNU C++11


#include <algorithm>
#include <iostream>
#include <unordered_map>
#include <utility>

using namespace std;

pair<int, int> movie[200000];

int main() {
	cin.tie(NULL);
	ios::sync_with_stdio(false);

	int n, m;
	unordered_map<int, int> cnt(400000);

	cin >> n;
	for (int i = 0; i < n; i++) {
		int a;
		cin >> a;
		cnt[a]++;
	}
	cin >> m;
	for (int i = 0; i < m; i++) {
		int b;
		cin >> b;
		movie[i].first = cnt[b];
	}
	for (int i = 0; i < m; i++) {
		int c;
		cin >> c;
		movie[i].second = cnt[c];
	}

	cout << max_element(movie, movie + m) - movie + 1 << endl;
    cerr << cnt.bucket_count() << endl;

	return 0;
}