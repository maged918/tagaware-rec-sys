//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
const int maxn=100000+10;
typedef double DB;
DB p[maxn];
int x[maxn],y[maxn];
int main()
{
    p[0]=1;
    for(int i=1;i<maxn;i++) p[i]=p[i-1]*0.5;
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++) scanf("%d%d",x+i,y+i);
    DB ans=0;
    for(int i=0;i<n;i++)
        for(int j=(i+1)%n,k=2;j!=i&&k<=60;j=(j+1)%n,k++)
            ans+=(p[k]-p[n])*(1.0*x[i]*y[j]-1.0*x[j]*y[i]-__gcd(abs(x[j]-x[i]),abs(y[j]-y[i])));
    ans=(ans*0.5)/(1.0-p[n]*(1+n+1.0*n*(n-1)/2));
    printf("%.9f\n",ans+1);
    return 0;
}
