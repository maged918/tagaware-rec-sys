//Language: GNU C++


#include <bits/stdc++.h>
#define debug(x) cout << #x << ": " << x << endl;
using namespace std;


long long d[111000];
long long Sd[111000];
long long aa[111000];
long long S[111000];
long long dp[110][111000];

struct line
{
	long long m,b;
	line() {}
	line(long long _m, long long _b): m(_m), b(_b) {}
};

line H[111000];
int sz = 0;
int pos = 0;


inline long long ff(int idx, long long cur)
{
	return H[idx].m * cur + H[idx].b;
}

long long get_value(long long cur)
{
	while( (pos + 1 < sz) && ff(pos, cur) > ff(pos + 1, cur) ) ++pos;
	return ff(pos, cur);
}

int check(line l0, line l1, line l)
{	
	if(l1.m == l.m)
	{	
		//Caso en que b[i] == b[i+1] , las rectas son paralelas
		if(l.b < l1.b) return 0;
		else return 2;
		return l.b < l1.b; // borro si la que inserto es menor en b, porque busco minimo
		// Si busco maximo, l.b > l1.b en este caso
	}
	double x1 = double(l1.b - l0.b)/(l0.m - l1.m);
	double x2 = double(l1.b - l.b)/(l.m - l1.m);
	return x1 >= x2 ? 0 : 1;
}

void insert(line l)
{

	while(sz >= 2 && !check(H[sz-2], H[sz-1], l))
	{
	   if(pos == sz - 1) pos--;
	   --sz;
	}
	if(sz < 2 || check(H[sz-2], H[sz-1], l) == 1) H[sz++] = l;
}

int main()
{
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	int n,m,p; cin >> n >> m >> p;
	int x,y;
	for(int i = 1; i < n; ++i) cin >> d[i];
	for(int i = 1; i < n; ++i) Sd[i] = Sd[i-1] + d[i];
	int cnt = 1;
	for(int i = 0; i < m; ++i)
	{
		cin >> x >> y;
		aa[cnt++] = y - Sd[x-1];		
	}
	sort(aa + 1, aa + m + 1);
	for(int i = 1; i<= m; ++i) S[i] = S[i-1] + aa[i];
	for(int i = 1; i<= m; ++i) dp[1][i] = (m - i + 1) * aa[m] + S[i-1] - S[m];
	for(int k = 2; k <= p; ++k)
	{
		sz = 0;
		pos = 0;
		for(int i = m; i >= 1; --i)
		{
			dp[k][i] = get_value(-i) + S[i-1];
			insert(line(aa[i-1], dp[k-1][i] + i*aa[i-1] - S[i-1]));
		}
	}
	cout << dp[p][1] << endl;
	return 0;
}













