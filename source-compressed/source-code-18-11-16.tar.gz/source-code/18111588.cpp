//Language: GNU C++11


#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
const int maxn=1000100;
const int INF=1e9+10;

int n,p;
int a[maxn];
double C[60][60];
double dp[60][60][60];

void InitC()
{
    C[0][0]=1;
    for(int i=1;i<=55;i++){
        for(int j=0;j<=i;j++){
            if(j==0) C[i][j]=C[i-1][j];
            else C[i][j]=C[i-1][j-1]+C[i-1][j];
        }
    }
}

void debug()
{
    cout<<dp[3][2][3]<<endl;
    cout<<dp[2][2][3]<<endl;
    cout<<dp[1][1][1]<<endl;
    cout<<dp[0][0][0]<<endl;
}

double DP(int used)
{
    for(int j=0;j<=n;j++) for(int k=0;k<=p;k++) dp[0][j][p]=0;
    dp[0][0][0]=1;
    for(int i=1;i<=n;i++){
        for(int j=0;j<=i;j++){
            for(int k=0;k<=p;k++){
                if(i==used) dp[i][j][k]=dp[i-1][j][k];
                else{
                    dp[i][j][k]=dp[i-1][j][k];
                    if(j>=1&&k>=a[i]) dp[i][j][k]+=dp[i-1][j-1][k-a[i]];
                }
            }
        }
    }
    //if(used==3) debug();
    double res=0;
    for(int L=p+1-a[used];L<=p;L++){
        for(int k=0;k<=n-1;k++){
            res+=dp[n][k][L]*k/C[n-1][k];
        }
    }
    return res/n;
}

void solve()
{
    double res=0;
    for(int i=1;i<=n;i++) res+=DP(i);
    printf("%.10f\n",res);
}

int main()
{
    //freopen("in.txt","r",stdin);
    InitC();
    while(cin>>n){
        int sum=0;
        for(int i=1;i<=n;i++) scanf("%d",&a[i]),sum+=a[i];
        cin>>p;
        if(sum<=p){
            printf("%d.0000000000",n);
            continue;
        }
        solve();
    }
    return 0;
}
