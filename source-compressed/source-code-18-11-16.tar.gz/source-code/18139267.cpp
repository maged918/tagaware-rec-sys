//Language: GNU C++11


/*
reality, be rent!
synapse, break!
Van!shment Th!s World !!
*/
#include <bits/stdc++.h>
using namespace std;

const int MN = 1010101;

int root[MN], t[MN], num[MN], X;
bool vst[MN];
vector<vector<pair<int, int> > > row, col;
vector<int> adj[MN];

void dfs(int u) {
	vst[u] = true;

	for (auto &x : adj[u]) if (!vst[x]) dfs(x);

	t[X++] = u;
}

int find_root(int u) {
	if (root[u] == u) return u;
	return root[u] = find_root(root[u]);
}

void join(int u, int v) {
	u = find_root(u), v = find_root(v);
	root[u] = v;
}

int main() {
	int n, m, i, j;
	scanf("%d %d", &n, &m);

	row.resize(n, vector<pair<int, int> > (m));
	col.resize(m, vector<pair<int, int> > (n));

	for (i = 0; i < n; ++i) {
		for (j = 0; j < m; ++j) {
			int x;
			scanf("%d", &x);
			row[i][j] = {x, j};
			col[j][i] = {x, i};
		}
	}

	for (i = 0; i < n; ++i) sort(row[i].rbegin(), row[i].rend());
	for (i = 0; i < m; ++i) sort(col[i].rbegin(), col[i].rend());

	for (i = 0; i < n * m; ++i) root[i] = i;

	for (i = 0; i < n; ++i) {
		for (j = 0; j < m - 1; ++j) {
			if (row[i][j].first == row[i][j + 1].first) {
				join(i * m + row[i][j].second, i * m + row[i][j + 1].second);
			}
		}
	}

	for (i = 0; i < m; ++i) {
		for (j = 0; j < n - 1; ++j) {
			if (col[i][j].first == col[i][j + 1].first) {
				join(col[i][j].second * m + i, col[i][j + 1].second * m + i);
			}
		}
	}

	for (i = 0; i < n; ++i) {
		for (j = 0; j < m - 1; ++j) {
			int u = find_root(i * m + row[i][j].second), v = find_root(i * m + row[i][j + 1].second);
			if (u == v) continue;
			adj[u].push_back(v);
		}
	}

	for (i = 0; i < m; ++i) {
		for (j = 0; j < n - 1; ++j) {
			int u = find_root(col[i][j].second * m + i), v = find_root(col[i][j + 1].second * m + i);
			if (u == v) continue;
			adj[u].push_back(v);
		}
	}

	for (i = 0; i < n * m; ++i) {
		int u = find_root(i);
		if (!vst[u]) dfs(u);
	}

	for (i = 0; i < X; ++i) {
		int maxi = 0;
		for (auto &x : adj[t[i]]) maxi = max(maxi, num[x]);

		num[t[i]] = maxi + 1;
	}

	for (i = 0; i < n; ++i) {
		for (j = 0; j < m; ++j) {
			int u = find_root(i * m + j);
			if (j) putchar(' ');
			printf("%d", num[u]);
		}
		puts("");
	}
	return 0;
}
