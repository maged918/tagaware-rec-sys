//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <list>
#include <string>
#include <cmath>
#include <queue>
#include <set>
#include <map>
#include <algorithm>

using namespace std;

const double MY_PI = 4 * atan2(1.0, 1.0);

struct Point
{
	double x,y;
	Point() : x(-1.7171717), y(-1.7171717) { } ;
	Point(double x_, double y_) : x(x_), y(y_) { } ;
	double len(void) const {return sqrt(x*x+y*y);};
};

double atan2(const Point &A)
{
	return atan2(A.y, A.x);
}

Point operator + (const Point A, const Point B)
{
	return Point(A.x+B.x, A.y+B.y);
}

Point operator - (const Point A, const Point B)
{
	return Point(A.x-B.x, A.y-B.y);
}

Point fromPolar(double R, double alpha)
{
	return Point(R * cos(alpha), R * sin(alpha));
}

double scal_mul(const Point &A, const Point &B)
{
	return A.x * B.x + A.y * B.y;
}

double vect_mul(const Point &A, const Point &B)
{
	return A.x * B.y - A.y * B.x;
}

typedef vector<int> vi;
typedef pair<int,int> pii;

bool segm_cross_circ(const Point &A, const Point &B, double R) // 
{
	if(fabs(vect_mul(A,B)) / (A-B).len() >= R)
		return false;
	return scal_mul(A, B-A) <= 0.0 && scal_mul(B, A-B) <= 0.0;	
}

Point find_touch(const Point &A, double R, double sign)
{
	double alpha = atan2(A);
	return fromPolar(R, alpha + acos(R/A.len()) * sign);
}


double min_angle_between(double alpha, double beta)
{
	double res = alpha - beta;
	if(res <= -MY_PI)
		res += 2 * MY_PI;
	if(res > +MY_PI)
		res -= 2 * MY_PI;
	return fabs(res);
}

double star__R;

double tot_dist(const Point &A, const Point &touch_0, const Point &touch_1, const Point &B)
{
	return (touch_0-A).len() + star__R * min_angle_between(atan2(touch_0), atan2(touch_1)) + (B-touch_1).len();
}


int main(int argc, char* argv[])
{
#ifndef ONLINE_JUDGE
	freopen("C.in", "rt", stdin);
	FILE *flog = fopen("log.txt", "wt");
#endif

	Point Planet_start;
	cin >> Planet_start.x >> Planet_start.y;
	double planet_R = Planet_start.len();
	double planet_start_phi = atan2(Planet_start);
	double planet_v;
	cin >> planet_v;
	double planet_omega = planet_v / (planet_R);
	Point spaceship_start;
	cin >> spaceship_start.x >> spaceship_start.y;
	double spaceship_v;
	cin >> spaceship_v;
	cin >> star__R;


	double left = 0.0, right = (spaceship_start.len() + planet_R * (1.2 * MY_PI + 1.2)) / spaceship_v;
	while(right - left > 1e-7)
	{
		double mid = (left + right) / 2.0;
/*
	start can_reach search
*/
		bool can_reach;
		Point Planet_curr = fromPolar(planet_R, planet_start_phi + planet_omega * mid);


#ifndef ONLINE_JUDGE
		fprintf(flog, "\n\n\n\\begin{Huge}%lf\\end{Huge}\n\n\\begin{mfpic}[2]{-10}{10}{-10}{10}\n\\circle{(0,0),%lf}\n\\lines{(%.3lf,%.3lf),(%.3lf,%.3lf)}", mid, star__R,
			Planet_curr.x, Planet_curr.y,
			spaceship_start.x, spaceship_start.y);
#endif

		if(!segm_cross_circ(spaceship_start, Planet_curr, star__R))
			can_reach = (Planet_curr-spaceship_start).len() <= spaceship_v * mid;
		else
		{
			Point touch_0_1 = find_touch(spaceship_start, star__R, -1);
			Point touch_0_2 = find_touch(spaceship_start, star__R, +1);
			Point touch_1_1 = find_touch(Planet_curr, star__R, -1);
			Point touch_1_2 = find_touch(Planet_curr, star__R, +1);

#ifndef ONLINE_JUDGE
			fprintf(flog, "\n\\point{(%.3lf,%.3lf)}\n\\point{(%.3lf,%.3lf)}\n\\point{(%.3lf,%.3lf)}\n\\point{(%.3lf,%.3lf)}\n", 
				touch_0_1.x, touch_0_1.y, 
				touch_0_2.x, touch_0_2.y, 
				touch_1_1.x, touch_1_1.y, 
				touch_1_2.x, touch_1_2.y);
			fprintf(flog, "\n\\lines{(%.3lf,%.3lf),(%.3lf,%.3lf)}\n", 
				spaceship_start.x, spaceship_start.y,
				touch_0_1.x, touch_0_1.y);
			fprintf(flog, "\n\\lines{(%.3lf,%.3lf),(%.3lf,%.3lf)}\n", 
				spaceship_start.x, spaceship_start.y,
				touch_0_2.x, touch_0_2.y);
			fprintf(flog, "\n\\lines{(%.3lf,%.3lf),(%.3lf,%.3lf)}\n", 
				Planet_curr.x, Planet_curr.y,
				touch_1_1.x, touch_1_1.y);
			fprintf(flog, "\n\\lines{(%.3lf,%.3lf),(%.3lf,%.3lf)}\n", 
				Planet_curr.x, Planet_curr.y,
				touch_1_2.x, touch_1_2.y);
#endif

			can_reach = min(
				min(tot_dist(spaceship_start, touch_0_1, touch_1_1, Planet_curr), 
				tot_dist(spaceship_start, touch_0_1, touch_1_2, Planet_curr)), 
				min(tot_dist(spaceship_start, touch_0_2, touch_1_1, Planet_curr), 
				tot_dist(spaceship_start, touch_0_2, touch_1_2, Planet_curr))
				) <= spaceship_v * mid;
		}

#ifndef ONLINE_JUDGE
		fprintf(flog, "\\end{mfpic}\n\n");
#endif
/*
	end can_reach search
*/
		if(can_reach)
			right = mid;
		else
			left = mid;
	}

	cout.precision(12);
	cout << (left + right)/2.0;


#ifndef ONLINE_JUDGE
	fclose(flog);
#endif	
	return 0;
}
