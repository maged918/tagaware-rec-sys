//Language: MS C++


#include<cstdio>
#include<cmath>
#include<iostream>
using namespace std;
int main(){


    int k,b,n,t,m,s;
    long long fn;
    double c,tmp;
    while(scanf("%d%d%d%d",&k,&b,&n,&t)!=EOF){

        fn=1;
        s=0;
        while(fn<t){
            
            fn=fn*k+b;  
            s++;
        }
        if(s>n){
            
            printf("0\n");
            continue;
        }
        if(k!=1){

            tmp=b*1.0/(k-1.0);
            c=(t+tmp)/(1+tmp);
        //  cout<< log(c)/log((double)k)<<endl;
            m = n-floor( log(c)/log((double)k) );
        }else{
            
            m=n-floor( (t-1.0)/b );
        
        }
        printf("%d\n",m);
    }
    return 0;
}