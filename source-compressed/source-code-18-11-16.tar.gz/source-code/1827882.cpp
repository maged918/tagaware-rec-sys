//Language: MS C++


#include <iostream>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <memory>
#include <cctype>
#include <string>
#include <vector>
#include <list>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <algorithm>
using namespace std;

typedef long long Int;
typedef pair<int,int> PII;
typedef vector<int> VInt;

#define FOR(i, a, b) for(i = (a); i < (b); ++i)
#define RFOR(i, a, b) for(i = (a) - 1; i >= (b); --i)
#define CLEAR(a, b) memset(a, b, sizeof(a))
#define SIZE(a) int((a).size())
#define ALL(a) (a).begin(),(a).end()
#define PB push_back
#define MP make_pair

int A[64][64];
int R[64][64][64];
int T[64][64][64];

int F(int n, int m, int cnt)
{
	int i, j;
	int pos = 0;
	FOR(i, 0, n)
	{
		if(pos == 0)
			FOR(j, 0, m)
			{
				A[i][j] = cnt;
				++cnt;
			}
		else
			RFOR(j, m, 0)
			{
				A[i][j] = cnt;
				++cnt;
			}

		pos = m - 1 - pos;
	}

	return cnt;
}

void F(int n)
{
	int i, j, k;
	if(n & 1)
	{
		FOR(i, 0, n)
			FOR(j, 0, n)
				FOR(k, 0, n)
					T[i + 1][j + 1][k + 1] = R[i][j][k] + n*n;

		int cnt = F(n, n, 0) + n*n*n;
		FOR(i, 0, n)
			FOR(j, 0, n)
				T[0][n - i][n - j] = A[i][j];

		cnt = F(n + 1, n, cnt);
		FOR(i, 0, n + 1)
			FOR(j, 0, n)
				T[n - i][0][j + 1] = A[i][j];

		cnt = F(n + 1, n + 1, cnt);
		FOR(i, 0, n + 1)
			FOR(j, 0, n + 1)
				T[j][i][0] = A[i][j];

		FOR(i, 0, n + 1)
			FOR(j, 0, n + 1)
				FOR(k, 0, n + 1)
					R[i][j][k] = T[k][n - j][n - i];
	}
	else
	{
		FOR(i, 0, n)
			FOR(j, 0, n)
				FOR(k, 0, n)
					T[i + 1][j + 1][k] = R[i][j][k] + n*n;

		int cnt = F(n, n, 0) + n*n*n;
		FOR(i, 0, n)
			FOR(j, 0, n)
				T[0][n - i][j] = A[i][j];

		cnt = F(n, n + 1, cnt);
		FOR(i, 0, n)
			FOR(j, 0, n + 1)
				T[n - j][0][i] = A[i][j];

		cnt = F(n + 1, n + 1, cnt);
		FOR(i, 0, n + 1)
			FOR(j, 0, n + 1)
				T[n - j][i][n] = A[i][j];

		FOR(i, 0, n + 1)
			FOR(j, 0, n + 1)
				FOR(k, 0, n + 1)
					R[i][j][k] = T[k][n - j][i];
	}
}

int main()
{
	CLEAR(R, -1);

	int n;
	scanf("%d", &n);

	R[0][0][0] = 0;
	int i, j, k;
	FOR(i, 1, n)
		F(i);

	FOR(i, 0, n)
	{
		FOR(j, 0, n)
			FOR(k, 0, n)
				printf("%d%c", R[i][j][k] + 1, k == n - 1 ? '\n' : ' ');

		if(i != n - 1)
			printf("\n");
	}

	return 0;
};
