//Language: GNU C++


#include <cstdio>

using namespace std;

int main(){
    int n;
    
    scanf("%d",&n);
    
    int sum = 0,x;
    
    for(int i = 0;i < n;++i){
        scanf("%d",&x);
        sum += x;
    }
    
    printf("%.5f\n",(double)sum / n);
    
    return 0;
}
