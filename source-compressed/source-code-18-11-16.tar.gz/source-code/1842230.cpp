//Language: GNU C++


#include <iostream>
#include <cstdio>
using namespace std;

const int N = 1005;
const long long inf = (long long) 1 << 61;
long long lin[N], col[N], n, m, rez_x, rez_y;

void standard()
{
    #ifndef ONLINE_JUDGE
        freopen("cf.in", "r", stdin);
        freopen("cf.out", "w", stdout);
    #endif
}

inline int dist(int x, int y)
{
    if (x == y)
        return 1;

    if (x < y)
        return 2 * (y - x - 1) + 1;

    return 2 * (x - y) + 1;
    return 2 * (x < y ? y - x : x - y) + 1;
}

long long sqr(long long x)
{
    return x * x;
}

int det(long long v[], long long& rez)
{
    rez = inf;
    long long val;
    int xbest;

    for (int i = 0 ; i <= v[0] + 1 ; i++)
    {
        val = 0;

        for (int j = 1 ; j <= v[0] ; j++)
            val += v[j] * sqr(dist(i, j));

        if (val < rez)
        {
            rez = val;
            xbest = i;
        }
    }

    return xbest;
}

int main()
{
    standard();

    int x, y;

    cin >> n >> m;

    lin[0] = n;
    col[0] = m;

    for (int i = 1 ; i <= n ; i++)
        for (int j = 1 ; j <= m ; j++)
        {
            cin >> x;
            lin[i] += x;
            col[j] += x;
        }

    x = det(lin, rez_x);
    y = det(col, rez_y);

    cout << 4 * (rez_x + rez_y) << "\n" << x << " " << y << "\n";

    return 0;
}
