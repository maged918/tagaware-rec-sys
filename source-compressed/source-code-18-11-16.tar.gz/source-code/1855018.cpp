//Language: GNU C++


#include<cstdio>
#include<cmath>
int main()
{
    int x,t,a,b,da,db;
    while(scanf("%d%d%d%d%d%d",&x,&t,&a,&b,&da,&db)!=EOF)
    {
        bool flag=false;
        if(x==0)
        {
            printf("YES\n");
            continue;
        }
        for(int i=0;i<t;i++)
        {
            if(a-da*i==x) flag=true;
            if(b-db*i==x) flag=true;
        }
        for(int i=0;i<t;i++)
        {
            for(int j=0;j<t;j++)
            {
                if(a-da*i+b-db*j==x) {flag=true;break;}
            }
        }

        if(flag ) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}