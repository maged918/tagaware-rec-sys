//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
#include <bitset>
using namespace std;
const int maxn=200,inf=0x3f3f3f3f;
int n,m,cur=1,dis[maxn][maxn],ans=inf,pre,aft;
struct hh
{
    int fr,to,lim;
}seg[maxn];
bool operator < (const hh &a,const hh &b)
{return a.lim<b.lim;}
struct matrix
{
    int r,c,a[maxn][maxn];
    bitset<maxn>row[maxn],col[maxn];
    void init(int lover,int fucker)
    {
        r=lover;
        c=fucker;
        for(int i=1;i<=r;i++)
            for(int j=1;j<=c;j++)
                col[j][i]=row[i][j]=a[i][j];
    }
}unit,can;
void matrix_multiply(matrix &x,matrix &y)
{
    matrix z;
    z.init(0,0);
    for(int i=1;i<=x.r;i++)
        for(int j=1;j<=y.c;j++)
            z.a[i][j]=(x.row[i]&y.col[j]).any();
    for(int i=1;i<=x.r;i++)
        for(int j=1;j<=y.c;j++)
        {
            x.a[i][j]=z.a[i][j]&1;
            x.row[i][j]=x.a[i][j];
            x.col[j][i]=x.a[i][j];
        }
}
void matrix_pow(matrix &x,matrix &y,int p)
{
    while(p>0)
    {
        if(p%2==1)
            matrix_multiply(x,y);
        p>>=1;
        matrix_multiply(y,y);
    }
}
void floyd()
{
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            dis[i][j]=unit.a[i][j]==1?1:inf;
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
    for(int i=1;i<=n;i++)
        if(can.a[1][i]==1)
            ans=min(ans,seg[cur].lim+dis[i][n]);
}
int main()
{
#ifdef sherco
    freopen("wtf.txt","r",stdin);
    freopen("a.txt","w",stdout);
#endif
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
        scanf("%d%d%d",&seg[i].fr,&seg[i].to,&seg[i].lim);
    sort(seg+1,seg+m+1);
    seg[m+1].lim=-1;
    can.a[1][1]=1;
    can.init(1,n);
    memset(unit.a,0,sizeof unit.a);
    for(int i=1;i<=m&&seg[i].lim==0;i++)
        unit.a[seg[i].fr][seg[i].to]=1;
    unit.init(n,n);
    floyd();
    while(cur<m)
    {
        pre=cur;
        while(seg[cur].lim==seg[cur+1].lim)
            cur++;
        matrix_pow(can,unit,seg[cur+1].lim-seg[cur].lim);
        aft=++cur;
        if(aft<=m)
        {
            while(seg[aft].lim==seg[aft+1].lim)
                aft++;
            memset(unit.a,0,sizeof unit.a);
            for(int i=1;i<=aft;i++)
                unit.a[seg[i].fr][seg[i].to]=1;
            unit.init(n,n);
            floyd();
        }
    }
    ans!=inf?printf("%d\n",ans):printf("Impossible\n");
    return 0;
}
