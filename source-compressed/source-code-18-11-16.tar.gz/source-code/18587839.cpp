//Language: GNU C++11


#include<bits/stdc++.h>
#define ll long long int
#define pb push_back
#define MOD 1000000007
using namespace std;

ll dp[1001][1001][11][2];
ll n,m,k;
string s,t;

ll maxi(ll a,ll b)
{
	if(a>b)
	return a;
	else
	return b;
}

ll fun(ll i,ll j,ll st,ll ma)
{
	if(i==n||j==m)
	return 0;
	if(dp[i][j][st][ma]!=-1)
	return dp[i][j][st][ma];
	if(st==k)
	{
		if(s[i]!=t[j])
		return dp[i][j][st][ma]=0;
		else
		return dp[i][j][st][ma]=1+fun(i+1,j+1,st,1);
	}
	dp[i][j][st][ma]=maxi(fun(i+1,j,st,0),fun(i,j+1,st,0));
	if(s[i]==t[j])
	{
		if(ma==0)
		dp[i][j][st][ma]=maxi(dp[i][j][st][ma],1+fun(i+1,j+1,st+1,1));
		else
		dp[i][j][st][ma]=maxi(dp[i][j][st][ma],1+fun(i+1,j+1,st,1));
	}
	return dp[i][j][st][ma];
}

int main()
{
	cin>>n>>m>>k;
	cin>>s;
	cin>>t;
	for(ll i=0;i<=n;++i)
	{
		for(ll j=0;j<=m;++j)
		{
			for(ll l=0;l<=k;++l)
			{
				dp[i][j][l][0]=-1;
				dp[i][j][l][1]=-1;
			}
		}
	}
	cout<<fun(0,0,0,0)<<endl;
	return 0;
}