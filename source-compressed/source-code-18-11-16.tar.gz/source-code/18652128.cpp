//Language: GNU C++11


#include <bits/stdc++.h>
#define SZ(X) (int)(X).size()
#define ALL(X) (X).begin(),(X).end()
typedef long long ll;

using namespace std;

/*
 * ElFashel
 */

int n, m, k;
char grid[501][501];
bool vis[501][501] = { { 0 } };
int dx[] = { 0, 0, 1, -1 };
int dy[] = { 1, -1, 0, 0 };

void dfs(int x, int y) {
	vis[x][y] = true;


	for (int i = 0; i < 4; ++i) {
		int nx = x + dx[i];
		int ny = y + dy[i];
		if (nx >= 0 && nx < n && ny >= 0 && ny < m && grid[nx][ny] == '.'
				&& !vis[nx][ny]) {
			dfs(nx, ny);
		}
	}
	if (k) {
		k--;
		grid[x][y] = 'X';
	}

}
int main() {
#ifndef ONLINE_JUDGE
//	freopen("in.txt", "r", stdin);
//  freopen("output.txt", "w", stdout);
#endif

	cin >> n >> m >> k;
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			cin >> grid[i][j];
		}
	}
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			if (grid[i][j] == '.' && !vis[i][j]) {
				dfs(i, j);
			}
		}
	}
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			cout << grid[i][j] ;
		}
		cout << endl;
	}

	return 0;
}
