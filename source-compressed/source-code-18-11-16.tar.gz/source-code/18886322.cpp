//Language: GNU C++11


#include <set>
#include <cstdio>
#include <algorithm>

using namespace std;

struct Frac {
    long long p;
    long long q;

    Frac(long long p_, long long q_) {
        long long g = __gcd(p_, q_);
        if (g != 0) {
            p = p_ / g;
            q = q_ / g;
        }
        if (q < 0) {
            q *= -1;
            p *= -1;
        }
    }

    bool operator < (const Frac& f) const {
        if (p != f.p) {
            return p < f.p;
        }
        return q < f.q;
    }

    bool operator == (const Frac& f) const {
        return p == f.p && q == f.q;
    }
};

struct Point {
    Frac x;
    Frac y;

    bool operator < (const Point& f) const {
        if (!(x == f.x)) {
            return x < f.x;
        }
        return y < f.y;
    }

    bool operator == (Point p) {
        return x == p.x && y == p.y;
    }
};

struct Line {
    long long A;
    long long B;
    long long C;
    int id;
};

int n, k, A, B, C;
vector < pair <int, int> > res;

bool Parallel(Line l1, Line l2) {
    return l1.A * l2.B == l2.A * l1.B;
}

Point Inter(Line l1, Line l2) {
    long long det = l1.B * l2.A - l2.B * l1.A;
    return Point{Frac(l2.C * l1.B - l1.C * l2.B, det), Frac(l2.C * l1.A - l1.C * l2.A, det)};
}

bool Common(Line l1, Line l2, Line l3) {
    if (Parallel(l1, l2) || Parallel(l2, l3)) {
        return false;
    }
    return Inter(l1, l2) == Inter(l2, l3);
}

bool Rec(vector <Line> &lines, int k) {
    int n = lines.size();
    if (k <= 0) {
        return n <= 0;
    }
    if (n <= k) {
        for (auto x : lines) {
            res.push_back({x.id + 1, -1});
        }
        return true;
    }
    int m = n;
    int min_sz = (n + k - 1) / k;
    if (n > k * k) {
        m = k * k + 1;
        min_sz = k + 1;
    }
    set <Point> branched;
    for (int i = 0; i < m; i++) {
        for (int j = i + 1; j < m; j++) {
            if (Parallel(lines[i], lines[j])) {
                continue;
            }
            vector <int> here{i, j};
            Point ziom = Inter(lines[i], lines[j]);
            if (branched.count(ziom) != 0) {
                continue;
            }
            branched.insert(ziom);
            for (int l = j + 1; l < m; l++) {
                if (Common(lines[i], lines[j], lines[l])) {
                    here.push_back(l);
                }
            }
            if (here.size() >= min_sz) {
                vector <Line> rest;
                res.push_back({lines[i].id + 1, lines[j].id + 1});
                for (int l = 0; l < n; l++) {
                    if (l != i && l != j && !Common(lines[i], lines[j], lines[l])) {
                        rest.push_back(lines[l]);
                    }
                }
                bool hehs = Rec(rest, k - 1);
                if (n > k * k) {
                    return hehs;
                } else {
                    if (hehs) {
                        return true;
                    }
                    res.pop_back();
                }
            }
        }
    }
    return false;
}

int main() {

    scanf("%d %d", &n, &k);

    vector <Line> lines;

    for (int i = 0; i < n; i++) {
        scanf("%d %d %d", &A, &B, &C);
        lines.push_back({A, B, C, i});
    }

    if (Rec(lines, k)) {
        puts("YES");
        printf("%d\n", res.size());
        for (auto p : res) {
            printf("%d %d\n", p.first, p.second);
        }
    } else {
        puts("NO");
    }

    return 0;

}
