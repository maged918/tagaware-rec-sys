//Language: GNU C++11


#include <iostream>
#include <cstdio>
#include <vector>
#include <set>
#include <deque>
#include <algorithm>
#include <queue>
#include <cmath>
#include <map>
#include <complex>
#include <cstring>
#include <bitset>
//#include "sdf.hpp"

using namespace std;
#define rep(i, a, b) for(int i = (a); i < (b); i++)
#define repd(i, a, b) for(int i = (a); i > (b); i--)
#define forIt(it, a) for(__typeof((a).begin()) it = (a).begin(); it != (a).end(); it++)
#define forRev(it, a) for(__typeof((a).rbegin()) it = (a).rbegin(); it != (a).rend(); it++)
#define ft(a) __typeof((a).begin())
#define ll long long
#define ld long double
#define fi first
#define se second
#define mk make_pair
#define pb push_back
#define sz(a) (int)(a).size()
#define all(a) (a).begin(), (a).end()
#define Rep(i,n) for(int i = 0; i < (n); ++i)

typedef complex<ld> cplex;
typedef vector<int> vi;
typedef pair<int, int> ii;
typedef pair<ii, int> iii;
typedef vector<ii> vii;
typedef vector<iii> viii;

const int N = 1e5 + 7;
const int M = 10;
const int mid = M / 2;
const int mod = 1e9 + 9;
const int inf = 1e9 + 7;
const ll linf = 1ll * inf * inf;
const double pi = acos(-1);
const double eps = 1e-7;
const double ep = 1e-5;
const int maxn = 1e5 + 7;
const double PI = acos(-1);

int inverse(int x, int n){
    int r = n, newr = x;
    int t = 0, newt = 1;
    while (newr > 0){
        int q = r / newr;
        int tmp = newr;
        newr = r % newr;
        r = tmp;
        
        tmp = newt;
        newt = t - q * newt;
        t = tmp;
    }
    if (t < 0) t += n;
    return t;
}

ll sl[3];
ll tmp[3];
int n;
ll a[N];

ll pw(ll x, ll k) {
    if (!k) return 1;
    else if (k & 1) return pw(x, k - 1) * x % inf;
    ll tmp = pw(x, k / 2);
    return tmp * tmp % inf;
}

void solve() {
    
    cin >> n;
    rep(i, 0, n) scanf("%lld", a + i);
    bool ok = true;
    ll p = 1;
    rep(i, 0, n) {
//        if (a[i] * p > 10) {
//            ok = false;
//            break;
//        } else {
//            p *= a[i];
//        }
        p *= a[i];
    }
    ok = false;
    //cout << p << " " << ok << "\n";
    if (ok) {
        sl[1] = 1;
        rep(t, 1, p + 1) {
            rep(j, 0, 3) cout << sl[j] << " ";
            puts("");
            rep(j, 0, 3) tmp[j] = sl[j];
            ll tol = sl[0] + sl[1] + sl[2];
            sl[1] = tol - tmp[1];
            sl[2] = tol - tmp[0];
            sl[0] = tol - tmp[2];
        }
        
        ll d = __gcd(sl[1], sl[0] + sl[1] + sl[2]);
        cout << sl[1] / d << "/" << (sl[0] + sl[1] + sl[2]) / d;
    } else {
        ll lt = 2;
        bool even = false;
        rep(i, 0, n){
            lt = pw(lt, a[i]) % inf;
            if (a[i] % 2 == 0) even = true;
        }
//        cout << lt << "\n";
        ll y = 0, x = 0;
        
        lt = lt * inverse(2, inf) % inf;
        if (even) {
            x = (lt + 1 + inf) % inf;
            y = lt;
            x = x * inverse(3, inf) % inf;
            
        } else {
            x = (lt - 1 + inf) % inf;
            y = lt;
            x = x * inverse(3, inf) % inf;
        }
        cout << x << "/" << y;
        
    }
}



int main() {
#ifndef ONLINE_JUDGE
    freopen("in.txt", "r", stdin); //freopen("out.txt", "w", stdout);
#endif
    int T = 1;
    //cin >> T;
    rep(i, 1, T + 1) {
        //printf("Case #%d: ", i);
        solve();
    }
    
}