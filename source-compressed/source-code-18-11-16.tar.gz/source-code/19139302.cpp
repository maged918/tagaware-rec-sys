//Language: GNU C++11


#include<stdio.h>
#include<iostream>
#define MOD 1000000007
using namespace std;
int N, rez=2, p;
long long a;
bool ok;

int pw(int x, long long y) {
    if(!y) return 1;
    int z = pw(x,y/2);
    z = (1LL*z*z) % MOD;
    if(y%2) {
        z = (1LL*x*z) % MOD;
    }
    return z;
}

int main() {
    cin>>N;
    for(int i=1;i<=N;++i) {
        cin>>a;
        if(a%2 == 0) ok = 1;
        rez = pw(rez,a) % MOD;
    }
    rez = (1LL*rez*pw(2,MOD-2)) % MOD;
    int p = (rez - 1 + MOD)%MOD;
    if(ok) p = (rez + 1)%MOD;
    p = (1LL*p*pw(3,MOD-2)) % MOD;
    cout<<p<<"/"<<rez;
    
    return 0;
}