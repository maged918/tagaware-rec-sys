//Language: GNU C++


#include <bits/stdc++.h>

#pragma comment(linker, "/STACK:102400000,102400000")
using namespace std;

#define LL long long
#define pii pair<int,int>
#define MP make_pair
#define ls i << 1
#define rs ls | 1
#define md (ll + rr >> 1)
#define lson ll, md, ls
#define rson md + 1, rr, rs
#define Pi acos(-1.0)
#define mod 1000000007
#define eps 1e-10
#define inf 0x3f3f3f3f
#define N 200010
#define M 2000020

int n, m, f;
double sum[N<<2], lmx[N<<2], rmx[N<<2], mx[N<<2], pro[N];
int a[N];
void push_up(int i){
	sum[i] = sum[ls] + sum[rs];
	lmx[i] = max(lmx[ls], sum[ls] + lmx[rs]);
	rmx[i] = max(rmx[rs], sum[rs] + rmx[ls]);
	mx[i] = max(max(mx[ls], mx[rs]), rmx[ls] + lmx[rs]);
}
void build(int ll, int rr, int i){
	if(ll == rr){
		lmx[i] = rmx[i] = mx[i] = sum[i] = pro[ll];
		return ;
	}
	build(lson);
	build(rson);
	push_up(i);
}
double ql(int l, int r, int ll, int rr, int i){
	if(l == ll && r == rr) return rmx[i];
	if(l > md) return ql(l, r, rson);
	return max(rmx[rs], sum[rs] + ql(l, md, lson));
}
double qr(int l, int r, int ll, int rr, int i){
	if(l == ll && r == rr) return lmx[i];
	if(r <= md) return qr(l, r, lson);
	return max(lmx[ls], sum[ls] + qr(md + 1, r, rson));
}
double query(int l, int r, int ll, int rr, int i){
	if(l == ll && r == rr) return mx[i];
	double ret = 0;
	if(r <= md) ret = query(l, r, lson);
	else if(l > md) ret = query(l, r, rson);
	else{
		ret = max(query(l, md, lson), query(md + 1, r, rson));
		ret = max(ret, ql(l, md, lson) + qr(md + 1, r, rson));
	}
	return max(ret, 0.0);
}
int main(){
	scanf("%d%d%d", &n, &m, &f);
	for(int i = 1; i <= n; ++i)
		scanf("%d", &a[i]);
	for(int i = 1; i < n; ++i)
		pro[i] = (a[i+1] - a[i]) * 0.5;
	for(int i = 1; i < n; ++i){
		int p;
		scanf("%d", &p);
		pro[i] -= p / 100.0 * f;
	}
	n--;
	build(1, n, 1);
	double ans = 0;
	while(m--){
		int l, r;
		scanf("%d%d", &l, &r);
		r--;
		if(l <= r)
			ans += query(l, r, 1, n, 1);
	}
	printf("%.9f\n", ans);
	return 0;
}
 	   	  					    		 	  					 		