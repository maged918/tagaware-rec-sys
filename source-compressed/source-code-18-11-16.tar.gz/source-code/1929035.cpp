//Language: MS C++


#include<iostream>
#include<queue>
#include<stdio.h>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#define INF 0x3f3f3f3f
using namespace std;
__int64 f[100],v[100],sum,ft,ans[10];
int n;
int main()
{
    int i,j;
    while(~scanf("%d",&n))
    {

        for(i=0;i<n;i++)
        {
            scanf("%I64d",&f[i]);
        }
        for(i=0;i<5;i++)
        {
            scanf("%I64d",&v[i]);
            ans[i]=0;
        }
        sum=0;
        for(i=0;i<n;i++)
        {
            sum+=f[i];
            for(j=4;j>=0;j--)
            {
                ft=sum/v[j];
                sum-=ft*v[j];
                ans[j]+=ft;
            }
        }
        for(i=0;i<4;i++)
            printf("%I64d ",ans[i]);
        printf("%I64d\n",ans[4]);
        printf("%I64d\n",sum);

    }
    return 0;
}
