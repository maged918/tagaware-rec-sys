//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
int main(){
	// freopen("input.txt","r",stdin);
	// freopen("output.txt","w",stdout);
	int n;
	cin>>n;
	int a[n];
	int sum=0;
	for (int i = 0; i < n; ++i)
	{
		cin>>a[i];
		sum+=a[i];
	}
	sum=sum/(n/2);
	int s=0,e=0;
	for (int i = 0; i < n; ++i)
	{
		if(a[i]!=0){
			for (int j = i+1; j < n; ++j)
			{	
				if(a[i]+a[j]==sum){
					a[i]=0;a[j]=0;
					cout<<i+1<<" "<<j+1<<endl;
					break;
				}
			}
		}
	}
return 0;
}