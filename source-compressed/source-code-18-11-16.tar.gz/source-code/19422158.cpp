//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
int n,m;
struct way{
	int t,l,r,m;
}p[5010];
int a[5010],b[5010];

int main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		scanf("%d%d%d%d",&p[i].t,&p[i].l,&p[i].r,&p[i].m);
	}
	for(int i=1;i<=n;i++)a[i]=1e9;
	for(int i=1;i<=m;i++){
		if(p[i].t==1){
			for(int j=p[i].l;j<=p[i].r;j++)b[j]+=p[i].m;
			
		}
		else {
			for(int j=p[i].l;j<=p[i].r;j++){
				a[j]=min(a[j],p[i].m-b[j]);
			}
		}
	}
	memset(b,0,sizeof(b));
	for(int i=1;i<=m;i++){
		if(p[i].t==1)
			for(int j=p[i].l;j<=p[i].r;j++)
				b[j]+=p[i].m;
		else {
			int k=-1e9;
			for(int j=p[i].l;j<=p[i].r;j++)
				k=max(k,a[j]+b[j]);
			if(k!=p[i].m){
				printf("NO");
				return 00;
			}
		}
	}
	puts("YES");
	for(int i=1;i<=n;i++)printf("%d ",a[i]);
	return 0;
	
}
	   		 	 		 				 	  	   	 			