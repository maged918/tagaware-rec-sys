//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <stack>
#include <cmath>
#include <map>
#include <stack>
#include <set>
#include <iomanip>
#include <queue>
#include <map>
#include <functional>
#include <memory.h>
#include <list>
using namespace std;
const int inf = 1e9+7;
const double eps = 1e-9;
const double pi = 2*acos(0.0);
#define int long long
main()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt","rt",stdin);
        freopen("output.txt","wt",stdout);
    #endif
    int n;
        cin >> n;
    for(int i=0;i<n;i++)
    {
        string s;
            cin >> s;
        if(s.size() > 10)
            cout << s[0] << s.size() - 2 << s[s.size()-1] << endl;else
            cout << s << endl;
    }
    return 0;
}
