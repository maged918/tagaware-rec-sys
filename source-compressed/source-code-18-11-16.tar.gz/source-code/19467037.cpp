//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <stack>
#include <set>
#include <cstdio>
using namespace std;

bool vis[100010];
vector <int> cn [100010];
vector <int> D;
vector <vector <int> > T;
vector <vector <vector <int> > > BM;
vector <vector <int> > c;
void dfs (int x)
{
	vis[x] = true;
	for (int i = 0; i < cn[x].size(); i++)
	{
		int v = cn[x][i];
		if (vis[v]) continue;
		D[v] = D[x]+1;
		T[v][0] = x;
		BM[v][0] = c[x];
		dfs(v);
	}
}

void gm (vector <int>& a, const vector <int> &b)
{
	int mo = min(10,int(a.size()+b.size()));
	vector <int> c = a;
	int pb = 0;
	int pc = 0;
	a.clear();
	for (int i = 0; i < mo; i++)
	{
		if (pc == c.size() && pb == b.size()) break;
		if (pb == b.size())
		{
			if (a.size() > 0)
			{
				if (c[pc] == a[a.size()-1])
				{
					pc++;
					mo++;
					continue;
				}
			}
			a.push_back(c[pc++]);
			continue;
			
		}
		if (pc == c.size())
		{
			if (a.size() > 0)
			{
				if (b[pb] == a[a.size()-1])
				{
					pb++;
					mo++;
					continue;
				}
			}
			a.push_back(b[pb++]);
			continue;
		}
		if (c[pc] < b[pb])
		{
			if (a.size() > 0)
			{
				if (c[pc] == a[a.size()-1])
				{
					pc++;
					mo++;
					continue;
				}
			}
			a.push_back(c[pc++]);
		}
		else
		{
			if (a.size() > 0)
			{
				if (b[pb] == a[a.size()-1])
				{
					pb++;
					mo++;
					continue;
				}
			}
			a.push_back(b[pb++]);
		}
	}
}

vector <int> solve (int x,int y)
{
	if (D[y] > D[x]) swap(x,y);
	vector <int> r = c[x];
	gm(r,c[y]);
	for (int i = 17; i >= 0; i--)
	{
		if (D[x]-D[y] >= (1<<i))
		{
			gm(r,BM[x][i]);
			x = T[x][i];
		}
	}
	if (x == y) return r;
	for (int i = 17; i >= 0; i--)
	{
		if (T[x][i] != T[y][i])
		{
			gm(r,BM[x][i]);
			gm(r,BM[y][i]);
			x = T[x][i];
			y = T[y][i];
		}
	}
	gm(r,BM[x][0]);
	return r;
}

int main()
{
	int n,m,q;
	scanf("%d%d%d",&n,&m,&q);
	D = vector <int> (n);
	T = vector <vector <int> > (n,vector <int> (18,-1));
	BM = vector <vector<vector<int> > > (n,vector <vector <int> > (18));
	c = vector <vector<int> > (n);
	for (int i = 1; i < n; i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		u--;v--;
		cn[u].push_back(v);
		cn[v].push_back(u);
	}
	for (int i = 1; i <= m; i++)
	{
		int t;
		scanf("%d",&t);
		t--;
		if (c[t].size() < 10) c[t].push_back(i);
	}
	dfs(0);
	for (int j = 1; j < 18; j++)
	{
		for (int i = 0; i < n; i++)
		{
			int s = T[i][j-1];
			if (s == -1) continue;
			BM[i][j] = BM[i][j-1];
			gm(BM[i][j],BM[s][j-1]);
			T[i][j] = T[s][j-1];
		}
	}
	for (int i = 0; i < q; i++)
	{
		int u,v,a;
		scanf("%d%d%d",&u,&v,&a);
		u--;
		v--;
		vector <int> anw = solve(u,v);
		int t = min(int(anw.size()),a);
		printf("%d",t);
		for (int j = 0; j < anw.size(); j++)
		{
			printf(" %d",anw[j]);
			t--;
			if (t == 0) break;
		}
		printf("\n");
	}
}
