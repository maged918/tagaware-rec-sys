//Language: GNU C++


/*************************************************************************
Author: zjut_polym
Created Time:   2012-8-3 13:03:47
File Name: B.cpp
************************************************************************/
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <set>
#include <string>
#include <climits>
using namespace std;
#define ll long long
#define NMAX 100005
#define MOD 1000000007
char ma[105][105];
int hang[105][26],lie[105][26];
int main() {
	for(int n,m;cin>>n>>m;){
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				cin>>ma[i][j];
			}
		}
		memset(hang,0,sizeof(hang));
		memset(lie,0,sizeof(lie));
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				hang[i][ma[i][j]-'a']++;
			}
		}
		for(int j=0;j<m;j++){
			for(int i=0;i<n;i++){
				lie[j][ma[i][j]-'a']++;
			}
		}
	//	cout<<1<<endl;
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				if(hang[i][ma[i][j]-'a']==1&&lie[j][ma[i][j]-'a']==1){
					cout<<ma[i][j];
				}
			}
		}
		cout<<endl;
	}
    return 0;
}


	  	  		   	  			 		 	 		