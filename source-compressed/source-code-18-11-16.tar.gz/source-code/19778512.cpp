//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;

#define f first
#define s second
#define mp make_pair
#define pb push_back
#define MOD 1000000007
#define ll long long

typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
typedef vector<int> vi;
typedef pair<double,double> pdd;
typedef vector<ll> vll;
typedef vector<pii> vpii;
typedef vector<pll> vpll;
typedef vector<pdd> vpdd;

ll GCD(ll a, ll b)
{
    return b? GCD(b,a%b) : a;
}
bool chk(string first, string second)
{
    string t1 = first + second;
    string t2 = second + first;
    return t1 < t2;
}
struct sort_pred
{
    bool operator()(const pair<int,int> &left, const pair<int,int> &right)
    {
        return left.second < right.second;
    }
};
long long POW(long long Base, long long Exp)
{
    long long y,ret=1;
    y=Base;
    while(Exp)
    {
        if(Exp&1)
            ret=(ret*y)%MOD;
        y = (y*y)%MOD;
        Exp/=2;
    }
    return ret%MOD;
}
int cont(ll n)
{
    ll count = 0;
    while(n)
    {
        count += n & 1;
        n >>= 1;
    }
    return count;
}

vll A,B,C,Res,Mark;
string str,str1,s1,s2;
set<string> st;
vector<string> chlo,final;
vpll Rec;
ll nCr[1007][1007];

int main()
{
	ll n,i,j,k,x,m,tmp1,tmp2;
	
	nCr[0][0]=1;
    nCr[1][0]=1;
    nCr[1][1]=1;
	
	for(i=2; i<1007; i++)
    {
        nCr[i][0]=nCr[i][i]=1;
        for(j=1; j<i; j++)
            	nCr[i][j]=(nCr[i-1][j-1] + nCr[i-1][j])%MOD;
    }
	cin>>n>>m>>k;
	
	tmp1 = nCr[n-1][2*k];
	if(2*k > n-1)
				tmp1 = 0;
	tmp2 = nCr[m-1][2*k];
	if(2*k > m-1)
				tmp2 = 0;	
	ll Ans = (tmp1*tmp2)%MOD;
	
	cout<<(Ans+MOD)%MOD<<endl;

	return 0;
}