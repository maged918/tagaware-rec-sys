//Language: GNU C++


#include "cstdio"
#include "iostream"
//#include "ctring"
using namespace std;
main()
{
      long i,j,n,m,ma;
      long a[1000],b[1000];
      ma=0;
      cin>>n;
      for (i=1;i<=n;i++) cin>>a[i];
      cin>>m;
      for (i=1;i<=m;i++) cin>>b[i];
      for (i=1;i<=n;i++)
      for (j=1;j<=m;j++)
       if (b[j]%a[i]==0 && b[j]/a[i]>ma) ma=b[j]/a[i];
      long res=0;
      for (i=1;i<=n;i++)
      for (j=1;j<=m;j++)
       if (b[j]/a[i]==ma && b[j]%a[i]==0) res++;
       cout<<res;
}
