//Language: GNU C++11


#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define pii pair<int,int>
#define pil pair<int,long long>
#define pli pair<long long,int>
#define pll pair<long long,long long>
#define pb push_back
#define mk make_pair
#define sd(x) scanf("%d", &x)
#define pd(x) printf("%d\n",x)
#define pdl(x) printf("%lld\n",x)
#define sdl(x) scanf("%lld", &x)
#define eps 1e-12l
#define maxn 100009
using namespace std;
ll mod=1000003;
ll pow_2[70];
inline long long int fastexpo(long long int base,long long int expo,ll c)
{
	long long int result=1;
	while(expo>0)
	{
		if(expo%2==1)
		{
			result=(result*base)%c;
		}
		expo=expo/2ll;
		base=(base*base)%c;
	}
	return result;
}
inline ll powin(ll n)
{
	if(n==0)
	{
		return 0;
	}
	return ((n/2)+powin(n/2))%(mod-1);
}
int main()
{
	pow_2[0]=1;
	for(int i=1;i<=64;i++)
	{
		pow_2[i]=pow_2[i-1]*2ll;
	}
	ll n,k;
	sdl(n);
	sdl(k);
	if(n<=63)
	{
		ll x=pow_2[n];
		if(x<k)
		{
			printf("1 1\n");
			return 0;
		}
	}
	ll comp=powin(k-1);
	ll x=n%(mod-1);
	ll x1=(k-1)%(mod-1);
	ll x2=(x*x1)%(mod-1);
	x2=(x2-comp)%(mod-1);
	if(x2<0)
	{
		x2+=(mod-1);
	}
	ll den=fastexpo(2,x2,mod);
	ll num=den;
	ll y=fastexpo(2,comp,mod);
	y=fastexpo(y,mod-2,mod);
	ll sec=y;
	ll t=(k-1)/mod;
	ll h=fastexpo(2,x,mod);
	ll ans=1;
	for(int i=1;i<mod;i++)
	{
		ans=(ans*((h-i)%mod))%mod;
		if(ans<0)
		{
			ans+=mod;
		}
	}
	ll hh=t%(mod-1);
	ans=fastexpo(ans,hh,mod);
	if(t!=0)
	{
		ll tt=t-1;
		tt=tt%(mod-1);
		ans=ans*fastexpo(h,tt,mod);
		ans=ans%mod;
	}
	if((k-1)%mod!=0)
	{
		for(int i=1;i<=(k-1)%mod;i++)
		{
			ans=(ans*((h-i)%mod))%mod;
			if(ans<0)
			{
				ans+=mod;
			}
		}
	}
	ans=ans*y;
	ans%=mod;
	num-=ans;
	num%=mod;
	if(num<0)
	{
		num+=mod;
	}
	printf("%lld %lld\n",num,den);
}