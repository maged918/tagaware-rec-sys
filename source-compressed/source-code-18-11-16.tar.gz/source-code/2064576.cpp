//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
struct ln {
    int num;
    double ans; 
}s[1010];
int cmp(const ln a,const ln b){
    if(a.ans!=b.ans)
        return a.ans>b.ans;
    return 
        a.num<b.num;    
}
int n,t1,t2,k;
int main(){
    while(cin>>n>>t1>>t2>>k){
        for(int i=0;i<n;i++){
            int a,b;
            cin>>a>>b;
            s[i].num=i+1;
            s[i].ans=1.0*a*t1*(100-k)/100.0+b*t2;
            s[i].ans=max(s[i].ans,1.0*b*t1*(100-k)/100.0+a*t2);
        }
        sort(s,s+n,cmp);
        for(int i=0;i<n;i++){
            cout<<s[i].num<<" ";
            printf("%.2lf\n",s[i].ans);
        }   
        
    }
    
    
    return 0;
}