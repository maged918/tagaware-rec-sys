//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
#define N 1100
int c[N][N];
int n,m;
inline int lowbit(int x)
{
    return x&(-x);
}
void add(int x,int y)
{
    for(int i=x;i<=n;i+=lowbit(i))
        for(int j=y;j<=n;j+=lowbit(j))
            c[i][j]+=1;

}
int sum(int x,int y)
{
    int ret=0;
    for(int i=x;i>0;i-=lowbit(i))
        for(int j=y;j>0;j-=lowbit(j))
            ret+=c[i][j];
    return ret;
}
int main()
{

    scanf("%d%d",&n,&m);
    int i,j,k,x,y;
    int ans=-1,tmp;
    for(k=0;k<m;k++)
    {
        scanf("%d%d",&x,&y);
        add(x,y);
        for(i=x;i<=x+2;i++)
            for(j=y;j<=y+2;j++)
            {
                if(i-3>=0&&j-3>=0)
                {
                    tmp=sum(i,j)-sum(i,j-3)-sum(i-3,j)+sum(i-3,j-3);
                    if(tmp==9&&ans==-1) ans=k+1;
                }
                
            }
    }
    printf("%d\n",ans);

    return 0;
}