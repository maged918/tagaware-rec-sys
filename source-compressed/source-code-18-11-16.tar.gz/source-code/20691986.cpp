//Language: GNU C++14


#include <iostream>
#include <vector>
using namespace std;

int cumSum[50001][26];
int cumMissing[50001];

int main()
{
    ios_base::sync_with_stdio(0);
    string x;
    cin>>x;
    int len = x.length();
    if(len < 26){
        cout<<-1;
        return 0;
    }else{
        for(int i = 1;i<=len;i++){
            cumMissing[i] += cumMissing[i-1];
            for(int j = 0;j<26;j++)
                cumSum[i][j] += cumSum[i-1][j];
            if(x[i-1] == '?'){
                cumMissing[i]++;
            }else{
                cumSum[i][x[i-1]-'A']++;
            }
        }
    }
    vector <char> letters;
    for(int i = 26;i<=len;i++){
        bool failed = false;
        int miss = cumMissing[i]-cumMissing[i-26];
        letters.clear();
        for(int j = 0;j<26;j++){
            if(cumSum[i][j]-cumSum[i-26][j] > 1){
                failed = true;
                break;
            }else if(cumSum[i][j]-cumSum[i-26][j] == 0){
                miss--;
                letters.push_back(j+'A');
            }
        }
        if(miss == 0 && !failed){
            int tempCnt = 0;
            for(int j = 0;j<len;j++){
                if(j >= i-26 && j< i){
                    if(x[j] == '?'){
                        cout<<letters[tempCnt++];
                    }else
                        cout<<x[j];
                }else{
                    if(x[j] == '?')
                        cout<<"A";
                    else
                        cout<<x[j];
                }
            }
            return 0;
        }
    }
    cout<<-1;
    return 0;
}
