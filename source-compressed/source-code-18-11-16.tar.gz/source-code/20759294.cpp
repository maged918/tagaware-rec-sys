//Language: GNU C++11


#include <bits/stdc++.h>

#if SEREZHKA
	#define filename "file"
#else
	#define filename ""
#endif // SEREZHKA

#define forn(i, n) for (llong i = 0ll; i < (llong) n; ++i)
#define fornn(i, l, r) for (llong i = (llong) l; i < (llong) r; ++i)
#define here(str) fprintf(stderr, "here: %s\n", #str)
#define size(x) ((int) (x.size()))

using namespace std;

const int MAX_MEM = (int) 1e8;
int mpos = 0;
char mem[MAX_MEM];

inline void * operator new (size_t n) { char *res = mem + mpos; mpos += n; return (void *) res; }
inline void operator delete (void *) { }

struct __io_dev
{
	__io_dev(const bool& __fastio = false)
	{
		if (__fastio) ios_base::sync_with_stdio(false), cin.tie(nullptr);
		srand(time(nullptr));

		if (!string(filename).empty())
			freopen(filename ".in", "r", stdin), freopen(filename ".out", "w", stdout);
	}

	~__io_dev() { fprintf(stderr, "%.6f ms\n", 1e3 * clock() / CLOCKS_PER_SEC); }
}
__io(false);

typedef long long llong;
const llong inf = (llong) 1e+9 + 7ll;
const llong linf = (llong) 1e+18 + 7ll;
const long double eps = (long double) 1e-9;
const long double pi = acosl((long double) -1.0);
const int alph = 26;
const int maxs = 512l;

static char buff[(int) 2e6 + 17];
llong __p[3] = {29ll, 31ll, 33ll};
llong __mod[3] = {inf, inf + 2ll, 14881337ll};

const int maxn = (int) 3e5 + 17;

int n;
llong ans = 0;
llong a[maxn], dp_l[maxn], dp_r[maxn];

int main()
{
	scanf("%d", &n);

	fornn (i, 1, n + 1)
		scanf("%d", a + i);

	for (int i = 0; i <= n + 1; ++i)
	{
		dp_l[i] = min(0ll + i, a[i]);
		if (i > 0) dp_l[i] = min(dp_l[i], dp_l[i - 1] + 1);
	}

	for (int i = n + 1; i >= 0; --i)
	{
		dp_r[i] = min(n + 1ll - i, a[i]);
		if (i < n + 1) dp_r[i] = min(dp_r[i], dp_r[i + 1] + 1);
	}

	for (int i = 0; i <= n + 1; ++i)
		ans = max(ans, min(dp_l[i], dp_r[i]));

	printf("%lld\n", ans);

	return 0;
}
