//Language: GNU C++11


#include<bits/stdc++.h>
using namespace std;
inline void read(int &x){
    x=0;
    register char c=getchar();
    while(c<'0'||c>'9')
        c=getchar();
    for(;c>='0'&&c<='9';c=getchar())
        x=(x<<1)+(x<<3)+(c-'0');
}
inline void write(long long x){
    char c[20],*p=c;
    do{
        *p++='0'+x%10;
        x/=10;
    }while(x);
    do{
        putchar(*--p);
    }while(p!=c);
}
int n,m,l[2005],x[2005][2005],y[2005][2005],w[2005][2005];
bool p[2005],q[2005];
long long b[2005][2005];
void update(int x,int y,int w){
    int z=y;
    while(x<=n){
        y=z;
        while(y<=m){
            b[x][y]+=w;
            y+=(y&(-y));
        }
        x+=(x&(-x));
    }
}
long long query(int x,int y){
    int z=y;
    long long w=0;
    while(x){
        y=z;
        while(y){
            w+=b[x][y];
            y-=(y&(-y));
        }
        x-=(x&(-x));
    }
    return w;
}
int main(){
    int t,i,j,k,xx,yy;
    char c;
    read(n);read(m);read(k);
    for(i=1;i<=k;++i){
        read(l[i]);
        for(j=0;j!=l[i];++j)
            read(x[i][j]),read(y[i][j]),read(w[i][j]);
        p[i]=1;
    }
    read(t);
    while(t--){
        c=' ';
        while(c==' ') c=getchar();
        if(c=='S'){
            read(j);
            p[j]=!p[j];
        }
        else{
            for(i=1;i<=k;++i)
                if(p[i]^q[i]){
                    if(p[i]){
                        for(j=0;j!=l[i];++j)
                            update(x[i][j],y[i][j],w[i][j]);
                    }
                    else{
                        for(j=0;j!=l[i];++j)
                            update(x[i][j],y[i][j],-w[i][j]);
                    }
                    q[i]=p[i];
                }
            read(i);read(j);read(xx);read(yy);
            write(query(xx,yy)-query(xx,j-1)-query(i-1,yy)+query(i-1,j-1));putchar('\n');
        }
    }
}
