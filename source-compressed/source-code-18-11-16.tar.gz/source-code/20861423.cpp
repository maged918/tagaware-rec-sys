//Language: GNU C++


/*
  Program: C
  Copyright by G10
  Please do not copy it
  Or Mr.Xiang will invite you with a cup of tee
*/
#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<ctime>
#include<vector>
#include<stack>
#include<set>
#include<map>
using namespace std;

typedef long long LL;

const int INF=2147483647;

LL getint()
{
    LL res=0,p=1;
    char ch=getchar();
    while ((ch<'0'||ch>'9') && ch!='-') ch=getchar();
    if (ch=='-') p=-1,ch=getchar();
    while (ch>='0'&&ch<='9') res=res*10+ch-'0',ch=getchar();
    return res*p;
}

const int N=200050;
int INT[N],FRA[N];
int l1,l2,n,t;

int main()
{
	n=getint();t=getint();
    int i,mn=0;
    char ch;
    do {
    	ch=getchar();
    	i=ch-'0';
    	if (0<=i && i<=9) INT[++l1]=i;
    }while (ch!='.');
    do {
    	ch=getchar();
    	i=ch-'0';
    	if (0<=i && i<=9) FRA[++l2]=i;
    }while (l2<n-l1-1);
    for (i=1;i<=l2;i++) if (FRA[i]>4) {mn=i;break;}
    while (t>0 && mn>0) {
		l2=i=mn-1;t--;
    	while (i>0 && FRA[i]==9) {
    		l2--;i--;
    	}
   		mn=0;
    	if (i>0) {
			FRA[i]++;
			if (FRA[i]>4) mn=i;
		}
		else {
			INT[l1]++;
			i=l1;
			while (INT[i]==10) {
				INT[i]=0;INT[i-1]++;
				i--;
			}
		}
	}
	if (INT[0]) printf("%d",INT[0]);
	for (i=1;i<=l1;i++) printf("%d",INT[i]);
	if (l2) printf(".");
	for (i=1;i<=l2;i++) printf("%d",FRA[i]);
	printf("\n");
    return 0;
}