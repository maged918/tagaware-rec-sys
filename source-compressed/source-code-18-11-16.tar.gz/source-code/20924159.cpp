//Language: GNU C++14


#include<cstdio>
#define Int register int
const int MAXN = 100005;
int n, m, w[MAXN];
bool vis[MAXN], flag = true;
long long sum[MAXN], ans, val;

int main() {
	scanf("%d", &n);
	for(Int i = 1; i <= n; ++i) {
		scanf("%d", w + i);
		sum[i] = sum[i - 1] + w[i];
		ans += 1LL * i * w[i];
		vis[i] = true;
	}
	while(flag) {
		flag = false;
		for(Int i = m = 1; i <= n; ++i) {
			val = 1LL * m * w[i] + sum[n] - sum[i];
			if(vis[i] && val < 0)
				ans -= val, vis[i] = false, flag = true;
			else if(!vis[i] && val >= 0)
				ans += val, vis[i] = true, flag = true;
			if(vis[i]) ++m;
			sum[i] = sum[i - 1] + vis[i] * w[i];
		}
	}
	printf("%lld\n", ans);
	return 0;
}