//Language: MS C++


#include <cstdio>
#include <vector>

using std::vector;

int main()
{
	int n;
	char str[102];
	scanf("%d%s", &n, str);

	str[n] = 'W';
	str[++n] = 0;

	vector<int> groups;
	int blast;
	bool bmode = false;
	for (int i = 0; str[i]; ++i)
	{
		if (str[i] != 'B' && bmode)
		{
			groups.push_back(i - blast);
			bmode = false;
		}
		if (str[i] == 'B' && !bmode)
		{
			blast = i;
			bmode = true;
		}
	}

	printf("%d\n", groups.size());
	for (size_t i = 0; i < groups.size(); ++i)
		printf("%d ", groups[i]);

	return 0;
}
