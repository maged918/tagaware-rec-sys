//Language: GNU C++14


#include<iostream>
#include<algorithm>
using namespace std;

struct lake
{
    int x,y;
    int area;
    bool notl;
    bool operator<(const lake&o) const
    {
        return area<o.area;
    }
};

lake l[3000];
int comp = 0;
char grid[51][51];
int m, n, k;

void number(int i, int j)
{
    if(i >= 0 && j >= 0 && i < n && j < m && grid[i][j] == '.')
    {
        if(i == 0 || j == 0 || i == n-1 || j == m-1)
            l[comp].notl = true;
        grid[i][j] = 'o';
        l[comp].area++;
        number(i-1, j);
        number(i+1, j);
        number(i, j-1);
        number(i, j+1);
    }
}

void fll(int i, int j)
{
    if(i >= 0 && j >= 0 && i < n && j < m && grid[i][j] == 'o')
    {
        if(i == 0 || j == 0 || i == n-1 || j == m-1)    {
            grid[i][j] = '.';
            return;
        }
        grid[i][j] = '*';
        fll(i-1, j);
        fll(i+1, j);
        fll(i, j-1);
        fll(i, j+1);
    }
}
int main()
{
    cin>>n>>m>>k;
    for(int i = 0; i < n; i++)
        cin>>grid[i];

    for(int i = 0; i < n; i++)
    for(int j = 0; j < m; j++)  {
        if(grid[i][j] == '.')   {
            l[comp].x = i;
            l[comp].y = j;
            number(i, j);
            comp++;
        }
    }
    sort(l, l+comp);
    int ch = 0;
    int lks = 0;
    for(int i = 0; i < comp; i++)
        if(!l[i].notl)
            lks++;

    int kch = lks - k;

    for(int i = 0; i < comp && kch>0; i++)   {
        if(!l[i].notl)   {
            ch += l[i].area;
            fll(l[i].x, l[i].y);
            kch--;
        }
    }
    for(int i = 0; i < n; i++)
    for(int j = 0; j < m; j++)  {
        if(grid[i][j] == 'o')   {
            grid[i][j] = '.';
        }
    }
    cout<<ch<<'\n';
    for(int i = 0; i < n; i++)
        cout<<grid[i]<<'\n';

}
