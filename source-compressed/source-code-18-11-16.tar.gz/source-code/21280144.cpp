//Language: GNU C++11


#include <bits/stdc++.h>

using namespace std;

#define ll long long

map<string, int> p;

int main() {
	p["monday"] = 0;
	p["tuesday"] = 1;
	p["wednesday"] = 2;
	p["thursday"] = 3;
	p["friday"] = 4;
	p["saturday"] = 5;
	p["sunday"] = 6;

	vector<int> m = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	string d1, d2;
	cin >> d1 >> d2;

	int i1 = p[d1], i2 = p[d2];

	for (int i = 0; i < 12; i++) {
		if ((i1 + m[i]) % 7 == i2) {
			cout << "YES\n";
			return 0;
		}
	}

	cout << "NO\n";

	return 0;
}
