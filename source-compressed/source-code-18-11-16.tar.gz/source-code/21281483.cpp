//Language: GNU C++11


#include <bits/stdc++.h>
#define MA 1000000000
using namespace std;
typedef long long ll;
ll n;
int st(string s){
	if(s[0]=='m')
		return 1;
	if(s[0]=='w')
		return 3;
	if(s[0]=='f')
		return 5;
	if(s[1]=='h')
		return 4;
	if(s[0]=='t')
		return 2;
	if(s[1]=='a')
		return 6;
	return 7;
}
string s1,s2;
int mon[]={31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
int main(){
	//ios_base::sync_with_stdio(0); cin.tie(0);
	//cin>>n;
	cin>>s1;
	cin>>s2;
	int a=st(s1);
	//cout<<a<<"\n";
	int b=st(s2);
	//cout<<b<<'\n';
	int k=(b-a+7)%7;
	bool can=0;
	for(int i=0;i<11;i++){
		if((mon[i]-k)%7==0){
			can=1;
			break;
		}
	}
	if(can)
		cout<<"YES\n";
	else
		cout<<"NO\n";
}