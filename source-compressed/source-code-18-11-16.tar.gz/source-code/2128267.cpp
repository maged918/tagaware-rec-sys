//Language: GNU C++


#include<cstdio>
#include<cmath>
#include<set>
#include<stack>
#include<queue>
#include<deque>
#include<string>
#include<cstring>
#include<iostream>
#include<sstream>
#include<algorithm>
using namespace std;

int a[10010101],b[10010101],x[100100],y[100100];
bool v[11001000]={0};
int isp()
{
    int i,j;
    for(i=2;i<=10000;i++)
    if(!v[i])
    for(j=i+i;j<=10000000;j+=i)v[j]=1;
}
int main()
{
    int i,j,m,n,k;
    isp();
    while(cin>>n>>m)
    {
        memset(a,0,sizeof(a));
        memset(b,0,sizeof(b));
        int temp;
        for(i=1;i<=n;i++)
        {
            scanf("%d",&temp);
            x[i]=temp;
            int l=sqrt(temp);
            for(j=2;j<=l&&j<=temp;j++)
            {
                if(v[temp]==0)
                {
                    a[temp]++;
                    temp=0;
                    break;
                }
                while(temp%j==0)
                a[j]++,temp/=j;
            }
            a[temp]++;
        }
        for(i=1;i<=m;i++)
        {
            scanf("%d",&temp);
            y[i]=temp;
            int l=sqrt(temp);
            for(j=2;j<=l&&j<=temp;j++)
            {
                if(v[temp]==0)
                {
             //       cout<<"prime "<<temp<<endl;
                    b[temp]++;
                    temp=0;
                    break;
                }
                while(temp%j==0)
                b[j]++,temp/=j;
            }
            b[temp]++;
        }
   //     cout<<a[2]<<' '<<b[2]<<endl;
        for(i=1;i<=n;i++)
        {
            int temp=x[i];
            int l=sqrt(temp);
            for(j=2;j<=l&&j<=temp;j++)
            {
                if(v[temp]==0)
                {
                    if(b[temp])
                    x[i]/=temp,b[temp]--;
                    temp=1;
                    break;
                }
                while(temp%j==0&&b[j])
                temp/=j,x[i]/=j,b[j]--;
                while(temp%j==0)
                temp/=j;
            }
            if(temp!=1&&b[temp])
            b[temp]--,x[i]/=temp;
        }
        for(i=1;i<=m;i++)
        {
            int temp=y[i];
            int l=sqrt(temp);
            for(j=2;j<=l&&j<=temp;j++)
            {
                if(v[temp]==0)
                {
                    if(a[temp])
                    y[i]/=temp,a[temp]--;
                    temp=1;
                    break;
                }
                while(temp%j==0&&a[j])
                temp/=j,y[i]/=j,a[j]--;
                while(temp%j==0)
                temp/=j;
            }
            if(temp!=1&&a[temp])
            a[temp]--,y[i]/=temp;
        }
        printf("%d %d\n",n,m);
        for(i=1;i<n;i++)
        printf("%d ",x[i]);
        printf("%d\n",x[i]);
        for(j=1;j<m;j++)
        printf("%d ",y[j]);
        printf("%d\n",y[j]);
    }
}
