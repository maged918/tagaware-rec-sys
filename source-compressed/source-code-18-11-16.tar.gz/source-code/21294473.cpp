//Language: GNU C++14


#include <bits\stdc++.h>
using namespace std;
typedef vector<int> vi;
typedef vector<long long> vll;
typedef vector<vi> vvi;
typedef vector<pair<int, int> > vpi;
typedef pair<int,int> pii;
#define ll long long
#define ull unsigned long long
#define pb push_back
#define sz size()
#define sqr(x) ((x) * (x))
#define mp make_pair
#define F first
#define S second
#define all(c) c.begin(), c.end()
#define rall(c) c.rbegin(), c.rend()
#define tr(container, it) \
 for(typeof(container.begin()) it = container.begin(); it != container.end(); it++)
#define present(container, element) (container.find(element) != container.end()) // set, map
#define cpresent(container, element) (find(all(container), element) != container.end())\


const int MAX = 67;
int n, a[MAX][MAX];
int k, m;
inline bool check(int x, int y) {
    for(int i = 1; i <= n; i++) {
        swap(a[i][x], a[i][y]);
    }
    bool b = 0;
    for(int i = 1; i <= n; i++) {
        int x = 0;
        for(int j = 1; j <= m; j++) {
            if(a[i][j] != j) ++x;
        }
        if(x > 2) b = 1;
    }
    for(int i = 1; i <= n; ++i) {
        swap(a[i][x], a[i][y]);
    }
    if(!b) return true;
    else return false;
}
int main(int argc, char* argv[]) { ios_base::sync_with_stdio(false); cin.tie(NULL);
    #ifndef ONLINE_JUDGE
      freopen("in", "r", stdin); freopen("out", "w", stdout);
    #endif
    cin >> n >> m;
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= m; j++) {
            cin >> a[i][j];
        }
    }
    for(int i = 1; i <= m; i++) {
        for(int j = 1; j <= m; ++j) {
            if(check(i, j)) {
                cout << "YES";
                return 0;
            }
        }
    }
    cout << "NO";




    #ifndef ONLINE_JUDGE
      cerr << 1.0 * clock() / CLOCKS_PER_SEC << 's';
    #endif
	return 0;
}
