//Language: GNU C++11


//by yjz
#include<bits/stdc++.h>
using namespace std;
#define FF first
#define SS second
#define PB push_back 
#define MP make_pair
typedef long long ll;
const ll INF=1<<28;
const ll LINF=1ll<<61;
ll dp[10011],nxt[10011];
int n,a[10011],b[10011],c;
int main()
{
	scanf("%d%d",&n,&c);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=n;i++)scanf("%d",&b[i]);
	memset(dp,127,sizeof(dp));
	ll ans=dp[0];
	dp[0]=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j>=0;j--)
		{
			dp[j]=a[i]+dp[j]+1ll*j*c;
			if(j>0)dp[j]=min(dp[j],b[i]+dp[j-1]);
			if(i==n)ans=min(ans,dp[j]);
		}
	}
	cout<<ans<<endl;
	return 0;
}