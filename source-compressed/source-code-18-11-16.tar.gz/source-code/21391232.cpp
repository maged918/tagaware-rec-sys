//Language: GNU C++14


#include<bits/stdc++.h>
using namespace std;

bool vs[10000]={0},vs2[10000];
vector<int> ts,adj[1000],adjt[1000];

void dfs1(int x)
{
    if(vs[x]==1)
        return;

    vs[x]=1;
    for(int j=0;j<adj[x].size();j++)
    {
        dfs1(adj[x][j]);
    }
    ts.push_back(x);
}

void dfs2(int x,int c)
{
    if(vs2[x]!=0)
        return;

    vs2[x]=c;
    for(int j=0;j<adjt[x].size();j++)
    {
        dfs2(adjt[x][j],c);
    }
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    int n;
    cin>>n;

    vector<pair<int,int> > vctr;
    for(int i=1;i<=n;i++)
    {
        int u,v;
        cin>>u>>v;
        vctr.push_back(make_pair(u,v));
    }

    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            if(vctr[i-1].first==vctr[j-1].first || vctr[i-1].second==vctr[j-1].second)
            {
                adj[i].push_back(j);
                adj[j].push_back(i);
            }
        }
    }

    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<adj[i].size();j++)
            adjt[adj[i][j]].push_back(i);
    }

    for(int i=1;i<=n;i++)
        if(vs[i]==0)
            dfs1(i);

    int c=0;
    for(int i=ts.size()-1;i>=0;i--)
    {
        if(vs2[ts[i]]==0)
            dfs2(ts[i],++c);
    }
    cout<<c-1<<endl;
}

