//Language: GNU C++11


#include <bits/stdc++.h>

#define pp pop_back
#define pb push_back
#ifdef KTL
  #define fname ""
#else
  #define fname "kids."
#endif

using namespace std;
typedef long long ll;
typedef double ld;
typedef pair <ll, ll> PII;

const int N = 3e5 + 5;
#define f first
#define s second
#define mp make_pair
#define forn(i, x, n) for (int i = int(x); i <= int(n); ++i)
#define for1(i, n, x) for (int i = int(n); i >= int(x); --i)

int n, m, c, u, cnt[N], id[N], qh, qt;

pair < int, pair < int, int > > q[N * 50];

map < int, vector < int > > all;

int main()
{
  #ifdef wws
    freopen(fname"in", "r", stdin);
  #endif
  scanf("%d%d", &n, &m);
  for (int i = 1;i <= n;i++)
  {
    int x; scanf("%d", &x);
    all[x].pb(i);
  }
  for (int i = 1;i <= m;i++)
  {
    int x; scanf("%d", &x);
//    q.push(mp(x, mp(i, 0)));
    q[qt++] = mp(x, mp(i, 0));
  }
  while(qh < qt)
  {
    auto now = q[qh++];
    if (all.count(now.f) && all[now.f].size())
    {
      int v = all[now.f].back();
      id[v] = now.s.f;
      all[now.f].pop_back();
      cnt[now.s.f] = now.s.s;
      c++, u += now.s.s;
    }
    else
    {
      if (now.f > 1)
      {
        int x = (now.f + 1) / 2;
        q[qt++] = mp(x, mp(now.s.f, now.s.s + 1));
      }
    }
  }
  printf("%d %d\n", c, u);
  for (int i = 1;i <= m;i++) printf("%d ", cnt[i]);
  puts("");
  for (int i = 1;i <= n;i++) printf("%d ", id[i]);
  return 0;
}
