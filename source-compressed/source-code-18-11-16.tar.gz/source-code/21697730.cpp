//Language: GNU C++


#include <cmath>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

typedef long long ll;
const int mod=1000000007;

int fac[100010],inv[100010],g[100010],dp[1510][1510],s[1510];

int power(int x,int y)
{
	int t=1;
	while (y)
	{
		if (y&1) t=ll(t)*x%mod;
		x=ll(x)*x%mod;y>>=1;
	}
	return t;
}

int c(int n,int m)
{
	return ll(fac[n])*inv[m]%mod*inv[n-m]%mod;
}

int main()
{
	#ifndef ONLINE_JUDGE
		freopen("input.txt","r",stdin);
		freopen("output.txt","w",stdout);
	#endif
	int n,m;scanf("%d%d",&n,&m);
	int a,b;scanf("%d%d",&a,&b);
	int k;scanf("%d",&k);
	fac[0]=1;for (int i=1;i<=k;i++) fac[i]=ll(fac[i-1])*i%mod;
	inv[k]=power(fac[k],mod-2);for (int i=k;i;i--) inv[i-1]=ll(inv[i])*i%mod;
	a=ll(a)*power(b,mod-2)%mod;
	int t=1;
	for (int i=0;i<=m&&i<=k;i++)
	{
		g[i]=ll(c(k,i))*t%mod*power(1-a+mod,k-i)%mod;
		t=ll(t)*a%mod;
	}
	for (int i=1;i<m;i++) dp[0][i]=0;dp[0][m]=1;
	for (int i=1;i<=n;i++)
	{
		s[0]=0;for (int j=1;j<=m;j++) s[j]=(s[j-1]+dp[i-1][j])%mod;
		int s1=0,s2=0;
		for (int j=1;j<=m;j++)
		{
			s1=(s1+g[j-1])%mod;
			s2=(ll(g[j-1])*s[j-1]+s2)%mod;
			dp[i][j]=(ll(s[m]-s[m-j]+mod)*s1-s2+mod)%mod*g[m-j]%mod;
		}
	}
	int ans=0;
	for (int i=1;i<=m;i++) ans=(ans+dp[n][i])%mod;
	printf("%d\n",ans);
	return 0;
}