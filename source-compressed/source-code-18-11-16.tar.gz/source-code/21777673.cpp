//Language: GNU C++11



#include <bits/stdc++.h>

using namespace std;

typedef long long L;
const int MAXV = 1e5+15;

int n, s, t;
///dinic here ...
/*using edge = tuple<int,int,L,int>;
int V, layer[MAXV], last[MAXV];
edge graph[700100];
int top = 0;

void init_dinic(int N)
{
    fill(last, last + N + 1, -1);
    V = N;
}

void add_edge(int u, int v, L cap)
{
    graph[top] = make_tuple(u, v, cap, last[u]);
    last[u] = top++;
    graph[top] = make_tuple(v, u, 0, last[v]);
    last[v] = top++;
}

bool bfs()
{
    fill(layer, layer + V + 1, -1);
    layer[t] = 0;
    queue<int> q; q.push(t);
    while(!q.empty())
    {
        int node = q.front(); q.pop();
        for(int e = last[node]; e != -1; e = get<3>(graph[e]))
        {
            edge& din = graph[e^1];
            if(get<2>(din) > 0 && layer[get<0>(din)] == -1)
            {
                layer[get<0>(din)] = layer[node] + 1;
                q.push(get<0>(din));
            }
        }
    }
    return layer[s] != -1;
}

L dfs(int node, L flow)
{
    if(node == t)
        return flow;
    for(int e = last[node]; e != -1; e = get<3>(graph[e]))
    {
        edge& dout = graph[e];
        edge& din = graph[e^1];
        if(get<2>(dout) > 0 && layer[get<1>(dout)] + 1 == layer[get<0>(dout)])
        {
            L f = dfs(get<1>(dout), min(flow, get<2>(dout)));
            if(f > 0)
            {
                get<2>(dout) -= f;
                get<2>(din) += f;
                return f;
            }
        }
    }
    return 0;
}

int dinic()
{
    L totflow = 0, amt;
    while(bfs())
        while((amt = dfs(s, LLONG_MAX)) > 0)
            totflow += amt;
    return totflow;
}
*/

struct edge {
	int from, to, f;
};

namespace Dinic {
	const int MAX = 1e5 + 15;

	int s, t, pt[MAX], d[MAX];
	vector <edge> e;
	vector <int> g[MAX];
	queue <int> q;
	typedef int type; //change to ll if needed

	void init(int s_, int t_) {
		s = s_, t = t_;

		for(int i = s; i <= t; i++)
			g[i].clear();
		e.clear();
	}

	void addEdge(int from, int to, type c, type cr = 0) {
		edge ed;
		ed.from = from, ed.to = to, ed.f = c;
		e.push_back(ed);
		g[from].push_back((int) e.size() - 1);

		ed.from = to, ed.to = from, ed.f = cr;
		e.push_back(ed);
		g[to].push_back((int) e.size() - 1);
	}

	bool bfs() {
		for(int i = s; i <= t; i++)
			d[i] = -1;

		d[s] = 0;
		q.push(s);

		while(!q.empty()) {
			int u = q.front();
			q.pop();

			for(int i = 0; i < (int) g[u].size(); i++) {
				int id = g[u][i];
				int v = e[id].to;

				if(d[v] == -1 && e[id].f > 0) {
					d[v] = d[u] + 1;
					q.push(v);
				}
			}
		}

		return d[t] != -1;
	}

	type dfs(int u, type flow = 1e9) {
		if(u == t)
			return flow;

		for(; pt[u] < (int) g[u].size(); pt[u]++) {
			int id = g[u][pt[u]];
			int v = e[id].to;

			if(d[u] + 1 != d[v] || e[id].f == 0)
				continue;

			type pushed = dfs(v, min(flow, e[id].f));

			if(pushed > 0) {
				e[id].f -= pushed;
				e[id ^ 1].f += pushed;
				return pushed;
			}
		}

		return 0;
	}

	type getMaxFlow() {
		type ans = 0;

		while(1) {
			if(!bfs())
				break;

			for(int i = s; i <= t; i++)
				pt[i] = 0;

			type f;
			while((f = dfs(s)))
				ans += f;
		}

		return ans;
	}
}
L tot[101];
int get_id(const string& size)
{
    if(size == "S")
        return 1;
    if(size == "M")
        return 2;
    if(size == "L")
        return 3;
    if(size == "XL")
        return 4;
    if(size == "XXL")
        return 5;
    return 6;
}
int main()
{
    //freopen("a.in", "r", stdin);

    s = 0;
    for(int i=1;i<=6;i++)
    {
        scanf("%I64d", &tot[i]);
        //add_edge(s, i, tot);
    }

    scanf("%d\n", &n);
    t = n+7;

    //init_dinic(t + 1);
    Dinic::init(0,t);

    for(int i = 1; i <= 6; i++)
    {
        Dinic::addEdge(i, t, tot[i]);
    }

    for(int i=1;i<=n;i++)
    {
        char cad[107]; scanf("%s", cad);
        int len = strlen(cad);
        int comma=-1;
        for(int i=0;i<len;i++)
            if(cad[i] == ',')
                comma = i;
        if(comma == -1)
            Dinic::addEdge(i+6, get_id(string(cad)), 1);
        else
        {
            string sz0="", sz1="";
            for(int i=0;i<comma;i++)
                sz0 += cad[i];
            for(int i=comma+1;i<len;i++)
                sz1 += cad[i];
            Dinic::addEdge(i+6, get_id(sz0), 1);
            Dinic::addEdge(i+6, get_id(sz1), 1);
        }
        Dinic::addEdge(s, i+6, 1);
    }

    int max_match = Dinic::getMaxFlow();
    if(max_match != n)
        printf("NO\n");
    else
    {
        printf("YES\n");
        for(int x = 7;x <= n+6; x++)
            for(int e: Dinic::g[x])
            {
                if(Dinic::e[e].f == 0 && Dinic::e[e].to != s)
                {
                    if(Dinic::e[e].to == 1)
                            printf("S");
                    else if(Dinic::e[e].to == 2)
                            printf("M");
                    else if(Dinic::e[e].to == 3)
                            printf("L");
                    else if(Dinic::e[e].to == 4)
                            printf("XL");
                    else if(Dinic::e[e].to == 5)
                            printf("XXL");
                    else if(Dinic::e[e].to == 6)
                            printf("XXXL");
                    printf("\n");
                    break;
                }
            }
    }

    return 0;
}