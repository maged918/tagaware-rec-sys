//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

// static int val;

int n;

int printAnswer(int x1, int y1, int x2, int y2) {
	int x11 = 1, y11 = 2, x12 = 4, y12 = 2, x21 = 1, y21 = 6, x22 = 4, y22 = 9;
	int c = 0;
	if (x1 <= x11 && y1 <= y11 && x2 >= x12 && y2 >= y12) ++c;
	if (x1 <= x21 && y1 <= y21 && x2 >= x22 && y2 >= y22) ++c;
	return c;
}

void printQuestion(int x1, int y1, int x2, int y2) {
	printf("? %d %d %d %d\n", x1, y1, x2, y2);
	// printf("%d\n", val = printAnswer(x1, y1, x2, y2));
	fflush(stdout);
}

int getAnswer() {
	int res;
	scanf("%d", &res);
	return res;
	// return val;
}

int isX() {
	int l = 1, r = n, res = 0;
	while (l <= r) {
		int mid = (l+r)/2;
		printQuestion(1, 1, mid, n);
		int v = getAnswer();
		if (v >= 1) {
			if (v == 1) res = mid;
			r = mid-1;
		}
		else l = mid+1;
	}
	if (res == 0) return 0;
	printQuestion(res+1, 1, n, n);
	return getAnswer() == 1 ? res : 0;
}

int isY() {
	int l = 1, r = n, res = 0;
	while (l <= r) {
		int mid = (l+r)/2;
		printQuestion(1, 1, n, mid);
		int v = getAnswer();
		if (v >= 1) {
			if (v == 1) res = mid;
			r = mid-1;
		}
		else l = mid+1;
	}
	if (res == 0) return false;
	printQuestion(1, res+1, n, n);
	return getAnswer() == 1 ? res : 0;
}

void findRec(int &x1, int &y1, int &x2, int &y2, int lx, int ly, int rx, int ry) {
	if (x2 == 0) {
		int l = lx, r = rx;
		while (l <= r) {
			int mid = (l+r)/2;
			printQuestion(lx, ly, mid, ry);
			int v = getAnswer();
			if (v == 1) {
				x2 = mid;
				r = mid-1;
			}
			else l = mid+1;
		}
	}

	{
		int l = lx, r = x2;
		while (l <= r) {
			int mid = (l+r)/2;
			printQuestion(mid, ly, x2, ry);
			int v = getAnswer();
			if (v == 1) {
				x1 = mid;
				l = mid+1;
			}
			else r = mid-1;
		}
	}
	
	if (y2 == 0) {
		int l = ly, r = ry;
		while (l <= r) {
			int mid = (l+r)/2;
			printQuestion(lx, ly, rx, mid);
			int v = getAnswer();
			if (v == 1) {
				y2 = mid;
				r = mid-1;
			}
			else l = mid+1;
		}
	}

	{
		int l = ly, r = y2;
		while (l <= r) {
			int mid = (l+r)/2;
			printQuestion(lx, mid, rx, y2);
			int v = getAnswer();
			if (v == 1) {
				y1 = mid;
				l = mid+1;
			}
			else r = mid-1;
		}
	}
}

int main() {
	scanf("%d", &n);
	
	int x11 = 0, y11 = 0, x12 = 0, y12 = 0, x21 = 0, y21 = 0, x22 = 0, y22 = 0;

	int v = isX();
	if (v > 0) {
		x12 = v;
		findRec(x11, y11, x12, y12, 1, 1, v, n);
		findRec(x21, y21, x22, y22, v+1, 1, n, n);
	}
	else {
		v = isY();
		y12 = v;
		findRec(x11, y11, x12, y12, 1, 1, n, v);
		findRec(x21, y21, x22, y22, 1, v+1, n, n);
	}
	printf("! %d %d %d %d %d %d %d %d\n", x11, y11, x12, y12, x21, y21, x22, y22);
	fflush(stdout);
	return 0;
}