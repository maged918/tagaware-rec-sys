//Language: GNU C++14


#include <bits/stdc++.h>
#define ALL(a) (a).begin(), (a).end()
#define FIN ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0)
#define FOR(x,n) for(int x = 0; x < n; x++)
#define FORR(x,n) for(int x = n-1; x >= 0; x--)
#define SZ(a) ((int)(a).size())
using namespace std;
typedef long long ll;

const int MXN = 1e6+1;
ll U[MXN], US[MXN], D[MXN], DS[MXN];

int main() {
  int N; cin >> N;
  string s; cin >> s;
  int Us = 1, Ds = 1;
  FOR(x,N) {
    if(s[x] == 'U')
      U[Us] = x+1, Us++;
    else
      D[Ds] = x+1, Ds++;
  }
  
  FOR(x,N)
    US[x+1] = U[x+1] + US[x], DS[x+1] = D[x+1] + DS[x];
  
  int lowerU = 0, upperD = Ds-1, upperDOFF = 1;
  
  FOR(x,N) {
    if(s[x] == 'U') {
      if(lowerU < upperD) {
        ll tmp = 2LL * (DS[upperDOFF+lowerU]-DS[upperDOFF-1]);
        tmp -= x+1;
        tmp -= 2 * US[lowerU];
        cout << tmp << " \n"[x==N-1];
      } else if(lowerU == upperD) {
        ll tmp = 2LL * (DS[Ds-1]-DS[upperDOFF-1]);
        tmp -= x+1;
        tmp -= 2 * US[lowerU];
        tmp += N+1;
        cout << tmp << " \n"[x==N-1];
      } else {
        ll tmp = 2LL * (DS[Ds-1]-DS[upperDOFF-1]);
        tmp -= x+1;
        tmp -= 2 * (US[lowerU] - US[lowerU-upperD]);
        tmp += N+1;
        cout << tmp << " \n"[x==N-1];
      }
      lowerU++;
    } else {
      upperD--;
      upperDOFF++;
      
      if(lowerU < upperD) {
        ll tmp = 2LL * (DS[upperDOFF+lowerU-1]-DS[upperDOFF-1]);
        tmp += x+1;
        tmp -= 2LL * US[lowerU];
        cout << tmp << " \n"[x==N-1];
      } else if(lowerU == upperD) {
        ll tmp = 2LL * (DS[Ds-1]-DS[upperDOFF-1]);
        tmp += x+1;
        tmp -= 2LL * US[lowerU];
        cout << tmp << " \n"[x==N-1];
      } else {
        ll tmp = 2LL * (DS[Ds-1]-DS[upperDOFF-1]);
        tmp += x+1;
        tmp -= 2LL * (US[lowerU] - US[lowerU-upperD-1]);
        tmp += N+1;
        cout << tmp << " \n"[x==N-1];
      }
    }
  }
}