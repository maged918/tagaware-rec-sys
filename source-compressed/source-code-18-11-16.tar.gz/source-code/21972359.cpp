//Language: GNU C++


#include<cstdio>  
#include <cstring>  
#include<cmath>  
#include<iostream>  
#include<algorithm>  
#include<vector>  
#include <map>  
using namespace std;  
  
int main()   
{  
    int i;  
    int n, c, cnt=0;  
    int last=0;   
    int now;  
    scanf("%d%d", &n, &c);  
    for(i=0;i<n;i++)   
    {  
        scanf("%d", &now);  
        if(now>last+c)   
        {  
            cnt=0;  
        }  
        cnt++;  
        last=now;  
    }  
    printf("%d\n", cnt);  
    return 0;  
}  