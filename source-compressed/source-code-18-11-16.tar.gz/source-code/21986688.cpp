//Language: GNU C++11


#include <iostream>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <utility>
#include <algorithm>
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define vi vector<int>
#define pi pair<int,int>
using namespace std;
int main()
{
    long long x1,y1,x2,y2,a,b,c,ans=0,n;
    cin >> x1 >> y1 >> x2 >> y2 >> n;
    while(n--)
    {
        cin >> a >> b >> c;
        long long m = a*x1+b*y1+c,k = a*x2+b*y2+c;
        if((m<0&&k>0) || (m>0 && k<0))
            ans++;
    }
    cout << ans;
    return 0;
}
