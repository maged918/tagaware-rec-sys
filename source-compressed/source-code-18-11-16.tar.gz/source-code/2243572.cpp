//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <vector>
using namespace std;

typedef long long LL;

template <class T> T gmin(T u,T v)
{return (u < v) ? u : v;}
template <class T> T gmax(T u,T v)
{return (u > v) ? u : v;}
template <class T> T gcd(T u,T v)
{if (v == 0) return u;return (u % v == 0) ? v : gcd(v,u%v);}

int n,m;
LL aa[100111],bb[100111],qq[100111];
bool Cmp(const int &u,const int &v)
{
	return (u > v);
}
void Calc(int now)
{
	LL ll,rr,kk,i;
	bb[now]=0;
	for (i=1,ll=rr=0,kk=1;rr < (n-1);++i)
	{
		kk *= now;
		ll = rr;
		rr += kk;
		if (rr >= n) rr = n-1;
		bb[now] += (aa[rr] - aa[ll]) * i;
	}
}
int main()
{
	int i;
	scanf("%d",&n);
	for (i=0;i<n;++i)
		scanf("%I64d",&aa[i]);
	sort(aa,aa+n,Cmp);
	for (i=1;i<n;++i)
		aa[i]+=aa[i-1];
	scanf("%d",&m);
	for (i=1;i<=m;++i)
	{
		scanf("%I64d",&qq[i]);
		bb[qq[i]]=-1;
	}
	for (i=1;i<=m;++i)
	{
		if (bb[qq[i]] < 0) Calc(qq[i]);
		printf("%I64d",bb[qq[i]]);
		if (i == m) printf("\n"); else printf(" ");
	}
	return 0;
}
