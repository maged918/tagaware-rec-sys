//Language: GNU C++


#include <cstdio>

using namespace std;

int R, S;
int isFractal[510][510][1 << 4][10], sumWhite[510][510];

char grid[510][510];

inline bool check( int mask, int r, int s ){

    if ( ( mask & ( 1 << 0 ) ) != 0 && grid[r][s] == '.' ) return false;
    if ( ( mask & ( 1 << 0 ) ) == 0 && grid[r][s] == '*' ) return false;


    if ( ( mask & ( 1 << 1 ) ) != 0 && grid[r][s + 1] == '.' ) return false;
    if ( ( mask & ( 1 << 1 ) ) == 0 && grid[r][s + 1] == '*' ) return false;

    if ( ( mask & ( 1 << 2 ) ) != 0 && grid[r + 1][s] == '.' ) return false;
    if ( ( mask & ( 1 << 2 ) ) == 0 && grid[r + 1][s] == '*' ) return false;

    if ( ( mask & ( 1 << 3 ) ) != 0 && grid[r + 1][s + 1] == '.' ) return false;
    if ( ( mask & ( 1 << 3 ) ) == 0 && grid[r + 1][s + 1] == '*' ) return false;

    return true;

}

inline void init(){

    for ( int i = 1; i <= R; ++i ){
        for ( int j = 1; j <= S; ++j ){
            sumWhite[i][j] = sumWhite[i - 1][j] + sumWhite[i][j - 1] - sumWhite[i - 1][j - 1] + ( grid[i - 1][j - 1] == '.' );
        }
    }

}

inline int getSum( int r, int s, int x ){
    return sumWhite[r + x][s + x] - sumWhite[r][s + x] - sumWhite[r + x][s] + sumWhite[r][s];
}

inline  bool realCheck( int r, int s, int mask, int dim, int ind ){

    if ( ( mask & ( 1 << 0 ) ) != 0 ){
        if ( getSum( r, s, dim / 2 ) > 0 ) return false;
    } else{
        if ( isFractal[r][s][mask][ind - 1] == 0 ) return false;
    }

    if ( ( mask & ( 1 << 1 ) ) != 0 ){
        if ( getSum( r, s + dim / 2, dim / 2 ) > 0 ) return false;
    } else{
        if ( isFractal[r][s + dim / 2][mask][ind - 1] == 0 ) return false;
    }

    if ( ( mask & ( 1 << 2 ) ) != 0 ){
        if ( getSum( r + dim / 2, s, dim / 2 ) > 0 ) return false;
    } else{
        if ( isFractal[r + dim / 2 ][s][mask][ind - 1] == 0 ) return false;
    }

    if ( ( mask & ( 1 << 3 ) ) != 0 ){
        if ( getSum( r + dim / 2, s + dim / 2, dim / 2 ) > 0 ) return false;
    } else{
        if ( isFractal[r + dim / 2][s + dim / 2][mask][ind - 1] == 0 ) return false;
    }

    return true;

}

int main( void ){

    scanf( "%d%d", &R, &S );
    for ( int i = 0; i < R; ++i ) scanf( "%s", grid[i] );

    init();
/*
    for ( int i = 1; i <= R; ++i ){
        for ( int j = 1 ; j <= S; ++j ) printf( "%d ", sumWhite[i][j] );
        printf( "\n" );
    }
*/
    int sol = 0;

            for ( int mask = 0; mask < ( 1 << 4 ); ++mask ){
                for ( int dim = 1; ( 1 << dim ) < 512; ++dim ){

                    for ( int i = 0; i < R; ++i ){
                            for ( int j = 0; j < S; ++j ){
                                if ( i + ( 1 << dim ) > R || j + ( 1 << dim ) > S ) continue;
                                if ( dim == 1 ){
                                    isFractal[i][j][mask][dim] = check( mask, i, j );
                //                    if ( mask == 15 ) printf( "%d\n", isFractal[i][j][mask][dim] );
                                    continue;
                                }

                                isFractal[i][j][mask][dim] = realCheck( i, j, mask, 1 << dim, dim );
                                if ( isFractal[i][j][mask][dim] == 1 ) ++sol;

                                }

                    }
                }
            }

    printf( "%d\n", sol );

    return 0;

}
