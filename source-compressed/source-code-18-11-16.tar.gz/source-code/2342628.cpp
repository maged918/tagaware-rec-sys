//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<cctype>
#include<ctime>
#include<climits>
#include<memory>
#include<utility>
#include<functional>
#include<iomanip>
#include<sstream>
#include<fstream>
#include<string>
#include<vector>
#include<deque>
#include<list>
#include<stack>
#include<queue>
#include<set>
#include<bitset>
#include<map>
#define sq(x) (x)*(x)
#define LL long long
#define bugout cout << "<bug>" << endl
#define pb push_back
#define pf push_front
#define mp make_pair
#define fs first
#define sc second
using namespace std;

const long long LLMAX = 0x7fffffffffffffffLL;
const long long LLMIN = 0x8000000000000000LL;
const int IMAX = 0x7fffffff;
const int IMIN = 0x80000000;
const int maxn =  + 10;
const double eps = 10e-7;
LL n, x;


LL digit(LL x) {
    LL ans = 0;
    while(x) {
        ans += x % 10;
        x /= 10;
    }
    return ans;
}
int main() {
    //freopen("in.txt", "r", stdin);
    //freopen("Bout.txt", "w", stdout);

//    for(LL n = 1LL; n <= 1000LL; n++) {
//        LL temp1 = (LL) sqrt((double) (n/2));
//        LL temp2 = (LL) sqrt((double) (n));
//        for(LL x = temp1; x <= temp2; x++) {
//            if(x * x + x * digit(x) == n) {
//                printf("Case n = %I64d:\n", n);
//                printf("  x = %I64d\n", x);
//                break;
//            }
//        }
//    }

    while(~scanf("%I64d", &n)) {
        LL square = (LL) sqrt((double) (n));
        bool judge = false;
        int cnt = 0;
        LL ans = square;
        for(LL x = square; x > 0; x--) {
            if(x * x + x * digit(x) == n) {
                judge = true;
                ans = x;
            }
            cnt++;
            if(cnt > 10000) break;
        }
        if(judge) printf("%I64d\n", ans);
        else printf("-1\n");
    }
    return 0;
}
