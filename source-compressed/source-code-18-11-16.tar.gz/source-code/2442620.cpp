//Language: GNU C++


/*
Author: LJQ
PROG: Codeforces Beta Round #69 Div1 E. Martian Food
DATE: 2012.10.27
*/
#include <cstdio>
#include <iostream>

using namespace std;

long double R, r, ret;
int K;

void init()
{
	cin >> R >> r >> K;
}

void work()
{
	long double rd, X, Y;
	rd = (1 / r - 1 / R) / 4;
	X = (1 / r + 1 / R) / 4;
	Y = K * 2 * rd;
	ret = rd / (X * X + Y * Y - rd * rd);
}

void print()
{
	printf("%.12lf\n", (double)ret);
}

int main()
{
	int T;
	scanf("%d", &T);
	for (int i = 0; i < T; i ++){
		init();
		work();
		print();
	}
	return 0;
}
