//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <set>

using namespace std;
typedef long long ll;

ll ary[100100],gnum[100100],orig[100100];
multiset <ll> g1,g2;

int main()
{
	int n;
	ll h,minf,maxf,tmp,v1,v2,v3,v4,mx1,mn1,mx2,mn2;
	int i,j,k,l,r,cur;
	while(cin>>n>>h)
	{
		for(i=0;i<n;i++)
		{
			cin>>ary[i];
			orig[i]=ary[i];
		}
		if(n==2)
		{
			cout<<0<<endl<<1<<" "<<2<<endl;
			continue;
		}
		sort(ary,ary+n);
		mx1=max(ary[n-1]+ary[n-2],ary[n-1]+ary[0]+h);
		mn1=min(ary[1]+ary[0]+h,ary[1]+ary[2]);

		mx2=ary[n-1]+ary[n-2];
		mn2=ary[1]+ary[0];

		if((mx2-mn2)>(mx1-mn1))
		{
			v1=mx1-mn1;
			tmp=ary[0];
		}
		else
		{
			v1=mx2-mn2;
			tmp=(-1);
		}

		cout<<v1<<endl;
		for(i=0;i<n-1;i++)
		{
			if(orig[i]==tmp)
			{
				tmp=(-1);
				cout<<1<<" ";
			}
			else
				cout<<2<<" ";
		}
		if(orig[i]==tmp)
			cout<<1;
		else
			cout<<2;
		cout<<endl;
	}
		
}
