//Language: GNU C++


#include<cstdlib>
#include<cstdio>
#include<vector>
#include<memory.h>
#define N 3333
#define F first
#define S second

using namespace std;
int tp,ck,n,i,s,d,ans = N;
vector < pair <int,int> > f[N];

void dfs2(int x,int k,int r,int u){
tp+=k;ck=max(ck,r);
r=max(r,0);
for(int j=0;j<f[x].size();j++)if(f[x][j].F!=u){
 if(f[x][j].S == 1){
  dfs2(f[x][j].F,1,r+1,x);
 }
 if(f[x][j].S == 0){
  dfs2(f[x][j].F,0,r-1,x);
 }
}
}

main(){
//freopen("input.txt","r",stdin);
 //freopen("output.txt","w",stdout);
scanf("%d",&n);
 for(i=1;i<n;i++){
  scanf("%d%d",&s,&d);
   f[s].push_back(make_pair(d,0));
   f[d].push_back(make_pair(s,1));
 }
for(i=1;i<=n;i++){
 tp = 0;ck = 0;
 dfs2(i,0,0,0);
 ans = min(ans,tp-ck);
}
printf("%d\n",ans);
}
