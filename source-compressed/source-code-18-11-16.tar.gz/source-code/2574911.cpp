//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<vector>
#include<map>
using namespace std;
struct T1
{
    int u,v;
};
const int maxn=100100;
T1 e[maxn];
vector<int > a[maxn];
map<int ,int >p[maxn];
int d[maxn];
int n,m,h,t;
int ans1[maxn],ans2[maxn];
int pp[maxn];
bool cheak(int u,int v,int h,int t)
{
    int tot1=0,tot2=0,tot3=0;
    //if (a[u])
    for (int i=0; i<a[u].size(); i++)
    {
        int k=a[u][i];
        if (k==v) continue;
        if (p[k].find(v)!=p[k].end())
        {
            pp[++tot3]=k;
            continue;
        }
        ans1[++tot1]=k;
        if (tot1>=h) break;
    }
    if (tot1+tot3<h) return 0;
    if (a[v].size()-tot3-1+tot3-(h-tot1)<t) return 0;
    while (tot1<h)
    {
        ans1[++tot1]=pp[tot3];
        tot3--;
    }
    for (int i=0; i<a[v].size(); i++)
    {
        int k=a[v][i];
        if (k==u) continue;
        if (p[k].find(u)!=p[k].end())
        continue;
        ans2[++tot2]=k;
        if (tot2>=t) break;
    }
    if (tot2+tot3<t) return false;
    while (tot2<t)
    {
        ans2[++tot2]=pp[tot3];
        tot3--;
    }
    return true;
}
int main()
{
    //freopen("input.txt","r",stdin);
    cin>>n>>m>>h>>t;
    for (int i=1; i<=m; i++)
    {
        int u,v;
        cin>>e[i].u>>e[i].v;
        u=e[i].u; v=e[i].v;
        a[u].push_back(v);
        a[v].push_back(u);
        d[u]++; d[v]++;
        p[u][v]=1;
        p[v][u]=1;
    }
    for (int i=1; i<=m; i++)
    {
        int u=e[i].u;
        int v=e[i].v;

        if (d[u]>=h+1&&d[v]>=t+1)
        if (cheak(u,v,h,t))
        {
            cout<<"YES"<<endl;
            cout<<u<<' '<<v<<endl;
            for (int j=1; j<=h; j++) cout<<ans1[j]<<' ';
            cout<<endl;
            for (int j=1; j<=t; j++) cout<<ans2[j]<<' ';
            cout<<endl;
            return 0;
        }
        int tt=u; u=v; v=tt;
        if (d[u]>=h+1&&d[v]>=t+1)
        if (cheak(u,v,h,t))
        {
            cout<<"YES"<<endl;
            cout<<u<<' '<<v<<endl;
            for (int j=1; j<=h; j++) cout<<ans1[j]<<' ';
            cout<<endl;
            for (int j=1; j<=t; j++) cout<<ans2[j]<<' ';
            cout<<endl;
            return 0;
        }
    }
    cout<<"NO"<<endl;
}
