//Language: GNU C++


#include<iostream>
#include<sstream>
#include<vector>
#include<algorithm>
#include<set>
#include<map>
#include<queue>
#include<complex>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cassert>
using namespace std;

#define rep(i,n) for(int i=0;i<(int)n;i++)
#define each(i,c) for(__typeof(c.begin()) i=c.begin();i!=c.end();i++)
#define pb push_back
#define mp make_pair
#define all(c) c.begin(),c.end()
#define dbg(x) cerr<<__LINE__<<": "<<#x<<" = "<<(x)<<endl

typedef vector<int> vi;
typedef pair<int,int> pi;
typedef long long ll;
const int inf=(int)1e9;
const double EPS=1e-9, INF=1e12;

const int MX = 100010;
const int SIZE = 3500;
int n, N;
int p[MX];
string name[MX];
map<string, int> id;
vector<vi> e;

int sz;
int tour[MX * 2];
int depth[MX];
int leftp[MX], rightp[MX];
vi seq[MX];
vi pos[MX];

int q;
int ans[MX];
vector<pair<pi, pi> > qs[MX]; //r, l / SIZE, l, id [depth]

void rec(int c, int p, int d){
	depth[c] = d;
	leftp[c] = sz;
	tour[sz++] = c;
	rep(i, e[c].size()) if(e[c][i] != p){
		rec(e[c][i], c, d + 1);
	}
	rightp[c] = sz;
	tour[sz++] = c;
}

int main(){
	cin >> n;
	e.resize(n + 1);
	rep(i, n){
		cin >> name[i] >> p[i];
		if(p[i] == 0) p[i] = n;
		else p[i]--;
		e[p[i]].pb(i);
		e[i].pb(p[i]);
		
		if(!id.count(name[i])) id[name[i]] = N++;
	}
	rec(n, n, 0);
	rep(i, sz){
		seq[depth[tour[i]]].pb(id[name[tour[i]]]);
		pos[depth[tour[i]]].pb(i);
	}
	cin >> q;
	rep(i, q){
		int v, k;
		cin >> v >> k;
		v--;
		
		int L = leftp[v];
		int R = rightp[v];
		int d = depth[v] + k;
		
		if(d >= MX) d = MX - 1;
		int l = lower_bound(all(pos[d]), L) - pos[d].begin();
		int r = upper_bound(all(pos[d]), R) - pos[d].begin();
		qs[d].pb(mp(mp(r, l / SIZE), mp(l, i)));
	}
	rep(d, MX){
		if(qs[d].empty()) continue;
		sort(all(qs[d]));
		int curl = 0;
		int curr = 0;
		int c = 0;
		map<int, int> cnt;
		vi &v = seq[d];
		
		rep(i, qs[d].size()){
			int l = qs[d][i].second.first;
			int r = qs[d][i].first.first;
			while(curr < r){
				if(cnt[v[curr++]]++ == 0) c++;
			}
			while(curl < l){
				if(--cnt[v[curl++]] == 0) c--;
			}
			while(l < curl){
				if(cnt[v[--curl]]++ == 0) c++;
			}
			ans[qs[d][i].second.second] = c;
		}
	}
	rep(i, q) cout << ans[i] << endl;
	
	return 0;
}
