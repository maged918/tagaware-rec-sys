//Language: GNU C++


#include <bits/stdc++.h>
#define f(i,x,y) for (int i = (x); i < (y); i++)
#define fd(i,x,y) for(int i = x; i>= y; i--)
#define FOR(it,A) for(typeof A.begin() it = A.begin(); it!=A.end(); it++)
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()
#define vint vector<int>
#define ll long long
#define clr(A,x) memset(A, x, sizeof A)
#define pb push_back
#define pii pair<int,int>
#define fst first
#define snd second
#define ones(x) __builtin_popcount(x)
#define cua(x) (x)*(x)
#define oo (1<<30)
using namespace std;
string calle;
int lim,n,casas[500000 + 10],dulces;

bool sepuede(int cant)
{
    int t = 0, idxcasa = 0 , tam = 0, cantdulces = 0;

    f(i,0,n)
    {  if(cantdulces == dulces) break;

        if(calle[i]=='H')
        {   if(cant > 0) cant-- , t++,cantdulces++;
            else//cant == 0
            casas[tam++] = i , t++;
        }
        else
            if(calle[i]=='S')
            {    cant++; t++;
                if(tam - idxcasa > 0 && cant >= tam - idxcasa)//regresamos
                { cantdulces += tam - idxcasa ; cant -=(tam-idxcasa);
                    if(cantdulces==dulces)
                    t+=i - casas[idxcasa];
                    else
                    t+=2*(i - casas[idxcasa]), idxcasa = tam ;
                }
            }
            else
            t++;
    }
return t<=lim;
}

int main()
{
   while(cin>>n>>lim>>calle)
   {
        int L = -1 , R = 1000000000;
        dulces = 0;


        f(i,0,n)
        if(calle[i] == 'H') L++,dulces++;
        else
            if(calle[i]=='S')L--;
            else{}
        if(L<=0 && 1 + 2*(n-1)<=lim){puts("0"); return 0;}

        L = max(L,-1);//cuidado

          while(L + 1 < R)
           {    int mid = (L+R)/2;
            if(sepuede(mid)) R = mid;
            else L = mid;
           }

        if(R==1000000000)puts("-1");
        else cout<<R<<endl;
   }

    return 0;
}
