//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
using namespace std;

/*
struct Node
{
	int val,pos;
}node[100010];

bool cmp(Node a,Node b)
{
	return a.val<b.val;
}
*/

bool isSorted(int arr[],int n)
{
	bool flag=true;
	for(int i=1;i<n;i++)
		if(arr[i]<arr[i-1])
		{
			flag=false;
			break;
		}
	if(flag)return true;
	flag=true;
	for(int i=1;i<n;i++)
		if(arr[i]>arr[i-1])
		{
			flag=false;
			break;
		}
	if(flag)return true;
	return false;
}

int a[100010];

int main()
{
	int n;
	scanf("%d",&n);
	set<int> ha;
	for(int i=0;i<n;i++)
	{
		scanf("%d",a+i);
		ha.insert(a[i]);
	}
	if(n<=2||ha.size()<2)
	{
		cout<<-1<<endl;
		return 0;
	}
	if(ha.size()==2)
	{
		if(isSorted(a,n))
		{
			if(a[1]==a[0])
				cout<<2<<" "<<n<<endl;
			else
				cout<<1<<" "<<n-1<<endl;
		}
		else
		{
			if(n==3)
				cout<<-1<<endl;
			else
			{
				for(int i=1;i<n-1;i++)
					if(a[i]!=a[i+1])
					{
						cout<<i+1<<" "<<i+2<<endl;
						break;
					}
			}
		}
		return 0;
	}
	if(isSorted(a,n))
	{
		int idx=0;
		while(a[0]==a[idx])idx++;
		cout<<idx+1<<" "<<n<<endl;
	}
	else
	{
		int mip=0,mxp=n-1;
		for(int i=0;i<n;i++)
		{
			if(a[mip]>a[i])
				mip=i;
			if(a[mxp]<a[i])
				mxp=i;
		}
		cout<<mip+1<<" "<<mxp+1<<endl;
	}
	return 0;
}
