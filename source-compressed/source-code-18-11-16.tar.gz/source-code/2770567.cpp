//Language: GNU C++


#include <cstdio>

int Tree[20][400000];
bool Mark[20][400000];
int a[100000];
void init(int tree[],bool mark[],int at,int l,int r,int v){
    if (l==r){
        tree[at]=((a[l]&v)?1:0);
        mark[at]=false;
        return;
    }
    int mid=(l+r)/2;
    init(tree,mark,2*at,l,mid,v);
    init(tree,mark,2*at+1,mid+1,r,v);
    tree[at]=tree[2*at]+tree[2*at+1];
}
void spread(int tree[],bool mark[],int at,int l,int r){
    mark[at]=false;
    if (l==r)
        return;
    mark[2*at]^=true;
    mark[2*at+1]^=true;
    int mid=(l+r)/2;
    tree[2*at]=mid-l+1-tree[2*at];
    tree[2*at+1]=r-mid-tree[2*at+1];
    tree[at]=tree[2*at]+tree[2*at+1];
}
void update(int tree[],bool mark[],int at,int l,int r,int dl,int dr){
    if (mark[at])
        spread(tree,mark,at,l,r);
    if (dl<=l&&r<=dr){
        tree[at]=r-l+1-tree[at];
        mark[at]^=true;
        return;
    }
    int mid=(l+r)/2;
    if (dl<=mid)
        update(tree,mark,2*at,l,mid,dl,dr);
    if (dr>=mid+1)
        update(tree,mark,2*at+1,mid+1,r,dl,dr);
    tree[at]=tree[2*at]+tree[2*at+1];
}
int sum;
void query(int tree[],bool mark[],int at,int l,int r,int dl,int dr){
    if (mark[at])
        spread(tree,mark,at,l,r);
    if (dl<=l&&r<=dr){
        sum+=tree[at];
        return;
    }
    int mid=(l+r)/2;
    if (dl<=mid)
        query(tree,mark,2*at,l,mid,dl,dr);
    if (dr>=mid+1)
        query(tree,mark,2*at+1,mid+1,r,dl,dr);
    tree[at]=tree[2*at]+tree[2*at+1];
}    
int main()
{
    int n;
    scanf("%d",&n);
    for (int i=0;i<n;i++)
        scanf("%d",&a[i]);
    for (int i=0,j=1;i<20;i++,j<<=1)
        init(Tree[i],Mark[i],1,0,n-1,j);
    int m,tmp,l,r,w;
    scanf("%d",&m);
    for (int i=0;i<m;i++){
        scanf("%d",&tmp);
        if (tmp==1){
            scanf("%d %d",&l,&r);
            long long ans=0;
            for (int i=0,j=1;i<20;i++,j<<=1){
                sum=0;
                query(Tree[i],Mark[i],1,0,n-1,l-1,r-1);
                ans+=(long long)j*sum;
            }
            printf("%I64d\n",ans);
        }
        else{
            scanf("%d %d %d",&l,&r,&w);
            for (int i=0,j=1;i<20;i++,j<<=1)
                if (j&w)
                    update(Tree[i],Mark[i],1,0,n-1,l-1,r-1);
        }
    }
    //scanf(" ");
}
