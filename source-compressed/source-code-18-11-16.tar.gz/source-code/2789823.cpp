//Language: GNU C++


//
//  main.cpp
//  253A
//
//  Created by pooya mirhosseini on 12/16/12.
//  Copyright (c) 2012 pooya mirhosseini. All rights reserved.
//

#include <iostream>
#include <algorithm>
#include <fstream>

using namespace std;


ifstream fin ("input.txt");
ofstream fout ("output.txt");

#define cin fin
#define cout fout

int main(int argc, const char * argv[])
{
    int n , m ;
    cin >> n >> m ;
    char b = 'B';
    char g = 'G';
    if ( n < m )
    {
        swap ( b , g );
        swap ( n , m );
    }
    for ( int i = 1 ; i <= ( m + n ) ; i++ )
    {
        if (( i % 2 == 1 ) || (( ( i + 1 ) / 2 > m ) && ( i / 2 <= n )))
            cout << b ;
        else if ( ( i + 1 ) / 2 <= m )
            cout << g ;
    }
    cout << endl;
    return 0;
}
