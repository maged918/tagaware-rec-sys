//Language: GNU C++



#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <vector>
#include <deque>

#define name 	""
#define inf		(int)1e9
#define eps		1e-9
#define SZ(x)	x.size()
#define fi		first
#define se		second

using namespace std;

typedef deque<int> 		di;
typedef deque<di> 		ddi;
typedef long long		ll;
typedef long double 	ld;
typedef pair<int,int>	pii;

	string a[50][50];

int main(){

	freopen("input.txt","r",stdin);
	freopen("output.txt","w",stdout); //*/

	int n,m,k;

	cin >> n >> m >> k;

	for (k = k; k > 0; -- k) {
		char c;
		cin >> c;
		if (c == '+'){
		 	cin >> c;
		 	int x, y;
		 	cin >> x >> y;
		 	while(a[x][y] != ""){
		 		y++;
		 		if(y>m) x++,y=1; 
		 		if(x>n) break;
		 	}
		 	cin >> a[x][y];
		}else{
		    cin >> c;
		    string s;
		    cin >> s;
		    bool ok = false;
		    for(int i = 1; i <= n; ++ i) {
		    	for(int j = 1; j <= m; ++j) {
		    		if(a[i][j] == s){
		    			cout <<i<<' '<<j<<endl;
		    			ok=true;
		    			a[i][j] = "";
		    			break;
		    		}
		    	}
		    	if(ok) break;
		    }
		    if(!ok) cout<<-1<<' '<<-1<<endl;
		}
	}

	return 0;
}
