//Language: GNU C++


#include <vector>
#include <string>
#include <iostream>
#include <cstdio>
#include <memory>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <map>
#include <cmath>
#include <climits>
#include <list>
#include <cmath>
#include <sstream>
#include <set>

using namespace std;

#define REP(i, n) for (int (i) = 0; (i) < (n); ++(i))
#define FOR(i, a, b) for (int (i) = (a); (i) <= (b); ++(i))
#define FORD(i, a, b) for (int (i) = (a); (i) >= (b); --(i))
#define ALL(x) (x).begin(), (x).end()
#define SIZE(x) (x).size()

#define DBG(x) cout << #x << " = " << x << endl
#define DBGARR(x) REP(i, SIZE(x)) cout << #x << "[" << i << "] = " << x[i] << endl

#define INF 1000000000

long long dp[55][55];

long double facts[55];

long long nck(int n, int k) {
    if (k > n) return 0;
    long long r = 1;
    for (int t = 1; t <= k; ++t) {
        r *= n;
        --n;
        r /= t;
    }
    return r;
}

int main() {
    // freopen("test.in", "r", stdin);
    // freopen("test.out", "w", stdout);

    int n;
    cin >> n;
    vector<int> l(n);
    REP(i, n) cin >> l[i];
    sort(ALL(l));
    reverse(ALL(l));
    int p;
    cin >> p;

    vector<long long> res(n, 0);

    int sum = 0;
    REP(i, n) sum += l[i];
    if (sum <= p) {
        cout << n << endl;
        return 0;
    }

    REP(i, n) {
        // i-th person is the "blocker"
        memset(dp, 0, sizeof(dp));
        dp[0][0] = 1; // 0 meters w/ 0 people is possible

        REP(j, n) if (j != i) {
            FORD(x, p, 0) FORD(y, n - 1, 0) if (dp[x][y]) {
                if (x + l[j] <= p && y + 1 <= n - 1) {
                    dp[x + l[j]][y + 1] += dp[x][y];
                }
            }
        }
        FOR(x, max(0, p - l[i] + 1), p) FOR(y, 1, n - 1) {
            res[y] += dp[x][y];
        }
        /*
        if (i == 0) {
            REP(y, n) {
                REP(x, p + 1) {
                    cout << dp[x][y] << ' ';
                }
                cout << endl;
            }
        }
        */
    }
    double avg = 0;

    FOR(y, 1, n - 1) {
        avg += y * res[y] * 1.0 / nck(n - 1, y);
    }
    avg /= n;
    printf("%.6f", avg);

    fclose(stdin);
    fclose(stdout);

    return 0;
}
