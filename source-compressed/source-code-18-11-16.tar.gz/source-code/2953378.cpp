//Language: GNU C++


#include <cstdio>
#include <algorithm>

#define abs(x) (((x) > 0) ? (x) : (-(x)))

using namespace std;

const int MAXN = 1001;

typedef long long int64;

int n, m, k;
int64 a [MAXN][MAXN], f [MAXN][MAXN];
int64 s1 [MAXN][MAXN], s2 [MAXN][MAXN], s3 [MAXN][MAXN], s4 [MAXN][MAXN];
int64 up [MAXN][MAXN], dn [MAXN][MAXN], lt [MAXN][MAXN], rt [MAXN][MAXN];

inline int64 S1 (int x1, int y1, int x2, int y2) { return s1 [x2][y2] - s1 [x1 - 1][y1]; }
inline int64 S2 (int x1, int y1, int x2, int y2) { return s2 [x2][y2] - s2 [x1][y1 - 1]; }
inline int64 S3 (int x1, int y1, int x2, int y2) { return s3 [x2][y2] - s3 [x1 - 1][y1 - 1]; }
inline int64 S4 (int x1, int y1, int x2, int y2) { return s4 [x2][y2] - s4 [x1 - 1][y1 + 1]; }

inline void bruteF (int x, int y) {
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			f [x][y] += a [i][j] * max (0, k - abs (i - x) - abs (j - y));
}

inline void bruteRt (int x, int y) {
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (j >= y && abs (i - x) + abs (j - y) < k)
				rt [x][y] += a [i][j];
}

inline void bruteLt (int x, int y) {
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (j <= y && abs (i - x) + abs (j - y) < k)
				lt [x][y] += a [i][j];
}

inline void bruteDn (int x, int y) {
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (i >= x && abs (i - x) + abs (j - y) < k)
				dn [x][y] += a [i][j];
}

inline void bruteUp (int x, int y) {
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (i <= x && abs (i - x) + abs (j - y) < k)
				up [x][y] += a [i][j];
}

inline void preCalcuS1 () {
	for (int j = 1; j <= m; ++j)
		for (int i = 1; i <= n; ++i)
			s1 [i][j] = s1 [i - 1][j] + a [i][j];
}

inline void preCalcuS2 () {
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			s2 [i][j] = s2 [i][j - 1] + a [i][j];
}

inline void preCalcuS3 () {
	for (int k = -n; k <= m; ++k)
		for (int i = 1; i <= n; ++i) {
			int j = k + i - 1;
			if (j >= 1 && j <= m)
				s3 [i][j] = s3 [i - 1][j - 1] + a [i][j];
		}
}

inline void preCalcuS4 () {
	for (int k = 1; k <= m + n; ++k)
		for (int i = 1; i <= n; ++i) {
			int j = k - i + 1;
			if (j >= 1 && j <= m)
				s4 [i][j] = s4 [i - 1][j + 1] + a [i][j];
		}
}

inline void preCalcuRt () {
	for (int x = k; x <= n - k + 1; ++x)
		for (int y = k; y <= m - k + 1; ++y)
			if (x == k && y == k)
				bruteRt (x, y);
			else if (x == k)
				rt [x][y] = rt [x][y - 1] + S3 (x - k + 1, y, x, y + k - 1) + S4 (x, y + k - 1, x + k - 1, y) - a [x][y + k - 1] - S1 (x - k + 1, y - 1, x + k - 1, y - 1);
			else
				rt [x][y] = rt [x - 1][y] + S4 (x, y + k - 1, x + k - 1, y) - S3 (x - k, y, x - 1, y + k - 1);
}

inline void preCalcuLt () {
	for (int x = k; x <= n - k + 1; ++x)
		for (int y = k; y <= m - k + 1; ++y)
			if (x == k && y == k)
				bruteLt (x, y);
			else if (x == k)
				lt [x][y] = lt [x][y - 1] + S1 (x - k + 1, y, x + k - 1, y) - S4 (x - k + 1, y - 1, x, y - k) - S3 (x, y - k, x + k - 1, y - 1) + a [x][y - k];
			else
				lt [x][y] = lt [x - 1][y] + S3 (x, y - k + 1, x + k - 1, y) - S4 (x - k, y, x - 1, y - k + 1);
}

inline void preCalcuDn () {
	for (int x = k; x <= n - k + 1; ++x)
		for (int y = k; y <= m - k + 1; ++y)
			if (x == k && y == k)
				bruteDn (x, y);
			else if (x == k)
				dn [x][y] = dn [x][y - 1] + S4 (x, y + k - 1, x + k - 1, y) - S3 (x, y - k, x + k - 1, y - 1);
			else
				dn [x][y] = dn [x - 1][y] + S3 (x, y - k + 1, x + k - 1, y) + S4 (x, y + k - 1, x + k - 1, y) - a [x + k - 1][y] - S2 (x - 1, y - k + 1, x - 1, y + k - 1);
}

inline void preCalcuUp () {
	for (int x = k; x <= n - k + 1; ++x)
		for (int y = k; y <= m - k + 1; ++y)
			if (x == k && y == k)
				bruteUp (x, y);
			else if (x == k)
				up [x][y] = up [x][y - 1] + S3 (x - k + 1, y, x, y + k - 1) - S4 (x - k + 1, y - 1, x, y - k);
			else
				up [x][y] = up [x - 1][y] + S2 (x, y - k + 1, x, y + k - 1) - S4 (x - k, y, x - 1, y - k + 1) - S3 (x - k, y, x - 1, y + k - 1) + a [x - k][y];
}

inline void preProcess () {
	preCalcuS1 (), preCalcuS2 ();
	preCalcuS3 (), preCalcuS4 ();
	
	preCalcuRt (), preCalcuLt ();
	preCalcuDn (), preCalcuUp ();
	
	for (int x = k; x <= n - k + 1; ++x)
		for (int y = k; y <= m - k + 1; ++y)
			if (x == k && y == k)
				bruteF (x, y);
			else if (x == k)
				f [x][y] = f [x][y - 1] + rt [x][y] - lt [x][y - 1];	
			else
				f [x][y] = f [x - 1][y] + dn [x][y] - up [x - 1][y];
}

int main () {
	#ifndef ONLINE_JUDGE
	freopen ("cf161div2e.in", "r", stdin);
	freopen ("cf161div2e.out", "w", stdout);
	#endif
	
	scanf ("%d %d %d\n", &n, &m, &k);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			scanf ("%I64d", &a [i][j]);
	
	preProcess ();
	
	int64 res = -1; int x = 0, y = 0;
	for (int i = k; i <= n - k + 1; ++i)
		for (int j = k; j <= m - k + 1; ++j)
			if (f [i][j] > res)
				res = f [i][j], x = i, y = j;
	
	printf ("%d %d\n", x, y);
	
	fclose (stdin);
	fclose (stdout);
	return 0;
}
