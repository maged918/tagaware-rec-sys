//Language: GNU C++


#include <iostream>
#include <stack>
#include <queue>
#include <vector>
#include <stdio.h>
#include <map>
#include <set>
#include <algorithm>
#include <math.h>
#include <cstring>

#define MAXN 100005
#define MOD 1000000007
#define INFY 1000000000

using namespace std;
vector<int> a[MAXN];
int r[MAXN];
bool c[MAXN];
bool contains(int i, int j){
    for(int k=0; k<4; k++){
        if(a[i][k]==j) return 1;
    }
    return 0;
}

int main () {
    //freopen("in.txt", "r", stdin);
    //freopen("out.txt", "w", stdout);
    int n;
    cin >> n;
    int x, y;
    for(int i=0; i<2*n; i++){
        scanf("%d %d", &x, &y);
        a[x].push_back(y);
        a[y].push_back(x);
    }
    for(int i=1; i<=n; i++){
        if(a[i].size()!=4){
            cout<<-1;
            return 0;
        }
    }
    for(int i1=0; i1<4; i1++) 
    for(int i2=0; i2<4; i2++) if(contains(a[1][i1], a[1][i2])){
        memset(c, 0, sizeof(c));
        memset(r, 0, sizeof(r));
        c[1] = 1;
        c[a[1][i1]] = 1;
        c[a[1][i2]] = 1;
        r[1] = 1;
        r[2] = a[1][i1];
        r[3] = a[1][i2];
        for(int i=4; i<=n; i++){
            for(int j=0; j<4; j++){
                x = a[r[i-1]][j];
                if(c[x]==0 && contains(r[i-2], x)){
                    r[i] = x;
                    c[x] = 1;
                    break;
                }
            }
            if(r[i]==0) break;
        }
        //cout<<"thu"<<endl;
        //cout<<r[1]<<" "<<r[2]<<" "<<r[n-1]<<" "<<r[n]<<endl;
        if(contains(r[2], r[n]) && contains(r[1], r[n]) && contains(r[1], r[n-1])){
            for(int i=1; i<=n; i++) printf("%d ", r[i]);
            return 0;
        }
    }    
    cout<<-1<<endl;
    return 0;
}
