//Language: MS C++


#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <algorithm>
#include <queue>
#include <cmath>
using namespace std;
typedef long double ld;
    
const int MAXN = 52;

int a [MAXN];
ld dp [MAXN][MAXN][MAXN];

ld fac( int x ){
    ld res = 1.0;
    for( int i = 1; i <= x; i++ )
        res *= i;
    return res;
}

int main(){
    int n;
    cin>>n;
    for( int i = 0; i < n; i++ )
        cin>>a[i];
    int p;
    cin>>p;
    ld ans = 0.0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < MAXN; j++)
            for (int k = 0; k < MAXN; k++)
                for (int l = 0; l < MAXN; l++)
                    dp[j][k][l] = 0.0;
        dp[0][0][a[i]] = 1.0;
        
        for (int j = 0; j < n; j++){
            for (int k = 0; k < MAXN; k++)
                for (int l = 0; l < MAXN; l++){
                    dp[j+1][k][l] = dp[j][k][l];
                }
            
            if (i == j) continue;
            
            for (int k = 0; k <= n; k++)
                for (int l = 0; l <= p; l++)
                    if (l + a[j] <= p)
                        dp[j+1][k+1][l+a[j]] += dp[j][k][l];
        }
        
        for (int j = 0; j <= n; j++){
            ld sum = 0.0;
            for (int k = 0; k <= p; k++)
                sum += dp[n][j][k];
            sum *= fac (j);
            sum *= fac (n-1-j);
            sum /= fac (n);
            ans += sum;
        }
    }
    
    cout<<fixed<<setprecision (7);
    cout<<ans<<"\n";
    return 0;
}
