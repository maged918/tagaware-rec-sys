//Language: GNU C++


#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <ctime>
#include <algorithm>
#include <vector>
#include <queue>
#include <deque>
#include <stack>
#include <set>
#include <map>
#include <complex>
#include <bitset>
#include <iomanip>
#include <utility>

#define x first
#define y second
#define ll long long
#define ull unsigned
#define pb push_back
#define pp pop_back
#define pii pair<int ,int>
#define vi vector<int>
using namespace std;
const int maxn=1000001;
int a[maxn];
string s;
int main()
{
    cin>>s;
    int n=s.size();
    int p=1;
    int q=n;
    for(int i=0;i<s.size();i++)
    {
        if(s[i]=='r')
        {
            a[p]=i+1;
            p++;
        }
        else
        {
            a[q]=i+1;
            q--;
        }
    }
    for(int i=1;i<=n;i++)
        cout<<a[i]<<endl;
    //cin>>n;
}