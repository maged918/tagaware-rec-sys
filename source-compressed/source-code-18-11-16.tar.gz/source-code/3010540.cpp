//Language: GNU C++


#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<cmath>
#include<stdlib.h>
#include<cstdio>
#include<stack>
#include<queue>
#include<limits.h>
using namespace std;
	int main(){
	int n,k, count=0;
	cin>>n>>k;
	int a[n];
for(int i=0;i<n;i++)
  cin>>a[i];
for(int i=0;i<n;i++)
{
	int sum=0;
 	while(a[i]>0)
		{
		 if((a[i]%10==4) || (a[i]%10==7))
		      sum++;
		   a[i]/=10;
		}
	if(sum<=k)
	count++;
}
cout<<count;
 return 0;
}
