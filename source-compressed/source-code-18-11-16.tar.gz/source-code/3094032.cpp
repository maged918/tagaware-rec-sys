//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <math.h>
#include <assert.h>
#include <map>
#include <queue>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <sstream>
#include <stdarg.h>
using namespace std;
typedef  long long ll;
template<typename T> int size(T &a) {return (int)a.size();}
template<typename T> T sqr(T a)  { return a * a; }

#define REP(i,a,b) for(int i=(a);i<(b); ++i)
#define REPD(i,a,b)for(int i=(b)-1;i>=a;--i)
#define _(a,b) memset((a), (b), sizeof(a))
#define all(a) a.begin(), a.end()
#define mp make_pair
#define pb push_back
#define vi vector<int> 



int main() {
#ifdef air
	freopen("input.txt", "r", stdin);
	freopen("output.txt","w", stdout);       
#endif
 
// 	ios_base::sync_with_stdio(false);	                                                                     
		

	int d;
	cin >> d;
	for(++d;;++d) {
		vector<int> u(10);
		int t = d;
		for(; t; ) {
			u[t % 10] ++;
			t /= 10;
		}
		bool ok=true;
		REP(i,0,10) if (u[i])
			ok &= u[i] == 1;
		if (ok) 
			break;
	}
	cout << d;





	
#ifdef air
	printf("\n\n %lf \n", clock() * 1e-3);
#endif
	
	return 0;
}                