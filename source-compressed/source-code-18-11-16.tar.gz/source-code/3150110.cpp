//Language: GNU C++


#include<iostream>
#include<cstdio>
using namespace std;

const int N = 155;
const int inf = 200000000;

int l, c[N], d[N][N], f[N][N][N];
char a[N];

int main() {
    int len, i, j, k;

    //freopen("t", "r", stdin);

    cin >> l;

    for(i = 1; i<=l; ++i)
        cin >> c[i];

    cin.get();
    cin.getline(a + 1, 200);

    for(i = 1; i <= 150; ++i)
        for(j = i; j <= 150; ++j)
            for(k = 0; k <= 150; ++k)
                f[i][j][k] = -inf;

    for(len = 1; len <= l; ++len) {

        for(i = 1; i<=l - len + 1; ++i) {
            int cs = i + len - 1;

            //calc f[i][cs][j], j = 1 sau j = 2

            for(j = i; j <= cs; ++j)
                f[i][cs][1] = max(f[i][cs][1],
                    f[i][j - 1][0] + f[j + 1][cs][0]);

            //calc f[i][cs][j], j >= 2
            for(j = 2; j <= len; ++j) {

                if(a[i] == a[cs])
                    f[i][cs][j] = max(f[i][cs][j],
                                      f[i + 1][cs - 1][j - 2]);

                for(k = i; k < cs; ++k)
                    f[i][cs][j] = max(max(f[i][cs][j], f[k + 1][cs][0] + f[i][k][j]),
                                      f[i][k][0] + f[k + 1][cs][j]);

            }

            //calc f[i][cs][j], j = 0

            for(j = 1; j <= len; ++j) if(c[j] != -1)
                f[i][cs][0] = max(f[i][cs][0],
                                  f[i][cs][j] + c[j]);

            //calc d[i][cs]
            d[i][cs] = max(d[i][cs], f[i][cs][0]);
            for(j = i; j < cs; ++j)
                d[i][cs] = max(d[i][cs],
                               d[i][j] + d[j + 1][cs]);

        }
    }

    cout << d[1][l];

    return 0;
}
