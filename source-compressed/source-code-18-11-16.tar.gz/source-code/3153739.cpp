//Language: MS C++


#pragma comment(linker, "/STACK:256000000")
#include <iostream>
#include <string>
#include <string.h>
#include <algorithm>
#include <vector>
#include <queue>
#include <ctime>
#include <cmath>
#include <stdio.h>
#include <set>
#include <map>
#include <stack>
#include <fstream>
#include <deque>
#include <list>
#include <ctime>

#define SZ(a) (int(a.size()))
#define MEM(a, val) memset(a, val, sizeof(a))
#define MP(a, b) make_pair(a, b)
#define PB(a) push_back(a)
#define ALL(a) a.begin(), a.end()
#define REP(i, n) for(int (i) = 0; (i) < (n); ++(i))
#define FOR(i, a, b) for(int (i) = (a); (i) <= (b); ++(i))
#define SQR(a) ((a) * (a))

using namespace std;

typedef unsigned long long ULL;
typedef long long LL;
typedef long double dbl;
typedef pair<int, int> pii ;
typedef vector<int> vint;
typedef vector<LL> vLL;

const int nmax = 100009;

struct edge {
	int v, next;
};

LL a[nmax];
LL add[nmax];
LL sub[nmax];

vector<edge> sp;
int po[nmax];

void push_edge(int v, int to) {
	edge tmp = {to, po[v]};
	po[v] = SZ(sp);
	sp.push_back(tmp);
}

int n;

void dfs(int v, int per) {
	add[v] = 0;
	sub[v] = 0;
	for (int j = po[v]; j != -1; j = sp[j].next) {
		int to = sp[j].v;
		if (to != per) {
			dfs(to, v);
			add[v] = max(add[v], add[to]);
			sub[v] = max(sub[v], sub[to]);
		}
	}
	LL tmp = a[v] - sub[v] + add[v];
	if (tmp > 0)
		sub[v] += tmp;
	else
		add[v] += abs(tmp);
}

int main()
{
#ifdef _DEBUG
	freopen("input.txt", "r", stdin); freopen("output.txt", "w", stdout);
#else
	//freopen("input.txt", "r", stdin);freopen("output.txt", "w", stdout);
#endif
	MEM(po, -1);
	cin >> n;
	REP(i, n - 1) {
		int v, u;
		cin >> v >> u;
		push_edge(u, v);
		push_edge(v, u);
	}
	FOR(i, 1, n) 
		cin >> a[i];
	dfs(1, -1);
	cout << add[1] + sub[1] << endl;
	return 0;
}
