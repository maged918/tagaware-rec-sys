//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <cmath>
#include <iostream>
#include <algorithm>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include <string>

using namespace std;
int fa[109];
int finfa(int k)
{
    if(fa[k]==k) return k;
    return fa[k] = finfa(fa[k]);
}
int v[109],vv[109];
int main()
{
   // freopen("in.txt","r",stdin);
    int n,m,ans = 0;
    scanf("%d%d",&n,&m);
    for(int i=0;i<=m;i++) fa[i] = i;
    for(int i=0;i<n;i++)
    {
        int t,tmp=-1,c;
        scanf("%d",&t);
        if(t==0) ans++;
        for(int j=0;j<t;j++)
        {
            scanf("%d",&c);
            v[c] = 1;
            if(tmp!=-1)
            {
                fa[finfa(tmp)] = finfa(c);
            }
            tmp = c;
        }
    }
    for(int i=0;i<=m;i++)
    if(v[i])
    {
        vv[finfa(i)] = 1;
    }
    int cc = 0;
    for(int i =0;i<109;i++) if(vv[i]) cc++;
    if(cc>1) ans+=(cc-1);
    cout<<ans<<endl;
    return 0;
}
