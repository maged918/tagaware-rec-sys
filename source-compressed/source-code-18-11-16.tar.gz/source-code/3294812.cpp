//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

struct node{
    int tt, y1, y2;
} a[100050], b[100050];
int ans;
int n, m, x1, x2, y1, y2;

int cmp(node a, node b){
    if (a.tt == b.tt) return a.y1 < b.y1;
    return a.tt < b.tt;
}

int work(node *a, int t1, int n, int m) {
    sort(a + 1, a + t1 + 1, cmp);
    int pre = 0, j, p, tot;
    for (int i = 1; i <= t1;) {
        if ((a[i].tt - pre - 1)%2)
            ans = ans^m;
        pre = a[i].tt;
        j = i;p = 0; tot = 0;
        while (j <= t1 && a[j].tt == a[i].tt) {
            if (a[j].y1 > p) tot += a[j].y1 - p;
            p = max(a[j].y2, p);
            ++j;
        }
        tot += m - p;
        ans^=tot;
        i = j;
    }
    if ((n - pre - 1) % 2) ans ^= m;
}

bool work2(node *a, int t1, int n, int m) {
    int pre = 0, j, p, tot;
    for (int i = 1; i <= t1;) {
        if ((a[i].tt - pre - 1)%2) {
            if ((m ^ ans) <= m) {
                x1 = x2 = pre + 1, y1 = 0, y2 = m - (m ^ ans);
                return true;
            }
        }
        pre = a[i].tt;
        j = i;p = 0; tot = 0;
        while (j <= t1 && a[j].tt == a[i].tt) {
            if (a[j].y1 > p) tot += a[j].y1 - p;
            p = max(a[j].y2, p);
            ++j;
        }
        tot += m - p;
        if ((tot ^ ans) <= tot) {
            int tmp = tot - (tot ^ ans);
            j = i;p = 0; tot = 0;
            while (j <= t1 && a[j].tt == a[i].tt) {
                if (a[j].y1 > p) {
                    if (tot + a[j].y1 - p >= tmp) {
                        x1 = x2 = a[i].tt; y1 = 0; y2 = p + (tmp - tot);
                        return true;
                    }
                    tot += a[j].y1 - p;
                }
                p = max(a[j].y2, p);
                ++j;
            }
            x1 = x2 = a[i].tt; y1 = 0; y2 = p + tmp - tot;
            return true;
        }
        i = j;
    }
    if (((n - pre - 1) % 2) && ((m^ans) <= m)) {
            x1 = x2 = pre + 1, y1 = 0, y2 = m - (m ^ ans);
            return true;
    }
    return false;
}

int main() {
//    freopen("in.txt", "r", stdin);
    int t1 = 0, t2 = 0, tt;
    scanf("%d%d%d", &n, &m, &tt);
    for (int i = 1; i <= tt; ++i) {
        scanf("%d%d%d%d", &x1, &y1, &x2, &y2);
        if (x1 > x2) swap(x1, x2);
        if (y1 > y2) swap(y1, y2);
        if (x1 == x2) {
            ++t1;
            a[t1].tt = x1;
            a[t1].y1 = y1;
            a[t1].y2 = y2;
        } else {
            ++t2;
            b[t2].tt = y1;
            b[t2].y1 = x1;
            b[t2].y2 = x2;
        }
    }
    ans = 0;
    work(a, t1, n, m);
    work(b, t2, m, n);
    if (ans == 0) cout << "SECOND" << endl;
    else {
        cout << "FIRST" << endl;
        if (work2(a, t1, n, m)) cout << x1 << " " << y1 << " " << x2 << " " << y2 << endl;
        else {
            work2(b, t2, m, n);
            cout << y1 << " " << x1 << " " << y2 << " " << x2 << endl; 
        }
    }
    return 0;
}
