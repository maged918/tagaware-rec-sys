//Language: GNU C++


/********************
CodeForces
By:South_stream
********************/

#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<string>
#include<cstdlib>
#include<queue>
#include<map>
#include<stack>
#include<iostream>
#include<vector>
#define PF printf
#define SF scanf
#define cls(a) memset(a,0,sizeof(a))
#define _cls(a) memset(a,-1,sizeof(a))
#define _cp(a,b) ((a)<(b))//a<b

using namespace std;
typedef __int64 LL;
typedef double dl;
const int Maxn=110;
const int Maxe=100000;

int main(){
    int i,j,k;
    int x,t=0;
    char str[5];
    scanf("%d",&x);
    while(x--){
        SF("%s",str);
        if(str[0]=='+'&&str[1]=='+') t++;
        else if(str[0]=='-'&&str[1]=='-') t--;
        else if(str[1]=='+'&&str[2]=='+') t++;
        else if(str[1]=='-' && str[2]=='-')  t--;
    }
    printf("%d\n",t);
    return 0;
}
