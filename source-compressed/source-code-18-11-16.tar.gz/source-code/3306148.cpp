//Language: GNU C++


#include <iostream>
#include <cmath>


using namespace std;

int main(){
    string s1, s2;
    int n, sum = 0;
    cin>>s1;
    cin>>s2;
    bool a = true, b = true;
    if (s1.length() != s2.length()) { cout<<"NO"; return 0;}
    for(int i = 0; i < s1.length(); i++){
            if (s1[i]=='1') a = false;
            if (s2[i]=='1') b = false;
    }
    
    if ((!a && !b)  || (s1==s2)) cout<<"YES"; else cout<<"NO";
    
    return 0;
}
