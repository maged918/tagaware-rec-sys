//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<string>
#include<set>
#include<vector>

using namespace std;

int main() {
  int n;
  int hn = 0;
  int h[103000];
  int maks = 0;
  int i, j, cur;
  cin >> n;
  for(i=0; i<n; i++){
    cin >> cur;
    while (hn > 0 && cur > h[hn-1]) {
      if (maks < (cur ^ h[hn-1])) maks = cur ^ h[hn-1];
      hn--;
    }
    h[hn] = cur;
    hn++;
    if (hn > 1) {
      if (maks < (cur ^ h[hn-2])) maks = cur ^ h[hn-2];
    }
  }
  cout << maks << '\n';
  return 0;
}