//Language: GNU C++0x


/*
	Author : ChnLich
*/
#include<cstdio>
#include<cmath>
#include<iomanip>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<iostream>
#include<sstream>
#include<fstream>
#include<algorithm>
#include<vector>
#include<list>
#include<stack>
#include<queue>
#include<deque>
#include<set>
#include<map>
#include<string>
#include<bitset>
#include<functional>
#include<utility>
#include<unordered_set>

using namespace std;

typedef long long llint;
typedef pair<int,int> ipair;
typedef unsigned int uint;
#define pb push_back
#define fi first
#define se second
#define mp make_pair

const int MOD=1000000007,dx[]={0,1,0,-1},dy[]={1,0,-1,0};
const double eps=1e-8;

void read(int &k)
{
	k=0; char x=getchar();
	while(x<'0'||x>'9') x=getchar();
	while(x>='0'&&x<='9') { k=k*10-48+x; x=getchar(); }
}

vector<int> a[100010];
unordered_set<int> exi[100010];
int tl,tmid,ttl,ttmid,la,lb,H,T,n,m,x,y;
int b[100010],c[100010],d[100010],e[100010],lt[100010];

bool exist(int x,int fd)
{
	return exi[x].find(fd)!=exi[x].end();
}

void calc(int A,int B)
{
	la=a[A].size(); lb=a[B].size();
	tl=tmid=0;
	for(int i=0;i+1<la;i++) if (a[A][i]!=B)
	{
		if (exist(B,a[A][i])) c[tmid++]=a[A][i]; else b[tl++]=a[A][i];
		if (tl>=H) break;
		if (tmid+tl>=H+T) break;
	}
	if (tl+tmid<H) return;
	ttl=ttmid=0;
	for(int i=0;i+1<lb;i++) if (a[B][i]!=A)
	{
		if (exist(A,a[B][i])) e[ttmid++]=a[B][i]; else d[ttl++]=a[B][i];
		if (ttl>=T) break;
		if (ttmid+ttl>=H+T) break;
	}
	if (tl+ttl+max(tmid,ttmid)<H+T) return;
	if (ttmid>tmid)
	{
		for(int i=0;i<ttmid;i++) c[i]=e[i];
		tmid=ttmid;
	}
	puts("YES");
	printf("%d %d\n",A,B);
	for(int i=0;i<tl&&H;i++)
	{
		printf("%d ",b[i]);
		H--;
	}
	for(;H;)
	{
		printf("%d ",c[tmid-1]);
		tmid--;
		H--;
	}
	puts("");
	for(int i=0;i<ttl&&T;i++)
	{
		printf("%d ",d[i]);
		T--;
	}
	for(;T;)
	{
		printf("%d ",c[tmid-1]);
		tmid--;
		T--;
	}
	puts("");
	exit(0);
}

int main()
{
	scanf("%d%d%d%d",&n,&m,&H,&T);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		a[x].pb(y); a[y].pb(x);
		exi[x].insert(y);
		exi[y].insert(x);
		lt[x]++; lt[y]++;
	}
	for(int i=1;i<=n;i++) a[i].pb(n+1),sort(a[i].begin(),a[i].end());
	for(int Q=1;Q<=n;Q++) if (lt[Q]>H)
	{
		int l=a[Q].size();
		for(int P=0;P+1<l;P++) if (lt[a[Q][P]]>T)
			calc(Q,a[Q][P]);
	}
	puts("NO");
	
	return 0;
}
