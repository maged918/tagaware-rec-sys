//Language: MS C++


#include <iostream>
using namespace std;

int main()
{
    int n,k,a,b,sum;
    sum=0;
    cin>>n>>k;
    for (int ix=1;ix<=n;ix++)
    {
        cin>>a>>b;
        sum+=b-a+1;
    }
    cout<<(k-sum%k)%k<<endl;
}
