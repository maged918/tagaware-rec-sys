//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string>
#include <cmath>
#include <vector>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <stack>
#include <queue>
#include <ctime>
#include <cstdlib>

using namespace std;

#define ll long long
#define pb push_back
#define mp make_pair
#define f first
#define s second
#define sz size()
#define pii pair<int,int>

const int MAXN = (int)(1e5) + 100;
const int INF = (1<<30);
const double PI = acos(-1.0);
const double EPS = (1e-6);

int a[MAXN];
int main () {        
	#ifndef ONLINE_JUDGE
	freopen("in", "r", stdin);
	freopen("out", "w", stdout);
	#endif
		int n, m, k, ans = INF;
		cin >> n >> m >> k;
		n *= m;
		for (int i=1; i<=n; i++)
			cin >> a[i];
		for (int i=1; i<=n; i++) {
			bool ok = false;
			int cnt = 0;
			for (int j=1; j<=n; j++) {
				if (i != j)
					if (abs(a[j] - a[i]) % k == 0)
						cnt += abs(a[j] - a[i]) / k;
					else {
						ok = true;
						break;
					}
			}
			if (ok) continue;;
		      ans = min (ans, cnt);
		}
		if (ans == INF)
			cout << -1;
		else
			cout << ans;
	return 0;
}
