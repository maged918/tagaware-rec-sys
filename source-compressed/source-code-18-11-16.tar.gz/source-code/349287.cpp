//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <map>
#include <queue>
#include <set>
#include <cmath>
#include <vector>

using namespace std;

int n, k, a;
int array[100100];
set<int> lol;
map<int, int> qtd;

int main () {
    scanf("%d %d", &n, &k);
    for(int i = 0; i < n; i++){
        scanf("%d", &array[i]);
    }
    for(int i = 0; i < k; i++){
        if(++qtd[array[i]] == 1){
            lol.insert(array[i]);
        }
        else lol.erase(array[i]);
    }
    if(lol.empty()){
        printf("Nothing\n");
    }
    else{
        a = *(--lol.end());
        printf("%d\n", a);
    }
    for(int i = k; i < n; i++){
        if(++qtd[array[i]] == 1){
            lol.insert(array[i]);
        }
        else lol.erase(array[i]);
        if(--qtd[array[i-k]] == 1){
            lol.insert(array[i-k]);
        }
        else if(qtd[array[i-k]] == 0){
            lol.erase(array[i-k]);
        }
        if(lol.empty()){
            printf("Nothing\n");
        }
        else{
            a = *(--lol.end());
            printf("%d\n", a);
        }
    }
    
    return 0;
}