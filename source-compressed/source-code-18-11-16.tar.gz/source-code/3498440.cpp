//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;

#define lson l, m, rt << 1
#define rson m+1, r, rt << 1 | 1
#define mid int m = (l+r) >>1
#define ls rt << 1
#define rs rt << 1 | 1

const int M = 175600;
struct nod{
    int tl[21], tr[21], tm[21], tv[21];
    int l[21], r[21], m[21], v[21];
    int s;
} p[M << 1];
int val[M];
int c;
const int inf = 0x7fffffff;


int max(int a, int b){return a > b ? a : b;}
int min(int a, int b){return a < b ? a : b;}
void PushUp(int rt, int a, int b){
    int i, j;
    for(i = 1; i <= p[rt].s; i++){
        p[rt].l[i] = p[rt].r[i] = p[rt].v[i] = -inf;
        p[rt].m[i] = 0;
    }
    for(i = 1; i <= p[a].s; i ++){
        p[rt].m[i] = max(p[rt].m[i], p[a].m[i]);
        p[rt].l[i] = max(p[rt].l[i], p[a].l[i]);
    }
    for(i = 1; i <= p[b].s; i ++){
        p[rt].m[i] = max(p[rt].m[i], p[b].m[i]);
        p[rt].r[i] = max(p[rt].r[i], p[b].r[i]);
    }
    for(i = 1; i <= p[a].s; i ++){
        for(j = 1; j <= p[b].s; j ++){
            if(j + i <= p[rt].s){
                p[rt].m[i+j] = max(p[rt].m[i+j], p[a].m[i] + p[b].m[j]);
                p[rt].v[i+j] = max(p[rt].v[i+j], p[a].l[i] + p[b].r[j]);
                p[rt].l[i+j] = max(p[rt].l[i+j], p[a].l[i] + p[b].m[j]);
                p[rt].r[i+j] = max(p[rt].r[i+j], p[a].m[i] + p[b].r[j]);
            }
            if(i+j-1 <= p[rt].s){
                p[rt].m[i+j-1] = max(p[rt].m[i+j-1], p[a].r[i] + p[b].l[j]);
                p[rt].v[i+j-1] = max(p[rt].v[i+j-1], p[a].v[i] + p[b].v[j]);
                p[rt].l[i+j-1] = max(p[rt].l[i+j-1], p[a].v[i] + p[b].l[j]);
                p[rt].r[i+j-1] = max(p[rt].r[i+j-1], p[a].r[i] + p[b].v[j]);
            }else break;
        }
    }
}

void build(int l, int r, int rt){
    p[rt].s = min(20, (r-l) / 2 + 1);
    if(l == r){
        p[rt].l[1] = p[rt].r[1] = p[rt].m[1] = p[rt].v[1] = val[l];
        return ;
    }
    mid;
    build(lson);
    build(rson);
    PushUp(rt, ls, rs);
}

void Up(int rt, int a, int b){
//  printf("rt = %d\n", rt);
    int is = c;
    int ll = min(c, p[a].s);
    int rr = min(c, p[b].s);
    int i, j;
    for(i = 1; i <= is; i++){
        p[rt].tl[i] = p[rt].tr[i] = p[rt].tv[i] = 0;
        p[rt].tm[i] = 0;
    }
    for(i = 1; i <= ll; i ++){
        p[rt].tm[i] = max(p[rt].tm[i], p[a].tm[i]);
        p[rt].tl[i] = max(p[rt].tl[i], p[a].tl[i]);
    }
    for(i = 1; i <= rr; i ++){
        p[rt].tm[i] = max(p[rt].tm[i], p[b].tm[i]);
        p[rt].tr[i] = max(p[rt].tr[i], p[b].tr[i]);
    }
    for(i = 1; i <= ll; i ++){
        for(j = 1; j <= rr; j ++){
            if(j + i <= is){
                p[rt].tm[i+j] = max(p[rt].tm[i+j], p[a].tm[i] + p[b].tm[j]);
                p[rt].tv[i+j] = max(p[rt].tv[i+j], p[a].tl[i] + p[b].tr[j]);
                p[rt].tl[i+j] = max(p[rt].tl[i+j], p[a].tl[i] + p[b].tm[j]);
                p[rt].tr[i+j] = max(p[rt].tr[i+j], p[a].tm[i] + p[b].tr[j]);
            }
            if(i+j-1 <= is){
                p[rt].tm[i+j-1] = max(p[rt].tm[i+j-1], p[a].tr[i] + p[b].tl[j]);
                p[rt].tv[i+j-1] = max(p[rt].tv[i+j-1], p[a].tv[i] + p[b].tv[j]);
                p[rt].tl[i+j-1] = max(p[rt].tl[i+j-1], p[a].tv[i] + p[b].tl[j]);
                p[rt].tr[i+j-1] = max(p[rt].tr[i+j-1], p[a].tr[i] + p[b].tv[j]);
            }else break;
        }
    }   
//  for(i = 1; i <= is; i ++) printf("%d\n", p[rt].tm[i]);cout << endl;
}

void query(int L, int R, int l, int r, int rt){
    int is, i;
    if(L <= l &&r  <= R){
        is = c;
        for(i = 1; i <= is; i ++){
            p[rt].tl[i] = p[rt].l[i];
            p[rt].tr[i] = p[rt].r[i];
            p[rt].tm[i] = p[rt].m[i];
            p[rt].tv[i] = p[rt].v[i];
        }
        return ;
    }
    mid;
    if(R <= m) {
        query(L, R, lson);
        is = c;
        for(i = 1; i <= is; i ++){
            p[rt].tl[i] = p[ls].tl[i];
            p[rt].tr[i] = p[ls].tr[i];
            p[rt].tm[i] = p[ls].tm[i];
            p[rt].tv[i] = p[ls].tv[i];
        }
    }else if(m < L){
        query(L, R, rson);
        is = c;
        for(i = 1; i <= is; i ++){
            p[rt].tl[i] = p[rs].tl[i];
            p[rt].tr[i] = p[rs].tr[i];
            p[rt].tm[i] = p[rs].tm[i];
            p[rt].tv[i] = p[rs].tv[i];
        }
    }else{
        query(L, R, lson);
        query(L, R, rson);
        Up(rt, ls, rs);
    }
}
void update(int d, int k, int l, int r, int rt){
    if(l == r){
        p[rt].r[1] = p[rt].l[1] = p[rt].v[1] = p[rt].m[1] = k;
        return ;
    }
    mid;
    if(d <= m) update(d, k,lson);
    else update(d, k, rson);
    PushUp(rt, ls, rs);
}
int main(){
    int n;
    cin >> n;
    int i;
    for(i = 0; i < n; i ++) scanf("%d", &val[i]);
    build(0, n-1, 1);
    int m;
    scanf("%d", &m);
    int a, b, op;
    while(m --){
        scanf("%d", &op);
        scanf("%d%d", &a, &b);
        if(op == 1){
            a --;
            b --;
            scanf("%d", &c);
            query(a, b, 0, n-1, 1);
            int ans = 0;
            for(i = 1; i <= c; i ++){
                ans = max(ans, p[1].tm[i]);
            }
            printf("%d\n", ans);
        }else {
            a --;
            update(a, b, 0, n-1, 1);
        }
    }
    return 0;
}

/*
15
-4 8 -3 -10 10 5 -7 -7 0 -3 3 8 -10 7 2
15
1 5 6 1
1 4 9 1
1 7 9 1
0 10 -3
1 4 10 2
1 3 13 2
1 4 11 2
0 15 -9
0 13 -9
0 11 -10
1 5 14 2
1 6 12 1
*/