//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string>
#include <map>
#include <cstring>
#include <algorithm>

int f_min(int x,int y) {return x>y?y:x;}
int f_max(int x,int y) {return x>y?x:y;}
int f_abs(int x) {return x>0?x:(-x);}
using namespace std;

const int MM = 1111;
int N,M;
int maze[55][55];
string a,b,c,d;
int mx;
int cc[MM];

map<char,int>mp;

bool ok(char ch) {
    return (ch>='0' && ch<='9');
}
void get_init() {
    mp.clear();
    for(int i=0;i<26;i++) mp['A'+i]=10+i;
//  printf("%c\n",'A'+i-1);
    for(int j=0;j<10;j++) mp['0'+j]=j;
}
void get_data() {
    int i,j,k;
    mx=-1;
    get_init();
    a=b="";
    for(i=c.length()-1;i>=0;i--) a+=c[i];
    for(i=d.length()-1;i>=0;i--) b+=d[i];
    for(i=0;i<a.length();i++) {
        if(mx==-1||mx<mp[a[i]]) mx=mp[a[i]];
    }
    for(i=0;i<b.length();i++) {
        if(mx==-1||mx<mp[b[i]]) mx=mp[b[i]];
    }
}

void solve() {
    int  i,j,k,p,ans=0,sum=0,len=0,tt,tmp,t1, cnt;
    for(p=mx+1;p<5000;p++) {
        tt=f_max(a.length(),b.length());
        tmp=0; len=0; cnt=0;
        memset(cc,0,sizeof(cc));
        for(i=0;i<tt;i++) {
            t1=mp[a[i]]+mp[b[i]];
            cc[cnt++]=(tmp+t1)%p;
            tmp=(tmp+t1)/p;
        }
        if(tmp) cc[cnt++]=tmp;
//      if(p==2) {
//          for(j=cnt-1;j>=0;j--) printf("%d",cc[j]); printf("\n");
//      }
        if(tmp<10 && tmp>0) len++;
        for(i=0;i<tt;i++) if(cc[i]<10) len++;
//      if(p<17) printf("%d %d\n",p,len);
        if(ans<len) ans=len;
    }
    printf("%d\n",ans);
}

int main() {
     while(cin>>c>>d) get_data(),solve();
    return 0;
}