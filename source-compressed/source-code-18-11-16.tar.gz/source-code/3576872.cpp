//Language: GNU C++


/* 

    GSKHIRTLADZE
    
*/

#include<iostream>
#include<stdio.h>
#include<math.h>
#include<algorithm>
#include<vector>
#include<map>
#include<queue>
#include<string>

using namespace std;

struct name
 {
  long long x;
  long long ind;
 };

bool operator<(name A,name B)
 {
  return A.x<B.x;
 };

name a[300000];
long long b[300000];
long long n,m,k,last,num1,i,j,N;

main()
 {
  cin>>n>>m>>k;
  for (i=1;i<=n;i++) cin>>a[i].x,a[i].ind=1;
  for (i=n+1;i<=n+m;i++) cin>>a[i].x,a[i].ind=2;
  sort(a+1,a+n+m+1);
  last=a[1].x;
  a[1].x=1;
  N=n+m;
  for (i=2;i<=N;i++)
   if (a[i].x == last) a[i].x=a[i-1].x; else
    {
     last=a[i].x;
     a[i].x=a[i-1].x+1;
    }
  N=n+m;
  last=N+10;
  for (i=1;i<=N;i++)
   {
    if (a[i].ind == 1) b[a[i].x]++; else
     b[a[i].x]--;
   }
  for (i=last;i>=1;i--)
   {
    num1+=b[i];
    if (num1 > 0)
     {
      cout<<"YES"<<endl;
      return 0;
     }
   }
  cout<<"NO"<<endl;
 }

