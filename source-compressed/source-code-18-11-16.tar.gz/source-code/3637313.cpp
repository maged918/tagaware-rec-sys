//Language: GNU C++


#include<cstdio>
#define mod 7340033
using namespace std;
long long f[35][1100];
long long d[1100];

int main() {
	int i,j,k,t,test,n,s;
	f[0][0]=1;
	for (i=1;i<=32;i++) {
		f[i][0]=1;
		for (t=1;t<=4;t++) {
			for (j=0;j<=1000;j++) d[j]=0;
			for (j=0;j<=1000;j++)
				for (k=0;k<=j;k++)
					d[j]=(d[j]+f[i][k]*f[i-1][j-k])%mod;
			for (j=0;j<=1000;j++) f[i][j]=d[j];
		}
		for (j=1000;j>=0;j--) f[i][j+1]=f[i][j];
		f[i][0]=1;
	}
	for (scanf("%d",&test);test;test--) {
		scanf("%d%d",&n,&k);
		for (s=0;n&1;s++) n/=2;
		if (!n) s--;
		printf("%I64d\n",f[s][k]);
	}
}
