//Language: GNU C++


#include<cstdio>  
#include<iostream>  
#include<algorithm>  
#include<cstring>
#include<vector>
using namespace std; 
int a[100005][2];
int b[100005], c[100005], rank[100005];
int cmp(const void *a, const void *b){
	return *(int*)a - *(int *)b;
}
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i][0]);
		a[i][1]=i;
	}
	qsort(a,n,sizeof(int)*2,cmp);
	for(int i=0;i<n;i++)
		rank[a[i][1]]=i;
	int m = (n/3) + (n%3 != 0);
	for(int i=0;i<m;i++){
		b[i] = i;
		c[i] = a[i][0] - i;
	}
	for(int i=m;i<n-m;i++){
		c[i] = i;
		b[i] = a[i][0] - i;
	}
	for(int i=n-m;i<n;i++){
		c[i] = n-i-1;
		b[i] = a[i][0]- c[i];
	}
	printf("YES\n");
	for(int i=0;i<n;i++){
		printf("%d ", b[rank[i]]);
	} 
	printf("\n");
	for(int i=0;i<n;i++){
		printf("%d ", c[rank[i]]);
	} 
	//cin>>n;
}
