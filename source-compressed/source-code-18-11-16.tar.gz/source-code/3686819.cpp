//Language: MS C++


#include <iostream>
#include <string>
#include <stdio.h>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;
typedef long long ll;
const int maxn = 120;
const ll MAX_INT = 1<<30;


int a[maxn];

std::vector< pair<int,int> > buffer ;
ll g[maxn][maxn];
bool visited[maxn];
ll dist[maxn];

void dij(int n)
{
	for (int i = 1; i <= n; ++i)
	{
		dist[i] = g[1][i];
		visited[i] = false;
	}

	dist[1] = 0;
	visited[1] = true;

	for( int i = 2 ;  i <= n ; ++i)
	{
		ll tmpMax = MAX_INT;
		int u = 1;
		for(int j = 1 ; j <= n ; j++)
			if( visited[j] == false && dist[j] < tmpMax)
				u = j , tmpMax = dist[j];
		visited[u] = true;
		
		for( int j = 1 ; j <= n ; ++j)
		{
			if(visited[j] == false && g[u][j] < MAX_INT)
			{
				int newDist = dist[u] + g[u][j];
				
				if(newDist < dist[j])
				{
					dist[j] = newDist;
					
				}
			}
		}
	}
}
int main(int argc, char const *argv[])
{
	
	
	int n,d;
	int u,v;
	while(~scanf("%d%d",&n,&d))
	{
		buffer.clear();
		for (int i = 0; i <= n; ++i)
			for (int j = 0; j <= n; ++j)
				g[i][j] = MAX_INT;

		a[1] = a[n] = 0;
		for (int i = 2; i <= n-1; ++i)
			scanf("%d",&a[i]);
		for (int i = 0; i < n; ++i)
		{
			scanf("%d%d",&u,&v);
			buffer.push_back(make_pair(u,v));
		}

		for (int i = 0; i < buffer.size() ; ++i)
		{
			for (int j = 0 ; j < buffer.size() ; ++j)
			{
				if(i == j)
					continue;
				int t = abs(buffer[i].first - buffer[j].first) + abs(buffer[i].second - buffer[j].second);
				g[i+1][j+1] = (t*1L)*(d*1L) - a[i+1]*1L;
				
			}
		}

		dij(n);

		cout << dist[n]<< endl;
	}
	return 0;
}
