//Language: GNU C++


#include <iostream>
#include <string>
#include <map>
#include <cstdlib>
#include <cstdio>
#include <string.h>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    int n;
    cin>>n;
    vector<int> v;
    for(int i = 0 ; i < n ; i++)
    {
        int temp;
        cin>>temp;
        v.push_back(temp);
    }
    vector<int>::iterator Min = min_element( v.begin() , v.end() );
    vector<int>::iterator Max = max_element( v.begin() , v.end() );
    int ML;
    for(int i = v.size()-1 ; i >= 0 ; i-- )
    {
        if(v[i] == *Min)
        {
            ML = i;
            break;
        }
    }
    int MAXL;
    for(int i = 0 ; i < v.size() ; i++)
    {
        if(v[i] == *Max)
        {
            MAXL = i;
            break;
        }
    }
    if(MAXL > ML)
    {
        cout<<MAXL + (v.size() - ML) - 2;
    }
    else
    {
        cout<<MAXL + v.size() - ML - 1;
    }
    return 0;
}
