//Language: GNU C++


// @utor : thnkndblv
#include "stdio.h"
#include "memory.h"
#include "string.h"
#include "ctype.h"
#include "math.h"
#include "limits.h"
#include "iostream"
#include "string"
#include "algorithm"
#include "utility"
#include "vector"
#include "sstream"
#include "stack"
#include "queue"
#include "deque"
#include "set"
#include "map"
#include "bitset"

using namespace std;

/*---------------------------------- Macros ----------------------------------*/
#define foreach(i, a) for (typeof((a).begin()) i = (a).begin(); i != (a).end(); i++)
#define fori(i, a, b) for (int i=(a); i<(b); i++)
#define forn(i, n) fori(i, 0, (n))

#define all(x) (x).begin(), (x).end()
#define null(x) memset((x), -1, sizeof (x))
#define zero(x) memset((x), 0, sizeof (x))

#define pb push_back
#define mp make_pair
#define upb upper_bound
#define lwb lower_bound
#define fr first
#define sc second

#define oo 1000000000

/*------------------------ Redefinir tipos de datos --------------------------*/
typedef vector<int> vi;
typedef long long Long;
typedef pair<int,int> ii;
typedef map<int,int> mii;
typedef map<string,int> msi;

/*------------------------------- Funciones ----------------------------------*/
inline Long mod(Long n, Long m = (Long)(1e9 + 7)){ return (n % m + m) % m; }
inline Long gcd(Long a, Long b){ return (b == 0LL) ? a : gcd(b, a % b); }
inline Long modPow(Long a, Long b, Long m = (Long)(1e9 + 7))
{
    Long ret = 1LL;
    while ( b > 0LL )
    {
        if ( b & 1 ) ret = mod( ret * a, m );
        a = mod( a * a, m );
        b >>= 1;
    }
    return ret;
}
inline bool leapYear(int year){ return (year%400 == 0) || (year%100 != 0 && year%4 == 0); }

/*-------------------------- PROGRAMA PRINCIPAL ------------------------------*/
void continuedFraction(Long p, Long q, std::vector<Long> &a)
{
    if ( q != 0LL )
    {
        a.pb( p / q );
        continuedFraction( q, p % q, a );
    }
}

int main()
{
    #ifdef thnkndblv
    freopen("b.in","rt",stdin);
    #endif

    Long p, q;
    while ( cin >> p >> q )
    {
        int n;
        cin >> n;
        vector< Long > a( n );
        forn(i, n) cin >> a[ i ];
        if ( a.size() > 1 && a.back()==1 )
        {
            a.pop_back();
            a.back()++;
        }

        std::vector<Long> b;
        continuedFraction(p, q, b);

        bool ans;
        if ( a.size() == b.size() )
        {
            ans = true;
            forn(i, a.size())
            {
                if ( a[i] != b[i] )
                    ans = false;
            }
        }
        else ans = false;
        puts( ans ? "YES" : "NO" );
    }

    return 0;
}
