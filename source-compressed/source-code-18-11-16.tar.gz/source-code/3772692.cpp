//Language: GNU C++


#include <cstdio>
#include <climits>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <string>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <functional>
#include <iostream>
#include <map>
#include <set>
using namespace std;
typedef pair<int,int> P;
typedef long long ll;
#define pu push
#define pb push_back
#define mp make_pair
#define eps 1e-7
#define INF 2000000000
ll gcd(ll a,ll b)
{
	if(a<b)swap(a,b);
	if(a%b==0)return b;
	return gcd(b,a%b);
}
int main()
{
	ll p,q,r;
	cin >> p >> q;
	r=gcd(p,q);
	p/=r;
	q/=r;
	ll a[90];
	int n;
	ll tmp;
	cin >> n;
	for(int i=0;i<n;i++)
	{
		cin >> a[i];
	}
	ll s=a[n-1],t=1,u;
	for(int i=n-1;i>0;i--)
	{
		u=s;
		if((ll)(LLONG_MAX/s)<=a[i-1])
		{
			cout << "NO" << endl;
			return 0;
		}	
		s*=a[i-1];
		//cout << s << endl;
		s+=t;
		//cout << s << endl;
		t=u;
		if(s>1e18)
		{
			cout << "NO" << endl;
			return 0;
		}
		//cout << s << ' ' << t << endl;
	}
	u=gcd(s,t);
	s/=u;
	t/=u;
	//cout << s << ' ' << t << endl;
	if(s==p&&t==q)cout << "YES" << endl;
	else cout << "NO" << endl;
	return 0;
}
