//Language: GNU C++


#include <string.h>
#include <stdio.h>
#include <algorithm>
#include <iostream>
#include <stdlib.h>

using namespace std;

const int N = 2000010;
const long long inf = 0x3f3f3f3f3f3f3f3fll;

typedef long long ll;

#define pb push_back
#define sz(x) ((x).size())

int n, m, k;

struct Data{
	int l, r, c;
	bool operator < (const Data &o) const{
		if(r != o.r) return r < o.r;
		return l < o.l;
	}
};

ll dp[310][310];
ll C[310][310];

int main(){
	memset(C, 0x3f, sizeof(C));
	memset(dp, 0x3f, sizeof(dp));
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 0; i < m; i++){
		int l, r, c;
		scanf("%d%d%d", &l, &r, &c);
		for(int j = l; j <= r; j++)
			C[l][j] = min(C[l][j], 0ll + c);
	}
	dp[0][0] = 0;
	for(int i = 1; i <= n; i++)
		for(int j = i; j >= 0; j--){
			dp[i][j] = dp[i - 1][j];
			dp[i][j] = min(dp[i][j], dp[i][j + 1]);
			for(int k = 0; k < i; k++){
				int t = i - k;
				if(j < t) continue;
				dp[i][j] = min(dp[i][j], dp[k][j - t] + C[k + 1][i]);
			}
		}
	//for(int i = 1; i <= n; i++)
		//for(int j = 0; j <= i; j++)
			//printf("dp[%d][%d] = %d\n", i, j, dp[i][j]);
	ll ret = inf;
	for(int i = k; i <= n; i++)
		ret = min(dp[n][i], ret);
	if(ret == inf) puts("-1");
	else printf("%I64d\n", ret);
	return 0;
}
