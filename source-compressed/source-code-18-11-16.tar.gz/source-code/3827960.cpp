//Language: GNU C++



#define _CRT_SECURE_NO_DEPRECATE
#define _SECURE_SCL 0
#pragma comment(linker, "/STACK:200000000")
 
#include <algorithm>
#include <bitset>
#include <cassert>
#include <cctype>
#include <complex>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <functional>
#include <fstream>
#include <iostream>
#include <map>
#include <memory.h>
#include <numeric>
#include <iomanip>
#include <queue>
#include <set>
#include <stack>
#include <list>
#include <string>
#include <sstream>
#include <vector>
#include <utility>
#include <cmath>

// all includes ahol


using namespace std;
#define fvi(v) for(vector<int>::iterator it=v.begin();it!=v.end();it++)
#define fvs(v) for(vector<string>::iterator it=v.begin();it!=v.end();it++)
#define ff(i,n) for(int i=0;i<int(n);i++)
#define f(i,a,b) for(int i=int(a);i<int(b);i++)
#define i(n) for(int i=0;i<int(n);i++)
#define j(n) for(int j=0;j<int(n);j++)

#define ii pair<int,int>
#define vi vector<int>
#define vvi vector<vector<int> >
#define vs vector<string>
#define pb push_back
#define	c(a) cout<<a<<endl;

#define si set<int>
#define ss set<string>
#define mp make_pair
#define mii map<int,int>

#define st string
#define l(a) a.length()

#define tr(container, it) \
	for(typeof(container.begin()) it = container.begin(); it != container.end(); it++)

#define ptr(z) \
	tr(z,it){cout<<(*it)<<" ";} c("");
#define sz(v) v.size()

#define pn c("");
#define ps cout<<" ";

#define all(v) v.begin(),v.end()
#define s(v) sort(v.begin(),v.end())

#define rs(v) sort(v.rbegin(),v.rend())
#define vmax(v) *max_element(all(v)) // value
#define vmin(v) *min_element(all(v)) // value
#define imin(v) max_element(all(v))-v.begin() // index
#define imax(v) min_element(all(v))-v.begin() // index


#define ifnd(v,val) find(all(v),val)-v.begin() //index
#define fnd(v,val) find(all(v),val) //iterator

#define mem(dp,a) memset(dp,a,sizeof(dp))
#define vit vector<int> :: iterator


#define eps 1e-8


typedef long long int ll;




int main()
{
	int a,b,x,y,s=0,c=0,k,n,m,p,q;
	vi z;
	cin>>n;string h;
	cin>>h;
	n=l(h);
	i(n-1){
		if(h[i]==h[i+1]){
			c++;
		}
	}
	c(c);
	return 0;
}
