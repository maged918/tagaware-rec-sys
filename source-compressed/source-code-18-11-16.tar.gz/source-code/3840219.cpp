//Language: GNU C++


#include<iostream>

using namespace std;
int a[200010];
int main(){
	int n,k; cin>>n>>k;
	for(int i=0; i<n; i++)	cin>>a[i];
	
	long long sum=0, counter=1,current=n,d;
	
	for(int i=1; i<n; i++){
		d=sum- (current-counter-1)*a[i]*(counter);
//		cout<<i<<' '<<d<<endl;
		if(d<k){
			cout<<(i+1)<<endl;
			current--;
		}
		else{
			sum+=a[i]*counter;
			counter++;
		}
	}
}
