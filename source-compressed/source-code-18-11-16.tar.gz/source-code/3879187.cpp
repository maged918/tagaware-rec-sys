//Language: MS C++


#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <queue>
using namespace std;

const int dx[4] = {0, 1, 0, -1};
const int dy[4] = {1, 0, -1, 0};

struct Event
{
	int comp;
	int dir;
	int smallDir;

	Event () {}
	Event (int comp, int dir, int smallDir) : comp(comp), dir(dir), smallDir(smallDir) {}
};

vector < Event > events;
char s[55][55];
bool f[55][55];
int comp[55][55];
int qx[2505], qy[2505];
int compXL[2505], compXR[2505], compYL[2505], compYR[2505];
int e[2505][4][2];
int compFieldX[2505][4][2], compFieldY[2505][4][2];
int n, m, steps;
int qSize;

bool inField (int x, int y)
{
	return x > -1 && x < n && y > -1 && y < m;
}

void bfs (int xs, int ys, int & compInd)
{
	qx[0] = xs; qy[0] = ys;
	qSize = 1;
	f[xs][ys] = true;
	int cur = 0;

	if (s[xs][ys] == '0')
		return ;

	char curCol = s[xs][ys];

	int xMin = xs, xMax = xs;
	int yMin = ys, yMax = ys;

	while (cur < qSize)
	{
		int xCur = qx[cur], yCur = qy[cur];
		cur++;
		
		for (int i = 0; i < 4; i++)
		{
			int xNext = xCur + dx[i];
			int yNext = yCur + dy[i];

			if (!inField(xNext, yNext) || s[xNext][yNext] != curCol || f[xNext][yNext] )
				continue;

			f[xNext][yNext] = true;
			qx[qSize] = xNext;
			qy[qSize] = yNext;
			qSize++;

			xMin = min(xMin, xNext);
			xMax = max(xMax, xNext);
			yMin = min(yMin, yNext);
			yMax = max(yMax, yNext);
		}
	}

	for (int i = 0; i < qSize; i++)
	{
		comp[qx[i] ][qy[i] ] = compInd;
	}

	compXL[compInd] = xMin;
	compXR[compInd] = xMax;
	compYL[compInd] = yMin;
	compYR[compInd] = yMax;

	// fields positions

	compFieldX[compInd][0][0] = xMin;
	compFieldY[compInd][0][0] = yMax;
	compFieldX[compInd][0][1] = xMax;
	compFieldY[compInd][0][1] = yMax;

	compFieldX[compInd][1][0] = xMax;
	compFieldY[compInd][1][0] = yMax;
	compFieldX[compInd][1][1] = xMax;
	compFieldY[compInd][1][1] = yMin;

	compFieldX[compInd][2][0] = xMax;
	compFieldY[compInd][2][0] = yMin;
	compFieldX[compInd][2][1] = xMin;
	compFieldY[compInd][2][1] = yMin;

	compFieldX[compInd][3][0] = xMin;
	compFieldY[compInd][3][0] = yMin;
	compFieldX[compInd][3][1] = xMin;
	compFieldY[compInd][3][1] = yMax;

	// #fields positions

	compInd++;
}

Event getNextEvent (Event cur)
{
	int x = compFieldX[cur.comp][cur.dir][cur.smallDir];
	int y = compFieldY[cur.comp][cur.dir][cur.smallDir];

	int xn = x + dx[cur.dir];
	int yn = y + dy[cur.dir];

	if (!inField(xn, yn) || s[xn][yn] == '0')
	{
		if (cur.smallDir == 0)
		{
			cur.smallDir = 1;
		}else
		{
			cur.smallDir = 0;
			cur.dir = (cur.dir + 1) % 4;
		}
	}else
	{
		cur.comp = comp[xn][yn];
	}

	return cur;
}

int main ()
{
	//freopen("input.txt", "rt", stdin);
	//freopen("output.txt", "wt", stdout);

	scanf("%d%d\n", &n, &steps);
	for (int i = 0; i < n; i++)
	{
		gets(s[i] );
	}
	m = strlen(s[0] );

	int compInd = 0;
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < m; j++)
		{
			if (!f[i][j] )
				bfs(i, j, compInd);
		}
	}

	for (int i = 0; i < 2505; i++)
		for (int j = 0; j < 4; j++)
			for (int k = 0; k < 2; k++)
				e[i][j][k] = -1;

	events.push_back(Event(comp[0][0], 0, 0) );
	e[comp[0][0] ][0][0] = 0;
	for (int i = 0; ; i++)
	{
		Event curEvent = getNextEvent(events.back() );

		if (i + 1 == steps)
		{
			printf("%c", s[compXL[curEvent.comp] ][compYL[curEvent.comp] ] );
			return 0;
		}

		if (e[curEvent.comp][curEvent.dir][curEvent.smallDir] == -1)
		{
			e[curEvent.comp][curEvent.dir][curEvent.smallDir] = i + 1;
			events.push_back(curEvent);
			continue;
		}

		// getting answer

		int st = e[curEvent.comp][curEvent.dir][curEvent.smallDir];
		int per = events.size() - st;

		int rem = steps - (i + 1);
		rem %= per;

		curEvent = events[st + rem];
		printf("%c", s[compXL[curEvent.comp] ][compYL[curEvent.comp] ] );
		return 0;
	}

	throw 42;

	return 0;
}