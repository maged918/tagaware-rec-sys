//Language: MS C++


#include <iostream>
using namespace std;


int main(int argc, char* argv[]){
    char name[81];
    cin >> name;
    unsigned n;
    cin >> n;
    char fri[200][81];
    char fri_ok[200][81];
    unsigned ozen[200]={0};
    unsigned ozen_ok[200]={0};
    char str_znaz[5][81];
    char str[81];
    unsigned count = 0;
    for(unsigned i=0; i<n; i++){
        cin.getline(str, 80);
        if(strlen(str)<10){
            i--;
            continue;
        }
        char *ptr = strtok(str, " \n\t");
        int k = 0;
        while(ptr){
            strcpy(str_znaz[k], ptr);
            ptr = strtok(NULL, " \n\t");
            k++;
        }
        if(k==4){
            strcpy(str_znaz[2], strtok(str_znaz[2], "'"));
            if(strcmp(str_znaz[0], name)==0){
                strcpy(fri[count], str_znaz[2]);
            }
            else{
                strcpy(fri[count], str_znaz[0]);
            }
            if((strcmp(str_znaz[0], name)==0) || (strcmp(str_znaz[2], name)==0)){
                ozen[count] = 5;
            }
            else{
                ozen[count] = 0;
                count++;
                strcpy(fri[count], str_znaz[2]);
                ozen[count] = 0;
            }
            count++;
        }
        else{
            strcpy(str_znaz[3], strtok(str_znaz[3], "'"));
            if(strcmp(str_znaz[0], name)==0){
                strcpy(fri[count], str_znaz[3]);
            }
            else{
                strcpy(fri[count], str_znaz[0]);
            }
            if((strcmp(str_znaz[0], name)==0) || (strcmp(str_znaz[3], name)==0)){
                if(strcmp(str_znaz[1], "posted")==0){
                    ozen[count] = 15;
                }
                else{
                    ozen[count] = 10;
                }
            }
            else{
                ozen[count] = 0;
                count++;
                strcpy(fri[count], str_znaz[3]);
                ozen[count] = 0;
            }
            count++;
        }
    }
    unsigned count_ok=0;
    for(unsigned i = 0; i<count; i++){
        unsigned j = 0;
        for(; j<count_ok; j++){
            if(strcmp(fri[i], fri_ok[j])==0){
                break;
            }
        }
        if(j == count_ok){
            strcpy(fri_ok[count_ok], fri[i]);
            ozen_ok[count_ok]+=ozen[i];
            count_ok++;
        }
        else{
            ozen_ok[j]+=ozen[i];
        }
    }
    unsigned flag=1;
    while(flag){
        flag =0;
        for(unsigned i=0; i<count_ok-1; i++){
            if((ozen_ok[i]<ozen_ok[i+1]) || ((ozen_ok[i]==ozen_ok[i+1]) && (strcmp(fri_ok[i], fri_ok[i+1])>0))){
                strcpy(str, fri_ok[i]);
                strcpy(fri_ok[i], fri_ok[i+1]);
                strcpy(fri_ok[i+1], str);
                unsigned tmp = ozen_ok[i];
                ozen_ok[i] = ozen_ok[i+1];
                ozen_ok[i+1] = tmp;
                flag =1;
            }
        }
    }
    for(unsigned i = 0; i<count_ok; i++){
        cout << fri_ok[i] << endl;
    }
    return 0;
}