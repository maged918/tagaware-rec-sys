//Language: GNU C++


#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <set>
#include <cassert>
using namespace std;
const int Maxn = 2e5 + 11;
set<int>st;
struct SegmentTree
{
	struct Node
	{
		int from, to, v;
		Node(){}
		Node(int from, int to, int v) : from(from), to(to), v(v){}
	}node[Maxn << 2];
	void build(int p, int from, int to)
	{
		node[p] = Node(from, to, 0);
		if (from == to) return;
		int mid = (from + to >> 1);
		build(p << 1, from, mid);
		build(p << 1 | 1, mid + 1, to);
	}
	void update(int p)
	{
		node[p].v = max(node[p << 1].v, node[p << 1 | 1].v);
	}
	void insert(int p, int k, int v)
	{
		if (node[p].from == node[p].to)
		{
			node[p].v = v;
			return;
		}
		int mid = node[p << 1].to;
		if (mid >= k) insert(p << 1, k, v);
		else insert(p << 1 | 1, k, v);
		update(p);
	}
	int search(int p, int k)
	{
		if (node[p].from == k)
			return node[p].v;
		int mid = node[p << 1].to;

		if (k <= mid) return max(search(p << 1, k), node[p << 1 | 1].v);
		else return search(p << 1 | 1, k);
	}
}segp, segh;
int n, m;
int htop[Maxn], ptoh[Maxn];

void plant(int p, int h)
{
	htop[h] = p;
	ptoh[p] = h;
	st.insert(p);
	for (int i = max(h - 10, 1); i < h; ++i)
		if (htop[i])
			segp.insert(1, htop[i], 0);
	int res = segp.search(1, p) + 1;
	segp.insert(1, p, res);
	segh.insert(1, h, res);
	
	for (int i = h - 1; i >= max(h - 10, 1); --i)
	{
		if(htop[i])
		{
			res = segp.search(1, htop[i]) + 1;
			segp.insert(1, htop[i], res);
			segh.insert(1, i, res);
		}
	}
	printf("%d\n", segp.search(1, 1));
}

void cut(int ind)
{
	assert(ind <= st.size());
	set<int>::iterator it = st.begin();
	for (int i = 0; i < ind; ++i, ++it)
	{
		int p = *it;
		assert(ptoh[p]);
		segh.insert(1, ptoh[p], 0);
	}
	it--;
	htop[ptoh[*it]] = 0;
	ptoh[*it] = 0;
	segp.insert(1, *it, 0);
	int p = *it;
while (it != st.begin())
	{
		--it;
		int p = *it;
		int res = segh.search(1, ptoh[p]) + 1;
		segh.insert(1, ptoh[p], res);
		segp.insert(1, p, res);
	}
st.erase(p);
	printf("%d\n", segp.search(1, 1));
}

int main()
{
	while (scanf("%d%d", &n, &m) != EOF)
	{
		st.clear();
		segp.build(1, 1, n);
		segh.build(1, 1, m + 10);
		memset(htop, 0, sizeof(htop));
		memset(ptoh, 0, sizeof(ptoh));
		for (int i = 0; i < m; ++i)
		{
			int type;
			scanf("%d", &type);
			if (type == 1)
			{
				int p, h;
				scanf("%d%d", &p, &h);
				h += m - i;
				plant(p, h);
			}
			else 
			{
				int ind;
				scanf("%d", &ind);
				cut(ind);
			}
		}
	}
	return 0;
}
