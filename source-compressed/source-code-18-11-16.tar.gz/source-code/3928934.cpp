//Language: GNU C++



#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<iostream>

using namespace std;

typedef long long LL;

int main(){

        LL a,b,m;
        cin >> a >> b >> m;

        //sort a,b
        if(a>b)swap(a,b);

        //if satisfied, no operation is needed
        if(b>=m){
                puts("0");
                return 0;
        }

        //if b is positive
        if(b > 0){
                LL cnt = 0;

                //if a is negative or zero
                if(a<=0){
                        LL tmp = (-a)/b+1;
                        a+=tmp*b;
                        cnt+=tmp;
                }

                //now a>0 and a<=b
                while(true){
                        LL tmp = a+b;
                        a = b;
                        b = tmp;
                        cnt++;
                        if(b>=m)break;
                }

                cout << cnt << endl;
        }
        else{
                puts("-1");
        }

        return 0;
}
