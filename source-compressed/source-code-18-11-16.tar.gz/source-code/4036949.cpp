//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<memory.h>
#include<string>
#include<cmath>
#include<cctype>
#include<algorithm>
#include<queue>
#include<set>
#include<map>
#include<stack>
#include<vector>
#include<functional>
#define sqr(x) ((x)*(x))
#define ll long long
#define ii pair<int,int>
#define mp make_pair
#define ms(x,y) memset(x,y,sizeof(x))
#define rep(x,y,z) for (int x=y;x<z;x++)
#define drep(x,y,z) for (int x=y;x>=z;x--)
#define all(x) x.begin(),x.end()
#define X first
#define Y second
using namespace std;
const int size=210000,mod=1000000007,inf=0x3f3f3f3f;
const ll llinf=0x3f3f3f3f3f3f3f3f;
const double pi=acos(-1.0),eps=1e-6;
int month[2][13]={0,31,28,31,30,31,30,31,31,30,31,30,31,
				  0,31,29,31,30,31,30,31,31,30,31,30,31};
int nex[2][8]={-1,0,1,0,-1,1,1,-1,0,1,0,-1,1,1,0,0};
template<class T> void inc(T &a,T b){a=(a+b)%mod;}
template<class T> T modu(T a){return (a%mod+mod)%mod;}
template<class T> void crl(T* l,T *r,int step){T tmp=*l;for (T* i=l;i<r;i+=step)*i=*(i+step);*(r-1)=tmp;}
template<class T> void crr(T* l,T *r,int step){T tmp=*(r-1);for (T* i=r-1;i>l;i-=step)*i=*(i-step);*l=tmp;}
bool dbeq(double a,double b){return fabs(a-b)<eps;}
template<class T> void cmin(T& a,T b){a=min(a,b);}
template<class T> void cmax(T& a,T b){a=max(a,b);}
/***********************************************************/
string a,c;
int b,d,f[110],ans;
int main ()
{
	cin>>b>>d>>a>>c;
	rep(i,0,c.size())
		rep(j,0,a.size())
			if (c[(i+f[i])%c.size()]==a[j])
				f[i]++;
	int cir;
	rep(i,1,b+1)
	{
		ans+=f[ans%c.size()];
		if (ans%c.size()==0)
		{
			cir=i;
			break;
		}
	}
	ans*=b/cir;
	rep(i,0,b%cir)
		ans+=f[ans%c.size()];
	printf("%d\n",ans/c.size()/d);
	return 0;
}