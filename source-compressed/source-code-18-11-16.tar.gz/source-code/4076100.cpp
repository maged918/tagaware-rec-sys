//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;

void quickSort(int *a,int *b,size_t left,size_t right)
{
    size_t p = (left + right)/2;
    int key = a[p];
    int bkey=b[p];
    for(size_t i = left,j = right; i < j;)
    {
        while(!(key < a[i] || p < i))
            i++;
        if(i < p)
        {
            a[p] = a[i];
            b[p]=b[i];
            p = i;
        }
        while(j>0 && !(j < p || a[j] < key))
            j--;
         if(p < j)
         {
             a[p] = a[j];
             b[p]=b[j];
             p = j;
         }
     }
     a[p] = key;
     b[p] =bkey;
     if(p - left > 1)
         quickSort(a,b,left,p-1);
     if(right - p > 1)
         quickSort(a,b,p + 1, right);
}

int main()
{
    int a[100005];
    int b[100005];
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i]>>b[i];
    }

   quickSort(a,b,1, n);
    int count=0;
    int sum=b[1];
    for(int i=2;i<=n;i++)
    {
        if(b[i]<sum)
        {
            count++;
        }
        else
        {
            sum=b[i];
        }
    }

    cout<<count;
    return 0;

}

		 					  			  	    					