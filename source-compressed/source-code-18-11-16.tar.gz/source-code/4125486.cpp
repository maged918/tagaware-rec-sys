//Language: GNU C++


#include<iostream>
#include<cctype>
#include<cmath>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<string>
#include<list>
#include<deque>
#include<cstdio>
#include<map>
#include<set>
#include<queue>
#include<stack>
#include<utility>
#include<sstream>
#include<cstring>
#include<numeric>
using namespace std;

#define FOR(I,A,B) for(int I=(A);I<=(B);I++)
#define FORD(I,A,B) for(int I=(A);I>=(B);I--)
#define REP(I,N) for(int I=0;I<(N);I++)
#define ALL(X) (X).begin(),(X).end()
#define PB push_back
#define MP make_pair
#define FI first
#define SE second
#define INFTY 100000000
#define VAR(V,init) __typeof(init) V=(init)
#define FORE(I,C) for(VAR(I,(C).begin());I!=(C).end();I++)
#define SIZE(x) ((int)(x).size())

typedef vector<int> VI;
typedef pair<int,int> PII;
typedef long long ll;
typedef vector<string> VS;

const int maxn = 1100;
char maps[maxn][maxn];
int vis[maxn][maxn],num[maxn][maxn];

int r,c;
int dir[][2]={{1,0},{-1,0},{0,1},{0,-1}};
vector<PII>pii;
PII st,et;
int ans;
struct POINT{
    PII pi;
    int step;
    int counts;
};




bool ok(PII tmp){
    if(tmp.FI<0||tmp.FI>=r||tmp.SE<0||tmp.SE>=c||vis[tmp.FI][tmp.SE]>0||vis[tmp.FI][tmp.SE]==-2)return false;
    return true;
}

void bfs(){
  //  memcpy(viss,vis,sizeof(vis));
    ans=0;
    int step=0;
    queue<POINT>que;
    POINT ets;
    ets.pi=et,ets.step=0;
    que.push(ets);
    while(!que.empty()){
        POINT top=que.front();que.pop();

        for(int i=0;i<4;i++){
            POINT tmp=top;
            tmp.pi.FI+=dir[i][0];
            tmp.pi.SE+=dir[i][1];
            if(!ok(tmp.pi))continue;
          //  printf("-----------%d,%d\n",tmp.pi.FI,tmp.pi.SE);
            tmp.step=top.step+1;
            if(vis[tmp.pi.FI][tmp.pi.SE]==-1)vis[tmp.pi.FI][tmp.pi.SE]=0;
            vis[tmp.pi.FI][tmp.pi.SE]=top.step+1;
            que.push(tmp);
        }
    }

    for(int i=0;i<r;i++){
        for(int j=0;j<c;j++){
            if(vis[i][j]!=-1){
              //  printf("%03d ", vis[i][j]);
                ans+=vis[i][j]<=vis[st.FI][st.SE]?num[i][j]:0;
            }

        }
      //  putchar(10);
    }
    printf("%d\n",ans);

}

int main(){
    while(scanf("%d%d",&r,&c)!=EOF){

        memset(vis,-1,sizeof vis);
        memset(num,0,sizeof num);
        pii.clear();
        for(int i=0;i<r;i++){
            scanf("%s",maps[i]);
            for(int j=0;j<c;j++){
                if(maps[i][j]=='T'){
                    vis[i][j]=-2;

                }
                else if(maps[i][j]=='S')vis[i][j]=0,st.FI=i,st.SE=j;
                else if(maps[i][j]=='E')et.FI=i,et.SE=j;
                else if(maps[i][j]=='0')continue;
                else {
                    num[i][j]=maps[i][j]-48;
                    pii.PB(PII(i,j));
                }
            }
        }
        bfs();
    }
    return 0;
}