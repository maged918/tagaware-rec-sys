//Language: GNU C++


#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cstring>
#define MAXK 7
#define mod 1000000007
using namespace std ;
typedef long long LL ;

struct matrix {
    LL c ;
    LL k[MAXK][MAXK] ;
    matrix operator * (matrix b) const {
        matrix n ;
        LL i, j, t ;
        n.c = c ;
        for(i = 0; i < c; i ++)
            for(j = 0; j < 7; j ++)
                for(t = 0, n.k[i][j] = 0; t < 7; t ++)
                    n.k[i][j] = (n.k[i][j]+k[i][t]*b.k[t][j])%mod ;
        return n ;
    }
} one, fr, st, ed, get ;

LL ans ;
LL L, R ;

matrix ksm(matrix x, LL t)
{
    if(!t) return one ; 
    matrix tmp = ksm(x, t/2) ;
    tmp = tmp*tmp ;
    if(t&1) tmp = tmp*x ;
    return tmp ;
}

LL Sp(LL x)
{
    if(x <= 0) return 0 ;
    ed = ksm(st, x) ;
    get = fr*ed ;
    return get.k[0][6]+1 ; 
}

int main()
{
    LL i, j ;
    scanf("%I64d %I64d", &L, &R) ;
    fr.k[0][0] = fr.k[0][1] = fr.k[0][2] = fr.k[0][3] = 1 ;
    fr.c = 1, st.c = one.c = 7 ;
    st.k[0][1] = st.k[0][2] = st.k[0][6] = 1 ;   
    st.k[1][0] = st.k[1][3] = st.k[1][6] = 1, st.k[1][5] = 1 ;
    st.k[2][0] = st.k[2][3] = st.k[2][6] = 1, st.k[2][4] = 1 ;
    st.k[3][1] = st.k[3][2] = st.k[3][6] = 1 ;
    st.k[4][1] = mod-1, st.k[5][2] = mod-1 ;
    st.k[6][6] = 1 ;
    for(i = 0; i <= 6; i ++)
        one.k[i][i] = 1 ;
    ed = ksm(st, R) ;
    get = fr*ed ;
    ans = get.k[0][6] ;
    ed = ksm(st, L-1) ;
    get = fr*ed ;
    ans = (ans-get.k[0][6]+mod)%mod ;
    st.k[1][6] = st.k[2][6] = st.k[3][6] = 2 ;
    ans += Sp((R-1)/2) ;
    ans = (ans-Sp((L-2)/2)+mod)%mod ;
    if(L == 1) ans += 4 ;
    printf("%I64d\n", ans*((1000000007+1)/2)%mod) ;
    //system("pause") ;
    return 0 ;
}

    				   					  		 	 			