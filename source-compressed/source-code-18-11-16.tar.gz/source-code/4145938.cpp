//Language: MS C++


#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
using namespace std;
int a[100010],b[100010];
int main()
{
    int n,m,k; 
	int j,i;
	int flag = 0;
    cin>>n>>m>>k;
    for( i=0;i<n;i++)
		cin >> a[i];
    for( i=0;i<m;i++)
        cin >> b[i];
    sort(a,a+n);
    sort(b,b+m);
	if(n > m)cout << "YES\n";
	else
	{
    for(i = 0,j = 0;i<n && j < m;)
    {
        if(a[i] <= b[j])
		{ 
			i++;
			j++;
		}
        else j++;
    }
    if(i==n ) cout<<"NO\n";
    else cout << "YES\n";
	}
    return 0;
}
	 		 	   		  						 						