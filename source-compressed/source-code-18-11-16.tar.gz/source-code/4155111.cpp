//Language: GNU C++


#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<queue>
#include<map>
#include<vector>
#include<cstdlib>
using namespace std;

#define max(a,b) a>b?a:b
#define min(a,b) a<b?a:b
#define LL __int64

LL a[200010];
LL mx[200010];

LL dpmax[201000][30];
LL wx[201000][30];
void rmq(LL n)
{
    LL i,j;
    for(i=1;i<=n;i++)
    {
        dpmax[i][0]=mx[i];
        wx[i][0]=i;
    }
    for(i=1;i<=log((double) n)/log(2.0);i++)
    {
        for(j=1;j+(1<<i)-1<=n;j++)
        {
            if(dpmax[j][i-1]>=dpmax[j+(1<<(i-1))][i-1])
            {
                dpmax[j][i]=dpmax[j][i-1];
                wx[j][i]=wx[j][i-1];
            }
            else 
            {
                dpmax[j][i]=dpmax[j+(1<<(i-1))][i-1];
                wx[j][i]=wx[j+(1<<(i-1))][i-1];
            }
        }
    }
}
LL getcha(LL s,LL e )
{
    LL k=log((double) e-s+1)/log(2.0);
    if(dpmax[s][k]>=dpmax[e-(1<<k)+1][k])
    {
        return wx[s][k];
    }
    return wx[e-(1<<k)+1][k];
}

int main()
{
    LL i,j,n,sum,k,maxn,s,t,f;
    while(scanf("%I64d%I64d",&n,&k)!=EOF)
    {
        sum=0;
        maxn=0;
        for(i=1;i<=n;i++)
        {
            scanf("%I64d",&a[i]);
            sum+=a[i];
            if(i>=k)
            {
                mx[i-k+1]=sum;
                sum-=a[i-k+1];
            }
        }
        rmq(n-k+1);
        maxn=0;
        for(i=1;i<=n-2*k+1;i++)
        {
            f=getcha(i+k,n-k+1);
            sum=mx[i]+mx[f];
            if(sum>maxn)
            {
                s=i;
                t=f;
                maxn=sum;
            }
        }
        printf("%I64d %I64d\n",s,t);
    }
    return 0;
}
