//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int main()
{
   
    __int64 i,n,x,y,a;
    while(cin>>n)
    {
        cin>>x>>y;
         a=y-(n-1);
        if(a*a+(n-1)>=x&&a>0)
        {
            for(i=1;i<n;i++)
            cout<<1<<endl;
            cout<<a<<endl;
        }
        else
       cout<<-1<<endl;
    }
    return 0;
}

	     	   		 	 	 	   	 	 	