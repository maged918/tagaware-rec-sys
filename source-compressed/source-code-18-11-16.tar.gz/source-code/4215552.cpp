//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

// codeforces E Paint Tree
const int N = 1503;
vector<int> next[N];

int ans[N],size[N];

struct node
{
    int x,y;
    int id;
    int root;
} num[N];
bool operator <(const node &a, const node &b)
{

    ///  O A B
    int root = a.root;
    long long xx = a.x- num[root].x;
    long long x1 = b.x- num[root].x;
    long long yy = a.y- num[root].y;
    long long y1 = b.y- num[root].y;
    return xx*y1 - x1*yy > 0;
}

void dfs(int u,int v)
{
    size[v] = 1;
    for(int i=0; i<next[v].size(); i++)
        if(next[v][i] != u)
        {
            dfs(v,next[v][i]);
            size[v] += size[next[v][i]];
        }
    return ;
}

void gao(int u,int v,int l,int r)
{
    int i;
    num[l].root = l;
    for(i=l+1; i<r; i++)
    {
        num[i].root = l;
        if(num[i].x < num[l].x || num[i].x == num[l].x && num[i].y <= num[l].y)
        {
            swap(num[i].x,num[l].x);
            swap(num[i].y,num[l].y);
            swap(num[i].id,num[l].id);
        }
    }
    ans[num[l].id] = v;
    sort(num+l+1,num+r);
    int have = 1;
    for(i=0; i<next[v].size(); i++)
        if(next[v][i] != u)
        {
            gao(v,next[v][i],l+have,l+have+size[next[v][i]]);
            have += size[next[v][i]];
        }
    return ;
}

int main()
{
    int n,i;
    scanf("%d",&n);
    for(i=1; i<n; i++)
    {
        int l,r;
        scanf("%d%d",&l,&r);
        l--;
        r--;
        next[l].push_back(r);
        next[r].push_back(l);
    }
    for(i=0; i<n; i++)
    {
        scanf("%d%d",&num[i].x,&num[i].y);
        num[i].id = i;
    }
    dfs(-1,0);
    gao(-1,0,0,n);
    for(i=0; i<n; i++)
        printf("%d%c",ans[i]+1,i==(n-1)?'\n':' ');
    return 0;
}
