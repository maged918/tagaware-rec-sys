//Language: GNU C++0x


#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include <sstream>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <deque>
#include <assert.h>
#include <ctime>
#include <bitset>
#include <numeric>
#include <complex>
//#include <conio.h>
using namespace std;

#define FOR(i, a, n) for (register int i = (a); i < (int)(n); ++i)
#define Size(n) ((int)(n).size())
#define pb push_back
#define X first
#define Y second
#define mp make_pair
#define MFOR(i,m,n) for(int i=m;i>n;i--)
#define error(x) cerr<<endl<<x<<endl;
#define PI 3.1415926535897932384626433

typedef long long ll;
typedef pair <int,ll> pil;
typedef pair <int,int> pii;
typedef pair <int,pii> piii;

void error2(const string &s,const int &t){
	cerr<<endl<<"  "<<s<<" = "<<t<<endl;
}

void error3(const string &s,const long double &t){
	cerr<<endl<<"  "<<s<<" = "<<t<<endl;
}

const int MAXINT=2147483647,MAXSINT=32767,MAXLDOUBLE=1000*1000-1;
const ll N=5000+5,INF=1000ll*1000*1000*1000*1000*1000ll;
vector <piii> edl;
vector <pii> adj[N],path;
vector <ll> di[N];
bool f=0;
ll w[N],s[2],h[N],d[N],S,came[N];

void dfs(int v,int fa){
	d[v]=1;
	di[v].resize(path.size());
	FOR(i,0,Size(adj[v])){
		int u=adj[v][i].Y;
		int w=adj[v][i].X;
		if(u != fa){
			h[u]=h[v]+1;
			path.pb(mp(w,u));
			dfs(u,v);
			path.pop_back();
			S+=came[v]*d[u]+(came[u]+d[u]*w)*d[v];
			came[v]+=came[u]+d[u]*w;
			d[v]+=d[u];
		}
	}
	di[v].back()=came[v];
}

void dfsf(int v,int fa){
	FOR(i,0,Size(adj[v])){
		int u=adj[v][i].Y;
		int w=adj[v][i].X;
		if(u != fa){
			path.pb(mp(w,u));
			dfsf(u,v);
			path.pop_back();
		}
	}
	ll dis=0;
	MFOR(i,path.size()-2,-1){
		int u=path[i].Y,u2=path[i+1].Y;
		int w=path[i+1].X;
		dis+=w;
		ll tmp=came[u]-came[u2]-d[u2]*w;
		tmp+=(d[u]-d[u2])*dis;
		di[v][i]=di[v][i+1]+tmp;
	}
}

void bfs(int v,int fa,int cost,int base){
	queue <piii> q;
	q.push(mp(v,mp(fa,cost)));
	while(!q.empty()){
		v=q.front().X;
		fa=q.front().Y.X;
		cost=q.front().Y.Y;
		q.pop();
		FOR(i,0,Size(adj[v])){
			int u=adj[v][i].Y;
			if(u != fa){
				if(!f) q.push(mp(u,mp(v,cost+adj[v][i].X)));
				else q.push(mp(u,mp(v,cost+1)));
			}
		}
		if(!f){
			ll dis=di[v][0]-cost*d[base]-di[base].back();
			if(s[f]>dis) s[f]=dis;
		}
		else{
			cost=Size(di[v])-cost;
			if(s[f]>di[v][cost]) s[f]=di[v][cost];
		}
	}
}

int main(){
	ios::sync_with_stdio(false);
	int n,a,b,cost;
	ll ans=0;
	cin>>n;
	for(int i=0;i<n-1;++i){
		cin>>a>>b>>cost;
		adj[a].pb(mp(cost,b));
		adj[b].pb(mp(cost,a));
		edl.pb(mp(cost,mp(a,b)));
	}
	path.pb(mp(0,1));
	dfs(1,1);
	dfsf(1,1);
	FOR(i,0,n-1){
		int v=edl[i].Y.X,u=edl[i].Y.Y;
		if(h[u] < h[v]) swap(v,u);
		s[0]=s[1]=INF;
		f=0;
		bfs(v,u,edl[i].X,u);
		f=1;
		bfs(u,v,1,v);
		ll dv=di[v][0]-(d[u]*edl[i].X+di[u].back());
		ll du=di[u].back();
		w[i]+=dv*d[u]+du*(n-d[u])-(s[0]*d[u]+s[1]*(n-d[u]));
		cerr<<dv*d[u]+du*(n-d[u])<<endl;
	}
	for(int i=0;i<n-1;++i)	ans=max(ans,w[i]);
	cout<<S-ans<<endl;
	return 0;
}