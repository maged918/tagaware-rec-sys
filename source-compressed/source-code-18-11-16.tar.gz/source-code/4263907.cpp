//Language: GNU C++


#include <iostream>
#include <cmath>

using namespace std;

int main()
{
	int x, y;
	cin >> x >> y;
	int y1 = abs(x)+abs(y), x2 = abs(x)+abs(y);
	if (y < 0)
		y1 = -y1;
	if (x < 0)
		x2 = -x2;
	if (x2 < 0)
		cout << x2 << " " << 0 << " " << 0 << " " << y1 << endl;
	else
		cout << 0 << " " << y1 << " " << x2 << " " << 0 << endl;
}
