//Language: GNU C++


//In the Name of God !!
using namespace std;
#include<iostream>
#include<fstream>
#include<map>
#include<set>
#include<conio.h>
#include<vector>
#include<queue>
#include<algorithm>
#define PB push_back
#define MP make_pair
#define L first
#define R second
#define ll long long
//#define cin fin
//#define cout fout
typedef pair<long long,long long> pie;
int main()
{
    ios_base::sync_with_stdio(false);
    int n , m;
    cin>>n>>m;
    if(n<m)
    {
        cout<<n+1<<endl;
        for(int i=0;i<=n;i++)
            cout<<i<<" "<<i+1<<endl;
        return 0;
    }
    else if(m<n)
    {
        cout<<m+1<<endl;
        for(int i=0;i<=m;i++)
            cout<<i+1<<" "<<i<<endl;
    }
    else
    {
        cout<<n+1<<endl;
        for(int i=n;i>=0;i--)
            cout<<i<<" "<<n-i<<endl;
    }
}
