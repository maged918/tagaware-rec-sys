//Language: GNU C++


#include <iostream>
#include<math.h>
#include<stdio.h>
#include<string.h>
using namespace std;
int stuff[11][4];
int dp[11][1001][1001];
int n , m , c0 , d0;

int turkies(int index,int stu,int dou){
    if(index==m+1)
        return 0;
    if(dp[index][stu][dou]!=-1)
        return dp[index][stu][dou];
    int take , dont;
    take=dont=0;
    if(stu>=stuff[index][1] && dou>=stuff[index][2])
        take=stuff[index][3]+turkies(index,stu-stuff[index][1],dou-stuff[index][2]);
    dont=turkies(index+1,stuff[index+1][0],dou);

    return dp[index][stu][dou]=max(take,dont);
}

using namespace std;

int main()
{
    memset(dp,-1,sizeof(dp[0][0][0])*11*1001*1001);
    cin>>n>>m>>c0>>d0;
    stuff[0][0]=0,stuff[0][1]=0,stuff[0][2]=c0,stuff[0][3]=d0;
    for(int i=0;i<m;i++){
        scanf("%d %d %d %d",&stuff[i+1][0],&stuff[i+1][1],&stuff[i+1][2],&stuff[i+1][3]);
    }
    printf("%d\n",turkies(0,stuff[0][0],n));
    return 0;
}
