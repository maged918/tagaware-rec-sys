//Language: GNU C++


#include <cstring>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <iostream>
#include <cmath>
#include <utility>
using namespace std;

#define _inline(f...) f() __attribute__((always_inline)); f
#define all(v) (v).begin(), (v).end()
#define rall(v) (v).rbegin(), (v).rend()
const int INF = 10000000;
const double EPS = 1e-9;

_inline(int cmp)(double x, double y = 0, double tol = EPS) {
  return (x <= y + tol) ? (x + tol < y) ? -1 : 0 : 1;
}

struct point {
  double x, y;
  point(double x = 0, double y = 0): x(x), y(y) {}
  
  point operator +(point q) { return point(x + q.x, y + q.y); }
  point operator -(point q) { return point(x - q.x, y - q.y); }
  point operator *(double t) { return point(x * t, y * t); }
  point operator /(double t) { return point(x / t, y / t); }
  double operator *(point q) { return x * q.x + y * q.y; }
  double operator %(point q) { return x * q.y - y * q.x; }
  int cmp(point q) const {
    if (int t = ::cmp(x, q.x)) return t;
    return ::cmp(y, q.y);
  }
  bool operator ==(point q) const { return cmp(q) == 0; }
  bool operator !=(point q) const { return cmp(q) != 0; }
  bool operator < (point q) const { return cmp(q) < 0; }
  friend ostream& operator <<(ostream& o, point p) {
    return o << "(" << p.x << ", " << p.y << ")";
  }
  
  static point pivot;
};

point point::pivot;

double abs(point p) { return hypot(p.x, p.y); }
double arg(point p) { return atan2(p.y, p.x); }

typedef vector<point> polygon;
typedef pair<point, double> circle;


_inline(int ccw)(point p, point q, point r) {
  return cmp((p-r) % (q-r));
}

//Retorna o menor angulo entre qp e qr
//o angulo eh positivo se qp estiver no sentido
_inline(double angle)(point p, point q, point r) {
  point u = p - q, v = r - q;
  return atan2(u % v, u * v);
}

double dist2(point p, point q) { return ((p-q) *  (p-q)); }
// rotate a point CCW or CW around the origin
point rotateCCW90(point p) { return point(-p.y,p.x); }
point rotateCW90(point p) { return point(p.y,-p.x); }
point rotateCCW(point p, double t) { 
  return point(p.x*cos(t)-p.y*sin(t), p.x*sin(t)+p.y*cos(t)); 
}
// project point c onto line through a and b
// assuming a != b
point projectPointLine(point a, point b, point c) {
  return a + (b-a)*((c-a)* (b-a))/ ((b-a) * (b-a));
}
// project point c onto line segment through a and b
point projectPointSegment(point a, point b, point c) {
  double r = ((b-a) * (b-a));
  if (fabs(r) < EPS) return a;
  r = ((c-a) * (b-a))/r;
  if (r < 0) return a;
  if (r > 1) return b;
  return a + (b-a)*r;
}

////////////////////////////////////////////////////////////////////////////////
// Decide se q está sobre o segmento fechado pr.
bool between(point p, point q, point r) {
  return ccw(p, q, r) == 0 && cmp((p - q) * (r - q)) <= 0;
}

// compute distance from c to segment between a and b
double distancePointSegment(point a, point b, point c) {
  return dist2(c, projectPointSegment(a, b, c));
}
// compute distance between point (x,y,z) and plane ax+by+cz=d
double distancePointPlane(double x, double y, double z,
              double a, double b, double c, double d){
  return fabs(a*x+b*y+c*z-d)/sqrt(a*a+b*b+c*c);
}
// determine if lines from a to b and c to d are parallel or collinear
bool linesParallel(point a, point b, point c, point d) { 
  return fabs((b-a) % ( c-d)) < EPS; 
}
bool linesCollinear(point a, point b, point c, point d) { 
  return linesParallel(a, b, c, d)
    && fabs((a-b) % (a-c)) < EPS
    && fabs((c-d) % (c-a)) < EPS; 
}

//////////////////////////////////////////////////////////////////////////////
// Decide se os segmentos fechados pq e rs têm pontos em comum.
bool seg_intersect(point p, point q, point r, point s) {
  point A = q - p, B = s - r, C = r - p, D = s - q;
  int a = cmp(A % C) + 2 * cmp(A % D);
  int b = cmp(B % C) + 2 * cmp(B % D);
  if (a == 3 || a == -3 || b == 3 || b == -3) return false;
  if (a || b || p == r || p == s || q == r || q == s) return true;
  int t = (p < r) + (p < s) + (q < r) + (q < s);
  return t != 0 && t != 4;
}

//////////////////////////////////////////////////////////////////////////////
// Encontra o ponto de interseção das retas pq e rs.
point line_intersect(point p, point q, point r, point s) {
  point a = q - p, b = s - r, c = point(p % q, r % s);
  return point(point(a.x, b.x) % c, point(a.y, b.y) % c) / (a % b);
}

////////////////////////////////////////////////////////////////////////////////
// Classifica o ponto p em relação ao polígono T.
// Retorna 0, -1 ou 1 dependendo se p está no exterior, na fronteira
// ou no interior de T, respectivamente.
int in_poly(point p, polygon& T) {
  double a = 0; int N = T.size();
  for (int i = 0; i < N; i++) {
    if (between(T[i], p, T[(i+1) % N])) return -1;
    a += angle(T[i], p, T[(i+1) % N]);
  }
  return cmp(a) != 0;
}

////////////////////////////////////////////////////////////////////////////////
// Calcula a área orientada do polígono T. 
// Possivelmenente negativa << 
double poly_area(polygon& T) {
  double s = 0; int n = T.size();
  for (int i = 0; i < n; i++)
    s += T[i] % T[(i+1) % n];
  return s / 2;
}
//centroid is often known as 
// the "center of gravity" or "center of mass".
point computeCentroid(vector<point> &p) {
  point c(0,0);
  double scale = 6.0 * poly_area(p);
  for (int i = 0; i < p.size(); i++){
    int j = (i+1) % p.size();
    c = c + (p[i]+p[j])*(p[i].x*p[j].y - p[j].x*p[i].y);
  }
  return c / scale;
}

////////////////////////////////////////////////////////////////////////////////
// Comparação radial.
bool radial_lt(point p, point q) {
  point P = p - point::pivot, Q = q - point::pivot;
  double R = P % Q;
  if (cmp(R)) return R > 0;
  return cmp(P * P, Q * Q) < 0;
}
////////////////////////////////////////////////////////////////////////////////
// Determina o fecho convexo de um conjunto de pontos no plano.
// Destrói a lista de pontos T.
polygon convex_hull(vector<point>& T) {
  int j = 0, k, n = T.size(); polygon U(n);
  point::pivot = *min_element(all(T));
  sort(all(T), radial_lt);
  for (k = n-2; k >= 0 && ccw(T[0], T[n-1], T[k]) == 0; k--);
  reverse((k+1) + all(T));
  for (int i = 0; i < n; i++) {
    // troque o >= por > para manter pontos colineares
    while (j > 1 && ccw(U[j-1], U[j-2], T[i]) >= 0) j--;
    U[j++] = T[i];
  }
  U.erase(j + all(U));
  return U;
}


////////////////////////////////////////////////////////////////////////////////
// Determina o polígono interseção dos dois polígonos convexos P e Q.
// Tanto P quanto Q devem estar orientados positivamente.
polygon poly_intersect(polygon& P, polygon& Q) {
  int m = Q.size(), n = P.size();
  int a = 0, b = 0, aa = 0, ba = 0, inflag = 0;
  polygon R;
  while ((aa < n || ba < m) && aa < 2*n && ba < 2*m) {
    point p1 = P[a], p2 = P[(a+1) % n], q1 = Q[b], q2 = Q[(b+1) % m];
    point A = p2 - p1, B = q2 - q1;
    int cross = cmp(A % B), ha = ccw(p2, q2, p1), hb = ccw(q2, p2, q1);
    if (cross == 0 && ccw(p1, q1, p2) == 0 && cmp(A * B) < 0) {
      if (between(p1, q1, p2)) R.push_back(q1);
      if (between(p1, q2, p2)) R.push_back(q2);
      if (between(q1, p1, q2)) R.push_back(p1);
      if (between(q1, p2, q2)) R.push_back(p2);
      if (R.size() < 2) return polygon();
      inflag = 1; break;
    } else if (cross != 0 && seg_intersect(p1, p2, q1, q2)) {
      if (inflag == 0) aa = ba = 0;
      R.push_back(line_intersect(p1, p2, q1, q2));
      inflag = (hb > 0) ? 1 : -1;
    }
    if (cross == 0 && hb < 0 && ha < 0) return R;
    bool t = cross == 0 && hb == 0 && ha == 0;
    if (t ? (inflag == 1) : (cross >= 0) ? (ha <= 0) : (hb > 0)) {
      if (inflag == -1) R.push_back(q2);
      ba++; b++; b %= m;
    } else {
      if (inflag == 1) R.push_back(p2);
      aa++; a++; a %= n;
    }
  }
  if (inflag == 0) {
    if (in_poly(P[0], Q)) return P;
    if (in_poly(Q[0], P)) return Q;
  }
  R.erase(unique(all(R)), R.end());
  if (R.size() > 1 && R.front() == R.back()) R.pop_back();
  return R;
}

double seg_distance(point p, point q, point r) {
 point A = r - q, B = r - p, C = q - p;
 double a = A * A, b = B * B, c = C * C;
 if (cmp(b, a + c) >= 0) return (a);
 else if (cmp(a, b + c) >= 0) return (b);
 else return (fabs(A % B)*fabs(A % B)) / c;
}

int main(){
  int y1,y2,yw,xb,yb,r;
  cin >> y1 >> y2 >> yw >> xb >> yb >> r;
  point right = point(xb,yb);
  point left = point(0,y1+r); 
  
  int cont = 1000000;
  double top = xb;
  double bot = 0;
  while( cont -- ){
    double mid = (top+bot) / 2;
    point topMid = point(mid,yw-r);
    point botMid = point(mid,0);
    if(angle(left,topMid,botMid) < angle(botMid,topMid,right) ){
      bot = mid;
    } else {
      top = mid;
    } 
  }
  point other = point(0,y2);
  if( distancePointSegment(left,point(bot,yw-r),other) < ((double)r) * r + EPS){
    printf("-1\n");
  } else {
    printf("%.9f\n",bot);
  }
  return 0;
}