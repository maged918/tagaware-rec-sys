//Language: MS C++


#include <iostream>
#include <fstream>
#include <cstdio>
#include <iomanip>
#include <cassert>
#include <climits>
#include <cmath>
#include <ctime>
#include <vector>
#include <string>
#include <cstring>
#include <queue>
#include <deque>
#include <stack>
#include <map>
#include <set>
#include <functional>
#include <algorithm>
using namespace std;

typedef pair<int, int> pii;
#define mp make_pair
#define sqr(x) ((x)*(x))
const double PI = 3.14159265359;
#define y1 ololo123654
#define y0 alalal1231

const int ans = 0x8, mod = 1000000007;
int n, dp[10500][16];
char f[10500][5];

void count(int x, int y, int mask, int nmask)
{
    if (x == n)
        return;
    if (y >= 3)
        dp[x + 1][nmask] = (dp[x + 1][nmask] + dp[x][mask]) % mod;
    else
    {
        int tmask = 1 << y;
        if (f[x][y] == 'X' || f[x][y] == 'O' || mask & tmask)
            count(x, y + 1, mask, nmask);
        else
        {
            if (y < 2 && f[x][y + 1] != 'X' && f[x][y + 1] != 'O' && !(mask & (1 << (y + 1))))
            {
                if (f[x][y + 2] == 'O' || (y > 0 && f[x][y - 1] == 'O'))
                    count(x, y + 2, mask, nmask | ans);
                else
                    count(x, y + 2, mask, nmask);
            }
            if (x < n - 1 && f[x + 1][y] != 'X' && f[x + 1][y] != 'O')
            {
                if (f[x + 2][y] == 'O' || (x > 0 && f[x - 1][y] == 'O'))
                    count(x, y + 1, mask, nmask | tmask | ans);
                else
                    count(x, y + 1, mask, nmask | tmask);
            }
        }
    }
}

int main()
{
#ifdef MYLOCAL
    freopen("input.txt", "rt", stdin);
    freopen("output.txt", "wt", stdout);
#endif

    cin >> n;
    
    for (int i = 0; i < 3; ++i)
    {
        getchar();
        for (int j = 0; j < n; ++j)
            f[j][i] = getchar();
    }
    dp[0][0] = 1;
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < 16; ++j)
            count(i, 0, j, j & ans);
    cout << dp[n][ans];

    return 0;
}