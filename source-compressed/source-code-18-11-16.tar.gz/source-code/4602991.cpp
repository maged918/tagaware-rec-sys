//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cmath>

using namespace std;

typedef long long ll ;

ll res,a[100007],t[100007];
int n;

int main()
{
    //freopen("i.i","r",stdin);
    //freopen("o.o","w",stdout);
    scanf("%d",&n);
    for (int i=1;i<=n;i++) cin>>a[i];
    sort(a+1,a+n+1);
    ll l=a[n],r=0,m;
    r=2*a[n];
    while (l<=r)
    {
        m=(l+r)/2;
        for (int i=1;i<=n;i++) t[i]=0;
        int i=1;
        ll cur =m;
        while (1)
        {
            while ((i<n) && (a[i+1]==a[i]) ) i++;
            if ((i==n) || (cur<i))break;
            t[i]=min(cur / i,a[i+1]-a[i]);
            cur-=(i*t[i]);
            i++;
        }
        t[n]=cur/n;
        cur%=n;
        t[cur]++;
        for (int i=n-1;i>0;i--) t[i]+=t[i+1];
        bool ok=1;
        //cout<<m<<endl;
        //for (int i=1;i<=n;i++) cout<<t[i]<<" ";
        //cout<<endl;
        //for (int i=1;i<=n;i++) cout<<a[i]<<" ";
        //cout<<endl;
        for (int i=1;i<=n;i++)
            if (a[i]>m-t[i]) ok=0;
        if (ok) {res=m;r=m-1;}
        else l=m+1;
    }
    cout<<res<<endl;
}
