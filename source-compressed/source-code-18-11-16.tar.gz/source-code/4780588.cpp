//Language: MS C++


#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <bitset>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define snuke(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

#define M 1000000

int K;
int s[M+10];
int lb;
bool check(int p){
    for(int x=0;x<=M;x+=p){
        int ymax = min(x+p-1, M);
        int ymin = (x+K);
        //cout<<x<<' '<<ymax<<' '<<ymin<<endl;
        if(ymin < ymax && s[ymin] < s[ymax]) return false;
    }
    return true;
}

int main(void){
    int N,x,i;
    lb = 1e9;

    cin >> N >> K;
    REP(i,N){
        scanf("%d", &x);
        s[x] = 1;
        lb = min(lb,x);
    }

    REP(i,M+5) s[i+1] += s[i];

    for(i=lb;i>=K;i--) if(check(i)) break;
    cout << i << endl;

    return 0;
}
