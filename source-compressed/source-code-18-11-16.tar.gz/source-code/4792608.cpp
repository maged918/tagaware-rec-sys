//Language: MS C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
using namespace std;
#define SIZE(vn) vn.size()
const long long modulo = 1000000007;
#define SET0(zn) memset(zn,0,sizeof(zn))
#define SET(zn, k) memset(zn,k,sizeof(zn))
#define REP(i,n)  for (int i=0; i<(n); ++i)
typedef long long LL;
template <class T> void refreshMin(T & a, const T & b) {if (a>b) a = b;}
template <class T> void refreshMax(T & a, const T & b) {if (a<b) a = b;}


LL n,m;
string s1,s2;

long long getGCD(long long x, long long y){
    return ((x == 0) ? y : getGCD(y%x, x));
}

int main(int argc, char const *argv[]) {
	cin>>n>>m;
	cin>>s1>>s2;
	LL l1,l2;
	l1 = s1.size();
	l2 = s2.size();
	LL g = getGCD(l1,l2);
	LL re = 0;
	for (int i=0; i<g; i++) {
		int flag1[200];
		int flag2[200];
		SET0(flag1);
		SET0(flag2);
		LL t = i;
		while(t<l1) {
			flag1[s1[t]-'a']++;
			t+=g;
		}
		t = i;
		while(t<l2) {
			flag2[s2[t]-'a']++;
			t+=g;
		}
		REP(j,26) {
			LL t = flag2[j] ;
			t *= l1/g - flag1[j];
			re+=t;
		}
	}

	re *= n/ ( l2/g );
	cout<<re;
	return 0;
}