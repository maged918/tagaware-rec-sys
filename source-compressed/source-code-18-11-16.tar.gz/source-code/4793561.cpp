//Language: GNU C++


#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <algorithm>
#include <fstream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <ctime>
#include <queue>
#include <stack>
#include <vector>
#include <map>
#include <set>
#include <deque>
#define ll long long
#define pb push_back
#define f first
#define s second
#define mp make_pair
#define sz size()
#define INF 1000*1000*1000
#define _USE_MATH_DEFINES
#define fname ""
const int  MAXN=1000*1000;
const double eps=1e-6;

using namespace std;
int n,m,i,ans[MAXN];
bool used[MAXN];	
int main()
{
	#ifndef ONLINE_JUDGE
	freopen(fname".in","r",stdin);
	freopen(fname".out","w",stdout);
	#endif
	cin>>n>>m;
	for(i=0;i<m;i++)
	{
		int x,y,z;
		cin >> x >>y >>z;
		if(used[x]==1)
		{
			used[y]=1;
			used[z]=1;
			if(ans[x]==1)ans[y]=2,ans[z]=3;
			if(ans[x]==2)ans[y]=1,ans[z]=3;
			if(ans[x]==3)ans[y]=1,ans[z]=2;
		}
		else if(used[y]==1)
		{
			used[x]=1;
			used[z]=1;
			if(ans[y]==1)ans[x]=2,ans[z]=3;
			if(ans[y]==2)ans[x]=1,ans[z]=3;
			if(ans[y]==3)ans[x]=1,ans[z]=2;
		}
		else if(used[z]==1)
		{
			used[x]=1;
			used[y]=1;
			if(ans[z]==1)ans[x]=2,ans[y]=3;
			if(ans[z]==2)ans[x]=1,ans[y]=3;
			if(ans[z]==3)ans[x]=1,ans[y]=2;
		}		
		else 
		{
			used[x]=1;
			used[y]=1;
			used[z]=1;
			ans[x]=1;
			ans[y]=2;
			ans[z]=3;
		}
	}
	for(i=1;i<= n;i++)
	{
		cout<<ans[i]<<" ";
	}
	return 0;
}