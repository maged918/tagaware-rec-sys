//Language: GNU C++


#include<cstdio>

int a[11],b[11],c[11];
int n;

int main()
{
    scanf("%d",&n);
    for (int i=0;i<n;i++) scanf("%d%d%d",&a[i],&b[i],&c[i]);
    int res=-1;
    for (int i=0;i<10000;i++)
    {
        int x[10];
        bool ok=1;
        for (int j=0;j<10;j++) x[j]=0;
        for (int j=i,o=0;o<4;j/=10,o++) x[j%10]++;
        for (int j=0;j<10;j++) ok&=(x[j]<2);
        for (int j=0;j<n;j++)
        {
            int y[10];
            for (int k=0;k<10;k++) y[k]=0;
            for (int k=a[j],o=0;k,o<4;k/=10,o++) y[k%10]++;

            int u=0,v=0;
            for (int k=0;k<10;k++) v+=(x[k]>0 && x[k]==y[k]);
            u+=(i/1000==a[j]/1000)+(i%1000/100==a[j]%1000/100)+(i%100/10==a[j]%100/10)+(i%10==a[j]%10);
            v-=u;
            ok&=(u==b[j]&& v==c[j]);
        }
        if (ok)
        {
            if (res>=0) {printf("Need more data\n");return 0;}
            res=i;
        }
    }
    if (res==-1) printf("Incorrect data\n");
    else printf("%.4d\n",res);
}
