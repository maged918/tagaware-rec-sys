//Language: MS C++


#pragma comment(linker, "/STACK:102400000,102400000")
#include <functional>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <iomanip>
#include <bitset>
#include <string>
#include <vector>
#include <ctime>
#include <queue>
#include <cmath>
#include <set>
#define CLR(a,v)        memset(a,v,sizeof(a))
#define ReadFile(file)  freopen(file,"r",stdin)  
#define WriteFile(file) freopen(file,"w",stdout)
using namespace std;
typedef long long       ll;
typedef pair<int,int>   pii;
typedef unsigned int    uint;
typedef unsigned long long    ull;

const double eps = 1e-6;
const double PI  = acos(-1.0);
const double EPS = eps;
const double pi  = PI;
const int N = 1e2+10;

struct Point{
	double x,y;
	Point(){}
	Point(const Point& Val){x=Val.x;y=Val.y;}
	Point(double x,double y):x(x),y(y){}
	void set(double x,double y){
		this->x = x;this->y = y;
	}
	void read(){
		scanf("%lf%lf",&x,&y);
	}
	void print(char end[]){
		if(end==NULL) end[0]='\0';
		printf("%.6f %.6f%s",x,y,end);
	}
	Point rot90(){
		return Point(-y,x);
	}
	Point operator + (const Point& Val)const{
		return Point(x+Val.x, y+Val.y);
	}
	Point operator - (const Point& Val)const{
		return Point(x-Val.x, y-Val.y);
	}
	Point operator * (double Val)const{
		return Point(x*Val, y*Val);
	}
	Point operator / (double Val)const{
		return (*this) * (1.0/Val);
	}
};
typedef Point Vec;
istream& operator >> (istream &io, Point& p){
	io >> p.x >> p.y;
	return io;
}
ostream& operator << (ostream &io, Point& p){
	io << "(" << (fabs(p.x-0)<eps?0:p.x) << "," << (fabs(p.y-0)<eps?0:p.y) << ")" ;
	return io;
}

//--------向量运算---------
Vec PtoV(Point a,Point b){ 
	// 两点 所示 向量
	return Vec(b.x - a.x , b.y - a.y );
}
double dMult(Vec a,Vec b){
	// 点乘
	return (a.x*b.x) + (a.y*b.y) ;
}
double xMult(Vec a,Vec b){
	// 叉积，有向面积|a||b|形成的平行四边形
	return a.x*b.y-a.y*b.x;
}
double VecMod(Vec a){
	// 模
	return sqrt(dMult(a,a));
}
double VecMod2(Vec a){
	// 模平方
	return dMult(a,a);
}
double Corner2V(Vec a,Vec b){
	//两向量夹角 返回弧度 debuged
	return fabs( acos( dMult(a,b)/VecMod(a)/VecMod(b) ) );
}
Vec VecUnit(Vec a){
	// a的单位向量
	return a / VecMod(a);
}
Vec VRotate(Vec v,double alph){
	// 获得v向量的逆时针旋转alph角度的向量
	double sa = sin(alph),ca = cos(alph);
	return Vec(v.x*ca - v.y*sa , v.x*sa + v.y*ca);
}
   Point PRotate(Point p,Point o,double alph){
	// wait for debug...
	return Point(o+VRotate(PtoV(o,p),alph));
}
Vec GetVV(Vec v){
	// 获得v向量的垂直向量 wait for test ...
	return VRotate(v,pi/2);
}
Point ShadowPOnLine(Point p,Point a,Point b){
	// p在直线|ab|上的垂足
	Vec ab = PtoV(a,b) , ap = PtoV(a,p);
	Vec alph = VecUnit(ab) * dMult(ab,ap) / VecMod(ab);
	return a + alph;
}
vector<Point> LineCrossCircle(Point a,Point b,Point o,double r){
	// 直线与圆的交点
	vector<Point> ret;
	Point t = ShadowPOnLine(o,a,b); // o到直线|ab|的垂足
	Vec ot = PtoV(o,t);
	if(VecMod(ot)-r>eps)return ret; // 没有交点
	if(fabs(VecMod(ot)-r)<eps){ // 如果相切
		ret.push_back(t);
		return ret;
	}
	double lr = sqrt(r*r-VecMod2(ot));
	Vec ta = t + VecUnit(PtoV(t,a))*lr , tb = t + VecUnit(PtoV(t,b))*lr;
	ret.push_back(ta);
	ret.push_back(tb);
	return ret;	
}

vector<Point> PointTangentCircle(Point p,Point o,double r){
	// 圆外一点作两个切线 返回切点
	double x2 = VecMod2(p-o);
	double d2 = x2 - r*r;
	vector<Point> ret;
	if(d2 < -eps)return ret; // 点在圆内
	if(r <= eps){ // 圆退化为点
		ret.push_back(o);
		ret.push_back(o);
		return ret;
	}
	d2 = max(d2,0.);
	Point q1 = o + (p-o) * (r*r/x2);
	Point q2 = (p-o).rot90() * (-r*sqrt(d2) / x2);
	ret.push_back(q1 - q2);
	ret.push_back(q1 + q2);
	return ret;
	//double x2 = (p - c).abs2(); // x * x + y * y
	//double d2 = x2 - r * r;
	//vector<Point> ret;
	//if (d2 < -EPS)
	//	return ret;
	//if (r <= EPS) {
	//	ret.push_back(c);
	//	ret.push_back(c);
	//	return ret;
	//}
	//d2 = max(d2, 0.);
	//Point q1 = c + (p - c) * (r * r / x2);
	//Point q2 = (p - c).rot90() * (-r * sqrt(d2) / x2);
	//ret.push_back(q1 - q2);
	//ret.push_back(q1 + q2);
	//return ret;

	//vector<Point> ret;
	//Vec po = PtoV(p,o);
	//if(VecMod(po)-r < eps) return ret;
	//if(fabs(VecMod(po)-r) < eps){
	//	ret.push_back(p);
	//	return ret;
	//}
	//double alph = asin(r/VecMod(po));
	//cout << "alpha===>" << alph*180/pi << "  r=>" << r << "  |po|=>" << VecMod(po) << endl;
	//cout << "circle o==>" << o << " p===>" << p << endl;
	//cout << "|p,T2|==>" << VRotate(VecUnit(po),alph) * sqrt(VecMod2(po)+r*r) << endl;
	//cout << "单位向量|p.T2|" << VRotate(VecUnit(po),alph) << "  长度|pT2|" << sqrt(VecMod2(po)+r*r) << endl;
	//
	//ret.push_back(p + VRotate(VecUnit(po),alph) * sqrt(VecMod2(po)+r*r));
	//ret.push_back(p + VRotate(VecUnit(po),2*pi-alph) * sqrt(VecMod2(po)+r*r));
	//return ret;

	//Vec pt = VecUnit(VRotate(po,asin(r/VecMod(po))))*sqrt(VecMod2(po)+r*r);
	//ret.push_back(p+pt);
	//Point tot = ShadowPOnLine(p+pt,p,o);
	//ret.push_back(tot + PtoV(tot,o));
	//return ret;
}
bool POnSeg(Point p, Point a, Point b){
	// 点在线段上
	if(fabs(xMult(PtoV(a,b), PtoV(a,p))) > eps)return false;
	if(min(a.x,b.x) > p.x || p.x > max(a.x,b.x))return false;
	if(min(a.y,b.y) > p.y || p.y > max(a.y,b.y))return false;
	return true;
}


double PDisLine(Point p,Point a, Point b){
	// p点到直线|ab| 的距离
	return VecMod(ShadowPOnLine(p,a,b) - p);
}
//--------向量运算---------End


void debug_function(){
	Point h(25,45),j(30,30),i(15,35),k(5,45);
	//cout.setf(ios::fixed); cout.setf(ios::showpoint); cout.precision(9); 
	Point aaa(0,0), bbb(0,5), ppp(0,-1);
	cout << "p in |ab| ? => " << POnSeg(ppp,aaa,bbb) << endl;

	cout << "π:" << pi << "\t\tπ checked" << endl;
	cout << i << h << j << "\tio checked" << endl;
	cout << Corner2V(PtoV(i,h),PtoV(i,j))*(180/pi) << "\t\t\tCorner2V() checked" << endl;
	i.set(0,0);k.set(-10,4);
	cout << VRotate(PtoV(i,k),pi/2) << " " << PtoV(i,k) << PtoV(i,Point(-4,-10)) << "VRotate() checked" << endl;
	Point p(10,2) , a(-6,6) , b(10,-10);
	cout << ShadowPOnLine(p,a,b) << "\t\t\tShadowPOnLine() checked" << endl;
	
	double r = 6.64;
	vector<Point> CP = LineCrossCircle(a,b,Point(0,0),r);
	cout << "cross point:" << CP.size() << " ";
	for(int i = 0 ; i < CP.size() ; i++) cout << CP[i] << " " ;
	cout << "\tchecked" << endl;

	p.set(10,2); r = 6.64;
	vector<Point> CT = PointTangentCircle(p,Point(0,0),r);
	cout << "tangent point:" << CT.size() << " ";
	for(int i = 0 ; i < CT.size() ; i++) cout << CT[i] << " " ;
	cout << endl;


	exit(0);
}

Point p,s;
double vp,vs,r , sita;
bool check(double t){
	double len_or = VecMod(p);
	Point e(len_or * cos(sita+t*vp/len_or) , len_or * sin(sita+t*vp/len_or)); // 终点
	//printf("t:%lf (%lf,%lf) \t\t",t,e.x,e.y);
	vector<Point> ccp;
	ccp = LineCrossCircle(s,e, Point(0,0), r);
	if(ccp.size() != 2 || (!POnSeg(ccp[0], s, e) && !POnSeg(ccp[1], s, e)) ){
		//cout << "| |len = " << VecMod(e-s) << endl;
		return vs*t > VecMod(e-s); // 如果没有交点路径就是直线	
	}
	vector<Point> ttp1 = PointTangentCircle(s,Point(0,0),r);
	if( PDisLine(ttp1[0],s,e) > PDisLine(ttp1[1],s,e) ) 
		swap(ttp1[0],ttp1[1]);
	double l1 = VecMod(PtoV(s,ttp1[0]));
	
	vector<Point> ttp2 = PointTangentCircle(e,Point(0,0),r);
	if( PDisLine(ttp2[0],s,e) > PDisLine(ttp2[1],s,e) ) 
		swap(ttp2[0],ttp2[1]);
	double l2 = VecMod(PtoV(e,ttp2[0]));

	double alph = Corner2V(PtoV(Point(0,0),ttp1[0]) , PtoV(Point(0,0),ttp2[0]));
	//cout << "tangent:" <<  ttp1[0] << " " << ttp2[0] << endl;
	//cout << "|-|alph = " << alph << ", " << VecMod( PtoV(s,ttp1[0]) )   << "," << VecMod( PtoV(e,ttp2[0]) ) << endl;
	return VecMod( PtoV(s,ttp1[0]) )
		+  VecMod( PtoV(e,ttp2[0]) )
		+ alph * r < vs*t;
}
int main(){
	ios::sync_with_stdio(false);
	//debug_function();
	//freopen("d:\\Program Files (x86)\\Microsoft Visual Studio 9.0\\por\\20130820\\20130820\\in.txt","r",stdin);
//	freopen("out.txt","w",stdout);
	//cout.setf(ios::fixed); cout.setf(ios::showpoint); cout.precision(2); 
	//cout << fixed << setprecision(2) << (*it).first << endl;
	while(cin >> p >> vp >> s >> vs >> r){
		//cout << p << vp << s << vs << " " << r << endl;
		//check(9.584544103);exit(0);
		sita = acos(p.x/VecMod(p));
		if(p.y<0)sita = -sita; // 跨过了180度
		
		double  left = 0, right = 1e+10;
		while( fabs(left-right) > 1e-12 ){
			double mid = (left+right)*0.5;
 			if(check(mid))
				right = mid;
			else 
				left = mid;
		}
		cout << fixed << setprecision(9) << left << endl;
	}
	return 0;
}
