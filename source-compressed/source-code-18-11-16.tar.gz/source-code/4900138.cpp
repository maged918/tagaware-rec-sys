//Language: MS C++


#include <cstdio>
#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

const int inf = 1 << 30;
int n, x[305], y[305];

int main( )
{
    scanf("%d", &n);
    for( int i=0; i<n; ++i ){
        scanf("%d%d", &x[i], &y[i]);
    }
    int Max=0, m1, m2, n1, n2,t;
    for( int i=0; i<n; ++ i ){
        for( int j=i+1; j<n; ++ j ){
                m1=-inf, m2=-inf, n1=inf, n2=inf;
            for( int k=0; k<n; ++ k ){
                if(k==i || k==j) continue;
                t=(x[j]-x[i])*(y[k]-y[i]) - (x[k]-x[i])*(y[j]-y[i]);
                if(t<0){
                    m1=max(m1, -t );
                    n1=min(n1, -t);
                }
                else{
                    m2=max(m2, t);
                    n2=min(m2, t);
                }
            }
            Max=max(Max, m1+m2);
        }
    }
    printf("%.6lf", 1.0*Max/2);
    return 0;
}