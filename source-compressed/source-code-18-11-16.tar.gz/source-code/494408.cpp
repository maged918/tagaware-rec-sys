//Language: GNU C++


#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
using namespace std;

typedef long long ll;
typedef long double ld;
typedef pair<int,int> ii;
typedef vector<int> vi;

#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define sz(x) ((int)(x).size())
#define all(x) (x).begin(),(x).end()
#define clr(t,v) memset((t),(v),sizeof(t))

const int inf=1999999999;
const double pi=acos(-1.0);
const double eps=1e-10;
char gc(){char c;while(isspace(c=getchar()));return c;}

int a[10000];
int main()
{
    //  freopen("test.in","r",stdin); freopen("test.out","w",stdout);
    int n,m,k;
    scanf("%d%d%d",&n,&m,&k);
    if((n%2)==0)
    {
        printf("0\n");
        return 0;
    }
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    int op=(n+1)/2;
    int t=0;
    int mx=999999;
    for(int i=0;i<n;i+=2)
        mx=min(mx,a[i]);
    for(int i=0;i<n;i+=2)
        a[i]-=mx;
    t+=mx;
    printf("%d\n",min((long long)t,(long long)k*(m/op)));
}
