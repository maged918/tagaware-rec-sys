//Language: GNU C++


//De hieu ro cac chu thich, nen ve hinh minh hoa ra giay

#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <deque>

using namespace std;

#define MAX_N 10000

int n,m,k;
long long a[MAX_N+1];

long long res;

int main()
{
    cin >> n >> m >> k;
    for (int i=1; i<=n; ++i) cin >> a[i];    

    //time: So vien kim cuong co the lay ra trong 1 phut
    //Moi lan lay 1 vien kim cuong ra khoi ket, can [n/2]+1 thao tac (tinh ca thao tac lay ra khoi ket) de co the danh lua he thong
    //1 phut duoc thuc hien khong qua m thao tac, nen so kim cuong toi da lay ra = m/(n/2+1)
    long long time=m/(n/2+1); 
    
    if ( n%2==0 || time==0 ) //Neu so o la chan; hoac so o le nhung So thao tac can de danh lua he thong > So thao tac cho phep
        res=0; //Khong the lay duoc vien nao
    else //Neu so o la le, moi co the lay kim cuong ra duoc
    {
        res=time*k; //Vi 1 phut co the lay toi da time vien kim cuong, nen k phut co the lay toi da time*k vien kim cuong
        //Chi co the lay kim cuong tu trong cac o le
        //Vi so kim cuong trong cac o le co the khong nhieu den time*k, nen can lay min cua cac gia tri
        for (int i=1; i<=n; i+=2) res=min(res,a[i]); 
    }            
    
    cout << res << endl;

    return 0;
}