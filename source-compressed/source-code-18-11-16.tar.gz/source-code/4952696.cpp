//Language: MS C++


#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <string>

using namespace std;

#define Debug(a) cerr << #a << " = " << a << endl;

int main()
{
    int n, k, l, c, d, p, nl, np;
    cin >> n >> k >> l >> c >> d >> p >> nl >> np;
    int toasts = k * l / nl;
    toasts = min(toasts, c * d);
    toasts = min(toasts, p / np);
    toasts /= n;
    cout << toasts << endl;
    return 0;
}