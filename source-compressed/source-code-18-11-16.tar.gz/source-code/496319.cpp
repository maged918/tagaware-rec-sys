//Language: MS C++


#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <sstream>

using namespace std;

struct widget
{
	string type;
	__int64 height, width;
	int border, spacing;
	vector<string> packs;

	widget() {}
	widget(string t, __int64 h = -1, __int64 w = -1): type(t), height(h), width(w), border(0), spacing(0) {}
};

map<string, widget> widgets;

void calc(string name)
{
	map<string, widget>::iterator current = widgets.find(name);
	if (current->second.height != -1 && current->second.width != -1)
		return;
	if (current->second.packs.empty())
	{
		current->second.height = 0;
		current->second.width = 0;
		return;
	}
	for(vector<string>::const_iterator it = current->second.packs.begin(); it != current->second.packs.end(); it++)
		calc(*it);
	if (current->second.type == "HBox")
	{
		current->second.height = 2 * current->second.border;
		current->second.width = 2 * current->second.border + (current->second.packs.size() - 1) * current->second.spacing;
		__int64 maximum_height = 0;
		for(vector<string>::const_iterator it = current->second.packs.begin(); it != current->second.packs.end(); it++)
		{
			current->second.width += widgets[*it].width;
			maximum_height = max(maximum_height, widgets[*it].height);
		}
		current->second.height += maximum_height;
	}
	if (current->second.type == "VBox")
	{
		current->second.height = 2 * current->second.border + (current->second.packs.size() - 1) * current->second.spacing;
		current->second.width = 2 * current->second.border;
		__int64 maximum_width = 0;
		for(vector<string>::const_iterator it = current->second.packs.begin(); it != current->second.packs.end(); it++)
		{
			current->second.height += widgets[*it].height;
			maximum_width = max(maximum_width, widgets[*it].width);
		}
		current->second.width += maximum_width;
	}
}

void parse(string s)
{
	if (s.substr(0, 6) == "Widget")
	{
		int pos = s.find("(");
		s.replace(pos, 1, " ");
		pos = s.find(")");
		s.replace(pos, 1, " ");
		pos = s.find(",");
		s.replace(pos, 1, " ");

		stringstream str(s);
		string type, name;
		__int64 height, width;
		str >> type >> name >> width >> height;
		widget tmp(type, height, width);

		widgets.insert(make_pair(name, tmp));
	} else
	if (s.substr(0, 4) == "HBox" || s.substr(0, 4) == "VBox")
	{
		stringstream str(s);
		string type, name;
		str >> type >> name;
		widget tmp(type);

		widgets.insert(make_pair(name, tmp));
	} else
	{
		int pos1 = s.find("."),
			pos2 = s.find("(");
		string type = s.substr(pos1, pos2 - pos1);
		s.replace(pos1, pos2 - pos1 + 1, " ");
		s.erase(s.length() - 1, 1);
		stringstream str(s);
		string name;
		str >> name;
		if (type == ".pack")
		{
			string name2;
			str >> name2;
			widgets[name].packs.push_back(name2);
		}
		if (type == ".set_border")
		{
			__int64 x;
			str >> x;
			widgets[name].border = x;
		}
		if (type == ".set_spacing")
		{
			__int64 x;
			str >> x;
			widgets[name].spacing = x;
		}
	}
}

int main(){
	int n;
	cin >> n;
	string s;
	getline(cin, s);
	for(int i = 0; i < n; i++)
	{
		getline(cin, s);
		parse(s);
	}
	for(map<string, widget>::const_iterator it = widgets.begin(); it != widgets.end(); it++)
	{
		calc(it->first);
		cout << it->first << " " << it->second.width << " " << it->second.height << endl;
	}
	return 0;
}
