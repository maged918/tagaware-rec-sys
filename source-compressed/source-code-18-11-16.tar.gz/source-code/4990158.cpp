//Language: GNU C++


#include<cstdio>
#include<algorithm>
#include<map>
using namespace std;
#define MOD 1000000007
#define LL __int64
int n, i;
LL a[100000], x, s, cnt, t, r;
map<LL,LL> MP;
map<LL,LL>::iterator it;
void solve(){
	LL ans=1;
	while(s>0){
		if(s%2==1)	ans = (ans*x)%MOD;
		x = (x*x)%MOD;
		s/=2;
	}
	printf("%I64d\n", ans);
}
int main(){
	while(~scanf("%d %I64d", &n, &x)){
		MP.clear();
		s=0;
		for(i=0; i<n; i++){
			scanf("%I64d", &a[i]);
			s+=a[i];
		}
		for(i=0; i<n; i++){
			a[i]=s-a[i];
			MP[a[i]]++;
		}
		while(1){
			it = MP.begin();
			t = it->first;
			r = it->second;
			MP.erase(t);
			if(r%x>0){
				if(t<s)	s=t;
				solve();
				break;
			}
			r/=x;
			t++;
			MP[t]+=r;
		}
	}
	return 0;
}