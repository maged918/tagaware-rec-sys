//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
        int n; cin>>n;
        int ans=0;
        for (int i=0; i<n; i++) {
                int cur; cin>>cur;
                ans=(ans+cur)%n;
        }
        if(!ans) cout << n << endl;
        else cout << n-1 << endl;
        return 0;
}