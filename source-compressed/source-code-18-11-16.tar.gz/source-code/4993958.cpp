//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <vector>
#include <algorithm>
#include <queue>
#include <set>
#include <map>
using namespace std;
typedef long long LL;
const int N = 100005;
const int M = 300;
struct Query {
    int l , r , id;
    inline void input (int i) {
        id = i;
        scanf ("%d %d" , &l , &r);
    }
    bool operator < (const Query &q) const {
        return l / M == q.l / M ? r < q.r : l / M < q.l / M;
    }
}query[N];
int n , b[N] , q , ret[N] , ans , tot;
int l = 1 , r = 0 , cnt[N] , gao[N];
deque <int> deq[N];
void add (int x) {
    if (++ cnt[x] == 1) {
        ans ++;
        if (++ tot == 1)
            ans --;
    }
}
void _add (int x) {
    if (++ gao[x] == 1) {
        if (-- tot == 0) {
            ans ++;
        }
    }
}
void del (int x) {
    if (-- cnt[x] == 0) {
        ans --;
        if (-- tot == 0)
            ans ++;
    }
}
void _del (int x) {
    if (-- gao[x] == 0) {
        if (++ tot == 1)
            ans --;
    }
}
void addLeft () {
    int val = b[-- l];
    deque <int> &v = deq[val];
    v.push_front (l);
    add (val);
    if ((int)v.size() >= 3 && v[1] - v[0] != v[2] - v[1])
        _add (val);
}
void addRight () {
    int val = b[++ r];
    deque <int> &v = deq[val];
    v.push_back (r);
    add (val);
    int m = (int)v.size() - 1;
    if ((int)v.size() >= 3 && v[m] - v[m - 1] != v[m - 1] - v[m - 2])
        _add (val);
}
void delLeft () {
    int val = b[l ++];
    deque <int> &v = deq[val];
    del (val);
    if ((int)v.size() >= 3 && v[1] - v[0] != v[2] - v[1])
        _del (val);
    v.pop_front ();
}
void delRight () {
    int val = b[r --];
    deque <int> &v = deq[val];
    del (val);
    int m = (int)v.size() - 1;
    if ((int)v.size() >= 3 && v[m] - v[m - 1] != v[m - 1] - v[m - 2])
        _del (val);
    v.pop_back ();
}
int main () {
    #ifndef ONLINE_JUDGE
        freopen ("input.txt" , "r" , stdin);
        // freopen ("output.txt" , "w" , stdout);
    #endif
    scanf ("%d" , &n);
    for (int i = 1 ; i <= n ; i ++)
        scanf ("%d" , &b[i]);
    scanf ("%d" , &q);
    for (int i = 0 ; i < q ; i ++)
        query[i].input (i);
    sort (query , query + q);
    for (int i = 0 ; i < q ; i ++) {
        while (r < query[i].r) addRight ();
        while (l > query[i].l) addLeft ();
        while (r > query[i].r) delRight ();
        while (l < query[i].l) delLeft ();
        ret[query[i].id] = ans + 1;
    }
    for (int i = 0 ; i < q ; i ++)
        printf ("%d\n" , ret[i]);
    return 0;
}