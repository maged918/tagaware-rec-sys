//Language: GNU C++


#include <iomanip>
#include <algorithm>
#include <map>
#include <fstream>
#include <stack>
#include <queue>
#include <vector>
#include <cmath>
#include <iostream>
#include <string>
#include <set>

#include <time.h>
#include <sys/time.h>

using namespace std;

int x[120][120];
int a[120][30];
int b[120][30];

int main()
{
//	freopen("anarc05b.in","r",stdin);
//	freopen("anarc05b.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);

	for (int i = 0; i < max(n,m); i++)
	for (int j = 0; j < 28; j++)
	{
		a[i][j] = 0;
		b[i][j] = 0;
	}
	for (int i = 0; i < n; i++)
	{
		string s;
		cin >> s;
		for (int j = 0; j < m; j++)
		{
			x[i][j] = s[j] - 'a';
			a[i][x[i][j]]++;
			b[j][x[i][j]]++;
		}
	}

	for (int i = 0; i < n; i++)
	for (int j = 0; j < m; j++)
	{
		char c = x[i][j] + 'a';
		if (a[i][x[i][j]] < 2 && b[j][x[i][j]] < 2) cout << c;
	}
	cout << endl;
//	in.getline(s);

	return 0;	
}
