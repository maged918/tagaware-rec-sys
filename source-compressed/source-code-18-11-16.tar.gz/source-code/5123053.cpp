//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;
const int nmax = 200;
int n;
int a[nmax];
int res;

int gcd(int a, int b){
	if ( a%b == 0) return b;
	
	return gcd(b, a%b);
}

int main(){
	cin >> n;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
	}
	
	sort(a+1, a+n+1);	
	int d = gcd(a[1], a[2]);
	
	for (int i = 3; i <= n; i++){
		d = gcd(d,a[i]);
	}
	int res = a[n]/d - n;
	if (res%2 == 1) cout << "Alice" << endl;
	else
		cout << "Bob";
}
