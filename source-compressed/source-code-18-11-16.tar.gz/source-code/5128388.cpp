//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <vector>
#include <map>
#include <cmath>
#include <string.h>
#define pb push_back
#define mp make_pair
#define x first
#define y second
#define ABS(a) ((a)>0?(a):(-(a)))
#define lowbit(a) (a&(a^(a-1)))
using namespace std;
typedef long long LL;
typedef double ld;
const int NMax=101000;
struct node {
	vector<int>s;
}T[NMax*8];
int N,nn,L;
pair<int,int>B[NMax];
vector<LL>LSH;
map<LL,int>ID;
vector<pair<int,pair<LL,LL> > >Q;
void insert(int a,int b,int c,int x,int y,int p){
	if(a>b) return ;
	if(a==x&&b==y) {
		T[p].s.pb(c);	
		return ;
	}
	int mid=(x+y)>>1;
	if(mid>=b)insert(a,b,c,x,mid,p*2);
	else if(mid<a)insert(a,b,c,mid+1,y,p*2+1);
	else {
		insert(a,mid,c,x,mid,p*2);
		insert(mid+1,b,c,mid+1,y,p*2+1);
	}
}
vector<int> calc(int a,int x,int y,int p) {
	if(x==y){
		vector<int>ret=T[p].s;
		while(!T[p].s.empty())T[p].s.pop_back();
		return ret;
	}
	int mid=(x+y)>>1;
	if(a<=mid) {
		vector<int> ret=calc(a,x,mid,p*2);
		for(int i=0;i<(int)T[p].s.size();i++)
			ret.pb(T[p].s[i]);
		while(!T[p].s.empty())T[p].s.pop_back();
		return ret;
	}else{
		vector<int> ret=calc(a,mid+1,y,p*2+1);
		for(int i=0;i<(int)T[p].s.size();i++)
			ret.pb(T[p].s[i]);
		while(!T[p].s.empty())T[p].s.pop_back();
		return ret;
	}
}
int father[NMax*4];
int Find(int a) {
	int R;
	for(R=a;father[R]!=-1;R=father[R]);
	int tmp;
	while(father[a]!=-1) {
		tmp=father[a];
		father[a]=R;
		a=tmp;	
	}
	return R;
}
void Union(int a,int b) {
	int x=Find(a),y=Find(b);
	if(x==y) return ;
	father[x]=y;
}
pair<LL,LL>A[NMax*4];
int main()
{
	memset(father,-1,sizeof(father));
	scanf("%d",&N);
	for(int i=1;i<=N;i++) {
		int t;
		LL x,y;
		scanf("%d%lld%lld",&t,&x,&y);
		if(t==1){
			Q.pb(mp(t,mp(x,y)));
			LSH.pb(x);LSH.pb(y);
		}else Q.pb(mp(t,mp(x,y)));
	}
	sort(LSH.begin(),LSH.end());
	for(int i=0;i<LSH.size();i++)
		if(i==0||LSH[i]!=LSH[i-1])
			ID[LSH[i]]=++L;
	nn=0;
	for(int i=0;i<N;i++) {
		if(Q[i].x==1) {
			Q[i].y.x=(LL)ID[Q[i].y.x];
			Q[i].y.y=(LL)ID[Q[i].y.y];
			nn++;
			A[nn]=mp(Q[i].y.x,Q[i].y.y);
		}
	}
	nn=0;
	int j1=0;
	for(int i=0;i<N;i++) {
		int x=(int)Q[i].y.x,y=(int)Q[i].y.y;
		int t=Q[i].x;
		if(t==1) {
			nn++;
			vector<int> t1=calc(x,1,L,1),t2=calc(y,1,L,1);
			int leftmost=x,rightmost=y;
			for(int j=0;j<(int)t1.size();j++) {
				int x1=t1[j],r1=Find(x1);
				leftmost=min(leftmost,B[r1].x);
				rightmost=max(rightmost,B[r1].y);
				Union(nn,x1);
			}	
			for(int j=0;j<(int)t2.size();j++) {
				int x1=t2[j],r1=Find(x1);
				leftmost=min(leftmost,B[r1].x);
				rightmost=max(rightmost,B[r1].y);
				Union(nn,x1);
			}
			int R=Find(nn);	
			B[R]=mp(leftmost,rightmost);
			insert(leftmost+1,rightmost-1,R,1,L,1);
		}else {
			j1++;
			if(Find(x)==Find(y)) puts("YES");
			else {
				int a=A[x].x,b=A[x].y,R=Find(y);
				if(B[R].x<a&&B[R].y>a||B[R].x<b&&B[R].y>b) puts("YES");
				else puts("NO");
			}
		}
	}
	getchar();getchar();
	return 0;
}
