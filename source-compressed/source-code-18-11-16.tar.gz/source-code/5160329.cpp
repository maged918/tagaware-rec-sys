//Language: MS C++


#define _USE_MATH_DEFINES
#define _CRT_SECURE_NO_DEPRECATE
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <sstream>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <iomanip>
#include <functional>
#include <bitset>
#include <cassert>
#include <cmath>
#include <ctime>
#include <queue>
#include <list>
#include <memory.h>
#include <complex>
#include <numeric>
using namespace std;
#pragma comment(linker, "/STACK:256000000")
#define mp make_pair
#define pb push_back
#define all(C) (C).begin(), (C).end()
#define sz(C) (int)(C).size()
#define PRIME 1103
#define PRIME1 31415
#define INF ((1ll << 61) - 1)
#define MOD 99990001
#define FAIL ++*(int*)0
#define EPS 1e-4
template<class T> T sqr(T a) {return a * a;}
typedef long long int64;
typedef unsigned long long uint64;
typedef pair<int, int> pii;
typedef pair<int64, int64> pi64;
typedef pair<int, pii> piii;
typedef vector<int> vi;
typedef vector<int64> vi64;
typedef vector<vi64> vvi64;
typedef vector<pi64> vpi64;
typedef vector<vpi64 > vvpi64;
typedef vector<pii> vpii;
typedef vector<vector<int> > vvi;
typedef vector<vvi> vvvi;
typedef vector<vector<pair<int, int > > > vvpii;
typedef vector<vector<vector<pair<int, int > > > > vvvpii;
typedef complex<long double> cd;
#define TASK "smith"
//----------------------------------------------------------
int m[4010];
int p[4010];
int sums[37000];
inline int get_sum (int l, int r)
{
    return (p[r] - p[l] + m[l]);
}
int main()
{
    //freopen ("test.in", "r", stdin); freopen ("test.out", "w", stdout);
    int a;
    cin >> a;
    char c;
    int i = 0;
    while (cin >> c)
    {
        m[i] = c - '0';
        if (i == 0)
            p[i] = m[i];
        else
            p[i] = m[i] + p[i - 1];
        ++i;
    }

    int n = i;
    for (int i = 0; i < n; ++i)
    {
        for (int j = i; j < n; ++j)
        {
            //cerr << get_sum (i, j) << endl;
            ++sums[ get_sum (i, j) ];
        }
    }

    /*for (int i = 0; i < 37000; ++i)
    {
        if (sums[i])
            cerr << i << ' ' << sums[i] << endl;
    }*/
    int64 ans = 0;

    if (a != 0)
    {
        for (int i = 1; i * 1ll * i <= a; ++i)
        {
            if (a % i)
                continue;
            //cerr << i << ' ' << a/i << endl;
        
            int q = i, r = a/i;
            if (q > 36000 || r > 36000)
                continue;

            ans += sums[q] * 1ll * sums[ r ];
            if (q != r)
                ans += sums[q] * 1ll * sums[ r ];
        }
    }
    else
    {
        for (int i = 1; i < 37000; ++i)
        {
            if (sums[i])
                ans += sums[i] * 1ll * sums[0];
        }
        ans *= 2;
        ans += sums[0] * 1ll * sums[0];
    }

    cout << ans;
    return 0;
}