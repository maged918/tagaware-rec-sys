//Language: GNU C++


#include<iostream>
#include<sstream>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<climits>
#include<iomanip>
#include<cstdlib>
#include<ctype.h>
#include<algorithm>
#include<numeric>
#include<vector>
#include<list>
#include<set>
#include<bitset>
#include<map>
#include<queue>
#include<deque>
#include<stack>
#define N 1000000009
#define PI acos(-1)
#define EPS 1e-8
#define INF 2147483647
#define INIT(x,y) memset(x,y,sizeof(x))
#define INITip(x,y,n) memset(x,y,n*sizeof(int))
#define INITbp(x,y,n) memset(x,y,n*sizeof(bool))
#define Readfile(x) freopen(x,"r",stdin)
#define Writefile(x) freopen(x,"w",stdout)
typedef long long LL;
typedef long double LD;
using namespace std;

int main() {
    //Readfile("in.txt");
    int n,d;
    cin>>n>>d;
    int x[n];
    for(int i=0;i<n;++i)
        cin>>x[i];
    LL ans=0;
    for(int i=0;i<n-2;++i) {
        int j=upper_bound(x+i,x+n,x[i]+d)-x;
        j--;
        ans+=(j-i)*1ll*(j-i-1)/2;
    }
    cout<<ans<<endl;
    return 0;
}
