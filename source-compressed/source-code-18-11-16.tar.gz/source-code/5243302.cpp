//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

const int N = 2009;

#define LL long long
LL a[N];
LL dp[N];
LL n, k;
LL LLabs(LL x)
{
    return x > 0LL ? x : -x;
}
bool check(LL mid)
{
    dp[1] = 0;

    for(int i = 2; i <= n; ++ i)
    {
        dp[i] = i - 1;
        for(int j = 1; j < i; ++ j)
        {
            if(LLabs(a[i] - a[j]) <= mid * (i - j))
            dp[i] = min(dp[i], dp[j] + (i - j - 1));
        }
    }
    for(int i = 1; i <= n; ++ i)
    {
        if(dp[i] + (n - i) <= k) return 1;
    }
    return 0;
}
int main()
{
//    freopen("in.txt", "r", stdin);
    cin >> n >> k;
    for(int i = 1; i <= n; ++ i) cin >> a[i];
    LL L = 0, R = 2e9;
    LL ans = 0;
    while(L <= R)
    {
        LL mid = (L + R) >> 1;
        if(check(mid)) R = mid - 1, ans = mid;
        else L = mid + 1;
    }
    cout << ans << endl;

    return 0;
}
