//Language: GNU C++


#pragma comment (linker, "/STACK:1073741824")
#define _USE_MATH_DEFINES
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <deque>
#include <vector>
#include <string>
#include <bitset>
#include <complex>

using namespace std;

#define SZ(x) (int((x).size()))
#define FOR(i, a, b) for(int (i) = (a); (i) <= (b); ++(i))
#define ROF(i, a, b) for(int (i) = (a); (i) >= (b); --(i))
#define REP(i, n) for (int (i) = 0; (i) < (n); ++(i))
#define REPD(i, n) for (int (i) = (n); (i)--; )
#define FE(i, a) for (int (i) = 0; (i) < (int((a).size())); ++(i))
#define MEM(a, val) memset((a), val, sizeof(a))
#define INF 1000000000
#define LLINF 1000000000000000000LL
#define PB push_back
#define PPB pop_back
#define ALL(c) (c).begin(), (c).end()
#define SQR(a) ((a)*(a))
#define MP(a,b) make_pair((a), (b))
#define XX first
#define YY second
#define GET_RUNTIME_ERROR *(int*)(NULL) = 1

typedef vector<int> vint;
typedef vector<long long> vLL;
typedef double dbl;
typedef long double ldbl;
typedef vector<pair<int, int> > vpii;
typedef long long LL;
typedef pair<int, int> pii;

const int nmax = 210;

int c[nmax][nmax];
int f[nmax][nmax];
vector<int> g[nmax];
int G[nmax][nmax];
vector<int> Gv[nmax];

bool used[nmax];

int T;

int d[nmax];
int q[nmax];
queue<int> gv[nmax];

bool bfs(int s, int t) {
  MEM(d, -1);
  d[s] = 0;
  int ql = 0;
  int qr = 0;
  q[qr++] = s;
  while(ql < qr) {
    int v = q[ql++];
    FE(i, g[v]) {
      int to = g[v][i];
      if (d[to] == -1 && f[v][to] < c[v][to]) {
        d[to] = d[v] + 1;
        q[qr++] = to;
      }
    }
  }

  return d[t] != -1;
}

int idx[nmax];

bool dfs(int v, int mn) {
  if (v == T) return mn;
  used[v] = true;
  for(; idx[v] < g[v].size(); ++idx[v]) {
    int to = g[v][idx[v]];
    if (!used[to] && d[to] == d[v] + 1 && f[v][to] < c[v][to]) {
      int val = dfs(to, min(mn, c[v][to] - f[v][to]));
      if (val) {
        f[v][to] += val;
        f[to][v] -= val;
        return val;
      }
    }
  }
  return 0;
}

int flow(int s, int t) {
  MEM(f, 0);
  T = t;
  int res = 0;

  while(bfs(s, t)) {
    MEM(idx, 0);
    MEM(used, 0);
    int val;
    while (val = dfs(s, INF)) {
      res += val;
    }
  }
  return res;
}

void dfsReachable(int v) {
  used[v] = true;
  FE(i, g[v]) {
    int to = g[v][i];
    if (!used[to] && f[v][to] < c[v][to])
      dfsReachable(to);
  }
}

int comp[nmax];

void dfsFindBest(int v) {
  used[v] = true;
  FE(i, Gv[v]) {
    int to = Gv[v][i];
    if (!used[to] && G[v][to])
      dfsFindBest(to);
  }
}

vector<int> findBest(vector<int> a) {
  if (a.size() == 1) return a;

  int curMin = INF;
  int v = -1, u = -1;
  FE(i, a)
    FE(j, a)
      if (G[a[i]][a[j]] && curMin > G[a[i]][a[j]]) {
        curMin = G[a[i]][a[j]];
        v = a[i];
        u = a[j];
      }

  G[v][u] = G[u][v] = 0;

  MEM(used, 0);
  dfsFindBest(v);
  vector<int> b;
  vector<int> c;
  FE(i, a) {
    if (used[a[i]]) {
      b.PB(a[i]);
    } else {
      c.PB(a[i]);
    }
  }

  vector<int> B = findBest(b);
  vector<int> C = findBest(c);
  FE(i, C) B.PB(C[i]);
  return B;
}

int main() {
#ifdef    CENADAR_DEBUG
  freopen("input.txt", "r", stdin);
//  freopen("output.txt", "w", stdout);
//  freopen("errput.txt", "w", stderr);
#else  // CENADAR_DEBUG
//  freopen("input.txt", "r", stdin);
//  freopen("output.txt", "w", stdout);
#endif // CENADAR_DEBUG

  int n, m;
  scanf("%d%d", &n, &m);
  REP(i, m) {
    int x, y, z;
    scanf("%d%d%d", &x, &y, &z);
    --x;
    --y;
    c[x][y] = c[y][x] = z;
    g[x].PB(y);
    g[y].PB(x);
  }

  int ans = 0;
  REP(k, n - 1) {
    int s = -1, t = -1;
    REP(i, n) {
      REP(j, n) {
        if (i != j && comp[i] == comp[j]) {
          s = i;
          t = j;
        }
      }
    }
    assert(s != -1 && t != -1 && s != t);
    int flowFound = flow(s, t);
    ans += flowFound;
    G[s][t] = G[t][s] = flowFound;
    Gv[s].PB(t);
    Gv[t].PB(s);

    MEM(used, 0);
    dfsReachable(s);
    REP(i, n)
      if (comp[i] == comp[s] && !used[i])
        comp[i] = k + 1;
  }
  cout << ans << endl;

  vector<int> a(n);
  REP(i, n) a[i] = i;
  a = findBest(a);
  REP(i, n)
    cout << a[i] + 1 << (i + 1 == n ? "\n" : " ");

  return 0;
}
