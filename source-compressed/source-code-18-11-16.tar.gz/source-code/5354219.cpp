//Language: MS C++


#include <cstdio>
int n;
int a[100000];
int min=2000000000,ind;

void init(){
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
        if(a[i]<min){
            min=a[i];
            ind=i;
        }
    }
}

void solve(){
    if(n<=2){
        printf("-1\n");
        return;
    }
    if(ind==0){
        for(int i=ind+1;i<n;i++){
            if(a[i]>min){
                if(i==1){
                    for(int j=i+1;j<n;j++){
                        if(a[j]>min){
                            printf("1 2\n");
                            return;
                        }
                    }
                    if(n==3){
                        printf("-1\n");
                    }else{
                        printf("2 3\n");
                    }
                    return;
                }else{
                    printf("%d %d\n",i,i+1);
                    return;
                }
            }
        }
        printf("-1\n");
    }else if(ind==n-1){
        for(int i=ind-1;i>=0;i--){
            if(a[i]>min){
                printf("%d %d\n",i+1,i+2);
                return;
            }
        }
        printf("-1\n");
    }else{
        if(a[ind-1]<a[ind+1]){
            printf("%d %d\n",ind+1,ind+2);
        }else if(a[ind-1]>a[ind+1]){
            printf("%d %d\n",ind,ind+1);
        }else{
            if(ind>1){
                printf("%d %d\n",ind,ind+1);
                return;
            }
            if(n==3){
                printf("-1\n");
                return;
            }
            for(int i=3;i<n;i++){
                if(a[i]>min){
                    printf("2 3\n");
                    return;
                }
            }
            printf("1 2\n");
            return;
        }
    }
}

int main(){
    init();
    solve();
    return 0;
}