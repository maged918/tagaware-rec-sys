//Language: GNU C++


#include <cstdio>
#include <cstring>

using namespace std;
bool f[51][51][26];
int F[51][51],n,m,i,j,k,ll,l,lll,S[2],node[2][1000000],next[2][1000000],a[2][51][51];
int C[26][26][26],s[26][26];
char c1[51],c2[51],ch1,ch2,ch3;

void work(int n){
  for (int len=2;len<=n;len++)
    for (i=1;i<=n-len+1;i++)
      for (j=i+len-1,l=0;l<26;l++){
        for (k=i;k<j;k++)
        if (!f[i][j][l]){
          for (ll=0;ll<26;ll++)
          if (!f[i][j][l]){
            for (lll=0;lll<s[l][ll];lll++)
            if (f[i][k][ll] && f[k+1][j][C[l][ll][lll]])
              {f[i][j][l]=1;break;}
          } else break;
        } else break;
      }
}

void add(int x,int y,int z,int typ){
  node[typ][++S[typ]]=z;
  next[typ][S[typ]]=a[typ][x][y];
  a[typ][x][y]=S[typ];
}

void dp1(){
  n=strlen(c1);
  m=strlen(c2);
  
  memset(f,0,sizeof(f));
  for (i=1;i<=n;i++) f[i][i][c1[i-1]-'a']=1;
  work(n);
  for (i=1;i<=n;i++)
    for (j=i;j<=n;j++)
      for (l=0;l<26;l++)
        if (f[i][j][l]) add(i,l,j,0);
  
  memset(f,0,sizeof(f));
  for (i=1;i<=m;i++) f[i][i][c2[i-1]-'a']=1;
  work(m);
  for (i=1;i<=m;i++)
    for (j=i;j<=m;j++)
      for (l=0;l<26;l++)
        if (f[i][j][l]) add(i,l,j,1);

}

void dp2(){
  memset(F,10,sizeof(F));
  F[0][0]=0;
  for (i=0;i<n;i++)
    for (j=0;j<m;j++)
    if (F[i][j]<100){
      for (k=0;k<26;k++)
        for (l=a[0][i+1][k];l;l=next[0][l])
          for (ll=a[1][j+1][k];ll;ll=next[1][ll])
          if (F[node[0][l]][node[1][ll]]>F[i][j]+1)
            F[node[0][l]][node[1][ll]]=F[i][j]+1;
    }
  if (F[n][m]>100) printf("-1\n");
    else printf("%d\n",F[n][m]);
}

int main(){
  //freopen("49E.in","r",stdin);
  //freopen("49E.out","w",stdout);
  scanf("%s",c1);
  scanf("%s",c2);
  scanf("%d\n",&n);
  for (i=1;i<=n;i++){
    scanf("%c->%c%c\n",&ch1,&ch2,&ch3);
    C[ch1-'a'][ch2-'a'][s[ch1-'a'][ch2-'a']++]=ch3-'a';
  }
  dp1();
  dp2();
  return 0;
}
