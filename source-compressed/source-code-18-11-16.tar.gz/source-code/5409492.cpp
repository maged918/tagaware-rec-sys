//Language: GNU C++


#include<bits/stdc++.h>
#define ALL(X) X.begin(),X.end()
#define SIZE(X) ((int)X.size())
#define FOR(I,A,B) for(int (I) = (A); (I) <= (B); (I)++)
#define FORW(I,A,B) for(int (I) = (A); (I) < (B); (I)++)
#define FORD(I,A,B) for(int (I) = (A); (I) >= (B); (I)--)
#define FOREACH(a,b) for(__typeof(b.begin()) a = b.begin(); a != b.end(); ++a)
#define LBOUND(P,R,PRED) ({__typeof(P) X=P,RRR=(R), PPP = P; while(PPP<RRR) {X = (PPP+(RRR-PPP)/2); if(PRED) RRR = X; else PPP = X+1;} PPP;})
#define CONTAIN(C,X) (C.find(X) != C.end())
#define CLEAR(X) memset(X, 0, sizeof(X))
#define PB push_back
#define MP make_pair

using namespace std;
typedef signed long long slong;
const slong Infinity = 1000000001;

typedef long double ldouble;
const ldouble Epsilon = 1e-9;
template<typename T, typename U> ostream& operator << (ostream& os, const pair<T,U>&p) {return os << "(" << p.first << "," << p.second << ")"; }
template<typename T> ostream& operator << (ostream &os, const vector<T>& V) {os << "["; FOREACH(i, V) os << *i << (i-V.begin()+1==SIZE(V)?"":","); os << "]\n"; return os; }
template<typename T> ostream& operator << (ostream &os, const set<T>& S) {os << "("; FOREACH(i, S) os << *i << (*i==*S.rbegin()?"":","); os << ")\n"; return os; }
template<typename T, typename U> ostream& operator << (ostream &os, const map<T, U>& M){os << "{"; FOREACH(i, M) os << *i << (i->first==M.rbegin()->first?"":","); os << "}\n"; return os; }

#define x1 _x1_
#define x2 _x2_
#define y1 _y1_
#define y2 _y2_
#define int slong
const int MAXN = 3005;
char A[MAXN][MAXN];
int N, M;

void read_data()
{
	cin >> M >> N;
	FOR(i,1,M) scanf("%s", A[i]+1);
//	FOR(i,1,M) {FOR(j,1,N) cout << A[i][j]; cout << endl; }
}

int DP[MAXN][MAXN];
const int MOD = 1000000007;

int x1, x2, y1, y2;
bool in_limit(int x, int y)
{
	return x1 <= x and x <= x2 and y1 <= y and y <= y2;
}

int f(int _x1, int _y1, int _x2, int _y2)
{
	x1 = _x1;
	x2 = _x2;
	y1 = _y1;
	y2 = _y2;
	if(x1 > x2 or y1 > y2) return 0;
	DP[x1][y1] = (A[x1][y1] == '.');
	FOR(i,x1,x2) FOR(j,y1,y2) if(!(i == x1 and j == y1))
	{
		DP[i][j] = 0;
		if(A[i][j] == '.')
		{
			if(in_limit(i-1,j)) DP[i][j] += DP[i-1][j];
			if(in_limit(i,j-1)) DP[i][j] += DP[i][j-1];
			DP[i][j] %= MOD;
		}
	}
	return DP[x2][y2];
}

void solve()
{
	int result = 0;
	int a = f(1,2,M-1,N);
   	int b = f(2,1,M,N-1);
	int c = f(1,2,M,N-1);
	int d = f(2,1,M-1,N);
	/*
	cout << "A: " << a << endl;
	cout << "B: " << b << endl;
	cout << "C: " << c << endl;
	cout << "D: " << d << endl;
	*/
	result = a*b-c*d;
	result %= MOD;
	result += MOD;
	result %= MOD;
	cout << result << endl;
}

#undef int
int main()
{
	read_data();
	solve();
    return 0;
}
