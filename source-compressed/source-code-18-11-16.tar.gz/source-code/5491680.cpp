//Language: GNU C++


#include <cmath>
#include <iostream>
#include <map>
#include <vector>
#include <set>
#include <string>
#include <algorithm>
#include <stack>
#include <queue>
#include <cstring>
#include <cstdio>
#include <string>
#include <functional>

#define all(cont) cont.begin(), cont.end()
#define rall(cont) cont.end(), cont.begin()
#define tr(cont, it) for (typeof(cont.begin()) it = cont.begin() ; it != cont.end() ; it++)
#define FOR(i, j, k, l) for(int i=(j) ; i<(k) ; i+=(l))
#define rep(i, j) FOR(i, 0, j, 1)
#define rrep(i, j) FOR(i, j, -1, -1)

#define INF 1000000000

using namespace std;

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef long long ll;

int n, m, k;
vi a;
int dp[55][55];

int min(int a, int b) {
    return a < b ? a : b;
}

int solve(int left, int sockets) {
    if (left == 0 && sockets >= 0) return 0;
    if (sockets < 0) return 1e9;
    if (dp[left][sockets] != -1) return dp[left][sockets];
    int ans = solve(left-1, sockets-1);
    if (!a.empty() && sockets > 0) {
        int added = a.back();
        // printf("%d\n", added);
        a.pop_back();
        ans = min(ans, 1 + solve(left, sockets-1+added));
    }
    return dp[left][sockets] = ans;
}

int main() {
    scanf("%d %d %d", &n, &m, &k);
    rep(i, n) {
        int temp;
        scanf("%d", &temp);
        a.push_back(temp);
    }
    sort(all(a));
    memset(dp, -1, sizeof dp);
    int ans = solve(m, k);
    if (ans == 1e9) printf("-1\n");
    else printf("%d\n", ans);
}