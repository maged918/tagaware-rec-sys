//Language: GNU C++


//Solution by Daniyar Maminov                                                                                                                                                                     
#include<iostream>
#include<fstream>
#include<string>
#include<algorithm>
#include<math.h>
#include<vector>
#include<cstring>
#include<queue>
#include<map>
#include<set>
#define mp make_pair
#define f first
#define pb push_back
#define s second
#define ub upper_bound
#define lb lower_bound
#define inf 1000*1000*1000
using namespace std;

string s[111111];

int n, m, i, j, k, l, t, u, v, x, gd;


struct po
{
    int tp, gd;
}a[111111];

void detect(int i)
{
    int ln=(int)s[i].length();
    if (s[i].length()<3)
    {
        cout<<"NO";
        exit(0);
    }
    if (s[i][ln-3]=='e' && s[i][ln-2]=='t' && s[i][ln-1]=='r')
    {
        a[i].tp=1;
        a[i].gd=1;
        return ;
    }
    if (s[i].length()<4)
    {
        cout<<"NO";
        exit(0);
    }
    if (s[i][ln-4]=='e' && s[i][ln-3]=='t' && s[i][ln-2]=='r' && s[i][ln-1]=='a')
    {
        a[i].tp=1;
        a[i].gd=0;
        return ;
    }
    if (s[i][ln-4]=='l' && s[i][ln-3]=='i' && s[i][ln-2]=='o' && s[i][ln-1]=='s')
    {
        a[i].tp=0;
        a[i].gd=1;
        return ;
    }
    if (s[i].length()<5)
    {
        cout<<"NO";
        exit(0);
    }
    if (s[i][ln-5]=='l' && s[i][ln-4]=='i' && s[i][ln-3]=='a' && s[i][ln-2]=='l' && s[i][ln-1]=='a')
    {
        a[i].tp=0;
        a[i].gd=0;
        return ;
    }
    if (s[i].length()<6)
    {
        cout<<"NO";
        exit(0);
    }
    if (s[i][ln-6]=='i' && s[i][ln-5]=='n' && s[i][ln-4]=='i' && s[i][ln-3]=='t' && s[i][ln-2]=='i' && s[i][ln-1]=='s')
    {
        a[i].tp=2;
        a[i].gd=1;
        return ;
    }
    if (s[i][ln-6]=='i' && s[i][ln-5]=='n' && s[i][ln-4]=='i' && s[i][ln-3]=='t' && s[i][ln-2]=='e' && s[i][ln-1]=='s')
    {
        a[i].tp=2;
        a[i].gd=0;
        return ;
    }
    cout<<"NO";
    exit(0);
}



    
    
            

int main()
{
    #ifndef ONLINE_JUDGE
    freopen (".in","r",stdin);
    freopen (".out","w",stdout);
    #endif
    while (cin>>s[n]) n++;
    for (i=0; i<n; i++)
    {
        detect(i);
    }
    if (n==1)
    {
        cout<<"YES";
        return 0;
    }
    gd=a[0].gd;
    l=0;
    while (l<n && a[l].tp==0) 
    {
        if (a[l].gd!=gd)
        {
            cout<<"NO";
            return 0;
        }
        l++;
    }
    while (l<n && a[l].tp==1)
    {
        if (a[l].gd!=gd)
        {
            cout<<"NO";
            return 0;
        }
        l++;
        k++;
    }
    if (k!=1)
    {
        cout<<"NO";
        return 0;
    }
    while (l<n && a[l].tp==2) 
    {
        if (a[l].gd!=gd)
        {
            cout<<"NO";
            return 0;
        }
        l++;
    }
    if (l!=n)
    {
        cout<<"NO";
        return 0;
    }
    cout<<"YES";



            

    return 0;
}