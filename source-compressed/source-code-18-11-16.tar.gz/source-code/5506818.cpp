//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cstdlib>
#include<cctype>
#include<algorithm>

using namespace std;

int main()

{
    string lever;
    long long int left=0,right=0,counter=0,pcounter=0,i,j,length,l,a;
  cin>>lever;
  l=lever.size();

    for(i=0;i<l;i++)
    {


        if(lever[i]=='^')
        {

            i++;
            while(i<l)
            {
                pcounter++;
                if(isdigit(lever[i]))
                {
                    a=(long long int)(lever[i]-48);
                    right=right+(a*pcounter);

                }
                i++;
            }
        }
    }

   for(i=l-1;i>-1;i--)
    {
       // cout<<lever[i]<<endl;
      if(lever[i]==94)
        {
            i--;
            while(i>-1)
            {
                counter++;
                if(isdigit(lever[i]))
                {
                    a=(long long int)(lever[i]-48);
                    left=left+(a*counter);


                }
                i--;
            }
        }
    }
   // cout<<left<<"\t\t"<<right<<endl;



    if(right==left)
        cout<<"balance";
    else if(right>left)
        cout<<"right";
    else
        cout<<"left";
    return 0;
}
