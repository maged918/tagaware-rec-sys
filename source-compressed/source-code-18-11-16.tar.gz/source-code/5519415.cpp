//Language: GNU C++


#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <set>
#include <vector>
#include <numeric> 
#include <map>
#include <cmath>
#include <algorithm>
#include <memory.h>
#include <string>
#include <sstream>
 
using namespace std;
int main(){
    long long i,j,k,t,num;
    long long sum=0; 
    string s;
    cin>>s;
    k=s.length();
    //cout<<k;
    i=s.find('^');
    //cout<<i;
    for(t=0;t<k;t++)
    {
        if(s[t]!='=' && s[t]!='^')
        {
            if(t>i)
            sum=sum+(((t+1)-(i+1))*(s[t]-48));
            else if(t<i)
            sum=sum-(((i+1)-(t+1))*(s[t]-48));
        }
    }
    if(sum==0)
    cout<<"balance";
    if(sum>0)
    cout<<"right";
    if(sum<0)
    cout<<"left";
}
    
