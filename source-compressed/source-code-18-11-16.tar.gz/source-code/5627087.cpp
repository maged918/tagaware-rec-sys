//Language: GNU C++


#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <string>
#include <cstring>
using namespace std;
typedef pair<long long,long long> pie;
const long long mode = 1000000000 + 7;
#define L first
#define R second
#define MP make_pair
#define PB push_back
long long next[10];
long long k;
bool can(long long x,long long step){
    if(step == 9)
        return false;
    if(next[x] == 1)
        return true;
    else
        return can(next[x],step+1);
}
bool chk(long long x){
    long long tmp = x;
    for(long long i=2;i<=k;i++){
        next[i] = (tmp%k)+1;
        tmp/=k;
    }
    for(long long i=2;i<=k;i++){
        if(!can(i,0))
            return false;
    }
    return true;
}
long long pow(long long a,long long b){
    long long ans = 1;
    for(long long i=1;i<=b;i++)
        ans*=a;
    return ans;
}
long long Pow(long long a,long long b){
    if(b == 0)
        return 1;
    if(b == 1)
        return a;
    if(b%2==0){
        long long now = Pow(a,b/2);
        return (now*now)%mode;
    }
    else{
        long long now = Pow(a,b/2);
        now*=now;
        if(now > mode)
            now%=mode;
        return (now*a)%mode;
    }
}
main()
{
    ios_base::sync_with_stdio(false);
    long long n , ans = 0;
    cin>>n>>k;
    for(long long i=0;i<pow(k,k-1);i++){
        //cout<<i<<" "<<chk(i)<<endl;
        ans+=chk(i);
    }
    ans*=k;
    cout<<(ans*Pow(n-k,n-k))%mode;
}
