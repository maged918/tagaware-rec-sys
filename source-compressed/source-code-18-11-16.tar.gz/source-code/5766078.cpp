//Language: GNU C++0x


#include <iostream>
using namespace std;
typedef long long ll;

const int N = 1000 + 5, M = 20000 + 5, T = 1000 * 1000 * 1000 + 7, X = 10000 + 1;
int dp[N][M], a[N];

int main() {
	ios::sync_with_stdio(false);
	ll ans = 0;
	int n;
	cin >> n;
	for(int i = 1;i <= n;++i)
		cin >> a[i];
	for(int i = 1;i <= n;++i) {
		++dp[i][X + a[i]];
		++dp[i][X - a[i]];
		for(int j = 0;j <= M;++j) {
			if(j - a[i] >= 0)
				dp[i][j] += dp[i - 1][j - a[i]];
			if(j + a[i] < M)
				dp[i][j] += dp[i - 1][j + a[i]];
			dp[i][j] %= T;
		}
		ans += dp[i][X];
	}
	cout << ans % T << endl;
	return 0;
}