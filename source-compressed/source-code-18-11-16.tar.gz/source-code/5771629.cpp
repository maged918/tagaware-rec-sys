//Language: GNU C++


#define _USE_MATH_DEFINES
#include <iostream>
#include <vector>
#include <cstdio>
#include <stack>
#include <queue>
#include <algorithm>
#include <cmath>

using namespace std;

typedef unsigned int ui;
typedef long long ll;
typedef unsigned long long ull;



//#define FILE_STREAM
#ifdef FILE_STREAM
{
    ifstream input("input.in");
    ofstream output("output.out");
#define cin input
#define cout output
}
#endif

using namespace std;



ull a, b, w, x, c;



void solve()
{
    while( cin >> a >> b >> w >> x >> c )
    {
        if(c - a <= 0)
        {
            cout<< 0 << '\n';
            continue;
        }
        ull res = ( (c-a) * x-b + w-x-1) / (w - x) + (c - a) * x / x;
        cout << res << '\n';
    }
}



int main()
{
    ios :: sync_with_stdio(false);
    solve();
    return 0;
}
