//Language: GNU C++


// In the name of Allah

#include <algorithm>
#include <iostream>
#include <sstream>
#include <cstring>
#include <vector>
#include <queue>
#include <cmath>
#include <set>
#include <map>

using namespace std;

#define FOR(i,a,b) for ( int i = a; i < b; i ++ )
#define ll long long
#define ld long double
#define PI 3.14159265

bool cmp ( string a, string b )
{
	if ( a.size() == b.size() )
		return a <= b;
	return a.size() < b.size() ;
}

int main()
{
	string p;
	cin >> p;
	p += '!';
	string temp = "", substr = "";
	int ans = 0;
	
	FOR ( i, 0, p.size() )
	{
		if ( p[i] != '0' )
		{
			ans = 1 + ans * ( cmp ( temp, substr ) );
			substr += temp;
			temp = "";
		}
		temp += p[i];
	}
	cout << ans << endl;

	return 0;
}
