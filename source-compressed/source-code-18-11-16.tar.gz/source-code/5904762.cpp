//Language: MS C++


#include <iostream>
using namespace std;
long long a[262144];
void l(int q,long long w){
  int e=1,r=65536,t=0;
  for(;r;r/=2){
   e*=2;
   if(t+r<=q){
    t+=r;
    a[e]+=w;
    e++;}}
}
int main(){
  int q,w,e,r,t,s[100000],d[100000];
  long long y,f[100000],g[100000];
  cin>>q>>w>>e;
  for(r=0;r<q;r++)
   cin>>g[r];
  for(r=0;r<w;r++)
   cin>>s[r]>>d[r]>>f[r];
  for(r=0;r<262144;r++)
   a[r]=0;
  for(r=0;r<e;r++){
   cin>>t>>y;
   l(y,1);
   l(t-1,-1);}
  for(r=0;r<w;r++){
   t=131072+r;
   y=0;
   while(t){
    y+=a[t];
    t/=2;}
   f[r]*=y;}
  for(r=0;r<262144;r++)
   a[r]=0;
  for(r=0;r<w;r++){
   l(d[r],f[r]);
   l(s[r]-1,-f[r]);}
  for(r=0;r<q;r++){
   t=131072+r;
   y=0;
   while(t){
    y+=a[t];
    t/=2;}
   cout<<g[r]+y<<" ";}
//  system("PAUSE");
  return 0;}
