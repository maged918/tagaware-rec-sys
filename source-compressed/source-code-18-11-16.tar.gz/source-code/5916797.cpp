//Language: MS C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <cstring>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#include <list>
#include <map>
#include <bitset>
#include <ctime>
#include <cmath>
#include <cassert>
#include <algorithm>
using namespace std;


#define pb(p) push_back(p)
#define fr(i,a,b) for(int i=a;i<b;i++)
#define PI 2*acos(0.0)

int MIN (int a, int b) {
  int x= (b>a)?a:b;
  return x;
}

int MAX(int a, int b) {
  int x= (b<a)?a:b;
  return x;
}

typedef long long ll;
const int size = 1000007;
const ll modulo = 1000000007;
const ll inf = 1e18;
const double eps = 1e-6;
ll n,m,a[4000],b[4000],k,n25,n50,n100;


int main()
{
	while(cin>>n)
	{
		fr(i,0,n)
			cin>>a[i];

		ll tmp[10001];

		ll max=0;

		fr(i,0,n)
		{
			fr(j,0,i+1)
			{
				ll val=0;
				/*for(int ind=0;ind<n;ind++)
				{
					if(tmp[ind]==1)
						b[i]++;
					tmp[ind]=a[ind];
				}*/

				//if(i==4 && j==1)
				//{
				//	//do nt

				//	cout<<" \n";
				//}

				fr(k,0,n)
				{
					if(k>=j && k<=i)
					{
						if(a[k]==0)
							val++;
						//val+= !a[k]; //flipp
					}
					else val+=a[k];
				}

				//cout<<"Value : "<<val<<" j: "<<j<<" i: "<<i<<endl;

				if(val>max) max=val;
			}
		}

		cout<<max<<endl;
	}
	return 0;
}