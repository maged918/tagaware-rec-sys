//Language: GNU C++


/*
  ------------------------- Hachiikung ---------------------------------
  ---------------------- Worrachate Bosri ------------------------------
  ------ Faculty of Computer Engineering Chulalongkorn University ------
*/
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<list>
#include<set>
#include<map>
#include<string>
#include<utility>
using namespace std;
#define REP(i,FN) for(int i=0;i<FN;i++)
#define FOR(i,ST,FN) for(int i=ST;i<=FN;i++)
#define FORD(i,FN,ST) for(int i=FN;i>=ST;i--)
#define FORX(i,c) for(typeof(c.begin())i=c.begin();i!=c.end();i++)
#define pause system("pause")
#define S scanf
#define P printf
#define X first
#define Y second
#define pb push_back
#define PII pair<int,int>
#define mp make_pair
#define sz size()
#define eps 1e-8

const int MOD(1000000007);
const int INF((1<<30)-1);
const int MAXN();

int main(){

    long long a,b;
    cin >> a >> b;

    if(b == 0)
    {
        cout << a*a << endl;
        REP(i,a)
            P("o");
    }

    else if(a == 0)
    {
        cout << -b*b << endl;
        REP(i,b)
            P("x");
    }

    else
    {
        int x,y;
        long long best;

        FOR(i,1,a)
        {
            if(b < i-1) continue;

            int t = min(b, (long long)i+1);

            long long A = a - (i-1);
            long long B = b / t;

            long long ans = A*A + (i-1);

            ans -= (B+1)*(B+1) * (b%t);
            ans -= (B*B) * (t-b%t);

            if(i == 1)
            {
                best = ans;
                x = i;
                y = t;
            }

            else if(ans > best)
            {
                best = ans;
                x = i;
                y = t;
            }
        }

        cout << best << endl;

        REP(i,x+y)
        {
            if(i%2 == x<y)
            {
                if(i == x<y)
                {
                    REP(j,a-(x-1))
                        P("o");
                }
                else
                {
                    P("o");
                }
            }

            else
            {
                REP(j,b/y)
                    P("x");

                if(i/2 < b%y) P("x");
            }
        }
    }


}
