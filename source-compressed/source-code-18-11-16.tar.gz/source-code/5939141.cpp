//Language: GNU C++


#include <iostream>
#include <cstring>
using namespace std;
char arr[13];
int main()
{
    int t;
    cin>>t;
    while(t--)
    {
        cin>>arr;
        int res = 0;
        int ans[6];
        memset(ans, 0, sizeof(ans));
        int i;
        for (i = 0; i < 12; ++i)
        {
            if (arr[i] == 'X')
                break;
        }
        if (i != 12)
        {
            res++;
            ans[0] = 1;
        }
        for (i = 0; i < 6; ++i)
        {
            if (arr[i] == 'X' && arr[i+6] == 'X')
                break;
        }
        if (i != 6)
        {
            res++;
            ans[1] = 1;
        }
        for (i = 0; i < 4; ++i)
        {
            if (arr[i] == 'X' && arr[i+4] == 'X' && arr[i+8] == 'X')
                break;
        }
        if (i != 4)
        {
            res++;
            ans[2] = 1;
        }
        for (i = 0; i < 3; ++i)
        {
            if (arr[i] == 'X' && arr[i+3] == 'X' && arr[i+6] == 'X' && arr[i+9] == 'X')
                break;
        }
        if (i != 3)
        {
            res++;
            ans[3] = 1;
        }
        for (i = 0; i < 2; ++i)
        {
            if (arr[i] == 'X' && arr[i+2] == 'X' && arr[i+4] == 'X' && arr[i+6] == 'X' && arr[i+8] == 'X' && arr[i+10] == 'X')
                break;
        }
        if (i != 2)
        {
            res++;
            ans[4] = 1;
        }
        for (i = 0; i < 12; ++i)
        {
            if (arr[i] != 'X')
                break;
        }
        if (i == 12)
        {
            res++;
            ans[5] = 1;
        }
        cout<<res;
        if (ans[0] == 1)
        {
            cout<<" 1x12";
        }
        if (ans[1] == 1)
        {
            cout<<" 2x6";
        }
        if (ans[2] == 1)
        {
            cout<<" 3x4";
        }
        if (ans[3] == 1)
        {
            cout<<" 4x3";
        }
        if (ans[4] == 1)
        {
            cout<<" 6x2";
        }
        if (ans[5] == 1)
        {
            cout<<" 12x1";
        }
        cout<<endl;
    }
    return 0;
}
