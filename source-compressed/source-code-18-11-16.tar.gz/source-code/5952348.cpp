//Language: GNU C++


#include<bits/stdc++.h>

using namespace std;

int main () {
    string s;
    cin>>s;
    if(s.size()>=19) {
        if(s.size()==19 && s>"9223372036854775807") {
        cout<<"BigInteger";
        return 0;
    }
    }
    stringstream ss;
    ss<<s;
    int long long i;
    ss>>i;
    if(s.size()>=1 && s.size()<=3 && i<=127 /*&& s<="127"*/) {
        cout<<"byte";

    }
    else if(s.size()>=1 && s.size()<=5 && i<=32767 /*&& s<="32767"*/)
        cout<<"short";
    else if (s.size()>=1 && s.size()<=10 && i<=2147483647 /*s<="2147483647"*/)
        cout<<"int";
    else if(s.size()>=1 && s.size()<=19 && i<=9223372036854775807 /*s<="9223372036854775807"*/)
        cout<<"long";
    else
        cout<<"BigInteger";
    return 0;
}
