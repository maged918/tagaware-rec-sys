//Language: GNU C++


#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
#define maxn 10010
struct Edge{
	int v,next;
}edge[2*maxn];
int head[maxn],cnt,vis[maxn],add,tot[maxn];
void adj(int u,int v)
{
	edge[add].v=v; edge[add].next=head[u]; head[u]=add++;
	edge[add].v=u; edge[add].next=head[v]; head[v]=add++;
}
bool f;
void dfs(int fa,int u)
{
	int i,v;
	vis[u]=1;
	for(i=head[u];i!=-1&&f;i=edge[i].next){
		v=edge[i].v;
		if(v==fa) continue;
		if(vis[v]){
			cnt++;
			if(cnt>2)
				f=false;
			continue;
		}
		dfs(u,v);
	}
}
int main()
{
	int n,m,u,v,ans;
	while(scanf("%d%d",&n,&m)!=EOF){
		memset(head,-1,sizeof(head)); add=0;
		memset(tot,0,sizeof(tot));
		for(int i=0;i<m;i++){
			scanf("%d%d",&u,&v);
			adj(u,v);
			tot[u]++;
			tot[v]++;
		}
		ans=1;
		for(int i=1;i<=n;i++){
			if(tot[i]==1){
				ans=i;
			}
		}
		memset(vis,0,sizeof(vis));
		f=true; cnt=0;
		dfs(-1,ans);
		for(int i=1;i<=n;i++)
			if(!vis[i]){
				f=false;
				break;
			}
		if(!f) printf("NO\n");
		else if(cnt==0) printf("NO\n");
		else printf("FHTAGN!\n");
	}
	return 0;
}


