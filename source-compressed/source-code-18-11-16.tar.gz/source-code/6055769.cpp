//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<set>
#include<vector>
#include<algorithm>
#define N 1000005
using namespace std;
typedef long long ll;
int n,k;
set<int>S;
int p[N],b[N],c[N];
int pos[N];
int lowbit(int x)
{
    return x&(x^(x-1));
}
void insert(int x, int w)
{
    while(x<=n)
    {
            c[x]+=w;
            x+=lowbit(x);
    }
}
int sum(int x)
{
    int ans = 0;
    while(x>0)
    {
          ans+=c[x];
          x-=lowbit(x);
    }
    return ans;
}
int main(){
    while(cin>>n>>k){
        memset(b,0,sizeof(b));
        for(int i=1;i<=n;++i){
                scanf("%d",p+i);
                pos[p[i]]=i;
        }
        for(int i=1;i<=k;++i){
                int x;
                cin>>x;
                b[x]=1;
        }
        S.clear();
        S.insert(0);
        S.insert(n+1);
        memset(c,0,sizeof(c));
        ll ans=0;
        for(int i=1;i<=n;++i){
                if(b[i]){
                      S.insert(pos[i]);   
                }
                else{
                     set<int>::iterator itr=S.lower_bound(pos[i]);
                     int r=*itr;
                     int l=*(--itr);
                     ll num=(ll)(r-l-1-sum(r-1)+sum(l));
                     ans+=num;
                     insert(pos[i],1);
                }
        }
        cout<<ans<<endl;
    }
    return 0;
}
