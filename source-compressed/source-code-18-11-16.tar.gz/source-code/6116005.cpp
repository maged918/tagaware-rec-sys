//Language: GNU C++


#include <stdio.h>
#include <stdlib.h>
int a[1010][1010];
int main()
{
    int i,j,n,p,sum=0,t,b;
    scanf("%d",&n);
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
           scanf("%d",&a[i][j]);
    for(i=0;i<n;i++)
        sum+=a[i][i];
    sum%=2;
    scanf("%d",&p);
    for(i=1;i<=p;i++)
    {
        scanf("%d",&t);
        if(t==3)
            printf("%d",sum);
        else
        {
            sum=1-sum;
            scanf("%d",&b);
        }
    }
    printf("\n");

    return 0;
}