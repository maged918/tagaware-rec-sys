//Language: GNU C++


#include <iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<stdlib.h>
#include<vector>
#include<cmath>
#include<queue>
#include<set>
using namespace std;
#define N 105
#define LL long long
#define INF 0xfffffff
const double eps = 1e-8;
const double pi = acos(-1.0);
const double inf = ~0u>>2;
char s[N];
int main()
{
    int i,j,k;
    cin>>s;
    k = strlen(s);
    int ans = 1,g=1;
    for(i = 1; i < k ;i++)
    {
        if(s[i]!=s[i-1])
        {
            g = 1;
            ans++;
        }
        else g++;
        if(g>5)
        {
            g = 1;
            ans++;
        }
        //cout<<ans<<" "<<g<<" "<<s[i]<<endl;
    }
    cout<<ans<<endl;
    return 0;
}

	      	 		     				 	 	 	