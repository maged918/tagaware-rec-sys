//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#define ALL(x) (x).begin(), (x).end()
#define SIZE(x) ((int)(x).size())

const int N = int(1e5) + 10;

int n, m;
int edges[N][2];
int value[N];
std::vector <int> choose[N], adj[N], id[N];
int dfn[N], timestamp;

int link(int k, int x) {
    return edges[k][edges[k][0] == x];
}

bool dfs(int x, int parent, int edge_id) {
    dfn[x] = ++timestamp;
    for (int i = 0; i < SIZE(adj[x]); i++) {
        int y = adj[x][i];
        if (y == parent) {
            continue;
        }
        if (!dfn[y]) {
            if (!dfs(y, x, id[x][i])) {
                return false;
            }
        } else if (dfn[y] < dfn[x]) {
            value[y] ^= 1;
            choose[y].push_back(id[x][i]);
        }
    }
    if (edge_id > -1) {
        if (value[x] == 0) {
            value[parent] ^= 1;
            choose[parent].push_back(edge_id);
        } else {
            value[x] ^= 1;
            choose[x].push_back(edge_id);
        }
    }
    return value[x] == 0;
}

int main() {
    scanf("%d%d", &n, &m);
    for (int i = 0; i < m; i++) {
        int x, y;
        scanf("%d%d", &x, &y);
        x--, y--;
        edges[i][0] = x;
        edges[i][1] = y;
        adj[x].push_back(y);
        id[x].push_back(i);
        adj[y].push_back(x);
        id[y].push_back(i);
    }
    for (int i = 0; i < n; i++) {
        if (!dfn[i]) {
            if (!dfs(i, -1, -1)) {
                puts("No solution");
                return 0;
            }
        }
    }
    for (int i = 0; i < n; i++) {
        if (SIZE(choose[i]) > 0) {
            for (int j = 0; j < SIZE(choose[i]); j += 2) {
                printf("%d %d %d\n", link(choose[i][j], i) + 1, i + 1, link(choose[i][j + 1], i) + 1);
            }
        }
    }
}

