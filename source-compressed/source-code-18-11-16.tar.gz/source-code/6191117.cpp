//Language: GNU C++


#include<stdio.h>
#include<string.h>
int main()
{
    int a[200]= {0},b[200]= {0},s=0,len,i,flag=0;
    char t,str[1010];
    gets(str);
    len=strlen(str);
    for (i=0; i<=len-1; i++)
        a[str[i]]++;
    gets(str);
    len=strlen(str);
    for (i=0; i<=len-1; i++)
        b[str[i]]++;
    for (i='a'; i<='z'; i++)
    {
        if (a[i]>=b[i]) s+=b[i];
        else if (b[i]>a[i]) s+=a[i];
        if (b[i]>0&&a[i]==0) flag=1;
    }
    if (flag==1) printf("-1");
    else printf("%d",s);
    return 0;
}
