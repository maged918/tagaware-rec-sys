//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<cmath>
#define MAXN 5100
#define MAX 40000
using namespace std;

int A[MAXN] , B[MAXN] , G[MAXN] , n , m, SU[MAX] , V[MAX]  ;
int GCD( int K1 , int K2 )
{
	if ( K2 == 0 ) return K1 ;
	return GCD( K2 , K1 % K2 ) ;
}

int main()
{
	//freopen( "B.in" , "r" , stdin );
	//freopen( "B.out" , "w" , stdout );
	
	memset( V , false , sizeof( V ) ); SU[0] = 0 ;
	for ( int i = 2 ; i < MAX ; i++ ) if ( !V[i] )
	{
		SU[ ++SU[0] ] = i ;
		for ( int j = i ; j < MAX ; j += i ) V[j] = true ;
	}

	scanf( "%d%d" , &n , &m );
	for ( int i = 1 ; i <= n ; i++ ) scanf( "%d" , &A[i] );
	for ( int i = 1 ; i <= m ; i++ ) scanf( "%d" , &B[i] );
	G[1] = A[1] ; for ( int i = 2 ; i <= n ; i++ ) G[i] = GCD( G[i-1] , A[i] );
	
	for ( int i = n ; i >= 1 ; i-- )
	{
		int g = G[i] , num = 0 ;
		for ( int j = 1 ; j <= m ; j++ ) 
			while ( g % B[j] == 0 ) g /= B[j] , num ++ ;
		for ( int j = 1 ; j <= SU[0] ; j++ ) 
			while ( g % SU[j] == 0 ) g /= SU[j] , num -- ;
		if ( g != 1 ) num -- ;
		
		if ( num <= 0 ) continue ;
		for ( int j = 1 ; j <= i ; j++ ) A[j] /= G[i] , G[j] /= G[i] ;
	}
	
	int ANS = 0 ;
	for ( int i = 1 ; i <= n ; i++ )
	{
		for ( int j = 1 ; j <= m ; j++ )
			while ( A[i] % B[j] == 0 ) A[i] /= B[j] , ANS ++ ;
		for ( int j = 1 ; j <= SU[0] ; j++ )
			while ( A[i] % SU[j] == 0 ) A[i] /= SU[j] , ANS -- ;
		if ( A[i] != 1 ) ANS--;
	}
	printf( "%d\n" , -ANS );
	return 0 ;
}
