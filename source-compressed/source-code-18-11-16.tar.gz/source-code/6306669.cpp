//Language: GNU C++


#include <iostream>
#include <math.h>
#include <algorithm>
#include <vector>

using namespace std;

long long do_it(long long x,long long a,long long b){
    long long l = 0,r =x, max = x*a / b;
    while (l < r){
        //cout << l << " " << r<< endl;
        long long m = l+(r-l)/2;
        if (a*m/b == max) r=m;
        else if (a*m/b < max) l=m+1;
    }
    return r;
}


int main()
{
    long long n,a,b,x;
    cin >> n;
    cin >> a;
    cin >> b;

    for (int i =0 ; i<n; ++i){
        cin >> x;
        long long r = do_it(x,a,b);
        cout << x-r << " ";
    };

    return 0;
}
