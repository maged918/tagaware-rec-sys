//Language: GNU C++0x


#include <vector>
#include<cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <string>
#include <map>
#include <deque>
#include <set>
#ifdef __GXX_EXPERIMENTAL_CXX0X__
#include <unordered_map>
#include <cassert>
#endif
#include <ctime>
#include <queue>
#include <stack>
#include<iomanip>
#include <sstream>
#include <cmath>
using namespace std;
typedef pair<int, int> PII;
void solve(int ncase) {
    int n;
    cin >> n;
    vector<pair<int, PII>> reqs(n);
    for(int i = 0; i < n; i ++) {
        int c, p;
        cin >> c >> p;
        reqs[i] = pair<int, PII>(c, PII(p, i + 1));
    }
    int nr;
    cin >> nr;
    vector<PII> room(nr);
    for(int i = 0; i < nr; i ++) {
        cin >> room[i].first;
        room[i].second = i + 1;
    }
    sort(reqs.begin(), reqs.end());
    sort(room.begin(), room.end());
    priority_queue<PII> pq;
    int idx = 0;
    vector<PII> accept;
    int sum_p = 0, sum_ac = 0;
    for(int i = 0; i < nr; i ++) {
        while(idx < n && reqs[idx].first <= room[i].first) {
            pq.push(reqs[idx ++].second);
        }
        if (!pq.empty()) {
            sum_ac ++;
            PII req = pq.top();
            pq.pop();
            sum_p += req.first;
            accept.push_back(PII(req.second, room[i].second));
        }
    }
    sort(accept.begin(), accept.end());
    cout << sum_ac << " " << sum_p << endl;
    for(int i = 0; i < sum_ac; i ++) {
        cout << accept[i].first << " " << accept[i].second << endl;
    }
}
int main() {
    ios::sync_with_stdio(false);
    //cout << setprecision(16) << endl;
#ifdef _zzz_
    //freopen("D--large.in", "r", stdin);
    //freopen("D-out.txt", "w", stdout);
#endif
    int T = 1;
    //cin >> T;
    int ncase = 0;
    while(T --) {
        solve(++ ncase);
    }
}
