//Language: GNU C++


#include <iostream>
#include <list>
using namespace std;

list< pair< pair<int, int>, int > > visitors;
list< pair<int, int> > tables;
list< pair<int, int> > result;
int s;

/*
void printLists() {
	list< pair<pair<int, int>, int> >::iterator it1 = visitors.begin();
	while (it1 != visitors.end()) {
		cout << it1->first.first << " " << it1->first.second << endl;
		it1++;
	}
	cout << endl;
	
	list< pair<int, int> >::iterator it2 = tables.begin();
	while (it2 != tables.end()) {
		cout << it2->first << " ";
		it2++;
	}
	cout << endl;
}
*/

void decide() {
	while (visitors.size() != 0) {
		list< pair<int, int> >::iterator it = tables.begin();
		while (it != tables.end() and it->first < visitors.begin()->first.second) it++;
		if (it != tables.end()) {
			s += visitors.begin()->first.first;
			result.push_back(pair<int, int>(visitors.begin()->second, it->second));
			tables.erase(it);
		}
		visitors.pop_front();
	}
	result.sort();
}

void printResult() {
	cout << result.size() << " " << s << endl;
	for (list< pair<int, int> >::iterator it = result.begin(); it != result.end(); ++it)
		cout << it->first << " " << it->second << endl;
}

bool descending_order(const pair<pair<int,int>, int> &a, const pair<pair<int,int>, int> &b) {
	return a.first.first >= b.first.first;
}


int main() {
	int n;
	cin >> n;
	for (int i = 0; i < n; ++i) {
		int ci, pi;
		cin >> ci >> pi;
		visitors.push_back(pair<pair<int, int>, int>(pair<int, int>(pi, ci), i+1));
	}
	int k;
	cin >> k;
	for (int i = 0; i < k; ++i) {
		int ri;
		cin >> ri;
		tables.push_back(pair<int, int> (ri, i+1));
	}
	visitors.sort(descending_order);
	tables.sort();
	//printLists();
	decide();
	printResult();
}