//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;
double p1 = 1.0, p2 = 1.0;
vector <int> ch, zn;
void factor(int x, vector <int>& a)
{
  if (x == 1 || x < 0)
    return;
  int d = 2;
  while (d * d <= x)
    if (x % d == 0)
    {
      a[d]++;
      x /= d;
    } else
      d++;
  a[x]++;
}
int main()
{
  int n, m, k, p = 0, x, sk;
  cin >> n >> m >> k;
  for (int i = 1; i <= m; i++)
  {
    cin >> x;
    if (i == k)
      sk = x;
    p += x;
  }
  k = sk - 1;
  p--;
  n--;
  if (p < n)
  {
    cout << -1;
    return 0;
  }
  ch.assign(p + 4, 0);
  for (int i = p - n - k + 1; i <= p - n; i++)
    factor(i, ch);
  zn.assign(p + 4, 0);
  for (int i = p - k + 1; i <= p; i++)
    factor(i, zn);
  for (int i = 1; i <= p; i++)
  {
    int dec = min(zn[i], ch[i]);
    ch[i] -= dec;
    zn[i] -= dec;
  }
  double ans = 1.0;
  for (int i = 0; i <= p; i++)
    while (ch[i] + zn[i] > 0)
    {
      if (ch[i] != 0)
      {
        ch[i]--;
        ans *= i;
      }
      if (zn[i] != 0)
      {
        zn[i]--;
        ans /= i;
      }
    }
  /*for (int i = 0; i <= p; i++)
    for (int j = 1; j <= ch[i]; j++)
      p1 *= i;
  for (int i = 0; i <= p; i++)
    for (int j = 1; j <= zn[i]; j++)
      p2 *= i;*/
  //cout << p1 << " " << p2 << endl;
  printf("%.8f", 1 - ans);
  return 0;
}
