//Language: MS C++


#include <stdio.h>
#include <iostream>
#include <string>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>

using namespace std;

struct A
{
	int x, k;
};

int main()
{ 
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	int n, ans = 0; 
	static int b[1000000] = {0};
	static A a[1000000];
	
	scanf("%d", &n);

	bool ok = true;
	for (int i = 0; i < n; i++)
	{
		scanf("%d%d", &a[i].x, &a[i].k);
		if (b[a[i].k] == a[i].x)
			b[a[i].k]++;
		else
			if (b[a[i].k] < a[i].x)
				ok = false;
	}

	if (ok)
		printf("YES");
	else
		printf("NO");

	return 0;
}