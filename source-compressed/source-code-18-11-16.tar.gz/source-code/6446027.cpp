//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <malloc.h>
#include <math.h>
#include <iostream>
#include <algorithm>
using namespace std;
#include <queue>
#include <stack>
#include <vector>
#include <set>
#include <deque>

deque <int> s;
int a[100005];
int p[100005];
int f[100005];
int tmp, num;
char b[2];
int main() 
{
    int n, m, x, i;
    scanf("%d%d", &n, &m);
    for(i=0;i<m;i++) 
    {
        scanf("%s%d", b, &x);
        if(b[0]=='+')
        {
            s.push_back(x);
            f[x] = 1;
        } 
        else 
        {
            s.push_back(-x);
            if(!f[x])
                s.push_front(x);
        }
    }
    memset(f, 0, sizeof(f));
    while(s.size()) 
    {
        x=s.front();
        s.pop_front();
        if(x>0) 
        {
            if(p[x]!=1 && (num>0 || tmp>0))
                f[x] = 1;
            num++;
            for(i=0;i<tmp;i++) 
            {
                if(a[i]==x)
                    continue;
                f[a[i]] = 1;
            }
            tmp=0;
            p[x]=1;
        } 
        else 
        {
            num--;
            if(num>0) 
                f[-x]=1;
            a[tmp++]=-x; 
        }
    }
    tmp=0;
    for(i=1;i<=n;i++)
        if(f[i]==0) 
            a[tmp++]=i;
    printf("%d\n", tmp);
    for(i=0;i<tmp;i++)
    {
        printf("%d", a[i]);
        if(i==(tmp-1))
            printf("\n");
        else
            printf(" ");
    }
    return 0;
}