//Language: GNU C++


#include <set>
#include <map>
#include <cmath>
#include <stack>
#include <queue>
#include <string>
#include <cstdio>
#include <vector>
#include <cctype>
#include <climits>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
#define mp make_pair
//int geti(){int y=0,s=1;char c=getchar();while(!isdigit(c)&&c!='-')c=getchar();if(c=='-')s=-1,c=getchar();while(isdigit(c))y=y*10+(c-'0'),c=getchar();return s*y;}
int dx[] = { 1, -1, 0, 0, 1, 1, -1, -1 };
int dy[] = { 0, 0, 1, -1, -1, 1, -1, 1 };

int main()
{
    //freopen("myfile.txt","r",stdin);
    vector<int>x;
    int n,a,b;
    cin>>n>>a>>b;
    int v;
    x.resize(n+1);
    for(int i=1;i<=a;++i){
        cin>>v;
        x[v]=1;
    }
    for(int i=1;i<=b;++i){
        cin>>v;
        x[v]=2;
    }
    
    for(int i=1;i<=n;++i)
        cout<<x[i]<<' ';

    return 0;
}
