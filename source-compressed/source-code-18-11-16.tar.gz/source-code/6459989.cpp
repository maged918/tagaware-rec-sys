//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>

using namespace std;

int X[110], D[110];

int main() {
  int n;
  while(scanf("%d", &n) != EOF) {
    for( int i=0; i<n; i++ ) {
      scanf("%d%d", &X[i], &D[i]);
    }
    int f = 0;
    for( int i=0; i<n && f == 0; i++ ) {
      for( int j=i+1; j<n; j++ ) {
        if(X[i] + D[i] == X[j] && X[j] + D[j] == X[i]) {
          f = true;
          break;
        }
      }
    }
    if(f) printf("YES\n");
    else printf("NO\n");
  }
  return 0;
}