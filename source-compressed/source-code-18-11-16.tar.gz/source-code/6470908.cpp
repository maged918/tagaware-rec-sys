//Language: GNU C++


//Template
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <climits>
#include <cmath>
#include <utility>
#include <set>
#include <map>
#include <queue>
#include <ios>
#include <iomanip>
#include <ctime>
#include <numeric>
#include <functional>
#include <fstream>
#include <string>
#include <vector>
#include <bitset>
#include <cstdarg>
#include <complex>
using namespace std;

typedef long long ll;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef long double ld;
#define pair(x, y) make_pair(x, y)
#define runtime() ((double)clock() / CLOCKS_PER_SEC)

inline int read() {
    static int r, sign;
    static char c;
    r = 0, sign = 1;
    do c = getchar(); while (c != '-' && (c < '0' || c > '9'));
    if (c == '-') sign = -1, c = getchar();
    while (c >= '0' && c <= '9') r = r * 10 + (int)(c - '0'), c = getchar();
    return sign * r;
}

template <typename T>
inline void print(T *a, int n) {
    for (int i = 1; i < n; ++i) cout << a[i] << " ";
    cout << a[n] << endl;
}
#define PRINT(_l, _r, _s, _t) { cout << #_l #_s "~" #_t #_r ": "; for (int _i = _s; _i != _t; ++_i) cout << _l _i _r << " "; cout << endl; }

#define N 310
typedef pair <int, pair <pair <int, int>, pair <int, int> > > answer;
int n, m, a[N + 1][N + 1], t, tp, tu, td, down[N + 1], up[N + 1];
int L[N + 1][N + 1], R[N + 1][N + 1], U[N + 1][N + 1], D[N + 1][N + 1];

inline int eval(int x, int y, int i, int j) {
    if (x == 0 || y == 0 || x > n || y > m) return 0;
    if (a[i][j] > a[x][y]) return tu;
    if (a[i][j] < a[x][y]) return td;
    return tp;
}

set <pair <int, int> > h;
set <pair <int, int> > :: iterator it;

answer solve() {
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j) {
            L[i][j] = L[i][j - 1] + eval(i, j - 1, i, j);
            U[i][j] = U[i - 1][j] + eval(i - 1, j, i, j);
        }
    for (int i = n; i > 0; --i)
        for (int j = m; j > 0; --j) {
            R[i][j] = R[i][j + 1] + eval(i, j + 1, i, j);
            D[i][j] = D[i + 1][j] + eval(i + 1, j, i, j);
        }
    
    answer ret = pair(INT_MAX, pair(pair(0, 0), pair(0, 0)));
    for (int l = 1; l <= m; ++l)
        for (int r = l + 2; r <= m; ++r) {
            for (int i = 1; i <= n; ++i) {
                down[i] = R[i][l] - R[i][r] + U[i][r] + D[1][l] - D[i][l];
                up[i] = L[i][r] - L[i][l] - U[i][r] - (D[1][l] - D[i][l]);
            }
            h.clear();
            for (int i = 3; i <= n; ++i) {
                h.insert(pair(up[i - 2], i - 2));
                it = h.lower_bound(pair(t - down[i], 0));
                int val = INT_MAX, p = -1;
                if (it != h.end())
                    val = abs(down[i] + it->first - t), p = it->second;
                if (it != h.begin()) {
                    --it;
                    if (val > abs(down[i] + it->first - t))
                        val = abs(down[i] + it->first - t), p = it->second;
                }
                if (val < ret.first)
                    ret = pair(val, pair(pair(p, l), pair(i, r)));
            }
        }
    
    return ret;
}

int main(int argc, char *argv[]) {
#ifdef KANARI
    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);
#endif
    
    scanf("%d%d%d", &n, &m, &t);
    scanf("%d%d%d", &tp, &tu, &td);
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= m; ++j)
            scanf("%d", &a[i][j]);
    
    answer ans = solve();
//  for (int i = 1; i <= n; ++i)
//      reverse(a[i] + 1, a[i] + m + 1);
//  ans = min(ans, solve());
    
    cerr << ans.first << endl;
    printf("%d %d ", ans.second.first.first, ans.second.first.second);
    printf("%d %d\n", ans.second.second.first, ans.second.second.second);
    
    fclose(stdin);
    fclose(stdout);
    return 0;
}