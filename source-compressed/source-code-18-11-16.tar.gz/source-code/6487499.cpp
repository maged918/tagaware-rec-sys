//Language: GNU C++



#include <stdio.h>
#include <iostream>
#include <algorithm>

using namespace std ;

int a[110] ;

int main()
{
    int n,s ;
    while(~scanf("%d %d",&n,&s))
    {
        for(int i = 0 ; i < n ; i++)
            scanf("%d",&a[i]) ;
        sort(a,a+n) ;
        int sum = 0 ;
        bool flag = false ;
        for(int i = 0 ; i < n-1 ; i++)
        {
            sum += a[i] ;
            if(sum > s)
            {
                flag = true ;
                break ;
            }
        }
        if(flag)
            puts("NO") ;
        else puts("YES") ;
    }
    return 0 ;
}
