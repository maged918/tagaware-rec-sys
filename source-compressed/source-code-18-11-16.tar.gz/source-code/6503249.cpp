//Language: MS C++


#include <iostream>
using namespace std;

const int mod = int(1e9)+7;  
#define LL __int64
int dp[510][510];

int cal(int a,int p)
{
	int ans = 1;
	int t = a;
	while(p)
	{
		if(p&1)
			ans = (LL)ans*t % mod;
		t = (LL)t*t %mod;
		p>>=1;
	}
	return ans;
}

int solve(int n,int k)
{
	if(k==0)
		return 1;
	if(dp[n][k]!=-1)
		return dp[n][k];
	if(k>n) return 0;

	LL ans = 0;
	for(int i=1;i<=n;i++)
	{
		LL t = (cal(2,i)+mod-1)%mod;
		t = t * solve(n-i,k-1) % mod;
		t = t * cal(2,i*(n-i)) % mod;
		ans += t;
		ans %= mod;
    }
	return dp[n][k] = (int)ans;
}

int main()
{
	int n,k;
	cin>>n>>k;
	memset(dp,-1,sizeof(dp));
	cout<<solve(n,k)<<endl;
	return 0;
}