//Language: GNU C++


/*************************************************************************
    > File Name: 244-2-E.cpp
    > Author: mengshangqi
    > Mail: mengshangqi@gmail.com 
    > Created Time: 2014年05月03日 星期六 16时38分15秒
 ************************************************************************/

#include<iostream>
#include<cstdio>
#include<set>
#include<map>
#include<algorithm>
#include<vector>
#include<cstring>
#include<string>
#include<bitset>
#include<sstream>
#include<queue>
#include<stack>
#include<cmath>
using namespace std;
typedef long long ll;
const int N=1000006;
ll x[N];
ll l[N],r[N];
int main()
{
#ifndef ONLINE_JUDGE
    freopen("input.txt","r",stdin);
#endif
	int n,m;
	while(scanf("%d%d",&n,&m)!=EOF)
	{
		for(int i=1;i<=n;i++)
			scanf("%I64d",&x[i]);

		memset(l,0,sizeof(l));
		memset(r,0,sizeof(r));
		
		sort(x+1,x+n+1);

		for(int i=2;i<=n;i++)
		{
			l[i]=l[i-1];
			ll mu=ll(i-1+m-1)/m;
			l[i]=l[i]+mu*2LL*(x[i]-x[i-1]);
			//cout<<(x[i]-x[i-1])<<endl;

		}
		for(int i=n-1;i>=1;i--)
		{
			int temp=n-i;
			ll mu=(temp+m-1)/m;
			r[i]=r[i+1];
			r[i]+=mu*2*(x[i+1]-x[i]);
		}
		
		ll res=1e16;
		for(int i=1;i<=n;i++)
		{
			res=min(res,l[i]+r[i]);
		}
		cout<<res<<endl;
	}
    return 0;
}
