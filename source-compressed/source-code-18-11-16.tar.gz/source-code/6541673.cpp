//Language: GNU C++0x


#include <iostream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <bitset>
#include <ctime>

using namespace std;

template <typename T> inline void mn(T& x, const T& y) { if (y < x) x = y; }
template <typename T> inline void mx(T& x, const T& y) { if (x < y) x = y; }
template <typename T> inline int sz(const T& x) { return (int) x.size(); }

#define PATH "C:\\Users\\Valenkof\\Desktop\\"
#define forn(i, n) for(int i = 0; i < (n); ++i)
#define all(x) x.begin(), x.end()
#define debug(x) cerr << "DEBUG: " << #x << " = " << x << endl;
#define pb push_back
#define mp make_pair

const int N = 300;

int sum_row_r[N][N];
int sum_row_l[N][N];
int sum_col_d[N][N];
int sum_col_u[N][N];

int tp, tu, td;

int n, m, t;

int h[N][N];

inline int cost(int h1, int h2) {
    if (h1 < h2) return tu;
    if (h1 > h2) return td;
    return tp;
}

int ansI1, ansI2;
int ansJ1, ansJ2;
int ansDiff = 2000000000;

inline void upd(int i1, int i2, int j1, int j2, int sum) {
    // cout << i1 << ' ' << i2 << ' ' << j1 << ' ' << j1 << ' ' << sum << endl;
    if (abs(sum - t) < ansDiff) {
        // debug(sum);
        ansDiff = abs(sum - t);
        ansI1 = i1;
        ansI2 = i2;
        ansJ1 = j1;
        ansJ2 = j2;     
    }
}

int main() {
    ios_base::sync_with_stdio(false);

    cin >> n >> m >> t;
    cin >> tp >> tu >> td;
    
    forn (i, n) forn (j, m) {
        cin >> h[i][j];
    }
    
    forn (i, n) forn (j, m) {
        if (i != 0) {
            sum_col_u[i][j] = sum_col_u[i - 1][j] + cost(h[i][j], h[i - 1][j]);
            sum_col_d[i][j] = sum_col_d[i - 1][j] + cost(h[i - 1][j], h[i][j]);
        }
        if (j != 0) {
            sum_row_l[i][j] = sum_row_l[i][j - 1] + cost(h[i][j], h[i][j - 1]);
            sum_row_r[i][j] = sum_row_r[i][j - 1] + cost(h[i][j - 1], h[i][j]);
        }   
    }
    
    for (int i1 = 0; i1 < n; ++i1) {
        for (int i2 = i1 + 2; i2 < n; ++i2) {
            map<int, int> js;
            
            js[sum_col_u[i2][0] - sum_col_u[i1][0]] = 0;

            for (int j2 = 2; j2 < m; ++j2) {
                int sum = (sum_row_r[i1][j2] + sum_row_l[i2][j2] +
                    sum_col_d[i2][j2] - sum_col_d[i1][j2]);

                auto it = js.upper_bound(t - sum);
                    
                if (it != js.end()) upd(i1, i2, it->second, j2, it->first + sum);
                if (it != js.begin()) { --it; upd(i1, i2, it->second, j2, it->first + sum); }
                    
                js[sum_col_u[i2][j2 - 1] - sum_col_u[i1][j2 - 1]
                    - sum_row_r[i1][j2 - 1] - sum_row_l[i2][j2 - 1]] = j2 - 1;
            }
        }
    }
    
    cout << ansI1 + 1 << ' ' << ansJ1 + 1 << ' ' << ansI2 + 1 << ' ' << ansJ2 + 1 << endl;
    
    
    return 0;
}