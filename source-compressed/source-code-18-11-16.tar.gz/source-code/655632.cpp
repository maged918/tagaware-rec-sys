//Language: GNU C++


#include <iostream>
#include <vector>
#include <cmath>
#include <cstdio>
#include <algorithm>
#include <string>
#include <map>
#include <queue>
#include <set>
#include <cstring>


using namespace std;
const int INF = 1000000010;

typedef long long ll;
#define sqr(i) ((i)*(i))



int main()
{
    //freopen("tester.in","r",stdin);
    //freopen("tester.out","w",stdout);
    //freopen("dict.in","r",stdin);freopen("dict.out","w",stdout);

    int n;
    cin >> n;
    int maxi = -1;
    for (int i = 0; i <= n; i++)
        if (i*4 <= n && (n-i*4)%7==0 ) {maxi = i; break;}

    if (maxi == -1) cout << -1;
    else
    {
        for (int i = 0; i < maxi; i++)
            printf("4");
        for (int i = 0; i < ((n-4*maxi)/7); i++)
            printf("7");
    }
    


    
}