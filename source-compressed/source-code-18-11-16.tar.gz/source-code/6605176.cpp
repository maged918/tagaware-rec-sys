//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#include <set>
#include <bitset>
#include <queue>
#include <stack>
#include <sstream>
#include <cstring>
#include <numeric>
#include <ctime>

#define re return
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define sz(x) ((int) (x).size())
#define rep(i, n) for (int i = 0; i < (n); i++)
#define rrep(i, n) for (int i = (n) - 1; i >= 0; i--)
#define y0 y32479
#define y1 y95874
#define fill(x, y) memset(x, y, sizeof(x))
#define sqr(x) ((x) * (x))
#define sqrt(x) sqrt(abs(x))
#define unq(x) (x.resize(unique(all(x)) - x.begin()))
#define spc(i,n) " \n"[i == n - 1]

using namespace std;

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<string> vs;
typedef double D;
typedef long double LD;
typedef long long ll;
typedef pair<ll, ll> pll;
typedef vector<ll> vll;

template<class T> T abs(T x) { return x > 0 ? x : -x;}

#define FILENAME ""

int m;
int n;
int a[100];

int prev[100];
vi v[100];

int check(int p) {
    int k = n - p;
    rrep(i, p) {
        int c = 1;
        rep(j, sz(v[i])) {
            int y = v[i][j];
            c += a[y];
        }
        if (c > a[i])
            re 0;
        if (a[i] - c > k)
            re 0;
        if (a[i] - c + sz(v[i]) < 2)
            re 0;
        k -= (a[i] - c);
    }
    re 1;
}

int go(int p) {
    if (a[p] <= 1)
        re check(p);
    rep(i, p) {
        prev[p] = i;
        v[i].pb(p);
        if (go(p + 1))
            re 1;;
        v[i].pop_back();
    }
    re 0;
}

int main() {
    //freopen("input.txt", "r", stdin);
    //freopen("output.txt", "w", stdout);

    cin >> n;
    rep(i, n) {
        cin >> a[i];
    }

    sort(a, a + n);
    reverse(a, a + n);
    if (a[0] != n) {
        cout << "NO" << endl;
        re 0;
    }
    if (2 * count(a, a + n, 1) <= n) {
        cout << "NO" << endl;
        re 0;
    }

    if (n == 1) {
        cout << "YES" << endl;
        re 0;
    }

    if (go(1))
        cout << "YES" << endl;
    else
        cout << "NO" << endl;

    re 0;
}
