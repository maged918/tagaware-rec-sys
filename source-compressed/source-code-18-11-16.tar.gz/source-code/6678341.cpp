//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <vector>
#include <cstring>
#include <string>
#include <cmath>
#include <queue>
#include <deque>
#include <bitset>
#include <algorithm>
#include <stack>
#include <set>
#include <map>
#include <list>
#include <sstream>
using namespace std;

#define DB(x) cerr<<#x<<"="<<x<<" "
#define DBN(x) cerr<<#x<<"="<<x<<"\n"
#define rep(i,l,r) for (int i=(l); i<=(r); i++)
#define repd(i,r,l) for (int i=(r); i>=(l); i--)
#define rept(i,c) for (typeof((c).begin()) i=(c).begin(); i!=(c).end(); i++)
#define sqr(x) ((x)*(x))
#define pb push_back
#define mp make_pair

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;

#define INF 1000000000
#define EPS (double)1e-9
#define MOD 1000000007
#define PI 3.14159265358979328462
long long m;
int k;
#define MAX_C 70
long long C[MAX_C][MAX_C];
void init() {
    memset(C, 0, sizeof(C));
    for (int i = 0; i < MAX_C; ++i) {
	C[i][0] = C[i][i] = 1;
	for (int j = 1; j < i; ++j)
	    C[i][j] = C[i-1][j] + C[i-1][j-1];
    }
}
long long get(long long n) {
    // [0, n] and k
    int cnt = 0;
    long long ans = 0;
    for (int i = 62; i >= 0 && k-cnt>=0; i--)
	if ((1LL<<i) & n) {
	    ans += C[i][k-cnt];
	    cnt++;
	}
    if (k == cnt) ans++;
    return ans;
}
long long solve() {
    long long L = 1, R = 1000000000000000000LL;
    while (L <= R) {
	long long M = L + (R-L)/2;
	long long res = get(M<<1) - get(M);
	if (res == m) return M;
	if (res > m) R = M-1;
	else L = M+1;
    }
    return -1;
}
int main(int argc, char *argv[])
{
    init();
    cin >> m >> k;
    cout << solve() << endl;
    return 0;
}

