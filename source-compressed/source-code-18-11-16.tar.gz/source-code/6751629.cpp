//Language: GNU C++


#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct coord
{
    int x,y;
    bool fl;
};

bool comp(coord a, coord b)
{
    return (a.y > b.y) || ((a.y==b.y) && a.x< b.x);
}

int a[1001];


/*
int ar[1000001];
bool arf[1000001];*/
int n;

vector<coord> coords;
vector<coord> coords2;

int main()
{
    cin>>n;
    a[0] = 0; 
    coord cur;
    int sumx = 0;
    cur.x = 0;
    cur.y = 0;
    coords.push_back(cur);
    for (int i = 1; i<= n; i++)
    {
        cin>>a[i];
    }
    for (int i = 1; i <= n; i++)
    {
        cur.x = coords[i-1].x+a[i];
        sumx +=a[i];
        if (i%2 == 1)
            cur.y = coords[i-1].y+a[i];
        else
            cur.y = coords[i-1].y-a[i];
        coords.push_back(cur);
    }
    //cout<<"safa"<<endl;
    long cn = 0;
    for (int i = 0; i<n; i++)
    {
        bool fl = coords[i].y > coords[i+1].y;
        int diff = (fl) ? -1 : 1;       
        int y = coords[i].y;
    
        for (int j = coords[i].x; j < coords[i+1].x; j++)
        {
            /*ar[j] = y;
            if (fl)
            {
                arf[j] = false;
            } else 
            {
                arf[j] = true;
            }*/
                
            cur.x = j;
            cur.y = y-fl;
            cur.fl = !fl;
            //cout<<cur.x<<" "<<cur.y<<" "<<cur.fl<<endl;
            coords2.push_back(cur);
            y += diff;
            cn++;
        }
        
    }
    sort(coords2.begin(), coords2.begin()+cn, comp);
    int curr = 0;
    char a = '/';
    char b = '\\';
    for (int j = coords2[0].y; j >= coords2[cn-1].y; j--)
    {
        
        for (int i = 0; i < sumx; i++)
        {
            if (coords2[curr].x == i && coords2[curr].y == j)
            {
                cout<<((coords2[curr].fl) ? a : b);
                curr++;
            } else 
            {
                cout<<" ";
            }           
        }
        cout<<endl;
    }
}