//Language: GNU C++0x


#include <iostream>
using namespace std;
int main()
{
	int n,m,d,i,cn=0;
	int ar[101];
	cin>>n>>m;
	for(i=0;i<n;i++)
	{
		cin>>ar[i];
	}
	i=0;
	while(i<n)
	{
		d=ar[i];
		while(d<=m)
		{
			i++;
			d+=ar[i];
		}
		cn++;
	}
	cout<<cn;
}