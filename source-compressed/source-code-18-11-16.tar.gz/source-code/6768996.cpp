//Language: GNU C++


#include<cstdio>
#include<algorithm>
#include<cmath>
#include<stack>
#include<cstring>
#include<queue>
#include<utility>
using namespace std;
typedef pair<int,int> PII;
vector<PII> b;
vector<int> s;
int lowbit(int x) {
	return x&(x^(x-1));
}

int main() {
	int sum,lim,tsum;
	scanf("%d%d",&sum,&lim);
	tsum=sum;
	for(int i=1;i<=lim;i++) b.push_back(PII(lowbit(i),i));
	sort(b.begin(),b.end());
	int pos1=b.size()-1;
	while(sum&&pos1>=0) {
		while(pos1>=0&&b[pos1].first>sum) pos1--;
		if(pos1<0) break;
		sum-=b[pos1].first;
		s.push_back(b[pos1].second);
		pos1--;
	}
	if(pos1<0&&sum>0) puts("-1");
	else {
		int len=s.size();
		printf("%d\n",len);
		for(int i=0;i<len;i++) printf("%d%c",s[i],(i==len-1)?'\n':' ');
	}
	return 0;
}