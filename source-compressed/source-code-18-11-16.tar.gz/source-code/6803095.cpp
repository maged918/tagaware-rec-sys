//Language: GNU C++


#include<iostream>
#include<vector>
#include<algorithm>
using namespace std ; 

int main()
{
    int n; 
    long long int d ; 
    long long int sum = 0 ; 
    cin >> n >> d ; 
    
    long long int x ; 
    
    vector<long long int> v; 
    
    for(int i = 0 ;i < n ; i++ )
    cin >> x , v.push_back(x) ; 
    
    sort(v.begin(),v.end());
    
    for(int i = 0 ; i < n ;i++ )
    sum += (long long int) ((d > 1 ? d-- : 1 )*v[i]) ;
    
    cout << sum << endl ;  
    
    return 0 ; 
}
    
