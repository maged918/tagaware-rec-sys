//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

#define gc getchar
int getint() { unsigned int c; int x = 0; while (((c = gc()) - '0') >= 10) { if (c == '-') return -getint(); if (!~c) exit(0); } do { x = (x << 3) + (x << 1) + (c - '0'); } while (((c = gc()) - '0') < 10); return x; }
int getstr(char str[]) { int c, n = 0; while ((c = gc()) <= ' ') { if (!~c) exit(0); } do { str[n++] = c; } while ((c = gc()) > ' ' ); str[n] = 0; return n; }
template<class T> inline bool chmin(T &a, T b) { return a > b ? a = b, 1 : 0; }
template<class T> inline bool chmax(T &a, T b) { return a < b ? a = b, 1 : 0; }



template<typename Ft> struct MF {
    static const int V = 202 * 51 + 2;
    static const Ft feps = (Ft)1e-10, finf = (Ft)(1 << 28);
    Ft tof;
    int nv, dst[V], srt[V], que[V], qs, qe, src, snk;
    struct edge {
        int to, rv; Ft cap; edge(int to, int rv, Ft cap) : to(to), rv(rv), cap(cap) {}
        string str() { stringstream ss;
            ss << rv << ' ' << cap;
            return ss.str();
        }
    };
    vector<edge> graph[V];
    void init(int v = V) {
        nv = v, tof = 0;
        for (v = 0; v < nv; v++) graph[v].clear();
    }
    void add_edge(int fr, int to, Ft fcap, Ft rcap = 0) {
        if (fr == to) return;
        int fe = graph[fr].size(), te = graph[to].size();
        graph[fr].push_back(edge(to, te, fcap));
        graph[to].push_back(edge(fr, fe, rcap));
    }
    Ft aug(int u, Ft flo) {
        if (u == snk) return flo;
        Ft df;
        for (int &i = srt[u]; i < graph[u].size(); i++) {
            edge &e = graph[u][i];
            if (e.cap > feps and dst[u] < dst[e.to]) {
                if (flo > e.cap) flo = e.cap;
                if ((df = aug(e.to, flo)) > feps) { e.cap -= df, graph[e.to][e.rv].cap += df; return df; }
            }
        }
        return 0;
    }
    Ft dinic(int source, int sink, Ft flo_lim = finf) {
        int i, v;
        src = source, snk = sink;
        Ft df;
        for ( ; tof + feps < flo_lim; ) {
            memset(dst, ~0, sizeof(dst));
            for (dst[src] = 0, qs = qe = 0, que[qe++] = src; qs != qe; ) {
                v = que[qs++];
                for (i = 0; i < graph[v].size(); i++) {
                    const edge &e = graph[v][i];
                    if (e.cap > feps and !~dst[e.to]) {
                        dst[e.to] = dst[v] + 1, que[qe++] = e.to;
                        if (v == snk) { qs = qe = 0; break; }
                    }
                }
            }
            if (!~dst[snk]) return tof;
            memset(srt, 0, sizeof(srt));
            for (; (df = aug(src, flo_lim - tof)) > feps; ) tof += df;
        }
        return tof;
    }
    void cap_inc(int fr, int to, Ft inc) {
        int i;
        for (i = 0; i < graph[fr].size(); i++) if (graph[fr][i].to == to) { graph[fr][i].cap += inc; return; }
        add_edge(fr, to, inc);
    }
    // dec > 0, return decreased flow
    Ft cap_dec(int fr, int to, Ft dec) {
        int i;
        Ft df, flo, res;
        for (i = 0; i < graph[fr].size(); i++) {
            if (graph[fr][i].to == to and graph[fr][i].cap > feps) {
                df = min(graph[fr][i].cap, dec);
                dec -= df, graph[fr][i].cap -= df;
                if (dec <= feps) return 0;
            }
        }
        flo = dinic(fr, to, dec);
        res = 0;
        if (dec - flo > feps) res = dec - flo, dinic(fr, src, res), dinic(snk, to, res);
        for (i = 0; i < graph[to].size(); i++) {
            if (graph[to][i].to == fr and graph[to][i].cap > feps) {
                df = min(graph[to][i].cap, dec);
                dec -= df, graph[to][i].cap -= df;
                if (dec <= feps) break;
            }
        }
        return res;
    }
};


int n, m;
int coef[55 * 3];
int lb[55], ub[55];
int us[111], vs[111], ds[111];
int nodesrt[55];

MF<int> mf;

int quad(int x, int i) {
    return coef[i * 3] * x * x + coef[i * 3 + 1] * x + coef[i * 3 + 2];
}
inline int node(int j, int i) { return nodesrt[i] + j; }

int main () {
    int i, j, tcc, tc = 1 << 28, level;
    for (tcc = 0; tcc < tc; tcc++) {
        n = getint(), m = getint();
        for (i = 0; i < n; i++) {
            coef[i * 3    ] = getint();
            coef[i * 3 + 1] = getint();
            coef[i * 3 + 2] = getint();
        }
        for (i = 0; i < n; i++) {
            lb[i] = getint();
            ub[i] = getint();
        }
        for (i = 0; i < m; i++) {
            us[i] = getint() - 1, vs[i] = getint() - 1, ds[i] = getint();
        }
        int s = 0, t = 1, v = 2, maxVal = 0;

        for (i = 0; i < n; i++) {
            nodesrt[i] = v;
            for (level = lb[i]; level <= ub[i]; level++) {
                chmax(maxVal, quad(level, i) + 1);
                v++;
            }
            v++;
        }

        // construct graph
        mf.init(v);
        const int inf = 1 << 28;
        // line
        for (i = 0; i < n; i++) {
            mf.add_edge(s, node(0, i), inf);
            for (level = lb[i], j = 0; level <= ub[i]; level++, j++) {
                mf.add_edge(node(j, i), node(j + 1, i), maxVal - quad(level, i));
            }
            mf.add_edge(node(j, i), t, inf);
        }
        for (i = 0; i < m; i++) {
            int u = us[i], v = vs[i], d = ds[i];
            for (level = lb[u]; level <= ub[u]; level++) {
                int v_val = level - d;
                if (lb[v] <= v_val and v_val <= ub[v] + 1) {
                    int uid = level - lb[u];
                    int vid = v_val - lb[v];
                    mf.add_edge(node(uid, u), node(vid, v), inf);
                }
            }
        }
        cout << maxVal * n - mf.dinic(s, t) << endl;
    }
    return 0;
}
