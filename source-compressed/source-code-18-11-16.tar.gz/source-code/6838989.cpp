//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<set>
#include<vector>
#include<string>
#include<algorithm>
#include<utility>




using namespace std;

int main()
{
  int n,v;
  cin>>n>>v;
  int i,j;
  vector<int> ans;
  for(i=0;i<n;i++)
    {
      int k;
      int flag=0;
      cin>>k;
      for(j=0;j<k;j++)
	{
	  int x;
	  cin>>x;
	  if(v>x)
	    {
	      flag=1;
	    }
	}
      if(flag)
	{
	  ans.push_back(i+1);
	}
    }
  cout<<ans.size()<<endl;
  for(i=0;i<ans.size();i++)
    {
      cout<<ans[i]<<" ";
    }
  cout<<endl;
  return 0;
}
