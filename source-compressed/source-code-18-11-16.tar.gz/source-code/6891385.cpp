//Language: GNU C++


#include <iostream>
using namespace std;
#define MOD 1000000007
int dp[101][101][2];	//length, total weight, includes a d-path

int main()
{
	int wTotal,K,D;
	int iLen,iWeight;
	int edge;
	cin >> wTotal >> K >> D;
	for(iWeight=0;iWeight<100;iWeight++)
		dp[0][iWeight][0] = dp[0][iWeight][1] = 0;
	dp[0][0][0] = 1;
	dp[0][0][1] = 0;
	for(iLen=1;iLen<=wTotal;iLen++)
	{
		for(iWeight=0;iWeight<=wTotal;iWeight++)
		{
			dp[iLen][iWeight][0] = 0;
			for(edge=1;edge<D && edge<=iWeight;edge++)
			{
				dp[iLen][iWeight][0] += dp[iLen-1][iWeight-edge][0];
				dp[iLen][iWeight][0] = dp[iLen][iWeight][0] % MOD;
			}
			dp[iLen][iWeight][1] = 0;
			for(edge=D;edge<=K && edge<=iWeight;edge++)
			{
				dp[iLen][iWeight][1] += dp[iLen-1][iWeight-edge][0];
				dp[iLen][iWeight][1] = dp[iLen][iWeight][1] % MOD;
			}
			for(edge=1;edge<=K && edge<=iWeight;edge++)
			{
				dp[iLen][iWeight][1] += dp[iLen-1][iWeight-edge][1];
				dp[iLen][iWeight][1] = dp[iLen][iWeight][1] % MOD;
			}
		}
	}
	int ans = 0;
	for(iLen=0;iLen<=wTotal;iLen++)
		if(1)
		{
			ans += dp[iLen][wTotal][1];
			ans = ans % MOD;
		}
	cout << ans << endl;
}