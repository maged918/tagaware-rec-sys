//Language: GNU C++0x


#include <bits/stdc++.h>
#define fr(i,a,b) for(int i = (a); i < (b); ++i)
#define rep(i,n) fr(i,0,n)
#define cl(a,b) memset((a), (b), sizeof(a))
#define all(c) (c).begin(), (c).end()
#define _ << ", " <<
#define db(x) cerr << #x " == " << x << endl

using namespace std;

typedef pair<int,int> ii;
typedef vector<int> vi;
typedef long long ll;
const int inf = 0x3f3f3f3f;

typedef pair<double,double> pdd;

pdd memo[111];
double prob[111]; int mark[111];
int n;

const double eps = 1e-9;

pdd solve(int id) {
  if (id == n) return pdd(0,1);
  pdd& ret = memo[id];
  if (mark[id]) return memo[id];
  mark[id] = 1;
  pdd cost = solve(id+1);
  double ncost = cost.first * (1 - prob[id]) + cost.second * prob[id];
  if (cost.first > ncost) ret = cost;
  else ret = pdd(ncost, cost.second * (1 - prob[id]));
  return ret;
}


double brute() {
  double ans = 0;
  for (int mask = 0; mask < (1 << n); ++mask) {
    vector<int> v;
    rep(i,n) if ((mask >> i) & 1) v.push_back(i);
    double cost = 0;
    for (int x : v) {
      double probb = 1;
      for (int y : v) if (x != y) {
        probb *= (1 - prob[y]);
      }
      probb *= prob[x];
      cost += probb;
    }
    ans = max(ans, cost);
  }
  //db(ans);
  return ans;
}

int main() {
  //ios_base::sync_with_stdio(false);
  scanf("%d", &n);
  rep(i,n) scanf("%lf", &prob[i]);
  sort(prob, prob + n);
  cl(mark,0);
  //db(solve(0).first);
  //assert(fabs(solve(0).first - brute()) < eps);
  printf("%.12lf\n", solve(0).first);
  return 0;
}
