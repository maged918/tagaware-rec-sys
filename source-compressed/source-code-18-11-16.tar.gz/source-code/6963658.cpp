//Language: GNU C++


//#pragma comment(linker,"/STACK:1024000000,1024000000")
#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <string>
#include <cstdlib>
#include <queue>
#include <stack>
#include <utility>
#include <map>
#include <set>
#include <vector>
#include <algorithm>
typedef long  long LL;

const int N = 100005;
const int M = 1000005;
const int inf = 1 << 28;
const int mod = 1e9 + 7;
const double eps = 1e-8;
using namespace std;
int n , m;
int a[N];
struct Segtree {
    LL sum[N << 2];
    int mx[N << 2];
    void pushup(int rt) {
        sum[rt] = sum[rt << 1] + sum[rt << 1 | 1];
        if (a[mx[rt << 1]] > a[mx[rt << 1 | 1]]) mx[rt] = mx[rt << 1];
        else mx[rt] = mx[rt << 1 | 1];
    }
    void build(int l, int r, int rt) {
        if (l == r) {
            scanf("%d", &a[l]);
            mx[rt] = l, sum[rt] = a[l];
            return ;
        }
        int mid = (l + r) >> 1;
        build(l, mid, rt << 1);
        build(mid + 1, r, rt << 1 | 1);
        pushup(rt);
    }
    void update(int k, int x, int l, int r, int rt) {
        if (l == r) {
            sum[rt] = x;
            return ;
        }
        int mid = (l + r) >> 1;
        if (k <= mid) update(k, x, l, mid, rt << 1);
        else update(k, x, mid + 1, r, rt << 1 | 1);
        pushup(rt);
    }
    int getMax(int L, int R, int l, int r, int rt) {
        if (L <= l && r <= R) return mx[rt];
        int mid = (l + r) >> 1;
        int id = -1;
        if (L <= mid) id = getMax(L, R, l, mid, rt << 1);
        if (R > mid) {
            int nid = getMax(L, R, mid + 1, r, rt << 1 | 1);
            if (id == -1 || a[id] < a[nid]) id = nid;
        }
        return id;
    }
    LL query(int L, int R, int l, int r, int rt) {
        if (L <= l && r <= R) return sum[rt];
        int mid = (l + r) >> 1;
        LL res = 0;
        if (L <= mid) res += query(L, R, l, mid, rt << 1);
        if (R > mid) res += query(L, R, mid + 1, r, rt << 1 | 1);
        return res;
    }
}seg;

int main() {
   // freopen("in", "r", stdin);
    while (cin >> n >> m) {
        seg.build(1, n, 1);
        int type, l, r, k, x;
        while (m --) {
            scanf("%d", &type);
            if (type == 1) {
                scanf("%d%d", &l, &r);
                printf("%I64d\n", seg.query(l, r, 1, n, 1));
            }else if (type == 2) {
                scanf("%d%d%d", &l, &r, &x);
                while (true) {
                    int id = seg.getMax(l, r, 1, n, 1);
                    if (a[id] < x) break;
                    a[id] %= x;
                    seg.update(id, a[id], 1, n, 1);
                }
            }else {
                scanf("%d%d", &k, &x);
                a[k] = x;
                seg.update(k, x, 1, n, 1);
            }
        }
    }
    return 0;
}





























