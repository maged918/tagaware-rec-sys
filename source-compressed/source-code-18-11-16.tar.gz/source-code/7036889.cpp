//Language: GNU C++


//============================================================================
// Name        : .cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
using namespace std;

int main() {
    string x;
    cin>> x;
    long long n = 0;

    while (x.size() != 1 ){

        if (x[x.size() - 1] == '0')
            x.erase(x.size() - 1 , 1 ) ;

        else {
                    bool flag = false ;
            for ( int i = x.size() - 1 ;  i >=0 ;  i--   ){
                if (x[i] == '1')
                    x[i] = '0' ;

                else if (x[i] == '0'){
                    x[i] = '1' ;
                    break;
                }
                if ( i == 0)
                    flag = true ;
            }

            if (flag)
                x.insert(x.begin() , '1') ;
        }
        n++ ;
    }

    cout<<n <<endl;
    return 0;
}