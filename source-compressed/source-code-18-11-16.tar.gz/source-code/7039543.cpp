//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
const int MAXN=100000+100;
int n,d;
ll x;
int a[MAXN],b[MAXN],c[MAXN],pos[MAXN],map[MAXN];
int getNextX()
{
    x=(x*37+10007)%1000000007;
    return x;
}
void initAB()
{
    for(int i=0;i<n;i++)
        a[i]=i+1;
    for(int i=0;i<n;i++)
        swap(a[i],a[getNextX()%(i+1)]);
    for(int i=0;i<n;i++)
        if(i<d)
            b[i]=1;
        else
            b[i]=0;
    for(int i=0;i<n;i++)
        swap(b[i],b[getNextX()%(i+1)]);
    for(int i=0;i<n;i++)
        pos[a[i]]=i;
    for(int i=0;i<n;i++)
        if(b[i])
            map[++map[0]]=i;
}
int main()
{
    //freopen("text1.txt","w",stdout);
    scanf("%d%d%I64d",&n,&d,&x);
    initAB();
    int cnt=0;
    for(int i=n;i>=1 && cnt<=10000000;i--)
        for(int j=1;j<=map[0];j++,cnt++)
            if(pos[i]+map[j]<n)
                c[pos[i]+map[j]]=max(c[pos[i]+map[j]],i);
    for(int i=0;i<n;i++)
        if(!c[i])
            for(int j=1;j<=map[0];j++)
            {
                if(i<map[j])
                    break;
                else
                    c[i]=max(c[i],a[i-map[j]]);
            }
    for(int i=0;i<n;i++)
        printf("%d\n",c[i]);
    return 0;
}
