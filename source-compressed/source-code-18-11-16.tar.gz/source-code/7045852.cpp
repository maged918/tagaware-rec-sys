//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <string.h>
using namespace std;

int n, ans, sum, a[110], b[110], to[110];
bool used[10][10];
char S[10];

int main() {
    scanf("%d", &n);
    for (int i = 1; i <= n; i++) {
        scanf("%s", S);
        if (S[0] == 'R')    a[i] = 1;
        else    if (S[0] == 'G')    a[i] = 2;
        else    if (S[0] == 'B')    a[i] = 3;
        else    if (S[0] == 'Y')    a[i] = 4;
        else    a[i] = 0;
        b[i] = S[1] - '0' - 1;
    }
    ans = 10000;
    for (int i = 0; i < 32; i++)
        for (int j = 0; j < 32; j++) {
            for (int p = 1; p <= n; p++) {
                int x, y;
                if ((1 << a[p]) & i)    x = a[p];
                else    x = 5;
                if ((1 << b[p]) & j)    y = b[p];
                else    y = 5;
                to[p] = x * 6 + y;
            }
            bool ok = true;
            for (int p = 1; p <= n; p++)
                for (int q = 1; q < p; q++)
                    if (to[p] == to[q] && (a[p] != a[q] || b[p] != b[q]))   ok = false;
            if (ok) {
                int tot = 0;
                for (int p = 0; p < 5; p++)
                    if ((1 << p) & i)   tot++;
                for (int p = 0; p < 5; p++)
                    if ((1 << p) & j)   tot++;
                ans = min(ans, tot);
            }
        }
    printf("%d\n", ans);
}