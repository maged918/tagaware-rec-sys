//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <utility>
#include <vector>
using namespace std;

const int maxn = 3005;
bool ok;
int n, x[maxn], fa[maxn], sz[maxn], sum[maxn];
pair<int, pair<int, int> > edge[maxn];

int F(int x)  {
	return x == fa[x] ? x : (fa[x] = F(fa[x]));
}
int main()  {
	scanf("%d", &n);
	for (int i = 1, a, b, c; i < n; i ++)  {
		scanf("%d%d%d", &a, &b, &c);
		edge[i] = make_pair(c, make_pair(a,b));
	}
	int all = 0;
	for (int i = 1; i <= n; i ++)
		scanf("%d", &x[i]), all += x[i];

	sort(edge + 1, edge + n);
	for (int i = 1; i <= n; i ++)
		fa[i] = i, sz[i] = 1, sum[i] = x[i];

	int ans = edge[1].first;
	ok = true;
	for (int i = 1; i + 1 < n; i ++)  {
		int a = edge[i].second.first, b = edge[i].second.second;
		int c = edge[i].first;
		if ((a = F(a)) != (b = F(b)))  {
			fa[a] = b;
			sz[b] += sz[a];
			sum[b] += sum[a];
			if (sz[b] > all - sum[b]) ok = false;
		}
		if (ok) ans = max(ans, edge[i + 1].first);
	}
	printf("%d\n", ans);
	return 0;
}