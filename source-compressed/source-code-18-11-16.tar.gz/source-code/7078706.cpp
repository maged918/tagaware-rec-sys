//Language: GNU C++


#include<stdio.h>
#include<string.h>
__int64 w[500],y[500]; 
int main()
{
    int a,b,i;
    while(~scanf("%d%d",&a,&b))
    {
        memset(y,0,sizeof(y));
        for(i=0;i<b;i++)
        {
            scanf("%d",&w[i]);
        }
        for(i=0;i<b;i++)
        {
            if(y[w[i]%a]==1)
                break;
            else
                y[w[i]%a]=1;
        }
        if(i>=b)
           printf("-1\n");
        else
            printf("%d\n",i+1);

    }
    return 0;
}