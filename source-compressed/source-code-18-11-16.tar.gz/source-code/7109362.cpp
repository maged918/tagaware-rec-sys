//Language: GNU C++


#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <fstream>
#include <numeric>
#include <iomanip>
#include <bitset>
#include <list>
#include <stdexcept>
#include <functional>
#include <utility>
#include <ctime>
using namespace std;

typedef long long LL;
#define rep(it,s) for(__typeof((s).begin()) it=(s).begin();it!=(s).end();it++)

int n, m;
vector<int> e[1010];
vector<pair<int,int> > intv[1010];
int q[1010];
bool vis[1010];

int search(int l, int r, bool doit) {

    if (l<1 || r>1000000 || l>r) return 0;

    int in = 0, fn = 0;
    q[fn++] = 0;
    for (int i=0; i<n; i++) vis[i] = 0;
    vis[0] = 1;

    while (in<fn) {
        int p = q[in++];

        if (p==n-1) break;

        for (int i=0; i<e[p].size(); i++) {
            if (!vis[e[p][i]]) {
                if (!(intv[p][i].first>r || intv[p][i].second<l )) {
                    vis[e[p][i]] = 1;
                    q[fn++] = e[p][i];
                }
            }
        }
    }

    if (!vis[n-1]) return 0;

    in = 0, fn = 0;
    q[fn++] = 0;
    for (int i=0; i<n; i++) vis[i] = 0;
    vis[0] = 1;

    while (in<fn) {
        int p = q[in++];

        if (p==n-1) break;

        for (int i=0; i<e[p].size(); i++) {
            if (!vis[e[p][i]]) {
                if (intv[p][i].first<=l && intv[p][i].second>=r ) {
                    vis[e[p][i]] = 1;
                    q[fn++] = e[p][i];
                }
            }
        }
    }

    if (!doit) {
        if (vis[n-1]) return r - l + 1;
        else return 0;
    }


    if (vis[n-1]) {
        int tmp = r - l + 1;

        int lo = 1;
        int hi = l;

        while (lo<hi) {
            int mi = (lo+hi)>>1;

            int f = search(mi, l, 0);

            if (f==l - mi + 1) {
                hi = mi;
            }
            else lo = mi+1;
        }

        tmp += l - lo;

        lo = r;
        hi = 1000000;

        while (lo<hi) {
            int mi = (lo+hi+1)>>1;

            int f = search(r, mi, 0);

            if (f==mi - r + 1) {
                lo = mi;
            }
            else hi = mi-1;
        }

        tmp += lo - r;

        return tmp;
    }

    int tmp = max(search(l, (l+r)/2, 1), search((l+r)/2 + 1, r, 1));

    return tmp;

}

int main() {

    //freopen("input.txt","r",stdin);
    //freopen("output.txt","w",stdout);

    cin>>n>>m;
    vector<int> v;
    for (int i=0; i<m; i++) {
        int a,b,c,d;
        scanf("%d%d", &a, &b);
        scanf("%d%d", &c, &d);
        a--; b--;
        e[a].push_back(b);
        e[b].push_back(a);
        intv[a].push_back(make_pair(c,d));
        intv[b].push_back(make_pair(c,d));
        v.push_back(c);
    }

    int res = search(1,1000000, 1);

    res = 0;

    for (int i=0; i<v.size(); i++) {
        int l = v[i];
        int lo = l;
        int hi = 1000000;
        while (lo<hi) {
            int mi = (lo+hi+1)>>1;
            int f = search(l, mi, 0);
            if (f==mi - l + 1) {
                lo = mi;
            }
            else {
                hi = mi-1;
            }
        }
        res = max(search(l,lo,0), res);
    }

    if (res==0) cout<<"Nice work, Dima!"<<endl;
    else cout<<res<<endl;

    return 0;
}
