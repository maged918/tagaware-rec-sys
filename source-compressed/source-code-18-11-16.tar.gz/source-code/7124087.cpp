//Language: GNU C++


#include<cstdio>
#include<cstring>
char s[1010];
int w[26];
int main(){
    int k;
    scanf("%s%d",s,&k);
    int i,j,ans=0,m=0;
    for(i=0;i<26;++i){
        scanf("%d",&w[i]);
        if(w[i]>m) m=w[i];
    }
    for(i=0;s[i];++i){
        ans+=(i+1)*w[s[i]-'a'];
    }
    ans+=(i+1+i+k)*k/2*m;
    printf("%d\n",ans);
    return 0;
}
