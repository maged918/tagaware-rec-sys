//Language: MS C++


#include<iostream>
using namespace std;
int main(){
	long long n,m,k;
	cin>>n>>m>>k;
	if(n+m-2<k){
		printf("-1");
		return 0;
	}
	if(n<m)
		swap(n,m);
	if(k<=m-1)
		cout<<max(m/(k+1)*n,n/(k+1)*m);
	else
		if(k<=n-1)
			cout<<n/(k+1)*m;
		else
			cout<<max(m/(k-n+2),n/(k-m+2));
	
}