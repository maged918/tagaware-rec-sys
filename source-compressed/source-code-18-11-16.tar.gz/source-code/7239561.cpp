//Language: GNU C++


#include <cstring>
#include <iostream>

using namespace std;

typedef long long LL;

const LL MOD = 1000000007;

int n,k;
LL C[15][15];
LL f[210][210][10];
int flag[10][10]={
	{1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 },
	{1 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 },
	{1 ,0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 ,0 },
	{1 ,2 ,0 ,1 ,0 ,0 ,0 ,0 ,0 ,0 },
	{1 ,2 ,0 ,0 ,1 ,0 ,0 ,0 ,0 ,0 },
	{1 ,1 ,1 ,0 ,0 ,1 ,0 ,0 ,0 ,0 },
	{1 ,0 ,2 ,0 ,0 ,0 ,1 ,0 ,0 ,0 },
	{1 ,3 ,0 ,2 ,1 ,0 ,0 ,1 ,0 ,0 },
	{1 ,2 ,1 ,1 ,0 ,2 ,0 ,0 ,1 ,0 },
	{1 ,4 ,0 ,4 ,2 ,0 ,0 ,4 ,0 ,1 }
},dt1[10]={12,9,6,6,6,3,0,3,0,0}
 ,dt2[10]={4 ,2,1,1,0,0,0,0,0,0};

int main()
{
	cin >> n >> k;
	
	C[0][0]=1;
	for(int i=1;i<15;i++){
		C[i][0]=1;
		for(int j=1;j<=i;j++)
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%MOD;
	}
	
	f[0][0][0]=1;
	f[0][1][1]=4;f[0][1][2]=4;
	f[0][2][3]=4;f[0][2][4]=2;f[0][2][5]=8;f[0][2][6]=2;
	f[0][3][7]=4;f[0][3][8]=4;
	f[0][4][9]=1;
	
	for(int i=0;i<n;i++)
		for(int j=0;j<10;j++)
			for(int p=0;p<=k;p++) if(f[i][p][j]){
				for(int q=0;q<10;q++) if(flag[j][q]){
					int left1=dt1[q],left2=dt2[q];
					for(int r=0;p+r<=k && r<=left2;r++)
						for(int t=0;p+r+t<=k && t<=left1-2*r;t++)
							(f[i+1][p+r+t][q]+=(f[i][p][j]*C[left2][r])%MOD*C[left1-2*r][t]*flag[j][q])%=MOD;
				}
			}
/*
	for(int j=0;j<3;j++){
		for(int q=0;q<16;q++)
			cout << "f[1][" << k << "][" << j <<"][" << q <<"]=" << f[1][k][j][q] << endl;
	}
*/
	LL ans=0;
	for(int j=0;j<10;j++) (ans+=f[n][k][j])%=MOD;
	for(int i=1;i<=k;i++) (ans*=i)%=MOD;
	cout << ans << endl;
	return 0;
}
