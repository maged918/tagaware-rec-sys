//Language: GNU C++


#include <iostream>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <vector>
#include <list>
using namespace std;
//======================
typedef long long int64;
typedef long long ll;
int64 S;
int64 F[21];
int N;
int64 MOD = 1000000007;
int64 ANS = 0;
int M[21][8];//2 3 5 7 11 13 17 19
int prime[8] = {2, 3, 5, 7, 11, 13, 17, 19};
//======================
int64 comb(int64 m, int64 n){
    if (m < n) {
        return 0;
    }
    //if (m - n < n) n = m - n;
    int64 ans = 1;
    int64 List[30];
    int X[8];
    memcpy(X, M[n], sizeof(X));
    for (int64 i = 0; i < n; i++) {
        List[i] = m - i;
    }
    for (int i = 7; i >= 0; i--) {
        while (X[i]) {
            for (int j = 0; j < n; j++) {
                while (X[i] && !(List[j] % prime[i])) {
                    List[j] /= prime[i];
                    X[i]--;
                }
                if (!X[i]) break;
            }
        }
    }
    for (int i = 0; i < n; i++) {
        int64 t = List[i];
        t %= MOD;
        ans *= t;
        ans %= MOD;
    }
    
    return ans;
}
void calc(){
    int end = 1 << N;
    for (int i = 0; i < end; i++) {
        int64 power = 0, coeff = 1;
        for (int j = 0; j < 20; j++) {
            if ((1 << j) & i) {
                power += F[j] + 1;
                coeff *= -1;
            }
        }
        int64 temp;
        temp = comb((int64)N + S - power - 1, (int64)N - 1) * coeff;
        //cout << (int64)N + S - power - 1 << " " << (int64)N - 1 << " " << temp << endl;
        //cout << i;
        ANS += temp;
        ANS += MOD;
        ANS %= MOD;
    }
}
int main(){
    for (int i = 2; i <= 20; i++) {
        memcpy(M[i], M[i - 1], sizeof(M[0]));
        int t = i;
        for (int j = 0; j < 8; j++) {
            while (!(t % prime[j])) {
                t /= prime[j];
                M[i][j]++;
            }
        }
    }
    
    
    cin >> N >> S;
    for (int i = 0; i < N; i++) {
        cin >> F[i];
    }
    calc();
    cout << ANS;
    return 0;
    
    
    
}
