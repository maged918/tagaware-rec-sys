//Language: GNU C++


#include <bits/stdc++.h>

using namespace std;

int n;
int a[101];

int p[200];
vector<int> pr;
void sieve()
{
     for(int i=2;i<=100;i++)
       {
           if(p[i]) continue;
           pr.push_back(i);

            for(int j=i*i;j<=100;j+=i)
            {
                p[j]=1;

            }
       }
}
int f[101][101];
unsigned fmask[101];
void foo()
{
    fmask[1]=0;
    for(int i=2;i<=100;i++)
    {
        fmask[i]=0;
        for(int j=0;j<pr.size();j++)
        {
            if(i%pr[j]==0)
            {
                f[i][j]=1;
                fmask[i]|=(1<<j);

            }
        }
    }
}
int dp[101][(1<<17)+1];
int masks[101][(1<<17)+1];
int anss[101][(1<<17)+1];
int solve(int idx,unsigned int mask)
{
       if(idx==n) return 0;
       long long  x = INT_MAX;
       int y = -1;
       if(dp[idx][mask]!=-1) return dp[idx][mask];
       unsigned mask3=0;
       for(int i=1;i<=60;i++)
       {
           unsigned mask2 =fmask[i];
    //       for(int j=0;j<16;j++)
      //     {
        //     if(f[i][j]) mask2|=(1<<j);
          // }
           if(!(mask&mask2) && x> abs(a[idx]-i)+ solve(idx+1, mask|mask2))
           {
               x=abs(a[idx]-i)+solve(idx+1,mask|mask2);
               y = i;
               mask3 = mask2;
           }

       }
       anss[idx][mask]=y;
       masks[idx][mask]=mask3;
       dp[idx][mask]=x;
       //cout << "ans " << y <<" "<<mask3<<endl;
       return x;


}
vector<int> best;
void  backtrack(int idx,unsigned int mask)
{
    //cout << idx <<" "<<mask << endl;
    if(idx==n)
    {
         return ;
    }
    int lm = INT_MAX;
    unsigned ans = 0;
    unsigned int maskc = 0;



        lm = dp[idx][mask];
        ans = anss[idx][mask];
        maskc = masks[idx][mask];


    best.push_back(ans);
    backtrack(idx+1,mask|maskc);

}
// (0,0)->(1,mask)
int main()
{

   sieve();
   foo();
    cin>>n;
    for(int i=0;i<n;i++)
    {
          cin>>a[i];
    }
  //  sort(a,a+n);
    memset(dp,-1,sizeof(dp));
    //cout << solve(0,0) << endl;
    solve(0,0);
    backtrack(0,0);
    for(int i=0;i<n;i++)
    {
        cout<<best[i]<<" ";
    }
    return 0;
}
