//Language: GNU C++


#include <iostream>
#include <fstream>
#include <vector>
#define pb push_back
using namespace std ;
typedef long long ll ;
/*PI7*/

vector < vector < int > > e ;
vector < int> path , pr ;
vector <bool> dfs_flag , f , f0 , f1 , df ;
bool err = 0 ;
int n , m , sz = 0 , nch = 0 ;


void dfs0 ( int x ) {
    df [x] = 1 ;
    if ( f [x] ) nch++ ;
    for ( int i = 0 ; i < e [x].size() ;++i) {
            if ( !df [e [x][i]])
            dfs0(e [x][i]) ;
    }
}

void dfs( int x ) {
    sz++ ;
    path.push_back(x) ;
    dfs_flag [x] = 1 ;
    f [x] = ! f [x] ;
    if ( f [x] ) nch++;
    else nch-- ;
    bool prob = 1 ;

    if ( e [x].size() ) {

    for ( int i = 0 ; i < e [x].size() ; ++i ) {
            if ( !dfs_flag [e [x][i]] ) {

            prob = 0 ;
            pr [e [x][i]] = x ;
            dfs (e [x][i]) ;
            }
    }
    }
    if ( prob ) {
            if ( f [x] && pr [x] != -1) {
            path.push_back ( pr [x] ) ;
             f [pr [x]] = ! f [pr [x]] ;
             if ( f [pr [x]]) nch++ ;
             else nch-- ;
             path.push_back (x) ;
             f [x] = ! f[x] ;
             if ( f [x] ) nch++ ;
             else nch-- ;
            }
         //   if ( pr [x] == -1 || pr [pr [x]] == -1 && !nch )
         //      ;
         //  else {
            if ( pr [x] != -1)
            dfs(pr [x]) ;
       //    }

}
}




int main () {
//ifstream cin ( "input.txt" ) ;
//ofstream cout ( "output.txt" ) ;
cin >> n >> m ;
e.resize(n+1) ;
pr.resize(n+1) ;
for ( int i = 0 ; i < m ; ++i ) {
        int a , b ;
        cin >> a >> b ;
        e[a].push_back(b) ;
        e[b].push_back(a) ;
}
 dfs_flag.resize(n+1) ;
 f.push_back(0) ;
 f0.push_back(0) ;
for ( int i = 1 ; i <= n ; ++i ) {
        bool j ;
cin >> j ;
f.push_back(j);
f0.push_back(j) ;
}
f.resize(n+1) ;
f0.resize(n+1);
f1.resize(n+1) ;
/*for ( int i = 1 ; i <= n ; ++i ) {
        if ( !df[i] && f [i] )
        dfs0(i) ;
}*/
//for ( int  i = 1 ; i <=n ; ++i ) {
  //      cout << pr [i] << " " << dfs_flag [i] << " " << f [i] << endl ;
//}
int count_dfs = 0 ;
for ( int i = 1 ; i <= n ; ++i ) {
        if (!dfs_flag[i] && f [i] ) {
                sz = 0 ;
                count_dfs++ ;
                pr [i] = -1 ;
                dfs (i) ;
        }
}
if ( count_dfs > 1 || err ) cout << -1 ;
    else {
        if ( !count_dfs ) cout << 0 ;
            else {
                    int rsize = path.size() ;
              //  cout << path.size() << endl ;
for ( int i = 0 ;i < path.size() ; ++i )
    f1 [path[i]] = ! f1 [path[i]] ;
    for ( int i = path.size()-1; i>=0 ;--i) {
            if ( f1 [path[i]] != f0 [path [i]] ) rsize-- ;
            else
                break ;
    }
    cout << rsize << endl ;
    for ( int i = 0 ; i < rsize ; ++i )
        cout << path [i] << " " ;
        }
    }
return 0  ;
}
