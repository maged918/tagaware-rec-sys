//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <queue>
#include <vector>
#include<iostream>
using namespace std;
typedef __int64 ll;
typedef pair<ll, int> P;
const int N = 100010;
const ll INF = 1ll << 60;

struct Edge{
    int to;
    ll val;
};
struct ee{
    int u, v;
    ll cost;
}e[N];
vector<Edge> G[N];
int par[N];
int rk[N];
int vis[N];
ll d[N];
ll ans;
int n, m;

int find(int x){
    return par[x] == x ? x : par[x] = find(par[x]);
}

bool unite(int x, int y){
    x = find(x);
    y = find(y);
    if(x == y) return false;
    if(rk[x] < rk[y]) par[x] = y;
    else{
        par[y] = x;
        if(rk[x] == rk[y]) rk[x]++;
    }
    return true;
}

void dijkstra(){
    priority_queue<P, vector<P>, greater<P> > que;
    for(int i = 1; i <= n; i++){
        if(vis[i]){
            d[i] = 0;
            que.push(P(0, i));
        }
        else d[i] = INF;
    }

    while(!que.empty()){
        P p = que.top();
        que.pop();
        int tv = p.second;
        if(p.first > d[tv]) continue;
        for(int i = 0; i < G[tv].size(); i++){
            Edge es = G[tv][i];
            if(d[es.to] > d[tv] + es.val){
                d[es.to] = d[tv] + es.val;
                que.push(P(d[es.to], es.to));
                par[es.to] = par[tv];
            }
        }
    }
}

bool cmp(ee x, ee y){
    return x.cost < y.cost;
}

void init(){
    for(int i = 1; i <= n; i++){
        par[i] = i;
        rk[i] = 1;
    }
}

int main(){
    scanf("%d%d",&n, &m);
    for(int i = 0; i < m; i++){
        scanf("%d%d%I64d", &e[i].u, &e[i].v, &e[i].cost);
        G[e[i].u].push_back((Edge){e[i].v, e[i].cost});
        G[e[i].v].push_back((Edge){e[i].u, e[i].cost});
    }
    int k;
    scanf("%d", &k);
    int t;
    for(int i = 0; i < k; i++){
        scanf("%d", &t);
        vis[t] = 1;
        par[t] = t;
        rk[t] = 1;
    }
    dijkstra();
    for(int i = 0; i < m; i++){
        e[i].cost += d[e[i].u] + d[e[i].v];
        e[i].u = par[e[i].u];
        e[i].v = par[e[i].v];
    }
    sort(e, e + m, cmp);
    init();
    for(int i = 0; i < m; i++){
        if(unite(e[i].u, e[i].v))
            ans += e[i].cost;
    }
    printf("%I64d\n", ans + d[1]);
    return 0;
}
/*
6 8
1 3 2
1 4 1
1 5 3
1 6 4
5 3 2
6 4 7
2 5 1
2 6 9
4
4 2 3 1
*/
