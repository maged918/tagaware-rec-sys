//Language: GNU C++


#include <cstdio> 
#include <cstdlib> 
#include <cmath> 
#include <climits> 
#include <cfloat> 
#include <map> 
#include <utility> 
#include <set> 
#include <iostream> 
#include <memory> 
#include <string> 
#include <vector> 
#include <algorithm> 
#include <functional> 
#include <sstream> 
#include <complex> 
#include <stack> 
#include <queue> 
#include <cassert>
using namespace std; 
#define REP(i,b,n) for(int i=b;i<n;i++) 
#define rep(i,n)      REP(i,0,n) 
#define pb push_back  
#define mp make_pair 
#define ALL(C)   (C).begin(),(C).end() 
template<class T> void vp(T &a,int p){rep(i,p)cout << a[i]<<" ";cout << endl;}  
typedef complex<double>P; 
typedef long long ll; 
typedef unsigned long long ull; 
typedef pair<int,int> pii; 
const ll mod = 1000000007;
const int N = 1010;

main(){
  int n;
  while(cin>>n){
#ifdef DEBUG
    time_t et_0 = clock();
#endif
    vector<int> in(n);
    rep(i,n)cin>>in[i];
    sort(ALL(in));
    in.erase(unique(ALL(in)),in.end());
    rep(i,(int)in.size()-1){
      if (in[i]*2 > in[i+1]){cout << "YES" << endl;goto end;}
    }
    cout <<"NO" << endl;
  end:;
#ifdef DEBUG
    time_t et_1 = clock();
    fprintf(stderr, "Execution time = %0.0lf ms\n", (et_1 - et_0) * 1000.0 / CLOCKS_PER_SEC);
#endif

#ifdef DEBUG
    cout <<"end " <<  endl;
#endif
  }
  return false;
}
