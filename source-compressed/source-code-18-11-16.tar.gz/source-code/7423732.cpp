//Language: GNU C++


#include <iostream>

using namespace std;

int main()
{
    string s;
    cin>>s;
    int n,ans=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        char a,b;
        cin>>a>>b;
        int sa=0,sb=0,mi=0;
        for(int j=0;j<s.size();j++)
        {
            if(s[j]==a)
            {
                sa++;
            }else if(s[j]==b)
            {
                sb++;
            }else
            {
                if(sa!=0&&sb!=0)
                    mi=min(sa,sb);
                    sa=0;
                    sb=0;
                    ans+=mi;
                    mi=0;
            }

        }
        if(sa!=0&&sb!=0)
            mi=min(sa,sb);
                sa=0;
                sb=0;
                ans+=mi;
                mi=0;


    }
    cout<<ans<<endl;
    return 0;
}

 		    	 				 					  	  	