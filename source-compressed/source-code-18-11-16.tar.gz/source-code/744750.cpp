//Language: GNU C++


# include <cstdio>
# include <cstdlib>
# include <cstring>
# include <cmath>
# include <ctime>
# include <string>
# include <algorithm>
# include <vector>
# include <stack>
# include <iostream>
# include <queue>
# include <set>
# include <map>

using namespace std;

# define INF 0x3f3f3f3f
# define MAXN 1
# define MOD 100000000
# define mp make_pair
# define pb push_back
# define SORT(v) sort(v.begin(), v.end())
# define pii pair<int,int>
# define vii vector< pii >
# define psi pair<string,int>

typedef long long ll;

int n1, n2, k1, k2;
ll dp[128][128][16][16];

ll solve(int foot, int horse, int footc, int horsec){
	
	if( footc > k1 ) return 0;
	if( horsec > k2 ) return 0;
	if( foot + horse == 0 ) return 1;
	
	if( dp[foot][horse][footc][horsec] != -1 ) return dp[foot][horse][footc][horsec];
	
	ll a = 0, b = 0;
	
	if( foot > 0 ) a = solve(foot-1, horse, footc+1,0);
	if( horse > 0) b = solve(foot, horse-1, 0, horsec+1);
	
	return dp[foot][horse][footc][horsec] = (a + b) % MOD;
}

int main (void){
	scanf("%d%d%d%d", &n1, &n2, &k1, &k2);
	memset(dp, -1, sizeof(dp));
	cout << solve(n1,n2,0,0) << endl;
	return 0;
}
