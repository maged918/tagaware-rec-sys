//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

int main()
{
    string s;
    long long m, n;
    vector<long long> f(26, 0);

    cin >> m >> n;
    cin >> s;

    for (long long i = 0; i < s.size(); i++) {
        long long tmp = (long long)s[i] - 65;
        f[tmp] += 1;
    }

    long long num, product = 0;
    vector<long long> :: iterator it;

    it = max_element(f.begin(), f.end());
    num = *it;

    while (n > 0) {
        if (n < num) {
            product += n * n;
            n = 0;
        } else {
            product += num * num;
            f.erase(it);
            n = n - num;
            it = max_element(f.begin(), f.end());
            num = *it;
        }
    }

    cout << product;

    return 0;
}
