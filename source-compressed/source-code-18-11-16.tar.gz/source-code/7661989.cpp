//Language: GNU C++


#include <stdio.h>
#include <cmath>
#include <string.h>
#include <vector>
#include <algorithm>

#define X real()
#define Y imag()
#define F first
#define S second
#define pb push_back
#define mp make_pair
#define SIZE(x) (int)x.size()
#define FOR(i,a,b) for(int i = a; i < b; i++)
#define ROF(i,a,b) for(int i = a; i > b; i--)
#define REP(i,a) FOR(i,0,a)
#define error(x) cout << #x << " = " << x << endl
#define mull(x) (x) * (x)
#define ALL(x) (x).begin(), (x).end()
#define SORT(x) sort(ALL(x))
#define CLS(x) memset(x,0,sizeof x);
#define REVERSE(x) reverse(ALL(x))
#define UNIQUE(x) SORT(x),(x).resize(unique(ALL(x))-(x).begin())
#define FORALL(i,j) for(typeof((j).begin()) i = (j).begin(); i != (j).end(); i++)
#define cross(a,b,c) ((b.x-a.x)*(c.y-a.y)-(c.x-a.x)*(b.y-a.y))
#define dis(a,b) sqrt(mull(a.x-b.x)+mull(a.y-b.y))
#define INF 1e9
#define EPS 1e-8
#define ll long long
#define left(a) a << 1
#define right(a) (a << 1) + 1

using namespace std;

const int N = 4 * 100004;
int a[N];
int n, k, s, e;
bool flip = 0;


void build (int x, int l, int r) {
	if(l == r)
		a[x] = 1;
	else 
	{
		build(left(x), l, (l+r)/2);
		build(right(x), (l+r)/2 + 1, r);
		a[x] = a[left(x)] + a[right(x)];
	}
}

void update(int n, int l, int r, int ix, int v){
	if(ix < l || ix > r) return;
	if(l == r && l == ix) a[n] += v;
	else{
		int m = (l+r)/2;
		if(ix <= m)
			update(left(n), l, m, ix, v);
		else
			update(right(n), m+1, r, ix, v);

		a[n] = a[left(n)] + a[right(n)];
	}
}

int query(int n, int l, int r, int ql, int qr){
	if(qr<l || ql>r) 
		return 0;
	if(l>=ql && r<=qr)
		return a[n];
	else
	{
		int m = (l+r)/2;
		return query(left(n), l, m, ql, qr) + query(right(n), m+1, r, ql, qr);
	}
}

int ans(int l, int r) {
	if(flip) {
		int nl, nr;
		nl = e-r+s+1; nr = e-l+s+1;
		return query(1, 1, n, nl, nr);
	} else 
		return query(1, 1, n, l, r);
}

void fld_r(int l) { 
	int id = s + 2*l;

	for(int i=s; i<s+l; i++) {
		int val = query(1, 1, n, i+1, i+1);
		update(1, 1, n, i+1, -val);
		update(1, 1, n, id, val); 
		id--;
	}

	s += l;

	flip = 0;
}

void fld_l(int l) {
	int id = e - 2*l + 1;

	for(int i=e; i>e-l; i--) { 
		int val = query(1, 1, n, i, i);
		update(1, 1, n, i, -val);
		update(1, 1, n, id, val); 
		id++;
	}

	e -= l;

	flip = 1;
}

int main() {
	scanf("%d %d", &n, &k);
	s = 0, e = n;

	build(1, 1, n);

	while(k--) {
		int task;
		scanf("%d", &task);

		if(task == 1) {
			int q; scanf("%d", &q);

		
			if(flip) {
				int nq = e - s - q;
				if(nq > (e - s)/2) fld_l(e - nq - s);
				else fld_r(nq);
			} else {
				if(q > (e - s)/2) fld_l(e - q - s);
				else fld_r(q);
			}

		} else {
			int ql,qr;
			scanf("%d %d", &ql, &qr);
			printf("%d\n", ans(ql+s+1, qr+s));
		}
	}
	return 0;
} 

