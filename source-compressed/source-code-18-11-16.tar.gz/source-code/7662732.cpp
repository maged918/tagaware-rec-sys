//Language: GNU C++


#include <iostream>
#include <cstring>
#include <vector>
using namespace std;
long long N,Q,Nodes[100005];//long long
vector <long long> G[100005];
long long Result[100005];
long long Prime[100005][25];
vector <long long> Poz[2000005];
vector <long long> Aux[2000005];
long long Level[100005];
long long Index[2000005];
long long PrimeN[1000005];
bool Use[100005],isPrime[2000005];
void Eratostenes()
{
    long long i,j;
    PrimeN[++PrimeN[0]]=2;
    for(i=3;i<=2000000;i+=2)
    {
        if(isPrime[i]==0)
        {
            PrimeN[++PrimeN[0]]=i;
            for(j=i*i;j<=2000000;j+=2*i)
                isPrime[j]=1;
        }
    }
}
void Read()
{
    long long i;
    cin>>N>>Q;
    for(i=1;i<=N;i++)
        cin>>Nodes[i];
    for(i=1;i<=N-1;i++)
    {
        long long x,y;
        cin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
}
void Descomp(long long x,long long poz,long long aux)
{
    long long i=PrimeN[1],initial=x,step=1;
    while(i*i<=x && x>1)
    {
        if(x%i==0)
        {
            Prime[poz][++Prime[poz][0]]=i;
            Poz[i].push_back(poz);
            Aux[i].push_back(aux);
            Index[i]++;
            while(x%i==0)
                x/=i;
        }
        ++step;
        i=PrimeN[step];
    }
    if(x>1)
    {
        Prime[poz][++Prime[poz][0]]=x;
        Poz[x].push_back(poz);
        Aux[x].push_back(aux);
        Index[x]++;
    }

}
void DFS(long long node)
{
    Use[node]=1;
    Descomp(Nodes[node],node,Level[node]);
    Result[node]=-1;
    for(long long i=0;i<G[node].size();i++)
    {
        long long v=G[node][i];
        if(Use[v]==0)
        {
            Level[v]=Level[node]+1;
            DFS(v);
        }
    }
    long long Max=-1;
    for(long long i=1;i<=Prime[node][0];i++)
    {
        long long prime=Prime[node][i];
        if(Index[prime]>1)
        {
            if(Max<Aux[prime][Index[prime]-2])
            {
                Max=Aux[prime][Index[prime]-2];
                Result[node]=Poz[prime][Index[prime]-2];
            }
        }
        Index[prime]--;
        Poz[prime].pop_back();
        Aux[prime].pop_back();
    }
    Prime[node][0]=0;
}
void Browse()
{
    long long i;
    DFS(1);
    memset(Use,0,sizeof(Use));
    for(i=1;i<=Q;i++)
    {
        long long type,x,y;
        cin>>type>>x;
        if(type==1)
        {
            cout<<Result[x]<<"\n";
        }
        else
        {
            cin>>y;
            Nodes[x]=y;
            DFS(1);
            memset(Use,0,sizeof(Use));
        }
    }
}
int main()
{
    Eratostenes();
    Read();
    Browse();
    return 0;
}
