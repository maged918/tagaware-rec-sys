//Language: GNU C++


#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define fi "b.inp"
#define fo "b.out"
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;

int n,ketqua;
int a[1010];

void input();
void solve();
void output();

void input()
{
     int i;
     scanf("%d",&n);
     for(i=0;i<n;i++)
                     scanf("%d",&a[i]);
}

void solve()
{
     int i;
     bool zoomin, zoomout;
     
     ketqua=0;
     i=0;
     zoomin=true;
     zoomout=true;
     
     while(i<n)
     {
         while(i<n && a[i]==0)
         {
                   i++;
         }
         
         zoomin = false;
         
         while(i<n && a[i]==1)
         {
                       if(zoomin == false)
                       {         
                                 zoomin=true;
                       }
                       
                       if(zoomout == false)
                       {
                                  ketqua++;
                                  zoomout=true;
                       }
                       ketqua++;
                       i++;
         }
         
         zoomout = false;
     }
}

void output()
{
     printf("%d\n",ketqua);
}

int main() {
	
	//freopen(fi,"r",stdin);
	//freopen(fo,"w",stdout);
	
	input();
	
	solve();
	
	output();
	
	return 0;
}
