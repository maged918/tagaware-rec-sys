//Language: MS C++


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

#define in_str(b) scanf("%s",(b))
#define in_int1(a) scanf("%d",&(a))
#define in_int2(a,b) scanf("%d%d",&(a),&(b))
#define in_int3(a,b,c) scanf("%d%d%d",&(a),&(b),&(c))
#define in_int4(a,b,c,d) scanf("%d%d%d%d",&(a),&(b),&(c),&(d))
#define mp(a,b) make_pair(a,b)
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;

int p[6][3] = {
		{ 0, 1, 2 },
		{ 0, 2, 1 },
		{ 1, 0, 2 },
		{ 1, 2, 0 },
		{ 2, 0, 1 },
		{ 2, 1, 0 } };

int o[8][3];
int c[8][3];

long long dist(int a, int b)
{
	long long x = c[a][0] - c[b][0];
	long long y = c[a][1] - c[b][1];
	long long z = c[a][2] - c[b][2];
	return x*x + y*y + z*z;
}

bool check()
{
	long long mas[8][8];
	int i, j;

	for (i = 0; i < 8; i++)
	{
		mas[i][i] = 0;
		for (j = i + 1; j < 8;j++)
			mas[i][j] = mas[j][i] = dist(i, j);
	}

	for (i = 0; i < 8; i++)
	{
		sort(mas[i], mas[i] + 8);
		if (i == 0)
		{
			if (!mas[i][1]) return false;
			for (j = 2; j < 4 && mas[i][j] == mas[i][1]; j++);
			if (j < 4) return false;
			for (j = 5; j < 7 && mas[i][j] == mas[i][4]; j++);
			if (j < 7) return false;
			if (mas[i][1] + mas[i][1] != mas[i][4]) return false;
			if (mas[i][1] + mas[i][4] != mas[i][7]) return false;
		}
		else
		{
			for (j = 1; j < 8 && mas[i][j] == mas[0][j]; j++);
			if (j < 8) return false;
		}
	}

	return true;
}

bool doit(int deep)
{
	if (deep == 8)
	{
		return check();
	}

	for (int i = 0; i < 6; i++)
	{
		c[deep][0] = o[deep][p[i][0]];
		c[deep][1] = o[deep][p[i][1]];
		c[deep][2] = o[deep][p[i][2]];
		if (doit(deep + 1)) return true;
	}

	return false;
}

void Solve()
{
	int i, j, k, n, m;

	for (i = 0; i < 8; i++)
	{
		in_int3(o[i][0], o[i][1], o[i][2]);
	}

	if (doit(0))
	{
		printf("YES\n");
		for (i = 0; i < 8; i++) printf("%d %d %d\n", c[i][0], c[i][1], c[i][2]);
	}
	else
	{
		printf("NO");
	}
}

int main()
{
#ifdef __LOCAL_RUN__
	#define _MAX_BUF_SIZE 32
	int _i = 0;
	char *_buf = new char[_MAX_BUF_SIZE];

	FILE *res_output = freopen("output.txt", "wt", stdout);
	while (true)
	{
		string _suffix = string(itoa(_i, _buf, 10)) + string(".txt");
		FILE *res_input = freopen((string("input-") + _suffix).c_str(), "rt", stdin);
		if (!res_input)
		{
			// the end
			break;
		}
		if (_i) printf("\n\n");
		printf("==== Case #%d =====\n", _i);
		Solve();
		_i++;
	}
#else
	Solve();
#endif
	return 0;
}