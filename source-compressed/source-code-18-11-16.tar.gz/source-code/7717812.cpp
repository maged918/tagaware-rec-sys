//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <utility>
#include <algorithm>
#include <vector>
#include <climits>
#include <map>
#include <queue>
#include <stack>
#include <set>

using namespace std;

#ifndef ONLINE_JUDGE
#  define LOG(x) (cerr << #x << " = " << (x) << endl)
#else
#  define LOG(x) 0
#endif

char ans[1001];
string s;
int n, p;

bool isPossible(int index, bool changed) {
    if (index == n) {
        return changed;
    }
    int start = changed ? 0 : s[index] - 'a';
    for (int i = start; i < p; ++i) {
        ans[index] = i + 'a';
        if (index >= 1 && ans[index] == ans[index - 1]) {
            continue;
        }
        if (index >= 2 && ans[index] == ans[index - 2]) {
            continue;
        }
        if (isPossible(index + 1, changed || (i > start))) {
            return true;
        }
    }
    return false;
}

int main() {
    cin >> n >> p >> s;
    if (isPossible(0, 0)) {
        ans[n] = '\0';
        cout << ans << endl;
        return 0;
    }
    cout << "NO" << endl;
    return 0;
}