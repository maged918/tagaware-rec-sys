//Language: GNU C++


#include <iostream>
#include <cmath>
using namespace std;
int main(){
    long long int n,joy=0;
    cin>>n;
    long long int v[n],t[n];
    long long int i;
    for(i=0;i<n;i++)
        cin>>v[i];
    for(i=0;i<n;i++)
        cin>>t[i];
    for(i=0;i<n;i++){
        //cout<<"i= "<<i<<endl;
        if((v[i]*2)<t[i] || t[i]==1){
            joy--;
            //cout<<"joy= "<<joy<<endl;
        }
        else if( t[i]%2!=0 ){
            joy+=floor(t[i]/2)*(floor(t[i]/2)+1);
            //cout<<floor(t[i]/2)*(floor(t[i]/2)+1)<<endl;
        }
        else{
            joy+=(t[i]/2)*(t[i]/2);
            //cout<<(t[i]/2)*(t[i]/2)<<endl;
        }
    }
    cout<<joy;
    //cin>>n;
    return 0;
}