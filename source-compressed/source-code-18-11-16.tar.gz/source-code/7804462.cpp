//Language: GNU C++


#include <bits/stdc++.h>

#define LL long long
#define MX 100009
#define clr(aa, bb) memset(aa, bb, sizeof aa)
#define MD 1000000007
#define check_bit(a,b) (a & (1<<b))
#define set_bit(a,b) (a | (1<<b))
#define PB push_back
#define FOR(aa,nn) for(aa=0; aa<nn; aa++)
#define vi vector<int>
#define vll vector<long long>
#define mp make_pair
#define pi pair<int, int>
#define MAXN 100001

using namespace std;

LL arr[MAXN];
vector<int>V[1000001];
int dp[4001][4001];
int n;
int solve(int pre, int cur)
{
    if(pre >= n || cur >= n) return 0;
    int &ret = dp[pre][cur];
    if(ret != -1) return ret;
    ret = 0;
    int next = upper_bound(V[arr[pre]].begin(), V[arr[pre]].end(), cur) - V[arr[pre]].begin();
    next = V[arr[pre]][next];
    if(next < n)
        ret = max(ret, 1 + solve(cur, next));
return ret;
}



int main()
{

    int i, j, k;
    LL x, y;
    cin>>n;
    int num;
    for(i = 0; i < n; i++){
        cin>>arr[i];
        V[arr[i]].PB(i);
    }
    if(n == 1)
    {
        cout<<1<<endl;
        return 0;
    }
    for(i = 0; i <= 1000000; i++)
        V[i].PB(n + 1);

    int res = 0;
    clr(dp, -1);
    for(i = 0; i < n; i++)
    {
        for(j = i + 1; j < n; j++)
            res = max(res, 2 + solve(i, j));
    }
    cout<<res<<endl;








    return 0;
}

/*




*/

	  	 	 	 		 	 	 	    	  							