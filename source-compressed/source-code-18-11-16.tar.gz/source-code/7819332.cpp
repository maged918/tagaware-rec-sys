//Language: GNU C++


#include <iostream>
#include <vector>
#include <string>


using namespace std;



int main()
{
    
    
    string s;
    cin >> s;
    long long h = 0, m = 0;
    long long ans = 0;
    
   if (s.length() < 5){
      cout<<0;
      return 0;
   }
    for (int i = 0; i < s.length()-4; i++){
        string k = s.substr(i, 5);
        if (k == "heavy"){
            h += 1;
           
            }
        else if (k == "metal"){
            m += 1;
            ans += h;
              
        }
       
    }
    cout << ans;
    
    return 0;
}