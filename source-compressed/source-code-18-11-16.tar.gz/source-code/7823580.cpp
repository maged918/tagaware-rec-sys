//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

typedef pair<int, int> PI;

const int N = 1005;
const int U = 700;
const int S = 305;
const int L = 1e6 + 5;
const int dx[4] = {0, 1, 0, -1};
const int dy[4] = {1, 0, -1, 0};
const int ch[4] = {'U','R','D','L'};

int block[N][N], last[N][N];

PI q[N*N];
void go(int x, int y, int S, int T, int *path)
{
	for(int i=0; i<N; i++) for(int j=0; j<N; j++) last[i][j]=-1; last[x][y]=4;
	int head=0, tail=0; q[0] = PI(x,y);
	
	for(; head<=tail && last[S][T]<0; ++head)
	{
		int nx = q[head].first, ny = q[head].second;
		for(int i=0; i<4; i++)
		{
			int xx = nx + dx[i], yy = ny + dy[i];
			if(xx<0 || yy<0 || xx>=N || yy>=N) continue;
			if(block[xx][yy] || last[xx][yy]>=0) continue;
			last[xx][yy] = i, q[++tail] = PI(xx, yy);
		}
	}
	
	if(last[S][T]<0) {path[0]=-1; return;}
	
	path[0] = 0;
	for(int tp; !(S==x&&T==y); )
	{
		path[++path[0]] = tp = last[S][T];
		S -= dx[tp], T -= dy[tp];
	}
	for(int i=1; i+i<=path[0]; i++) swap(path[i], path[path[0]-i+1]);
}

void sgo(int &x, int &y, int *path, int *spath)
{
	spath[0] = 0;
	for(int i=1; i<=path[0]; i++)
	{
		int xx = x + dx[path[i]], yy = y + dy[path[i]];
		if(xx>0 && yy>0 && xx<N && yy<N && block[xx][yy]) ;
		else x = xx, y = yy, spath[++spath[0]] = path[i];
	}
}

int sx, sy, tx, ty, K;
int blx[N], bly[N];
int sp[L], spl[L], ans[L];

void ad(int x){ ans[++ans[0]]=x; }

void outgo()
{
	ans[0] = 0;
	for(int i=1; i<=sp[0]; i++) ans[++ans[0]] = sp[i];
	sx = U-1, sy = U-1, sgo(tx, ty, sp, spl);
	go(tx, ty, U-1, U-1, sp);
	for(int i=1; i<=sp[0]; i++) ans[++ans[0]] = sp[i];
	tx = U-1, ty = U-1, sgo(sx, sy, sp, spl);
	
	// already out
	#define rep(x) for(int i=0; i<x; i++)
	if(sx<=tx && sy<=ty)
	{
		int bx(N), by(N);
		for(int i=1; i<=K; i++) if(bly[i]<by || (bly[i]==by && blx[i]<bx)) bx=blx[i], by=bly[i];
		rep(ty-by+1) ad(2); rep(tx-bx) ad(3); rep(ty-sy) ad(0);
		ad(3), ad(0); rep(tx-sx) ad(1);
	}
	else if(sx<=tx && sy>ty)
	{
		int bx(N), by(0);
		for(int i=1; i<=K; i++) if(bly[i]>by || (bly[i]==by && blx[i]<bx)) bx=blx[i], by=bly[i];
		rep(tx-bx) ad(3); rep(sy-by-1) ad(2);
		ad(3), ad(2); rep(tx-sx) ad(1);
	}
	else if(sx>tx && sy<=ty)
	{
		int bx(0), by(N);
		for(int i=1; i<=K; i++) if(bly[i]<by || (bly[i]==by && blx[i]>bx)) bx=blx[i], by=bly[i];
		rep(ty-by+1) ad(2); rep(tx-bx) ad(3); rep(ty-sy) ad(0);
		ad(1), ad(0); rep(sx-tx) ad(3);
	}
	else
	{
		int bx(0), by(0);
		for(int i=1; i<=K; i++) if(bly[i]>by || (bly[i]==by && blx[i]>bx)) bx=blx[i], by=bly[i];
		rep(tx-bx) ad(3); rep(sy-by-1) ad(2);
		ad(1), ad(2); rep(sx-tx) ad(3);
	}
}

void chasing()
{
	ans[0] = 0, go(sx, sy, tx, ty, sp);
	for(;!(sx==tx && sy==ty);)
	{
		for(int i=1; i<=sp[0]; i++) ans[++ans[0]] = sp[i];
		sx = tx, sy = ty, sgo(tx, ty, sp, spl);
		for(int i=0; i<=spl[0]; i++) sp[i] = spl[i];
	}
}

int main()
{
	while(scanf("%d%d%d%d%d", &sx, &sy, &tx, &ty, &K)>0)
	{
		sx += S, sy += S, tx += S, ty += S;
		memset(block, 0, sizeof(int) * N * N);
		for(int i=1, x, y; i<=K; i++) scanf("%d%d", &x, &y), block[x+S][y+S] = 1, blx[i]=x+S, bly[i]=y+S;
		
		if(!K || (go(sx, sy, tx, ty, sp), sp[0]<0)) {puts("-1"); continue;}
		if((go(sx, sy, U-1, U-1, sp), sp[0]<0)) chasing(); else outgo();
		for(int i=1; i<=ans[0]; i++) printf("%c", ch[ans[i]]); puts("");
	}
	return 0;
}
