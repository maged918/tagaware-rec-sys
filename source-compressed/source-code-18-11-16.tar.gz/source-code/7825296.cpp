//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<vector>
#include<string>
#include<cmath>
#define LL long long
using namespace std;
vector<int> C[100010];
int x,y,n,K,f[2][100010],A,inf=1e9;
void read(int &x)
{
	char ch=getchar();int mark=1;for(;ch!='-'&&(ch<'0'||ch>'9');ch=getchar());if (ch=='-') mark=-1,ch=getchar();
	for(x=0;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-48;x*=mark;
}
int Cnt(int x,int y)
{
	return upper_bound(C[x].begin(),C[x].end(),y)-C[x].begin();
}
int main()
{
	//freopen("a.in","r",stdin);
	read(n);read(K);
	for(int i=1;i<=K;i++)
	{
		read(x);read(y);C[y].push_back(x);
	}
	for(int i=1;i<=n;i++) sort(C[i].begin(),C[i].end());
	int T=sqrt(6*K);
	for(int i=1;i<=n;i++)
	{
		A^=1;
		for(int j=0;j<=i&&j<=T;j++) f[A][j]=inf;
		for(int k=0;k<=i&&k<=T;k++) 
			f[A][0]=min(f[A][0],((k)?f[A^1][k-1]+2:f[A^1][0])+(k+1)*k/2+3*Cnt(n-i+1,n-k));
		for(int j=1;j<=i&&j<=T;j++) f[A][j]=min(f[A][j-1],f[A^1][j-1]+3*Cnt(n-i+1,n-j));
	}
	printf("%d\n",f[A][0]);
	return 0;
}
