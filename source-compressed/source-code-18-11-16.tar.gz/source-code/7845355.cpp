//Language: MS C++


#include <stdio.h>
#include <vector>
#include <algorithm>
#include <iostream>
#include <cstring>

using namespace std;

long long pow10(int st)
{
    long long res = 1;
    int st1 = st;
    long long x = 10;

    while (st1 > 0)
    {
        if (st1 & 1)
            res = (res * x) % 1000000007;
        x = (x * x) % 1000000007;
        st1 /= 2;
    }
    return res;
}

int main()
{
    static char s[100005], temp[100005];
    static char *z[100005];
    static int lengths[100005];
    int n;

    cin >> s >> n;
    for (int i=0; i<n; ++i)
    {
        cin >> temp;
        lengths[i] = strlen(temp);
        z[i] = (char*)malloc(lengths[i]+1);
        strcpy(z[i], temp);
    }

    long long zifra[10] = {0,1,2,3,4,5,6,7,8,9};
    long long zifraLen[10] = {1,1,1,1,1,1,1,1,1,1};

    for (int i = n-1; i>=0; --i)
    {
        long long newZ = 0;
        long long newLen = 0;
        for (int j = 0; j < lengths[i]-3; ++j)
        {
            int currZifra = z[i][lengths[i]-1-j] - '0';
            newZ = (newZ + zifra[currZifra] * pow10(newLen)) % 1000000007;
            newLen = (newLen + zifraLen[currZifra]) % 1000000006;
        }
        zifra[z[i][0] - '0'] = newZ;
        zifraLen[z[i][0]-'0'] = newLen;
    }

    long long ans = 0;
    long long currLen = 0;

    for (int i = 0; s[i]; ++i)
    {
        ans = (ans * pow10(zifraLen[s[i]-'0']) + zifra[s[i]-'0']) % 1000000007;
    }

    printf("%I64d", ans);

    return 0;
}