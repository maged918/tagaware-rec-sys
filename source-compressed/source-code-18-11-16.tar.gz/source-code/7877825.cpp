//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
#include <map>
#include <cstring>
#include <vector>

using namespace std;
int s[1000];
int main()
{
    int n;
    scanf("%d",&n);
    memset(s,0,sizeof(s));
    int p;
    scanf("%d",&p);
    for(int i=1;i<=p;i++)
    {
        int a;
        scanf("%d",&a);
        s[a]=1;
    }
    scanf("%d",&p);
    for(int i=1;i<=p;i++)
    {
        int a;
        scanf("%d",&a);
        s[a]=1;
    }
    for(int i=1;i<=n;i++)
    {
        if(s[i]==0)
        {
            printf("Oh, my keyboard!\n");
            return 0;
        }
    }
    printf("I become the guy.\n");
    return 0;
}
