//Language: GNU C++


#include <iostream> 
#include <queue> 
#include <vector> 
#include <string> 
#include <set> 
#include <algorithm> 
using namespace std; 

typedef unsigned int ui; 
#define REP(f,g) for(int f = 0; f < g; f++)
#define bc(x) __builtin_popcount(x)
vector<vector<set<int> > > setgrid; 
vector<string> grid; 

int k;
int ro[4] = { 1, -1,  0,  0};
int co[4] = { 0,  0, -1,  1};

struct s
{
    s() : r(-1), c(-1), set(-1), path(""), let('A'), d(0) {}
    s(int nr, int nc, ui nset, string npath, char nlet, int nd)
        : r(nr), c(nc), set(nset), path(npath), let(nlet), d(nd) {}

    int r, c, d;
    ui set;
    string path; 
    char let; 
};
bool operator<(const s &lhs, const s&rhs)
{
    if(lhs.d == rhs.d)
        if(lhs.path == rhs.path)
            return lhs.let >= rhs.let; 
        else
            return lhs.path >= rhs.path;
    else
        return lhs.d >= rhs.d; 
}

bool visited(int r, int c, ui set)
{
    ui subset = set; 
    do
    {
        subset = (subset - 1) & set;
            if(setgrid[r][c].find(subset) != setgrid[r][c].end())
            {
                //cout << r << ',' << c << ':' << grid[r][c] << '\n';
                return true; 
            }
    } while (subset != set);
    return false; 
}

int main(void) 
{
    s qf; 
    int rs, cs, nr, nc; 
    ui nset, one = 0x00000001;
    priority_queue<s> q; 
    vector<s> pv,tv; 

    cin >> rs >> cs >> k;
    grid.resize(rs); 
    REP(i,rs)
        cin >> grid[i]; 
    setgrid.resize(rs); 
    REP(i, rs)
        setgrid[i].resize(cs); 
    
    int sr, sc;
    REP(i, rs)
        REP(j, cs) 
            if(grid[i][j] == 'S') {sr = i; sc = j; break;}

    q.push(s(sr, sc, 0, "", 'a', 0));
    setgrid[sr][sc].insert(0);
    while(!q.empty())
    {
        pv.clear(); 
        //tv.clear();
        qf = q.top(); 
        //cout << qf.let << ' ' << qf.d << '\n';
        //while(!q.empty() && (q.front().d == qf.d))
        //{
        //    tv.push_back(q.front());
        //    q.pop();
        //}    
        //sort(tv.begin(), tv.end());
        //REP(j,tv.size())
       //     qf = tv[j];
       REP(i, 4)
       {
           nr = qf.r + ro[i]; 
           nc = qf.c + co[i];
           if(nr < 0 || nr >= rs || nc < 0 || nc >= cs)
               continue; 
           if(grid[nr][nc] == 'T')
               goto success; 
           nset = qf.set | (one << int(grid[nr][nc] - 'a')); 
           if((bc(nset) > k) || visited(nr, nc, nset))
               continue; 
           pv.push_back(s(nr, nc, nset, qf.path + grid[nr][nc], grid[nr][nc], qf.d+1));
           setgrid[nr][nc].insert(nset);
       }
       sort(pv.begin(), pv.end());
       REP(i, pv.size())
           q.push(pv[i]);
       q.pop();
    }
    cout << -1 << '\n';
    return 0;
success: 
    if(qf.path != "")
        cout << qf.path << '\n';
    return 0;
}
