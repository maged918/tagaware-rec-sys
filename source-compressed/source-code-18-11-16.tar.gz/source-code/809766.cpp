//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>

using namespace std;

#define pb push_back
#define mp make_pair

#define ALL(x) (x).begin(),(x).end()
#define CLR(a,b) memset(a,b,sizeof(a))
#define REPN(x,a,b) for (int x=a; x<b;++x)
#define REP(x,b) REPN(x, 0, b)

#define dbg(x) cout << #x << " = " << x << endl;
#define dbg2(x, y) cout << #x << " = " << x << "  " << #y << " = " << y << endl;
#define dbg3(x, y, z) cout << #x << " = " << x << "  " << #y << " = " << y << "  " << #z << " = " << z << endl;
#define dbg4(x, y, z, w) cout << #x << " = " << x << "  " << #y << " = " << y << "  " << #z << " = " << z << "  " << #w << " = " << w <<  endl;

typedef long long LL;

int main() {
	int n, k;
	char word[100010];
	scanf("%d %d", &n, &k);
	scanf("%s", word);
	if (k != 0)
	REP(i, n) {
		if (i <= n - 3 && word[i] == '4' && i % 2 == 0) {
			if (word[i + 1] == '7' && word[i + 2] == '7') {
				if (k % 2 == 1) {
					word[i + 1] = '4';
				}
				k = 0;
			}
			else if (word[i + 1] == '4' && word[i + 2] == '7') {
				if (k % 2 == 1) {
					word[i + 1] = '7';
				}
				k = 0;
			}
			else if (word[i + 1] == '7') {
				word[i + 1] = '4';
				k--;
			}
		}
		else {
			if (i <= n - 2 && word[i] == '4' && word[i+1] == '7') {
				if (i%2 == 0) word[i + 1] = '4';
				else word[i] = '7';
				k--;
			}
		}
		if (k == 0) break;
	}

	printf("%s\n", word);
	return 0;
}