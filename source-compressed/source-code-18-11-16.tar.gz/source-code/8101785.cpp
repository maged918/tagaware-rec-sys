//Language: GNU C++0x


#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#include<ctime>
#include<iostream>
#include<cmath>
#include<vector>
#include<stack>
#include<map>
#define int64 long long
#define mk make_pair
#define pb push_back
#define sqr(x) (x)*(x)
#define rep(i,x,y) for(int i=x;i<=y;++i)
#define VI vector<int>
#define VS vector<string>
#define PII pair<int,int>
#define VPII vector< PII >
#define N 102100
#define S 1000
#define B 102
using namespace std;
const double pi=acos(-1);
stack<int> label[N/S];
map<int,int> CNT,Hash[B];
int n,col[N],h[N],L[B],R[B],cntl[B][S],cntr[B][S],cnts[B][N],be[N],nn,num[B],m,type;
int calc(int x){
	int res=cntl[be[x]][h[x]];
	rep(i,L[be[x]],x-1)if(col[i]==col[x])res++;
	return res;
}
int main(){
	scanf("%d",&n);
	rep(i,1,n)scanf("%d",&col[i]);
	nn=n/S+1;
	rep(i,1,nn){
		L[i]=(i-1)*S+1;
		R[i]=min(n,i*S);
		rep(j,L[i],R[i]){
			be[j]=i;
			if(!Hash[i].count(col[j])){
				Hash[i][col[j]]=++num[i];
				cntr[i][num[i]]=(cntl[i][num[i]]=CNT[col[j]]+1)-1;
			}
			h[j]=Hash[i][col[j]];
			cnts[i][++cntr[i][h[j]]]++;
			CNT[col[j]]++;
		}
		rep(j,num[i]+1,S)label[i].push(j);
	}
	scanf("%d",&m);
	rep(i,1,m){
		int x,y;
		scanf("%d%d%d",&type,&x,&y);
		if(type==1){
			int p=be[y];
			//del
			cnts[p][cntr[p][h[y]]--]--;
			if(cntl[p][h[y]]>cntr[p][h[y]]){
				Hash[p].erase(col[y]);
				label[p].push(h[y]);
			}
			rep(j,p+1,nn)if(Hash[j].count(col[y])){
				int v=Hash[j][col[y]];
				cnts[j][cntr[j][v]--]--;
				cnts[j][--cntl[j][v]]++;
			}
			//add
			col[y]=x;
			if(!Hash[p].count(x)){
				int tmp=label[p].top();
				Hash[p][x]=tmp;
				label[p].pop();
				int v=0;
				for(int j=p-1;j>=1;--j)if(Hash[j].count(x)){
					v=cntr[j][Hash[j][x]];
					break;
				}
				cntr[p][tmp]=((cntl[p][tmp]=v+1)-1);
			}
			h[y]=Hash[p][x];
			cnts[p][++cntr[p][h[y]]]++;
			rep(j,p+1,nn)if(Hash[j].count(col[y])){
				int v=Hash[j][col[y]];
				cnts[j][cntl[j][v]++]--;
				cnts[j][++cntr[j][v]]++;
			}
		}else{
			if(x==1)printf("%d\n",col[y]);
			else if(x%2==0)printf("%d\n",calc(y));
			else{
				x=calc(y);
				int ans=1,p=be[y];
				rep(j,1,p-1)ans+=cnts[j][x];
				rep(j,L[p],y-1)if((cntl[p][h[j]]++)==x)ans++;
				rep(j,L[p],y-1)cntl[p][h[j]]--;
				printf("%d\n",ans);
			}
		}
	}
}
