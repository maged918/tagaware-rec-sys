//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <string>
using namespace std;
typedef long long LL;
const int Maxn=100005,mod=1000000007,Maxk=6;
int n,m,pref[Maxn][Maxk];
int C[Maxk][Maxk];

inline int get() {
    char ch;
    while (!isdigit(ch=getchar()));
    int v=ch-48;
    while (isdigit(ch=getchar())) v=v*10+ch-48;
    return v;
}

struct node{
    int l,r,mid,cov,s[Maxk];
    node *lc,*rc;
    void update() {
        for (int i=0;i<Maxk;i++)
            if ((s[i]=lc->s[i]+rc->s[i])>=mod)
                s[i]-=mod;
    }
    void cover(int x) {
        cov=x;
        for (int j=0;j<Maxk;j++)
            s[j]=(pref[r][j]-pref[l-1][j]+mod)*LL(x)%mod;
    }
    void push_down() {
        if (cov!=-1) {
            lc->cover(cov);
            rc->cover(cov);
            cov=-1;
        }
    }
}po[Maxn*2],*pn=po;

class Segment_Tree{
    node *root;
    int sum[Maxk];
    void build(node *&x,int l,int r) {
        (x=++pn)->cov=-1;
        x->l=l; x->r=r;
        x->mid=(l+r)>>1;
        if (l==r) {
            x->s[0]=get();
            for (int i=1;i<Maxk;i++)
                x->s[i]=x->s[i-1]*LL(l)%mod;
            return;
        }
        int mid=(l+r)>>1;
        build(x->lc,l,mid);
        build(x->rc,mid+1,r);
        x->update();
    }
    void modify(node *x,int s,int t,int v) {
        if (s<=x->l&&t>=x->r) x->cover(v);
        else {
            x->push_down();
            if (s<=x->mid) modify(x->lc,s,t,v);
            if (t>x->mid) modify(x->rc,s,t,v);
            x->update();
        }
    }
    void qry(node *x,int s,int t,int k) {
        if (s<=x->l&&t>=x->r) {
            for (int i=0;i<=k;i++)
                if ((sum[i]+=x->s[i])>=mod) sum[i]-=mod;
            return;
        }
        if (x->cov!=-1) {
            s=max(s,x->l);
            t=min(t,x->r);
            for (int i=0;i<=k;i++)
                sum[i]=(sum[i]+(pref[t][i]-pref[s-1][i]+mod)*LL(x->cov))%mod;
            return;
        }
        if (s<=x->mid) qry(x->lc,s,t,k);
        if (t>x->mid) qry(x->rc,s,t,k);
    }
    public:
        void build() {
            build(root,1,n);
        }
        void modify(int s,int t,int v) {
            modify(root,s,t,v);
        }
        int qry(int s,int t,int k) {
            for (int i=0;i<=k;i++) sum[i]=0;
            qry(root,s,t,k);
            int res=0;
            for (int i=0,g=1;i<=k;i++,g=LL(g)*(1-s)%mod)
                res=(res+sum[k-i]*LL(C[k][i])%mod*g%mod)%mod;
            return res<0?res+mod:res;
        }
}tr;

int main() {
    n=get(); m=get();
    for (int i=1;i<=n;i++) {
        pref[i][0]=1;
        for (int j=1;j<Maxk;j++) pref[i][j]=pref[i][j-1]*LL(i)%mod;
        for (int j=0;j<Maxk;j++)
            if ((pref[i][j]+=pref[i-1][j])>=mod) pref[i][j]-=mod;
    }
    tr.build();
    C[0][0]=1;
    for (int i=1;i<Maxk;i++) {
        C[i][0]=1;
        for (int j=1;j<Maxk;j++)
            C[i][j]=(C[i-1][j]+C[i-1][j-1])%mod;
    }
    for (int i=1;i<=m;i++) {
        char opx=getchar();
        while (opx!='='&&opx!='?') opx=getchar();
        int l=get(),r=get(),k=get();
        if (opx=='=') tr.modify(l,r,k);
        else printf("%d\n",tr.qry(l,r,k));
    }
    return 0;
}
