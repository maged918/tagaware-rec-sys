//Language: GNU C++


// Authored by dolphinigle
// CodeForces 92
// 3 November 2011

#include <vector>
#include <list>
#include <map>
#include <set>

#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <assert.h>

#define FORN(X,Y) for (int (X) = 0;(X) < (Y);++(X))
#define DEBUG(x) cout << '>' << #x << ':' << x << '\n';

#define REP(X,Y,Z) for (int (X) = (Y);(X) < (Z);++(X))
#define RESET(Z,Y) memset(Z,Y,sizeof(Z))

#define SZ(Z) ((int)Z.size())
#define ALL(W) W.begin(), W.end()
#define PB push_back

#define MP make_pair
#define A first
#define B second

#define INF 1023123123
#define EPS 1e-11

#define MX(Z,Y) Z = max((Z),(Y))
#define MN(X,Y) X = min((X),(Y))

#define FORIT(X,Y) for(typeof((Y).begin()) X = (Y).begin();X!=(Y).end();X++)

using namespace std;

typedef long long ll;
typedef double db;
typedef vector<int> vint;
typedef vector<ll> vll;

class SuffixTreeNode;

class SuffixTreeEdge {
 public:
  SuffixTreeEdge(SuffixTreeNode* destination, int lower_limit,
                 int upper_limit)
      : destination_(destination), lower_limit_(lower_limit),
        upper_limit_(upper_limit) {}

  SuffixTreeNode* destination_;

  // Keeps which part of the string variable marks this edge.
  // Inclusive.
  int lower_limit_;
  int upper_limit_;

  int Size() const {
    return upper_limit_ - lower_limit_ + 1;
  }
};

class SuffixTreeNode {
 public:
  // Put 0 as alphabet_count to denote this is a leaf.
  SuffixTreeNode(int alphabet_count, bool is_terminal)
      : edges_(alphabet_count), is_terminal_(is_terminal) {}

  bool IsLeaf() const {
    return edges_.size() == 0;
  }

  // If this is empty, it denotes that this node is a leaf.
  vector<SuffixTreeEdge*> edges_;

  // If there exists a suffix ending here.
  bool is_terminal_;
};

class WeinerNode : public SuffixTreeNode {
 public:
  WeinerNode(int alphabet_count, int depth, WeinerNode* parent, bool is_leaf)
      : SuffixTreeNode(is_leaf ? 0 : alphabet_count, /* is_terminal = */ false),
        links_(alphabet_count),
        indicator_(alphabet_count, false),
        depth_(depth),
        parent_(parent) {}

  // L and I vectors as in Gusfield's book. These are empty if the
  // node is a leaf.
  vector<WeinerNode* > links_;
  vector<bool> indicator_;

  // Length of the pathlen until this node.
  int depth_;

  WeinerNode* parent_;
};

void FinalizeWeiner(SuffixTreeNode* node, int alphabet_size, int seq_length) {
  if (node->IsLeaf()) {
    node->is_terminal_ = true;
    return;
  }

  if (node->edges_[alphabet_size - 1] != NULL) {
    assert(node->edges_[alphabet_size - 1]->upper_limit_ ==
           seq_length - 1);
    assert(node->edges_[alphabet_size - 1]->lower_limit_ ==
           seq_length - 1);
    delete node->edges_[alphabet_size - 1]->destination_;
    delete node->edges_[alphabet_size - 1];
    node->is_terminal_ = true;
  }

  node->edges_.pop_back();
  for (int i = 0; i < alphabet_size - 1; ++i) {
    if (node->edges_[i] != NULL) {
      if (node->edges_[i]->upper_limit_ == seq_length - 1) {
        node->edges_[i]->upper_limit_ = seq_length - 2;
      }
      assert(node->edges_[i]->lower_limit_ <= node->edges_[i]->upper_limit_);
      assert(node->edges_[i]->lower_limit_ >= 0);
      assert(node->edges_[i]->upper_limit_ <= seq_length - 2);
      FinalizeWeiner(node->edges_[i]->destination_,
                     alphabet_size, seq_length);
    }
  }

}

SuffixTreeNode* Weiner(int alphabet_size, vector<int> sequence) {

  assert(alphabet_size >= 0);
  for (int i = 0; i < SZ(sequence); ++i) {
    assert(sequence[i] >= 0 && sequence[i] < alphabet_size);
  }

  // Add a sentinel node so that no suffix is a prefix of other suffix.
  sequence.push_back(alphabet_size);
  ++alphabet_size;

  WeinerNode* root = new WeinerNode(alphabet_size, 0, NULL, /* is_leaf = */ false);
  // DEBUG(root);

  WeinerNode* last = root;
  for (int i = SZ(sequence) - 1; i >= 0; --i) {
    // Traverse back finding v and v'
    WeinerNode* v = NULL;
    WeinerNode* va = NULL;

    int num = sequence[i];

    // cout << i << " start" << endl;
    while (true) {
      // DEBUG(last);
      // cout << "inside" << endl;
      assert(v == NULL || last->indicator_[num]);
      if (last->indicator_[num] && v == NULL) {
        v = last;
      }

      // We update for the next iteration
      last->indicator_[num] = true;

      if (last->links_[num] != NULL) {
        assert(v != NULL);
        assert(va == NULL);
        va = last;
        break;
      }

      if (last == root) break;
      last = last->parent_;
    }
    // cout << "break free" << endl;

    // There are three cases.
    assert(!(va != NULL && v == NULL));
    assert(va != NULL || last == root);

    if (va == NULL && v == NULL) {
      // cout << "Case 1" << endl;
      // The not found case.
      assert(last == root);
      assert(last->indicator_[num]);
      assert(last->edges_[num] == NULL);

      // In this case, S[i] was never found.
      // So, we create a new leaf.
      WeinerNode* new_leaf = new WeinerNode(alphabet_size, SZ(sequence) - i,
                                            last, /* is_leaf = */ true);
      last->edges_[num] = new SuffixTreeEdge(new_leaf, i, SZ(sequence) - 1);
      // cout << new_leaf << " created" << endl;

      last = new_leaf;
      continue;
    }

    int diff = 0;

    if (v != NULL && va == NULL) {
      // cout << "Equivalenting good case" << endl;
      // This is equivalent with the good case
      assert(last == root);
      va = root;
      // cout << v << " " << va << endl;
      diff = v->depth_ + 1;
    } else {
      assert(!va->IsLeaf());
      assert(va->links_[num] != NULL);
      diff = v->depth_ - va->depth_;
      va = va->links_[num];
    }

    // DEBUG(diff);
    // cout << va << " " << v << " " << endl;
    assert(va != NULL || v == NULL);
    assert(!v->IsLeaf());
    assert(!va->IsLeaf());

    // Both va and v must be found.
    // Furthermore, it must be the suffix starting in va, of diff length.

    // First, we check if we need to create a new internal node.
    if (diff != 0) {
      // cout << "Creating a new internal node..." << endl;
      int new_num = sequence[i + va->depth_];
      assert(va->edges_[new_num] != NULL);
      assert(va->edges_[new_num]->Size() > diff);

      WeinerNode* internal_node =
          new WeinerNode(alphabet_size, va->depth_ + diff, va, /* is_leaf = */ false);
      assert(!internal_node->IsLeaf());
      // cout << internal_node << " (internal_node) created" << endl;

      WeinerNode* child = (WeinerNode*)va->edges_[new_num]->destination_;

      // First, create the new edge and update the old one.
      internal_node->edges_[sequence[va->edges_[new_num]->lower_limit_ + diff]] =
          new SuffixTreeEdge(child,
                             va->edges_[new_num]->lower_limit_ + diff,
                             va->edges_[new_num]->upper_limit_);

      va->edges_[new_num]->upper_limit_ =
          va->edges_[new_num]->lower_limit_ + diff - 1;
      va->edges_[new_num]->destination_ = internal_node;
      child->parent_ = internal_node;

      // Copies the indicator vector from child.
      internal_node->indicator_ = child->indicator_;
      // DEBUG(child);
      // DEBUG(SZ(internal_node->indicator_));

      // Updates the link vector from v to here.
      v->links_[num] = internal_node;

      va = internal_node;
    }

    // Now, we are sure va does not have that.
    assert(va->depth_ < (SZ(sequence) - i));
    assert(!va->IsLeaf());

    int ask_num = sequence[i + va->depth_];
    assert(va->edges_[ask_num] == NULL);

    // Finally, insert an edge here
    WeinerNode* new_leaf = new WeinerNode(alphabet_size, SZ(sequence) - i,
                                          va, /* is_leaf = */ true);
    // cout << new_leaf << " (new leaf) created" << endl;
    va->edges_[ask_num] = new SuffixTreeEdge(new_leaf, i + va->depth_,
                                             SZ(sequence) - 1);

    last = new_leaf;
  }

  FinalizeWeiner(root, alphabet_size, SZ(sequence));
  return root;
}

ll answer = 0LL;

ll Solve(SuffixTreeNode* node) {
  if (node->IsLeaf()) return 1;
  ll res = node->is_terminal_;
  FORN(i, 26) if (node->edges_[i] != NULL) {
    ll hasil = Solve(node->edges_[i]->destination_);
    res += hasil;
    ll uk = node->edges_[i]->Size();
    answer += uk * ((hasil * (hasil + 1)) / 2LL);
  }
  return res;
}

int main() {

  string str;
  cin >> str;

  vector<int> seq;
  FORN(i, SZ(str)) seq.PB(str[i] - 'a');

  SuffixTreeNode* tree = Weiner(26, seq);

  Solve(tree);
  cout << answer << endl;

  return 0;
}
