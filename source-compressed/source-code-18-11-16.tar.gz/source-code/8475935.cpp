//Language: GNU C++


#include <iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#define LL long long
#define FOR(x,y,z) for(int (x) = (y); (x) < (z); (x)++)
#define FER(x,y,z) for(int (x) = (y); (x) <= (z); (x)++)
#define C 1000000007LL
using namespace std;

int main(){
    int n,k, cur = 1, os, up = 1, mark;
    scanf("%d%d", &n, &k);
    os = k;
    printf("1 ");
    while(1){
        if(up) mark = cur+k;
        else mark = cur-k;
        printf("%d ", mark);
        if(k == 1) break;
        up = !up; k--; cur = mark;
    }
    for(int i=os+2; i<=n;i++) printf("%d ", i);
    return 0;
}