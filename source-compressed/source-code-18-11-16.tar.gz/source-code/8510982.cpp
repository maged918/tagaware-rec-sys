//Language: GNU C++


#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>
#include<cstdlib>

using namespace std;

const int maxn = 1010;
bool mark [maxn][maxn];
int n, m, dis[maxn][maxn], dx[4] = {0, 0, -1, 1}, dy[4] = {-1, 1, 0, 0}, sx, sy, ex, ey, sd, num = 0;
queue <pair<int, int> > q;
char city[maxn][maxn];

bool isav (int x, int y)
{
    return x >= 0 && x < n && y >= 0 && y < m;
}

void bfs (int x, int y)
{
    mark[x][y] = true;
    dis[x][y] = 0;
    q.push(make_pair(x, y));
    while (!q.empty())
    {
        int xx = q.front().first, yy = q.front().second;
        for (int j = 0; j < 4; j++)
        {
            if (isav(xx+dx[j], yy+dy[j]) && mark[xx+dx[j]][yy+dy[j]] == false && city[xx+dx[j]][yy+dy[j]] != 'T')
            {
                mark[xx+dx[j]][yy+dy[j]] = true;
                dis[xx+dx[j]][yy+dy[j]] = dis[xx][yy]+1;
                q.push(make_pair(xx+dx[j], yy+dy[j]));
            }
        }
        q.pop();
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin >> n >> m;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> city[i][j];
            if (city[i][j] == 'S')
            {
                sx = i;
                sy = j;
            }
            if (city[i][j] == 'E')
            {
                ex = i;
                ey = j;
            }
        }
    }
    bfs(ex, ey);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            if (int(city[i][j]) >= 49 && int(city[i][j]) <= 57 && dis[i][j] <= dis[sx][sy] && dis[i][j] > 0)
                num+=int(city[i][j])-48;
        }
    }
    cout << num;
    return 0;
}
