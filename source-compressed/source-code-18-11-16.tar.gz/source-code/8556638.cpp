//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <map>
#include <queue>
#include <set>
using namespace std;
#define SZ(v) ((int)(v).size())
#define rep(i, n) for (int i = 0; i < (n); ++i)
#define repf(i, a, b) for (int i = (a); i <= (b); ++i)
#define repd(i, a, b) for (int i = (a); i >= (b); --i)
const int maxint = -1u>>1;
struct seg{
    int a , b ;
    bool operator < ( const seg &q ) const {
        return a < q.a ;
    }
};
int l[110000], r[110000], q[110000] ;
int n , m ;
int num[32] ;
vector<seg> have , que , ret[32] ;
bool pass( int k ) {
    seg now ; now.a = 1000000 ; now.b = 0 ;
    ret[k].push_back(now) ;
    rep( i , (int)que.size() ) {
        int x = upper_bound(ret[k].begin(),ret[k].end(),que[i]) - ret[k].begin() ;
        //cout<<ret[0].a<<" "<<ret[0].b<<endl;
        if ( x == 0 ) continue ;
        x -- ;
        if ( que[i].a <= ret[k][x].b ) {
            if ( que[i].b <= ret[k][x].b ) return false ;
        }
    }
    return true ;
}
int main() {
    scanf("%d %d" , &n , &m ) ;
    repf( i , 1 , m ) 
        scanf("%d %d %d" , &l[i] , &r[i] , &q[i] ) ;
    bool checkOk = true ;
    rep( i , 30 ) {
        have.clear() ;
        que.clear() ;
        repf( j , 1 , m ) {
            seg s  ; s.a = l[j] ; s.b = r[j] ;
            if ( q[j] & ( 1 << i ) ) {
                have.push_back(s) ;
            }
            else {
                que.push_back(s) ;
            }
        }
        sort(have.begin(),have.end()) ;
        
        seg now ; now.a = -1 ;
        for ( int j = 0 ; j < (int)have.size() ; j ++ ) {
            if ( now.a == -1 ) {
                now = have[j] ;
                continue ;
            }
            if ( have[j].a > now.b ) {
                ret[i].push_back(now) ;
                now = have[j] ;
            }
            else 
                now.b = max( now.b , have[j].b ) ;
        }
        if ( now.a != -1 )
            ret[i].push_back(now) ;
        
        if ( !pass(i) ) {
            checkOk = false ;
            break ;
        }
    }
    puts(checkOk?"YES":"NO") ;
    if ( checkOk ){
        repf( i , 1 , n ) {
            int now = 0 ;
            rep( j , 30 ) {
                while ( (int)ret[j].size() - 1 > num[j] && i > ret[j][num[j]].b )
                    num[j] ++ ;
                if ( i >= ret[j][num[j]].a && i <= ret[j][num[j]].b )
                    now |= 1<<j ;
            }
            printf("%d" , now ) ;
            if ( i!= n ) printf(" ") ;
        }
        puts("") ;
    }
}
