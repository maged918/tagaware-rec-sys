//Language: GNU C++0x


#include <bits/stdc++.h>
using namespace std;
const int MOD=1e9+7;
int N,K;
int dp[2001][2001];
int ans;
inline void add(int &a,int b){
	a+=b;
	if(a>MOD)
		a-=MOD;
}
int main(){
	cin >> N >> K;
	for(int i=1;i<=N;i++)
		dp[i][1]=1;
	for(int j=1;j<K;j++)
		for(int i=1;i<=N;i++)
			for(int k=i;k<=N;k+=i)
				add(dp[k][j+1],dp[i][j]);
	for(int i=1;i<=N;i++)
		add(ans,dp[i][K]);
	cout << ans << endl;
	return 0;
}
