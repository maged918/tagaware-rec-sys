//Language: GNU C++


#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>

using namespace std;

const int maxn = 1000;
int n, mark[maxn + 5], num[26];
char map[maxn + 5];

int is_prime(int n)
{
	int up = sqrt(n);
	for (int i = 2; i <= up; i++) 
		if (n % i == 0)
			return 0;
	return 1;
}

int main()
{
	cin >> map + 1;
	n = strlen(map + 1);
	if (n <= 3)
	{
		cout << "YES" << "\n" << map + 1 << "\n";
		return 0;
	}
	memset(num, 0, sizeof(num));
	memset(mark, 0, sizeof(num));
	for (int i = 1; i <= n; i++)
		num[map[i] - 'a']++;
	int max_num = 0;
	char max_c;
	for (int i = 0; i < 26; i++) 
	{
		if (max_num < num[i])
			max_num = num[i], max_c = 'a' + i;
	}
	for (int i = 2, up = n >> 1; i <= up; i++) if (is_prime(i))
	{
		if (i + i <= n)
		for (int t = i; t <= n; t += i)
			mark[t] = 1;
	}
	int sum = 0;
	for (int i = 2; i <= n; i++)
		sum += mark[i];
	if (sum <= max_num)
	{
		cout << "YES\n";
		for (int i = 1, t = 1; i <= n; i++)
		{
			if (mark[i])
				cout << max_c;
			else
			{
				int f = 1;
				for (; t <= n; t++)
				{
					if (map[t] != max_c) 
					{
						cout << map[t++];
						f = 0;
						break;
					}
				}
				if (f)
					cout << max_c;
			}
		}
		cout << "\n";
	} else
		cout << "NO\n";
	return 0;
}
