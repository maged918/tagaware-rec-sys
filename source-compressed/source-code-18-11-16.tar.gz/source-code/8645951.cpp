//Language: MS C++


#include <cstdio>
#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

class request
{
public:
	int lostHair, unpleasent;
	int id, id2;
	bool operator < (const request &b) const
	{
		if(unpleasent == b.unpleasent)
		{
			return lostHair < b.lostHair;
		}
		return unpleasent > b.unpleasent;
	}
}req[100000 + 100];

request req2[100000 + 100];

bool cmp(const request &a, const request &b)
{
	if(a.lostHair == b.lostHair)
	{
		return a.id2 < b.id2;
	}
	return a.lostHair > b.lostHair;
}

int main()
{
	int n, p, k;
	scanf("%d%d%d", &n, &p, &k);
	for(int i = 0; i < n; ++i)
	{
		scanf("%d%d", &req[i].lostHair, &req[i].unpleasent);
		req[i].id = i + 1;
	}
	sort(req, req + n);
	int mustRem = p - k;
	for(int i = 0; i < n - mustRem; ++i)
	{
		req2[i] = req[i];
		req2[i].id2 = i;
	}
	sort(req2, req2 + n - mustRem, cmp);
	vector<int> ans;
	ans.clear();
	int stPoint = 0;
	for(int i = 0; i < k; ++i)
	{
		ans.push_back(req2[i].id);
		stPoint = max(stPoint, req2[i].id2);
	}
	for(int i = stPoint + 1, cnt = 0; i < n && cnt < mustRem; ++i, ++cnt)
	{
		ans.push_back(req[i].id);
	}
	for(int i = 0; i < (int)ans.size(); ++i)
	{
		printf("%d%c", ans[i], (int)ans.size() == i + 1 ? '\n' : ' ');
	}
	return 0;
}
		 		 		   		  	 	 			   		