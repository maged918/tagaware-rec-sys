//Language: GNU C++


#define _CRT_SECURE_NO_DEPRECATE

#include <iostream>
#include <cstdio>
#include <fstream>
#include <vector>
#include <deque>
#include <set>
#include <map>
#include <list>
#include <string>
#include <iterator>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <cstring>
using namespace std;

#define DMAX 10002
#define MOD  1000003
#define min(a,b) a>b ? b : a
#define max(a,b) a<b ? b : a

int n; char c[101];

int main(){
    int i = 0, lg;

    /*freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);*/

    scanf("%s", c); lg = strlen(c);
    while (i < lg) {
        switch (c[i++])
        {
            case '>': n *= 16, n += 8; break;
            case '<': n *= 16, n += 9; break;
            case '+': n *= 16, n += 10; break;
            case '-': n *= 16, n += 11; break;
            case '.': n *= 16, n += 12; break;
            case ',': n *= 16, n += 13; break;
            case '[': n *= 16, n += 14; break;
            case ']': n *= 16, n += 15; break;
            default: break;
        }
        n %= MOD;
    }

    printf("%d", n);

    return 0;
}