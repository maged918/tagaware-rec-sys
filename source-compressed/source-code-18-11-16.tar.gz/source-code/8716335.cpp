//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<cstring>
#define MAX 10

using namespace std;

int v[MAX];
int num[6]; 

int main(){
    int i, j, k;
    while(~scanf("%d%d%d%d%d%d", &num[0], &num[1], &num[2], &num[3], &num[4], &num[5])){
    bool flag = false;
    memset(v, 0, sizeof(v));
    for(i = 0; i < 6; i++){
        k = num[i];
        v[k]++;
        if(v[k] >= 4){
            flag = true;
        }
    }
    if(flag){
        bool cc = flag = true;
        for(i = 0; i <= 9; i++){
            v[i] %= 4;
            if(v[i] == 2){
                puts("Elephant");
                cc = false;
                break;
            }
        }
        if(cc)
        puts("Bear");
    }
    else{
        puts("Alien");  
    }
    }
    return 0; 
} 