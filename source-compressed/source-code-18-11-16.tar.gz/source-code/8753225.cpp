//Language: GNU C++0x


/**
 * Copyright (c) 2014 Authors. All rights reserved.
 * 
 * FileName: E.cpp
 * Author: Beiyu Li <sysulby@gmail.com>
 * Date: 2014-11-19
 */
#include <bits/stdc++.h>

using namespace std;

#define rep(i,n) for (int i = 0; i < (n); ++i)
#define For(i,s,t) for (int i = (s); i <= (t); ++i)
#define foreach(i,c) for (__typeof(c.begin()) i = c.begin(); i != c.end(); ++i)

typedef long long LL;
typedef pair<int, int> Pii;

const int inf = 0x3f3f3f3f;
const LL infLL = 0x3f3f3f3f3f3f3f3fLL;

const int maxn = 50 + 5;
const int maxm = 20 + 5;
const int maxs = (1 << 20) + 5;

int n, m, ALL;
string s[maxn];
LL d[maxs];
int bit[maxs];
double C[maxm][maxm];

void init()
{
        rep(S,maxs) if (S) bit[S] = bit[S^(S&-S)] + 1;
        rep(i,maxm) {
                C[i][0] = C[i][i] = 1;
                for (int j = 1; j < i; ++j) C[i][j] = C[i-1][j-1] + C[i-1][j];
        }
}

int bit_count(LL S)
{
        int res = 0, ALL = (1 << 20) - 1;
        for (; S; S >>= 20) res += bit[S&ALL];
        return res;
}

int main()
{
        init();
        cin >> n;
        rep(i,n) cin >> s[i];
        m = s[0].length();
        ALL = (1 << m) - 1;
        rep(i,n) rep(j,n) if (j > i) {
                int S = 0;
                rep(k,m) if (s[i][k] == s[j][k]) S |= 1 << k;
                d[S] |= (1LL << i) | (1LL << j);
        }
        for (int S = ALL; S; --S) rep(k,m)
                if (S & (1 << k)) d[S^(1<<k)] |= d[S];
        double res = 0;
        For(S,0,ALL) res += (double)bit_count(d[S]) / C[m][bit_count(S)];
        printf("%.10f\n", res / n);

        return 0;
}
