//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<vector>
#include<map>
#define INF 0x3f3f3f3f


using namespace std;
typedef long long LL;
const int N=5010;

LL a[N];
LL sum[N];
LL num[N];
LL dp[N][N];

int main()
{
        int n,m,k;
        //freopen("i.txt","r",stdin);
        while(cin>>n>>m>>k)
        {
                sum[0]=0;
                memset(dp,0,sizeof dp);
                for(int i=1;i<=n;i++)
                {
                        cin>>a[i];
                        sum[i]=sum[i-1]+a[i];
                }
                for(int i=m;i<=n;i++)
                        num[i]=sum[i]-sum[i-m];
/*
                for(int j=1;j<=n;j++){
                        for(int i=1;i<=k;i++){
                                if(j+m-1<=n)
                                {
                                        if(j-m>=1) dp[i][j]=max(dp[i][j-1],dp[i-1][j-m]+num[j]);
                                        else dp[i][j]=dp[i][j-1];
                                }
                        }
                }
*/
               for(int j=1;j<=k;j++){
                        for(int i=m;i<=n;i++){
                                dp[i][j]=max(dp[i-1][j],dp[i-m][j-1]+num[i]);
                        }

                }
                cout<<dp[n][k]<<endl;
        }

}

  	       	 			     							 			