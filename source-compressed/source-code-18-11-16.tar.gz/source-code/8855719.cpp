//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 1e6 + 5;
char str[N];
int mark[N], power[N];
typedef long long LL;

int main() {
    scanf("%s", str + 1);
    int n = strlen(str + 1);
    int a, b;
    scanf("%d%d", &a, &b);
    power[0] = 1;
    for (int i = 1; i < N; ++i)
	power[i] = (LL)power[i - 1] * 10 % b;
    mark[n + 1] = 0;
    for (int i = n; i >= 1; --i)
	mark[i] = ((LL)power[n - i] * (str[i] - '0') + mark[i + 1]) % b;
    int i, sum = 0;
    for (i = 1; i < n; ++i) {
	sum = ((LL)sum * 10 + str[i] - '0') % a;
	if (sum == 0 && mark[i + 1] == 0 && str[i + 1] != '0') 
	    break;
    }
    if (i >= n) puts("NO");
    else {
	puts("YES");
	for (int j = 1; j <= i; ++j)
	    putchar(str[j]);
	puts("");
	for (int j = i + 1; j <= n; ++j)
	    putchar(str[j]);
	puts("");
    }
    return 0;
}
