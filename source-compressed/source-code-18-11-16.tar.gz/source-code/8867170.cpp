//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string>
#include <cstring>
#include <cmath>
#include <queue>
#include <vector>
#include <set>
#include <map>
#include <iomanip>
#include <algorithm>
using namespace std;

int num1[200100],num2[200100];

int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
        scanf("%d",&num1[i]);
    for(int i=1;i<=n;++i){
        int a;
        scanf("%d",&a);
        num2[a]=i;
    }
    int pos=num2[num1[1]];
    for(int i=2;i<=n;++i){
        if(pos<num2[num1[i]])
            pos=num2[num1[i]];
        else{
            printf("%d\n",n-i+1);
            return 0;
        }
    }
    printf("%d\n",0);
    return 0;
}

	 	 			 					 	  			 				