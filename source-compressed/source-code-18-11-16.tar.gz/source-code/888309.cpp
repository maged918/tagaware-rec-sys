//Language: GNU C++


#include<cstdio>
#include<cmath>
#include<math.h>
#include<cstring>
#include<cstdlib>
#include<cassert>
#include<ctime>
#include<algorithm>
#include<iterator>
#include<iostream>
#include<cctype>
#include<string>
#include<vector>
#include<map>
#include<set>
#include<queue>
#include<list>
#define ep 0.00001
#define maxn 100111
#define oo 1111111111
#define modunlo 111539786
#define TR(c, it) for(typeof((c).begin()) it=(c).begin(); it!=(c).end(); it++)
//#define g 9.81
double const PI=4*atan(1.0);

using namespace std;

typedef pair<int, int> II;
typedef vector<int> VI;
typedef vector<II> VII;
typedef vector<VI> VVI;
typedef vector<VII> VVII;


int main(){
   //  freopen("B.in","r",stdin);
   //  freopen("B.out","w",stdout);
     int h,w,x=1,h1,w1;
     bool doicho = false;
     cin>>h>>w;
     h1 = h; w1 = w;
     if(h<w){
          swap(h,w);
          doicho = true;
     }
     while(x<=h) x*=2; x/=2;
     while(x*0.8-ep>w) x/=2;
     if(x>w) h = x;
     else{
          w = x;
          h = min(h,int(x*1.25+ep));
     }
     if(doicho && h1<h) swap(h,w);
     printf("%d %d",h,w);
}
