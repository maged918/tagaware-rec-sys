//Language: GNU C++0x


#include<bits/stdc++.h>


#define vi vector<int>
#define ii pair<int, int>
#define vii vector<ii>
#define si set<int>
#define msi map<string, int>
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define ll long long
#define ALL(c) (c).begin(),(c).end()
#define rep(i, a, b) for (int i = (a); i <= (b); ++i)
#define repn(i, a, b) for (int i = (a); i >= (b); --i)
const int INF = 1<<29;

#define ItrVi(c, it) \
for (vi::iterator it = (c).begin(); it != (c).end(); it++)
#define ItrRevVi(c, it) \
for (vi::reverse_iterator it = (c).rbegin(); it != (c).rend(); it++)

using namespace std;

int main()
{
	int n, tmp, min1, max1;
	cin>>n;
	int arr[n];
	rep(i,0,n-1)
	{
		cin>>tmp;
		arr[i]=tmp;
	}
	min1 = min(arr[0], arr[n-1]);
	rep(i,2,n-2)
	{
		max1= max(arr[i], arr[i-1]);
		min1= min(max1, min1);
	}
	cout<<min1;
	return 0;
}
