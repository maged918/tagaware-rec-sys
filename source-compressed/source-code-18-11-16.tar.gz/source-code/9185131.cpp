//Language: GNU C++


#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <stdio.h>
using namespace std;
int d[100000],f[100000];
void qs(int q,int w){
  int e=q,r=w,y=q+(rand()%(w-q+1)),t=d[q],t1=f[q];
  do{
  while((d[e]<t)||((d[e]==t)&&(f[e]<t1)))e++;
  while((d[r]>t)||((d[r]==t)&&(f[r]>t1)))r--;
  if(e<=r){
   y=d[e];d[e]=d[r];d[r]=y;
   y=f[e];f[e]=f[r];f[r]=y;
   e++;r--;}
  }while(e<=r);
  if(q<r)qs(q,r);
  if(e<w)qs(e,w);
}
int main(){
  //freopen("input.txt","r",stdin);
  //freopen("output.txt","w",stdout);
  int q,w,e,r,t=0,c,v,c1,v1,c2,v2,i=1,a[100001],s[100001],h[100001];
  cin>>q;
  for(w=0;w<=q;w++)
   a[w]=s[w]=0;
  for(w=1;w<=q;w++){
   scanf("%d",&e);
   if(e==1)
    a[w]++;
   else
    s[w]++;
   a[w]+=a[w-1];
   s[w]+=s[w-1];
   h[w]=e;
   }
  bool b;
  for(w=1;w<=q;w++){
   if((i<<1)<=w)
    i<<=1;
   r=0;
   b=1;
   c=v=0;
   for(e=0;e<q;){
    c1=a[min(q,e+w)]-a[e];
    v1=s[min(q,e+w)]-s[e];
    e+=w;
    for(v2=i;v2;v2>>=1){
     c2=e+v2;
     if((c2<=q)&&(max(c1+a[c2]-a[e],v1+s[c2]-s[e])<w)){
      c1+=a[c2]-a[e];
      v1+=s[c2]-s[e];
      e=c2;}}
    while((e<q)&&(max(c1,v1)<w)){
     e++;
     if(h[e]==1)
      c1++;
     else
      v1++;}
    if(max(c1,v1)<w){
     b=0;break;}
    if(c1<v1)
     v++;
    else
     c++;}
   if(((h[q]==1)&&(c<v))||((h[q]==2)&&(c>v)))
    continue;
   if((b)&&(c!=v)){
    d[t]=max(c,v);
    f[t]=w;
    t++;
                   }
   
                   }
  cout<<t<<"\n";
  if(t>0)
   qs(0,t-1);
  for(w=0;w<t;w++)
   cout<<d[w]<<" "<<f[w]<<"\n";
  
  return 0;}
