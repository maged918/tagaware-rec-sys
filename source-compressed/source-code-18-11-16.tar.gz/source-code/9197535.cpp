//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <string.h>
using namespace std;
#define N 200010
#define mod 1000000007
int z[N]; // z[0] = 0
char s[N];
int n;
void build(int n)
{
	int L = 0, R = 0;
	for (int i = 1; i < n; i++) 
	{
		if (i > R || z[i-L] >= R-i+1) 
		{
			L = i; R = max(R, i);
			while (R < n && s[R-L] == s[R]) R++;
			z[i] = R---L;
		}
		else z[i] = z[i-L];
	}
}
char t[N];
long long pd[N];
long long acc[N];
long long sum[N];

int main (void) {
	cin >> t >> s;
	int len = strlen(s);
	strcpy(s+len, t);
	int n = strlen(s);
	build(n);
	int last = -1;
	int i;
	sum[len-1] = acc[len-1] = 0;
	for (i = len; i < n; i++) {
		if (z[i-len+1] >= len) {
			last = i-len+1;
			if (last < len)	last = -1;
		}
		if (last == -1)	pd[i] = 0;
		else {
			pd[i] = (sum[last-1]+last-len+1)%mod;
		}
		acc[i] = (acc[i-1]+pd[i])%mod;
		sum[i] = (sum[i-1]+acc[i])%mod;
	}
	cout << acc[n-1];
}
