//Language: GNU C++


#include <vector>
#include <map>
#include <set>
#include <cmath>
#include <string>
#include <cstring>
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <sstream>
#include <queue>
using namespace std;

#define next next12321312

const char DOWN = 'S';
const char RIGHT = 'C';

const int INF = 1000000000;
const int MAXN = 50000;

char resultString[MAXN];
int X[MAXN], Y[MAXN];
int n, m, P;
int dp[2][MAXN], dpBack[2][MAXN];

inline int getValue(int x, int y) {
	if (x < 0 || y < 0 || x >= n || y >= m) {
		return -1000000000;
	}
	int val = (X[x] + Y[y]);
	if (val >= P) return val - P;
	return val;
}

void rec(int xStart, int yStart, int xFinish, int yFinish) {
	if (xStart == xFinish) {
		for (int i = 0; i < yFinish-yStart; ++i) {
			resultString[xStart + yStart + i] = DOWN;
		}
	} else if (yStart == yFinish) {
		for (int i = 0; i < xFinish - xStart; ++i) {
			resultString[xStart + yStart + i] = RIGHT;
		}
	} else {
		int middle = (xStart + yStart + xFinish + yFinish) >> 1;
		
		int dst = middle - xStart - yStart;
		int cur = 0, nx = 1;
		dp[cur][0] = 0;
		for (int i = 1; i <= dst; ++i) {
			for (int j = 0; j <= i && j <= xFinish - xStart; ++j) {
				dp[nx][j] = max(j > 0 ? dp[cur][j-1] : -INF, i - j > 0 ? dp[cur][j] : -INF) + getValue(xStart + j, yStart + i - j);
			}
			swap(nx, cur);
		}
		
		int dstBack = xFinish + yFinish - middle;
		int cur2 = 0, nx2 = 1;
		dpBack[cur2][0] = 0;
		for (int i = 1; i <= dstBack; ++i) {
			for (int j = 0; j <= i && j <= xFinish - xStart; ++j) {
				dpBack[nx2][j] = max(j > 0 ? dpBack[cur2][j-1] : -INF, i - j > 0 ? dpBack[cur2][j] : -INF) + getValue(xFinish - j, yFinish - i + j);
			}
			swap(nx2, cur2);
		}
		
		int m = -1;
		int bestCost = -1;
		for (int j = max(0, dst - yFinish + yStart); j <= xFinish - xStart && j <= dst; ++j) {
			int cost = dp[cur][j] + dpBack[cur2][xFinish - xStart - j] - getValue(xStart + j, yStart - j + dst);
			if (cost > bestCost) {
				bestCost = cost;
				m = j;
			}
		}
		rec(xStart, yStart, xStart + m, yStart + dst - m);
		rec(xStart + m, yStart + dst - m, xFinish, yFinish);
	}
}

int main() {
	scanf("%d%d%d", &n, &m, &P);
	for (int i = 0; i < n; ++i) {
		scanf("%d", X + i);
		X[i] %= P;
	}
	for (int i = 0; i < m; ++i) {
		scanf("%d", Y + i);
		Y[i] %= P;
	}
	rec(0, 0, n-1, m-1);
	int result = 0;
	int x = 0, y = 0;
	for (int i = 0; i < n + m - 2; ++i) {
		result += getValue(x, y);
		if (resultString[i] == RIGHT) {
			++x;
		} else {
			++y;
		}
	}
	resultString[n + m - 2] = 0;
	result += getValue(x, y);
	printf("%d\n", result);
	puts(resultString);
	return 0;
}