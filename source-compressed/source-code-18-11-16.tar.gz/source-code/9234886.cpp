//Language: GNU C++0x


#include <bits/stdc++.h>

using namespace std;

const int N = 100010;

int n;
int p[N], g[N];
int p_cum[N], g_cum[N];

int check(int t) {
	int p_pos = distance(p_cum, lower_bound(p_cum, p_cum + n, t));
	int g_pos = distance(g_cum, lower_bound(g_cum, g_cum + n, t));
	int pos = min(p_pos, g_pos);
	if (pos >= n) return -1;
	int ps = 0, gs = 0;
	if (p_pos < g_pos) {
		ps++;
	} else {
		gs++;
	}
	if (pos == n - 1) {
		if (gs == ps) return -1;
		return max(ps, gs);
	}
	while (pos < n - 1) {
		p_pos = distance(p_cum + pos, lower_bound(p_cum + pos, p_cum + n, p_cum[pos] + t));
		g_pos = distance(g_cum + pos, lower_bound(g_cum + pos, g_cum + n, g_cum[pos] + t));
		pos += min(p_pos, g_pos);
		int last_win;
		if (p_pos < g_pos) {
			ps++;
			last_win = 0;
		} else {
			gs++;
			last_win = 1;
		}
		if (pos == n - 1) {
			if (gs == ps) return -1;
			if (ps < gs && last_win == 1) {
				return gs;
			} else if (gs < ps && last_win == 0) {
				return ps;
			} else {
				return -1;
			}
		}
	}
	return -1;
}

int main() {
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		int x;
		scanf("%d", &x);
		if (x == 1) {
			p[i] = 1;
			g[i] = 0;
		} else {
			p[i] = 0;
			g[i] = 1;
		}
	}
	partial_sum(p, p + n, p_cum);
	partial_sum(g, g + n, g_cum);
	set<pair<int, int> > ans;
	for (int i = 1; i <= n; i++) {
		int s = check(i);
		if (s != -1) {
			ans.insert(make_pair(s, i));
		}
	}
	printf("%d\n", ans.size());
	for (auto &v: ans) {
		printf("%d %d\n", v.first, v.second);
	}
	return 0;
}
