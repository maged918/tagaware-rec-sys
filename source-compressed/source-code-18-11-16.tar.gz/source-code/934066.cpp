//Language: GNU C++


#include <cstdio>
#include <cstring>

const int lf = 105;

int len, n, ans;
char s[1000];
bool v[110][250][50][2];

inline int fab(int x) 
{
	if( x < 0 )
		return -x;
	return x;
}

void dfs( int pos, int val, int cnt, int k )
{
	if( v[pos][val][cnt][k] )
		return;
	v[pos][val][cnt][k] = 1;
	if( pos == len )
	{
		if( cnt == n && fab(val-lf) > ans )
			ans = fab(val-lf);
		return;
	}

	int t = (s[pos] == 'F' ? 0 : 1);
	for( int i = cnt; i <= n; ++i, ++t )
	{
		if( t%2 )
			dfs(pos+1, val, i, (k+1)%2);
		else if( k )
			dfs(pos+1, val-1, i, k);
		else
			dfs(pos+1, val+1, i, k);
	}
}

int main()
{
	int i, j, k;

	while( scanf("%s %d", s, &n) != EOF )
	{
		ans = 0;
		memset(v, 0, sizeof(v));
		len = strlen(s);

		dfs(0, lf, 0, 0);

		printf("%d\n", ans);
	}

	return 0;
}