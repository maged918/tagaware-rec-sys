//Language: MS C++


#include<stdio.h>
double dp[2005][2005];
int chkr[2005],chkc[2005];
int main()
{
	int n,m,i,j,er=0,ec=0,x,y;
	scanf("%d%d",&n,&m);
	for(i=0;i<m;i++)
	{
		scanf("%d%d",&x,&y);
		chkr[x]=1;
		chkc[y]=1;
	}
	for(i=1;i<=n;i++)
	{
		er += chkr[i];
		ec += chkc[i];
	}
	for(i = n ; i >= er ; i--)
	{
		for(j=n; j>= ec ; j--)
		{
			if(i==n && j==n)
			{
				dp[i][j] = 0;
			}
			else if(i==n)
			{
				dp[i][j] = (double)i*(n-j)/(n*n-i*j)*dp[i][j+1]+(double)n*n/(n*n-i*j);
			}
			else if(j==n)
			{
				dp[i][j] = (double)j*(n-i)/(n*n-i*j)*dp[i+1][j]+(double)n*n/(n*n-i*j);
			}
			else
			{
				dp[i][j] = (double)i*(n-j)/(n*n-i*j)*dp[i][j+1]+(double)j*(n-i)/(n*n-i*j)*dp[i+1][j]+(double)(n-i)*(n-j)/(n*n-i*j)*dp[i+1][j+1]+(double)n*n/(n*n-i*j);
			}
		}
	}
	printf("%lf",dp[er][ec]);
}
