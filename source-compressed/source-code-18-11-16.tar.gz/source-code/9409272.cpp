//Language: GNU C++0x


#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <string>
#include <queue>
#include <set>
#include <map>
using namespace std;


int main()
{
	ios::sync_with_stdio(false);
	int q;
	cin>>q;
	map<string,string> nm;
	int ct = 0;
	string t1,t2;
	for(int i = 0; i < q;i++)
	{
		cin>>t1>>t2;
		if(nm.count(t1))
		{
			string temp = nm[t1];
			nm.erase(t1);
			nm[t2]=temp;
		}
		else
		{
			ct++;
			nm[t2]=t1;
		}
	}
	cout<<nm.size()<<"\n";
	for(auto& i : nm){
	cout<<i.second<<" "<<i.first<<"\n";
	}
}
