//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
const int Maxn=1<<17;
int a[Maxn],b[Maxn];
typedef pair<int,int> pi;
priority_queue<pi>q;
vector<pi>ans;
int main()
{
   int n;
   scanf("%d",&n);
   for(int i=0;i<n;i++)scanf("%d%d",a+i,b+i);
   for(int i=0;i<n;i++)if(a[i]==1)q.push(pi(1,i));
   while(!q.empty())
   {
      pi u=q.top();q.pop();
      int i=u.second;
      if(!a[i])continue;
      a[i]--;
      ans.push_back(pi(i,b[i]));
      b[b[i]]^=i;
      a[b[i]]--;
      if(a[b[i]]==1)q.push(pi(1,b[i]));
   }
   printf("%d\n",(int)ans.size());
   for(int i=0;i<ans.size();i++)printf("%d %d\n",ans[i].first,ans[i].second);
}
