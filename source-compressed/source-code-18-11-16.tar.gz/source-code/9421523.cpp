//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cmath>
#include <climits>
#include <algorithm>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <cassert>
#include <vector>
#define all(x) x.begin() , x.end()
#define fi first
#define se second
#define pb push_back
#define umax( x , y ) x = max( x , (y) )
#define umin( x , y ) x = min( x , (y) )
#define For( i , a ) for(int i=1;i<=a;i++)
#define ort (b+s)/2
#define y2 asrwjaelkf
#define y1 asseopirwjaelkf

using namespace std;

const int maxn = 100020;
const int logn = 18;
const int MOd = 1e9+7;

typedef long long Lint;
typedef long double db;
typedef pair<int,int> ii;
typedef pair<int,ii> iii;

int a;
Lint power[maxn];

int main() {
	
	scanf("%d",&a);
	
	if( a == 1 ) { printf("YES\n1"); return 0; }
	if( a == 4 ) { printf("YES\n1\n3\n2\n4\n"); return 0; }
	for(int i=2;i*i<=a;i++)
		if( a % i == 0 ) { printf("NO\n"); return 0; }
	
	int g;
    while(1){
        g = rand() % (a - 1) + 1;
        Lint G = 1;
        int i;
        for(i=1;;i++){
            G = G * g % a;
            if(G == 1) break;
        }
        if(i == a-1) break;
    }
    
    power[0] = 1;
    for(int i=0;i<a;i++) power[i+1] = power[i] * g % a;
    
    cout << "YES" << endl;
    for(int i=0;i<a-1;i++) {
        int tmp = i;
        if(i % 2 == 0) tmp = a - 1 - tmp;
        printf("%d\n", (int)power[tmp]);
    }
    printf("%d\n",a);
	
	return 0;
}
