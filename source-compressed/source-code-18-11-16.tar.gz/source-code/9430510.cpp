//Language: GNU C++


#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <climits>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <iterator>

using namespace std;

long long factorials[200001];
long long toBeSummed1[200001], toBeSummed2[200001], sumResult[200001];

typedef struct
{
    int numLeaves;
    int val;
    int maxLeafVal;
} Node;

Node tree[400001];

int initTreeHelper(int leaves, int i)
{
    if(i >= leaves)
    {
        tree[i].numLeaves = 1;
        tree[i].maxLeafVal = tree[i].val;
        return tree[i].numLeaves;
    }
    else
    {
        tree[i].numLeaves = initTreeHelper(leaves, i << 1) +
                            initTreeHelper(leaves, (i << 1) + 1);
        tree[i].maxLeafVal = tree[(i << 1) + 1].maxLeafVal;
        return tree[i].numLeaves;
    }
}

int initTree(int n)
{
    int numNodes = (n << 1) - 1;
    int leftmostLeafIndex;
    for(int i=31; i >= 0; --i)
    {
        if((1 << i) & numNodes)
        {
            leftmostLeafIndex = (1 << i);
            break;
        }
    }

    for(int i = leftmostLeafIndex, j = 0; i <= numNodes; ++i, ++j)
    {
        tree[i].val = j;
    }

    for(int i = leftmostLeafIndex - 1, j = n-1; i >= n; --i, --j)
    {
        tree[i].val = j;
    }

    initTreeHelper(n, 1);
}

int findOrderOfKthLeaf(int k, int leaves, int i)
{
    if(i >= leaves)
    {
        return 0;
    }

    if(k > tree[i << 1].maxLeafVal)
    {
        return findOrderOfKthLeaf(k, leaves, (i << 1) + 1) + tree[i << 1].numLeaves;
    }
    else
    {
        return findOrderOfKthLeaf(k, leaves, i << 1);
    }
}

int getNthSmallest(int n, int leaves, int i)
{
    int result;
    if(i >= leaves)
    {
        tree[i].numLeaves--;
        return tree[i].val;
    }

    if(n < tree[i << 1].numLeaves)
    {
        result = getNthSmallest(n, leaves, i << 1);
    }
    else
    {
        result = getNthSmallest(n - tree[i << 1].numLeaves, leaves, (i << 1) + 1);
    }
    tree[i].numLeaves--;
    return result;
}

void translatePermutationOrder(int seq[], int n, int ind, long long res[])
{
    res[ind] = findOrderOfKthLeaf(seq[ind], n, 1);
    getNthSmallest(res[ind], n, 1);
    if(ind == n - 1)
        return;

    translatePermutationOrder(seq, n, ind + 1, res);
}

void sumR(long long n)
{
    int carry = 0;
    int mod = 2;
    for(int i=n-2; i >= 0; --i)
    {
        sumResult[i] = toBeSummed1[i] + toBeSummed2[i] + carry;
        if(sumResult[i] >= mod)
        {
            carry = sumResult[i] / mod;
            sumResult[i] %= mod;
        }
        else
            carry = 0;
        mod++;
    }
    sumResult[n-1] = 0;
}

void print(long long n)
{
    for(int i=0; i < n; ++i)
    {
        cout << getNthSmallest(sumResult[i], n, 1) << " ";
    }
}

int main()
{
    long long m, n, t;
    int P[200001], Q[200001];
    long long p = 0, q = 0;

    cin >> n;
    
    for(int i=0; i < n; ++i)
    {
        cin >> P[i];
    }
    for(int i=0; i < n; ++i)
    {
        cin >> Q[i];
    }

    initTree(n);
    translatePermutationOrder(P, n, 0, toBeSummed1);
    initTree(n);
    translatePermutationOrder(Q, n, 0, toBeSummed2);

    sumR(n);
    initTree(n);
    print(n);

    return 0;
}