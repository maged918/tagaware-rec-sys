//Language: GNU C++


#include <sstream>
#include <queue>
#include <set>
#include <map>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;
string DecimalToBase(long long num)
{
    string strBin = "";
    long long result[10000];
    long long MaxBit = 0;
    for(; num > 0; num/=3)
    {
        long long rem = num % 3;
        //cout<<rem;
        //result[MaxBit++] = rem;
        strBin.push_back(rem);

    }
    return strBin;
    for (long long i=MaxBit-1;i>=0;i--)

            strBin.push_back(result[i]);
            //cout<<strBin;
    return strBin;
}
long long BaseToDecimal(string sBase)
{ long long numbase=3;
    long long dec = 0;
    long long b;
    long long iProduct=1;
    //string sHexa = "";
    long long a=1;
   // for(long long i=sBase.length()-1;i>=0;i--,a*=3){
   for(long long i=0;i<sBase.length();i++,a*=3){
        dec+=(sBase.at(i))*a;
    }
    return dec;
}
string tor(string num1,string num2){
    string s="";
    //cout<<num1<<"\n"<<num2<<"\n";
    for(long long i=0;i<num1.length()||i<num2.length();i++)
        {
            if(i>=num2.length()) for(;i<num1.length();i++) s.push_back(num1.at(i));
            else if(i>=num1.length()) for(;i<num2.length();i++) s.push_back((3-num2.at(i))%3);
            else{
                s.push_back((num1.at(i)-num2.at(i)+3)%3);
               // cout<<s.at(i)+'0';
            }


        }
        return s;
}
int main(){
    long long a,b;
    cin>>a>>b;
    //cout<<
    //tor(DecimalToBase(b),DecimalToBase(a));
    cout<<BaseToDecimal(tor(DecimalToBase(b),DecimalToBase(a)));
}
