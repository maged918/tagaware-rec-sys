//Language: GNU C++


#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

#define F cin
#define G cout

vector<int> ans;
int n;

int main()
{
    ios::sync_with_stdio(0);
    F>>n;
    ans.push_back(0);
    for (int c=0;c<10;++c)
        for (int x=0;x<10;++x)
            for (int y=0;y<10;++y)
            {
                for (int cf=0;cf<(1<<c);++cf)
                {
                    long long nbr = 0;
                    for (int j=0;j<=c;++j)
                        if ( (1<<j) & cf )
                            nbr = nbr * 10 + x;
                        else
                            nbr = nbr * 10 + y;
                    if ( nbr <= n )
                        ans.push_back( nbr );
                }
            }
    sort(ans.begin(),ans.end());
    ans.erase( unique(ans.begin(),ans.end()) , ans.end() );
    G<<int(ans.size())-1<<'\n';
}
