//Language: GNU C++0x


//
//  main.cpp
//  c
//
//  Created by Iago Almeida Neves on 1/18/15.
//  Copyright (c) 2015 Iago Almeida Neves. All rights reserved.
//

#include <bits/stdc++.h>
using namespace std;
#define INF 0x3f3f3f3f
#define MOD 1000000007
#define _ ios_base::sync_with_stdio(false); cin.tie(NULL);
typedef long long ll;
#define REP(i,n) for (int i = 0; i < n; i++)
#define REPI(i,n) for (int i = 1; i <= n; i++)
#define REPN(i,n) for (int i = n-1; i >= 0; i--)
#define REPF(j,i,n) for (int j = i; j < n; j++)

#define MAXN 30100
#define MAXK 510
int dp[MAXN][MAXK];
int v[MAXN];
int offset;
int maxx;

int solve(int i, int k) {
  int &ans = dp[i][k+offset];
  if (ans != -1) {
    return ans;
  }
  ans = 0;
  ans += v[i];
  int a, b, c;
  a = b = c = 0;
  if (i + k + 1 <= maxx) {
    a = solve(i+k+1, k+1);
  }
  if (i + k <= maxx) {
    b = solve(i+k, k);
  }
  if (i + k - 1 <= maxx && k > 1) {
    c = solve(i+k-1, k-1);
  }
  ans += max(a, max(b, c));
  return ans;
}

int main(int argc, const char * argv[]) { _
  int n, k;
  cin >> n >> k;
  maxx = -INF;
  offset = 250 - k;
  memset(dp, -1, sizeof(dp));
  REP(i, n) {
    int a;
    cin >> a;
    v[a]++;
    maxx = max(maxx, a);
  }
  cout << solve(k, k) << endl;
}
