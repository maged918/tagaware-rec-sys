//Language: GNU C++


#include<bits/stdc++.h>

using namespace std;
 
#define FOR(i,a,b) for(int i=a;i<b;i++)
#define For(i,a,b) for(int i=a-1;i>=0;i--)
#define K 1000000007
#define L 400
#define ll long long
#define s1(a) scanf("%d",&a);
#define s2(a) scanf("%lld",&a);
#define s3(a,b) scanf("%lld%lld",&a,&b);
#define s4(a,b,c) scanf("%lld%lld%lld",&a,&b,&c);
#define pb push_back
#define mp make_pair
#define F first
#define S second 
/*******************************MAIN CODE STARTS*******************************/

ll n,m;
int a[2][100010],h[100010],b[2][100010],t,f;

void scan()
{
    s3(n,m)
    memset(b,0,sizeof(b));
    memset(h,0,sizeof(h));
    FOR(i,0,n)
    {
        //char c;
        scanf("%d",&a[1][i]);
        if(a[1][i]<0)
        {
            a[0][i]=1;
            ++f;
            a[1][i]=-a[1][i];
        }
        else
        {
            a[0][i]=0;
            ++t;
        }
        ++b[a[0][i]][a[1][i]];
        //cout<<a[0][i]<<' '<<a[1][i]<<'\n';
    }
}

void out()
{
    int tr,fa,no=0;
    FOR(i,1,n+1)
    {
        tr=b[0][i];
        fa=b[1][i];
        tr+=f-b[1][i];
        fa+=t-b[0][i];
        if(tr==m)
        {
            ++h[i];
            ++no;
        }
    }
    FOR(i,0,n)
    {
        if(a[0][i]==0)
        {
            if(h[a[1][i]]==0)
                puts("Lie");
            else
            {
                if(no==1)
                    puts("Truth");
                else
                    puts("Not defined");
            }
        }
        else
        {
            
            if(h[a[1][i]]==0)
                puts("Truth");
            else
            {
                if(no==1)
                    puts("Lie");
                else
                    puts("Not defined");
            }   
        }
    }
}

int main()
{
    scan();
    out();
    return 0;
}