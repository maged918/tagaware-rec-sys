//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <string>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>
#include <cstring>
#include <set>
#include <map>
#include <ctime>
#include <stack>
using namespace std;

#define inf 2147483647
#define eps 0.0000000000001
#define pi 3.1415926535897932
#define mod 1000000007
#define LL long long
#define ULL unsigned long long
#define LD long double
#define ULD unsigned long double

const int N = 100005;

//	cout<<fixed<<setprecision(3)<<"\nExecution time="<<clock()/1000.0<<endl;
//	freopen("input.txt","r",stdin);
//	freopen("output.txt","w",stdout);

int n, m, i, j, k, q, s, w, v, ans;
int a[1010][1010];

int main()
{
	cin >> n >> m >> k;
	for (i = 1; i <= k; i++)
	{
		int x, y;
		cin >> x >> y;
		a[x][y] = 1;
		if (x > 1 && y > 1)
		{
			if (a[x][y] == 1 && a[x - 1][y] == 1 && a[x][y - 1] == 1 && a[x - 1][y - 1] == 1)
			{
				cout << i << endl;
				return 0;
			}
		}
		if (x > 1 && y < m)
		{
			if (a[x][y] == 1 && a[x - 1][y] == 1 && a[x][y + 1] == 1 && a[x - 1][y + 1] == 1)
			{
				cout << i << endl;
				return 0;
			}
		}
		if (x < n && y < m)
		{
			if (a[x][y] == 1 && a[x + 1][y] == 1 && a[x][y + 1] == 1 && a[x + 1][y + 1] == 1)
			{
				cout << i << endl;
				return 0;
			}
		}
		if (x < n && y > 1)
		{
			if (a[x][y] == 1 && a[x + 1][y] == 1 && a[x][y - 1] == 1 && a[x + 1][y - 1] == 1)
			{
				cout << i << endl;
				return 0;
			}
		}
	}
	cout << 0 << endl;
	return 0;
}