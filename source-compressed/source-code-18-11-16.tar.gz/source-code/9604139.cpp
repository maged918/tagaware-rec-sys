//Language: GNU C++


#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cassert>
#include<stack>
#include<cstring>
#include<vector>
#include<string>
#include<cmath>
#include<ctime>
#include<set>
#include<map>
#include<queue>
#include<fstream>
#include<sstream>
#include<iomanip>

#define mp(makepairtmp1,makepairtmp2) make_pair(makepairtmp1,makepairtmp2)

using namespace std;

//def
const int MOD = 10;
typedef long long ll;
typedef long double ld;
const double eps = 1e-5;
const int maxN = 3 * 1000 * 10 + 1000;
const int inf = 1e9;
int n, d;
long long dp[maxN][900];
int num[maxN];

//init
inline void init()
{
    cin >> n >> d;
    for (int i = 0; i < n; i++)
    {
        int now;
        cin >> now;
        num[now]++;
    }
}

//Solve
inline void solve()
{
    for (int i = 0; i < maxN; i++)
        for (int j = 0; j < 900; j++)
            dp[i][j] = (-maxN) * 2;
    dp[d][420] = num[d];
    long long ans = 0;
    ans = num[d];
    for (int i = d + 1; i < 30001; i++){
        for (int j = max(d - 400, 1); j < d + 400; j++){
            if (i < j)
                continue;
            if (d - j + 420)
                dp[i][d - j + 420] = max(dp[i - j][d - j + 420] + num[i], dp[i][d - j + 420]);
            if (d - j + 420 - 1)
                dp[i][d - j + 420] = max(dp[i - j][d - j + 420 - 1] + num[i], dp[i][d - j + 420]);
            if (d - j + 420 + 1)
                dp[i][d - j + 420] = max(dp[i - j][d - j + 420 + 1] + num[i], dp[i][d - j + 420]);
            ans = max(ans, dp[i][d - j + 420]);
            //          if(num[i] && i < 29)
            //          cerr << i << ' ' << j << ' ' << dp[i][d-j+420] << endl;
        }
    }
    cout << ans << endl;
}


int main()
{
    ios_base::sync_with_stdio(0);
    //freopen("f.in", "r", stdin);
    //freopen("f.out", "w", stdout);
    init();
    solve();
    //system("pause");
    return 0;
}