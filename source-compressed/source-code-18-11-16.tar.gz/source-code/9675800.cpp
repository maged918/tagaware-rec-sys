//Language: GNU C++


#include"iostream"
#include"cstdio"
#include"algorithm"
using namespace std;
const int maxn = 100100;
int a[maxn],b[maxn];
int n,x;

int main()
{
    int i,j,res = 0;
    scanf("%d%d",&n,&x);
    for(i = 1; i<=n; ++i) {
        scanf("%d",&a[i]);
    }
    for(i = 1; i<=n; ++i) {
        scanf("%d",&b[i]);
    }
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    for(i = 1,j = n; i<=n; i++) {
        if(a[i]+b[j]>=x) {
            --j;
            ++res;
        }
    }
    printf("1 %d\n",res);
}

	  		  	 			    			  	    	 		