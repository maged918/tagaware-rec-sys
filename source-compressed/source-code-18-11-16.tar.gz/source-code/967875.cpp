//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<vector>
#include<algorithm>

using namespace std; 

#define vc vector
#define fr(i,n) for(int i=0; i<n; i++) 

string sa,sb,sc; 
int n,a,b,c; 

int id(string s) {
		if (s== "Anka") return 1;  
		if (s== "Chapay") return 2;
		if (s== "Cleo") return 3;  
		if (s== "Troll") return 4;
		if (s== "Dracul") return 5;  
		if (s== "Snowy") return 6;
		if (s== "Hexadecimal") return 7;  
		return -1; 
}

int x[100], y[100],p[100],q[100],z[100],ans,ans2;

int main() {
//	freopen("in","r",stdin);
//	freopen("out","w",stdout);
		cin >>n; 
		fr(i,n) {
			cin >> sa >> sb >> sc; 
			x[i] = id(sa); 
			y[i] = id(sc);
		}

		cin >> q[0] >> q[1] >> q[2]; 

		long long ans=2*1000000000; 
		for (int i=0; i<2297; i++) {
			int xx=i; 
			for (int j=1; j<=7; j++) {
				p[j]=xx%3;
				xx/=3; 	
			}

			bool ok=true; 
			fr(j,3) {
				int cnt=0;
				for (int k=1; k<=7; k++) if (p[k]==j) cnt++; 
				if (cnt==0) {ok=false; break;}
				z[j] = q[j]/cnt; 
			}
			if (ok)  {
			if (ans > max(z[0],max(z[1],z[2])) - min(z[0],min(z[1],z[2]))) {
				ans= max(z[0],max(z[1],z[2])) - min(z[0],min(z[1],z[2])); 
				int w=0; 
				fr(j,n) if (p[x[j]] == p[y[j]]) w++; 
				ans2=w; 
			} else
			if (ans == max(z[0],max(z[1],z[2])) - min(z[0],min(z[1],z[2]))) {
				ans= max(z[0],max(z[1],z[2])) - min(z[0],min(z[1],z[2])); 
				int w=0; 
				fr(j,n) if (p[x[j]] == p[y[j]]) w++; 
				ans2=max(w,ans2); 
			}
			}

		} 
		cout << ans <<" " << ans2; 
	return 0; 
}

