//Language: GNU C++0x


#include<bits/stdc++.h>
#define N 200005
using namespace std;
int n;
int a[N],b[N], bit[N];

int sum(int x){
    int ret = 0;
    while(x){
        ret += bit[x];
        x-= x&-x;
    }
    return ret;
}

void update(int v, int x){
    while(x <= n){
        bit[x] += v;
        x+= x&-x;
    }
}

void toFac(int *arr){
    memset(bit,0,sizeof(bit));
    for(int i=1; i<=n;i++){
        int tmp = arr[i]  + sum(arr[i]+1);
        update(-1, arr[i]+1);
        arr[i] = tmp;
    }
}

int main(){
    scanf("%d", &n);
    for(int i=1; i<=n;i++) scanf("%d", &a[i]);
    for(int i=1; i<=n;i++) scanf("%d", &b[i]);

    toFac(a); toFac(b);
    for(int i=1; i<=n;i++) a[i] += b[i];
    for(int i=n; i>=1;i--)
        if(a[i] > n-i){ a[i-1]+= a[i]/(n-i+1); a[i]%= n-i+1;}
    
    
    
    memset(bit, 0, sizeof(bit));
    for(int i=1; i<=n;i++){
        int L = 1, R = n, M, ans;
        while(L <= R){
            M = L + (R-L)/2;
        //  printf("%d %d %d\n", M, sum(M), a[i]);
            if(M + sum(M) - 1 >= a[i]){ans = M-1; R = M-1;}
            else L = M+1;
        }
        update(-1, ans+1);
        printf("%d ", ans);
    }
    
    return 0;   
}