//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstdlib>
#include <cmath>

#define x 501

using namespace std;

int n,m,d,e,a[x],b[x],c[x],g[x],sh[x],cost[x],p[x],ans[x][x],ma[x],sum;

int main() {

//	freopen("zadb.in","r",stdin);

	cin >> n;
	for (int i=0; i<n; i++)  {
		cin >> a[i] >> b[i] >> c[i];
		p[i]=2*(a[i]+b[i]);
	}
	cin >> m;
	for (int i=0; i<m; i++)
		cin >> g[i] >> sh[i] >> cost[i];



//	for (int i=0; i<n; i++) cerr << p[i];	

   	for (int i=0; i<n; i++) {
   		for (int j=0; j<m; j++) {
            d=g[j]/c[i]*sh[j];
         //   cout << d << " ";
         if (d!=0) {
   			if (p[i] % d == 0 )    e=p[i]/d;    else e=p[i]/d+1;
   		//	cout << e << " ";
   			ans[i][j]=cost[j] * e;
   		//	cout << ans[i][j] << endl;
   		} else ans[i][j]=2000000000;
   		}
    }

    //	for (int i=0; i<n; i++) cerr << p[i];	
   			
   for (int i=0; i<n; i++) {
   	ma[i]=ans[i][0];
   	for (int j=0; j<m; j++) {
   		if (ans[i][j]<ma[i]) 
   			ma[i]=ans[i][j];
   	}
   }

   for (int i=0; i<n; i++)
  	 sum+= ma[i];

   	cout << sum <<endl; 


return 0;
}