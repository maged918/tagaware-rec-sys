//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
struct Book
{
    int t,w;
}book1[105],book2[105];
int sum1[105],sum2[105];
bool cmp(Book a,Book b)
{
    return a.w>b.w;
}
int main()
{
    int n;
    cin>>n;
    int i,j,t1=0,t2=0;
    for(i=1;i<=n;++i)
    {
        int t,w;
        scanf("%d%d",&t,&w);
        if(t==1) {book1[++t1].t=t;book1[t1].w=w;}
        else {book2[++t2].t=t;book2[t2].w=w;}
    }
    sort(book1+1,1+book1+n,cmp);
    sort(book2+1,1+book2+n,cmp);
    sum1[0]=sum2[0]=0;
    for(i=1;i<=t1;++i) sum1[i]=sum1[i-1]+book1[i].w;
    for(i=1;i<=t2;++i) sum2[i]=sum2[i-1]+book2[i].w;
    int ans=0x3f3f3f3f;
    for(i=0;i<=t1;++i)
        for(j=0;j<=t2;++j)
        {
            if(i+2*j>=sum1[t1]-sum1[i]+sum2[t2]-sum2[j])
                ans=min(ans,i+2*j);
        }
    cout<<ans<<endl;
    return 0;
}

	    		 	  	     			 	   				