//Language: GNU C++


#include <iostream>
#include <vector>
using namespace std;
const int max_n = 100000;
bool mark1[max_n];
bool mark[max_n];
vector<int>adj[max_n];
vector<int>ans;
int par[max_n];
void dfs(int v)
{
    mark[v] = true;
    ans.push_back(v);
    mark1[v] = !mark1[v];
    for(int i=0;i<adj[v].size();i++)
    {
        int u = adj[v][i];
        if(mark[u]==false)
        {
            dfs(u);
            ans.push_back(v);
            mark1[v] = !mark1[v];
            if(mark1[u]==true)
            {
                mark1[v] = !mark1[v];
                mark1[u] = false;
                ans.push_back(u);
                ans.push_back(v);
            }
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++)
    {
        int u,v;
        cin>>u>>v;
        u--,v--;
        adj[v].push_back(u);
        adj[u].push_back(v);
    }
    for(int i=0;i<n;i++)
        cin>>mark1[i];
    for(int i=0;i<n;i++)
    {
        if(mark1[i])
        {
            dfs(i);
            if(mark1[i])
                ans.pop_back();
            break;
        }
    }
    for(int i=0;i<n;i++)
        if(mark1[i]&&mark[i]==false)
        {
            cout<<-1<<endl;
            return 0;
        }
    cout<<ans.size()<<endl;
    for(int i=0;i<ans.size();i++)
        cout<<ans[i]+1<<" ";
    cout<<endl;
    return 0;
}