//Language: MS C++


#include <iostream>
using namespace std;

int max(int a, int b){
	return (a > b) ? a : b;
}

int main()
{
	int r, g, b;
	cin >> r >> g >> b;
	cout << max(max(3 * ((r + 1) / 2) + 27, 3 * ((b + 1) / 2) + 29), 3 * ((g + 1) / 2) + 28);
	return 0;
}