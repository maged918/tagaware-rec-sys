//Language: GNU C++0x


#include<iostream>
using namespace std;


int main(){
	int n , x ;
	cin >> n >> x;
	int ans = 0;
	int a  ,b ;
	cin >> a >> b;
	ans += b - a + 1;
        ans += ( a - 1 ) % x;
	int last = b;
	for( int i = 1 ; i < n ; ++i ){
		cin >> a >> b; 
		ans += ( a  - last  - 1  ) %  x;
		ans += b - a + 1 ;
		last = b;
	}
	cout << ans <<endl;
	return 0;
}



