//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
#define pb push_back
const long long int MAXN=10e5+3;
long long int a[MAXN];
long long int BS(long long int key,long long int a[],long long int first,long long int last)
{
    long long int mid=(first+last)/2;
    if(first>last)
        return 0;
    if(key>a[mid])
        first=mid+1;
    else if(key==a[mid])
        return 1;
    else
        last=mid-1;
    BS(key,a,first,last);
}

int main()
{
    #define int long long int
    int n,l,x,y;
    cin>>n>>l>>x>>y;
    for(int i=0;i<n;i++)
        cin>>a[i];
    int u1=0,u2=0;
    vector<int> v1;
    vector<int> v2;
    for(int i=0;i<n;i++)
    {
        int key1=a[i]-x;
        int key2=a[i]+x;
        int ans1=BS(key1,a,0,n-1);
        int ans2=BS(key2,a,0,n-1);
        if(ans1==1||ans2==1)
            u1=1;
        if(key1>=0&&key1<=l)
            v1.pb(key1);
        if(key2>=0&&key2<=l)
            v1.pb(key2);
    }
    for(int i=0;i<n;i++)
    {
        int key1=a[i]-y;
        int key2=a[i]+y;
        int ans1=BS(key1,a,0,n-1);
        int ans2=BS(key2,a,0,n-1);
        if(ans1==1||ans2==1)
            u2=1;
        if(key1>=0&&key1<=l)
            v2.pb(key1);
        if(key2>=0&&key2<=l)
            v2.pb(key2);
    }
    if(u1==1&&u2==1)
    {
        cout<<0;
        return 0;
    }
    if(u1==1&&u2==0)
    {
        cout<<1<<endl<<y;
        return 0;
    }
    if(u1==0&&u2==1)
    {
        cout<<1<<endl<<x;
        return 0;
    }
    sort(v2.begin(),v2.end());
    int c[v2.size()];
    for(int i=0;i<v2.size();i++)
        c[i]=v2[i];
    for(int i=0;i<v1.size();i++)
    {
        int ans =BS(v1[i],c,0,v2.size()-1);
        if(ans==1)
        {
            cout<<1<<endl<<v1[i];
            return 0;
        }
    }
    cout<<2<<endl<<x<<" "<<y;
    return 0;
}