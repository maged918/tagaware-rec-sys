//Language: GNU C++


/* 

   SHUBHAM RAI-IIIT Hyderabad

 */
#include<bits/stdc++.h>
using namespace std;
#define FOR(i,a,b) for(i=a;i<b;i++)
#define REP(i,a) for(i=0;i<a;i++)
#define LLD long long int
#define MOD 1000000007
#define si(n) scanf("%d",&n);
#define si2(n,m) scanf("%d%d",&n,&m);
#define sl(n) scanf("%lld",&n);
#define TR(container,it) for(typeof(container.begin()) it=container.begin();it!=container.end();it++)
#define F first
#define S second
#define pb push_back
#define mp make_pair
typedef pair<int,int> PII;
#define TRACE

#ifdef TRACE
#define trace1(x)                cerr << #x << ": " << x << endl;
#define trace2(x, y)             cerr << #x << ": " << x << " | " << #y << ": " << y << endl;
#define trace3(x, y, z)          cerr << #x << ": " << x << " | " << #y << ": " << y << " | " << #z << ": " << z << endl;
#define trace4(a, b, c, d)       cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << endl;
#define trace5(a, b, c, d, e)    cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << endl;
#define trace6(a, b, c, d, e, f) cerr << #a << ": " << a << " | " << #b << ": " << b << " | " << #c << ": " << c << " | " << #d << ": " << d << " | " << #e << ": " << e << " | " << #f << ": " << f << endl;

#else

#define trace1(x)
#define trace2(x, y)
#define trace3(x, y, z)
#define trace4(a, b, c, d)
#define trace5(a, b, c, d, e)
#define trace6(a, b, c, d, e, f)

#endif


int main()
{
	string a,b;
	cin>>a>>b;
	int i,j,c=0,c1=0,freq[256]={0},freq1[256]={0},l=a.size(),l1=b.size();
	for(i=0;i<l;i++)
		freq[a[i]]++;
	for(i=0;i<l1;i++)
		freq1[b[i]]++;
	for(i=0;i<256;i++)
	{
		if(freq1[i]>=freq[i])
		{
			c+=freq[i];
			freq1[i]-=freq[i];
			freq[i]=0;
		}
		else
		{
			c+=freq1[i];
			freq[i]-=freq1[i];
			freq1[i]=0;
		}
	}
	for(i=0;i<256;i++)
	{
		if(freq[i])
		{
			if(freq1[i+32])
			{
				int t=freq[i];
				c1+=min(freq[i],freq1[i+32]);
				freq[i]-=min(freq[i],freq1[i+32]);
				freq1[i+32]-=min(t,freq1[i+32]);
			}
			if(freq1[i-32])
			{
				int t=freq[i];
				c1+=min(freq[i],freq1[i-32]);
				freq[i]-=min(freq[i],freq1[i-32]);
				freq1[i-32]-=min(t,freq1[i-32]);
			}
		}
	}
	cout<<c<<" "<<c1<<endl;
	return 0;
}
