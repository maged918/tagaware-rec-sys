//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <algorithm>
#define NMax 45

using namespace std;

int N;
long long  t[3][3];
long long T[NMax][3][3];

int main() {

#ifndef ONLINE_JUDGE
    freopen("in", "r", stdin);
#endif // ONLINE_JUDGE

    for ( int i = 0; i < 3; ++ i )
        for ( int j = 0; j < 3; ++ j )
            cin >> t[i][j];

    cin >> N;

    for ( int n = 1; n <= N; ++ n ) {

        for ( int a = 0; a < 3; ++ a ) for ( int b = 0; b < 3; ++ b ) if ( a != b ) {
            T[n][a][b] = T[n - 1][a][3 - a - b] + t[a][b] + T[n - 1][3 - a - b][b];

            T[n][a][b] = min ( T[n][a][b],
                T[n - 1][a][3 - a - b] + T[n - 1][3 - a - b][b] + t[a][b]);
            T[n][a][b] = min ( T[n][a][b],
                T[n - 1][a][3 - a - b] + T[n - 1][3 - a - b][a] + T[n - 1][a][b] + t[a][b]);
            T[n][a][b] = min ( T[n][a][b],
                2 * (T[n - 1][a][b]) + t[a][3 - a - b] + t[3 - a - b][b] +
                    T[n - 1][b][a]);


        }

        /*for ( int k = 0; k < 9; ++ k )
        for ( int a = 0; a < 3; ++ a ) for ( int b = 0; b < 3; ++ b ) if ( a != b )  {
            T[n][a][b] = min(T[n][a][b], T[n][a][3 - b - a] + T[n][3 - b - a][b]);
        }*/
    }
    cout << T[N][0][2] << endl;

    return 0;
}
