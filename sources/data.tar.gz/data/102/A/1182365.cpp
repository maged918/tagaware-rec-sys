//Language: GNU C++


#include<iostream>
#include<conio.h>
using namespace std;
bool a[110][110];
int cost[110];
int main()
{
    int n,m,x,y,ans=3111111;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    cin>>cost[i];
    for(int i=0;i<m;i++)
    {
    cin>>x>>y;
    a[x][y]=1;
    a[y][x]=1;
    }
    if(m<3)
    {
    cout<<-1;
    return 0;
    }
    int t=0;
    for(int i=1;i<=n;i++)
    for(int j=1;j<=n;j++)
    for(int d=1;d<=n;d++)
    {
            if(i!=j&&i!=d&&j!=d)
            if(a[i][j]&&a[i][d]&&a[j][d])
            {
            ans=min(ans,cost[i]+cost[j]+cost[d]);
            t=1;
}
}
     if(t==1)
     cout<<ans;
     else          
     cout<<-1;
    return 0;
    }
    
