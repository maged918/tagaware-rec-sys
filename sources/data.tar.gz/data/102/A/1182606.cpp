//Language: GNU C++


#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <vector>
#include <map>
#include <cstring>
#include <string>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <queue>
#include <stack>
#include <set>

using namespace std;

#define finp "102A.inp"
#define fout "102A.out"

#define fs first
#define sd second
#define PB push_back
#define MP make_pair
#define sz(a) (a.size())
#define sstr(s,a,b) (s.substr(a,b))
#define fillchar(a,v) memset(a,v,sizeof(a))
#define FOR(i,s,e) for(int i=(s);i<(e);i++)
#define FORD(i,s,e) for(int i=(e);i>(s);i--)
#define rep(i,d) for(int i=0;i<d;i++)
#define it_type(s) (s::iterator)

typedef long long llint;
typedef pair<int,int> II;

//Frequently used function(s)
static inline int rint(int &n){scanf("%d",&n); return n;}
static inline void wint(int n){printf("%d",n);}
static inline void wintln(int n){printf("%d\n",n);}

const int maxn=101;

int n,m;
int prices[maxn];
bool fr[maxn][maxn];

void enter(){
     scanf("%d%d",&n,&m);
     for (int i=1;i<=n;i++)
         scanf("%d",&prices[i]);
     fillchar(fr,false);
     int u,v;
     for (int i=1;i<=m;i++){
         scanf("%d%d",&u,&v);
         fr[u][v]=true;
         fr[v][u]=true;    
     }
}

void solve(){
     int res=1000000001,sum;
     for (int i=1;i<=n-2;i++)
         for (int j=i+1;j<=n-1;j++)
             for (int k=j+1;k<=n;k++)
                 if (fr[i][j] && fr[j][k] && fr[k][i]){
                     sum=prices[i]+prices[j]+prices[k];
                     if (sum < res) res=sum;            
                 }
     if (res == 1000000001) 
         printf("-1\n");
     else printf("%d\n",res);
}

int main(){
    //freopen(finp,"r",stdin);
    //freopen(fout,"w",stdout);
    enter();
    solve();
    return 0;    
}
