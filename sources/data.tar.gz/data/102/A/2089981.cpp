//Language: GNU C++


#include <cstdio>
#include <iostream>

using namespace std;

#define openfile {freopen("a.inp","r",stdin);}
#define debug 0

const int maxC = 2000000000;
int n, m, x, y, res;
bool match[105][105];
int a[105];

int main() {
    if (debug) openfile;
    scanf("%d%d",&n,&m);
    for (int i=0;i<n;i++) scanf("%d",&a[i]);
    for (int i=0;i<m;i++)
        scanf("%d%d",&x,&y), match[x-1][y-1] = true, match[y-1][x-1] = true;
    res = maxC;
    for (int i=0;i<n-2;i++)
    for (int j=i+1;j<n-1;j++)
    for (int k=j+1;k<n;k++)
        if (match[i][j]&&match[j][k]&&match[k][i]) 
            res = min(res,a[i]+a[j]+a[k]);
    if (res==maxC) printf("-1\n");
    else printf("%d\n",res);
}
