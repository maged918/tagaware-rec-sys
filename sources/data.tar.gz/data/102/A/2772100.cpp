//Language: GNU C++


#include <cstdlib>
#include <cstdio>
#include<iostream>
#include<cstring>
#define INF 10000000
using namespace std;
int a[105][105];
int main(){
    int n,m;
    int v[110];
    int x,y;
    while(cin>>n>>m){
        memset(a,0,sizeof(a));
        for(int i=1;i<=n;i++)
             cin>>v[i];
        for(int i=0;i<m;i++){
              cin>>x>>y;
              a[x][y]=a[y][x]=1;
        }
        int min=INF;
        for(int i=1;i<=n;i++)
           for(int j=1;j<=n;j++)
              for(int k=1;k<=n;k++)
                 if(a[i][j]&&a[i][k]&&a[k][j]){
                        int t=v[i]+v[k]+v[j];
                        if(t<min)
                          min=t;
                 }
        if(min==INF)
          cout<<-1<<endl;
        else
          cout<<min<<endl;



    }



}
