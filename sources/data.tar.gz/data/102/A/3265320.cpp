//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;

const int NN = 110;

int n,m,mt[NN][NN],p[NN];

int main()
{
    memset(mt,false,sizeof(mt));
    cin >> n >> m;
    for (int i=1; i<=n; i++) cin >> p[i];
    for (int i=1; i<=m; i++)
    {
        int x,y;
        cin >> x >> y;
        mt[x][y]=mt[y][x]=1;
    }
    int ans=0x7f7f7f7f;
    for (int i=1; i<=n; i++)
      for (int j=i+1; j<=n; j++) if (mt[i][j])
        for (int k=j+1; k<=n; k++) if (mt[i][k] && mt[j][k])
        {
            if (p[i]+p[j]+p[k]<ans) ans=p[i]+p[j]+p[k];
        }
    if (ans==0x7f7f7f7f) cout << -1 << endl;
    else cout << ans << endl;
    return 0;
}

	  		  			  	     	  	   	