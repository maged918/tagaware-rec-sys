//Language: GNU C++


#include <iostream>
#include <cstring>
using namespace std;
const int maxn=100+5;
int a[maxn],map[maxn][maxn];
int main()
{
    int n,m;
    cin>>n>>m;
    memset(map,0,sizeof(map));
    for(int i=1;i<=n;i++) cin>>a[i];
    while(m--){
        int u,v;
        cin>>u>>v;
        map[u][v]=map[v][u]=1;
    }
    int Min=-1;
    for(int i=1;i<=n;i++)
        for(int j=i+1;j<=n;j++)
            for(int k=j+1;k<=n;k++)
                if(map[i][j]&&map[j][k]&&map[k][i]){
                    if(Min!=-1) Min=min(Min,a[i]+a[j]+a[k]);
                    else Min=a[i]+a[j]+a[k];
                }
    cout<<Min<<endl;
    return 0;
}