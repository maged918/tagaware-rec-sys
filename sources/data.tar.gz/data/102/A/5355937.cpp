//Language: GNU C++


#include<stdio.h>
int main(){
	int n, m;
	while (scanf("%d%d", &n, &m) == 2){
		int price[100] = { 0 };
		bool C[100][100] = { false };
		for (int i = 0; i < n; i++)
			scanf("%d", &price[i]);
		for (int i = 0; i < m; i++){
			int a, b;
			scanf("%d%d", &a, &b);
			a--, b--;
			C[a][b] = C[b][a] = true;
		}
		int ans = 2e9;
		for (int i = 0; i < n; i++){
			for (int j = i + 1; j < n; j++){
				for (int k = j + 1; k < n; k++){
					if (C[i][j] && C[j][k] && C[i][k]){
						int cost = price[i] + price[j] + price[k];
						if (ans>cost)
							ans = cost;
					}
				}
			}
		}
		
		if (ans == 2e9)
			ans = -1;
		printf("%d\n", ans);
	}
	return 0;
}