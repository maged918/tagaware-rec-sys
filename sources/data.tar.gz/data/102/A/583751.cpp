//Language: MS C++


#include<stdio.h>
#include<algorithm>
#include<string.h>
#include<vector>
#define rep(i,n) for (int i=0; i<(int)n; i++)

using namespace std;

int c[110][110];
int p[110];

int main (void) {
	int m,n,c1,c2;
	
	memset(c,0,sizeof(c));
	
	scanf("%d %d",&n,&m);
	rep(i,n+1) if(i) scanf("%d",&p[i]);
	rep(i,m) {
		scanf("%d %d",&c1,&c2);
		c[c1][c2] = 1;
		c[c2][c1] = 1;
	}
	
	int s = 123456789;
	
	for (int i = 1; i <= n; i++ )
		for (int j = i+1; j <= n; j++ )
			for (int k = j+1; k <= n; k++)
				if ( c[i][j] && c[i][k] && c[j][k] )
					s = min(s, p[i]+p[j]+p[k]);
	
	if ( s == 123456789 ) s = -1;
	printf("%d\n",s);
}
