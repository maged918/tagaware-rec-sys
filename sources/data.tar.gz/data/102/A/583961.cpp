//Language: GNU C++


#include <iostream>
#include <vector>
#include <stack>
#include <set>
#include <map>
#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <algorithm>
#define INFY 1000000000
#define MAXN 100
using namespace std;

int a[MAXN];
int ke[MAXN][MAXN];

int main(){
    //freopen("in.txt", "r", stdin);
    //freopen("out.txt", "w", stdout);
    int n, i, m, j, k;
    scanf("%d %d", &n, &m);
    for(i=0 ; i<n ; i++){
         scanf("%d", &a[i]);
    }
    for(i=0 ; i<m ; i++){
         scanf("%d %d", &j, &k);
         j--;k--;
         ke[j][k] = ke[k][j] = 1;
    }
    int kq=INFY;
    for(i=0 ; i<n ; i++){        
        for(j=i+1 ; j<n ; j++){
            for(k=j+1; k<n ; k++){
                if(ke[i][j] && ke[j][k] && ke[k][i] && kq>a[i]+a[j]+a[k])
                    kq=a[i]+a[j]+a[k];
            }
        }
    }
            
    if(kq<INFY) cout<<kq;
    else cout<<-1;
    return 0;
}
