//Language: GNU C++


#include <cstdlib>
#include <iostream>
#include <stdio.h>
using namespace std;

int main(int argc, char *argv[])
{
	int i,j,k,n,m,price[101],a,b,ans;
	bool match[102][102];
	
	for(i=0;i<102;i++) 
		for(j=0;j<102;j++)
			match[i][j]=false;
	
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++) scanf("%d",&price[i]);
	for(i=0;i<m;i++)
	{
		scanf("%d %d",&a,&b);
		match[a][b]=true;
		match[b][a]=true;
	}
	
	ans=3000001;
	for(i=1;i<n;i++)
		for(j=i+1;j<=n;j++)
			if(match[i][j])
				for(k=1;k<=n;k++)
					if(match[i][k]&&match[k][j]&&k!=i&&k!=j)
						ans=min(price[i]+price[j]+price[k],ans);
					
	if(ans==3000001) printf("-1\n");	
	else printf("%d\n",ans);
	
  //  system("PAUSE");
    return EXIT_SUCCESS;
}
/****** PCCA -Thu Aug 04 08:17:11 GMT 2011 *******/