//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <map>
#define FOR(i,s,n) for(int(i)=(s);(i)<(n);(i)++)
#define DFOR(i,s,n) for(int(i)=(s);(i)>(n);(i)--)
#define SZ(v) (int)(v).size()
#define RESET(v,n) memset((v),(n),sizeof((v)))
#define PII pair<int,int>
#define PFF pair<double,double>
#define eps 1e-8
#define isEQF(f,a) (abs((f)-(a)) < eps)
#define LL long long
#define DEBUG puts("OK")
#define x first
#define y second
#define mp(x,y) make_pair((x),(y))
#define pb(x) push_back(x)
using namespace std;

int mx[4] = {-1,0,1,0};
int my[4] = {0,1,0,-1};

inline void OPEN(string s) {
        freopen((s+ ".in").c_str(), "r",stdin );
        freopen((s+".out").c_str(), "w",stdout);
}

int main() {
        int n, m;
        int prices[120];
        int a, b;
        int connect[120][120];
        scanf("%d %d",&n,&m);
        for (int i=1; i<=n; i++) {
                scanf("%d",&prices[i]);
        }
        for (int i=0; i<m; i++) {
                scanf("%d %d", &a, &b);
                connect[a][b] = true;
                connect[b][a] = true;
        }
        int price, ans = -1;
        FOR(i,1,n-1) {
                FOR(j,i+1,n) { if (connect[i][j])
                        FOR(k,j+1,n+1) { 
                                if (connect[i][k] && connect[j][k]) {
                                        price = prices[i] + prices[j] + prices[k];
                                        if (ans == -1) {
                                                ans = price;
                                        } else {
                                                ans = min(ans, price);
                                        }
                                }
                        }
                }
        }
        cout << ans << endl;
        return 0;
}