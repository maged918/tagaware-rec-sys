//Language: GNU C++


#include <iostream>
#include <cstdio>
using namespace std;

const int MAXN = 105;
const int oo = (int)1e9;

int v[MAXN], n, m;
bool a[MAXN][MAXN];

int main() {
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= n; i++)
        scanf("%d", v + i);
    for (int i = 0; i < m; i++) {
        int x, y; scanf("%d %d", &x, &y);
        if (x > y) swap(x, y);
        a[x][y] = true;
    }
    
    int res = oo;
    for (int i1 = 1; i1 <= n; i1++)
        for (int i2 = i1 + 1; i2 <= n; i2++)
            for (int i3 = i2 + 1; i3 <= n; i3++)
                if (a[i1][i2] && a[i1][i3] && a[i2][i3])
                    res = min(res, v[i1] + v[i2] + v[i3]);
                    
    cout << (res == oo ? -1 : res);
}