//Language: GNU C++


#include <cstdio>

int g[101][101];
int price[101];

int main(){
    int n,m;
    int x,y;
    scanf("%d%d",&n,&m);
    for(int i=0;i<n && ~scanf("%d",&price[i]);++i);
    for(int i=0;i<m && ~scanf("%d%d",&x,&y);++i) g[--x][--y]=g[y][x]=1;
    int max=-1,pos;
    for(int i=0;i<n;++i)
        for(int j=i+1;j<n;++j){
            if(g[i][j])
                for(int k=0;k<n;++k)
                    if(g[j][k] && g[k][i]){
                        pos=price[i]+price[j]+price[k];
                        if(max==-1 || max>pos) max=pos;
                    }
        }
    printf("%d\n",max);
    return 0;
}