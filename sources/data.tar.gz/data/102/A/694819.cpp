//Language: GNU C++


#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <set>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <queue>

using namespace std;

int main ()
{
	int n, m;
	while(cin>>n>>m)
	{
		int v[n];
		for(int i=0; i<n; i++)
			cin>>v[i];
		
		int adj[n][n];
		memset(adj, 0, sizeof(adj));
		
		for(int i=0; i<m; i++)
		{
			int a, b;
			cin>>a>>b;
			a--;
			b--;
			
			adj[a][b] = 1;
			adj[b][a] = 1;
		}
		
		int minN = 1<<30;
		
		for(int i=0; i<n; i++)
			for(int j=0; j<n; j++)
				for(int k=0; k<n; k++)
					if(adj[i][j] && adj[j][k] && adj[i][k])
						minN = min(minN, v[i] + v[j] + v[k]);
		
		if(minN == (1<<30)) cout<<-1<<endl;
		else cout<<minN<<endl;
	}
	
	return 0;
}
