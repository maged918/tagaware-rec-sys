//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
#define rep(i,a,b)	for (int i=a;i<(b+1);i++)
using namespace std;
int mp[150][150]={0},v[150]={0};
int main(){
	int n,m;
	scanf("%d%d",&n,&m);
	memset(mp,0,sizeof mp);
	rep(i,1,n)	scanf("%d",&v[i]);
	rep(i,1,m){
		int a,b;
		scanf("%d%d",&a,&b);
		mp[a][b]=v[a];
		mp[b][a]=v[b];
	}
	int ans=0x3f3f3f3f;
	rep(i,1,n)	rep(j,1,n)	rep(k,1,n){
		if (i==j||j==k||i==k)	continue;
		if (mp[i][j]>0&&mp[j][k]>0&&mp[k][i]>0&&(mp[i][j]+mp[j][k]+mp[k][i])<ans)	ans=mp[i][j]+mp[j][k]+mp[k][i];
	}
	if (ans==0x3f3f3f3f)	ans=-1;
	printf("%d\n",ans);	
	return 0;
}
 				   			 				   	 		   	