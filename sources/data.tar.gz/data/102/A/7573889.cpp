//Language: GNU C++


#include<iostream>
#include <stack>
#include <queue>
#include <string>
#include <memory>
#include <memory.h>
#include <stdio.h>
#include <cmath>
#include <math.h>
#include<set>
#include<map>
#include<list>
#include <algorithm>
#include <vector>
using namespace std;

int g[105][105], ar[105];
int n, m;

int main() {
    scanf("%d%d", &n, &m);
    int i ,j ,k , u, v, sum = 100000000, twin;
    memset(g, 0, sizeof(g));
    for (i = 1; i <= n; i++)
        scanf("%d", &ar[i]);
    for (i = 1; i <= m; i++) {
        scanf("%d%d", &u, &v);
        g[u][v] = g[v][u] = 1;
    }
    
    for (i = 1; i <= n; i++)
        for (j = i + 1; j <= n; j++)
            for (k = j + 1; k <= n; k++)
                if (g[i][j] && g[i][k] && g[j][k]) {
                    twin = ar[i] + ar[j] + ar[k];
                    if (twin < sum)
                        sum = twin;
                }
    if (sum != 100000000)
        printf("%d\n", sum);
    else
        puts("-1");
    return 0;
}