//Language: GNU C++



#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <cassert>
#include <algorithm>
#include <vector>
#include <set>
#include <map>
#include <bitset>
#include <stack>
#include <queue>
#include <deque>
#include <complex>

using namespace std;


#define pb push_back
#define len(s) (int)((s).size())
#define all(s) (s).begin(), (s).end()
#define mem(a, x)   memset(a, x, sizeof (a))
#define ff first
#define ss second
#define rep(i, n) for (int (i) = 0, j1234 = n; (i) < j1234; (i) ++)
#define For(i, a, b) for (int (i) = (a), ub1234=b; (i) < ub1234; (i) ++)
#define db(x) {cerr << #x << " = " << (x) << endl;}
#define dba(a, x, y) {cerr << #a << " :";For(i, (x), (y))cerr<<" "<<(a)[(i)];cout<<endl;}
#define FOREACH(a,b) for(typeof((b).begin()) a=(b).begin();a!=(b).end();++a)
#define ll long long
#define pii pair<int,int>
#define vi  vector<int>
#define vpii vector<pii>

const int INF = (1<<30);
const double eps = 1e-9;
const int MAXN = int(1e5) + 100;
const int dx[] ={-1,+1, 0, 0};
const int dy[] ={ 0, 0,-1,+1};

bool match[111][111];

int main() {
    ios::sync_with_stdio(false);

    //  freopen("input.txt","r",stdin);

    int n , m; cin >> n >> m;
    vi pr(n) ;
    rep(i, n) cin >> pr[i];

    mem(match, false);
    rep(i, m) {
        int x, y; cin >> x >> y;
        match[x][y] = true;
        match[y][x] = true;
    }

    int ans=INF;

    for(int i=1 ; i<=n ; i++) for(int j=i+1 ; j<=n ; j++) for(int k=j+1 ; k<=n ; k++)
    {
        if(match[i][j] && match[j][k] && match[k][i])
        {
            ans = min(ans, pr[i - 1] + pr[j - 1] + pr[k - 1]);
        }
    }

    if(ans == INF) ans = -1;
    cout << ans << endl;


    return 0;
}
