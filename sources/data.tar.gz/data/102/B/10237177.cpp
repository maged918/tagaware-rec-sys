//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
int sumofdigits(int n)
{
	int sum1=0;
while(n>0)
{
sum1=sum1+n%10;
n=n/10;
}
return sum1;

}

int main()
{
	long int i,sum,ans;
string str;
cin>>str;
sum=0;
for(i=0;i<str.length();i++)
sum=sum+str[i]-48;
ans=0;
if(str.length()==1)
{
printf("0");
return 0;
}
while(1)
{
if(sum<10)
break;	
ans++;
sum=sumofdigits(sum);

}

cout<<ans+1;






return 0;
}
