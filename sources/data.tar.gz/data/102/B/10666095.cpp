//Language: GNU C++11


#include<iostream>
#include<cstdio>
#include<stack>
#include<vector>
#include<cstring>
#include<sstream>
#include<cmath>
#include<map>
#include<queue>
#include<algorithm>
#include<cstdlib>
using namespace std;
using ll = long long ;
#define sc(a) scanf("%d",&a)
#define scll(a) scanf("%lld",&a)
#define sc2(a,b) scanf("%d %d",&a,&b);
#define pr(a) printf("%d\n",a)
#define prll(a) printf("%lld\n",a)
#define wh(t); while(t--)
#define mp make_pair
#define pb push_back
#define MOD 1000000007
int main()
{
    string s;
    cin >> s;
    ll sum = 0;
    if (s.length() == 1)
        cout << 0;
    else
    {

        for (int i = 0; i < s.length(); i++)
            sum += (s[i] - '0');
        int count = 1;
        //cout << sum << endl;
        while (sum % 10 != sum)
        {
            ll sum2 = 0;
            while (sum)
            {
                sum2 += sum % 10;

                sum = sum / 10;
            }
            sum = sum2;
            count++;
        }
        cout << count;
    }
    return 0;
}