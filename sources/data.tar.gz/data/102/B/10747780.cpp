//Language: GNU C++


#include<iostream>
using namespace std;
long long rakm=0;
 long long se7s(long long x)
{  long long sum=0;
    if(x<10)
    return 1;
    else{
    while(x>0)
    {
      long long  y=x%10;
        x=x/10;  sum=sum+y;
    }
    rakm++;
}
    return se7s(sum);
}
int main()
{
    int sum8=0;
string x;
cin>>x;
if(x.size()==1)
cout<<0<<endl;
else
{
    for(int i=0;i<x.size();i++)
    {
        sum8+=x[i]-'0';
    }
    rakm++;
    se7s(sum8);
    cout<<rakm<<endl;
}
    return 0;
}