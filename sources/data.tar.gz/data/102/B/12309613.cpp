//Language: GNU C++


/*****************************************
Author      :Crazy_AC(JamesQi)
Time        :
File Name   :
*****************************************/
#include <iostream>
#include <algorithm>
#include <string>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include <set>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <limits.h>
using namespace std;
#define FILL(a,b) memset(a,b,sizeof a)
#define CLR(a) memset(a,0,sizeof a)
template<class T> inline T Get_Max(const T&a,const T&b) {return a < b?b:a;}
template<class T> inline T Get_Min(const T&a,const T&b) {return a < b?a:b;}
char s[100010];
long long sum;
int main()
{
    //freopen("in.txt","r",stdin);
    //freopen("out.txt","w",stdout);
    scanf("%s",s);
    int len = strlen(s);
    int cnt = 0;
    while(len > 1)
    {
        sum = 0;
        for (int i = 0;i < len;i++)
        {
            sum += s[i] - '0';
        }
        cnt++;
        // if (sum < 10) break;
        int top = 0;
        while(sum)
        {
            s[top++] = sum % 10 + '0';
            sum /= 10;
        }
        len = top;
    }
    printf("%d\n",cnt);
    return 0;
}