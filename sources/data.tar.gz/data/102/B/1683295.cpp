//Language: GNU C++


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define Max_Digit_Num 100001

char str[Max_Digit_Num+1];

int Cal_Rounds(int num)
{ 
 if(num<10)
  return 0;
  
 int sum=0;
 
 while(num)
 {
  sum+=num%10;
  num=num/10;
 }
 
 return 1+Cal_Rounds(sum);  
}

void SumOfDigits()
{
 int ndigits=0;
 int num=0;

 scanf("%s",str);
 ndigits=strlen(str);
    
 for(int i=0;i<ndigits;i++)
  num+=str[i]-'0';
    
 printf("%d\n",Cal_Rounds(num)+((ndigits==1)?0:1));
 
// system("pause");
}

int main()
{
 SumOfDigits();
 return 0;
}
