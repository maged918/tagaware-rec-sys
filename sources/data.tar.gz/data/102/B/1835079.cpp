//Language: GNU C++


#include<stdio.h>
#include<string.h>
long long count=1,i;
int total(long long sum)
    {long long n=0;
    if(sum<10){printf("%ld",count);return 0;}
    else
    count++;
    for(i=sum;i>0;i/=10)
        {
        n+=(i%10);
        }
       total(n);
    return 0;
    }
int main()
{
long long int i,sum=0;
char s[100100];
scanf("%s",s);
if(strlen(s)==1){printf("0");return 0;}
for(i=0;i<strlen(s);i++)
    {
    sum=(sum+s[i]-48);
    }
   total(sum);
return 0;
}