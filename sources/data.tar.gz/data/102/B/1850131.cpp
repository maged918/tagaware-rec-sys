//Language: GNU C++


#include <iostream>
#include <string>
using namespace std;

int suma (string n)
{
    int res = 0;
    for (int  i=0; i<n.length(); i++)
    {
        res = res + n[i] - '0';
    }
    return res;
}


int suma (int n)
{
    int res = 0;
    while (n)
    {
        res = res + n%10;
        n /= 10;
    }
    return res;
}



int spell(int n, int res)
{
    if (n < 10) return res;
    else return spell(suma(n), res+1);
}

int spell(string n, int res)
{
    if (n.length() < 2) return res;
    else return spell(suma(n), res+1);
}
int main()
{
    string n;
    while (cin>>n)
    {
        cout<<spell(n, 0)<<endl;
    }
    return 0;
}
