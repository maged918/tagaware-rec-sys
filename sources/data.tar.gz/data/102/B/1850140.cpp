//Language: GNU C++


#include <iostream>
#include <cstring>
#include <cstdlib>
using namespace std;
int main(){
    int ans=0;
    int sum=0,x,i;
    char s[100000];
    cin>>s;
    while (strlen(s)>1)
    {
        ans++;
        sum=0;for
        (i=0;i<(int)strlen(s);i++)
        {
            sum+=(s[i]-'0');
            }
            itoa(sum,s,10);
            }
            cout<<ans;
            return 0;
}
