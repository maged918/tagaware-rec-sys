//Language: GNU C++


#include<cstdio>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cctype>
#include<iostream>
using namespace std;
char a[1000000]={0};
int main()
{
    //freopen("Input.txt","r",stdin);
   // freopen("Output.txt","w",stdout);
   while(~scanf("%s",a))
   {
        long i,n,l,s=0,c=1,x,k=0,z;
   l=strlen(a);
   for(i=0;i<l;i++)
   s=s+a[i]-'0';
   if(l==1)
   printf("0\n");
   else
   {
       while(s>9)
       {
           x=s;
           s=0;
         while(x!=0)
         {
             s+=x%10;
             x/=10;

         }
         c++;
       }
       printf("%ld\n",c);

   }
   }
    return 0;
}
