//Language: GNU C++


#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<cstdlib>
#include<cstring>
#include<string>
#include<vector>
#include<stack>
#include<queue>
#include<map>

using namespace std;

int n;

char b[100010];

int main ()
{
  int sum=0,p=1,q,i;
  scanf ("%s",b);
  n=strlen (b);
  for (i=0;i<n;i++)
  sum+=b[i]-'0';
  while (sum>=10)
  {
    q=sum;
    sum=0;
    while (q!=0)
    {
      sum+=q%10;
      q/=10;
    }
    p++;
  }
  if(n==1)p=0;
  printf ("%d\n",p);
    return 0;
}