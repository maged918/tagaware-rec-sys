//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <string.h>
#include <string>
using namespace std;

string s;
int n;

int getSum(int k)
{
    int ans=0;
    while (k>0)
    {
        ans+=k%10;
        k/=10;
    }
    return ans;
}

int main()
{
    int i;
    while (cin>>s)
    {
        int t=0,l=s.length(),n=0;
        if (l==1)
        {
            printf("0\n");
            continue;
        }
        for (i=0;i<l;i++)
        {
            n+=s[i]-'0';
        }
        if (n<=9)
        {
            printf("1\n");
            continue;
        }
        t++;
        while (1)
        {
            t++;
            n=getSum(n);
            if (n<=9) break;
        }
        printf("%d\n",t);
    }
    return 0;
}
