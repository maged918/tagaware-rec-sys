//Language: GNU C++


#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <math.h>
#include <fstream>
#include <iostream>
#include <vector>
#include <deque>
#include <map>
#include <cstdlib>
using namespace std;

//Beta Round 79 Div2 Problem B codeforces.ru
//Disable warning messages C4996.
//#pragma warning(disable:4996)

#define INPUT_FROM 0
#if INPUT_FROM
#define fromc from
#else
#define fromc cin
#endif

//long long fr(vector<long long>&, long long);
string lltostr(long long);

int main(int argc, char **argv)
{
	//ifstream from;
	const long long nmin=1, nmax=1000;
	long long n, m, res, rt, i, j, k, t, ax, a, b, c;
	//char ch;
	//string sres[2]={"YES", "NO"};
	string s, st, sr;
	//long double dt;

	//if(INPUT_FROM) from.open("test.txt");
	//freopen("input.txt","r",stdin);
	//freopen("output.txt","w",stdout);

	//vector<long long> v;
	//deque<vector<long long> > dq;
	//map<long long, long long> mi;
	//map<long long, long long>::iterator it;
	//typedef map<string, long long>::const_iterator CI;

	fromc>>s;
	n=s.size();

	res=0;
	while(n>1){
		rt=0;
		for(i=0;i<n;i++) rt+=(s[i]-'0');
		s=lltostr(rt);
		n=s.size();
		res++;
	}

	cout<<res<<endl;

	return 0;
}

string lltostr(long long x){
	long long n, rt, i;
	char ch;
	string s, st;
	s=st="";
	n=0;
	if(x<0){
		s+='-';
		x=-x;
	}
	if(x==0) s="0";
	else{
		rt=x;
		while(rt>0){
			ch='0'+rt%10;
			st+=ch;
			rt/=10;
			n++;
		}
	}
	for(i=n-1;i>=0;i--) s+=st[i];
	return s;
}