//Language: GNU C++


#include <iostream>
#include <string>
#include <stdio.h>
using namespace std;

#define max_size 100000

int a[max_size][2];
int alen[2];

void a_add(int cur,int k)
{
    int i,temp=k;
    for(i=0;i<alen[cur];i++)
    {
        temp=a[i][cur]+temp;
        a[i][cur]=temp%10;
        temp/=10;
    }
    
    if(temp>0)
    {
        a[i][cur]=temp;
        alen[cur]++;
    }
}

int main()
{
#ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        freopen("output.txt","w",stdout);
#endif
    long col=0;
    int cur=0;
    int i,j,k;
    
    a[0][0]=0;
    a[0][1]=0;
    alen[0]=1;
    alen[1]=1;
    
    char c;
    
    
    i=0;
    while(scanf("%c",&c)==1 && c>='0' && c<='9')
    {
        a[i][cur]=c-'0';
        i++;
    }
    alen[cur]=i;
    
    while(alen[cur]>1)
    {
        a[0][1-cur]=0;
        alen[1-cur]=1;
        
        for(i=0;i<alen[cur];i++)
        {
            a_add(1-cur,a[i][cur]);
        }
        
        cur=1-cur;
        
        col++;
    }
    cout << col;
    return 0;
}
