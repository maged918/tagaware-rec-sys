//Language: MS C++


#include<iostream>
using namespace std;
#include<map>
const int lmax=1000005;
char s[lmax];
int main()
{
 int i,sum,ret=0;
 map<char,int> m;
 for(i=0;i<10;i++)  m[i+'0']=i;
 gets(s);
 while(strlen(s)!=1)
 {
  ret++;
  sum=0;
  int len=strlen(s);
  for(i=0;i<len;i++)
    sum+=m[s[i]];
  sprintf(s,"%d",sum);
 }
 printf("%d\n",ret);
}