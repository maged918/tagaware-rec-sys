//Language: GNU C++


#include <bits/stdc++.h>
using namespace std;

typedef long long lld;

const int N = 101000;
char s[N];

int work() {
        int len = strlen(s);
        if (len==1) return 0;
        lld x = 0;
        for (int i = 0; i < len; i ++)
                x += s[i]-'0';
        int ret = 1;
        while (x>=10) {
                lld y = 0;
                while (x) {
                        y += x%10;
                        x /= 10;
                }
                x = y;
                ret ++;
        }
        return ret;
}

int main() {
        scanf("%s",s);
        printf("%d\n",work());
        return 0;
}