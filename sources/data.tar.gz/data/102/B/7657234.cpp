//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
#define i64 unsigned long long int
int main()
{
	i64 a=0,counter=0,b=0;
	string str;
	cin>>str;
	for(i64 i=0;i<str.length();i++)
	a=a+int(str[i]-48);
	if(str.length()>1)
	counter=1;
	while(a>9)
	{
		while(a>=1)
		{
			b=b+a%10;
			a=a/10;
		}
		a=b;
		b=0;
		counter++;
	}
	cout<<counter<<endl;
	return 0;
}