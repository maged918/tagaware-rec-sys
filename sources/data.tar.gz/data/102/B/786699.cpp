//Language: GNU C++


#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

#define clr(x) memset((x), 0, sizeof(x))
#define pb push_back
#define mp make_pair
#define sz size()
#define For(i, st, en) for(int i=(st); i<=(int)(en); i++)
#define Ford(i, st, en) for(int i=(st); i>=(int)(en); i--)
#define forn(i, n) for(int i=0; i<(int)(n); i++)
#define ford(i, n) for(int i=(n)-1; i>=0; i--)
#define fori(it, x) for (__typeof((x).begin()) it = (x).begin(); it != (x).end(); it++)

template <class _T> inline _T sqr(const _T& x) { return x * x; }
template <class _T> inline string tostr(const _T& a) { ostringstream os(""); os << a; return os.str(); }

typedef long double ld;
typedef long long i64;

// Constants
const ld PI = 3.1415926535897932384626433832795;
const ld EPS = 1e-11;

// Types
typedef long long llint;
typedef set < int > SI;
typedef vector < int > VI;
typedef map < string, int > MSI;
typedef pair < int, int > PII;


#ifdef WINasdf32
    const bool LOCAL = true;
#else
    const bool LOCAL = false;

#endif


int main()
{
    time_t et_0 = clock();

//  freopen("circles.in", "rt", stdin);
//  freopen("circles.out", "wt", stdout);
    cout << setiosflags(ios::fixed) << setprecision(10);

    string str;
    getline(cin, str);
    vector<int> a(str.size());
    forn(i, str.sz) {
        a[i] = str[i] - '0';
    }

    if(a.sz == 1) {
        cout <<"0" << endl;
        return 0;
    }
    int count = 0;
    i64 sum = 0;
    while(true) {
        forn(i, a.sz) {
            sum += a[i];
        }
        count++;
        if(sum < 10) break;
        string  tmp = tostr(sum);
        forn(i, tmp.sz) {
            sum = 0;
            a.resize(tmp.sz);
            a[i] = tmp[i] - '0';
        }

    }

    cout << count << endl;

    if( LOCAL ) {
        time_t et_1 = clock();
        fprintf(stderr, "\nExecution time = %0.0lf ms\n", (et_1 - et_0) * 1000.0 / CLOCKS_PER_SEC);
    }
    return 0;
}
