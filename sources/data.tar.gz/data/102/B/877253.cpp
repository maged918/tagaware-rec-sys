//Language: MS C++


#include <iostream>;
#include <math.h>;
#include <string>;

using namespace std;

int main()
{
    int n=0,sum=10;
    string s;
    cin>>s;
    if (s.length()==1){cout<<0;}
    else
    {
        string s1=s;
        while (sum>=10)
        {
            s=s1;
            sum=0;
            n++;
            for (int i=0;i<s.length();i++)
            {
                sum+=int(s[i])-int('0');
            }
            int k=sum;
            s1="";
            while (k>0)
            {
                int l=k%10+int('0');
                //cout<<char(l)<<" ";
                s1=(char(k%10+int('0')))+s1;
                k/=10;
            }
        }
        cout<<n;
    }
}