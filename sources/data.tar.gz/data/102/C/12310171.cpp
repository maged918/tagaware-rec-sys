//Language: GNU C++


/*****************************************
Author      :Crazy_AC(JamesQi)
Time        :
File Name   :
*****************************************/
#include <iostream>
#include <algorithm>
#include <string>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include <set>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <limits.h>
using namespace std;
#define FILL(a,b) memset(a,b,sizeof a)
#define CLR(a) memset(a,0,sizeof a)
template<class T> inline T Get_Max(const T&a,const T&b) {return a < b?b:a;}
template<class T> inline T Get_Min(const T&a,const T&b) {return a < b?a:b;}
int cnt[30],k,sum,pos,mark[200];
vector<pair<int,int> > vec;
string s;
int main()
{
	// freopen("in.txt","r",stdin);
	//freopen("out.txt","w",stdout);
	cin >> s >> k;
	int len = s.size();
	for (int i = 0;i < len;i++)
	{
		cnt[s[i] - 'a']++;
	}
	for (int i = 0;i < 26;i++)
	{
		vec.push_back(make_pair(cnt[i],'a' + i));
	}
	sort(vec.begin(),vec.end());
	pos = 26;
	for (int i = 0;i < vec.size();i++)
	{
		if (sum + vec[i].first <= k)
			sum += vec[i].first;
		else
		{
			pos = i;
			break;
		}
	}
	for (int i = 0;i < pos;i++)
	{
		mark[vec[i].second] = 1;
	}
	cout << 26 - pos << endl;
	for (int i = 0;i < len;i++)
	{
		if (!mark[s[i]])
			printf("%c",s[i]);
	}
	printf("\n");
	return 0;
}
				        				 	   		  						