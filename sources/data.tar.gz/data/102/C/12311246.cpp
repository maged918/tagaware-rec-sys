//Language: GNU C++


#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<math.h>
#include<queue>
#include<stack>
#include<limits.h>
using namespace std;
#define INF 3000001
#define p(x) ((x)*(x))
typedef long long ll ;
struct node{
    int x;
    char c;
}b[30];
bool cmp(node a,node b)
{
    return a.x<b.x;
}
int main()
{
       string s;
       int k;
       while(cin>>s>>k)
       {
            int len=s.length();
            for(int i=0;i<26;i++)
            {
                b[i].x=0;
                b[i].c='a'+i;
            }
            for(int i=0;i<len;i++)
            {
                b[s[i]-'a'].x++;
            }
            sort(b,b+26,cmp);
            for(int i=0;i<26;i++)
            {
                if(k>=b[i].x&&b[i].x!=0)
                {
                     k-=b[i].x;
                     b[i].x=-1;
                }
            }
            int ans=0;
            for(int i=0;i<26;i++)
                if(b[i].x>0)
                    ans++;
            cout<<ans<<endl;
            for(int i=0;i<len;i++)
                for(int j=0;j<26;j++)
                {
                    if(s[i]==b[j].c&&b[j].x>0)
                        cout<<s[i];
                }
            cout<<endl;
       }
}

			  	   				 		 	 	       			