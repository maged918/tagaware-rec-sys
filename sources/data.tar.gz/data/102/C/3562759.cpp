//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#include <map>
#include <set>
#include <vector>
#include <queue>
#include <cmath>
#define N 100005
#define INF 0x6f6f6f6f
#define debug(a) cout<<#a<<' '<<a<<endl;
typedef long long LL;
using namespace std;
char str[N];
struct node
{
    int x,y;
    friend bool operator<(node a,node b)
    {
        return a.x<b.x;
    }
}a[30];
bool cmp1(node a,node b)
{
    return a.y<b.y;
}
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("in.txt","r",stdin);
    #endif

    int k;
    while(scanf("%s",str)!=EOF)
    {
        scanf("%d",&k);
        int m=strlen(str);
        for(int i=0;i<26;i++)
        {
            a[i].x=0;
            a[i].y=i;
        }
        for(int i=0;i<m;i++)
        {
            a[str[i]-'a'].x++;
        }
        sort(a,a+26);

        for(int i=0;i<26;i++)
        {
            if(k-a[i].x>=0)
            {
                k-=a[i].x;
                a[i].x=0;
            }else break;
        }
        int ans=0;
        for(int i=0;i<26;i++)
            if(a[i].x)ans++;
        printf("%d\n",ans);

        sort(a,a+26,cmp1);
        for(int i=0;i<m;i++)
            if(a[str[i]-'a'].x)
                printf("%c",str[i]);
        printf("\n");
    }
	return 0;
}
