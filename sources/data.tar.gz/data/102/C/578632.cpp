//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string>
#include <algorithm>
using namespace std;



struct letter
{
    char h;
    int k;
};

bool by_count(letter x, letter y)
{
    return(x.k < y.k);
}


bool by_char(letter x, letter y)
{
    return(x.h < y.h);
}

letter a[26];
string s;
int k;

int main()
{
    for(int i = 0; i < 26; i++)
    {
        a[i].k = 0;
        a[i].h = 'a' + i;
    }
    cin >> s;
    for(int i = 0; i < s.length(); i++)
        a[s[i] - 'a'].k++;
    sort(a, a + 26, by_count);
    cin >> k;
    int i = 0;
    while(i < 26  &&  k >= a[i].k)
    {
        k -= a[i].k;
        a[i].k = 0;
        i++;
    }
    sort(a, a + 26, by_char);
    int res = 0;
    for(int i = 0; i < 26; i++)
        if(a[i].k)  res++;
    cout << res << endl;
    for(int i = 0; i < s.length(); i++)
        if(a[s[i] - 'a'].k) cout << s[i];
    return 0;
}
