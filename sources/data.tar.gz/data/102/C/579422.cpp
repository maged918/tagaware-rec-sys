//Language: GNU C++


#include <iostream>
#include <algorithm>
using namespace std;

const int SIGMA = 26;
int k;

struct Letter
{
	char l;
	int t;
} l[SIGMA];

bool operator <(Letter a, Letter b)
{
	return a.t < b.t;
}

string s;

int main()
{
	cin >> s >> k;
	for(int i = 0; i < SIGMA; i++)
	{
		l[i].l = 'a' + i;
	}
	for(int i = 0; i < (int)s.length(); i++)
	{
		l[s[i] - 'a'].t++;
	}
	sort(l, l + SIGMA);
	int sum = 0, m = SIGMA;
	for(int i = 0; i < SIGMA; i++)
	{
		sum += l[i].t;
		if(sum > k)
		{
			m = i;
			break;
		}
	}
	cout << SIGMA - m << endl;
	for(int i = 0; i < (int)s.length(); i++)
	{
		bool isInGoods = false;
		for(int j = 0; j < m; j++)
		{
			if(l[j].l == s[i])
			{
				isInGoods = true;
				break;
			}
		}
		if(!isInGoods)
		{
			cout << s[i];
		}
	}
	cout << endl;
	return 0;
}
