//Language: GNU C++


#include<cstdio>
#include<algorithm>
using namespace std;

typedef struct l{
 int ch;
 int times;
 bool del,used;
}L;

int k;
l chars[26];
char text[100002];
int dis;

bool comp(l a, l b){ return a.times < b.times; }
bool comp2(l a, l b){ return a.ch < b.ch; }

int main(){
 int i;
 for(i=0;i<26;i++){
  chars[i].ch = i;
  chars[i].del = 0;
  chars[i].used = 0;
 }
 scanf("%s",text);
 scanf("%d",&k);
 i = 0;
 dis = 0;
 while(text[i] >= 'a' && text[i] <= 'z'){
  chars[text[i]-'a'].times++;
  chars[text[i]-'a'].used = 1;
  i++;
 }
 for(i=0;i<26;i++) if(chars[i].used) dis++;
 sort(chars,chars+26,comp);
 
 for(i=0;i<26;i++){
  if(chars[i].used && k >= chars[i].times){
   chars[i].del = 1;
   k -= chars[i].times;
   dis--;
  }
 }
 sort(chars,chars+26,comp2);

 printf("%d\n",dis);
 i = 0;
 while(text[i] >= 'a' && text[i] <= 'z'){
  if(!chars[text[i]-'a'].del) printf("%c",text[i]);
  i++;
 }
 printf("\n");

 return 0;
}
