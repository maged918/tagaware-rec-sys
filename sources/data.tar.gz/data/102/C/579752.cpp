//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <string>
#include <vector>
using namespace std;

int main(int argv, char* argc[]){
	string str;
	cin >> str;
	unsigned k;
	cin >> k;
	vector<unsigned> znaz(26, 0);
	for(unsigned i=0; i<str.size(); i++ ){
		znaz[str[i]-'a']++;
	}
	bool flag = 1;
	while(flag){
		unsigned min = 0;
		unsigned pos = 0;
		for(unsigned i=0; i<26; i++){
			if((znaz[i]>0) && ((znaz[i]<min) || (min == 0))){
				pos = i;
				min = znaz[i];
			}
		}
		if((min == 0) || (min > k)){
			break;
		}
		znaz[pos] = 0;
		k-=min;
		for(unsigned i=0; i<str.size(); i++){
			if(str[i]==(pos + 'a')){
				str.erase(i, 1);
				i--;
			}
		}
	}
	unsigned m = 0;
	for(unsigned i=0; i<26; i++){
		if(znaz[i]){
			m++;
		}
	}
	cout << m << endl;
	cout << str << endl;
	return 0;
}

