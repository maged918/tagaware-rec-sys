//Language: MS C++


#define _CRT_SECURE_NO_DEPRECATE 
#define _USE_MATH_DEFINES

#include <utility> 
#include <iostream> 
#include <cstdio> 
#include <cmath> 
#include <algorithm> 
#include <cstdlib> 
#include <string> 
#include <cstring> 
#include <vector>
#include <map>
#include <queue>

using namespace std;

typedef long long int64;
#define INF 1234567890
#define prime 1103
#define FOR(a, b) for(int a = 0; a < b; ++a)

string s;
int k, kol = 0, was[100001], res = 0;
pair <int, char> alf[50], del[50];
int main()
{
	//freopen("numbers.in", "r", stdin);   freopen("numbers.out", "w", stdout);
	//freopen("input.txt", "r", stdin);     freopen("output.txt", "w", stdout);
	cin >> s >> k;
	if (k >= s.length())
	{
		cout << 0;
		return 0;
	}
	for(char i = 'a'; i <= 'z'; ++i)
	{
		del[kol].second = alf[kol].second = i;
		del[kol].first = alf[kol].first = 0;
		++kol;
	}
	FOR(i, s.length())
		++alf[(int)(s[i] - 'a')].first;
	sort(alf, alf + kol);
	memset(was, 0, sizeof was);
	FOR(i, kol)
	{
		if (alf[i].first > 0 && k)
		{
			if (alf[i].first <= k)
			{
				int num = 0;
				FOR(j, kol)
					if (del[j].second == alf[i].second) num = j;
				del[num].first = alf[i].first;
				k -= alf[i].first;
				alf[i].first = 0;
			}
			else
			{
				int num = 0;
				FOR(j, kol)
					if (del[j].second == alf[i].second) num = j;
				del[num].first = k;
				k = 0;
				alf[i].first -= k;
			}
		}
	}
	FOR(i, kol)
		if (alf[i].first) ++res;
	cout << res << endl;
	FOR(i, s.length())
		if (del[(int)(s[i] - 'a')].first)
		{
			++was[i];
			--del[(int)(s[i] - 'a')].first;
		}
	FOR(i, s.length())
		if (!was[i]) cout << s[i];
	return 0; 
} 