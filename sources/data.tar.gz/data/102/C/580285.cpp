//Language: GNU C++


#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <fstream>
#include <numeric>
#include <iomanip>
#include <bitset>
#include <list>
#include <stdexcept>
#include <functional>
#include <utility>
#include <ctime>
using namespace std;
const int maxs = 1000005;
char ch[maxs];
int cnt[26] = {0};
bool todel[26] = {false};
int k;

int main()
{
	gets(ch);
	scanf("%d",&k);
	int len = strlen(ch);
	for (int i=0;i<len;i++)
	{
		cnt[ch[i]-'a'] ++;
	}
	pair<int ,int> num[26];
	for (int i=0;i<26;i++)
	{
		num[i] = std::make_pair(cnt[i],i);
	}
	std::sort(num,num+26);
	int res = 0;
	for (int i=0;i<26;i++)
	{
		if (num[i].first !=0)
		{
			if (res + num[i].first <= k)
			{
				todel[num[i].second ] = true;
				res += num[i].first;
			}
			else
			{
				break;
			}
		}
	}
	int ans = 0;
	for (int i=0;i<26;i++)
	{
		if (cnt[i]!=0 && todel[i]==false)
		{
			ans ++;
		}
	}
	printf("%d\n",ans);
	for (int i=0;i<len;i++)
	{
		if (todel[ch[i]-'a'] == true)
		{
			continue;
		}
		else putchar(ch[i]);
	}
	putchar('\n');
	return 0;
}