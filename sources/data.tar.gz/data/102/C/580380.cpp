//Language: GNU C++


# include <iostream>
# include <string>
# include <algorithm>

using namespace std;

int main()
{
    string a;
    cin>>a;
    pair<int,int>b[26];
    for(int i=0;i<26;i++)
    b[i]=make_pair(0,i);
    for(int i=0;i<a.size();i++)
    b[a[i]-'a'].first++;
    sort(b,b+26);
    int k;
    cin>>k;
    int m=0;
    for(int i=0;i<26&&b[i].first<=k;i++)
    {
    if(b[i].first==0)
    continue;
    string c="";
    k-=b[i].first;
    for(int h=0;h<a.size();h++)
    if(a[h]!=(char)(97+b[i].second))
    c+=a[h];
    b[i].first=0;
    a=c;        
}
    for(int j=0;j<26;j++)
    if(b[j].first>0)
    m++;
    cout<<m<<endl;
    if(a!="")
    cout<<a<<endl;
    return 0;
}
