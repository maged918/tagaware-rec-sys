//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <utility>
#include <algorithm>
using namespace std;

int sf(pair<char,int> a, pair<char,int> b) {
  return a.second < b.second ? 1 : 0;
}

int main() {
  char in[100010];
  int k;
    int dist = 0;
  vector<pair<char,int> >alpha(30);
  int i = 0;

  for (int i = 0; i < 30; i++) {
    alpha[i].first = 'a' + i;
    alpha[i].second = 0;
  }

  while (1) {
    char a;
    scanf("%c", &a);
    if (a == '\n')
      break;
    in[i++] = a;
    if (alpha[a - 'a'].second == 0) dist++;
    alpha[a - 'a'].second++;
  }
  scanf("%d", &k);

  int isin[30] = {0};

  sort(alpha.begin(), alpha.end(), sf);
  int j = 0;
  int sum = 0;

  while (sum < k && j < alpha.size()) {
    if (sum + alpha[j].second <= k) {
      sum += alpha[j].second;
      if (alpha[j].second != 0)
        dist--;
      alpha[j].second = 0;
      isin[alpha[j].first - 'a'] = 1;
    }
    j++;
  }

  printf("%d\n", dist);
  for (int l = 0; l < i; l++)
    if (isin[in[l] - 'a'] == 0)
      printf("%c", in[l]);
  printf("\n");

  return 0;

}


