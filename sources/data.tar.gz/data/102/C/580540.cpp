//Language: MS C++


#include <vector>
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

string str , ans;

int myMap[1000];

struct myPair{ int cnt ; char let; } mp ;
vector <myPair> myVect ;

bool operator<(const myPair a , const myPair b)
{
	return a.cnt < b.cnt ;
}


bool mark[1000] ;

int main()
{
	int i , j , k, asa = 0 ;

	cin >> str >> k;

	for(i = 0; i < str.length(); ++i)
	{
		myMap[ str[i] ] ++;
	}

	for(i = 'a' ; i <= 'z' ; ++i)
	{
		if( myMap[ i ] != 0 )
		{
			mp.let = char(i) ;
			mp.cnt = myMap[i] ;
			myVect.push_back(mp);
		}
	}

	sort(myVect.begin() , myVect.end());

	for(i = 0; i < myVect.size(); ++i)
	{
		if( myVect[i].cnt <= k )
		{
			k -= myVect[i].cnt ;
			mark[ myVect[i].let ] = 1;
			asa++;
		}
	}

	cout << myVect.size() - asa << endl;

	for(i = 0; i < str.length(); ++i)
	{
		if( mark[ str[i] ] == false )
		{
			ans += str[i];
		}
	}

	cout << ans << endl;

	return 0;
}