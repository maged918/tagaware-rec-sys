//Language: GNU C++


#include<iostream>
#include<string.h>
#include<string>
#include<vector>
using namespace std;
int main()
{
        string a;
        int k,n,l,temp,d=0,o[30]={0},p[30]={0},b[30],qq=26;
        cin>>a>>n;
        l=a.size();
        if(n>=l){
                cout<<"0"<<endl;
                return 0;
        }
        else {
                for(int i=0;i<26;i++){
                        b[i]=i;
                }
                for(int i=0;i<l;i++){
                        p[int(a[i]-97)]++;
                        o[int(a[i]-97)]=1;
                }
                for(int i=0;i<26;i++){
                        for(int j=i+1;j<26;j++){
                                if(p[i]>p[j]){
                                        temp=p[i];
                                        p[i]=p[j];
                                        p[j]=temp;
                                        temp=o[i];
                                        o[i]=o[j];
                                        o[j]=temp;
                                        temp=b[i];
                                        b[i]=b[j];
                                        b[j]=temp;
                                }
                        }
                }
                k=0;
                while(n>=p[k]){
                        n-=p[k];
                        o[k]=0;
                        k++;
                        qq--;
                }
                for(int i=0;i<26;i++){
                        for(int j=i+1;j<26;j++){
                                if(b[i]>b[j]){
                                        temp=o[i];
                                        o[i]=o[j];
                                        o[j]=temp;
                                        temp=b[i];
                                        b[i]=b[j];
                                        b[j]=temp;
                                }
                        }
                }
                cout<<qq<<endl;
                for(int i=0;i<l;i++){
                        if(o[int(a[i]-97)]!=0)cout<<a[i];
                }
                cout<<endl;                             
        }
        return 0;
}
