//Language: GNU C++



#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>

using namespace std;

#define rep(i,s,n) for( int i = s; i < n; ++i)

#define MAX 100009

char str[MAX], ss[100];
bool deleted[26];
struct Frequen{
    char ch;
    int f;
}f[26];

int cmp( Frequen *a, Frequen *b){
    if(a->f > b->f) return 1;
    if(a->f < b->f) return -1;
    return a->ch - b->ch;
}
int main(){
//    freopen("c.in", "r", stdin);

    int n, k, del = 0, diff = 0, delc = 0;
    rep(i, 0, 26){
        f[i].ch = 'a' + i;
        f[i].f = 0;
    }
    gets(str);
    gets(ss);
    sscanf(ss, "%d", &k);
    n = strlen(str);
    rep(i, 0, n) f[str[i]-'a'].f++;
    rep(i, 0, 26) if(f[i].f != 0) diff++;
    
    qsort(f, 26, sizeof(f[0]), (int (*)(const void *, const void *))cmp);

    rep(i, 0, 26){
        if(f[i].f > 0 && del + f[i].f <= k){
            del += f[i].f;
            deleted[f[i].ch-'a'] = true;
            delc++;
        }
    }

    printf("%d\n", diff - delc);
    rep(i, 0, n) if(!deleted[str[i]-'a']) printf("%c", str[i]);
    printf("\n");
    return 0;
}
