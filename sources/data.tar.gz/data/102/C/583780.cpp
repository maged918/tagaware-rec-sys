//Language: MS C++


#include<iostream>
#include<cstdio>
#include<stdlib.h>
#include<string.h>
using namespace std;
struct Letter{
    char c;
    int i_th;
    int num;
}s[100100];
int count[26];
int cmp1(const void *_a,const void *_b){
    Letter *A=( Letter *) _a;
     Letter *B= (Letter *) _b;
     if( A->num!=B->num)
        return B->num-A->num;
     return A->c-B->c;
}
int cmp2(const void *_a,const void *_b){
    Letter *A=( Letter *) _a;
     Letter *B= (Letter *) _b;
     return A->i_th-B->i_th;
}
int main(){
    char c;
    int n=0,i,j;
    int k;
    int diff=0;
    memset(count,0,sizeof(count));
    while(scanf("%c",&c)!=EOF){
        if(c=='\n')
            break;
        s[n].c=c;
        count[c-'a']++;
        s[n].i_th=n;
        n++;
    }
    for(j=0;j<26;j++){
        if(count[j])
            diff++;
    }
    i=0;
    for(i=0;i<n;i++){
        s[i].num=count[s[i].c-'a'];
    }
    qsort(s,n,sizeof(s[0]),cmp1);
    i=n-1;
    scanf("%d",&k);
    while(i>=0&&k){
        int x=(k>s[i].num)?s[i].num:k;
        if(x==s[i].num)
            diff--;
        i=i-x;
        k=k-x;
    }
    printf("%d\n",diff);
	if(diff){
		qsort(s,i+1,sizeof(s[0]),cmp2);
		for(j=0;j<=i;j++){
			printf("%c",s[j].c);
		}
	}
	return 0;
}
