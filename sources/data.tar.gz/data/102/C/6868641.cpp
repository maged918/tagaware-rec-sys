//Language: GNU C++


#include<iostream>
#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
const int maxn = 100005;
struct data{
    int id,cnt;
};
char s[maxn];
data d[30];
bool v[30];
bool cmp(data a,data b){
    return a.cnt < b.cnt;
}
int main(){
    int k;
    scanf("%s%d",s,&k);
    //memset(cnt,0,sizeof(cnt));
    memset(v,false,sizeof(v));
    for(int i = 0;i < 26;i ++){
        d[i].id = i;
        d[i].cnt = 0;
    }
    for(int i = 0;s[i] != '\0';i ++){
        d[s[i] - 'a'].cnt ++;
    }
    sort(d,d + 26,cmp);
    int i;
    for(i = 0;i < 26;i ++){
        if(k - d[i].cnt >= 0)k -= d[i].cnt;
        else break;
    }
    int ans = i;
    for(i ;i < 26;i ++){
        v[d[i].id] = true;
    }
    printf("%d\n",26 - ans);
    for(int i = 0;s[i] != '\0';i ++){
        if(v[s[i] - 'a'])printf("%c",s[i]);
    }
    printf("\n");
    return 0;
}
