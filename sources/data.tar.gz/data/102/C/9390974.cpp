//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
const int maxn = 100006;
char str[maxn];
int k;
bool cur[26];
bool flag[26];

struct nums
{
    int cnt;
    char c;
}num[26];

bool cmp(nums a,nums b)
{
    if(a.cnt < b.cnt)
        return true;
    return false;
}

int main()
{
    int total = 0;
    scanf("%s%d",str,&k);
    int len = strlen(str);
    memset(flag,0,sizeof(flag));
    memset(cur,0,sizeof(cur));

    for(int i = 0; i < 26; i++)
    {
        num[i].cnt = 0;
        num[i].c = 'a'+i;
    }
    for(int i = 0; i < len; i++)
    {
        num[str[i]-'a'].cnt++;
        cur[str[i]-'a'] = true;
    }
    for(int i = 0; i < 26; i++)
    {
        if( cur[i] )
            total++;
    }

    sort(num,num+26,cmp);
    int cnt = 0;
    for(int i = 0; i < 26; i++)
    {
        if(num[i].cnt == 0)
            continue;
        cnt += num[i].cnt;
        if(cnt <= k)
        {
            total--;
            flag[num[i].c-'a'] = true;
        }
        else
            break;
    }
    printf("%d\n",total);
    for(int i = 0; i < len; i++)
    {
        if( !flag[str[i]-'a'] )
            putchar(str[i]);
    }
    printf("\n");
    return 0;
}

   		 		 			 	 	   						 		 		