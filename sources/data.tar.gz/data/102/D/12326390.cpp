//Language: GNU C++11


#include <set>
#include <map>
#include <queue>
#include <stack>
#include <cmath>
#include <string>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iomanip>
#include <complex>
#include <sstream>
#include <iostream>
#include <algorithm>
using namespace std;
#define ls id<<1,l,mid
#define rs id<<1|1,mid+1,r
#define OFF(x) memset(x,-1,sizeof x)
#define CLR(x) memset(x,0,sizeof x)
#define MEM(x) memset(x,0x3f,sizeof x)
typedef long long ll ;
typedef pair<int,int> pii ;
const int maxn = 2e5+50 ;
const int inf = 0x3f3f3f3f ;
const int MOD = 1e9+7 ;
int n,m;
vector<int>V;
ll dp[maxn];
struct bus {
    int l,r;
    bool operator < (const bus &a)const {
        if (r==a.r) return l<a.l;
        return a.r>r ;
    }
}a[maxn];

void update(int id,ll val) {
    while (id<=n) {
        dp[id]=(dp[id]+val)%MOD;
        id+=id&(-id);
    }
}
ll getsum(int id) {
    ll ret=0;
    while (id) {
        ret=(ret+dp[id])%MOD;
        id-=(id&-id);
    }
    return ret;
}
void init(){
    CLR(dp);
    V.push_back(1);
    for (int i=0;i<m;i++) {
        int u,v;
        scanf("%d%d",&a[i].l,&a[i].r);
        V.push_back(a[i].l);
        V.push_back(a[i].r);
    }
    sort(V.begin(),V.end());
    V.resize(unique(V.begin(),V.end())-V.begin());
    for (int i=0;i<m;i++) {
        a[i].r=upper_bound(V.begin(),V.end(),a[i].r)-V.begin();
        a[i].l=upper_bound(V.begin(),V.end(),a[i].l)-V.begin();
    }
}

int main () {
#ifdef LOCAL
	freopen("C:\\Users\\Administrator\\Desktop\\in.txt","r",stdin);
//      freopen("C:\\Users\\Administrator\\Desktop\\out.txt","w",stdout);
#endif
    scanf("%d%d",&n,&m);
    init();
    sort(a,a+m);
    if (V[0]!=0||V[V.size()-1]!=n) {
        printf("0\n");
        return 0;
    }
    n=upper_bound(V.begin(),V.end(),n)-V.begin();
    update(1,1);
    for (int i=0;i<m;i++) {
        int l=a[i].l,r=a[i].r;
        ll val=(getsum(r-1)-getsum(l-1)+MOD)%MOD;
//        printf("%d\n",l);
        int gl=getsum(l-1),gr=getsum(r-1);
        update(r,val);
    }
     printf("%I64d\n",(getsum(n)-getsum(n-1)+MOD)%MOD);
	return 0;
}

		  	 	   	   	  				  		   		