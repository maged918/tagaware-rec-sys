//Language: GNU C++


#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

const int MOD = 1000000007;
const int N = 100010;

vector<int> V[N];
int n, m, mm;
int dp[N], C[N];
int lowbit(int x) {return x & (-x);}
void add(int x, int ad) {
        for(;x<=mm;x+=lowbit(x)) C[x] = (C[x] + ad)%MOD;
}
int sum(int x) {
        int ret = 0;
        for(;x;x-=lowbit(x)) ret = (ret + C[x]) % MOD;
        return ret;
}
int s[N];
int a[N], b[N];
int main () {
        cin >> n >> m;
        for(int i=1;i<=m;++i) {
                cin >> a[i] >> b[i];
                s[i] = b[i];
        }
        sort(s+1, s+1+m);
        mm = unique(s+1, s+1+m) - s;
        if( s[mm-1] != n ) {
                cout << 0 << endl;
                return 0;
        }
        //for(int i=1;i<mm;++i) cout << s[i] << " "; cout << endl;
        //cout << mm << endl;
        for(int i=1;i<=m;++i) {
                a[i] = lower_bound(s, s+mm, a[i]) - s;
                b[i] = lower_bound(s, s+mm, b[i]) - s;
                V[ b[i] ].push_back( a[i] );
        }
        for(int i=1;i<mm;++i) {
                int ret = 0;
                for(int j=0;j<V[i].size();++j) {
                        if(V[i][j] == 0)
                                ret ++, V[i][j] ++;
                        ret = (ret + sum(i-1)) % MOD;
                        ret = (ret - sum(V[i][j]-1)) % MOD;
                }
                add(i, ret);
        }
        int ans = ( sum(mm-1) - sum(mm-2) ) % MOD;
        if(ans < 0) ans += MOD;
        cout << ans << endl;

        return 0;
}
