//Language: MS C++


#include <iostream>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

int n, m;
pair<int, int> s[100001];
set<int> q;
const int mod = 1000000007;
map<int, int> tr;
vector<int> t;
int dp[100001];
int ps[100001];

bool cmp(pair<int, int> a, pair<int, int> b)
{
    return a.second < b.second;
}

int sum(int l, int r)
{
    int u = 1;
    int v = tr[r] - 1;
    int lef = 0, rig = v;
    while (u <= v)
    {
        int m = (v + u) >> 1;
        if (t[m] < l)
            lef = m, u = m + 1;
        else v = m - 1;
    }
    int ret = ps[rig] - ps[lef];
    if (ret < 0)
        return ret + mod;
    else return ret;
}

int main()
{
    cin >> n >> m;
    for (int i = 0; i < m; ++i)
    {
        cin >> s[i].first >> s[i].second;
        q.insert(s[i].second);
    }
    int j = 0;
    t.push_back(0);
    for (set<int>::iterator it = q.begin(); it != q.end(); ++it)
        tr[*it] = ++j, t.push_back(*it);
    sort(s, s + m, cmp);
    for (int i = 0; i < m; ++i)
    {
        int ind = tr[s[i].second];
        dp[ind] += (s[i].first == 0) + sum(s[i].first, s[i].second);
        dp[ind] %= mod;
        ps[ind] = dp[ind] + ps[ind - 1];
        ps[ind] %= mod;
    }
    cout << dp[tr[n]] << endl;
    return 0;
}