//Language: MS C++


#include <cstdio>
#include <cstring>
#include <map>
#include <vector>
#include <algorithm>
#define MAXNUM 400000
#define MOD 1000000007

using namespace std;

typedef long long i64;

struct Info
{
    int l,r;
}a[MAXNUM];

bool Comp(const Info &a1,const Info &a2)
{
    if(a1.r!=a2.r) return a1.r<a2.r;
    return a1.l<a2.l;
}

map<int,int> mp;
vector<int> vec;
i64 c[MAXNUM];

int Lowbit(int x)
{
    return x&(-x);
}

void Insert(int x,i64 k)
{
    for(int i=x;i<MAXNUM;i+=Lowbit(i))
        c[i]=(c[i]+k)%MOD;
}

i64 Query(int x)
{
    i64 ret=0;
    if(x==0) return 0;
    for(int i=x;i>=1;i-=Lowbit(i))
        ret=(ret+c[i])%MOD;
    return ret;
}

int main()
{
    int n,m;
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        mp.clear();vec.clear();
        vec.push_back(0);
        vec.push_back(n);
        for(int i=0;i<m;i++)
        {
            scanf("%d%d",&a[i].l,&a[i].r);
            vec.push_back(a[i].l);
            vec.push_back(a[i].r);
        }
        sort(vec.begin(),vec.end());
        int p=1;
        for(int i=0;i<vec.size();i++)
        {
            int x=vec[i];
            if(mp.find(x)==mp.end())
                mp[x]=p++;
        }
        for(int i=0;i<m;i++)
        {
            a[i].l=mp[a[i].l];
            a[i].r=mp[a[i].r];
        }
        sort(a,a+m,Comp);
        memset(c,0,sizeof(c));
        Insert(1,1);
        for(int i=0;i<m;i++)
        {
            i64 k=(Query(a[i].r-1)-Query(a[i].l-1)+MOD)%MOD;
            Insert(a[i].r,k);
        }
        printf("%lld\n",(Query(mp[n])-Query(mp[n]-1)+MOD)%MOD);
    }
    return 0;
}