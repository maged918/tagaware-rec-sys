//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <queue>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <complex>

using namespace std;

typedef long long LLN;
typedef unsigned long long LLU;

const double pi = 2.0 * acos(0.0);
const double eps = 1.0e-9;
const int dr[] = {-1, 0, 1, 0},  dc[] = {0, 1, 0, -1};
const int dr6[] = {1, 1, 0, -1, -1, 0}, dc6[] = {0, 1, 1, 0, -1, -1};
const int dr8[] = {-1, -1, 0, 1, 1, 1, 0, -1}, dc8[] = {0, 1, 1, 1, 0, -1, -1, -1};

////////////////////////////////////////////////////////////////////////////////

const int Mod = 1000000007;
pair <int, int> buses[100100];
int k, xx[200200], ways[200200];

int add(int x, int y)
{
    return ((x + y) < Mod ? (x + y) : (x + y - Mod));
}

int sub(int x, int y)
{
    return ((x < y) ? (x - y + Mod) : (x - y));
}

int query(int x)
{
    int t = 0;
    while (x > 0)
    {
        t = add(t, ways[x]);
        x -= x & -x;
    }
    return t;
}

void update(int x, int y)
{
    while (x <= k)
    {
        ways[x] = add(ways[x], y);
        x += x & -x;
    }
}

int main(void)
{
    int kase = 1000000000;
    //scanf("%d", &kase);

    for (int ks = 1, n, m; ks <= kase && 2 == scanf("%d %d", &n, &m); ++ks)
    {
        //if (ks > 1) puts("");

        for (int i = 0; i < m; ++i) scanf("%d %d", &buses[i].second, &buses[i].first);
        sort(buses, buses + m);
        for (int i = 0, j = 0; i < m; ++i) xx[j++] = buses[i].first, xx[j++] = buses[i].second;
        k = m + m;
        xx[k++] = 0;
        xx[k++] = n;
        sort(xx, xx + k);
        k = unique(xx, xx + k) - xx;
        for (int i = 0; i < m; ++i)
        {
            buses[i].first = lower_bound(xx, xx + k, buses[i].first) - xx + 1;
            buses[i].second = lower_bound(xx, xx + k, buses[i].second) - xx + 1;
        }
        memset(ways, 0, sizeof(ways));
        update(1, 1 % Mod);
        for (int i = 0; i < m; ++i)
        {
            //printf("%d -> %d\n", xx[buses[i].second - 1], xx[buses[i].first - 1]);
            //printf("%d %d\n", query(buses[i].first - 1), query(buses[i].second - 1));
            int x = sub(query(buses[i].first - 1), query(buses[i].second - 1));
            update(buses[i].first, x);
        }
        printf("%d\n", sub(query(k), query(k - 1)));
        
        break;
    }
	
    return 0;
}
