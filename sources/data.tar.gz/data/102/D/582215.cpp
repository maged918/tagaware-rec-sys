//Language: MS C++


#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <string>
#include <queue>
#include <map>
#include <set>

#define pb push_back
#define mp make_pair
#define PI 3.14159265358979
#define sqr(x) (x)*(x)
#define forn(i, n) for(int i = 0; i < n; ++i)
#define ALL(x) x.begin(), x.end()
#define max(a,b) ((a>b)?(a):(b))
#define min(a,b) ((a<b)?(a):(b))
#define sz(x) int((x).size())
typedef long long ll;
typedef long double ld;
using namespace std;
typedef pair<int,int> pii;
const int INF = 2147483647;
const ll LLINF = 9223372036854775807LL;
const int maxn = 200010;
const int mod = 1000000007;
map<int, int> prev;
int a[maxn], cnt = 0;
int dp[maxn] = {0};
int psum[maxn] = {0};
vector<int> tvect[maxn];
int vind = 0;
int main()
{
#ifndef ONLINE_JUDGE
	freopen("input.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
#endif
	int n, m; scanf("%d%d", &n, &m);
	a[cnt++] = 0;
	for (int i = 0; i < m; ++i) {
		int s, t; scanf("%d%d", &s, &t);
		if (prev.count(t) == 0) {
			prev[t] = vind;
			tvect[vind].pb(s);
			vind++;
		}
		else tvect[prev[t]].pb(s);
		a[cnt++] = t;
	}
	sort(a, a + cnt);
	cnt = unique(a, a + cnt) - a;
	dp[0] = 1;
	psum[0] = 1;
	for (int i = 1; i < cnt; ++i) {
		int vcur = prev[a[i]];
		dp[i] = 0;
		for (int j = 0; j < tvect[vcur].size(); ++j) {
			int pr = tvect[vcur][j];
			int l = -1;
			int r = i;
			while (r - l > 1) {
				int m = (l + r) / 2;
				if (a[m]>=pr) r = m;
				else l = m;
			}
			int al = r, ar = i - 1;
			if (al <= ar) {
				int curs = psum[ar];
				if (al) curs = (curs + mod - psum[al-1]) % mod;
				dp[i] = (dp[i] + curs) % mod;
			}
		}
		psum[i] = (psum[i-1] + dp[i]) % mod;
	}
	if (a[cnt - 1] != n) printf("%d", 0);
	else printf("%d", dp[cnt - 1]);
	return 0;
}