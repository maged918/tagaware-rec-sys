//Language: GNU C++


#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)

long long mod = 1000000007;

pair<int,int> bus[100002];//first finish   &&  second start
int finish[100002];//finish time ha ro inja mizarim
long long dp[100002]={0};
long long full[100002]={0};

int main(){
    int i,n,m;
    bool flag = false;
    cin>>n>>m;
    bus[0]=make_pair(0,-1);
    REP(i,m){
        cin>>bus[i+1].second>>bus[i+1].first;
        if(bus[i+1].second==0)
            flag=true;
    }
    sort(bus,bus+m+1);
    if(bus[m].first!=n || !flag){
        cout<<0<<endl;
        return 0;
    }
    REP(i,m+1)
        finish[i]=bus[i].first;
    //full kolesho moshakhas mikone  --> full[i]=dp[i-1]+...+dp[0]
    dp[0]=1;
    full[0]=0;
    full[1]=1;
    for(i=1;i<=m;i++){
        int t1 = lower_bound(finish,finish+m+1,bus[i].second)-finish;
        int t2 = lower_bound(finish,finish+m+1,bus[i].first)-finish;

        dp[i]=((full[t2]-full[t1])+mod)%mod;
        full[i+1]=(full[i]+dp[i])%mod;
    }
    long long ans=0;
    REP(i,m+1)
        if(bus[i].first==n)
            ans=(ans+dp[i])%mod;
    
    cout<<ans<<endl;
    return 0;
}