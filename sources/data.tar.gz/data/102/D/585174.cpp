//Language: MS C++


#include <stdio.h>
#include <iostream>
#include <vector>
#include <list>
#include <cmath>
#include <fstream>
#include <algorithm>
#include <string>
#include <queue>
#include <set>
#include <map>
#include <complex>
#include <iterator>
#include <cstdlib>
#include <cstring>
#include <sstream>

using namespace std;

#define EPS (1e-10)
#define EQ(a,b) (abs((a) - (b)) < EPS)
#define EQV(a,b) (EQ((a).real(),(b).real()) && EQ((a).imag(),(b).imag()))

typedef complex<double> P;
typedef long long ll;

const int MAX_SIZE = 1000000;

map<ll,ll> dp;

map<ll,vector<ll> > G;
set<ll> ss;

ll bit[MAX_SIZE+1];
int nn;

const ll MOD=1000000007LL;

ll sum(ll i){
    ll s=0;
    while(i>0){
        s=(s+bit[i])%MOD;
        i-=(i&-i);
    }
    return s;
}
void add(ll i,ll x){
    while(i<=nn){
        bit[i]=(bit[i]+x)%MOD;
        i+=(i&-i);
    }
}


map<ll,ll> index;

void solve(){

    ll n,m;
    cin>>n>>m;
    vector<pair<ll,ll> > v;
    ll cnt=1;
    for(ll i = 0; i < m; i++){
        ll a,b;
        cin>>a>>b;
        v.push_back(make_pair(b,a));
        ss.insert(b);
        ss.insert(a);
        ss.insert(b-1);
        ss.insert(a-1);
    }
    ss.insert(0);
    ss.insert(-1);
    ss.insert(n);
    ss.insert(n-1);

    sort(v.begin(),v.end());
    for(set<ll>::iterator it = ss.begin(); it != ss.end(); it++){
        index[*it]=cnt;
        cnt++;
    }
    //if((ss.find(0)==ss.end()||ss.find(n)==ss.end())){
    //  cout<<0<<endl;
    //  return;
    //}

    nn=cnt-1;
    add(2,1);
    // 順番に累積和を求めてみる
    for(ll i = 0; i < v.size(); i++){
        ll s1=sum(index[v[i].first]-1);
        ll s2=sum(index[v[i].second]-1);
        add(index[v[i].first],(s1-s2+MOD)%MOD);
    }
    ll tmp1=(sum(nn));
    ll tmp2=(sum(nn-1));
    cout<<((tmp1-tmp2)+MOD)%MOD<<endl;

}

int main(){

    solve();

    return 0;
}