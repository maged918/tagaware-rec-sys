//Language: GNU C++



#include <iostream>
#include <map>
#include <string.h>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

const int N = 200010;
const long long MOD = 1000000007;

long long C[N], dp[N];

struct node {
       int l, r;
}bus[N];
int rank[N];
map<int,int> mymap;

int lowbit(int x) { return x&(-x); }

void add(int x,long long v) {
       while ( x <= N ) {
              C[x] += v;
              C[x] = (C[x]+MOD)%MOD;
              x += lowbit(x);
       }
}

int sum(int x) {
       long long ans = 0;
       while ( x > 0 ) {
              ans += C[x];
              ans = (ans + MOD)%MOD;
              x -= lowbit(x);
       }
       return ans%MOD;
}

bool cmp(node a,node b) {
       if ( a.r == b.r ) return a.l < b.l;
       return a.r < b.r;
}

int main() {
       int n, m;
       cin >> n >> m;
       mymap.clear();
       memset(C,0,sizeof(C));
       memset(dp,0,sizeof(dp));
       int nn = 0;
       for (int i = 0; i < m; ++i) {
              cin >> bus[i].l >> bus[i].r;
              rank[nn++] = bus[i].l;
              rank[nn++] = bus[i].r;
       }
       rank[nn++] = n;
       sort(rank,rank+nn);
       int rr = 1;
       for (int i = 0; i < nn; ++i) {
              if ( mymap[rank[i]] == 0 ) {
                     mymap[rank[i]] = rr++;
              }
       }
       sort(bus,bus+m,cmp);
       if ( rank[0] == 0 ) add(1,1);
       for (int i = 0; i < m; ++i) {
              int x = mymap[bus[i].l];
              int y = mymap[bus[i].r];
              int ans = sum(y-1)-sum(x-1);
              dp[y] = dp[y] + ans;
              dp[y] = (dp[y]+MOD)%MOD;
              add(y,ans);
       }
       cout << dp[mymap[rank[nn-1]]]<< endl;
       return 0;
}
