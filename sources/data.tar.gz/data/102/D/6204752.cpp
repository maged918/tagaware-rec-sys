//Language: GNU C++



#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
#define MAX 100010
#define LL long long 
#define MOD 1000000007LL

int n,m,LEN,index;
int Hash[MAX<<1];
struct seg{
	int l,r;
	bool operator < (const seg &temp)const{
		return r < temp.r;
	}
}s[MAX];
LL dp[MAX<<1],sum[MAX<<1];

int find(int key){
	int low = 0 , high = n-1;
	while(low <= high){
		int mid = (low + high) >> 1;
		if(Hash[mid] == key) return mid;
		else if(Hash[mid] < key) low = mid + 1;
		else high = mid - 1;
	}
}

int main(){
	while(scanf("%d%d",&LEN,&m)!=EOF){
		for(int i = 0; i < m; i++){
			scanf("%d%d",&s[i].l,&s[i].r);
			Hash[i<<1] = s[i].l; Hash[i<<1|1] = s[i].r;
		}

		n = 1;
		sort(Hash,Hash+2*m);
		for(int i = 1; i < 2*m; i++){
			if(Hash[i] != Hash[i-1]) Hash[n++] = Hash[i];
		}
		if(Hash[n-1] != LEN || Hash[0] != 0) { puts("0"); continue; }
		
		for(int i = 0; i < m; i++){
			s[i].l = find(s[i].l);
			s[i].r = find(s[i].r);
		}
		sort(s,s+m);
		
		memset(dp,0,sizeof(dp));
		memset(sum,0,sizeof(sum));
		index = 0;
		dp[0] = sum[0] = 1LL;
		for(int i = 1; i < n; i++){
			while(s[index].r < i && index < m) index++;
			for(; index < m && s[index].r == i; index++){
				dp[i] = (dp[i] + sum[i-1] - sum[s[index].l] + dp[s[index].l] + MOD) % MOD;
			}
			sum[i] = (sum[i-1] + dp[i]) % MOD;
		}
		cout << dp[n-1] << endl;
	}
	return 0;
}
		 						   	   	    			 	