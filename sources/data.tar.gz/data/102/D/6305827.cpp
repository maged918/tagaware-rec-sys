//Language: GNU C++0x


#include <cstdio>
#include <vector>
#include <cstring>
#include <functional>
#include <algorithm>
const int MAX_N = 200010;
int dp[MAX_N];
int sum[MAX_N];
struct node {
    int l, r;
    void in() {
        scanf("%d%d",&l,&r);
    }
    bool operator < (const node& cmp) const {
        return r  < cmp.r;
    }
}interval[MAX_N];
const int MOD = 1000000007;
void insert(int x, int val) {
    x++;
    for(;x < MAX_N; x += x & -x) {
        sum[x] += val;
        if(sum[x] >= MOD) {
            sum[x] -= MOD;
        }
    }
}
int get_sum(int x) {
    int ret = 0;
    x++;
    for(; x; x -= x & -x) {
        ret += sum[x];
        if(ret >= MOD) {
            ret -= MOD;
        }
    }
    return ret;
}
int main() {
    int n, m;
    scanf("%d%d",&n,&m);
    std::vector<int> points;
    for(int i = 0; i < m; i++) {
        interval[i].in();
        points.push_back(interval[i].l);
        points.push_back(interval[i].r);

    }
    points.push_back(0);
    std::sort(points.begin(), points.end());
    points.erase(std::unique(points.begin(), points.end()), points.end());
    std::sort(interval, interval + m);
    int result = 0;

    insert(0, 1); dp[0] = 1;
    for(int i = 0; i < m; i++) {
        int left = interval[i].l;
        int right = interval[i].r;
        left = std::lower_bound(points.begin(), points.end(), left) - points.begin();
        right = std::lower_bound(points.begin(), points.end(), right) - points.begin();
        int add = get_sum(right - 1) - get_sum(left - 1) + MOD;
        if(add >= MOD) add -= MOD;
        dp[i] = add;
        insert(right, dp[i]);
        if(interval[i].r == n) {
            result += dp[i];
            if(result >= MOD) {
                result -= MOD;
            }
        }
    }
    printf("%d\n",result);
}

 		    	 	 		   					   	