//Language: GNU C++


    #include<stdio.h>
    #include<string.h>
    #include<iostream>
    #include<algorithm>
    #define M 100005
    #define P 1000000007
    #define lowbit(x) (x&(-x))
    using namespace std;
    struct Bus{
        int s,t;
    }bus[M];
    struct node{
        int L,R,cnt;
    }tree[4*M];
    int ans[M];
    int s[M];
    int C[M],n;
    bool cmp(Bus a,Bus b){
        if(a.t!=b.t)return a.t>b.t;
        return a.s>b.s;
    }
    int Find1(int x,int L,int R){
        int res=-1;
        while(L<=R){
            int mid=(L+R)>>1;
            if(s[mid]>x){
                res=mid;
                L=mid+1;
            }else R=mid-1;
        }
        return res;
    }
    int Find2(int x,int L,int R){
        int res=-1;
        while(L<=R){
            int mid=(L+R)>>1;
            if(s[mid]<x){
                res=mid;
                R=mid-1;
            }else L=mid+1;
        }
        return res;
    }
    int get(int x){
        int res=0;
        while(x){
            res=(res+C[x]);
            if(res>P)res-=P;
            x-=lowbit(x);
        }
        return res;
    }
    void add(int x,int a){
        while(x<=n){
            C[x]+=a;
            if(C[x]>P)C[x]-=P;
            else if(C[x]<0)C[x]=C[x]+P;
            x+=lowbit(x);
        }
    }
    int main(){
        int m;
        int i,j,k;
        while(scanf("%d %d",&m,&n)!=EOF){
            if(n==0){
                puts("0");
                continue;
            }
            for(i=1;i<=n;i++)
                scanf("%d %d",&bus[i].s,&bus[i].t);
            sort(bus+1,bus+n+1,cmp);
            for(i=1;i<=n;i++){
                s[i]=bus[i].t;
                ans[i]=0;
            }
            for(i=1;i<=n;i++)
                C[i]=0;
            for(i=1;i<=n;i++){
                if(bus[i].t==m)ans[i]=1;
                else {
                    ans[i]=get(i);
                    if(!ans[i])continue;
                }
                int R=Find1(bus[i].s-1,i+1,n);      
                if(R==-1)continue;
                int L=Find2(bus[i].t,i+1,n);
                if(L==-1)continue;
                if(L>R)continue;
                add(L,ans[i]);
                add(R+1,-ans[i]);
            }
            int res=0;
            for(i=1;i<=n;i++)
                if(bus[i].s==0)res=(res+ans[i])%P;
            printf("%d\n",res);
        }
        return 0;
    }