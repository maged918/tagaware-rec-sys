//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<map>
#include<cstring>
#include<algorithm>
using namespace std;

const int mod=1000000007;

int n,m;
pair<int, int > pr[100009];
map<int , long long > mp;


int lowbit(int x){
	return x&(-x);
} 

void update(int x, long long k){
	while(x<=n+1){
		mp[x]=(mp[x]+k)%mod;
		x+=lowbit(x);
	}
}

long long sum(int x){
	long long ans=0;
	while(x>0){
//		if(mp.count(x)){
			ans+=mp[x];
			ans%=mod;
//		}
		x-=lowbit(x); 
	}
	return (ans+mod)%mod;
}

int main()
{
//	freopen("in.txt","r",stdin);
	
	while(cin >> n >> m){
		mp.clear();
//		pr.clear();
		for(int i=0; i<m; ++i){
			cin >> pr[i].second >> pr[i].first;
			pr[i].first++;
			pr[i].second++;
		}
		sort(pr,pr+m);
		update(1,1);
		for(int i=0; i<m; ++i){
			int d=pr[i].first;
			int s=pr[i].second;
			long long num = sum(d-1)-sum(s-1);
			num=(num%mod+mod)%mod;
			update(d,num);
		}
		long long anss=sum(n+1)-sum(n);
		anss=(anss%mod+mod)%mod;
		cout << anss << endl;
	}
	return 0;
}
	 		 			   			   		  		 		