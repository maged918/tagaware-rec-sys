//Language: GNU C++


#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <map>
#include <queue>
#include <set>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

#define clr(x) memset((x), 0, sizeof(x))
#define pb push_back
#define mp make_pair
#define sz size()
#define For(i, st, en) for(int i=(st); i<=(int)(en); i++)
#define Ford(i, st, en) for(int i=(st); i>=(int)(en); i--)
#define forn(i, n) for(int i=0; i<(int)(n); i++)
#define ford(i, n) for(int i=(n)-1; i>=0; i--)
#define fori(it, x) for (__typeof((x).begin()) it = (x).begin(); it != (x).end(); it++)

template <class _T> inline _T sqr(const _T& x) { return x * x; }
template <class _T> inline string tostr(const _T& a) { ostringstream os(""); os << a; return os.str(); }

typedef long double ld;

// Constants
const ld PI = 3.1415926535897932384626433832795;
const ld EPS = 1e-11;

// Types
typedef long long llint;
typedef set < int > SI;
typedef vector < int > VI;
typedef map < string, int > MSI;
typedef pair < int, int > PII;


#ifdef MY_COMP
    const bool LOCAL = true;
#else
    const bool LOCAL = false;

#endif

vector<int> begins;
vector<int> end;


struct bus{
    int b, e;
    bus( int _b, int _e ) : b(_b), e(_e) {}
};
vector<bus> a;

bool cmp_b( int p1, int p2 )
{
    return a[p1].b < a[p2].b;
}
bool cmp_e( int p1, int p2 )
{
    return a[p1].e < a[p2].e;
}





int main()
{
    time_t et_0 = clock();
    if( LOCAL )
        freopen("input.txt", "rt", stdin);
    cout << setiosflags(ios::fixed) << setprecision(10);

    int N, M;
    cin >> N >> M;

    forn( i, M ) {
        int b, e;
        cin >> b >> e;
        
        a.pb( bus( b, e ) );
        begins.pb( i );
        end.pb( i );
    }
    begins.pb( M );
    end.pb( M );
    a.pb( bus( N, N+3 ) );
    M++;

    begins.pb( M );
    end.pb( M );
    a.pb( bus( -1, 0 ) );
    M++;




    sort( begins.begin(), begins.end(), cmp_b );
    sort( end.begin(), end.end(), cmp_e );

    vector<int> ans( M );
    ans[ M-2 ] = 1;
    

    //конец автобуса
    int e = M - 2;
    int b = M - 1;

    long long int sum = 1;
    const long long int MOD = 1000000000 + 7;

    
    while( e >= 0 ) {
        //начинаются раньше
        while( a[ begins[b] ].b > a[ end[e]].e ) {
            sum -= ans[ begins[b] ];
            if( sum < 0 )
                sum += MOD;
            b--;
        }

        //какие заканчиваются?
        int lastSum = sum;
        ans[ end[e] ] = lastSum;
        sum = ( sum + ans[ end[e] ] ) % MOD;
        
        int lastE = a[ end[e]].e;
        int lastIndex = end[e];
        e--;

        while( e >= 0 && a[ end[e]].e == lastE ) {
            ans[end[e]] = ans[lastIndex];
            sum = ( sum + ans[ lastIndex ] ) % MOD;
            e--;
        }
    }

    cout << ans[M-1];




    if( LOCAL ) {
        time_t et_1 = clock();
        fprintf(stderr, "\nExecution time = %0.0lf ms\n", (et_1 - et_0) * 1000.0 / CLOCKS_PER_SEC);
    }
    return 0;
}
