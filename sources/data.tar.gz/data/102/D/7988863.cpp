//Language: GNU C++0x


#include <bits/stdc++.h>
using namespace std;
#define int long long
const int inf = 1000*1000*1000;
const int maxN = 100*1000 + 5;
const int mod = 1000*1000*1000 + 7;


pair<int, int> a[maxN];
int dp[maxN];
int sum[maxN];
main()
{
    ios::sync_with_stdio(0); cin.tie(0);
    int n, m; cin >> n >> m;
    for(int i = 0; i < m; i ++)
	  cin >> a[i].second >> a[i].first;
    
    sort(a, a + m);
    int ans = 0;

    for(int i = 0; i < m; i ++)
    {
	  pair<int, int> x = make_pair(a[i].second, -1);
	  int pss = lower_bound(a, a + m, x) - a;
	  x.first = a[i].first - 1; x.second = mod;
	  int pse = lower_bound(a, a + m, x) - a;
	  pse --;
	  if(a[i].second == 0) dp[i] ++;
	  if(pss > pse) 
	  {
		sum[i] = (dp[i] + (i ? sum[i - 1] : 0)) % mod;
		continue;
	  }
	  
	  dp[i] += sum[pse] - (pss ? sum[pss - 1] : 0);
	  dp[i] %= mod; dp[i] += mod; dp[i] %= mod;
	  sum[i] = (dp[i] + (i ? sum[i - 1] : 0)) % mod;
    }
    //for(int i = 0; i < m; i ++)
    //  cout << sum[i] << endl;
    pair<int, int> x = make_pair(n, -1);
    int ps = lower_bound(a, a + m, x) - a;
    if(ps == m) { cout << 0 << endl; return 0; }
    cout << (((sum[m - 1] - (ps ? sum[ps - 1] : 0)) % mod) + mod) % mod << endl; 
    return 0;
}
