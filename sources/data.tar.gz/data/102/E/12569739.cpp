//Language: GNU C++11


//  Created by Chlerry in 2015.
//  Copyright (c) 2015 Chlerry. All rights reserved.
//

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <algorithm>
#include <sstream>
#include <cstring>
#include <climits>
#include <complex>
#include <string>
#include <vector>
#include <cmath>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <unordered_map>
using namespace std;
#define Size 100000
#define ll long long
#define mk make_pair
#define pb push_back
#define mem(array, x) memset(array,x,sizeof(array))
typedef pair<int,int> P;

typedef complex <long long>cll;
 
bool div(const cll& a,const cll&b)
{
    cll c(0,0);
     c=a / b;
     return (b * c==a);
 }

int main()
{
    ll a,b;
    cin>>a>>b;
    cll A(a,b);
    cin>>a>>b;
    cll B(a,b);
    cin>>a>>b;
    cll C(a,b);
    cll I(0,1);
    bool flag=0;
    if(C.real()==0  &&  C.imag()==0)
    {
        if (A==B) flag=1;
        else if (B==-A) flag=1;
        else if (B==A*I) flag=1;
        else if (B==-A*I) flag=1;
    }
    else 
    {
        if (div(B-A,C)) flag=1;
        else if (div(B+A,C)) flag=1;
        else if (div(B-A*I,C)) flag=1;
        else if (div(B+A*I,C)) flag=1;
    }
    if(flag) cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
    return 0;
}
		   	 	 		 	 				 	 			  				