//Language: GNU C++


#include <iostream>
#include <cmath>
using namespace std;
int f(long long x,long long y,long long x1,long long y1)
{
    long long t=(x*x1+y*y1)%(x1*x1+y1*y1);
    //cout << t<<endl;
    if(t)return 0;
    long long tx=-y1;long long ty=x1;
x1=tx;y1=ty;
t=(x*x1+y*y1)%(x1*x1+y1*y1);
    //cout << t<<endl;
    if(t)return 0;
    return 1;       
}
int main(){
    long long q,w,e,r,t,y;
    cin >>q >>w>>e>>r>>t>>y;
    long long tq=q;long long tw=w;
    
    for(int i=0;i<4;i++){
    q=-tw;w=tq;
    if(t||y){if(f(e-q,r-w,t,y))return(cout << "YES"),0;}
    else{if(e-q==0&&0==r-w)return(cout << "YES"),0;}
    tw=w;tq=q;
    }
    cout <<"NO";
}