//Language: GNU C++


//#include "stdafx.h"
#include <iostream>
using namespace std;
typedef long long int li;

bool solve(li a00,li a01,li a10,li a11,li b0,li b1) {
	li det=a00*a11-a10*a01;
	if (det!=0)
		return ((a00*b1-a01*b0)%det==0 && (b0*a11-b1*a10)%det==0);
	else	
		return b0==0&&b1==0;
}

int main(void)
{
	int xa,ya,xb,yb,xc,yc;
	cin>>xa>>ya>>xb>>yb>>xc>>yc;
	bool res=solve(xc,yc,yc,-xc,xb-xa,yb-ya)||
		solve(xc,yc,yc,-xc,xb-ya,yb+xa)||
		solve(xc,yc,yc,-xc,xb+xa,yb+ya)||
		solve(xc,yc,yc,-xc,xb+ya,yb-xa);
	if (res)
		cout<<"YES";
	else
		cout<<"NO";
	return 0;
}
