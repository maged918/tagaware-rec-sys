//Language: MS C++


#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

int main()
{
    __int64 xaa, yaa, xb, yb, xc, yc;
    cin >> xaa >> yaa;
    cin >> xb >> yb;
    cin >> xc >> yc;

    int ax[] = {1,1,-1,-1};
    int ay[] = {1,-1,1,-1};
    for ( int i = 0; i < 4; i++ ) {
        __int64 xa = xaa*ax[i], ya = yaa*ay[i];
        if ( i==1 || i==2 ) swap(xa,ya);
        __int64 xd = xb-xa, yd = yb-ya;
        __int64 nl = xc*xc + yc*yc;
        if ( nl == 0 ) {
            if ( xd == 0 && yd == 0 ) {
                cout << "YES" << endl;
                return 0;
            } else {
                continue;
            }
        }

        __int64 nu = xc*yd - yc*xd;
        if ( nu%nl ) {
            continue;
        }

        nu = xc*xd + yd*yc;
        if ( nu%nl ) {
            continue;
        }

        cout << "YES" << endl;
        return 0;
    }
 
    cout << "NO" << endl;
    return 0;
}
