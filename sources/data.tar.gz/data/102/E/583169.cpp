//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<sstream>
#include<vector>
#include<set>
#include<algorithm>
#include<map>
#include<math.h>
#define x first
#define y second
#define pii pair<long long,long long>
using namespace std;
pii rotate(pii p){
    return make_pair(-p.y,p.x);
}
int  main(){
    //prlong longf("%d\n",5%0);
    pii A;
    scanf("%I64d %I64d",&A.x,&A.y);
    pii B;
    scanf("%I64d %I64d",&B.x,&B.y);
    pii C;
    scanf("%I64d %I64d",&C.x,&C.y);
    //cin >> A.x >> A.y >> B.x >> B.y >> C.x >> C.y;
    pii C2=rotate(C);
    for(int i=0;i<4;i++,
        A=rotate(A)){

        if(C.x==0&&C.y==0){
            if(A.x==B.x&&A.y==B.y){
                printf("YES\n");
                return 0;
            }
        }
        else if(C.x==0||C.y==0){
            long long a=B.x-A.x;
            long long b=B.y-A.y;
            a=abs(a);
            b=abs(b);
            if(C.x==0){
                if(abs(a)%abs(C.y)==0&&abs(b)%abs(C.y)==0){
                    printf("YES\n");
                    return 0;
                }
            }
            else{
                if(abs(a)%abs(C.x)==0&&abs(b)%abs(C.x)==0){
                    printf("YES\n");
                    return 0;
                }
            }
        }
        else{
            long long a,b,c,d,e,f;
            c=B.x-A.x;
            a=C.x;
            b=C2.x;
            f=B.y-A.y;
            d=C.y;
            e=C2.y;
            if(a*e-b*d==0|| (c*e-b*f )%(a*e-b*d)!=0)continue;
            long long x=c*e-b*f;
            x/=(a*e-b*d);
            long long y=c-a*x;
            if(abs(y)%abs(b)!=0)continue;
            y/=b;
            if(a*x+b*y!=c||d*x+e*y!=f)continue;
            printf("YES\n");
            return 0;
        }

    }
    printf("NO\n");
    return 0;
}
