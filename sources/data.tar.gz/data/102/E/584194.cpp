//Language: GNU C++


#include <algorithm>
#include <string>
#include <vector>
#include <queue>
#include <iostream>
#include <cmath>
#include <sstream>
#include <map>
#include <set>
#include <numeric>
#include <memory.h>
#include <cstdio>

using namespace std;

#define pb push_back
#define INF 1011111111
#define FOR(i,a,b) for (int _n(b), i(a); i < _n; i++)
#define rep(i,n) FOR(i,0,n)
#define ford(i,a,b) for(int i=(a),_b=(b);i>=_b;--i)
#define CL(a,v) memset((a),(v),sizeof(a))
#define mp make_pair
#define X first
#define Y second
#define all(c) (c).begin(), (c).end()
#define SORT(c) sort(all(c))

typedef long long ll;
typedef pair<int,int> pll;

pll rot(pll a)
{
    swap(a.X,a.Y);
    a.Y = -a.Y;

    return a;
}

pll operator + (pll a, pll b)
{
    return pll(a.X+b.X, a.Y+b.Y);
}

pll operator - (pll a, pll b)
{
    return pll(a.X-b.X, a.Y-b.Y);
}

ll det(ll a,ll b, ll c,ll d){return a*d-b*c;}

int main()
{
	#ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        //freopen("output.txt","w",stdout);
	#endif

	pll A,B,C;

    cin >> A.X >> A.Y;
    cin >> B.X >> B.Y;
    cin >> C.X >> C.Y;

    pll CT = rot(C);

    rep(rotation,4)
    {
        A = rot(A);
        pll BA = B - A;

        ll d = det(C.X,CT.X,C.Y,CT.Y);
        ll c = det(C.X,BA.X,C.Y,BA.Y);
        ll ct = det(BA.X,CT.X,BA.Y,CT.Y);

        if(d==0)
        {
            if(BA.X==0 && BA.Y==0)
            {
                cout << "YES" << endl;
                return 0;
            }
        }
        else
        {
            if(d < 0) d = -d;

            if(c%d==0 && ct%d==0)
            {
                cout << "YES" << endl;
                return 0;
            }
        }
    }

    cout << "NO" << endl;

	return 0;
}
