//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

struct P{
    long long x,y;
}str,end,con;


bool match(P c, P b){
    if( b.x*b.x+b.y*b.y ==0){
        if(c.x*c.x+c.y*c.y==0)
            return true;
        else return false;
    }
    if(b.x==0 || b.y==0){
        if(c.x*c.x+c.y*c.y==0)
            return false;
        else{
            if(b.x!=0 && c.x%b.x==0 && c.y%b.x==0)
                return true;
            else if(b.y!=0 && c.x%b.y==0 && c.y%b.y==0)
                return true;
            else return false;
        }
    }
    
    long long m = (long long)(c.x*b.x+c.y*b.y)/(b.x*b.x+b.y*b.y);
    if(m*(b.x*b.x+b.y*b.y) != (long long)(c.x*b.x+c.y*b.y) )
        return false;
    long long n = (c.x-m*b.x)/b.y;
    if(n * b.y != (long long)(c.x-m*b.x))
        return false;
    return true;
/*  
    b.x b.y

    b.y -b.x

    c.x c.y
    
    -b.y b.x
*/  
}

int main()
{
//  freopen("in.txt","r",stdin);
    while(cin >> str.x >> str.y >> end.x >> end.y >> con.x >> con.y){
        P t;
        t.x = end.x-str.x;
        t.y = end.y-str.y;
        bool flg = match(t,con);
        if(flg){
            cout << "YES" << endl;
            continue;
        }
        t.x = end.x+str.y;
        t.y = end.y-str.x;
        flg = match(t,con);
        if(flg){
            cout << "YES" << endl;
            continue;
        }
        t.x = end.x-str.y;
        t.y = end.y+str.x;
        flg = match(t,con);
        if(flg){
            cout << "YES" << endl;
            continue;
        }
        t.x = end.x+str.x;
        t.y = end.y+str.y;
        flg = match(t,con);
        if(flg){
            cout << "YES" << endl;
            continue;
        }
        cout << "NO" << endl;       
    }
    return 0;
}