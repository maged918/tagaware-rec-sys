//Language: MS C++


#include <iostream>
using namespace std;
int main()
{
    int n, res;
    cin >> n;
    n -= 10;
    if (n > 0 && n < 10 || n == 11) res = 4;
    else if (n == 10) res = 15;
    else res = 0;
    cout << res << endl;
    return 0;
}