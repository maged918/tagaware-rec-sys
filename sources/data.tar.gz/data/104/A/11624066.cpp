//Language: GNU C++


 #include<iostream>
#include<string>
using namespace std;
int main()
{
    int n;
    cin>>n;
    if (n<=10||n==22||n==23||n==24||n==25)
    cout<<0<<endl;
    else if (n==20)
        cout<<15<<endl;
    else
        cout<<4<<endl;
    return 0;
}