//Language: GNU C++



#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <set>
using namespace std;



int main(int argc, char *argv)
{
    int input;
    map<int, int> myMap;

    for (int i = 2; i <= 10; i++) {
        myMap[i] = 4;       
    }
    myMap[10] += 11;
    myMap[1] = 4;
    myMap[11] = 4;
    cin >> input;

    if (input <= 10 || input > 21) {cout << "0" << endl; }
    else if (input == 21)  {cout << "4" << endl; }
    else if (input == 11)  {cout << "4" << endl; }
    else {cout << myMap[input-10] << endl;}

    return 0;
}