//Language: MS C++


#include <stdio.h>
#include <math.h>
int main ()
{
int n,m;
scanf("%i",&n);
if (n==20) {printf("15");return 0;}
if (n>=11&&n<=21) {printf("4");return 0;}
else printf("0");
}