//Language: GNU C++


// Blackjack.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include <iostream>
using namespace std;

int main()
{
	int n;
	cin >> n;
	n-=10;
	if(n<=0 || n>=12){
		cout << 0 << endl;;
		return 0;
	}
	int num[12]={0,4,4,4,4,4,4,4,4,4,15,4};
	cout << num[n] << endl;
	return 0;
}

