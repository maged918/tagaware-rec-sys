//Language: GNU C++


#include<stdio.h>
#include<iostream>
using namespace std;
int main()
{int n,a;
    cin>>n;
    if((n<=10)||(n>=22))
    a=0;
    else
    if(n==20)
    a=15;
    else 
    a=4;
    cout<<a;

return 0;
}
