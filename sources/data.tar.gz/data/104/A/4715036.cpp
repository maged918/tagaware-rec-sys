//Language: GNU C++


//by Daulet Sergazin
#include<iostream>
#include<string>
#include<cstdlib>
#include<iomanip>
#include<cmath>
using namespace std;
int n,a[100000];
int main()
{
//freopen("input.txt","r",stdin);
//freopen("output.txt","w",stdout);
cin>>n;
if(n<10){cout<<0;return 0;}
a[0]=0;
for(int i=1;i<=9;i++)
{
a[i]=4;
}
a[10]=15;
a[11]=4;
cout<<a[n-10];
//system("pause");
return 0;
}
