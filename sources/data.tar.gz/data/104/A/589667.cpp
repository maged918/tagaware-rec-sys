//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <queue>
#include <string>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <utility>
#include <sstream>
#include <iostream>
#include <cstdio>
#include <cctype>
#include <cstring>
#include <cmath>
#include <cstdlib>

using namespace std;

typedef pair <int,int> ii;
typedef vector <int> vi;
const long long LONGINF = 99999999999999LL;
const int INF = 999999999;

int main()
{
  int n,ans = 0;
  int values[] = {2,3,4,5,6,7,8,9,10,10,10,10};
  cin >> n;
  if(n <= 10)
    {
      cout << 0 << endl;
      return 0;
    }
  n -= 10;
  for(int i=0; i<52; i++)
    {
      if(i == 10) continue;
      if(i%13 < 12)
	{
	  if(values[i%13] == n) ans++;
	}
      else if(i%13==12)
	{
	  if(n == 1 || n == 11) ans++;
	}
    }
  cout << ans << endl;
  return 0;
}
