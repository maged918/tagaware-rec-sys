//Language: MS C++


#include<stdio.h>
#include<iostream>
#include<string.h>
#include<queue>
#include<stack>
#include<set>
using namespace std;

int main()
{
	int n;
	scanf("%d",&n);
	n=n-10;
	if(n==0)
		printf("0\n");
	else if(n>=1&&n<=9)
		printf("4\n");
	else if(n==10)
		printf("15\n");
	else if(n==11||n==1)
		printf("4\n");
	else
		printf("0\n");
}
