//Language: MS C++


    #include <iostream>
    #include <algorithm>
    #include <string>

    using namespace std;

    int n;

    int main()
    {
            cin>>n;
            n-=10;
            if ((n>11)||(n<=0)) n=0; else {
                    if (n==10) n=15; else n=4;
            }
            cout<<n<<endl;
            return 0;
    }