//Language: GNU C++


// #includes {{{
#include <algorithm>
#include <numeric>

#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <queue>
#include <deque>
#include <stack>
#include <set>
#include <map>

#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cassert>
#include <cstring>

#include <cmath>
#include <complex>
using namespace std;
// }}}
// pre-written code {{{
#define rep(i,n) for(int i=0;i<(int)(n);++i)
#define rrep(i,a,b) for(int i=(int)(a);i<(int)(b);++i)
#define foreach(i,c) for(__typeof((c).begin())i=(c).begin();i!=(c).end();++i)
#define all(c) (c).begin(), (c).end()
#define MP make_pair

typedef long long Int;
typedef long long ll;
typedef long double ld;

typedef pair<int,int> pii;
// }}}

int n;

int main() {
	cin>>n;
	n-=10;
	int s=0;
	if(n==0){
		cout<<0<<endl;
	}else if(n==1){
		cout<<4<<endl;
	}else if(2<=n and n<=9){
		cout<<4<<endl;
	}else if(n==10){
		cout<<15<<endl;
	}else if(n==11){
		cout<<4<<endl;
	}else{
		cout<<0<<endl;
	}
	return 0;
}

