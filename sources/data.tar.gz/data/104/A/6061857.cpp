//Language: GNU C++


#include <stdio.h>
#include <cstring>
#include <algorithm>
#include <vector>
#include <iostream>
#define S(x) scanf("%d",&x)
#define P(x) printf("%d\n",x)
#define rep(i,a) for(int i=0;i<a;i++)
using namespace std;
int main() {
    int  n,A[16]={0};
    A[1]=A[2]=A[3]=A[4]=A[5]=A[6]=A[7]=A[8]=A[9]=4;A[10]=15;A[11]=4;
    S(n);
    if(n-10<1) P(0);
    else P(A[n-10]);
    return 0;
}
