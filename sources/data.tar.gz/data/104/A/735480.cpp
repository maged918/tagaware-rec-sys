//Language: GNU C++


#include <iostream>
#include <map>
#include <algorithm>

using namespace std;

int main()
{
	int n; cin >> n;

	cout << (10 < n && n < 22 ? (n == 20 ? 15 : 4) : 0) << endl;

	return 0;
}
