//Language: GNU C++


#include <stdio.h>
int solve(int n)
{
	if(n<=10)return 0;
	if(n>21)return 0;
	if(n==21)return 4;
	if(n==20)return 15;
	if(n==11)return 4;
	if(n>11&&n<20)return 4;
}
int main()
{
	int n;
	scanf("%d",&n);
	printf("%d\n",solve(n));
	return 0;
}

