//Language: GNU C++


#include <stdio.h>

#include <math.h>
int main ()
{
	int n,m;

	scanf ("%d",&n);
	
	m=n-10;
	if ((m>=1)&&(m<=11)&&(m!=10))
	printf ("4");
	if (m==10)
	printf ("15");
	if ((m<=0)||(m>11))
	printf("0");
	

	return 0;
}
