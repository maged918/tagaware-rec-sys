//Language: GNU C++11


#include <cstdio>

int main()
{
    int n;
    long long sum = 0;
    scanf("%d", &n);
    for(int i = 0; i < n; i++) {
        long long crt;
        scanf("%I64d", &crt);
        sum += (i + 1) * (crt - 1) + 1;
    }
    printf("%I64d\n", sum);
    return 0;
}

	 		 	  	    				 			  		  				