//Language: GNU C++11


#include<iostream>
#include<string>
using namespace std;
long long n;
long long a[111];
long long ans;
int main()
{
	ans = 0;
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		ans += a[i]+(a[i]-1)*(i-1);
	}
	cout << ans << endl;
	
	return 0;
}