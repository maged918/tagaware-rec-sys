//Language: GNU C++


#include <algorithm>
#include <iostream>
#include <cstring>
#include <string>
#include <vector>
#include <cstdio>
#include <stack>
#include <queue>
#include <cmath>
using namespace std;

int n;
__int64 sum;
__int64 ans[110];

//
void solve(){
    sum = 0;
    int tmp;
    for(int i = 1; i <= n ; i++){ 
        tmp = 0;
        for(int j = 1 ; j < i ; j++) tmp++;
        sum += tmp*(ans[i]-1) + ans[i];//推出的公式
    }
    printf("%I64d\n" , sum);
}

int main(){
    //freopen("input.txt" , "r" , stdin);
    while(scanf("%d" , &n) != EOF){
        memset(ans , 0 , sizeof(ans));
        for(int i = 1 ; i <= n ; i++)      
            cin>>ans[i];
        solve();
    }
    return 0;
}


    					 	  		 		   			 		 	 	