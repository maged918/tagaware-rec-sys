//Language: MS C++


#include <iostream>
#include <string>
#include <cmath>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;

int main()
{
	int n;
	cin >> n;
	long long clicks = 0;
	for (int i = 0; i < n; i++)
	{
		long long ans;
		cin >> ans;
		clicks += ans;
		clicks += (ans - 1) * i;
	}
	cout << clicks << endl;
	return 0;
}
