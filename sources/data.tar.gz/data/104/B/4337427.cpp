//Language: MS C++


#include <iostream>
#include <string>
#include <cstdio>
#include <cmath>
#include <vector>
#include <map>
#include <sstream>
#include <algorithm>
using namespace std;
#define rep(_m,s,e) for(ll _m=s;_m<e;_m++)
#define ll long long
#define li __int64
int  toInt(string s)   {int r=0; istringstream sin(s); sin>>r; return r;}
ll   toInt64(string s) {ll r=0; istringstream sin(s); sin>>r; return r;}
double  toDouble(string s){double r=0; istringstream sin(s); sin>>r; return r;}
string toString(ll n) {string s,s1; while (n / 10 > 0){ s += (char)((n%10) + 48); n/=10;} s += (char)((n%10) + 48); n/=10; s1 = s; rep(i,0,s.length()) s1[(s.length()-1)-i] = s[i]; return s1;}
bool isUpperCase(char c){return c >= 'A' && c <= 'Z';}
bool isLowerCase(char c){return c >= 'a' && c <= 'z';}
bool isLetter(char c)   {return c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z';}
bool isDigit(char c)    {return c >= '0' && c <= '9';}
char toLowerCase(char c){return (isUpperCase(c))?(c + 32) : c;}
char toUpperCase(char c){return (isLowerCase(c))?(c - 32) : c;}
int main()
{
	ios::sync_with_stdio(0);
	ll n,ans = 0,dp[101];
	cin >> n;
	rep(i,0,n)
		cin >> dp[i];
	rep(i,1,n)
	{
		dp[i] = ((dp[i]-1)*(i+1));
		dp[i]++;
	}
	rep(i,0,n)
		ans += dp[i];
	cout << ans << endl;
}
