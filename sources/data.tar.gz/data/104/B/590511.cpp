//Language: GNU C++


#include <stdio.h>
#include <string.h>

int main()
{
    long long n,ans,x;

    ans=0;
    while(scanf("%I64d",&n)==1)
    {
        ans=0;
        for(int i=0;i<n;i++)
        {
            scanf("%I64d",&x);
            //printf("%I64d ",x);
            ans+=i*(x-1)+x;
        }
        printf("%I64d\n",ans);
    }
    return 0;
}
