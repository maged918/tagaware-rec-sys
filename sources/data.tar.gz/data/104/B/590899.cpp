//Language: GNU C++


#include <stdio.h>
#include <iostream>
using namespace std;
main()
{
	int n,i;
	long long int a[105],sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	cin>>a[i];
	for(i=0;i<n;i++)
	sum+=1+(a[i]-1)*(i+1);
	cout<<sum<<endl;
	return 0;
}
