//Language: MS C++


#include<stdio.h>
int main()
{
	__int64 n,sum,s;
	while(~scanf("%I64d",&n))
	{
		scanf("%I64d",&sum);
		for(int i=2;i<=n;i++)
		{
			scanf("%I64d",&s);
			sum+=i*(s-1)+1;
		}
		printf("%I64d\n",sum);
	}
	return 0;
}