//Language: GNU C++


#include <iostream>

using namespace std;


int main(){

  int n;
  cin >> n;
  unsigned long long ret = 0;
  
  for(int i=1;i<=n;i++){
    unsigned long long a;
    cin >> a;
    ret += a + (a-1)*(i-1);
  }

  //long long test = 1000000000000;
  //cout << test << endl;
  cout << ret << endl;

}
