//Language: GNU C++


#include <cstdlib>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    int n;
    __int64 *p;
    __int64 S=0;
    cin>>n;
    p = new __int64[n];
    __int64 t;
    for(int i=0;i<n;i++)
    {
        cin>>t;
        p[i]=t;
    }
    for(int i=0;i<n;i++)
    {
        S+=p[i]+i*(p[i]-1);
    }
    cout<<S;
    //system("PAUSE");
    return EXIT_SUCCESS;
}
