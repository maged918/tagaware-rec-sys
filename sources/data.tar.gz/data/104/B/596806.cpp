//Language: GNU C++


#include <cstdio>
#include <iostream>
using namespace std;

#define REP(i,b,n) for(int i=b;i<(int)n;i++)
#define rep(i,n) REP(i,0,n)
#define foreach(i,c) for(__typeof((c).begin())i=(c).begin();i!=(c).end();i++)

int main(int argc, char* argv[]) {
  int n;
  long long a[100];
  cin>>n;
  rep(i,n) cin>>a[i];
  
  long long res = 0;
  rep(i,n) {
    res += 1;
    if (a[i] > 1) {
      res += i * (a[i]-1);
      res += a[i]-1;
    }
  }
  cout<<res<<endl;
  return 0;
}
