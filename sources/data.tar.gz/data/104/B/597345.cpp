//Language: GNU C++


// URL : http://www.codeforces.com/contest/104/problem/B
// Testing Pants for Sadness

#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <set>

using namespace std;

int main()
{
    long long n;
    cin >> n;
    long long arr[n];
    for(int i = 0; i < n; ++i)cin >> arr[i];
    long long ans = n;
    for(int i = 0; i < n; ++i)
    {
            ans += (long long)(arr[i] - 1) * (i + 1);
    }
    cout << ans << endl;
    return 0;
}
