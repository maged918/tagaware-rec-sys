//Language: GNU C++


#include <cstdio>
#include <iostream>
using namespace std;

int main(){
    int n;
    long long ret=0LL,ans;
    scanf("%d",&n);
    for (int i=1;i<=n;++i){
        scanf("%I64d",&ans);
        ret+=((ans-1)*i)+1;
    }
    printf("%I64d\n",ret);
    return 0;
}
