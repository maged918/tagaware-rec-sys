//Language: MS C++


#include<stdio.h>
int main()
{
	__int64 sum;
	int n;
	__int64 a[105];
	while(~scanf("%d",&n))
	{
		int i;
		sum=0;
		for(i=0;i<n;i++)
		{
			scanf("%I64d",&a[i]);
		}
		for(i=n-1;i>=1;i--)
		{
			sum+=a[i];
			sum+=(a[i]-1)*i;
		}
		sum+=a[0];
		printf("%I64d\n",sum);
	}
	return 0;
}
      		 		    			    			