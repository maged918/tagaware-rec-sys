//Language: GNU C++


#include<iostream>
using namespace std;
int main(){
	int n;
	cin>>n;
	long long res = 0;
	for(int i = 0; i<n; i++){
		long long x;
		cin>>x;
		if(i!=n-1){
			res+=(i+1)*(x-1);
		}
		else{
			res+=(i+1)*x;
		}
	}
	cout<<res<<endl;
}


