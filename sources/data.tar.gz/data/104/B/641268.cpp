//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define le 105
__int64 ar[le];
int n;

void input(){
    int i;
    for(i = 1;i <= n;i++)
        scanf("%I64d",&ar[i]);
}

void deal(){
    int i;
    long long sum = 0;
    for(i = 1;i <= n;i++)
        sum += i * (ar[i] - 1) + 1;
    printf("%I64d\n",sum);
}

int main(void){
    while(scanf("%d",&n) == 1){
        input();
        deal();
    }
    return 0;
}