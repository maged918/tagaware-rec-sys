//Language: GNU C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <istream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <ctime>

#define all(x) (x).begin(),(x).end()
#define dump(x)  cerr << #x << " = " << (x) << endl;
#define debug(x) cerr << #x << " = " << (x) << " (L" << __LINE__ << ")" << " " << __FILE__ << endl;

using namespace std;

int main(){
  unsigned long long n,a,c=0;
  cin >> n;
  for(int i=0; i<n; i++){
    cin >> a;
    c+=(a-1)*(i+1);
  }
  c+=n;
  cout << c << endl;
}

// sortしてbinary_search(all(x),key)->keyを二分探索(http://www.geocities.jp/ky_webid/cpp/library/020.html)
// xor A = (B xor A) xor A = B xor (A xor A) = B xor 0 = B
