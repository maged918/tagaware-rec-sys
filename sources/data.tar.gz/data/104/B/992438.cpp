//Language: GNU C++0x


#include <iostream>
#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <string>
#include <cstring>
#include <cmath>
#include <climits>
#include <algorithm>
#include <cstdio>
using namespace std;

typedef unsigned long long ULL;
typedef long long LL;

#define REP(i,n)      FOR(i,0,n)
#define FOR(i,a,b)    for(int i = a; i < b; i++)
#define ROF(i,a,b)    for(int i=a;i>b;i--)
#define GI 		      ({int t;scanf("%d",&t);t;})
#define GL 		      ({LL t;scanf("%lld",&t);t;})
#define GD 		      ({double t;scanf("%lf",&t);t;})
#define pb 	          push_back
#define mp 	          make_pair
#define MOD 	      1000000007
#define INF	          (int)1e9
#define EPS	          1e-9
#define TR(a,it)      for(typeof((a).begin()) it = (a).begin(); it!=(a).end(); ++it)

int main()
{
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);

	int T, t = 0, n;
	LL sum = 0;
	scanf("%d", &n);
	int a[n+1];
	for (int i=1; i<=n; i++)
        scanf("%d", &a[i]);
    for (int i=1; i<=n; i++){
        sum += (LL)(a[i]-1)*i + 1;
    }
    cout << sum << endl;
	return 0;
}
