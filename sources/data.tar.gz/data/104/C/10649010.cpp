//Language: GNU C++11


# include<bits/stdc++.h>
using namespace std;
# define MAX 102   
int gra[MAX][MAX],vis[MAX];  
int n,m;  
void dfs(int u)  
{  
	int i;
    vis[u]=1;  
    for(i=1;i<=n;i++)  
    if(0==vis[i]&&gra[u][i])dfs(i);  
}  
int main()  
{  
    int i,u,v;
    cin>>n>>m; 
    for(i=1;i<=m;i++)  
    {  
        cin>>u>>v; 
        gra[u][v]=gra[v][u]=1;  
    }  
    dfs(1);  
    for(i=1;i<=n;i++)  
    if(0==vis[i])  
    {  
        cout<<"NO"<<endl; 
        return 0;  
    }  
    if(m==n) cout<<"FHTAGN!"<<endl;  
    else cout<<"NO"<<endl;  
    return 0;  
}
 	 	 	  	    	 		 	 	   		 	 		