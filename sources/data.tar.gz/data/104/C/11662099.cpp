//Language: GNU C++11


//Bismillah
#include <bits/stdc++.h>
using namespace std;
#define FOR(i,begin,end) for (ll i=begin;i<=end;i++)
#define rep(i,t) for (ll i=0;i<t;i++)
#define pb push_back
#define mp make_pair
typedef long long ll;
int n,m;
bool mark[1100];
vector <int> a[1100];
void dfs(int u)
{
    mark[u] = true;
    rep(j,a[u].size())
    {
        int v = a[u][j];
        if (!mark[v])
            dfs(v);
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    int n,m;
    cin>>n>>m;
    rep(i,m)
    {
        int x,y;
        cin>>x>>y;
        a[x].pb(y);
        a[y].pb(x);
    }
    int comp = 0;
    FOR(i,1,n)
    {
        if (!mark[i])
            dfs(i) , comp++;
    }
    //ejtemayi az derakht ha ke faghat root ha dor tashkil bedan <--> n = m
    //(mesal bezan shohood yadet biad!) :D
    if (comp==1 && n==m) //yek moallefe , n=m (sharte kafi)
        cout<<"FHTAGN!";
    else
        cout<<"NO";
    return 0;
}