//Language: GNU C++


#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;
int cnt,vis[110];
vector<int>g[110];
void dfs(int x)
{
	cnt++;	vis[x]=1;
	for(int i=0;i<g[x].size();++i)if(!vis[g[x][i]])
		dfs(g[x][i]);
}
int main()
{
	memset(vis,0,sizeof(vis));
	int n,m,u,v;
	scanf("%d %d",&n,&m);
	for(int i=0;i<m;++i)
	{
		scanf("%d %d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	cnt=0;
	dfs(1);
	if(m!=n||cnt!=n)
		printf("NO\n");
	else
		printf("FHTAGN!\n");
	return 0;
}
 		  	  		     	   			  		