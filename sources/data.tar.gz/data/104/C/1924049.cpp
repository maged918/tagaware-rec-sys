//Language: GNU C++


#include<iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
typedef long long ll;
const int Maxn=110;
struct Edge
{
    int from,to,next;
    bool dlt;
    Edge(int from,int to,int next):
    from(from),to(to),next(next){dlt=0;}
    Edge(){}
}edge[Maxn*Maxn];
int box[Maxn],size;
void add(int from,int to)
{
    edge[size]=Edge(from,to,box[from]);
    box[from]=size++;
}
vector<int>vec;
int n,m;
bool visit[Maxn];
int ok;
int stack[Maxn],sp;
void dfs(int x,int l)
{
   // cout<<x<<" "<<ok<<endl;
    if(ok==2)return;
    stack[sp++]=x;
    visit[x]=1;
    for(int i=box[x];i!=-1;i=edge[i].next)
    {
        int x1=edge[i].to;
        if(x1==l||edge[i].dlt)continue;
        edge[i].dlt=edge[i^1].dlt=1;
        if(visit[x1]==1)
        {
        //    cout<<x<<" "<<x1<<" "<<ok<<endl;
            if(ok==0)ok=1;
            else if(ok==1)ok=2;
            vec.push_back(x1);
            for(int j=sp-1;stack[j]!=x1;--j)
                vec.push_back(stack[j]);
            continue;
        }
        dfs(x1,x);
    }
}
bool connected()
{
    for(int i=1;i<=n;++i)if(!visit[i])return 0;
    return 1;
}
int main()
{
  //  freopen("in.txt","r",stdin);
    scanf("%d%d",&n,&m);
    memset(box,-1,sizeof(box));size=0;
    for(int i=0;i<m;++i)
    {
        int x,y;scanf("%d%d",&x,&y);
        add(x,y),add(y,x);
    }
    ok=0;sp=0;
    dfs(1,-1);
    if(ok==1&&vec.size()>=3&&connected())printf("FHTAGN!\n");
    else printf("NO\n");
    return 0;
}
