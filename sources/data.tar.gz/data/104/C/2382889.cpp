//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<algorithm>
#include<vector>
using namespace std;
vector<int> v[105];
int chk[105];
int n,m;
void dfs(int x)
{
    if(chk[x]==1) return;
    chk[x]=1;
    int i;
    for(i=0;i<v[x].size();i++)
    {
        dfs(v[x][i]);
    }
}
bool t[105][105];
bool fin;
void f(int x,int pa)
{
    if(chk[x]==2) return;
    if(chk[x]==1) //CIRCLE
    {
        //printf("%d %d\n",pa,x);
        t[pa][x]=0;
        t[x][pa]=0;
        fin=1;
        return;
    }
    chk[x]=1;
    for(int i=1;i<=n;i++)
    {
        if(t[x][i]==1 && i!=pa)
        {
            f(i,x);
            if(fin) break;
        }
    }
    chk[x]=2;
    return;
}
main()
{
    scanf("%d %d",&n,&m);
    int i;
    bool no=0;
    int a,b;
    for(i=0;i<m;i++)
    {
        scanf("%d %d",&a,&b);
        v[a].push_back(b);
        v[b].push_back(a);
        t[a][b]=1;
        t[b][a]=1;
    }
    dfs(1);
    for(i=1;i<=n;i++)
    {
        if(chk[i]==0) break;
    }
    if(i<=n) no=1;
    else
    {
        for(i=1;i<=n;i++) chk[i]=0;
        f(1,0);
        if(fin==1)
        {
            for(i=1;i<=n;i++) chk[i]=0;
            fin=0;
            f(1,0);
            if(fin==1) no=1;
        }
        else no=1;
    }
    if(no) printf("NO\n");
    else printf("FHTAGN!\n");
    scanf(" ");
}