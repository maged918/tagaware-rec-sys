//Language: MS C++


#include <iostream>
#include <string>
#include <cstdio>
#include <queue>
#include <cmath>
#include <vector>
#include <map>
#include <sstream>
#include <algorithm>
using namespace std;
#define rep(_m,s,e) for(ll _m=s;_m<e;_m++)
#define ll long long
#define li __int64
int  toInt(string s)   {int r=0; istringstream sin(s); sin>>r; return r;}
ll   toInt64(string s) {ll r=0; istringstream sin(s); sin>>r; return r;}
double  toDouble(string s){double r=0; istringstream sin(s); sin>>r; return r;}
string toString(ll n) {string s,s1; while (n / 10 > 0){ s += (char)((n%10) + 48); n/=10;} s += (char)((n%10) + 48); n/=10; s1 = s; rep(i,0,s.length()) s1[(s.length()-1)-i] = s[i]; return s1;}
bool isUpperCase(char c){return c >= 'A' && c <= 'Z';}
bool isLowerCase(char c){return c >= 'a' && c <= 'z';}
bool isLetter(char c)   {return c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z';}
bool isDigit(char c)    {return c >= '0' && c <= '9';}
char toLowerCase(char c){return (isUpperCase(c))?(c + 32) : c;}
char toUpperCase(char c){return (isLowerCase(c))?(c - 32) : c;}

bool hambandi[101],matrix[101][101],mark[101];
int n, m;
queue <int> q;

bool hamband()
{
	while (!q.empty())
	{
		int f = q.front();
		q.pop();
		for (int i = 1;i <= n;i++)
		{
			if (matrix[f][i] && !mark[i])
			{
				mark[i] = true;
				q.push(i);
			}
		}
	}
	for (int i = 1; i <= n; i++)
		if (!mark[i])
			return false;
	return true;
}

bool m2[101];
int pedar[101];

int bfs()
{
	int num = 0,last = -1;
	while (!q.empty())
	{
		int f = q.front();
		q.pop();
		for (int i = 1;i <= n;i++)
		{
			if (matrix[f][i] && mark[i] && i != last && !m2[f] && pedar[f] != i)
			{
				num++;
				m2[i] = true;
				//matrix[i][f] = matrix[f][i] = false;
			}
			if (matrix[f][i] && !mark[i])
			{
				mark[i] = true;
				q.push(i);
				pedar[i] = f;
			}
		}
		last = f;
	}
	return num;
}

int main()
{
	ios::sync_with_stdio(0);
	cin >> n >> m;
	int a,b;
	rep(i,0,m)
	{
		cin >> a >> b;
		matrix[a][b] = matrix[b][a] = true;
	}
	q.push(1);
	mark[1] = true;
	bool f = hamband();
	for (int i = 1; i <= 100; i++)
		mark[i] = false;
	q.push(1);
	mark[1] = true;
	int bf = bfs();
	if (bf == 1 && f)
	{
		cout << "FHTAGN!" << endl;
		return 0; 
	}
	else cout << "NO" << endl;
}
