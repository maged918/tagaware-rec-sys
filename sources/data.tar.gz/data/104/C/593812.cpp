//Language: GNU C++


#include <cstdlib>
#include <iostream>
#include <cstdio>

using namespace std;

const int MaxN = 100500;

int mark[MaxN], start[MaxN], finish[MaxN], n, m, flag;

void dfs(int v, int pr) {
  int i;
  mark[v] = 1;
  for(i = 1; i <= m; i++) {
    if (start[i] == v) {
      if ((mark[finish[i]] != 2) && (finish[i] != pr)) {
        if (mark[finish[i]] == 1) {
          flag++;
        }
        else {
          dfs(finish[i], v);
        }
      }
    }
    
    if (finish[i] == v) {
      if ((mark[start[i]] != 2) && (start[i] != pr)) {
        if (mark[start[i]] == 1) {
          flag++;
        }
        else {
          dfs(start[i], v);
        }
      }
    }
  }
  mark[v] = 2;
}

int main() {
  //freopen("input.txt", "r", stdin);
  //freopen("output.txt", "w", stdout); 
  int i, j;
  flag = 0;
  cin >> n >> m;
  for(i = 1; i <= m; i++) {
    cin >> start[i] >> finish[i];
    if (i <= n) {
      mark[i] = 0;
    }
  }
  int color = 0;
  for(i = 1; i <= n; i++) {
    if (mark[i] == 0) {    
      dfs(i, -1);
      color++;
      //cout << i << endl;  
    } 
  }  
  //cout << color << endl;
  if (color > 1) {
    cout << "NO";
    return 0;
  }
  if (flag == 0) {
    cout << "NO";
  }
  if (flag == 1) {
    cout << "FHTAGN!";
  }
  if (flag > 1) {
    cout << "NO";
  }
  cin.get();
  cin.get();
}
