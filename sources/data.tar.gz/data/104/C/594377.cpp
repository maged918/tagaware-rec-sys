//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
#include<memory.h>
int v[210],ok,root[210];
int g[210][210],cnt,q[210],ans,n;
void dfs(int pre,int now,int k)
{
    int i,t;
    if(ok) return ;
    v[now]=1;
    q[k]=now;
    //for(i=1;i<=k;i++) printf("%d ",q[i]);printf("\n");
    //printf("k=%d  now=%d\n",k,now);getchar();
    for(i=1;i<=g[now][0];i++)
    {
        t=g[now][i];
        //printf("t=%d\n",t);
        if(t==pre) continue;
        if(!v[t]) 
        {
            dfs(now,t,k+1);
        }
        else
        {
            ok=1;
            if(cnt==0) cnt=k;
            return ;
        }
        
    }
}
void dfs1(int pre,int now)
{
    int i,t;
    v[now]=1;
    //printf("now=%d\n",now);getchar();
    if(ans==-1) return;
    for(i=1;i<=g[now][0];i++)
    {
        t=g[now][i];
        if(t==pre) continue;
        if(root[t]) continue;
       // printf("t=%d\n",t);
        if(v[t])
        {
            ans=-1;
            return ;
        }
        else
        {
            v[t]=1;
            dfs1(now,t);
        }
    }
}
int chk()
{
    if(ok==0) return 0;
    int i,j,he;

    he=0;
    for(i=1;i<=cnt;i++)
        for(j=1;j<=g[q[i]][0];j++)
            if(root[g[q[i]][j]]) he++;

                if(he!=cnt*2) return 0;


    memset(v,0,sizeof(v));
    for(i=1;i<=cnt;i++) v[q[i]]=1;

    ans=1;
    for(i=1;i<=cnt;i++)
    {
        dfs1(-1,q[i]);
        if(ans==-1) return 0;
    }
    for(i=1;i<=n;i++) if(!v[i]) return 0;
    return 1;
}
int main()
{
    int m,i,j,t,x,y;
    scanf("%d%d",&n,&m);
    memset(g,0,sizeof(g));
    for(i=1;i<=m;i++)
    {
        scanf("%d%d",&x,&y);
        t=++g[x][0];
        g[x][t]=y;
        t=++g[y][0];
        g[y][t]=x;
    }

    //for(i=1;i<=n;i++) {for(j=1;j<=g[i][0];j++) printf("%d ",g[i][j]);printf("\n");}


    for(i=1;i<=n;i++)
        {
            memset(v,0,sizeof(v));
            ok=0;
            cnt=0;
            dfs(-1,i,1);
            if(ok==1)break;
        }
    //printf("cnt=%d\n",cnt);
    //for(i=1;i<=cnt;i++) printf("%d ",q[i]);getchar();
    
    memset(root,0,sizeof(root));
    for(i=1;i<=cnt;i++)
    {
        root[q[i]]=1;
    }
    if(chk())
    
        printf("FHTAGN!\n");
        
    else printf("NO\n");
  
    
    return 0;
}