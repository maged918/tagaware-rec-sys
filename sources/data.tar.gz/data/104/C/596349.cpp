//Language: GNU C++


#include <iostream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <utility>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>
#include <stack>
#include <cstdlib>
#include <bitset>

using namespace std;

#define MAXN 110
#define MAXM 110
#define EPS 1e-8
#define INF (1<<30)
#define FILE "C"
#define PB push_back
#define MP make_pair
#define FT first
#define SD second
#define ALL(x) (x).begin(), (x).end()
#define SZ(x) ((int) (x).size())
#define REP(i, n) for(int i = 0; i < (n); ++i)
#define FOR(i, a, b) for(int i = (a); i < (b); ++i)
#define FORD(i, a, b) for(int i = (a); i > (b); --i)

int n, m, u, v, c, cc;
bool b[MAXN][MAXN] = {0};
queue <pair <int, int> > q;
int d[MAXN];
int buf;
int p[MAXN];

int cicle() {
	cc = 0;
	REP(i, n) d[i] = INF;
	q.push(MP(0, 0));
	d[0] = 0;
	p[0] = 0;
	while (!q.empty()) {
		c = (q.front()).FT;
		buf = (q.front()).SD;
//		cout << c << endl;
		q.pop();
		REP(i, n) {                                    
			if (b[c][i] && d[i] != INF && p[c] != i) {
				cc++;
				u = c; v = i;
//				cout << u << ' ' << v << ' ' << d[i] << ' ' << buf << endl;
			}
			if (b[c][i] && d[i] > d[c] + 1) {
				d[i] = d[c] + 1;
				p[i] = c;
				q.push(MP(i, buf + 1));
			}
		}
	}
	return cc;
}

int main () {

	ios_base :: sync_with_stdio(false);
	
//	freopen(FILE".in", "r", stdin);
//	freopen(FILE".out", "w", stdout);
	
	cin >> n >> m;
	REP(i, m) {
		cin >> u >> v;
		b[--u][--v] = b[v][u] = 1;
	}

	if (!cicle()) {
		cout << "NO";
		return 0;
	} else {
		b[u][v] = b[v][u] = 0;
		if (cicle()) {
			cout << "NO";
			return 0;
		}
		b[u][v] = b[v][u] = 1;
	}

	REP(i, n)
		if (d[i] == INF) {
			cout << "NO";
			return 0;
		}

	cout << "FHTAGN!";
	
	return 0;
}
