//Language: GNU C++


#include <iostream>
#include <vector>
#include <map>

using namespace std;

int used[101];
map<int,vector<int> > arr;


void dfs(int ver)
{
  used[ver] = 1;
  for(int i = 0; i < arr[ver].size(); i++)
    if(!used[arr[ver][i]]) dfs(arr[ver][i]);
}


int main()
{
   int n,m,c1,c2,k = 0,pred = 0;
   cin >> n >> m;

   for(int i =  0; i < m; i++)
   {
     cin >> c1 >> c2;
     arr[c1].push_back(c2);
     arr[c2].push_back(c1);
   }
   try
   {
     if (n!=m) throw 1;
     dfs(1);
     for(int j = 1; j <=n; j++) if(!used[j]) throw 1;
     cout << "FHTAGN!" ;
   }
   catch(int)
   {
    cout <<"NO";
   } 

}

