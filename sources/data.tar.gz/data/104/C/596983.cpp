//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <set>
#include <cmath>
#include <cstring>
#include <queue>
#include <list>

using namespace std;

#define foreach(i,n) for(__typeof(n.begin()) i=n.begin();i!=n.end();i++)
#define REP(i,n) for(int i = 0; i < (n); i++)
#define FOR(i,a,b) for(int i = (a); i <= (b); i++)
#define RFOR(i,a,b) for(int i = (a); i >= (b); i--)
#define SIZE(x) ((int)(x).size())
#define LENGTH(x) ((int)(x).length())
#define PB push_back

template<typename T> inline void checkmin(T &a, T b) {if(a>b) a=b;}

const int N = 100;

void dfs(int n,int x,bool *graph,bool *visited)
{
    for(int i = 0; i < n; i++) {
        int y = i;
        if(graph[x*N+y] && !visited[y]) {
            visited[y] = true;
            dfs(n,y,graph,visited);
            // visited[y] = 0;
        }
    }
}

bool isconnected(int n,bool *graph)
{
    bool visited[N];
    memset(visited,0x00,sizeof(visited));
    dfs(n,0,graph,visited);
    for(int i = 0; i < n; i++) if(!visited[i]) return false;
    return true;
}

int haveloop(int depth,int n,int x,bool *graph,int *visited,int *order,int &oi)
{
    order[n-depth] = x;
    for(int i = 0; i < n; i++) {
        int y = i;
        if(graph[x*N+y]==true) {
            if(visited[y]) {
                if(visited[y]-depth>1) {
                    oi = n-visited[y];
                    return visited[y]-depth+1;
                }
                else continue;
            }
            visited[y] = depth-1;
            int res = haveloop(depth-1,n,y,graph,visited,order,oi);
            if(res != 0) return res;
            // visited[y] = 0;
        }
    }
    return 0;
}

void solve()
{
    int n,m;
    bool graph[N*N];

    memset(graph,0x00,sizeof(graph));
    scanf("%d %d", &n, &m);
    for(int i = 0; i < m; i++) {
        int x,y;
        scanf("%d %d", &x, &y);
        x--;y--;
        graph[x*N+y] = true;
        graph[y*N+x] = true;
    }

    if(!isconnected(n,graph)) {
        cout << "NO" << endl;
        return;
    }

    int visited[N];
    int order[N+1],oi;

    int len;
    len = 0;

    memset(visited,0x00,sizeof(visited));
    visited[0] = n;
    len = haveloop(n,n,0,graph,visited,order,oi);

    if(len == 0) {
        cout << "NO" << endl;
        return;
    }

    bool res = true;
    int a, b = order[oi+len-1];
    for(int i = 0; i < len; i++) {
        a = b; b = order[oi+i];
        graph[a*N+b] = false;
        graph[b*N+a] = false;

        memset(visited,0x00,sizeof(visited));
        visited[0] = n;
        len = haveloop(n,n,0,graph,visited,order,oi);

        if(len > 0) {
            res = false;
            break;
        }

        graph[a*N+b] = true;
        graph[b*N+a] = true;
    }
    if(res) cout << "FHTAGN!" << endl;
    else cout << "NO" << endl;
}

int main()
{
	solve();
	return 0;
}
