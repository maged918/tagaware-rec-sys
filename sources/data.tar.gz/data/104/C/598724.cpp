//Language: GNU C++


#include <cstring>
#include <cstdio>
using namespace std;

int map[110][110];
int n,m;
int main()
{
	scanf("%d%d",&n,&m);
	memset(map,0,sizeof(map));

	int i;
	for (i = 1;i<=m;i++)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		map[a][b] = map[b][a] = 1;
	}

	int ans = 0;

	if (n==m)
	{
		int j,k;
		for (k = 1;k<=n;k++)
		{
			for (i = 1;i<=n;i++)
			{
				for (j=1;j<=n;j++)
				{
					if (map[i][k] && map[k][j])
						map[i][j] = 1;
				}
			}
		}
		ans = 1;
		for (i = 2;i<=n;i++)
		{
			if (map[1][i] == 0)
			{
				ans = 0;
				break;
			}			
		}
	}
	
	if (ans) printf("FHTAGN!\n");
	else printf("NO\n");

	return 0;
}
