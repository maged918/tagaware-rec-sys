//Language: GNU C++


#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<cmath>
#include<set>
#include<fstream>
#include<queue>
#include<fstream>
#include<map>
#include<sstream>

using namespace std;

map<int,vector<int> > v;
map<int,bool> vis;
int num;
void calc(int x)
{
    if(!vis[x])
    {
        num++;
        vis[x]=true;
        for(int i=0;i<v[x].size();i++)
        {
            if(!vis[v[x][i]])
            {
                calc(v[x][i]);
            }
        }
    }
}

int  main()
{
    num=0;
    int n,m;
    cin>>n>>m;

    for(int i=0;i<m;i++)
    {
        int n1,n2;
        cin>>n1>>n2;
        v[n1].push_back(n2);
        v[n2].push_back(n1);
    }

    if(n==m)
    {
        calc(1);
        if(num==m)
            cout<<"FHTAGN!\n";
        else
            cout<<"NO\n";
    }
    else
        cout<<"NO\n";




    //system("pause");
    return 0;
}