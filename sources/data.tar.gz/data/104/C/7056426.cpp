//Language: MS C++


#include <iostream>
#include <vector>
using namespace std;

int id[100];
int sz[100];

void init()
{
	for(int i=0;i<100;i++)
	{
		id[i] = i;
		sz[i] = 1;
	}
}

int find(int i)
{
	int j = i;
	while(id[j]!=j)
		j = id[j];
	id[i] = j;
	return j;
}

void join(int i,int j)
{
	int ri = find(i);
	int rj = find(j);
	if(ri==rj) return;
	if(sz[ri]<sz[rj])
	{
		id[ri] = rj;
		sz[rj] += sz[ri];
	}
	else
	{
		id[rj] = ri;
		sz[ri] += sz[rj];
	}
}

int main()
{
	int N,M;
	int a,b;
	cin >> N >> M;
	if(M!=N)
	{
		cout << "NO" << endl;
		return 0;
	}
	init();
	int i;
	for(i=0;i<M;i++)
	{
		cin >> a >> b;
		a--,b--;
		join(a,b);
	}
	int cComp = 0;
	for(i=0;i<N;i++)
		cComp += (find(i)==i);
	if(cComp==1)
		cout << "FHTAGN!" << endl;
	else
		cout << "NO" << endl;
	return 0;
}