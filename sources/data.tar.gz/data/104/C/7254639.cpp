//Language: GNU C++


/*
 * Author:  xtestw
 * Created Time:  2014/7/27 12:47:33
 * File Name: H.cpp
 */
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <time.h>
using namespace std;
const int maxint = -1u>>1;
int ans=0;
vector<int> mp[110];
int vis[110]={0};
int vismp[110][110]={0};
void dfs(int pre,int cur)
{
    if (ans>1) return;
    if (vis[cur]==1){
        ans++;
        return;
    }
    vis[cur]=1;
    for(int i=0;i<mp[cur].size();i++)
    {
        if (mp[cur][i]!=pre && vismp[cur][mp[cur][i]]==0){vismp[cur][mp[cur][i]]=vismp[mp[cur][i]][cur]=1;dfs(cur,mp[cur][i]);}
    }
}
int main() {
#ifndef ONLINE_JUDGE
   freopen("f:/in.txt","r",stdin);
#endif
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){int a,b;scanf("%d%d",&a,&b);mp[a-1].push_back(b-1);mp[b-1].push_back(a-1);}
    dfs(-1,0);
    if (ans==0 || ans>1){cout<<"NO"<<endl;}else{
        int f=0;
        for(int i=0;i<n;i++){if(vis[i]!=1) {f=1;break;}}
       if (f==0) cout<<"FHTAGN!"<<endl;else cout<<"NO"<<endl;}
    return 0;
}

		    		 	  		 		 					   	