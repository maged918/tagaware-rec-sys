//Language: MS C++


// (.Y.)

#define _USE_MATH_DEFINES

#include <cmath>
#include <cstdio>

#include <algorithm>
#include <functional>
#include <iostream>
#include <iterator>
#include <list>
#include <map>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include <vector>

using namespace std;

#define mp make_pair
#define pb push_back

#define DEBUG(x) cout << #x << ": " << (x) << endl;

int n, m;

bool G[110][110];
int  P[110];

//int st = 0;

//void dfs(int u) {
//  P[u] = 1;
//
//  for (int i = 1; i <= n; i++)
//      if ( G[u][i] )
//          if ( P[i] == 0 ) {
//              G[u][i] = G[i][u] = false;
//              dfs(i);
//              G[u][i] = G[i][u] = true;
//
//              if ( st != 0 ) {
//                  G[u][i] = G[i][u] = 0;
//
//                  if ( st == u)
//                      st = 0;
//
//                  break;
//              }
//          }
//          else {
//              
//              st = i;
//              G[u][st] = G[st][u] = false;
//              break;
//          }
//}

int Find(int x) {
    return ( (x == P[x]) ? (x) : (P[x] = Find(P[x])) );
}

void Union(int x, int y) {
    (rand() & 1) ? (P[Find(x)] = Find(y)) : 
                   (P[Find(y)] = Find(x));
}

int main() {
#ifndef ONLINE_JUDGE
    freopen( "input.txt", "rt", stdin );
    //freopen("output.txt", "wt", stdout);
#endif

    cin >> n >> m;

    if (n != m) {
        cout << "NO";
        goto exit;
    }

    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;

        G[u][v] = G[v][u] = true;
    }

    //dfs(1);

    for (int i = 1; i <= n; i++)
        P[i] = i;

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            if ( G[i][j] )
                Union(i, j);

    int cnt = 0;
    for (int i = 1; i <= n; i++)
        if ( i == P[i] )
            cnt++;

    cout << ( (cnt == 1) ? ("FHTAGN!") : ("NO") );

exit:
    return ( 0 );
}
