//Language: GNU C++


/*In the Name of GOD
     ASU(SUST) */
#include <iostream>
#include <string>
#include <map>
#include <queue>
#include <stack>
#include <algorithm>
#include <list>
#include <set>
#include <cmath>
#include <cstring>

#include <stdio.h>
#include <string.h>
#include <sstream>
#include <stdlib.h>
#include <vector>
#include <iomanip>
#include <ctime>
#include <numeric>
using namespace std;

#ifdef __GNUC__
typedef long long ll;typedef unsigned long long ull;
#else
typedef __int64 ll;  typedef unsigned __int64 ull;
#pragma warn -csu
#endif



#define INF 1<<28
#define SIZE 100
#define ERR 1e-9
#define PI 3.141592653589793

#define REP(i,n) for (i=0;i<n;i++)
#define REV(i,n) for (i=n;i>=0;i--)

vector<int>VC[1005];
int nodes,edges,cycle,col[1005];

void rec(int val)
{
    cycle++;
    if(!col[val]) col[val]=1;
    for(int i=0;i<VC[val].size();i++)
     if(!col[VC[val][i]])
      rec(VC[val][i]);
   return;
}
int main()
{
    int i,j,k,v,u;
    scanf("%d %d",&nodes,&edges); cycle=0;
    for(i=0;i<=nodes;i++)
    {
        VC[i].clear();
        col[i]=0;
    }
    for(i=0;i<edges;i++)
    {
        scanf("%d %d",&u,&v);
        VC[u].push_back(v);
        VC[v].push_back(u);
    }
    rec(1);
    if(nodes==edges && nodes==cycle)
    printf("FHTAGN!\n");
    else
    printf("NO\n");
    return 0;
}
