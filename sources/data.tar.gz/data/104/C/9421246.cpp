//Language: GNU C++


#include <bits/stdc++.h>
#define mp              make_pair
#define pb              push_back
#define mem(x, n)       memset(x, n, sizeof(x))
#define INF             0x3fffffff
#define read(x, n)      for ( int i = 0; i < n; i++ ) cin >> x[i]
#define print(x, n)     for ( int i = 0; i < n; i++ ) cout << x[i] << ' '
#define MAX             105

using namespace std;

vector<int> G[MAX];

struct disjoint_set {
    vector<int> parent, rank;
    int c = 0;
    disjoint_set ( int n ) {
        parent = vector<int>(n);
        rank = vector<int>(n, 0);
        for ( int i = 0; i < n; i++ )
            parent[i] = i;
    }

    int find_set ( int x ) {
        if ( parent[x] == x ) return x;
        return parent[x] = find_set(parent[x]);
    }

    bool union_set ( int x, int y ) {
        int x_root = find_set(x);
        int y_root = find_set(y);
        if ( x_root == y_root ) { c++; return false; }
        if ( rank[x_root] > rank[y_root] )
            parent[y_root] = x_root;
        else {
            parent[x_root] = y_root;
            if ( rank[x_root] == rank[y_root] )
                rank[y_root]++;
        }
        return true;
    }

    bool ok ( ) {
        int sets = 0;
        for ( int i = 0; i < parent.size(); i++ ) sets += parent[i] == i;
        return sets == 1 && c == 1;
    }
};

int main ( ) {
    int n, m, a, b;
    cin >> n >> m;
    disjoint_set dsu(n);
    while ( m-- ) {
        cin >> a >> b;
        --a, --b;
        dsu.union_set(a, b);
    }

    cout << (dsu.ok() ? "FHTAGN!" : "NO");
}
