//Language: GNU C++


#include <iostream>
using namespace std;

int main () {
	long long n, k, p;
	cin >> n >> k >> p;
	long long b = n - k;
	if (k == 0) {
		for (int i = 0; i < p; i ++) {
			cout << '.' ;
		}
	}
	else if (b == k) {
		for (int i = 0; i < p; i ++) {
			long long in; cin >> in; 
			if (in % 2 == 0)
				cout << 'X' ;
			else 
				cout << '.' ;
		}
	}
	else if (b < k) {
		for (int i = 0; i < p; i ++) {
			long long in; cin >> in; 
			if (in <= 2*b) {
				if (in % 2 == 0)
					cout << 'X' ;
				else 
					cout << '.' ;
			}
			else 
				cout << 'X' ;
		}
	}
	else if (b > k) {
		if ((b % 2) == (k % 2)) {
			for (int i = 0; i < p; i ++) {
				long long in; cin >> in; 
				if (in > (n - 2*k + 1)) {
					if ((n - in) % 2 == 0) {
						cout << 'X' ;
					}
					else 
						cout << '.' ;
				}
				else 
					cout << '.' ;
			}
		}
		else {
			for (int i = 0; i < p; i ++) {
				long long in; cin >> in;
				if (in == n) {
					cout << 'X' ;
				}
				else if (in > (n - 2*k + 2)) {
					if ((n - in) % 2 == 0) {
						cout << '.' ;
					}
					else 
						cout << 'X' ;
				}
				else 
					cout << '.' ;
			}
		}
	}
	cout << endl;
	//system ("pause");
}