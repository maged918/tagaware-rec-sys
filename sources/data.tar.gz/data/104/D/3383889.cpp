//Language: GNU C++


#include <cstdio>
#include <cmath>
using namespace std;
int main()
{
    //freopen("input.txt", "r", stdin);
    int i = 0, j = 0, p = 0;
    __int64 n = 0, k = 0, x = 0;
    scanf("%I64d %I64d %d", &n, &k, &p);
    if(n&1) n--, k--;
    while(p--)
    {
        scanf("%I64d", &x);
        if((x&1) == 0 && n/2-k<x/2) printf("X");
        else if(n/2-k<=0 && (x&1))
        {
            __int64 t = n/2-k;
            t = -t;
            if((n/2)-(x+1)/2+1<=t) printf("X");
            else printf(".");
        }
        else if(x == n+1 && k>=0) printf("X");
        else printf(".");
    }
    return 0;
}
