//Language: GNU C++


#include <stdio.h>
#include <string.h>

typedef long long ll;

ll n,t2,p,t1,x;

int main()
{
    while(scanf("%I64d%I64d%I64d",&n,&t2,&p)==3)
    {
        t1=n-t2;
        for(int i=0;i<p;i++)
        {
            scanf("%I64d",&x);
            if (t1==t2)
            {
                if (x&1) putchar('.');
                else putchar('X');
            } else
            if (t1<t2)
            {
                if (x<2*t1&&(x&1)) putchar('.');
                else putchar('X');
            }  else
            {
                if (t2==1)
                {
                    if (x==n) putchar('X');
                    else putchar('.');
                } else
                if (t2==0) putchar('.');
                else
                {
                    ll p=(t1-t2);
                    if (p&1)
                    {
                        p=t1-t2+1;
                        if (x==n) putchar('X'); else
                        if (x<=p) putchar('.'); else
                        {
                            x-=p;
                            if (x&1) putchar('.');
                            else putchar('X');
                        }
                    } else
                    {
                        p=t1-t2;
                        if (x<=p) putchar('.');else
                        {
                            x-=p;
                            if (x&1) putchar('.');
                            else putchar('X');
                        }
                    }
                }
            }
        }
    }
    return 0;
}
