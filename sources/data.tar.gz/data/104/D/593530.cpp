//Language: GNU C++


/*
*/
#include <iostream>
#include <string>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
#include <utility>
#include <cassert>
#include <queue>
#include <ctime>
#include <map>
#include <set>
using namespace std;

#define REP(i, n) for(int i = 0; i < n; i++)
#define CL(x) memset(x, 0, sizeof(x))
typedef long long ll;

ll n, k, p;
//char x[100];
ll x;

int main() {
	cin >> n >> k >> p;
	for (int i = 0; i < p; i++) { 
		bool flag;
		cin >> x; x--;
		
		x = (n-1) - x; //0 is right end
		if (n % 2 == 0) { 
			//even n
			if (x % 2 == 0) { 
				flag = (x/2+1) <= k;
			} else { 
				flag = (x/2+1) <= (k - n/2);
			}
		} else { 
			//odd n. place 0, 1, 3, 5, ... then even
			if (x == 0) flag = k > 0;
			else if (x == 1) flag = k > 1;
			else {
				if (x % 2 == 1) { 
					flag = (x-1)/2 <= (k-2);
				} else { 
					flag = x/2 <= (k-1-n/2);
				}
			}
		}
		
		if (flag)
			cout << "X";
		else
			cout << ".";
	}
	cout << endl;
}

/* int main() {
	cin >> n >> k; // >> p;
	for (int i = 0; i < k; i++) x[i] = 'X';
	for (int i = k; i < n; i++) x[i] = '.';
	
	//int win = 0;
	sort(x,x+n);
	pair<ll, string> best = make_pair((ll)1000000, "");
	do { 
		ll win = 0;
		for (int i = 0; i < n; i++) { 
			int j = 0; while (x[(i+j)%n] == '.') j++;
			if (j % 2 == 1) win++;
		}
		//cout << x << " " << win << endl;
		best = min(best, make_pair(n - win, (string)x));
	} while (next_permutation(x, x+n));
	
	cout << best.first << " " << best.second << endl;
} */