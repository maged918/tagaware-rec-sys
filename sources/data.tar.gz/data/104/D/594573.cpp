//Language: GNU C++


#include <stdio.h>
#include <iostream>
#include <queue>
#include <cmath>
#include <algorithm>
#include <cstring>
using namespace std;
long long n,k,x,y,m;
int i,p;
int main()
{  cin>>n>>k>>p;
   if (2*k<=n && n%2==0)
    { for (i=1;i<=p;i++)
       {
        cin>>m;
        if ((n-m+1)%2==1 && (n-m+1)/2<k) cout<<'X'; else cout<<'.';
       }
    }
   if (2*k<=n && n%2==1)
    {
      for (i=1;i<=p;i++)
       {
        cin>>m;
        if (n==m && k>0) cout<<'X';
        else
        if ((n-m+1)%2==0 && (n-m+1)/2<k) cout<<'X'; else cout<<'.';
       }
    }
  if (2*k>n)
   {
       x=n-k;
       for (i=1;i<=p;i++)
       {
        cin>>m;
        if (m%2==1 && (m+1)/2<=x) cout<<'.'; else cout<<'X';
       }
   }
   cout<<endl;
   return 0;
}
