//Language: GNU C++


// PERSHIK
// CBR - 80 (div 2)
// Problem D

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <algorithm>
#include <stack>
#include <queue>
#include <string>
#include <vector>
#include <math.h>
#include <set>
#include <map>

#define INF (1000000000)
#define EPS (1e-8)
#define PI (acos(-1))

using namespace std;

int main(){
	//freopen ("input.txt", "r", stdin);
	//freopen ("output.txt", "w", stdout);
	long long n, k, p, a[1100], i, g, h;
	cin >> n >> k >> p;
	for (i=0; i<p; i++) cin >> a[i];
	if (n % 2 == 0){
	    if (k * 2 <= n){
	        for (i=0; i<p; i++)
                if (a[i] % 2 == 0 && a[i] > n - k * 2 ) cout << 'X'; else cout << '.';
	    } else

	    {
	        g = k - n / 2;
	        h = n / 2 - g;
	        h = h * 2 - 1;
	        for (i=0; i<p; i++)
                if (a[i] % 2 == 0 || a[i] > h) cout << 'X'; else cout << '.';
	    }
	    cout << endl;
	    return 0;
	}


    if (k == 0){
        for (i=0; i<p; i++) cout << '.';
        cout << endl;
        return 0;
    }
    n--; k--;

        if (k * 2 <= n){
	        for (i=0; i<p; i++)
                if ((a[i] % 2 == 0 && a[i] > n - k * 2) || a[i] == n + 1) cout << 'X'; else cout << '.';
	    } else

	    {
	        g = k - n / 2;
	        h = n / 2 - g;
	        h = h * 2 - 1;
	        for (i=0; i<p; i++)
                if (a[i] % 2 == 0 || a[i] > h || a[i] == n + 1) cout << 'X'; else cout << '.';
	    }
	    cout << endl;

}
