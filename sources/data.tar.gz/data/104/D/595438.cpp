//Language: GNU C++


#include <iostream>

using namespace std;


int main()
{
long long n,k;
int p;
cin>>n>>k>>p;
for(int i=0;i<p;i++){
   long long t;
   cin>>t;
   t=n-t;
   if(k==0){
      cout<<".";
      continue;
   }
   if(n%2==0){
      if(k<=n/2){
         if(t<2*k && t%2==0)
            cout<<"X";
         else
            cout<<".";
      }else{
         long long pl=k-(n/2);
         if(t<2*pl || (t-2*pl)%2==0)
            cout<<"X";
         else
            cout<<".";
      }
   }else{
      if(t==0){
         cout<<"X";
      }else{
         t--;
         long long k2=k-1;
         long long n2=n-1;
         if(k2<=n2/2){
            if(t<2*k2 && t%2==0)
               cout<<"X";
            else
               cout<<".";
         }else{
            long long pl=k2-(n2/2);
            if(t<2*pl || (t-2*pl)%2==0)
               cout<<"X";
            else
               cout<<".";
         }
      }
   }
}
cout<<endl;
return 0;
}
