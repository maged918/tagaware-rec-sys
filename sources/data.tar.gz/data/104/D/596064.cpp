//Language: GNU C++


#include <cstdio>
#include <iostream>

using namespace std;

int main()
{
    //freopen("input.txt", "r", stdin);
    long long n, k, p, d, x;
    cin >> n >> k >> d;
    p = n - k;
    for (int i = 0; i < d; i++)
    {
        cin >> x;
        x--;
        if (p <= k)
        {
            if (x % 2 == 0 && x / 2 < p)
            {
                cout << ".";
            }
            else
            {
                cout << "X";
            }
        }
        else
        {
            if (n % 2 == 0)
            {
                if ((x % 2 == 1) && (n - 1 - x) / 2 < k)
                {
                    cout << "X";
                }
                else
                {
                    cout << ".";
                }
            }
            else
            {
                if (x != n - 1)
                {
                    if ((x % 2 == 1) && (n - 2 - x) / 2 < (k - 1))
                    {
                        cout << "X";
                    }
                    else
                    {
                        cout << ".";
                    }
                }
                else
                {
                    if (k > 0)
                        cout << "X";
                    else
                        cout << ".";
                }
            }
        }
    }
    return 0;
}
