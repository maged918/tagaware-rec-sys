//Language: GNU C++


#include <algorithm>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <set>
#include <string>
#include <vector>

using namespace std;

typedef long long ll;

int is_blank(ll n, ll k, ll x) {

  if (k <= n/2) {
    return !(x&1) || x<n-2*k;
  }
  else {
    return !(x&1) && x/2<n-k;
  }

}

void solve() {

  ll n, k, p;
  cin >> n >> k >> p;

  while (p--) {
    ll x;
    cin >> x;
    int blank;
    if (n&1) {
      blank = (!k || x<n) && is_blank(n-1,k-1,x-1);
    }
    else {
      blank = is_blank(n,k,x-1);
    }
    cout << (blank ? '.' : 'X');
  }
  cout << endl;

}

int main() {

  solve();

  return 0;

}
