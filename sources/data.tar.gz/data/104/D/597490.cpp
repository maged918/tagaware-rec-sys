//Language: GNU C++


#include <iostream>

using namespace std;

int main(){
    long long N,K,Q;
    cin >> N >> K >> Q;
    for(int i=0; i<Q; i++){
	long long x;
	cin >> x;
	if(x==N and K>0){
	    cout << "X";
	}else if(x%2==0){
	    long long remain=K-(N%2==1);
	    if(x>(N-N%2)-2*remain){
		cout << "X";
	    }else{
		cout << ".";
	    }
	}else{
	    long long remain=K-((N+1)/2);
	    if(remain>0){
		long long first=N-(N%2)-1;
		if(first-x<=2*(remain-1)){
		    cout << "X";
		}else{
		    cout <<".";
		}
	    }else{
		cout << ".";
	    }
	}
    }
    cout << endl;
}
