//Language: GNU C++


#include <cstdio> 
#include <iostream> 
 
using namespace std; 
 
 int main() 
 { 
   __int64 n, d,x; 
   int k;
   cin >> n >> d >> k; 

   for (int i = 0; i < k; i++) 
   { 
       cin >> x;
       if ( n % 2 == 0)
       {
           if ( d <= n /2)
           {
              if ( x % 2 == 1) cout << ".";
              else 
                if ( (n - x)/2+1 <=d) cout << "X";
                else cout << ".";
           }
           else
           {
              if ( x % 2 == 0) cout << "X";
              else
                if ( (n-1-x)/2 +1+n/2 <= d) cout << "X";
                else cout << ".";
           }
       }
       else
       {
          if ( d <= n /2+1)
           {
              if (( x % 2 == 1)&&(x != n)) cout << ".";
              else 
                if (x == n) 
                  if ( d >=1) cout << "X";
                  else cout << ".";
              else if ( (n-1 - x)/2+2 <=d) cout << "X";
                else cout << ".";
           }
           else
           {
              if ( (x % 2 == 0)||(x == n)) cout << "X";
              else
                if ( (n-2-x)/2 +2+n/2 <= d) cout << "X";
                else cout << ".";
           }
       }
   }
}

