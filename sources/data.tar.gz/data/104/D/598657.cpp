//Language: GNU C++


#include <iostream>
#include <cstdio>

using namespace std;

typedef long long ll;
ll n, k, p, i, x, r, f;
char ch;

int main() {
    #ifndef ONLINE_JUDGE
            freopen("input.txt", "r", stdin);
            freopen("output.txt", "w", stdout);
    #endif

    cin >> n >> k >> p;
    
    for (i=0; i<p; ++i) {
        cin >> x;
        if ((x == n) && (k > 0)) ch = 'X'; else
        if (x%2 == 0) {
           r = k - ll(n%2 == 1);
           if (x > (n - n%2) - 2*r) ch = 'X'; else ch = '.';
        }
        else {
             r = k - ((n+1) / 2);
             if (r > 0) {
                f = n - 1 - (n%2);
                if (f - x <= 2 * (r-1)) ch = 'X'; else ch = '.';
             }
             else ch = '.';
        }
        
        cout << ch;
    }    
    
    cout << "\n";    
    return 0;
}
