//Language: MS C++


#include <cstdio>
#include <cstring>
#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <algorithm>
using namespace std;

long long n, k, p, temp;
const long long two = 2;
const long long one = 1;

bool Chet(long long a)
{
	
	if (a % two == 0)
	{
		long long num = a / two;
		if (k >= (n / two - num + one))
			return true;
		else
			return false;
	}
	else
	{
		long long num = a / two + one;
		if (k >= (n - num + one))
			return  true;
		else
			return false;
	}
}

bool NeChet(long long a)
{
//	int num = a / 2 + 1;
	if (a == n && k >= one)
		return true;
	if (a % two == 0)
	{
		long long num = a / two;
		if (k >= (n / two - num + two))
			return true;
		else
			return false;
	}
	else
	{
		long long num = a / two + one;
		if (k >= (n - num + one))
			return  true;
		else
			return false;
	}

}

int main()
{
	//freopen("test.in", "a+", stdin);
	
	cin >> n >> k >> p;
	for (long long i = 0; i < p; ++i)
	{
		cin >> temp;
		if (n % two == 0)
		{
			if (Chet(temp))
				cout  << "X";
			else
				cout << ".";
		}
		else
		{
			if (NeChet(temp))
				cout  << "X";
			else
				cout << ".";
		}
	}
	return 0;
}