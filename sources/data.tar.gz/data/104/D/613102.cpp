//Language: GNU C++


#include<stdio.h>
#include<iostream>
using namespace std;
long long trans(long long x,long long n){
    if(x==1)return 1;
    else if(n&1)x--;
    if(x&1)
        return (x>>1)+1+(n&1);
    else return (x>>1)+(n+1>>1);
}
int main(){
    long long n,k,p,x;
    while(cin>>n>>k>>p){
        for(int i=0;i<p;i++){
            cin>>x;
            x=n-x+1;
            x=trans(x,n);
            if(x>k)
                printf(".");
            else printf("X");
        }
        puts("");
    }
}
/****** PCCA -Tue Aug 16 15:29:23 GMT 2011 *******/