//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;


int main()
{
long long n,k,p,rq,i,j;
cin>>n>>k>>p;

if(n%2==0)
for(i=0;i<p;i++)
 {
	 cin>>rq;
	 if(rq%2==0) rq=(n/2+1)-rq/2;
	 else rq=n+1-(rq/2+1);
	 //~ cout<<rq<<endl;
	 if(rq<=k) cout<<'X'; else cout<<'.';
 }
 
if(n%2!=0)
for(i=0;i<p;i++)
 {
	 cin>>rq;
	 if(rq==n) rq=1; else
	 if(rq%2==0) rq=((n/2+1)-rq/2)+1;
	 else rq=(n-(rq/2+1))+1;
	 //~ cout<<rq<<endl;
	 if(rq<=k) cout<<'X'; else cout<<'.';
 }
 


return 0;
}

