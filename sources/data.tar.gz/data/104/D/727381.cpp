//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <string>
#include <cstring>
#include <complex>
#include <cmath>
using namespace std;

#define fo(i,n) for(int i=0; i<(int)(n); i++)
#define pb push_back
#define mp make_pair

long long n, k, x;
int p;

int main(){
    cin >> n >> k >> p;
    long long l = n-k;
    if (k>=n/2ll+n%2ll){
        //.X.X.X.XXXXX
        fo(i,p){
            cin >> x;
            if (x>2ll*l) printf("X");
            else printf("%c",x%2ll==1?'.':'X');
        }
    } else {
        if ((n-2ll*k)%2ll==0ll){
            //...X.X.X
            fo(i,p){
                cin >> x;
                if (x<=n-2ll*k) printf(".");
                else printf("%c",(n-x)%2?'.':'X');
            }
        } else {
            //...X.X.XX
            fo(i,p){
                cin >> x;
                if (x<=n-2ll*k+1ll) printf(".");
                else if (x==n) printf("X");
                else printf("%c",(n-x)%2ll?'X':'.');
            }
        }
    }
}
