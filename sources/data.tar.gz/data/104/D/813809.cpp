//Language: GNU C++


#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int maxn = 2000;
int p;
int ans[maxn];
void solve(long long n,long long k,long long x)
{
     if(k<=n/2)
     {
        long long tp1 = n/2;
        if(x%2==0)
        {
            if(x>=2*(tp1-k+1)&&x<=n)printf("X");
            else printf(".");
        }
        else printf(".");
     }
     else
     {
          if(x%2==0)printf("X");
          else 
          {
              long long tp1 = k-n/2;
              if(x>=n-(2*tp1-1)&&x<=n)printf("X");
              else printf(".");
          }
     }
} 
int main()
{
    int i,j,p;
    long long x,n,k;
    while(scanf("%I64d%I64d%d",&n,&k,&p)!=EOF)
    {
         while(p--)
         {
             scanf("%I64d",&x);
             if(k==0)
             {
                 printf(".");
                 continue;
             }
             if(k==n)
             {
                  printf("X");
                  continue;
             }
             if(n&1)
             {
                 if(x==n)printf("X");
                 else solve(n-1,k-1,x);
             }
             else solve(n,k,x);
         }
         printf("\n");
    }
    return 0;
}

   	   		   	  			  		 	 	