//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <math.h>
using namespace std;
#define ll long long
const int maxn=300005;
struct node{int s,t,no;ll ans;}e[maxn];
int n,q;
ll f[maxn];int a[maxn],len;
bool cmp(node x,node y)
{
    return x.t<y.t;
}
ll baoli(node x)
{
    ll ans=0;
    for(int i=x.s;i<=n;i+=x.t)
    ans+=a[i];return ans;
}
void pre(node x)
{
    int i;
   // cout<<" "<<x.s<<endl;
    //cout<<" "<<x.t<<endl;
    for(i=1;i<=n;i++)
    if(i<=x.t) f[i]=a[i];
    else f[i]=a[i]+f[i-x.t];
}
bool cmp2(node x,node y) {return x.no<y.no;}
void init()
{
    scanf("%d",&q);
    for(int i=0;i<q;i++)
    scanf("%d%d",&e[i].s,&e[i].t),e[i].no=i;
    sort(e,e+q,cmp);

    ll ans;
    for(int i=0;i<q;i++)
    {
       //cout<<"F"<<e[i].t<<len<<endl;
        if(e[i].t>len) ans=baoli(e[i]);
    else
    {
        int aim=(n-e[i].s)/e[i].t*e[i].t+e[i].s;
       // for(int k=1;k<=n;k++)cout<<a[k]<<endl;
        if(i==0||e[i].t!=e[i-1].t)pre(e[i]);
       // for(int k=1;k<=n;k++)cout<<f[k]<<endl;
        if(e[i].s<=e[i].t) ans=f[aim];
        else
        {
            ans=f[aim]-f[max(e[i].s-e[i].t,0)];
        }
    }
    e[i].ans=ans;
    }
    sort(e,e+q,cmp2);
    for(int i=0;i<q;i++)
    cout<<e[i].ans<<endl;
}
int main()
{
   // freopen("in.txt","r",stdin);
    cin>>n;
    for(int i=1;i<=n;i++) scanf("%d",&a[i]);
    len=(int)sqrt(n);
    init();
//    cout << "Hello world!" << endl;
    return 0;
}
