//Language: GNU C++


#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long LL;
LL n,w[300001],m,s[300001];
struct Query
{
	LL a,b,p,ans;
	void Make(LL a1,LL b1,LL p1){a=a1;b=b1;p=p1;ans=0;}
}q[300001];

bool cmp1(const Query x,const Query y)
{
	return x.b<y.b;
}

bool cmp2(const Query x,const Query y)
{
	return x.p<y.p;
}

int main()
{
	cin>>n;
	for (int i=1;i<=n;i++)
		cin>>w[i];
	cin>>m;
	LL a,b;
	for (int i=0;i<m;i++)
	{
		cin>>a>>b;
		q[i].Make(a,b,i);
	}
	sort(q,q+m,cmp1);
	q[m].b=n+1; a=0;
	for (int i=0;i<=m;i++)
	{
		if (i!=0&&q[i].b!=q[i-1].b)
		if (q[i-1].b*q[i-1].b<n)
		{
			b=q[i-1].b;
			for (int j=1;j<=b;j++)
				s[j]=w[j];
			for (int j=b+1;j<=n;j++)
				s[j]=s[j-b]+w[j];
			for (int j=a;j<i;j++)
				q[j].ans=s[((n-q[j].a)/b)*b+q[j].a]-((q[j].a-b>0)?s[q[j].a-b]:0);
			a=i;
		}
		if (q[i].b*q[i].b>=n)
		{
			for (int j=q[i].a;j<=n;j+=q[i].b)
				q[i].ans+=w[j];
		}
	}
	sort(q,q+m,cmp2);
	for (int i=0;i<m;i++)
		cout<<q[i].ans<<endl;
	return 0;
}
	
