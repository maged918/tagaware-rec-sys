//Language: GNU C++


#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include<algorithm>
#include<string>
#include<sstream>
#include<set>
#include<map>
#include<vector>
#include<queue>
#include<time.h>
#define forn(i,n) for(int i=0;i<n;i++)
#define clr(a,b) memset(a,b,sizeof(a))
#define ll long long
#define lowb(i) (i&(-i))
#define bug(n,m,x) forn(i,n){forn(j,m)printf("%d ",x[i][j]);puts("");}puts("")
#define sqr(x) ((x)*(x))
using namespace std;
const int inf=1<<30;
const double eps=1e-8;
const double pi=acos(-1.0);
//const double inf = 1e10;

const int lim=15;
int n,a[300010];
int q;
ll c[300010];
struct my{
    int a,b,id;
    my(){}
    my(int a,int b,int id):a(a),b(b),id(id){}
    bool operator <(const my &u)const{
        if(b==u.b)return a%b<u.a%b;
        return b<u.b;
    }
}b[300010];
ll ans[300010];
int l;
int main(){
    //freopen("D:\\in.txt","r",stdin);
    //freopen("D:\\in.txt","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",&a[i]);
//    init();
    scanf("%d",&q);
    forn(i,q){
        int w,e;
        scanf("%d%d",&w,&e);
        b[i]=my(w,e,i);
    }
    sort(b,b+q);
    for(int i=0;i<q;i++){
        if(b[i].b>=500){
            int id=b[i].id;
            for(int j=b[i].a;j<=n;j+=b[i].b)ans[id]+=a[j];
            continue;
        }
        if(i==0||b[i].b!=b[i-1].b||(b[i].a%b[i].b!=b[i-1].a%b[i-1].b)){
            l=1;
            int q=b[i].a,w=b[i].b;
            int t=q%w;
            if(t==0)t=w;
            for(int j=t;j<=n;j+=w)c[l]=c[l-1]+a[j],l++;
            ans[b[i].id]=c[l-1]-c[(q+w-1)/w-1];
        }
        else{
            int q=b[i].a,w=b[i].b;
            ans[b[i].id]=c[l-1]-c[(q+w-1)/w-1];
        }
    }
    forn(i,q)printf("%I64d\n",ans[i]);
//    while(q--){
//        int b,c;
//        scanf("%d%d",&b,&c);
//        if(c<=lim){
//            int t=b%c;
//            if(t==0)t=c;
//            int w=(b+c-1)/c-1;
//            vector <ll> &e=sum[c][t];
//            printf("%I64d\n",e[e.size()-1]-e[w]);
//        }
//        else{
//            ll ans=0;
//            for(int i=b;i<=n;i+=c)ans+=a[i];
//            printf("%I64d\n",ans);
//        }
//    }
    return 0;
}

	  	 		 	   	   	 		 			  	