//Language: GNU C++


#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
#include <cmath>

using namespace std;

typedef long long ll;

struct Query
{
    int a, b, id;
    Query (int x, int y, int z) {a = x; b = y; id = z;}
    Query () {}
};

const int MAX = 3e5 + 5;
ll n, p, A[MAX];
vector<Query> q[MAX];
ll res[MAX], dp[MAX * 2];

int main()
{
    cin >> n;
    for (int i=0; i<n; i++)
        cin >> A[i + 1];
    cin >> p;
    for (int i=0; i<p; i++)
    {
        int a,b; cin >> a >> b;
        q[b].push_back (Query (a, b, i));
    }
    int x = sqrt (n);
    for (int i=1; i<=n; i++)
    {
        if (i <= x)
        {
            memset (dp, 0, sizeof (dp));
            for (int j=n; j>0; j--)
                dp[j] = dp[j + i] + A[j];
            for (int j=0; j<q[i].size(); j++)
                res [q[i][j].id] = dp [q[i][j].a];
        }else
        {
            for (int j=0; j<q[i].size(); j++)
            {
                int a = q[i][j].a, b = q[i][j].b, id = q[i][j].id;
                res[id] = 0;
                for (int k=a; k<=n; k += b)
                    res[id] += A[k];
            }
        }
    }
    for (int i=0; i<p; i++)
        cout << res[i] << endl;
}