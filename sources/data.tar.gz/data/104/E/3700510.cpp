//Language: GNU C++0x


#include <functional>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <cassert>
#include <cstring>
#include <cstdlib>
#include <complex>
#include <iomanip>
#include <climits>
#include <string>
#include <cstdio>
#include <vector>
#include <limits>
#include <queue>
#include <stack>
#include <cmath>
#include <set>
#include <map>

using namespace std;

typedef int _int;
#define int long long

#define endl '\n'
#define sqr(x) ((x) * (x))
#define count _count
#define y0 _y0
#define y1 _y1

int dx[] = {1, 0, -1, 0, 1, -1, 1, -1};
int dy[] = {0, 1, 0, -1, 1, 1, -1, -1};

const int WHITE = 0, GRAY = 1, BLACK = 2, GREEN = 3, BLUE = 4;

const int LIM = 3e+5 + 10, LIM1 = 1e+3;
const long long INF = 1e+9, MOD = 1e+9 + 7;
const double PI = 3.141592653589793, EPS = 1e-7;

int n, p, w[LIM], d[LIM], pos[LIM], ans[LIM];
pair<int, int> req[LIM], buf_req[LIM];

void solve_b(int b) {
  for (int i = n - 1; i >= 0; i--) {
    if (i + b >= n)
      d[i] = w[i];
    else
      d[i] = d[i + b] + w[i];
  }
}

_int main() {
  ios_base::sync_with_stdio(0);
  cin >> n;
  for (int i = 0; i < n; i++)
    cin >> w[i];
  cin >> p;
  for (int i = 0; i < p; i++) {
    cin >> req[i].first >> req[i].second;
    --req[i].first;
    swap(req[i].first, req[i].second);
    buf_req[i] = req[i];
  }
  sort(buf_req, buf_req + p);
  for (int i = 0; i < p; i++) {
    int px = lower_bound(buf_req, buf_req + p, req[i]) - buf_req;
    pos[i] = px;
  }
  int prev_b = -1;
  for (int i = 0; i < p; i++) {
    if (buf_req[i].first <= 300) {
      if (prev_b != buf_req[i].first) {
        prev_b = buf_req[i].first;
        solve_b(buf_req[i].first);
#ifdef DEBUG
        cerr << buf_req[i].first << " : ";
        for (int k = 0; k < n; k++) {
          cerr << d[k] << ' ';
        }
        cerr << endl;
#endif
      }
      ans[i] = d[buf_req[i].second];
    } else {
      int res = 0;
      for (int j = buf_req[i].second; j < n; j += buf_req[i].first)
        res += w[j];
      ans[i] = res;
    }
  }
  for (int i = 0; i < p; i++) {
    cout << ans[pos[i]] << endl;
  }
  return 0;
}
