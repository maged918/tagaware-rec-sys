//Language: GNU C++


#include <cstdio>
#include <algorithm>
#include <cmath>
#define LL long long int
#define N 300005
using namespace std;

struct query{
	int a,b,t;
	LL AC;
}Q[N];

int n,NQ,hd,tl,D,st,a,b;
LL w[N],s[N];

bool cmp1(query A,query B){
	return A.b<B.b;
}

bool cmp2(query A,query B){
	return A.t<B.t;
}

int main(){
	scanf("%d",&n);
	
	for (int i=1;i<=n;i++)
		scanf("%I64d",&w[i]);
	
	scanf("%d",&NQ);
	for (int i=0;i<NQ;i++){
		scanf("%d%d",&Q[i].a,&Q[i].b);
		Q[i].t=i;
	}
	
	sort(Q,Q+NQ,cmp1);
	
	D = (int)sqrt(n*1.0);
	st = 0;
	
	for (int i=0;i<NQ;i++){
		
		a=Q[i].a;
		b=Q[i].b;
		
		if (Q[i].b<=D){
			
			
			if (a>=b) hd=a-b;
			else hd = 0;
			tl = n-((n-a)%b);
			
			if (Q[i].b==st)
				Q[i].AC = s[tl]-s[hd];
			else {
				st = Q[i].b;
				s[0]=0;
				for (int j=1;j<=n;j++){
					if (j<b) s[j]=w[j];
					else s[j]=s[j-b]+w[j];
				}
				Q[i].AC=s[tl]-s[hd];
			}
		}
		else {
			Q[i].AC=0;
			for (int j=a;j<=n;j+=b)
				Q[i].AC+=w[j];
		}
	}
	
	
	sort(Q,Q+NQ,cmp2);
	for (int i=0;i<NQ;i++)
		printf("%I64d\n",Q[i].AC);
	//scanf("\n");
	return 0;
}
