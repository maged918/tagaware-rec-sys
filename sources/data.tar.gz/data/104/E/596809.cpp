//Language: MS C++


#include <stdio.h>
#include <vector>
using namespace std;
struct sc
{
    int a,b;
    long long int s;
};
struct ab
{
    vector <int> i;
    ab()
    {
        i.resize(0);
    }
};
const int tt=1000;
int n,p;
vector <int> w;
vector <sc> c;
vector <vector <ab> > d(tt);
vector <long long int> s;
int main()
{
    for (int i=0;i<tt;i++) d[i].resize(i+1);
    scanf("%d",&n);
    w.resize(n);
    for (int i=0;i<n;i++) scanf("%d",&w[i]);
    scanf("%d",&p);
    c.resize(p);
    for (int i=0;i<p;i++) scanf("%d%d",&c[i].a,&c[i].b);
    for (int i=0;i<p;i++)
    {
        if (c[i].b>tt) for (int j=c[i].a-1;j<n;j+=c[i].b) c[i].s+=w[j];
        else d[c[i].b-1][(c[i].a-1)%c[i].b].i.push_back(i);
    }
    for (int i=0;i<tt;i++) for (int j=0;j<=i;j++) if (d[i][j].i.size()>0)
    {
        s.assign(1,0);
        for (int k=j;k<n;k+=i+1) s.push_back(s[s.size()-1]+w[k]);
        for (int k=0;k<d[i][j].i.size();k++) c[d[i][j].i[k]].s=s[s.size()-1]-s[(c[d[i][j].i[k]].a-1)/(i+1)];
    }
    for (int i=0;i<p;i++) printf("%I64d\n",c[i].s);
}
