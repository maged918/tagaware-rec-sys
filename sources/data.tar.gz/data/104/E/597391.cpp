//Language: GNU C++


//In the name of Allah
//
//
#include <iostream>
#include <utility>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;
const int MN=3*1000*100+100;
const int MX=150;
typedef pair<int,int> pie;
typedef long long ll;
map<pie,ll> mp;
int list[MN];
ll ans[MN];
int n,q;
vector <pair<pie,int> > qs;
int main()
{
	cin>>n;
	for (int i=0;i<n;i++)
		cin>>list[i];
	cin>>q;
	for (int i=0;i<q;i++)
	{
		int a,b; cin>>a>>b; a--;
		if (b<=MX)
			qs.push_back(make_pair(pie(a,b),i));
		else
		{
			ll res=0;
			for (int j=a;j<n;j+=b)
				res+=list[j];
			ans[i]=res;
		}
	}
	sort(qs.begin(),qs.end());
	reverse(qs.begin(),qs.end());
	for (int i=0;i<qs.size();i++)
	{
		int a=qs[i].first.first,b=qs[i].first.second,p=qs[i].second;
		ll now=0;
		for (int j=a;j<n;j+=b) 
		{
			if (mp.find(pie(j,b))!=mp.end())
			{
				now+=mp[pie(j,b)];
				break;
			}
			now+=list[j];
		}
		mp[pie(a,b)]=now;
		ans[p]=now;
	}
	for (int i=0;i<q;i++)
		cout<<ans[i]<<endl;
	return 0;
}
