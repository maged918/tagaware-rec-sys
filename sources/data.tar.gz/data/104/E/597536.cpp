//Language: GNU C++


#include <algorithm>
#include <cstdio>
#include <iostream>
#include <cmath>
using namespace std;

struct cow{
    int a, b, num;
    inline bool operator<(const cow &x) const {
        return b < x.b;
    }
};

const int MAXN = 300100;
int a[MAXN];
long long s[MAXN], ans[MAXN];
cow query[MAXN];

int main() {
    int n;
    scanf("%d", &n);
    for(int i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    int p;
    scanf("%d", &p);
    for(int i = 0; i < p; i++) {
        scanf("%d %d", &query[i].a, &query[i].b);
        query[i].num = i, query[i].a--;
    }
    sort(query, query + p);
    const int LIM = int(sqrt(n)) + 1;
    for(int i = 0; i < p; i++) {
        if(query[i].b > LIM) {
            long long t = 0;
            for(int j = query[i].a; j < n; j += query[i].b)
                t += a[j];
            ans[query[i].num] = t;
        }
        else {
            for(int j = 0; j < n; j++)
                s[j] = 0;
            for(int j = n - 1; j >= 0; j--) {
                s[j] = a[j] + ((j + query[i].b < n) ? s[j + query[i].b] : 0);
            }
            int j = i;
            while(query[j].b == query[i].b and j < p) j++;
            for(int k = i; k < j; k++) {
                ans[query[k].num] = s[query[k].a];
            }
            i = j - 1;
        }
    }
    for(int i = 0; i < p; i++) {
        printf("%I64d\n", ans[i]);
    }
    return 0;
}
