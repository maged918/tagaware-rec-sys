//Language: GNU C++


#include <iostream>
#include <vector>
#include <map>

using namespace std;

int main(int argc, char* argv[])
{
	int n;
	cin >> n;
	vector<int> w(n);
	
	for (int i = 0; i < n; ++i)
		cin >> w[i];
	
	map<int,multimap<int,int> > m;
	int p;
	cin >> p;
	
	for (int i = 0; i < p; ++i)
	{
		int a, b;
		cin >> a >> b;
		a--;

		m[b].insert(make_pair(a, i));
	}
	
	vector<long long> r(p);
	
	for (map<int,multimap<int,int> >::iterator i = m.begin(); i != m.end(); ++i)
	{
		int b = i->first;
		multimap<int,int> &k = i->second;
		
		if (k.size() > b / 2)
		{
			vector<long long> f(w.begin(), w.end());
			for (int t = n - 1 - b; t >= k.begin()->first; --t)
				f[t] += f[t + b];

			for (multimap<int,int>::iterator j = k.begin(); j != k.end(); ++j)
			{
				int a = j->first;
				int c = j->second;
				r[c] = f[a];
			}
		}
		else
		{
			for (multimap<int,int>::iterator j = k.begin(); j != k.end(); ++j)
			{
				int a = j->first;
				int c = j->second;
				
				for (int t = a; t < n; t += b)
					r[c] += w[t];
			}
		}
	}
	
	for (int i = 0; i < p; ++i)
		cout << r[i] << endl;
	
	return 0;
}