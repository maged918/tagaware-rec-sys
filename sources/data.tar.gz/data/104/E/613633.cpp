//Language: GNU C++


#include<stdio.h>
#include<iostream>
#include<algorithm>
using namespace std;
struct data{
    int a,b,index;
    bool operator<(data z)const{
        if(b!=z.b)return b<z.b;
        if(a%b!=z.a%z.b)return a%b<z.a%z.b;
        return a<z.a;
    }
}d[300005];
int c[300005];
long long t[300005],ans[300005];
int main(){
    int n,p;
    while(scanf("%d",&n)==1){
        for(int i=0;i<n;i++)
            scanf("%d",&c[i]);
        scanf("%d",&p);
        for(int i=0;i<p;i++){ 
            scanf("%d%d",&d[i].a,&d[i].b);
            d[i].a--; 
            d[i].index=i;
        }
        sort(d,d+p);
        int prevb=-1,prevab=-1;
        for(int i=0;i<p;i++){
            if(prevb==d[i].b&&prevab==d[i].a%d[i].b)
                ans[d[i].index]=t[d[i].a];
            else{
                int temp=n%d[i].b-d[i].a%d[i].b;
                if(temp<=0)temp+=d[i].b;
                for(int j=n-temp;j>=d[i].a;j-=d[i].b)
                    if(j<n-temp)
                        t[j]=t[j+d[i].b]+c[j];
                    else t[j]=c[j];
                ans[d[i].index]=t[d[i].a];
            }
            prevb=d[i].b;
            prevab=d[i].a%d[i].b;
        }
        for(int i=0;i<p;i++)
            cout<<ans[i]<<endl;
    }
}
/****** PCCA -Wed Aug 17 08:16:18 GMT 2011 *******/