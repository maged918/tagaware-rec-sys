//Language: MS C++


#include <cstdio>
#include <algorithm>
#include <cmath>
using namespace std;
struct zap
{int a,b,n;};
bool f(zap a,zap b)
{return a.b<b.b;}
int n,p,a[300001],q;
long long ans[300001],d[300001];
zap c[300000];
int main()
{
	scanf("%d",&n);
	for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	scanf("%d",&p);
	for (int i=0;i<p;i++)
	{
		scanf("%d%d",&c[i].a,&c[i].b);
		c[i].n=i+1;
	}
	sort(c,c+p,f);
	q=int(sqrt(double(n)));
	for (int i=0;i<p;i++)
	{
		if (c[i].b<q)
		{
			if (c[i].b!=c[i-1].b)
			{
				for (int j=n;j>0;j--)
					if (j+c[i].b>n) d[j]=a[j];
					else d[j]=a[j]+d[j+c[i].b];
			}
			ans[c[i].n]=d[c[i].a];
		}
		else
		{
			int j=c[i].a;
			ans[c[i].n]+=a[j];
			while(j+c[i].b<=n)
			{
				j+=c[i].b;
				ans[c[i].n]+=a[j];
			}
		}
	}
	for (int i=1;i<=p;i++) printf("%I64d\n",ans[i]);
}
