//Language: MS C++


#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <functional>
#include <iomanip>
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <hash_set>
#include <hash_map>
#include <algorithm>

//define NDEBUG
#include <cassert>

#define FILE_READER assert(freopen("input.txt", "r", stdin)); assert(freopen("output.txt", "w", stdout));
#define FAST_READER ios::sync_with_stdio(false); cin.tie(nullptr);
#define all_(v) (v).begin(), (v).end()
#define for_(i, a, b) for (int i = (a); i < (int)(b); i++)
#define ford_(i, a, b) for (int i = (a); i > (int)(b); i--)
#define foreach_(it,S) for(__typeof((S).begin()) it = (S).begin(); it != (S).end(); it++)
#define sz_(v) ((int)(v).size())
#define mp_ make_pair
#define pb_ push_back
typedef long long LL_;
typedef long double LD_;
template<class T> T sqr_(T a) {return a * a;}
template<class T> T abs_(T a) {return a > 0 ? a : -a;}
template<class T> T sgn_(T a) {return a > 0 ? 1 : (a < 0 ? -1 : 0);}

using namespace std;

const int maxn = 3 * (int)1e5 + 111;
int n, p;
pair<pair<int, int>, int> q[maxn];
LL_ w[maxn];
long long d[maxn];
LL_ ans[maxn];

int main() {

#ifndef ONLINE_JUDGE 
	FILE_READER 
#endif 	
	
	//FAST_READER;
	
	//cin >> n;
	scanf("%d", &n);
	//for_(i, 0, n) cin >> w[i];
	for_(i, 0, n) scanf("%I64d", &w[i]);
	//cin >> p;
	scanf("%d", &p);
	//for_(i, 0, p) cin >> q[i].first.second >> q[i].first.first, q[i].second = i;
	for_(i, 0, p) scanf("%d%d", &q[i].first.second, &q[i].first.first), q[i].second = i;
	sort(q, q + p);
	for_(t, 0, p) {
		int a, b;
		a = q[t].first.second - 1;
		b = q[t].first.first;
		if (b > 500) {
			LL_ ss = 0;
			for(int i = a; i < n; i += b) ss += w[i];
			ans[q[t].second] = ss;
		} else {
			if (t == 0 || b != q[t - 1].first.first) {
				ford_(i, n - 1, -1) {
					if (i + b >= n)
						d[i] = w[i];
					else
						d[i] = w[i] + d[i + b];
				}
			}
			ans[q[t].second] = d[a];
		}
	}
	//for_(i, 0, p) cout << ans[i] << endl;
	for_(i, 0, p) printf("%I64d\n", ans[i]);
	return 0;
}