//Language: GNU C++


#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <iostream>
using namespace std;

#define FOR(i,n) for (int i = 0; i < n; i++)
#define abs(x) ((x)<0?(-(x)):(x))
#define REP(i,v) for (unsigned i = 0; i < v.size(); i++)
#define RL(i,v) for (unsigned i = 0; i < v.length(); i++)
typedef long long ll;

struct Question {
        int a, b, idx;
        Question() {}
        Question(int a, int b, int idx) : a(a), b(b), idx(idx) {}
        inline bool operator < (const Question& rhs) const
        {
                if (b != rhs.b) return b < rhs.b;
                return a < rhs.a;
        }
};

int n;
#define MAXN 300002
const int BOUND = 512;
ll a[MAXN], b[MAXN];
Question questions[MAXN];
ll answers[MAXN];


int main(void)
{
        cin >> n;
        FOR(i, n) cin >> a[i];
        int qn;
        cin >> qn;
        FOR(i, qn) {
                int x, y;
                cin >> x >> y;
                questions[i] = Question(x - 1, y, i);
        }
        sort(questions, questions + qn);
        int last = 0;
        FOR(i, qn) {
//              if (i % 1000 == 0) printf("%dK done\n", i/1000);
                Question& q = questions[i];
                if (q.b < BOUND && last != q.b) {
                        last = q.b;
                        for (int j = n - 1; j >= 0; j--) {
                                b[j] = a[j];
                                if (j + q.b < n) b[j] += b[j + q.b];
                        }
                }
                if (q.b < BOUND) {
                        answers[q.idx] = b[q.a];
                } else {
                        answers[q.idx] = 0;
                        for (int j = q.a; j < n; j += q.b) {
                                answers[q.idx] += a[j];
                        }
                }
        }
        FOR(i, qn)
                cout << answers[i] << endl;
        return 0;
}
