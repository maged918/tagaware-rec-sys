//Language: GNU C++0x


#include <iostream>
#include <vector>
#include <climits>
#include <queue>
#include <cstdio>
#include <string>
#include <sstream>
#include <cstring>
#include <algorithm>
#include <math.h>

using namespace std;

int a[300001];
long long dp[300001];
long long res[300001];

struct query
{
    int a;
    int b;
    int i;
};

query q[300001];

bool comp(query &q1, query &q2)
{
    return q1.b > q2.b;
}

bool comp2(query &q1, query &q2)
{
    return q1.i < q2.i;
}

int main()
{
    ios::sync_with_stdio(true);
    int n, p;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    scanf("%d", &p);
    for (int i = 0; i < p; i++)
    {
        scanf("%d%d", &q[i].a, &q[i].b);
        q[i].i = i;
    }
    sort(q, q + p, comp);
    int i = 0;
    int to = sqrt(.0 + n);
    int last = -1;
    while (1)
    {
        if (i == p)
            break;
        if (q[i].b > to)
            break;
        if (q[i].b != last)
        {
            for (int j = n - 1; j > -1; j--)
            {
                if (j + q[i].b > n - 1)
                    dp[j] = a[j];
                else dp[j] = dp[j + q[i].b] + a[j];
            }
            last = q[i].b;
        }
        res[q[i].i] = dp[q[i].a - 1];
        i++;
        //printf("%I64d\n", dp[q[i].a-1]);
    }
    for (; i < p; i++)
    {
        res[q[i].i] = 0;
        for (int j = q[i].a-1; j < n; j += q[i].b)
            res[q[i].i] += a[j];
        //printf("%I64d\n", r);
    }
    for (int i = 0; i < p; i++)
        printf("%I64d\n", res[i]);
    return 0;
}