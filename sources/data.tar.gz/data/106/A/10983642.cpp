//Language: MS C++


#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<map>
#include<set>
#include<bitset>
#include<utility>
#include<iomanip>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<pii> vpi;
typedef set<int> si;
typedef vector<int> vi;
typedef vector<vi> vvi;

#define all(v)              ((v).begin()), ((v).end())
#define sz(v)               ((int)((v).size()))
#define clr(v, d)           memset(v, d, sizeof(v))
#define rep(i, v)       for(int i=0;i<sz(v);++i)
#define pp(x)               push_back(x)
#define isodd(x) (x&1)
#define iseven(x) (!(x&1))
#define lop(i,n) for(ll i=0;i<n;i++)
#define lop1(i,n) for(ll i=1;i<=n;i++)
#define loop(i,a,b) for(int i=a;i<=b;i++)
#define INF                   1000000000
#define PI             3.141592653589793
#define rep(i, v)       for(int i=0;i<sz(v);++i)
int gcd(int a, int b) { return (b == 0 ? a : gcd(b, a % b)); }
int lcm(int a, int b) { return ((a*b) / gcd(a, b)); }
ll pw(ll b, ll p){ if (!p) return 1; ll sq = pw(b, p / 2); sq *= sq; if (p % 2) sq *= b; return sq; }
int sd(ll x){ return x<10 ? x : x % 10 + sd(x / 10); }
int  n, m; string str1, str2; char C;
 


int main(){
    map<char, int>gemy;
    gemy['6'] = 1;
    gemy['7'] = 2;
    gemy['8'] = 3;
    gemy['9'] = 4;
    gemy['T'] = 5;
    gemy['J'] = 55;
    gemy['Q'] = 555;
    gemy['K'] = 5555;
    gemy['A'] = 77777;
    string s;
    cin >> s >> str2 >> str1;
    if (str2[1] == s[0]&&str1[1]!=s[0])cout << "YES";
    else if (str2[1] == str1[1] && gemy[str2[0]]>gemy[str1[0]])cout << "YES";
    else cout << "NO";





}