//Language: GNU C++11


#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <cmath>
#include <cstdlib>
#include <cstdio>

using namespace std;

#define REP(i,n) for(int (i)=0;(i)<(int)(n);(i)++)
#define REPV(i,x,n) for(int (i)=(x);(i)<(int)(n);(i)++)
#define bhavik(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

char arr[] = { '0' ,'6', '7', '8', '9', 'T', 'J', 'Q', 'K','A'};
char trump;
string s1 , s2;

int main () {
	cin >> trump >> s1 >> s2;
	int firstrank = 0, secondrank = 0;

	REP(i , 10) {
		if (s1[0] == arr[i]) firstrank = i;
		if (s2[0] == arr[i]) secondrank = i;
	}

	if (s1[1] == trump && s2[1] == trump) {
		(firstrank > secondrank)? puts("YES") : puts("NO");
		return 0;
	}
	
	if (s1[1] == s2[1]) {
		(firstrank > secondrank)? puts("YES") : puts("NO");
		return 0;
	}

	return (s1[1] == trump && s2[1] != trump)? puts("YES") : puts("NO") , 0;

	puts("NO");

	return 0;
}