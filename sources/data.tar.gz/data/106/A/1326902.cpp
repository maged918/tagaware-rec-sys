//Language: MS C++


#include <vector>
#include <list>
#include <map>
#include <set>
#include <queue>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include<cstring>
#include<string>
using namespace std;
typedef long long ll;
#define mp make_pair
#define pb push_back
#define f0(i,n) for(i=0;i<n;i++)
#define SORT(c) sort((c).begin(),(c).end())
const double PI = acos(-1.0);
const double EPS = 1e-7;
const ll BIG_PRIME7 = 1000000007;
const ll BIG_PRIME9 = 1000000009;

int gcd(int x, int y) {return y ? gcd(y, x%y): x;} 

vector<int> vi;
vector<string>vs;
pair<int,int>pii;
set<int> seti;

char st[1000];
int  a[1000];
char ch,c;
string s,ss,s1,s2,ss1,ss2;
int i,j,k,m,n,d,f,g,t,mini,maxi;
ll I,J,L,K,M,N,C;
bool ind, flag;
double x,y,z;


int main(){
	cin>>s;
	cin>>ss>>s1;
	if(ss[1]!=s1[1] && ss[1]!=s[0]){
		cout<<"NO";
	} else {
		if(ss[1]!=s1[1] && ss[1]==s[0]){
			cout<<"YES";
		} else {
			if(isdigit(ss[0]) && isdigit(s1[0])){
				if(ss[0]>s1[0]){
					cout<<"YES";
				} else cout<<"NO";
			} else {
				if(isdigit(ss[0])){
					cout<<"NO";
				} else {
					if(isdigit(s1[0]))
						cout<<"YES";
				 else {
					if(ss[0]=='A'){
						cout<<"YES";
					} else {
						if(ss[0]=='T')cout<<"NO";
						else 
							switch(ss[0]){
							case 'Q':
								switch(s1[0]){
								case 'T':
								case 'J':
									cout<<"YES";
									break;
								default :cout<<"NO";
								}
								break;
							case 'J':
								switch(s1[0]){
								case 'T':
									cout<<"YES";
									break;
								default :cout<<"NO";
								}
								break;
							case 'K':
								switch(s1[0]){
								case 'A':
									cout<<"NO";
									break;
								default :cout<<"YES";
								}
								break;
							}
					}
					
				 }
			}
			}}}

	return 0;
}