//Language: GNU C++


#include <iostream>
#include <string>

using namespace std;

char indexes[] = {'6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'};

int getIndex(char s)
{
    for(int i = 0; i < 9; i++)
        if(s == indexes[i]) return i;
}

int main()
{
    char m;
    string s1;
    string s2;
    
    cin >> m;
    cin >> s1 >> s2;
    
    if(s1[1] == s2[1])
    {
        if(getIndex(s1[0]) > getIndex(s2[0]))
        {
            cout << "YES";
            //system("PAUSE");
            return 0;
        }
        else
        {
            cout << "NO";
            //system("PAUSE");
            return 0;
        }
    }
    else
    {
        if(s1[1] == m)
        {
            cout << "YES";
            //system("PAUSE");
            return 0;
        }
        else
        {
            cout << "NO";
            //system("PAUSE");
            return 0;
        }
    }
    
    //system("PAUSE");
    return 0;
}
