//Language: GNU C++


#include<stdio.h>
char rank[10]="6789TJQKA",suit[5]="CDHS";

int main()
{                                                
    int i=0,j=0,k=0,l=0,m=0;
    char c,c1,c2,c3,c4;
    scanf("%c\n",&c);
    scanf("%c%c %c%c",&c1,&c2,&c3,&c4);
    if(c==c2 && c4!=c)
    {
        printf("YES\n");
        return 0;
    }
    if(c==c4 && c2!=c)
    {
        printf("NO\n");
        return 0;
    }
    for(i=0;i<9;i++)
    {
        if(c1==rank[i])
        {
            j=i;
        //  printf("%d\n",j);
            break;
        }
    }
    for(i=0;i<9;i++)
    {
        if(c3==rank[i])
        {
            k=i;
        //  printf("%d\n",k);
            break;
        }
    }
    for(i=0;i<4;i++)
    {
        if(c2==suit[i])
        {
            l=i;
        //  printf("%d\n",l);
            break;
        }
    }
    for(i=0;i<4;i++)
    {
        if(c4==suit[i])
        {
            m=i;
        //  printf("%d\n",m);
            break;
        }
    }
    if(j>k && l==m)
    printf("YES\n");
    else printf("NO\n");
    
    return 0;
}