//Language: GNU C++


#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cctype>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <set>
#include <map>
using namespace std;

typedef long long ll;

#define rep(i, n) for(int i = 0; i < n; ++i)
#define repd(i, n) for(int i = n - 1; i >= 0; --i)
#define all(x) x.begin(), x.end()
#define pb push_back
#define mp make_pair

const int INF = (int)2e9;
const double PI = 3.1415926535;
const int MOD = 1000003;

char a[9] = {'6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'};

int main() {
    // freopen("input.txt", "r", stdin);
    char ch, ch1, ch2, tch1, tch2;
    int n1, n2;
    scanf("%c\n%c%c %c%c", &ch, &tch1, &ch1, &tch2, &ch2);
    rep(i, 9) {
        if (tch1 == a[i])
            n1 = i;
        if (tch2 == a[i])
            n2 = i;
    }
    if ((ch1 == ch2 && n1 > n2) || (ch1 != ch2 && ch1 == ch))
        cout << "YES";
    else
        cout << "NO";
    return 0;
}
