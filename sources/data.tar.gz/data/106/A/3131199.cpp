//Language: GNU C++


#include <iostream>

using namespace std;

int main()
{
    string s;
    cin>>s;

    string a,b;
    cin>>a>>b;

    if( a[1] == s[0] && b[1] != s[0] ) cout<<"YES";
    else
    if( a[1] ==  b[1]  )
    {
        int v1,v2;

        if(a[0] == '6' || a[0] == '7'||a[0] == '8'||a[0] == '9')
        v1=a[0]-'0';
        else if (a[0] == 'T') v1=10;
        else if (a[0] == 'J') v1=11;
        else if (a[0] == 'Q') v1=12;
        else if (a[0] == 'K') v1=13;
        else if (a[0] == 'A') v1=14;

        if(b[0] == '6' || b[0] == '7'||b[0] == '8'||b[0] == '9')
        v2=b[0]-'0';
        else if (b[0] == 'T') v2=10;
        else if (b[0] == 'J') v2=11;
        else if (b[0] == 'Q') v2=12;
        else if (b[0] == 'K') v2=13;
        else if (b[0] == 'A') v2=14;


        if(v1 > v2) cout<<"YES";
        else cout<<"NO";

    }
    else cout<<"NO";

    return 0;
}
