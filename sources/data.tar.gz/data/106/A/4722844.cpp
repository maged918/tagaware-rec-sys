//Language: GNU C++


#include <cstdio>

int color_1, rank_1, color_2, rank_2;
char trump;

int get_color(char token) {
    if (token == 'S') return 0;
    if (token == 'H') return 1;
    if (token == 'D') return 2;
    return 3;
}

void obtain(int &color, int &rank) {
    char buffer[3];
    scanf("%s", buffer);
    color = get_color(buffer[1]);
    if (buffer[0] >= '0' && buffer[0] <= '9') {
        rank = buffer[0] - '0';
    } else if (buffer[0] == 'T') {
        rank = 10;
    } else if (buffer[0] == 'J') {
        rank = 11;
    } else if (buffer[0] == 'Q') {
        rank = 12;
    } else if (buffer[0] == 'K') {
        rank = 13;
    } else if (buffer[0] == 'A') {
        rank = 14;
    }
}

int main() {
    char buffer[2];
    scanf("%s", buffer);
    trump = get_color(buffer[0]);

    obtain(color_1, rank_1);
    obtain(color_2, rank_2);
    if (color_1 == trump && color_2 != trump) {
        puts("YES");
    } else if (color_1 != trump && color_2 == trump) {
        puts("NO");
    } else if (color_1 == color_2) {
        puts(rank_1 > rank_2 ? "YES" : "NO");
    } else {
        puts("NO");
    }
}

					    		 	    			 		   	