//Language: MS C++


#include <string>
#include <iostream>
using namespace std;
string a,b,c;
char d[]={'6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'};
int p,q;
int main()
{
    cin >> a >> b >> c;
    if (a[0]==b[1] && a[0]!=c[1]) cout << "YES";
    else if (b[1]!=c[1]) cout << "NO";
    else
    {
        for (int i=0;i<9;i++)
        {
            if (b[0]==d[i]) p=i+1;
            if (c[0]==d[i]) q=i+1;
        }
        if (p>q) cout << "YES";
        else cout << "NO";
    }
    return 0;
}
