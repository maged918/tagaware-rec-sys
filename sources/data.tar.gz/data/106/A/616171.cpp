//Language: GNU C++


#include<cstdio>
char s[9],s1[9],s2[9];
int main()
{
    scanf("%s",s);
    scanf("%s%s",s1,s2);
    if (s1[0]=='T') s1[0]='A';
    else if (s1[0]=='J') s1[0]='B';
    else if (s1[0]=='Q') s1[0]='C';
    else if (s1[0]=='K') s1[0]='D';
    else if (s1[0]=='A') s1[0]='E';
    if (s2[0]=='T') s2[0]='A';
    else if (s2[0]=='J') s2[0]='B';
    else if (s2[0]=='Q') s2[0]='C';
    else if (s2[0]=='K') s2[0]='D';
    else if (s2[0]=='A') s2[0]='E';
    if (s1[1]==s[0]&&s2[1]!=s[0])
    {
        puts("YES");
    }
    else if (s1[1]==s2[1]&&s1[0]>s2[0])
    {
        puts("YES");
    }
    else puts("NO");

}
