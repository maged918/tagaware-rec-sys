//Language: GNU C++


#include <iostream>
#include <map>

using namespace std;

int main(){
  char trump; cin >> trump;
  char s1; cin >> s1;
  char n1; cin >> n1;
  char s2; cin >> s2;
  char n2; cin >> n2;

  map<char,int> rank;
  rank['6'] = 0;
  rank['7'] = 1;
  rank['8'] = 2;
  rank['9'] = 3;
  rank['T'] = 4;
  rank['J'] = 5;
  rank['Q'] = 6;
  rank['K'] = 7;
  rank['A'] = 8;
 
  bool win = false;

  if(n1 == n2){
    if(rank[s1] > rank[s2]) win = true;
  }else{
    if(n1 == trump) win = true;
  }

  cout << (win ? "YES" : "NO") << endl;

  return 0;
}
