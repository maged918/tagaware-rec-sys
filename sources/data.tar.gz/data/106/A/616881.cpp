//Language: GNU C++


#include <cstdio>
#include <iostream>
#include <cmath>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <algorithm>
#include <string>
#include <cstring>

#define FORU(i,a,b) for(int i=(a);i<=(b);i++)
#define FORD(i,a,b) for(int i=(a);i>=(b);i--)
#define maxn 52
#define PB push_back
#define ll long long

const long long oo=(long long)1e18;

using namespace std;

int main(){
map<char,int> cod;
FORU(i,'6','9') cod[i]=i-'0';
cod['T']=10;
cod['J']=11;
cod['Q']=12;
cod['K']=13;
cod['A']=14;
string tr , c1 , c2;
cin>>tr>>c1>>c2;
if (c1[1]==c2[1]){
   if (cod[c1[0]]>cod[c2[0]]) cout<<"YES\n"; else cout<<"NO\n";
   }
else if (c1[1]==tr[0]) cout<<"YES\n"; else cout<<"NO\n";

return 0;
}