//Language: GNU C++


#include<stdio.h>
#include<string>
int main()
{
	char m;
	char n1,m1,n2,m2;
	scanf("%c\n",&m);
	scanf("%c%c %c%c",&n1,&m1,&n2,&m2);
	if(n1=='A')
		n1='E';
	if(n1=='T')
		n1='A';
	if(n1=='J')
		n1='B';
	if(n1=='Q')
		n1='C';
	if(n1=='K')
		n1='D';
	
	if(n2=='A')
		n2='E';
	if(n2=='T')
		n2='A';
	if(n2=='J')
		n2='B';
	if(n2=='Q')
		n2='C';
	if(n2=='K')
		n2='D';
	

	if((m1==m2&&n1>n2)||(m1!=m2&&m1==m))
		printf("YES");
	else
		printf("NO");
	return 0;
}