//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <iostream>
using namespace std;

typedef long long int64;
typedef unsigned long long u64;
const double pi = acos(-1.0);
const double eps = 1e-8;
const int inf = ~(1<<31);
const int N = 10;

int main()
{
    int i, n, t;
    char tr, r1, r2, s1, s2;
    cin >> tr;
    getchar();
    scanf("%c%c %c%c", &r1, &s1, &r2, &s2);
    if (r1 == 'T') r1 = '9'+1;
    else if (r1 == 'J') r1 = '9'+2;
    else if (r1 == 'Q') r1 = '9'+3;
    else if (r1 == 'K') r1 = '9'+4;
    else if (r1 == 'A') r1 = '9'+5;
    if (r2 == 'T') r2 = '9'+1;
    else if (r2 == 'J') r2 = '9'+2;
    else if (r2 == 'Q') r2 = '9'+3;
    else if (r2 == 'K') r2 = '9'+4;
    else if (r2 == 'A') r2 = '9'+5;
    bool flag;
    if (s1 == s2) flag = (r1 > r2);
    else if (s1 == tr) flag = 1;
    else flag = 0;
    if (flag) cout << "YES" << endl;
    else cout << "NO" << endl;
    return 0;
}

