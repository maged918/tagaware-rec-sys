//Language: MS C++


#pragma comment(linker, "/STACK:64000000")
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include <map>
#include <set>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cassert>
#include <ctime>
#include <deque>

#define forn(i, n) for (int i = 0; i < int(n); i ++)
#define ford(i, n) for (int i = int(n) - 1; i >= 0; i --)
#define mp make_pair
#define pb push_back
#define x first
#define y second
#define pi 3.1415926535897932
#define ll long long
#define ld long double

using namespace std;

pair<int, char> s1, s2;

int f(char c){
    if (c <= '9') return int(c) - '6';
    if (c == 'T') return 4;
    if (c == 'J') return 5;
    if (c == 'Q') return 6;
    if (c == 'K') return 7;
    return 8;
}

int main(){
#ifndef ONLINE_JUDGE
    freopen ("input.txt","rt",stdin);
    freopen ("output.txt","wt",stdout);
#endif
    char c;
    scanf("%c\n", &c);
    char c1, c2;
    scanf("%c%c", &c1, &c2);
    s1 = mp(f(c1),c2);
    scanf(" %c%c", &c1, &c2);
    s2 = mp(f(c1), c2);
    bool q = false;
    if (s1.second == s2.second && s1.first > s2.first) q = true;
    if (s1.second == c && s2.second != c) q = true;
    if (q) printf ("YES");
    else printf ("NO");
    return 0;
}