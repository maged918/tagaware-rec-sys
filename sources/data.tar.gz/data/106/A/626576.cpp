//Language: GNU C++


#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cmath>
#include <utility>
#include <sstream>
#include <map>
#include <stack>
#include <queue>
#include <list>
#include <iomanip>
#include <set>

#define REP(i, n) for(int i = 0; i < (int)n; i++)
#define FORP(i, k, n) for(int i= (int)k; i < (int)n; i++)
#define FORN(i, k, n) for(int i= (int)k; i >= (int)n; i--)

using namespace std;


char cards[] = {'6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A'};

int value(char a){
    
    for(int i = 0; i < 9; ++i){
        if(a == cards[i]) return i;
    }
    return 0;

}



int main(){

    char trump;
    cin >> trump;
    string first, second;
    cin >> first >> second;
    if(first[1] != second[1]){
        if(first[1] == trump) cout << "YES" << endl;
        else cout << "NO" << endl;
    }
    else {
        if(value(first[0]) > value(second[0])) cout << "YES" << endl;
        else cout << "NO" << endl;
    }
}
