//Language: MS C++


#include <iostream>
#include <string>
using namespace std;
int i;
char m[10];
int poisk(char f)
{
         for (i = 1; i <= 9; i++)
                if (m[i] == f) return i;
}
int main(void)
{
        m[1] = '6';
        m[2] = '7';
        m[3] = '8';
        m[4] = '9';
        m[5] = 'T';
        m[6] = 'J';
        m[7] = 'Q';
        m[8] = 'K';
        m[9] = 'A';
        char c;
        cin >> c;
        string s1 = "", s2 = "";
        cin >> s1 >> s2;
        if (c == s1[1])
        {
                if (s2[1] == c)
                {
                        int k1 = poisk(s1[0]);
                        int k2 = poisk(s2[0]);
                        if ( k1 > k2)  cout << "YES";
                        else cout << "NO";
                }
                else   cout << "YES";
        }
        else
        {
                if (s2[1] == c)  cout << "NO";
                else
                {
                        if (s1[1] == s2[1])
                        {
                                 int k1 = poisk(s1[0]);
                                int k2 = poisk(s2[0]);
                                if ( k1 > k2)  cout << "YES";
                                else cout << "NO";

                        }
                        else  cout << "NO";

                }

        }



return 0;
}
