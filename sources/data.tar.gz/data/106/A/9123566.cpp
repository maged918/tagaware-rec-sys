//Language: GNU C++


#include<algorithm>  
#include<iostream>  
#include<cstdio>
#include<string.h>

using namespace std;  
int main()
{
	char ch,a[2],b[2],c[10]="6789TJQKA";
	int i,x,y;
	while(scanf("%c",&ch)!=EOF)
	{
		getchar();
		scanf("%s %s",a,b);
		getchar();
		if(a[1]==ch)
		{
			if(b[1]!=ch)
				printf("YES\n");
			else
			{
				for(i=0;i<9;i++)
				{
					if(a[0]==c[i])
						x=i;
					if(b[0]==c[i])
						y=i;
				}
				if(x<=y)
					printf("NO\n");
				else
					printf("YES\n");
			}
		}
		else 
		{
			if(a[1]==b[1])
			{
				for(i=0;i<9;i++)
				{
					if(a[0]==c[i])
						x=i;
					if(b[0]==c[i])
						y=i;
				}
				if(x<=y)
					printf("NO\n");
				else
					printf("YES\n");
			}
			else
				printf("NO\n");
		}
	}
	return 0;
}
		 			 	  			 		 		  			 		  	