//Language: MS C++


#include <iostream>
#include <string>
#include <algorithm>
using namespace std;
int main(){
	char trump;
	string card1, card2;
	cin >> trump >> card1 >> card2;
	signed int found = card1.find(trump);
	string res;
	string rank = "6789TJQKA";
	unsigned int card1Rank = rank.find(card1[0]);
	unsigned int card2Rank = rank.find(card2[0]);
	if (found == -1 && card1[1] != card2[1]) res = "NO";
	else if (found == -1 && card1[1] == card2[1] && card1Rank > card2Rank) res = "YES";
	else if (found != -1 && card1[1] != card2[1]) res = "YES";
	else if (found != -1 &&  card1[1] == card2[1] && card1Rank > card2Rank) res = "YES";
	else res = "NO";
	cout << res << endl;
}