//Language: GNU C++


#include<iostream>
using namespace std;
#include<string>
#include<map>

int main()
 {
          string s1, s2, s3;
          map <char, int> ref;
          
          ref['6']=0;
          ref['7']=1;
          ref['8']=2;
          ref['9']=3;
          ref['T']=4;
          ref['J']=5;
          ref['Q']=6;
          ref['K']=7;
          ref['A']=8;
          
          cin>>s1>>s2>>s3;
          if(s1[0]==s2[1] && s1[0]==s3[1])
           {
                          if(ref[s2[0]]>ref[s3[0]])
                                         cout<<"YES";
                          else
                                         cout<<"NO";
           }
          else if(s1[0]==s2[1])
               cout<<"YES";
          else if(s1[0]==s3[1])
               cout<<"NO";
          else
           {
               if(ref[s2[0]]>ref[s3[0]] && s2[1]==s3[1])
                                        cout<<"YES";
               else
                                        cout<<"NO";
           }
          return 0;
 }