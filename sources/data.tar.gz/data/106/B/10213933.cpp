//Language: GNU C++


//Pham Huu Canh
//B. Choosing Laptop
//Algorithm:
//Complexity:
//AC:

#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <queue>
#include <stack>
#include <map>
#include <set>

#define max64 9223372036854775807LL
#define max32 2147483647
#define maxty 1001001001
#define max16 32767
#define EPS 1e-8
#define ll long long
#define ull unsigned long long
#define pb push_back
#define MP make_pair
#define PQ priority_queue
#define LB lower_bound
#define UB upper_bound
#define fi first
#define se second
#define timmax(x, y)    ((x) > (y) ? (x) : (y))
#define timmin(x, y)    ((x) < (y) ? (x) : (y))
#define fori(i, n)      for((i) = 0; (i) < (n); (i)++)
#define ford(i, n)      for((i) = (n-1); (i) >= 0; (i)--)
#define fore(i, v)      for(typeof(v.begin()) i = v.begin(); i != v.end(); i++)
#define repi(i, a, b)   for((i) = (a); (i) <= (b); (i)++)
#define repd(i, a, b)   for((i) = (a); (i) >= (b); (i)--)
#define all(tmpv)      tmpv.begin(), tmpv.end()

#define fii "b.inp"
#define foo "b.out"
#define MOD 1000000007

using namespace std;

typedef pair<int, int> II;
typedef vector<int> VI;

void input()
{
    int i, j, n;
    int s[105], r[105], h[105], c[105];
    
    scanf("%d", &n);
    fori(i, n)  scanf("%d %d %d %d", &s[i], &r[i], &h[i], &c[i]);
    
    int res = maxty, id;
    fori(i, n){
        fori(j, n)  if (s[i] < s[j] && r[i] < r[j] && h[i] < h[j])  break;
        if (j == n && c[i] < res)   res = c[i], id = i+1;
    }
    printf("%d", id);
}

int main()
{
    #ifndef ONLINE_JUDGE
        freopen(fii,"r",stdin);
        freopen(foo,"w",stdout);
    #endif

    input();

    return 0;
}

