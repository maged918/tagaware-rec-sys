//Language: GNU C++


#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <set>
#include <vector>
#include <map>
#include <cmath>
#include <algorithm>
#include <memory.h>
#include <string>
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <cassert>

using namespace std;

typedef long long LL;
typedef pair<int,int> PII;
typedef pair<PII,char> PIIC;

#define MP make_pair
#define PB push_back
#define FF first
#define SS second

#define FORN(i, n) for (int i = 0; i <  (int)(n); i++)
#define FOR1(i, n) for (int i = 1; i <= (int)(n); i++)
#define FORD(i, n) for (int i = (int)(n) - 1; i >= 0; i--)
#define FOREACH(i, c) for (typeof((c).begin()) i = (c).begin(); i != (c).end(); i++)

#define MOD 1000000007
#define INF 2000000000

int n,i,mincost;
vector< vector< int > > computers;
vector<int> discard;
int main() {
    cin >> n;
    for (i = 0; i < n; i++){
	vector<int> t;
	t.resize(4);
	cin>>t[0];
	cin>>t[1];
	cin>>t[2];
	cin>>t[3]; //cost
	
	computers.PB(t);
    }
    
    for (i=0; i<n; i++){ //reference
	if (find(discard.begin(), discard.end(), i) != discard.end()) {continue;}
	FORN(j,n){
	    if (find(discard.begin(), discard.end(), i) != discard.end()) {continue;}
	    if (computers[i][0]>computers[j][0] && computers[i][1]>computers[j][1] && computers[i][2]>computers[j][2]){
		discard.PB(j);
	    }
	}
    }
    mincost=-1;
    for (i=0; i<n; i++){ //reference
	if (find(discard.begin(), discard.end(), i) != discard.end()) {continue;}
	if (mincost==-1) {mincost=i; continue;}
	if (computers[i][3] < computers[mincost][3]) { mincost=i;}
    }
    

    cout << mincost+1 << '\n';

    return 0;
}