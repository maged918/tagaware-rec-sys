//Language: GNU C++


#include <iostream>
#include <cstring>
using namespace std;

int n, s[110], r[110], h[110], c[110];
bool f[110];

int main()
{
        while ( cin >> n ) {
                int mc = 10000, mi = 1;
                for ( int i = 1; i <= n; ++i )  cin >> s[i] >> r[i] >> h[i] >> c[i];
                memset ( f, true, sizeof( f ) );
                for ( int i = 1; i <= n; ++i )
                        for ( int j = 1; j <= n; ++j )
                                if ( i != j )
                                        if ( s[i] < s[j] && r[i] < r[j] && h[i] < h[j] ) { f[i] = false; break; }
                for ( int i = 1; i <= n; ++i )
                        if ( f[i] && c[i] < mc ) { mc =  c[i]; mi = i; }
                cout << mi << endl;
        }
}
