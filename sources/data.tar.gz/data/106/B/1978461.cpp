//Language: GNU C++


// Codeforces.com - Problem 106B
#include <set>
#include <bitset>
#include <queue>
#include <deque>
#include <stack>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <cstring>
#include <string>
#include <cassert>
#include <vector>
#include <list>
#include <map>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#define FOR(i,begin,end) for(int i = (int)begin; i < (int)end; i++)

// map<datat,datat> mymap ~ in: mymap[tmp]++; ~ out: for(typeof((mymap).begin()) i = (mymap).begin(); i != (mymap).end(); i++) KEY: cout<<(*i).first; VALUE: cout<<(*i).second;
// set<datat> myset ~ in: s.insert(tmp); ~ out: for(typeof((myset).begin()) i = (myset).begin(); i != (myset).end(); i++) cout<<*i; 

using namespace std;
bool realMin(int x, int row,int a[101][5], int n)
{
    FOR(i,0,3)
    {
        if(a[row][i] < a[x][i])
            return false;
    }
    return true;
}
int main(int argc, char *argv[])
{
    int n;
    cin>>n;
    int a[n][5];
    FOR(i,0,n)
        FOR(j,0,4)
            cin>>a[i][j];
    // 
    FOR(i,0,n)
    {
        a[i][4] = 0;
        FOR(j,0,n)
        {
            if(a[i][0] < a[j][0] && realMin(i,j,a,n) && a[j][0] != 1)
                a[i][4] = 1;
        }
    }
  //  FOR(i,0,n)
  //  {
 //       FOR(j,0,5)
  //          cout<<a[i][j]<<" ";
  //      cout<<endl;
   // }
    int x,mn;
    mn = 1001;
    FOR(i,0,n)
    {
        
        if(a[i][3] < mn && a[i][4] == 0)
        {
            mn = a[i][3];
            x = i;
        }
    }
    cout<<x+1;
    return 0;
}