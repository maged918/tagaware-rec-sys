//Language: GNU C++


#include<iostream>
using namespace std;
int a[100][5];
int main(){
    int n,i,j,t=10010,m;
    cin>>n;
    for (i=0;i<n;i++) cin>>a[i][0]>>a[i][1]>>a[i][2]>>a[i][3];
    
    for (i=0;i<n;i++)
     for (j=0;j<n;j++)
      if (a[i][0]<a[j][0] && a[i][1]<a[j][1] &&a[i][2]<a[j][2] ) a[i][4]=1;
      
    for (i=0;i<n;i++)
     if (!a[i][4] && t>a[i][3]) {t=a[i][3];m=i+1;}
        
    cout<<m; 
    //system("pause"); 
}
