//Language: GNU C++


//In the name of God

#include <iostream>
using namespace std;
const int MAXN=110;
int a[MAXN],b[MAXN],c[MAXN],d[MAXN];
bool e[MAXN];
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i]>>b[i]>>c[i]>>d[i];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(a[i]<a[j] && b[i]<b[j] && c[i]<c[j])
				e[i]=true;
	int min=0;
	for(int i=1;i<=n;i++)
		if(min==0 && e[i]==false)
			min=i;
		else if(e[i]==false && d[i]<d[min]) 
			min=i;
	cout<<min<<endl;
	return 0;
}
