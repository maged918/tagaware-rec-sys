//Language: GNU C++


#include <cstdlib>
#include <cctype>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <sstream>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <fstream>
#include <numeric>
#include <iomanip>
#include <bitset>
#include <list>
#include <stdexcept>
#include <functional>
#include <utility>
#include <ctime>
using namespace std;
const int maxs = 1003;

int n;
struct node
{
	int s,r,h;
	int price;
};
node lap[maxs];
bool flag[maxs];

int main()
{
	while (cin >> n)
	{
		memset(flag,false,sizeof(flag));
		for (int i=0;i<n;i++)
		{
			cin >> lap[i].s >> lap[i].r >> lap[i].h >> lap[i].price;
		}
		for (int i=0;i<n;i++)
		{
			for (int j=0;j<n;j++)
			{
				if (i==j)	continue;
				if (lap[i].s<lap[j].s && lap[i].r<lap[j].r && lap[i].h<lap[j].h)
				{
					flag[i] = true;break;
				}
			}
		}
		int mins = 10000000,index=0;
		for (int i=0;i<n;i++)
		{
			if (flag[i] ==false && lap[i].price<mins)
			{
				mins = lap[i].price ;
				index = i;
			}
		}
		cout << index+1 <<endl;
	}
	return 0;
}