//Language: MS C++


#include <stdio.h>        
#include <string.h>        
#include <ctype.h>        
#include <stdlib.h>      

int comp(const void *a, const void *b) {   
	return ((*(int *)a) - (*(int *)b));   
}   

int min(int a, int b) {
	return (a < b ? a : b);
}

int max(int a, int b) {
	return (a > b ? a : b);
}
int n, a[110][4], m = -1;
bool u[110];


int main() {     
	//freopen("input.txt", "r", stdin);      
	//freopen("output.txt", "w", stdout);   
	scanf("%d", &n);  
	for (int i = 0; i < n; i++) {
		scanf("%d%d%d%d", &a[i][0], &a[i][1], &a[i][2], &a[i][3]);
		u[i] = 0;
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (i == j || u[j])
				continue;
			if (a[i][0] < a[j][0] && a[i][1] < a[j][1] && a[i][2] < a[j][2]) {
				u[i] = true;
				break;
			}
		}
		if (!u[i] && (a[i][3] < a[m][3] || m == -1))
			m = i;
	}

	printf("%d", ++m);
	return 0; 
}