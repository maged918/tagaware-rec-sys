//Language: GNU C++


#include <stdio.h>
#include <assert.h>
#include <vector>
#include <algorithm>

using namespace std;

struct Laptop {
	int speed;
	int ram;
	int hdd;
	int cost;
	int id;
	bool operator < (const Laptop & b) const {
		return cost < b.cost;
	}
};

int main() {
	int n;
	scanf("%d", &n);
	vector<Laptop> list;
	for(int id=1; id<=n; ++id) {
		Laptop laptop;
		laptop.id = id;
		scanf("%d%d%d%d", &laptop.speed, &laptop.ram, &laptop.hdd, &laptop.cost);
		list.push_back(laptop);
	}
	sort(list.begin(), list.end());
	for(int i=0, s=list.size(); i<s; ++i) {
		bool flag = true;
		for(int j=i+1; j<s; ++j) {
			if(list[i].speed<list[j].speed && list[i].ram<list[j].ram && list[i].hdd<list[j].hdd) {
				flag = false;
				break;
			}
		}
		if(flag) {
			printf("%d\n", list[i].id);
			break;
		}
	}
	return 0;
}
