//Language: GNU C++


#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
typedef struct lap 
{ int speed, ram, hdd,cost,index;
}lap;

bool comp(lap l1, lap l2){
  return l1.cost <= l2.cost;
}

bool outdated(lap l1, lap l2) {
    
   if(l1.speed < l2.speed && l1.ram < l2.ram && l1.hdd < l2.hdd )
     return true;
   return false;
}



main(){

  lap in[100];
  int n;

  cin>>n;
  for(int i = 0; i < n; i++){
    cin>>in[i].speed>>in[i].ram>>in[i].hdd>>in[i].cost;
    in[i].index = i+1;
  }
  
  vector<lap> inp(in, in+n);
  vector<lap>::iterator it,jt;
  sort(inp.begin(), inp.end(), comp);
 // for(it = inp.begin(); it != inp.end(); ++it){
 //   cout<<it->speed<<" "<<it->ram<<" "<<it->cost<<endl;
 // }
  
  int flag = 0; 
  for( it = inp.begin(); it != inp.end(); ++it){
    flag = 0;
    for(jt = it+1; jt != inp.end(); ++jt){
      if(outdated(*it,*jt)){ 
        flag = 1;
        break;
      }
    }
    if(flag == 0 ) {
       cout<< it->index;
       break;
    }
 }

}



