//Language: GNU C++


#include<iostream>
#include<string>
#include<string.h>
#define drop 9999

using namespace std;
int main(){

    int num=0;
    while(cin>>num){
        int speed[101]={0};
        int ram[101]={0};
        int hdd[101]={0};
        int cost[101]={0};

        int i=0;
        int j=0;
        for(i=0;i<num;i++){
            cin>>speed[i]>>ram[i]>>hdd[i]>>cost[i];
        }

        for(i=0;i<num;i++){             /*���T������ܧC��*/
            for(j=0;j<num;j++){
                if(i==j)
                    continue;
                if(speed[i]<speed[j]&&ram[i]<ram[j]&&hdd[i]<hdd[j]){
                    cost[i]=drop;
                    break;
                }
            }
        }
        int min=1001;
        int answer=0;
        for(i=0;i<num;i++){             /*�D�̫K�y��*/
            if(cost[i]<min){
                min=cost[i];
                answer=i;
            }
        }
        answer++;
        cout<<answer<<endl;

    }
    return 0;
}
