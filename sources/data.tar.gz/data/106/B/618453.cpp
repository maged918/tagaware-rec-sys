//Language: GNU C++


#include<iostream>
#include<vector>
using namespace std;
string tr,f,s,rank;
int get(char c){
  int i,j;
  for(i=0;i<rank.size();i++)
    {
        if(rank.at(i)==c)
        return i;
    }
}
main()
{
vector<vector<int> > p1;
vector<int> em;
int n,i,j,k,x1,x2,x3,x4;
cin>>n;
int minc = -1;
int minN = -1;
    for(i=0;i<n;i++)
    {
        p1.push_back(em);
        cin>>x1>>x2>>x3>>x4;
        p1[i].push_back(x1);
        p1[i].push_back(x2);    
        p1[i].push_back(x3);
        p1[i].push_back(x4);
    }
    for(i=0;i<n;i++)
    {
        int outD = 0;
        for(j=0;j<n;j++)
        {
            if(p1[i][0] < p1[j][0] && p1[i][1] < p1[j][1] && p1[i][2] < p1[j][2])
            {outD = 1;break;}
        }
        if(outD == 0)
        {
            if(minc == -1 || minc >=p1[i][3])
            {minc=p1[i][3];minN = i;}
        }
    }
    cout<<minN+1<<endl;
}