//Language: GNU C++


#include<cstdio>
#include<algorithm>

#define rep(i,n) for(int i=0;i<(n);i++)

using namespace std;

const int INF=1<<29;

int main(){
	int n,a[4][100]; scanf("%d",&n);
	rep(i,n) rep(j,4) scanf("%d",a[j]+i);

	rep(i,n){
		bool outdate=false;
		rep(j,n) if(a[0][i]<a[0][j] && a[1][i]<a[1][j] && a[2][i]<a[2][j] && a[3][i]<a[3][j]) outdate=true;
		if(outdate) a[3][i]=INF;
	}

	printf("%d\n",1+min_element(a[3],a[3]+n)-a[3]);

	return 0;
}
