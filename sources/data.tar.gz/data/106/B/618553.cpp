//Language: MS C++


#include <iostream>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <map>
#include <string>
#include <string.h>
using namespace std;

struct notebook
{
    int speed;
    int ram;
    int hdd;
    int cost;
};
bool speed_pr(notebook elem1,notebook elem2)
{
    return elem1.speed>elem2.speed;
}
bool ram_pr(notebook elem1,notebook elem2)
{
    return elem1.ram>elem2.ram;
}
bool hdd_pr(notebook elem1,notebook elem2)
{
    return elem1.hdd>elem2.hdd;
}
bool cost_pr(notebook elem1,notebook elem2)
{
    return elem1.cost>elem2.cost;
}
int main()
{
    
    int n;
    cin>>n;
    vector<notebook> notes(n);
    for (int i=0;i<n;i++)
        cin>>notes[i].speed>>notes[i].ram>>notes[i].hdd>>notes[i].cost;
    vector<notebook> tmp(notes);
    sort(tmp.begin(),tmp.end(),speed_pr);
    for (int i=0;i<tmp.size();i++)
    {
        vector<int> del;
        for (int j=0;j<tmp.size();j++)
        {
            if (tmp[j].speed<tmp[i].speed && tmp[j].hdd<tmp[i].hdd && tmp[j].ram<tmp[i].ram)
                del.push_back(j);
        }
        for (int q=del.size()-1;q>=0;q--)
            tmp.erase(tmp.begin()+del[q]);
    }
    sort(tmp.begin(),tmp.end(),cost_pr);
    for (int i=0;i<notes.size();i++)
    {
        if (notes[i].cost==tmp[tmp.size()-1].cost)
            {
                cout<<i+1<<endl;
                return 0;
            }
    }
    return 0;
}
