//Language: GNU C++


#include <iostream>
#include <vector>

using std::cin;
using std::cout;
using std::endl;
using std::vector;

class Notebook
{
    int _speed;
    int _ram;
    int _hdd;
    int _cost;
    int _old;

public:
    Notebook()
        : _old(0)
    {}

    void setOld()
    {
        _old = 1;
    }

    int isOld()
    {
        return _old;
    }

    void setParameters(int speed, int ram, int hdd, int cost)
    {
        _speed = speed;
        _ram   = ram;
        _hdd   = hdd;
        _cost  = cost;
    }

    int operator<(const Notebook& n)
    {
        if ((_speed < n._speed) && (_hdd < n._hdd) && (_ram < n._ram))
            return 1;
        else
            return 0;
    }

    int getCost() const
    {
        return _cost;
    }

    ~Notebook()
    {}
};

int main()
{
    int n = 0;
    cin >> n;

    vector<Notebook> notebooks(n);

    for (int i = 0; i < n; ++i)
    {
        int speed, ram, hdd, cost;
        cin >> speed >> ram >> hdd >> cost;

        notebooks[i].setParameters(speed, ram, hdd, cost);
    }

    for (int i = 0; i < n; ++i)
    for (int j = 0; j < n; ++j)
    {
        if (notebooks[i] < notebooks[j])
        {
            notebooks[i].setOld();
        }
    }

    int best_i = 0;

    while (notebooks[best_i].isOld())
        ++best_i;

    for (int i = best_i + 1; i < n; ++i) 
    {
        if ((notebooks[i].isOld() == 0) && (notebooks[i].getCost() < notebooks[best_i].getCost()))
            best_i = i;
    }

    cout << best_i + 1 << endl;

    return 0;
}

