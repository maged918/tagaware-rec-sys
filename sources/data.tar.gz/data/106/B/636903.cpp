//Language: GNU C++


     #include<iostream>
     #include<string>
      #include<algorithm>
    #include<cstdio>
    using namespace std;
    #define INF 1000000
    
    
    int n,s[102],r[102],h[102],c[102],mark[102],v[102];
    
    int main()
    {
        int i,j,k;
        
        while(scanf("%d",&n)==1)
        {
            c[0]=INF;
            for(i=1;i<=n;i++)
            {
               scanf("%d%d%d%d",&s[i],&r[i],&h[i],&c[i]);
               v[i]=c[i];
               mark[i]=1;
            }
            
            for(i=1;i<=n;i++)
            {
                for(j=i+1;j<=n;j++)
                {
                    if(mark[i] && mark[j])
                    {
                        if(s[i]<s[j] && h[i]<h[j] && r[i]<r[j]) mark[i]=0,c[i]=INF;
                        else  if(s[j]<s[i] && h[j]<h[i] && r[i]>r[j]) mark[j]=0,c[j]=INF;      
                        
                    }
                }
            }
            
            sort(c,c+n+1);
            for(i=1;i<=n;i++)
            {
                if(v[i]==c[0])
                {
                    printf("%d\n",i);
                    break;
                }
            }
        }
        return 0;
    }
