//Language: GNU C++


#include<stdio.h>
struct kk{
	int s,r,h,c;
}a[101];
int main(){
	int n,i,j,best,nbest;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d%d%d%d",&a[i].s,&a[i].r,&a[i].h,&a[i].c);
	}
	best=10000;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(a[i].s<a[j].s&&a[i].r<a[j].r&&a[i].h<a[j].h){
				a[i].c=9999;
				break;
			}
		}
		if(a[i].c<best){
			best=a[i].c;
			nbest=i+1;
		}
	}
	printf("%d\n",nbest);
}