//Language: GNU C++


#include <iostream>
#include <stdio.h>
#include <algorithm>
#include <string.h>
using namespace std;


int main()
{
int n,c0,d0,m,a[105],b[105],c[105],d[105];
int f[1005][105]={0};

//freopen("i.txt","r",stdin);
cin>>n>>m>>c0>>d0;
for(int i=1; i<=m; i++)
cin>>a[i]>>b[i]>>c[i]>>d[i];
for(int i=0; i<=n; i++)
f[i][0]=i/c0*d0;

for(int j=1; j<=m; j++)
for(int i=0; i<=n; i++)
{
 int q=0;
for (int k=0; k<=i; k++)
{int l=min(k/c[j],a[j]/b[j]);
    int x=l*d[j]+f[i-k][j-1];
    if (x>q) q=x;
}
f[i][j]=q;
}

cout<<f[n][m];
    return 0;
}
