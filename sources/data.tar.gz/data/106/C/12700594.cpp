//Language: GNU C++


#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct pro
{
	int a,b,c,d;
}arr[1001];
int a,b,c,d,i,j,k,ans,n,m;
int dp[15][1100];
int main()
{
	ios_base::sync_with_stdio(false);cin.tie(0);
	cin>>n>>m>>c>>d;
	for(i=1;i<=m;i++)
		cin>>arr[i].a>>arr[i].b>>arr[i].c>>arr[i].d;
	memset(dp,0,sizeof(dp));
	for(i=1;i<=m;i++)
	{
		for(j=0;j<=n;j++)
		{
			for(k=0;k<=arr[i].a/arr[i].b;k++)
			{
				if(j-k*arr[i].c>=0)
				{
					dp[i][j]=max(dp[i][j],arr[i].d*k + dp[i-1][j-k*arr[i].c]);
				}
			}
		}
	}
	ans=-1;
	for(i=0;i<=n;i++)
	{
		ans=max(ans,dp[m][i]+((n-i)/c)*d);
	}
	cout<<ans;
}

