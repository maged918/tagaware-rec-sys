//Language: GNU C++


#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;
#define MAXM 10
#define MAXDOUGH 1000
int N, M, C0, D0;

int maxM[MAXM+3];
int dp[MAXDOUGH+5][MAXM+3];
int A[MAXM+3];
int B[MAXM+3];
int C[MAXM+3];
int D[MAXM+3];

int main()
{
	scanf("%d %d %d %d", &N, &M, &C0, &D0);
	for (int i = 1; i <= M; i++) {
		scanf("%d %d %d %d", &A[i], &B[i], &C[i], &D[i]);
		maxM[i] = min(N / C[i], A[i] / B[i]);
	}
	memset(dp, -1, sizeof dp);
	dp[0][0] = 0;
	int x = D0;
	for (int i = C0; i <= N; i += C0) {
		dp[i][0] = x;
		x += D0;
	}
	int nextDough, buns, bunWt, money;
	for (int k = 1; k <= M; k++) {
		x = D[k];
		bunWt = C[k];
		for (int i = 0; i <= N; i++) {
			buns = min(maxM[k], (N-i) / bunWt);
			if (buns > 0 && dp[i][k-1] >= 0) {
				// can create up to buns
				nextDough = i;
				money = dp[i][k-1];
				for (int m = 1; m <= buns; m++) {
					nextDough += bunWt;
					money += x;
					if (nextDough <= N) {
						if (money > dp[nextDough][k]) {
							dp[nextDough][k] = money;
						}
					} else {
						break;
					}
				}
			}
			dp[i][k] = max(dp[i][k], dp[i][k-1]);
		}
	}
	int maxMoney = 0;
	for (int i = 0; i <= N; i++) {
		maxMoney = max(maxMoney, dp[i][M]);
	}
	printf("%d\n", maxMoney);
	return 0;
}
