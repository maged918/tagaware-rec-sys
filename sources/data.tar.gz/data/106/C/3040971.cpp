//Language: GNU C++


#include<iostream>
#include<algorithm>
using namespace std;
int p[13][1001]={0};
int main()
{
    int n,m,a[13],c[13],d[13];
    cin>>n>>m;
    cin>>c[0]>>d[0];
    int i=1;
    for(;i<=m;i++)
    {
        int b1,b2;
        cin>>b1>>b2>>c[i]>>d[i];
        if(b2>b1)
        i--,m--;
        else
        {
            a[i]=b1/b2;
            //cout<<a[i]<<"a\n";
        }
    }
    m=i;

    for(i=1;i<=n;i++)
    {
        p[0][i]=d[0]*(i/c[0]);
        //cout<<p[0][i]<<" ";
    }
    //cout<<"\n"<<p[0][n]<<"b\n";
    for(i=1;i<m;i++)
    {
       for(int j=1;j<=n;j++)
       {
           int s=j/c[i];
           int max=p[i-1][j],mn=min(a[i],s);
           //cout<<p[i-1][j]<<" "<<i-1<<" "<<j<<"\n";
           for(int h=1,l=j;h<=mn;h++)
           {
               l -= c[i];
               int t=p[i-1][l]+h*d[i];
               if(max<t)
               max=t;
           }
           p[i][j]=max;
           //cout<<p[i][j]<<" "<<i<<" "<<j<<"\n";
       }
    }
    /*for(i=0;i<m;i++)
    {
       for(int j=1;j<=n;j++)
       cout<<p[i][j]<<" ";
       cout<<"\n";
    }*/
    //cout<<p[0][n]<<"p";
    cout<<p[m-1][n]<<"\n";
}
