//Language: GNU C++


#include<iostream>
#include<stdio.h>
#include<algorithm>
#include<string.h>
using namespace std;
const int INF = 0x3f3f3f3f;
int dp[1005];
int w[10005],v[10005];
int top = 0;
int main(){
	int n,m,c,d;
	scanf("%d%d%d%d",&n,&m,&c,&d);
	for(int i = 0;i < 1000;i ++){
		w[top] = c;
		v[top ++] = d;
	}
	int ta,tb,tc,td;
	for(int i = 0;i < m;i ++){
		scanf("%d%d%d%d",&ta,&tb,&tc,&td);
		for(int j = 1;j <= ta / tb;j ++){
			w[top] = tc;
			v[top ++] = td;
		}
	}
	for(int i = 0;i < top;i ++){
		for(int j = n;j >= w[i];j --){
			dp[j] = max(dp[j],dp[j - w[i]] + v[i]);
		}
	}
	printf("%d\n",dp[n]);
	return 0;
}
 			   	   		 							 				