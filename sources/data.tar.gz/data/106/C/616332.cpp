//Language: GNU C++


#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <deque>
#include <queue>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <utility>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstdio>

using namespace std;

#define REP(i,n) for((i)=0;(i)<(int)(n);(i)++)
#define foreach(c,itr) for(__typeof((c).begin()) itr=(c).begin();itr!=(c).end();itr++)

#define INF (1<<29)

int cap[20],x[20],price[20];
int dp[20][1010];

int main(void){
    int N,X,a,b,i,j,k;
    
    cin >> X >> N >> x[0] >> price[0];
    cap[0] = INF;
    REP(i,N){
        cin >> a >> b >> x[i+1] >> price[i+1];
        cap[i+1] = a/b;
    }
    N++;
    
//  REP(i,N) cout << cap[i] << ' ' << x[i] << ' ' << price[i] << endl;
    
    REP(i,N) REP(j,X+1) for(k=0;k<=cap[i]&&j+k*x[i]<=X;k++) dp[i+1][j+k*x[i]] = max(dp[i+1][j+k*x[i]],dp[i][j]+price[i]*k);
    
    cout << dp[N][X] << endl;
    
    return 0;
}
