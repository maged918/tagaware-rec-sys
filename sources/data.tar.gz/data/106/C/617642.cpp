//Language: GNU C++


#include <cctype>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <vector>
#include <string>
#include <iostream>
#include <map>
#include <set>
#include <queue>
#include <stack>
using namespace std;

#define PB push_back
#define MP make_pair

typedef vector<int> VI;
typedef vector<string> VS;
typedef vector<double> VD;
typedef long long LL;
typedef pair<int,int> PII;

int dp[20][1010];

int a[20], b[20], c[20], d[20];

int main(){
	int i, j, k, m, n;
	scanf("%d%d%d%d", &n, &m, c + 1, d + 1);
	for(i = 2; i <= m + 1; i++){
		scanf("%d%d%d%d", a + i, b + i, c + i, d + i);
	}
	a[1] = 10000;
	b[1] = 0;
	memset(dp, 0, sizeof(dp));
	for(i = 1; i <= m + 1; i++){
		for(k = n; k >= 0; k--)
			dp[i][k] = dp[i-1][k];
		for(j = 1; j * b[i] <= a[i] && j * c[i] <= n; j++){
			int u = j * c[i];
			for(k = n; k >= u; k--){
				dp[i][k] = max(dp[i][k], dp[i-1][k-u] + j * d[i]);
			}
			//printf("%d\n", dp[i][n]);
		}
	}
	printf("%d\n", dp[m + 1][n]);
	//scanf("%*d");
}
