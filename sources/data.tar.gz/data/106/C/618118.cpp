//Language: GNU C++


#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <algorithm>
#include <iomanip>
using namespace std;


int dp[1005][12];
int main() {
    vector<int>a,b,c,d;
    int n,m,tmpc,tmpd;
    int r = 0;
    cin >> n >> m >> tmpc >> tmpd;
    a.push_back(1);
    b.push_back(0);
    c.push_back(tmpc);
    d.push_back(tmpd);
    for (int i=0; i<m; i++) {
        int ta,tb,tc,td;
        cin >> ta >> tb >> tc >> td;
        a.push_back(ta);
        b.push_back(tb);
        c.push_back(tc);
        d.push_back(td);
    }
    for (int i=n; i>=0; i--) {
        dp[i][0] = (n-i)/c[0]*d[0];
    }
    for (int i=0; i<m; i++) {
        for (int j=n; j>=0; j--) {
            for (int k=j; k>=0; k--) {
                int ko = (j-k)/c[i+1];
                if (ko*b[i+1]>a[i+1])ko = a[i+1]/b[i+1];
                dp[k][i+1] = max(dp[k][i+1] ,dp[j][i] + ko*d[i+1]);
            }
        }
    }
    cout << dp[0][m] << endl;
    return 0;
}
